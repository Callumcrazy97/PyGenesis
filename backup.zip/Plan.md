# PyGenesis & Nova Development Plan

**Last Updated**: Based on feasibility analysis and current architecture assessment  
**Status**: Actionable roadmap for Nova and PyGenesis improvements

---

## Executive Summary

This plan consolidates the most beneficial recommendations from feasibility analysis, focusing on **bounded, deterministic, infrastructure-first** improvements that align with PyGenesis's architecture and Nova's design philosophy.

**Core Principle**: Nova is a **planner and executor over deterministic subsystems**, not a free-roaming AI. PyGenesis is a **solo-friendly, metadata-driven game engine**, not a physics simulation competitor.

**Core Policies** (non-negotiable):
- **User Override Always Wins**: Nova may suggest, plan, and execute — but user code always overrides Nova behavior
- **Failure Is a Valid Outcome**: Nova is allowed to say "I ran out of time", "This is incomplete", "This needs human input", "I cannot safely proceed"
- **Honest Reporting**: Nova must summarize limitations, skipped tasks, and incomplete work — this is a strength, not a weakness

---

## Top 10 Areas to Improve

### 1. **Time-Boxed Execution Controller** (Nova)
**Priority**: 🔴 **CRITICAL**  
**Status**: Not implemented  
**Benefit**: Enables autonomous task execution with time budgets, preventing runaway processes and fake "finished" claims.

**What's Needed**:
- `TimeBoxedExecutionController` wrapper around `OperationPlanner`, `Executors`, and `TransactionManager`
- Time budget tracking and clean shutdown when budget expires
- Task graph execution with progress reporting

---

### 2. **Constrained Code Authoring System** (Nova)
**Priority**: 🔴 **CRITICAL**  
**Status**: Partially implemented (validation exists, generation missing)  
**Benefit**: Allows Nova to safely write PGSL/Python code through infrastructure, not direct file manipulation.

**What's Needed**:
- Operation-based code editing (not direct file writes)
- Template-based PGSL generation
- Context-aware code insertion (`EditorContext.SCRIPT`, `EditorContext.OBJECT_EVENT`, etc.)
- Full validation pipeline integration

---

### 3. **Physics-Driven Gameplay Framework** (PyGenesis)
**Priority**: 🟠 **HIGH**  
**Status**: Not implemented  
**Benefit**: Provides perceived realism via impulse + metadata, ideal for solo developers and Nova analysis.

**What's Needed**:
- Instance-level physics state (matches object model)
- Impulse-based interactions (no continuous solvers)
- Metadata-driven system (JSON + PGSL)
- Editor-friendly (no hard rendering coupling)

**Non-Goals** (explicitly excluded):
- ❌ Fluids
- ❌ Deformables
- ❌ Muscle simulation

---

### 4. **Combat System Metadata** (PyGenesis)
**Priority**: 🟠 **HIGH**  
**Status**: Not implemented  
**Benefit**: AI-friendly, testable, deterministic balance system that Nova can analyze and tune.

**What's Needed**:
- JSON-based combat metadata (damage, health, cooldowns, etc.)
- Designer-modifiable data, engine-evaluated math
- Enables Nova-assisted balancing (Phase 3)
- Supports replay analysis and difficulty scaling

---

### 5. **Nova Code Generation Rules** (Nova)
**Priority**: 🟠 **HIGH**  
**Status**: Not implemented  
**Benefit**: Ensures Nova generates valid, context-appropriate code that passes validation.

**What's Needed**:
- PGSL syntax templates and patterns
- Context-specific code generation rules
- Integration with `UnifiedValidationPipeline`
- Sandbox testing before commit

---

### 6. **Operation Schema for Code Edits** (Nova)
**Priority**: 🟠 **HIGH**  
**Status**: Not implemented  
**Benefit**: Standardizes how Nova proposes and executes code changes, ensuring auditability.

**What's Needed**:
- `Operation` schema for code edits (insert_block, modify_function, etc.)
- Preview system before execution
- Diff generation and review
- Atomic transaction commits

---

### 7. **Task Graph Progress Reporting** (Nova)
**Priority**: 🟡 **MEDIUM**  
**Status**: Partially implemented (TaskManager exists)  
**Benefit**: Users see real progress during time-boxed execution, not fake "thinking" states.

**What's Needed**:
- Real-time task execution status
- Estimated completion times
- Skipped vs. completed task reporting
- Clean shutdown summaries

---

### 8. **Nova-Assisted Balancing System** (PyGenesis + Nova)
**Priority**: 🟢 **LOW (Phase 3)**  
**Status**: Not implemented  
**Benefit**: Rule-based, heuristic-assisted game balance analysis without cloud LLMs.

**What's Needed** (Phase 3):
- Event logging system
- Physics metadata capture
- Combat outcome tracking
- Outlier detection and imbalance flagging
- Tuning delta suggestions

**Approach**: Rule-based first → Heuristic second → AI-assisted last

---

### 9. **EditorContext Integration** (Nova + PyGenesis)
**Priority**: 🟡 **MEDIUM**  
**Status**: Partially implemented (`EditorContext` enum exists)  
**Benefit**: Ensures Nova generates code appropriate for the context (script, object event, shader).

**What's Needed**:
- Full `EditorContext` awareness in code generation
- Context-specific built-in recognition (already done for `OBJECT_EVENT`)
- Context validation in operation planner
- Context-based template selection

---

### 10. **Transaction Safety Enhancements** (Nova)
**Priority**: 🟡 **MEDIUM**  
**Status**: Implemented but needs enhancement  
**Benefit**: Ensures Nova never exceeds time limits, never deletes without confirmation, always summarizes limitations.

**What's Needed**:
- Time budget enforcement in `TransactionManager`
- Deletion confirmation gates
- Limitation summary generation
- Rollback on budget exhaustion

---

### 11. **Engine Capability Introspection Layer** (Nova + PyGenesis)
**Priority**: 🟠 **HIGH**  
**Status**: Not implemented  
**Benefit**: Nova knows what the engine can actually do right now, preventing hallucinated workflows and enabling honest "cannot do yet" responses.

**What's Needed**:
- `EngineCapabilities` registry (JSON-based capability manifest)
- Capability query API for Nova
- Auto-update as engine evolves
- Integration with `OperationPlanner` to reject unsupported features

**Example Structure**:
```python
EngineCapabilities = {
    "physics": {
        "impulse": True,
        "continuous_solver": False
    },
    "rendering": {
        "instancing": True,
        "compute_shaders": True
    },
    "networking": {
        "authoritative": False,
        "p2p": True
    }
}
```

**Benefits**:
- Nova never suggests unsupported features
- Nova adapts to engine evolution
- Prevents hallucinated workflows
- Enables honest "cannot do yet" responses

---

### 12. **Deterministic Replay Core (Foundation)** (PyGenesis)
**Priority**: 🟡 **MEDIUM**  
**Status**: Not implemented  
**Benefit**: Enables future balance analysis, regression testing, Nova debugging, and "why did this happen?" investigation.

**What's Needed** (Foundation Only):
- Input capture system
- Event ordering mechanism
- Seed control for randomness
- Minimal replay storage format

**Why Now** (even minimal):
- Low-cost foundation now, expensive later if ignored
- Enables future balance analysis
- Enables regression testing
- Enables Nova debugging
- Enables "why did this happen?" investigation

**Not a Full Replay System Yet**:
- Just foundation: input capture, event ordering, seed control
- Full replay UI and analysis comes later (Phase 3)

---

### 13. **User Override Policy (Explicit)** (Nova)
**Priority**: 🔴 **CRITICAL**  
**Status**: Implicit, needs explicit implementation  
**Benefit**: Prevents AI hostility concerns, prevents "AI taking control" fear, makes Nova a tool not authority, helps adoption and trust.

**What's Needed**:
- Written policy in code and documentation
- Enforcement in `OperationPlanner` and `TransactionManager`
- UI indicators when user code overrides Nova suggestions
- Clear messaging: "User code always wins"

**Policy Statement**:
> **Nova may suggest, plan, and execute — but user code always overrides Nova behavior.**

**Protects**:
- Social and legal concerns
- User trust and adoption
- Nova as tool, not authority

---

### 14. **Failure-as-Success UX (Explicit)** (Nova)
**Priority**: 🟠 **HIGH**  
**Status**: Partially implemented, needs explicit UX  
**Benefit**: Makes Nova's honesty a differentiator, not a weakness. Allows Nova to say "I cannot safely proceed" without user frustration.

**What's Needed**:
- Explicit UX patterns for failure states
- Clear messaging: "I ran out of time", "This is incomplete", "This needs human input", "I cannot safely proceed"
- UI that celebrates honest reporting
- Documentation that frames failure as strength

**Failure States Nova Should Express**:
- "I ran out of time" (time budget exhausted)
- "This is incomplete" (partial work done)
- "This needs human input" (blocked by ambiguity)
- "I cannot safely proceed" (safety gate triggered)

**This is not a weakness** — it is one of PyGenesis's strongest differentiators.

---

## Recommendations

### For Nova

#### 1. Implement Time-Boxed Execution Controller

**Location**: `Core/AI/PyGenesisAssistant/Nova/core/time_boxed_controller.py`

**Responsibilities**:
- Wrap `OperationPlanner`, `Executors`, and `TransactionManager`
- Track time budget and stop cleanly when exhausted
- Report executed vs. skipped tasks
- Prevent fake "finished" claims

**Key Methods**:
```python
class TimeBoxedExecutionController:
    def execute_with_budget(self, goal: str, time_budget: float) -> ExecutionReport
    def check_budget_remaining(self) -> bool
    def stop_cleanly(self) -> ExecutionSummary
```

**Integration Points**:
- `WorkflowPipeline._execute_with_plan()` - Add time budget parameter
- `TransactionManager` - Add time tracking
- `TaskManager` - Add progress reporting

---

#### 2. Implement Constrained Code Authoring

**Location**: `Core/AI/PyGenesisAssistant/Nova/core/code_authoring.py`

**Responsibilities**:
- Generate PGSL/Python code via templates
- Create `Operation` objects for code edits
- Validate before commit
- Test in sandbox before applying

**Key Components**:
- `PGSLTemplateEngine` - Template-based code generation
- `CodeOperationBuilder` - Creates operation objects
- `CodeValidationGate` - Pre-commit validation
- Integration with `UnifiedCodeEditor` and `UnifiedValidationPipeline`

**Five Boundaries** (must enforce):
1. **Language Contract**: PGSL first (Simple Mode), PGSL or Python (Advanced Mode)
2. **Structural Context**: Always write into known `EditorContext`
3. **Deterministic Generation**: Templates and patterns, not freeform
4. **Validation Pipeline**: Generate → Validate → Test → Diff → Commit
5. **Time & Scope Governor**: Only touch declared files, stop on budget

---

#### 3. Define Operation Schema for Code Edits

**Location**: `Core/AI/PyGenesisAssistant/Nova/core/operations/code_operations.py`

**Operation Types**:
```python
@dataclass
class InsertCodeBlockOperation:
    file: str
    location: str  # Function name, event name, or line number
    code: str
    context: EditorContext

@dataclass
class ModifyFunctionOperation:
    file: str
    function_name: str
    new_code: str
    context: EditorContext

@dataclass
class ReplaceValueOperation:
    file: str
    variable_name: str
    new_value: Any
    context: EditorContext
```

**Integration**:
- `OperationPlanner` - Generate these operations
- `TransactionManager` - Execute atomically
- Preview system - Show diffs before commit

---

#### 4. Enhance Task Graph Progress Reporting

**Location**: `Core/AI/PyGenesisAssistant/Nova/core/tasks.py` (enhance existing)

**Add**:
- Real-time execution status updates
- Estimated completion times per task
- Progress percentage calculation
- Skipped task reporting (when budget exhausted)

**UI Integration**:
- Update `TasksDialog` to show live progress
- Add progress bar for time-boxed executions
- Show "X of Y tasks completed" status

---

#### 5. Implement Engine Capability Introspection

**Location**: `Core/Engine/capabilities.py` (new file)

**Responsibilities**:
- Maintain `EngineCapabilities` registry
- Provide capability query API for Nova
- Auto-update as engine evolves
- Reject operations that require unsupported features

**Key Components**:
- `EngineCapabilitiesRegistry` - Central capability store
- `CapabilityQueryAPI` - Query interface for Nova
- `CapabilityValidator` - Validates operations against capabilities
- Integration with `OperationPlanner` to reject unsupported features

**Integration Points**:
- `OperationPlanner` - Check capabilities before planning
- `Nova` - Query capabilities before suggesting features
- `GameGenerator` - Report actual engine capabilities
- Documentation - Auto-generate capability docs

**Benefits**:
- Nova never suggests unsupported features
- Nova adapts to engine evolution
- Prevents hallucinated workflows
- Enables honest "cannot do yet" responses

---

#### 6. Implement Deterministic Replay Foundation

**Location**: `Core/Replay/` (new directory)

**Responsibilities** (Foundation Only):
- Capture input events
- Maintain event ordering
- Control randomness seeds
- Store minimal replay data

**Key Components**:
- `InputCapture` - Records user inputs and game events
- `EventOrderer` - Ensures deterministic event ordering
- `SeedController` - Manages randomness seeds
- `ReplayStorage` - Minimal storage format

**Integration Points**:
- `GameRuntime` - Capture inputs during execution
- `PhysicsSystem` - Use seed-controlled randomness
- `CombatSystem` - Log combat events for replay
- Future: Balance analysis, regression testing, Nova debugging

**Why Foundation Now**:
- Low-cost foundation now, expensive later if ignored
- Enables future balance analysis
- Enables regression testing
- Enables Nova debugging
- Enables "why did this happen?" investigation

**Not Full Replay Yet**:
- Just foundation: input capture, event ordering, seed control
- Full replay UI and analysis comes later (Phase 3)

---

#### 7. Enforce User Override Policy

**Location**: `Core/AI/PyGenesisAssistant/Nova/core/policies.py` (new file)

**Responsibilities**:
- Define and enforce "User Override Always Wins" policy
- Check user code overrides before Nova operations
- Provide UI indicators when overrides occur
- Document policy clearly

**Key Components**:
- `UserOverridePolicy` - Policy definition and enforcement
- `OverrideChecker` - Checks if user code overrides Nova suggestions
- `OverrideIndicator` - UI component showing override status
- Policy documentation

**Integration Points**:
- `OperationPlanner` - Check overrides before planning
- `TransactionManager` - Respect overrides during execution
- `UnifiedCodeEditor` - Show override indicators
- Documentation - Clear policy statement

**Policy Statement**:
> **Nova may suggest, plan, and execute — but user code always overrides Nova behavior.**

**Protects**:
- Social and legal concerns
- User trust and adoption
- Nova as tool, not authority

---

#### 8. Implement Failure-as-Success UX

**Location**: `Core/AI/PyGenesisAssistant/Nova/ui/failure_states.py` (new file)

**Responsibilities**:
- Define explicit UX patterns for failure states
- Provide clear messaging for honest reporting
- Celebrate honest reporting as a strength
- Document failure states as features

**Key Components**:
- `FailureStateUI` - UI patterns for failure states
- `HonestReportingMessages` - Clear messaging templates
- `FailureCelebration` - UI that frames failure as strength
- Documentation - Failure states as features

**Failure States to Support**:
- "I ran out of time" (time budget exhausted)
- "This is incomplete" (partial work done)
- "This needs human input" (blocked by ambiguity)
- "I cannot safely proceed" (safety gate triggered)

**Integration Points**:
- `TimeBoxedExecutionController` - Report time exhaustion
- `OperationPlanner` - Report incomplete work
- `WorkflowPipeline` - Report human input needed
- `TransactionManager` - Report safety blocks

**This is not a weakness** — it is one of PyGenesis's strongest differentiators.

---

### For PyGenesis

#### 1. Implement Physics-Driven Gameplay Framework

**Location**: `Core/Physics/` (new directory)

**Architecture**:
- **Instance-level physics state** - Matches object model
- **Impulse-based interactions** - No continuous solvers
- **Metadata-driven** - JSON + PGSL integration
- **Editor-friendly** - No hard rendering coupling

**Key Components**:
- `PhysicsState` - Per-instance physics properties
- `ImpulseSystem` - Apply impulses based on metadata
- `CollisionDetector` - Simple AABB/OBB detection
- `PhysicsMetadata` - JSON schema for physics properties

**Integration Points**:
- `ObjectEditor` - Add physics properties panel
- `GameGenerator` - Generate physics runtime code
- `UnifiedCodeEditor` - Add physics built-ins to `OBJECT_EVENT` context

**Non-Goals** (explicitly excluded):
- ❌ Fluids, deformables, muscle simulation
- ❌ Continuous physics solvers
- ❌ Complex constraint systems

---

#### 2. Implement Combat System Metadata

**Location**: `Core/Combat/` (new directory)

**Architecture**:
- **JSON-based metadata** - Designer-modifiable
- **Engine-evaluated math** - Deterministic
- **AI-friendly** - Nova can analyze numbers
- **Balance-analyzable** - Supports tuning

**Key Components**:
- `CombatMetadata` - JSON schema (damage, health, cooldowns, etc.)
- `CombatCalculator` - Evaluates combat math
- `BalanceAnalyzer` - Detects outliers (Phase 3)
- Integration with physics system

**Integration Points**:
- `ObjectEditor` - Add combat properties panel
- `GameGenerator` - Generate combat runtime code
- `Nova` - Analyze balance (Phase 3)

---

#### 3. Enhance EditorContext System

**Location**: `Core/Code/Unified/` (enhance existing)

**Current State**: `EditorContext` enum exists, partially integrated

**Enhancements Needed**:
- Full context awareness in all code generation
- Context-specific built-in recognition (expand beyond `OBJECT_EVENT`)
- Context validation in operation planner
- Context-based template selection for Nova

**Contexts to Support**:
- `EditorContext.SCRIPT` - Standalone scripts
- `EditorContext.OBJECT_EVENT` - Object event code (✅ implemented)
- `EditorContext.SHADER` - Shader code (future)

---

## Refactored Summary: Beneficial Parts from Feasibility Analysis

### Core Principle: Bounded, Auditable, Infrastructural

> **Nova is a planner and executor over deterministic subsystems, not a free-roaming AI.**

This principle ensures:
- ✅ Honest execution (no fake "finished" claims)
- ✅ Auditable changes (all operations logged)
- ✅ Deterministic behavior (same input = same output)
- ✅ Infrastructure-first (tools before AI)

---

### 1. Time-Boxed Execution (Nova)

**What It Is**:
Nova executes a task graph whose execution is externally time-bounded, not a continuous "thinking" process.

**What Nova Does NOT Do**:
- ❌ Track wall-clock time internally
- ❌ Sleep / wake
- ❌ "Think" continuously

**What Nova DOES Do**:
1. Receives goal + time budget
2. Produces task graph with estimated costs
3. Executes tasks while budget remains
4. Stops cleanly when budget exhausted or no safe tasks remain

**Implementation**:
- One new coordinator: `TimeBoxedExecutionController`
- Wraps existing: `OperationPlanner`, `Executors`, `TransactionManager`
- Nova remains unchanged in intelligence — just runs under a governor

**Safety Rules** (non-negotiable):
- Nova may not exceed time limit
- Nova may not delete without confirmation
- Nova must summarize limitations

---

### 2. Constrained Code Authoring (Nova)

**Mental Model**: Nova is a **constrained authoring agent**, not a general-purpose coder.

**Five Hard Boundaries**:

#### Boundary 1: Language Contract (PGSL First)
- **Simple Mode**: Nova writes only PGSL (syntax locked, no Python)
- **Advanced Mode**: Nova may write PGSL or Python (still validated)
- **Enforced by**: `UnifiedCodeEditor`, `ValidationPipeline`, Advanced Mode setting

#### Boundary 2: Structural Context (EditorContext)
- Nova never writes "raw files"
- Always writes into known context (`SCRIPT`, `OBJECT_EVENT`, `SHADER`)
- Context determines: allowed constructs, lifecycle hooks, accessible APIs
- **Prevents**: Writing update logic in draw-only context, orphaned code, breaking invariants

#### Boundary 3: Deterministic Generation (Not Freeform)
- Nova never emits "creative blobs" of code
- Uses: templates, fillable blocks, parameterized snippets, known patterns
- **Example**: `function on_update(delta): velocity_y += gravity * delta`
- Nova assembles known legal structures, doesn't invent language

#### Boundary 4: Validation → Execution → Commit
- **Pipeline**: Generate → Validate → Test → Diff → Commit
- **Steps**:
  1. Nova generates PGSL code
  2. `UnifiedValidationPipeline` checks it
  3. Execution engine runs it (sandbox)
  4. Diff is produced
  5. `TransactionManager` commits atomically
- **If any step fails**: Edit is rejected
- **Makes Nova**: Honest, auditable, non-destructive

#### Boundary 5: Time & Scope Governor
- Nova may only touch files declared in task plan
- Nova may only execute tasks while time remains
- Nova must stop when budget expires
- Nova must summarize what was done vs. skipped
- **Prevents**: "AI worked for an hour" fiction, hidden processes, scope creep

**How Nova Writes Code Practically**:
- Nova never directly "types" code into files
- Instead, emits `Operation` objects:
  ```python
  Operation(
      component="CodeEditor",
      method="insert_block",
      params={
          "file": "Player.pgsl",
          "location": "on_update",
          "code": GENERATED_PGSL_BLOCK
      }
  )
  ```
- Operations are: planned, previewed, executed by infrastructure
- Nova is the **planner**, not the filesystem actor

**Why This Is Better Than Cloud LLMs**:

| Cloud LLM     | Nova                    |
| ------------- | ----------------------- |
| Writes text   | Writes validated code   |
| No execution  | Sandbox-tested          |
| No context    | Full project context    |
| No rollback   | Atomic transactions     |
| Pretends time | Time-governed execution |

---

### 3. Physics-Driven Gameplay Framework (PyGenesis)

**Philosophy**: Perceived realism via impulse + metadata

**Not Competing With**:
- ❌ PhysX, Bullet, Havok (continuous solvers)

**Same Class As**:
- ✅ Smash Bros (impulse-based)
- ✅ BOTW (many interactions)
- ✅ Fighting games
- ✅ Platformers

**Why This Works Architecturally**:
- Instance-level physics state → matches object model
- No continuous solvers → stable + deterministic
- Metadata-driven impulses → ideal for PGSL + JSON
- No hard coupling to rendering → editor-friendly

**This is a v1 engine-native system**, not a bolt-on.

---

### 4. Combat System Metadata (PyGenesis)

**Why This Is Strong**:
- Designers modify data
- Engine evaluates math
- Nova can analyze numbers

**Makes It**:
- AI-friendly
- Testable
- Deterministic
- Balance-analyzable

**Enables**:
- Nova-assisted balancing (Phase 3)
- Replay analysis
- Difficulty scaling
- Weight classes

**JSON-based metadata** is perfectly scoped for this.

---

### 5. Physics Scope Control (Non-Goals)

**Explicit Non-Goals** (professional restraint):
- ❌ Fluids
- ❌ Deformables
- ❌ Muscle simulation

**Protects**:
- Performance
- Mental load
- Tooling
- Nova's reasoning scope

**This is not a limitation** — it's professional restraint.

---

### 6. Nova-Assisted Balancing & Analysis (Phase 3)

**Is This Possible Without Cloud LLMs?**
**Yes — later — with constraints.**

**Nova Does NOT Need**:
- Deep ML
- Neural gameplay understanding

**Nova Only Needs**:
- Logged events
- Physics metadata
- Combat outcomes

**Then Nova Can**:
- Detect outliers
- Flag imbalance
- Suggest tuning deltas

**Approach**:
- Rule-based first
- Heuristic second
- AI-assisted last

**Matches your philosophy**: Tool-first, AI-second.

**⚠️ This is Phase 3**, not now.

---

## Implementation Priority

### Phase 1: Nova Foundation (Weeks 1-4)
1. ✅ Time-Boxed Execution Controller
2. ✅ Constrained Code Authoring System
3. ✅ Operation Schema for Code Edits
4. ✅ Task Graph Progress Reporting
5. ✅ Engine Capability Introspection Layer
6. ✅ User Override Policy (Explicit)
7. ✅ Failure-as-Success UX (Explicit)

### Phase 2: PyGenesis Gameplay (Weeks 5-8)
1. ✅ Physics-Driven Gameplay Framework
2. ✅ Combat System Metadata
3. ✅ EditorContext Integration Enhancements
4. ✅ Deterministic Replay Core (Foundation Only)

### Phase 3: Advanced Features (Weeks 9+)
1. ⚠️ Nova-Assisted Balancing System
2. ⚠️ Replay Analysis (Full System)
3. ⚠️ Difficulty Scaling

---

## Success Criteria

### For Nova
- ✅ Can execute time-boxed tasks with clean shutdown
- ✅ Can generate valid PGSL code that passes validation
- ✅ Can propose code edits through operations (not direct file writes)
- ✅ Can report honest progress and limitations
- ✅ Can query engine capabilities and reject unsupported features
- ✅ Respects user code overrides (user code always wins)
- ✅ Can express failure states honestly ("I cannot safely proceed")
- ✅ Never suggests features the engine doesn't support

### For PyGenesis
- ✅ Physics system provides perceived realism via impulses
- ✅ Combat system is metadata-driven and balance-analyzable
- ✅ All systems are editor-friendly and Nova-accessible
- ✅ Deterministic replay foundation enables future analysis
- ✅ Engine capabilities are introspectable and documented

---

## Notes

- **This plan is not fantasy** — it's bounded, honest, deterministic, incremental, tool-first
- **Nova remains unchanged in intelligence** — she just runs under governors
- **PyGenesis stays solo-friendly** — metadata-driven, not simulation-heavy
- **All features are infrastructure-first** — tools before AI, validation before commit
- **User code always wins** — explicit policy prevents AI authority concerns
- **Failure is a feature** — honest reporting is a differentiator, not a weakness
- **Engine capabilities are known** — Nova never suggests unsupported features
- **Replay foundation is low-cost now** — expensive later if ignored

---

## What You Got Exactly Right (Critical Wins)

These are not just good ideas — they are rarely done correctly.

### ✅ Nova as Planner, Not Magician
- Reject free-roaming AI
- Reject "thinking forever"
- Reject unbounded code generation
- Reject pretending work was completed
- This puts Nova closer to a build system + IDE assistant than a chatbot

### ✅ Time-Boxed Execution as a First-Class Concept
- Time is a resource
- AI must be governed externally
- Partial success must be reported honestly
- This single concept protects from user distrust, over-promising AI, runaway complexity

### ✅ Physics & Combat via Metadata (Not Solvers)
- Explicitly excluding fluids, deformables, continuous solvers
- Avoids numerical instability, debug hell, tooling complexity
- Impulse + metadata gives Smash Bros–style combat, BOTW-style interaction illusion
- Deterministic replay, AI-analyzable systems

### ✅ Operation-Based Code Editing
- Nova emits operations, not files
- Provides previews, diffs, rollback, audit trails, user trust
- Puts Nova closer to Git, IDE refactors, compiler pipelines
- Far away from unsafe LLM behavior

---

## Things We Will NOT Add (Correct Exclusions)

You made good exclusions. Keep them excluded.

- ❌ Visual scripting graphs
- ❌ Machine-learning-based gameplay tuning
- ❌ Real-world physics accuracy
- ❌ Procedural generation "AI magic"
- ❌ Cloud dependence

All of these would:
- Increase complexity
- Reduce determinism
- Hurt Nova's reasoning
- Delay shipping indefinitely

---

**Next Steps**: Choose a flagship demo that proves all of this, then implement Phase 1.

