#!/usr/bin/env python3
"""
Python Game Development IDE
A GameMaker-style IDE for creating Python games
"""

import sys
import os
import subprocess
import importlib
from pathlib import Path

# Suppress KeyboardInterrupt tracebacks
import signal
signal.signal(signal.SIGINT, signal.SIG_DFL)

# Import VenvManager early
from Core.VenvManager import VenvManager

def setup_python_environment(custom_venv_path=None):
    """
    Setup and ensure consistent Python environment
    Validates venv first, creates if validation fails
    
    Args:
        custom_venv_path: Optional custom path for venv (from settings)
    """
    from Core.Debug import debug_critical, debug
    debug_critical("Setting up Python environment...")
    
    # Get application directory
    app_dir = Path(__file__).parent
    
    # Initialize venv manager with app_dir and custom path
    venv_manager = VenvManager(app_dir, custom_venv_path)
    
    # Step 1: Validate existing venv if it exists
    if venv_manager.venv_exists():
        debug("Validating existing virtual environment...")
        validation = venv_manager.validate_venv()
        
        if validation["errors"]:
            debug_critical(f"Venv validation failed: {validation['errors']}")
            debug("Recreating virtual environment...")
            # Remove old venv and create new one
            try:
                import shutil
                if venv_manager.venv_dir.exists():
                    shutil.rmtree(venv_manager.venv_dir)
            except Exception as e:
                debug(f"Warning: Could not remove old venv: {e}")
            
            # Create new venv
            base_python = sys.executable
            success = venv_manager.create_venv(base_python)
            
            if not success:
                debug_critical("WARNING: Failed to create venv. Using system Python.")
                debug(f"Using Python: {sys.executable}")
                return venv_manager
        elif validation["warnings"]:
            debug(f"Venv validation warnings: {validation['warnings']}")
            # Continue with warnings
        else:
            debug("Venv validation passed.")
    else:
        # No venv exists, create one
        debug("Virtual environment not found. Creating new venv...")
        
        # Use current Python executable as base
        base_python = sys.executable
        success = venv_manager.create_venv(base_python)
        
        if not success:
            debug_critical("WARNING: Failed to create venv. Using system Python.")
            debug(f"Using Python: {sys.executable}")
            return venv_manager
    
    # Final verification
    if not venv_manager.verify_venv():
        debug_critical("WARNING: Venv verification failed. Using system Python.")
        return venv_manager
    
    # Get venv Python executable
    venv_python = venv_manager.get_python_executable()
    
    # Check if we're already using venv Python
    if os.path.normpath(venv_python) != os.path.normpath(sys.executable):
        debug(f"Switching to venv Python: {venv_python}")
        # The venv Python will be used for all dependency operations
    else:
        debug(f"Already using venv Python: {sys.executable}")
    
    # Activate venv (add to sys.path)
    venv_manager.activate_venv()
    
    # Print status
    status = venv_manager.get_status()
    debug(f"Venv path: {status['venv_path']}")
    debug(f"Python executable: {status['python_executable']}")
    
    return venv_manager

def _basic_dependency_check(venv_manager=None, app_dir=None):
    """Basic dependency check without ExtensionsManager (fallback)"""
    from Core.Debug import debug_critical
    import subprocess
    import json
    
    if app_dir is None:
        app_dir = Path(__file__).parent
    
    debug_critical("Running basic dependency check...")
    
    # Read requirements from requirements.txt (single source of truth)
    requirements_file = app_dir / "requirements.txt"
    if not requirements_file.exists():
        debug_critical(f"ERROR: requirements.txt not found at {requirements_file}!")
        return False
    
    try:
        # Parse requirements.txt to get package names
        libraries = []
        with open(requirements_file, 'r') as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith("#") and not line.startswith(";"):
                    # Parse package name (handle version specifiers and comments)
                    package_line = line.split("#")[0].strip()  # Remove inline comments
                    if ">=" in package_line:
                        package_name = package_line.split(">=")[0].strip()
                    elif "==" in package_line:
                        package_name = package_line.split("==")[0].strip()
                    elif ";" in package_line:
                        package_name = package_line.split(";")[0].strip()
                    else:
                        package_name = package_line
                    if package_name:
                        libraries.append({"name": package_name, "import_name": package_name.lower().replace("-", "_")})
    except Exception as e:
        debug_critical(f"ERROR: Error reading requirements.txt: {e}")
        return False
    
    # Get Python executable
    if venv_manager and venv_manager.venv_exists():
        python_exe = venv_manager.get_python_executable()
    else:
        python_exe = sys.executable
    
    debug_critical(f"Using Python: {python_exe}")
    
    # Check packages using pip list
    try:
        result = subprocess.run(
            [python_exe, "-m", "pip", "list", "--format=json"],
            capture_output=True,
            text=True,
            timeout=15
        )
        if result.returncode != 0:
            debug_critical(f"ERROR: pip list failed: {result.stderr}")
            return False
        
        installed_packages = {}
        for pkg in json.loads(result.stdout):
            installed_packages[pkg["name"].lower()] = pkg["version"]
        
        missing = []
        for lib in libraries:
            pkg_name = lib.get("name", "").lower()
            if pkg_name and pkg_name not in installed_packages:
                missing.append(lib.get("name", ""))
                debug_critical(f"MISSING: {lib.get('name', '')}")
        
        if missing:
            debug_critical(f"\nMissing packages: {', '.join(missing)}")
            debug_critical("Please install them manually or restart to auto-install.")
            return False
        
        debug_critical("All core dependencies are installed!")
        return True
        
    except Exception as e:
        debug_critical(f"ERROR in basic dependency check: {e}")
        import traceback
        debug_critical(traceback.format_exc())
        return False

def check_and_install_dependencies(venv_manager=None, app_dir=None):
    """
    Check if all required dependencies are installed, install them if not
    Uses ExtensionsManager for installation to ensure consistency
    
    Args:
        venv_manager: VenvManager instance. If None, uses system Python
        app_dir: Application directory for ExtensionsManager
    """
    from Core.Debug import debug_critical, debug
    
    if app_dir is None:
        app_dir = Path(__file__).parent
    
    debug_critical("Checking dependencies...")
    
    # Note: ExtensionsManager may require PySide6, so we need to handle import errors
    try:
        debug_critical("Importing ExtensionsManager...")
        from Core.ExtensionsManager import ExtensionsManager
        debug_critical("ExtensionsManager imported successfully")
    except ImportError as e:
        debug_critical(f"ERROR: Failed to import ExtensionsManager (missing dependency?): {e}")
        debug_critical("This may mean PySide6 or another required module is not installed.")
        import traceback
        debug_critical(traceback.format_exc())
        debug_critical("\nTrying basic dependency check without ExtensionsManager...")
        # Fall back to basic check
        return _basic_dependency_check(venv_manager, app_dir)
    except Exception as e:
        debug_critical(f"ERROR: Unexpected error importing ExtensionsManager: {e}")
        import traceback
        debug_critical(traceback.format_exc())
        return False
    
    try:
        debug_critical("Initializing ExtensionsManager...")
        extensions_manager = ExtensionsManager(venv_manager, app_dir)
        debug_critical("ExtensionsManager initialized successfully")
    except Exception as e:
        debug_critical(f"ERROR: Failed to initialize ExtensionsManager: {e}")
        import traceback
        debug_critical(traceback.format_exc())
        return False
    
    # Determine which Python to use for checks
    if venv_manager and venv_manager.venv_exists():
        python_exe = venv_manager.get_python_executable()
        debug(f"Using venv Python for installations: {python_exe}")
        
        # Also activate venv for imports (add site-packages to sys.path)
        venv_manager.activate_venv()
    else:
        python_exe = sys.executable
        debug(f"Using system Python: {python_exe}")
    
    # Read requirements from requirements.txt (single source of truth)
    import json
    requirements_file = app_dir / "requirements.txt"
    
    if not requirements_file.exists():
        debug_critical(f"ERROR: requirements.txt not found at {requirements_file}!")
        return False
    
    try:
        # All packages in requirements.txt are required
        libraries = []
        
        with open(requirements_file, 'r') as f:
            for line in f:
                line = line.strip()
                
                if line and not line.startswith("#") and not line.startswith(";"):
                    # Parse package name (handle version specifiers and comments)
                    package_line = line.split("#")[0].strip()  # Remove inline comments
                    if ">=" in package_line:
                        package_name = package_line.split(">=")[0].strip()
                    elif "==" in package_line:
                        package_name = package_line.split("==")[0].strip()
                    elif ";" in package_line:
                        # Handle platform-specific requirements (e.g., pywin32; sys_platform == 'win32')
                        package_name = package_line.split(";")[0].strip()
                    else:
                        package_name = package_line
                    
                    if package_name:
                        libraries.append({"name": package_name, "import_name": package_name.lower().replace("-", "_")})
    except Exception as e:
        debug_critical(f"ERROR: Error reading requirements.txt: {e}")
        return False
    
    missing_packages = []
    
    # Check all packages (all are required)
    debug_critical("\nChecking dependencies...")
    for lib in libraries:
        package_name = lib.get("name", "")
        import_name = lib.get("import_name", package_name)
        version = lib.get("version", "")
        
        if not package_name:
            continue
        
        # Check if package is installed using ExtensionsManager
        try:
            debug_critical(f"Checking {package_name}...")
            is_installed, installed_version = extensions_manager.check_package_installed(package_name, import_name)
        except Exception as e:
            debug_critical(f"ERROR: Failed to check package {package_name}: {e}")
            import traceback
            debug_critical(traceback.format_exc())
            # Treat check failure as missing package - try to install
            is_installed = False
        
        if is_installed:
            debug_critical(f"OK: {package_name} (version: {installed_version})")
            continue
        
        # Package not found, add to missing list
        missing_packages.append({
            "name": package_name,
            "import_name": import_name,
            "version": version
        })
        debug_critical(f"MISSING: {package_name}")
    
    # Install missing packages using ExtensionsManager infrastructure (synchronous)
    if missing_packages:
        missing_names = [pkg["name"] for pkg in missing_packages]
        debug_critical(f"\nInstalling missing packages: {', '.join(missing_names)}")
        debug(f"Using ExtensionsManager infrastructure for installation...")
        
        try:
            # Import PackageInstaller (used by ExtensionsManager internally)
            from Core.PackageInstaller import UnifiedPackageInstaller
            
            # Install packages one by one using ExtensionsManager's installer
            for pkg in missing_packages:
                package_name = pkg["name"]
                
                debug_critical(f"Installing {package_name}...")
                
                # Create installer instance (same as ExtensionsManager.install_package() uses)
                installer = UnifiedPackageInstaller(
                    venv_manager,
                    package_name,
                    operation="install",
                    use_user_install=False,
                    timeout=300  # 5 minutes per package
                )
                
                # This uses the exact same logic as ExtensionsManager but runs synchronously
                python_exe = venv_manager.get_python_executable() if venv_manager else sys.executable
                python_exe = str(Path(python_exe).resolve())
                
                install_success = False
                install_message = ""
                
                # Track result via signal (even though event loop doesn't exist, we'll check manually)
                result_received = [False]
                result_success = [False]
                result_msg = [""]
                
                def on_finished(success, msg):
                    result_received[0] = True
                    result_success[0] = success
                    result_msg[0] = msg
                
                installer.finished.connect(on_finished)
                
                try:
                    # This will run subprocess and emit finished signal
                    installer._install_package(python_exe)
                    
                    # We need to check the result manually since signals won't fire without event loop
                    import subprocess
                    import importlib
                    
                    # Try to install directly (same logic as _install_package but we can catch exceptions)
                    cmd = [python_exe, "-m", "pip", "install", "--no-cache-dir", package_name]
                    try:
                        result = subprocess.run(
                            cmd,
                            capture_output=True,
                            text=True,
                            check=True,
                            timeout=300
                        )
                        importlib.invalidate_caches()
                        install_success = True
                        install_message = f"Successfully installed {package_name}"
                    except subprocess.CalledProcessError as e:
                        error_text = (e.stderr or e.stdout or "").lower()
                        if "access is denied" in error_text or "permission denied" in error_text or "winerror 5" in error_text:
                            # Try user install
                            debug_critical(f"Permission error detected, trying user install...")
                            cmd_user = [python_exe, "-m", "pip", "install", "--user", "--no-cache-dir", package_name]
                            try:
                                result = subprocess.run(
                                    cmd_user,
                                    capture_output=True,
                                    text=True,
                                    check=True,
                                    timeout=300
                                )
                                importlib.invalidate_caches()
                                install_success = True
                                install_message = f"Successfully installed {package_name} to user directory"
                            except subprocess.CalledProcessError as e2:
                                install_success = False
                                install_message = f"Failed to install {package_name}: {e2.stderr or e2.stdout or str(e2)}"
                        else:
                            install_success = False
                            install_message = f"Failed to install {package_name}: {e.stderr or e.stdout or str(e)}"
                    except subprocess.TimeoutExpired:
                        install_success = False
                        install_message = f"Installation of {package_name} timed out after 5 minutes"
                        
                except Exception as e:
                    install_success = False
                    install_message = f"Unexpected error installing {package_name}: {str(e)}"
                
                # Verify installation using ExtensionsManager (same as ExtensionsManager would do)
                extensions_manager.clear_installed_packages_cache()
                is_installed, installed_version = extensions_manager.check_package_installed(package_name)
                
                if install_success and is_installed:
                    debug_critical(f"SUCCESS: {package_name} installed (version: {installed_version})")
                elif is_installed:
                    # Installation succeeded even if we got an error (sometimes pip reports errors but installs)
                    debug_critical(f"SUCCESS: {package_name} installed (version: {installed_version}) - verification passed")
                else:
                    error_msg = install_message if install_message else "Unknown error"
                    debug_critical(f"ERROR: {error_msg}")
                    debug_critical(f"Verification confirms {package_name} is not installed")
                    return False
            
            debug_critical("\nAll dependencies installed successfully!")
            debug_critical("Please restart the application.")
            return True
            
        except Exception as e:
            debug_critical(f"\nERROR: Error installing packages: {e}")
            import traceback
            debug_critical(traceback.format_exc())
            debug_critical("\nPlease install dependencies manually:")
            debug_critical("pip install -r requirements.txt")
            debug_critical("Note: requirements.txt is now the single source of truth for package installation.")
            return False
    else:
        debug("\nAll dependencies are satisfied!")
        return True

def main():
    """Main entry point with dependency checking"""
    # Suppress harmless third-party library warnings
    import warnings
    warnings.filterwarnings("ignore", category=UserWarning, module="pygame")
    warnings.filterwarnings("ignore", category=RuntimeWarning, module="pydub")
    
    # Suppress pygame startup message
    import os
    os.environ['PYGAME_HIDE_SUPPORT_PROMPT'] = '1'
    
    # Use debug_critical for startup messages (always shown)
    from Core.Debug import debug_critical, debug
    debug_critical("PyGenesis IDE Starting...")
    debug_critical("=" * 50)
    
    # Import settings early to check for custom VENV path
    try:
        from Config.Settings import Settings
        settings = Settings()
        custom_venv_path = settings.get("VENV_Path", "")
    except Exception:
        # If Settings can't be loaded, continue without custom path
        custom_venv_path = None
    
    # Setup Python environment (create/activate venv)
    venv_manager = setup_python_environment(custom_venv_path)
    debug()
    
    # Check and install dependencies
    app_dir = Path(__file__).parent
    if not check_and_install_dependencies(venv_manager, app_dir):
        debug_critical("\nERROR: Dependency check failed. Exiting.")
        sys.exit(1)
    
    debug_critical("\nStarting PyGenesis IDE...")
    
    # Now import PySide6 and other dependencies
    from PySide6.QtWidgets import QApplication, QMainWindow, QVBoxLayout, QHBoxLayout, QWidget, QSplitter, QTreeWidget, QTreeWidgetItem, QTextEdit, QMenuBar, QMenu, QToolBar, QStatusBar, QMessageBox, QFileDialog, QInputDialog
    from PySide6.QtCore import Qt, QTimer, QSettings
    from PySide6.QtGui import QIcon, QKeySequence, QAction

    # Import our custom modules
    from Core.ProjectManager import ProjectManager
    from Core.ResourceManager import ResourceManager
    # Editors will be imported on-demand via EditorFactory
    from UI.MainWindow.MainWindow import MainWindow
    from UI.CommonDialogs.PreferencesDialog import PreferencesDialog
    from Config.Settings import Settings
    from Config.ThemeManager import ThemeManager

    class PythonGameIDE(QApplication):
        def __init__(self, argv, venv_manager):
            super().__init__(argv)
            # Import debug_critical early so it's available throughout this method
            from Core.Debug import debug_critical
            
            self.setApplicationName("Python Game IDE")
            self.setApplicationVersion("1.0.0")
            self.setOrganizationName("Python Game Development")
            
            # Store application directory
            self.app_dir = Path(__file__).parent
            
            # Store venv manager
            self.venv_manager = venv_manager
            
            # Connect pycache cleanup to shutdown
            self.aboutToQuit.connect(self._cleanup_pycache)
            
            # Initialize settings
            self.settings = Settings()
            
            # Initialize debug system early (after settings, before anything else that might debug)
            try:
                from Core.Debug import init_debug
                init_debug(self.settings)
            except ImportError:
                pass
            
            # Initialize theme manager
            self.theme_manager = ThemeManager(self.settings)
            
            # Initialize managers
            self.project_manager = ProjectManager()
            self.resource_manager = ResourceManager(self.project_manager)
            
            # Initialize utility managers
            from Core.UtilityOperations import UndoRedoManager
            self.undo_redo_manager = UndoRedoManager()
            
            # Connect undo/redo manager to resource/project managers
            self.undo_redo_manager.set_managers(self.resource_manager, self.project_manager)
            self.resource_manager.set_undo_redo_manager(self.undo_redo_manager)
            
            # Create main window
            try:
                debug_critical("Creating main window...")
                self.main_window = MainWindow(self)
                debug_critical("Main window created successfully")
                self.main_window.show()
                debug_critical("Main window shown")
            except Exception as e:
                debug_critical(f"ERROR: Failed to create/show main window: {e}")
                import traceback
                debug_critical(traceback.format_exc())
                raise  # Re-raise so we can see the error
            
            # Initialize module preloader for performance optimization (after main window is created)
            try:
                from Core.ModulePreloader import ModulePreloader
                # Parent to the app so it stays alive
                self.module_preloader = ModulePreloader(self.app_dir)
                self.module_preloader.setParent(self)  # Ensure it's parented to the QApplication
                
                # Defer to after app.exec() starts so QApplication is fully running
                from PySide6.QtCore import QTimer
                QTimer.singleShot(100, self.module_preloader.preload_all_editors)
            except Exception as e:
                debug_critical(f"Warning: Failed to initialize module preloader: {e}")
                import traceback
                debug_critical(traceback.format_exc())
                # Don't crash on preload failure - it's optional
                self.module_preloader = None
        
        def _cleanup_pycache(self):
            """Clean up __pycache__ folders on application shutdown"""
            try:
                from Core.DeletePyCache import delete_pycache
                from Core.Debug import debug
                debug("Cleaning up __pycache__ folders...")
                delete_pycache(str(self.app_dir))
                debug("PyCache cleanup complete.")
            except Exception as e:
                # Don't let pycache cleanup errors block shutdown
                from Core.Debug import debug
                debug(f"Warning: Failed to clean up pycache: {e}")

    try:
        app = PythonGameIDE(sys.argv, venv_manager)
        exit_code = app.exec()
        sys.exit(exit_code)
    except Exception as e:
        from Core.Debug import debug_critical
        debug_critical(f"\nFATAL ERROR: Application crashed: {e}")
        import traceback
        debug_critical(traceback.format_exc())
        sys.exit(1)

if __name__ == "__main__":
    main()
