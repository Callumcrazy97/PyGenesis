"""
Screen Recorder - Integrated screen recording tool for PyGenesis IDE
Refactored for performance with Entire Screen and Running App options

This module provides screen recording functionality for PyGenesis IDE.
Located in Tools/ScreenRecording/ as part of the refactored folder structure.
"""

import sys
import time
import threading
import zlib
from pathlib import Path
from typing import List, Optional
import numpy as np
from PIL import Image
import mss
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QSlider, QLabel,
    QFileDialog, QMessageBox, QProgressBar, QGroupBox, QCheckBox, QComboBox
)
from PySide6.QtCore import QTimer, Qt, Signal, QThread, QMutex, QMutexLocker
from PySide6.QtGui import QFont


class ScreenCaptureThread(QThread):
    """Thread for capturing screen frames without blocking the GUI."""
    
    frame_captured = Signal(int)  # Emits frame count
    
    def __init__(self, capture_rate: int = 10, playback_fps: int = 10, capture_mode: str = "entire_screen"):
        super().__init__()
        self.capture_rate = capture_rate
        self.playback_fps = playback_fps
        self.capture_mode = capture_mode  # "entire_screen" or "running_app"
        self.is_recording = False
        self.is_paused = False
        self.frames: List[bytes] = []
        self.frame_shapes: List[tuple] = []
        self.mutex = QMutex()
        self.sct = None
        self.monitor = None
        
        # Performance optimization: Primary color palette for real-time compression
        self.primary_colors = np.array([
            [0, 0, 0], [255, 255, 255], [255, 0, 0], [0, 255, 0],
            [0, 0, 255], [255, 255, 0], [255, 0, 255], [0, 255, 255],
            [128, 128, 128], [192, 192, 192], [128, 0, 0], [0, 128, 0],
            [0, 0, 128], [128, 128, 0], [128, 0, 128], [0, 128, 128]
        ], dtype=np.uint8)
        
        # Real-time compression settings
        self.use_realtime_compression = True
        self.target_width = 800
        self.target_height = 600
        self.current_preset = 'balanced'
        
        # Quality presets
        self.quality_presets = {
            'fast_small': {'colors': 64, 'resize': 0.7, 'dither': False},
            'balanced': {'colors': 128, 'resize': 0.8, 'dither': True},
            'high_quality': {'colors': 200, 'resize': 0.9, 'dither': True}
        }
    
    def set_capture_rate(self, capture_rate: int):
        """Update the capture rate setting."""
        self.capture_rate = capture_rate
    
    def set_playback_fps(self, playback_fps: int):
        """Update the playback FPS setting."""
        self.playback_fps = playback_fps
    
    def set_capture_mode(self, mode: str):
        """Set capture mode: 'entire_screen' or 'running_app'"""
        self.capture_mode = mode
    
    def set_realtime_compression(self, enabled: bool, target_width: int = 800, target_height: int = 600):
        """Enable/disable real-time compression with target dimensions."""
        self.use_realtime_compression = enabled
        self.target_width = target_width
        self.target_height = target_height
    
    def set_quality_preset(self, preset_name: str):
        """Set quality preset for compression."""
        if preset_name in self.quality_presets:
            self.current_preset = preset_name
            preset = self.quality_presets[preset_name]
            self.target_width = int(1920 * preset['resize'])
            self.target_height = int(1080 * preset['resize'])
    
    def compress_frame(self, frame: np.ndarray) -> bytes:
        """Compress a frame for storage using zlib."""
        if frame.dtype != np.uint8:
            frame = frame.astype(np.uint8)
        compressed = zlib.compress(frame.tobytes(), level=6)
        return compressed
    
    def fast_map_to_primary_colors(self, img_array: np.ndarray) -> np.ndarray:
        """Fast primary color mapping using vectorized operations."""
        pixels = img_array.reshape(-1, 3).astype(np.float32)
        
        # Vectorized distance calculation
        distances = np.sqrt(np.sum((pixels[:, np.newaxis, :] - self.primary_colors[np.newaxis, :, :]) ** 2, axis=2))
        closest_indices = np.argmin(distances, axis=1)
        
        return self.primary_colors[closest_indices].reshape(img_array.shape)
    
    def start_recording(self):
        """Start the recording process."""
        with QMutexLocker(self.mutex):
            self.is_recording = True
            self.is_paused = False
            self.frames.clear()
            self.frame_shapes.clear()
    
    def pause_recording(self):
        """Pause the recording process."""
        with QMutexLocker(self.mutex):
            self.is_paused = True
    
    def resume_recording(self):
        """Resume the recording process."""
        with QMutexLocker(self.mutex):
            self.is_paused = False
    
    def stop_recording(self):
        """Stop the recording process."""
        with QMutexLocker(self.mutex):
            self.is_recording = False
            self.is_paused = False
    
    def get_frames(self) -> tuple[List[bytes], List[tuple]]:
        """Get a copy of all captured frames."""
        with QMutexLocker(self.mutex):
            return self.frames.copy(), self.frame_shapes.copy()
    
    def clear_frames(self):
        """Clear all captured frames."""
        with QMutexLocker(self.mutex):
            self.frames.clear()
            self.frame_shapes.clear()
    
    def run(self):
        """Main capture loop."""
        self.sct = mss.mss()
        
        # Set monitor based on capture mode
        if self.capture_mode == "entire_screen":
            self.monitor = self.sct.monitors[1]  # Primary monitor
        else:
            # Running app mode - placeholder for future implementation
            # Will use dirty flag to detect when game is running
            self.monitor = self.sct.monitors[1]  # Default to primary for now
        
        frame_interval = 1.0 / self.capture_rate
        
        while True:
            if not self.is_recording:
                time.sleep(0.1)
                continue
            
            if self.is_paused:
                time.sleep(0.1)
                continue
            
            start_time = time.time()
            
            if self.sct is None or self.monitor is None:
                time.sleep(0.1)
                continue
            
            # Capture screen
            screenshot = self.sct.grab(self.monitor)
            img_array = np.array(screenshot)
            
            # Convert BGRA to RGB
            if img_array.shape[2] == 4:
                img_array = img_array[:, :, [2, 1, 0]]  # BGR -> RGB
            else:
                img_array = img_array[:, :, [2, 1, 0]]
            
            # Real-time compression
            if self.use_realtime_compression:
                preset = self.quality_presets[self.current_preset]
                original_height, original_width = img_array.shape[:2]
                
                # Resize if needed
                if original_width > self.target_width or original_height > self.target_height:
                    aspect_ratio = original_width / original_height
                    if original_width > original_height:
                        new_width = self.target_width
                        new_height = int(self.target_width / aspect_ratio)
                    else:
                        new_height = self.target_height
                        new_width = int(self.target_height * aspect_ratio)
                    
                    img_pil = Image.fromarray(img_array, 'RGB')
                    img_pil = img_pil.resize((new_width, new_height), Image.Resampling.LANCZOS)
                    img_array = np.array(img_pil)
                
                # Color quantization
                if self.current_preset == 'fast_small':
                    img_array = self.fast_map_to_primary_colors(img_array)
                else:
                    img_pil = Image.fromarray(img_array, 'RGB')
                    img_pil = img_pil.quantize(colors=preset['colors'], method=Image.MEDIANCUT)
                    if preset['dither']:
                        img_pil = img_pil.convert('P', palette=Image.ADAPTIVE, colors=preset['colors'])
                        img_pil = img_pil.convert('RGB')
                    else:
                        img_pil = img_pil.convert('RGB')
                    img_array = np.array(img_pil)
            
            with QMutexLocker(self.mutex):
                if self.is_recording and not self.is_paused:
                    compressed_frame = self.compress_frame(img_array)
                    self.frames.append(compressed_frame)
                    self.frame_shapes.append(img_array.shape)
                    self.frame_captured.emit(len(self.frames))
            
            # Maintain target FPS
            elapsed = time.time() - start_time
            sleep_time = max(0, frame_interval - elapsed)
            time.sleep(sleep_time)
    
    def cleanup(self):
        """Clean up resources."""
        if self.sct is not None:
            try:
                self.sct.close()
            except:
                pass
            self.sct = None


class GifProcessingThread(QThread):
    """Background thread for processing and saving GIF files."""
    
    progress_updated = Signal(int)
    processing_completed = Signal(str, int)
    processing_failed = Signal(str)
    
    def __init__(self, frames_data, frame_shapes, playback_fps, file_path):
        super().__init__()
        self.frames_data = frames_data
        self.frame_shapes = frame_shapes
        self.playback_fps = playback_fps
        self.file_path = file_path
    
    def run(self):
        """Process frames and create GIF in background."""
        try:
            total_frames = len(self.frames_data)
            self.progress_updated.emit(0)
            
            pil_frames = []
            
            for i, (compressed_frame, shape) in enumerate(zip(self.frames_data, self.frame_shapes)):
                # Decompress frame
                decompressed = zlib.decompress(compressed_frame)
                frame = np.frombuffer(decompressed, dtype=np.uint8).reshape(shape)
                
                # Resize for final output
                original_height, original_width = frame.shape[:2]
                new_width = int(original_width * 0.75)
                new_height = int(original_height * 0.75)
                
                img = Image.fromarray(frame, mode='RGB')
                img = img.resize((new_width, new_height), Image.Resampling.LANCZOS)
                img = img.quantize(colors=128, method=Image.FASTOCTREE)
                img = img.convert('RGB')
                
                pil_frames.append(img)
                
                progress = int((i + 1) / total_frames * 80)
                self.progress_updated.emit(progress)
            
            # Create optimized GIF
            duration = int(1000 / self.playback_fps)
            
            if pil_frames:
                # Create master palette
                sample_frames = pil_frames[:min(10, len(pil_frames))]
                combined = Image.new('RGB', (sum(f.size[0] for f in sample_frames), sample_frames[0].size[1]))
                x_offset = 0
                for frame in sample_frames:
                    combined.paste(frame, (x_offset, 0))
                    x_offset += frame.size[0]
                
                master_palette = combined.quantize(colors=128, method=Image.FASTOCTREE)
                
                # Apply palette to all frames
                palettized_frames = []
                for i, frame in enumerate(pil_frames):
                    palettized_frame = frame.quantize(palette=master_palette)
                    palettized_frames.append(palettized_frame)
                    
                    progress = 80 + int((i + 1) / len(pil_frames) * 20)
                    self.progress_updated.emit(progress)
                
                # Save with maximum optimization
                palettized_frames[0].save(
                    self.file_path,
                    save_all=True,
                    append_images=palettized_frames[1:],
                    duration=duration,
                    loop=0,
                    optimize=True,
                    method=6
                )
            
            self.processing_completed.emit(self.file_path, total_frames)
        
        except Exception as e:
            self.processing_failed.emit(f"Error processing GIF: {str(e)}")


class ScreenRecorderWidget(QWidget):
    """Integrated screen recorder widget for PyGenesis IDE."""
    
    def __init__(self, parent=None, recordings_folder=None):
        super().__init__(parent)
        self.recordings_folder = Path(recordings_folder) if recordings_folder else None
        self.capture_thread = ScreenCaptureThread()
        self.capture_thread.frame_captured.connect(self.update_frame_count)
        self.capture_thread.start()
        
        self.recording_state = "stopped"
        self.use_defaults = True
        self.gif_thread = None
        
        self.setup_ui()
    
    def setup_ui(self):
        """Set up the user interface."""
        layout = QVBoxLayout(self)
        
        # Title
        title_label = QLabel("Screen Recorder")
        title_label.setAlignment(Qt.AlignCenter)
        title_font = QFont()
        title_font.setPointSize(16)
        title_font.setBold(True)
        title_label.setFont(title_font)
        layout.addWidget(title_label)
        
        # Capture Mode Selection
        mode_group = QGroupBox("Capture Mode")
        mode_layout = QVBoxLayout(mode_group)
        
        self.mode_combo = QComboBox()
        self.mode_combo.addItem("Entire Screen", "entire_screen")
        self.mode_combo.addItem("Running App (Coming Soon)", "running_app")
        self.mode_combo.setCurrentIndex(0)
        self.mode_combo.currentIndexChanged.connect(self.on_mode_changed)
        # Note: Running App option is disabled in on_mode_changed handler
        mode_layout.addWidget(self.mode_combo)
        
        layout.addWidget(mode_group)
        
        # Default Options Toggle
        self.defaults_checkbox = QCheckBox("Use Default Options (Recommended)")
        self.defaults_checkbox.setChecked(True)
        self.defaults_checkbox.stateChanged.connect(self.toggle_defaults)
        layout.addWidget(self.defaults_checkbox)
        
        # Real-time Compression Toggle
        self.realtime_compression_checkbox = QCheckBox("Real-time Compression (Recommended)")
        self.realtime_compression_checkbox.setChecked(True)
        self.realtime_compression_checkbox.stateChanged.connect(self.toggle_realtime_compression)
        layout.addWidget(self.realtime_compression_checkbox)
        
        # Quality Preset Selection
        quality_layout = QHBoxLayout()
        quality_layout.addWidget(QLabel("Quality Preset:"))
        
        self.quality_combo = QComboBox()
        self.quality_combo.addItem("Fast & Small (Primary Colors)", "fast_small")
        self.quality_combo.addItem("Balanced Quality", "balanced")
        self.quality_combo.addItem("High Quality", "high_quality")
        self.quality_combo.setCurrentIndex(1)
        self.quality_combo.currentTextChanged.connect(self.change_quality_preset)
        quality_layout.addWidget(self.quality_combo)
        quality_layout.addStretch()
        
        layout.addLayout(quality_layout)
        
        # Recording Settings Group
        settings_group = QGroupBox("Recording Settings")
        settings_layout = QVBoxLayout(settings_group)
        
        # Capture Rate Control
        capture_layout = QHBoxLayout()
        capture_layout.addWidget(QLabel("Capture Rate (frames/sec):"))
        self.capture_rate_label = QLabel("8")
        capture_layout.addWidget(self.capture_rate_label)
        capture_layout.addStretch()
        settings_layout.addLayout(capture_layout)
        
        self.capture_rate_slider = QSlider(Qt.Horizontal)
        self.capture_rate_slider.setMinimum(1)
        self.capture_rate_slider.setMaximum(60)
        self.capture_rate_slider.setValue(8)
        self.capture_rate_slider.valueChanged.connect(self.update_capture_rate)
        settings_layout.addWidget(self.capture_rate_slider)
        
        # Playback FPS Control
        playback_layout = QHBoxLayout()
        playback_layout.addWidget(QLabel("Playback FPS:"))
        self.playback_fps_label = QLabel("8")
        playback_layout.addWidget(self.playback_fps_label)
        playback_layout.addStretch()
        settings_layout.addLayout(playback_layout)
        
        self.playback_fps_slider = QSlider(Qt.Horizontal)
        self.playback_fps_slider.setMinimum(1)
        self.playback_fps_slider.setMaximum(60)
        self.playback_fps_slider.setValue(8)
        self.playback_fps_slider.valueChanged.connect(self.update_playback_fps)
        settings_layout.addWidget(self.playback_fps_slider)
        
        # Info label
        self.info_label = QLabel("Default: 8 fps capture, 8 fps playback")
        self.info_label.setStyleSheet("color: #666; font-size: 10px;")
        self.info_label.setAlignment(Qt.AlignCenter)
        settings_layout.addWidget(self.info_label)
        
        layout.addWidget(settings_group)
        
        # Control Buttons
        button_layout = QHBoxLayout()
        
        self.start_button = QPushButton("Start Recording")
        self.start_button.clicked.connect(self.start_recording)
        self.start_button.setStyleSheet("QPushButton { background-color: #4CAF50; color: white; font-weight: bold; }")
        button_layout.addWidget(self.start_button)
        
        self.pause_button = QPushButton("Pause")
        self.pause_button.clicked.connect(self.pause_recording)
        self.pause_button.setEnabled(False)
        self.pause_button.setStyleSheet("QPushButton { background-color: #FF9800; color: white; font-weight: bold; }")
        button_layout.addWidget(self.pause_button)
        
        self.stop_button = QPushButton("Stop & Save")
        self.stop_button.clicked.connect(self.stop_recording)
        self.stop_button.setEnabled(False)
        self.stop_button.setStyleSheet("QPushButton { background-color: #F44336; color: white; font-weight: bold; }")
        button_layout.addWidget(self.stop_button)
        
        self.cancel_button = QPushButton("Cancel Processing")
        self.cancel_button.clicked.connect(self.cancel_processing)
        self.cancel_button.setVisible(False)
        self.cancel_button.setStyleSheet("QPushButton { background-color: #FF5722; color: white; font-weight: bold; }")
        button_layout.addWidget(self.cancel_button)
        
        layout.addLayout(button_layout)
        
        # Status and Progress
        self.status_label = QLabel("Ready to record")
        self.status_label.setAlignment(Qt.AlignCenter)
        layout.addWidget(self.status_label)
        
        self.frame_count_label = QLabel("Frames: 0")
        self.frame_count_label.setAlignment(Qt.AlignCenter)
        layout.addWidget(self.frame_count_label)
        
        self.progress_bar = QProgressBar()
        self.progress_bar.setVisible(False)
        layout.addWidget(self.progress_bar)
        
        layout.addStretch()
        
        # Initialize default settings
        self.apply_default_settings()
        self.update_control_states()
    
    def on_mode_changed(self, index):
        """Handle capture mode change."""
        mode = self.mode_combo.itemData(index)
        if mode:
            if mode == "running_app":
                QMessageBox.information(
                    self,
                    "Coming Soon",
                    "Running App mode will be available in a future update. It will automatically detect when your game is running using a dirty flag system."
                )
                self.mode_combo.setCurrentIndex(0)  # Reset to entire screen
                return
            self.capture_thread.set_capture_mode(mode)
    
    def toggle_defaults(self, state):
        """Toggle default options and update controls."""
        self.use_defaults = state == Qt.Checked
        if self.use_defaults:
            self.apply_default_settings()
        self.update_control_states()
    
    def apply_default_settings(self):
        """Apply default settings for smooth recording."""
        capture_rate = 8
        playback_fps = 8
        
        self.capture_thread.set_quality_preset('balanced')
        self.capture_thread.set_realtime_compression(True, 800, 600)
        
        self.capture_rate_slider.setValue(capture_rate)
        self.playback_fps_slider.setValue(playback_fps)
        
        self.capture_thread.set_capture_rate(capture_rate)
        self.capture_thread.set_playback_fps(playback_fps)
        
        self.info_label.setText(f"Default: {capture_rate} fps capture, {playback_fps} fps playback")
    
    def update_control_states(self):
        """Enable/disable controls based on defaults toggle."""
        enabled = not self.use_defaults
        self.capture_rate_slider.setEnabled(enabled)
        self.playback_fps_slider.setEnabled(enabled)
    
    def update_capture_rate(self, value):
        """Update capture rate value and label."""
        if not self.use_defaults:
            self.capture_rate_label.setText(str(value))
            self.capture_thread.set_capture_rate(value)
            self.update_info_label()
    
    def update_playback_fps(self, value):
        """Update playback FPS value and label."""
        if not self.use_defaults:
            self.playback_fps_label.setText(str(value))
            self.capture_thread.set_playback_fps(value)
            self.update_info_label()
    
    def update_info_label(self):
        """Update the info label with current settings."""
        if not self.use_defaults:
            capture_rate = self.capture_rate_slider.value()
            playback_fps = self.playback_fps_slider.value()
            self.info_label.setText(f"Custom: {capture_rate} fps capture, {playback_fps} fps playback")
    
    def toggle_realtime_compression(self, state):
        """Toggle real-time compression mode."""
        enabled = state == Qt.Checked
        if enabled:
            self.capture_thread.set_realtime_compression(True, 800, 600)
            self.update_quality_info()
        else:
            self.capture_thread.set_realtime_compression(False)
            self.info_label.setText("Real-time compression disabled - higher quality but larger files")
    
    def change_quality_preset(self, text):
        """Change quality preset."""
        for i in range(self.quality_combo.count()):
            if self.quality_combo.itemText(i) == text:
                preset_key = self.quality_combo.itemData(i)
                self.capture_thread.set_quality_preset(preset_key)
                self.update_quality_info()
                break
    
    def update_quality_info(self):
        """Update info label with current quality settings."""
        if self.realtime_compression_checkbox.isChecked():
            current_preset = self.capture_thread.current_preset
            preset_info = self.capture_thread.quality_presets[current_preset]
            self.info_label.setText(f"Quality: {preset_info['colors']} colors, {int(preset_info['resize']*100)}% size")
    
    def update_frame_count(self, count):
        """Update the frame count display."""
        self.frame_count_label.setText(f"Frames: {count}")
    
    def start_recording(self):
        """Start the recording process."""
        self.recording_state = "recording"
        self.capture_thread.start_recording()
        
        self.start_button.setEnabled(False)
        self.pause_button.setEnabled(True)
        self.stop_button.setEnabled(True)
        
        self.status_label.setText("Recording...")
        self.status_label.setStyleSheet("color: #4CAF50; font-weight: bold;")
    
    def pause_recording(self):
        """Pause or resume the recording."""
        if self.recording_state == "recording":
            self.recording_state = "paused"
            self.capture_thread.pause_recording()
            self.pause_button.setText("Resume")
            self.status_label.setText("Paused")
            self.status_label.setStyleSheet("color: #FF9800; font-weight: bold;")
        else:
            self.recording_state = "recording"
            self.capture_thread.resume_recording()
            self.pause_button.setText("Pause")
            self.status_label.setText("Recording...")
            self.status_label.setStyleSheet("color: #4CAF50; font-weight: bold;")
    
    def stop_recording(self):
        """Stop recording and save to GIF."""
        if self.gif_thread and self.gif_thread.isRunning():
            return
        
        self.recording_state = "stopped"
        self.capture_thread.stop_recording()
        
        self.start_button.setEnabled(True)
        self.pause_button.setEnabled(False)
        self.pause_button.setText("Pause")
        self.stop_button.setEnabled(False)
        
        self.status_label.setText("Processing...")
        self.status_label.setStyleSheet("color: #2196F3; font-weight: bold;")
        self.progress_bar.setVisible(True)
        self.progress_bar.setRange(0, 100)
        
        self.start_gif_processing()
    
    def cancel_processing(self):
        """Cancel GIF processing."""
        if self.gif_thread and self.gif_thread.isRunning():
            self.gif_thread.terminate()
            self.gif_thread.wait(2000)
        self.reset_ui()
    
    def start_gif_processing(self):
        """Start background GIF processing."""
        frames_data, frame_shapes = self.capture_thread.get_frames()
        
        if not frames_data:
            QMessageBox.warning(self, "No Frames", "No frames captured!")
            self.reset_ui()
            return
        
        # Get save location
        if self.recordings_folder and self.recordings_folder.exists():
            default_path = str(self.recordings_folder / f"screen_recording_{int(time.time())}.gif")
        else:
            default_path = f"screen_recording_{int(time.time())}.gif"
        
        file_path, _ = QFileDialog.getSaveFileName(
            self,
            "Save GIF File",
            default_path,
            "GIF Files (*.gif)"
        )
        
        if not file_path:
            self.reset_ui()
            return
        
        # Create and start background processing thread
        self.gif_thread = GifProcessingThread(
            frames_data,
            frame_shapes,
            self.capture_thread.playback_fps,
            file_path
        )
        
        self.gif_thread.progress_updated.connect(self.update_gif_progress)
        self.gif_thread.processing_completed.connect(self.gif_processing_completed)
        self.gif_thread.processing_failed.connect(self.gif_processing_failed)
        
        self.cancel_button.setVisible(True)
        self.gif_thread.start()
        
        # Clear frames immediately to free memory
        self.capture_thread.clear_frames()
    
    def update_gif_progress(self, progress):
        """Update progress bar during GIF processing."""
        self.progress_bar.setValue(progress)
    
    def gif_processing_completed(self, file_path, frame_count):
        """Handle successful GIF processing completion."""
        file_size = Path(file_path).stat().st_size / (1024 * 1024)
        QMessageBox.information(
            self,
            "Recording Saved",
            f"GIF saved successfully!\n\nFile: {Path(file_path).name}\nFrames: {frame_count}\nSize: {file_size:.1f} MB"
        )
        self.reset_ui()
    
    def gif_processing_failed(self, error_message):
        """Handle GIF processing failure."""
        QMessageBox.critical(self, "Error", error_message)
        self.reset_ui()
    
    def reset_ui(self):
        """Reset the UI to initial state."""
        self.status_label.setText("Ready to record")
        self.status_label.setStyleSheet("color: black;")
        self.frame_count_label.setText("Frames: 0")
        self.progress_bar.setVisible(False)
        self.cancel_button.setVisible(False)
    
    def closeEvent(self, event):
        """Handle widget close."""
        self.capture_thread.stop_recording()
        if self.gif_thread and self.gif_thread.isRunning():
            self.gif_thread.terminate()
            self.gif_thread.wait(3000)
        self.capture_thread.cleanup()
        self.capture_thread.quit()
        self.capture_thread.wait(3000)
        if self.capture_thread.isRunning():
            self.capture_thread.terminate()
            self.capture_thread.wait(1000)
        event.accept()

