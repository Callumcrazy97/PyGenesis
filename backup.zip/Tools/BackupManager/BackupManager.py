"""
Backup Manager for PyGenesis IDE
Handles creating backups with progress feedback
"""

import os
import sys
import subprocess
import zipfile
from pathlib import Path
from typing import Optional, Callable, List, Set

# Check if packaging is installed, install it if not
try:
    from packaging import version as version_lib
except ImportError:
    # Try to install it silently
    try:
        subprocess.check_call([sys.executable, "-m", "pip", "install", "packaging", "-q"], 
                            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        from packaging import version as version_lib
    except Exception:
        # If installation fails, create a simple version comparison
        class SimpleVersion:
            def __init__(self, version_str):
                self.version_str = version_str
            def __lt__(self, other):
                try:
                    parts_self = [int(x) for x in self.version_str.split('.')]
                    parts_other = [int(x) for x in other.version_str.split('.')]
                    return parts_self < parts_other
                except:
                    return self.version_str < other.version_str
        version_lib = type('version', (), {'Version': SimpleVersion})()


class BackupManager:
    """Manages backup creation with progress feedback"""
    
    def __init__(self, progress_callback: Optional[Callable[[str], None]] = None):
        """
        Initialize BackupManager
        
        Args:
            progress_callback: Optional callback function(str) to report progress messages
        """
        self.progress_callback = progress_callback or (lambda msg: None)
        self.exclude_patterns = ['__pycache__', '.pyc', '.pyo', '.pyd']
        self.included_folders: Optional[Set[str]] = None  # None = include all, set = only include these
        self.excluded_folders: Set[str] = set()  # Folders to explicitly exclude
    
    def _log(self, message: str):
        """Log a message via callback or print"""
        self.progress_callback(message)
    
    def get_backup_destination(self, base_path: Path, use_version_structure: bool = True):
        """
        Determine the next backup destination folder.
        
        Args:
            base_path: Base path where backups are stored
            use_version_structure: If True, uses MainVersion/Range/Number structure.
                                  If False, uses simple Range/Number structure.
        
        Returns:
            tuple: (destination_path, main_version, backup_number)
        """
        if not use_version_structure:
            # Simple structure: base_path/Range/Number
            highest_number = -1
            
            # Find highest backup number
            if base_path.exists():
                for item in base_path.iterdir():
                    if item.is_dir() and '-' in item.name:
                        # This is a range folder (e.g., "50-59")
                        for number_folder in item.iterdir():
                            if number_folder.is_dir():
                                try:
                                    num = int(number_folder.name)
                                    highest_number = max(highest_number, num)
                                except:
                                    pass
            
            next_number = highest_number + 1
            range_start = (next_number // 10) * 10
            range_end = range_start + 9
            range_folder = f"{range_start}-{range_end}"
            destination = base_path / range_folder / str(next_number)
            
            return destination, None, next_number
        
        # Version-based structure: base_path/MainVersion/Range/Number
        # Find highest MainVersion
        main_versions = []
        for item in base_path.iterdir():
            if item.is_dir():
                try:
                    version_lib.Version(item.name)
                    main_versions.append(item.name)
                except:
                    pass
        
        if main_versions:
            main_versions.sort(key=lambda v: version_lib.Version(v))
            main_version = main_versions[-1]
        else:
            main_version = "0.1"
        
        # Find highest backup number in current MainVersion
        main_version_path = base_path / main_version
        highest_number = -1
        
        if main_version_path.exists():
            for item in main_version_path.iterdir():
                if item.is_dir() and '-' in item.name:
                    for number_folder in item.iterdir():
                        if number_folder.is_dir():
                            try:
                                num = int(number_folder.name)
                                highest_number = max(highest_number, num)
                            except:
                                pass
        
        next_number = highest_number + 1
        range_start = (next_number // 10) * 10
        range_end = range_start + 9
        range_folder = f"{range_start}-{range_end}"
        destination = main_version_path / range_folder / str(next_number)
        
        return destination, main_version, next_number
    
    def set_folder_filters(self, included_folders: Optional[Set[str]] = None, excluded_folders: Optional[Set[str]] = None):
        """
        Set folder inclusion/exclusion filters
        
        Args:
            included_folders: Set of folder names to include (None = include all)
            excluded_folders: Set of folder names to exclude
        """
        self.included_folders = included_folders
        if excluded_folders:
            self.excluded_folders = excluded_folders
        else:
            self.excluded_folders = set()
    
    def should_exclude(self, path: Path, relative_to_source: Optional[Path] = None) -> bool:
        """
        Check if path should be excluded from backup
        
        Args:
            path: Full path to check
            relative_to_source: Relative path from source directory (for folder name checking)
        """
        path_str = str(path)
        
        # Check exclude patterns (__pycache__, .pyc, etc.)
        for pattern in self.exclude_patterns:
            if pattern in path_str:
                return True
        
        # Check folder inclusion/exclusion if relative path provided
        if relative_to_source is not None:
            # Get top-level folder name
            parts = relative_to_source.parts
            if parts:
                top_folder = parts[0]
                
                # Check if this is a root-level file (only one part, and it's a file, not a folder)
                # Root files like main.py should always be included
                is_root_file = len(parts) == 1 and path.is_file()
                
                if is_root_file:
                    # Root-level files are always included (e.g., main.py, requirements.txt, etc.)
                    return False
                
                # Check explicit exclusions
                if top_folder in self.excluded_folders:
                    return True
                
                # Check inclusions (if specified)
                if self.included_folders is not None:
                    if top_folder not in self.included_folders:
                        return True
            else:
                # Root-level file (no folder parts) - always include root files like main.py
                # This ensures root .py files are backed up even when included_folders is set
                return False
        
        return False
    
    def get_relative_path(self, source_dir: Path, file_path: Path) -> Path:
        """Get relative path from source directory"""
        try:
            return file_path.relative_to(source_dir)
        except:
            return Path(file_path.name)
    
    def format_path_for_display(self, path: Path, max_length: int = 60) -> str:
        """Format path for display, truncating if too long"""
        path_str = str(path)
        if len(path_str) > max_length:
            return "..." + path_str[-(max_length-3):]
        return path_str
    
    def create_backup(self, 
                     source_dir: Path, 
                     backup_base_path: Path,
                     use_version_structure: bool = True,
                     progress_callback: Optional[Callable[[int, int, str, str], None]] = None) -> tuple[Optional[Path], dict]:
        """
        Create a backup of the source directory to a zip file.
        
        Args:
            source_dir: Directory to backup
            backup_base_path: Base path where backup will be stored
            use_version_structure: If True, uses MainVersion/Range/Number structure
            progress_callback: Optional callback(current, total, current_file, current_folder) for progress updates
        
        Returns:
            tuple: (zip_path or None if failed, result_dict with stats)
        """
        source_path = Path(source_dir).resolve()
        
        if not source_path.exists():
            self._log(f"Error: Source directory does not exist: {source_path}")
            return None, {"error": "Source directory does not exist"}
        
        # Create backup base folder if it doesn't exist
        if not backup_base_path.exists():
            backup_base_path.mkdir(parents=True, exist_ok=True)
        
        # Determine destination
        destination, main_version, backup_number = self.get_backup_destination(
            backup_base_path, use_version_structure
        )
        
        # Create folder structure
        try:
            destination.mkdir(parents=True, exist_ok=True)
        except Exception as e:
            self._log(f"Error creating destination folder: {e}")
            return None, {"error": str(e)}
        
        zip_path = destination / "backup.zip"
        
        # Scan files
        all_files = []
        excluded_count = 0
        total_size = 0
        
        for root, dirs, files in os.walk(source_path):
            root_path = Path(root)
            relative_root = self.get_relative_path(source_path, root_path)
            
            # Filter out excluded directories
            dirs[:] = [d for d in dirs if not self.should_exclude(root_path / d, relative_root / d)]
            
            # Process files
            for file_name in files:
                file_path = root_path / file_name
                relative_file = self.get_relative_path(source_path, file_path)
                if self.should_exclude(file_path, relative_file):
                    excluded_count += 1
                    continue
                
                all_files.append(file_path)
                try:
                    total_size += file_path.stat().st_size
                except:
                    pass
        
        file_count = len(all_files)
        
        if file_count == 0:
            self._log("No files to backup")
            return None, {"error": "No files to backup"}
        
        # Create zip file and backup
        processed = 0
        current_folder = None
        current_folder_display = None
        errors = []
        
        try:
            with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as zipf:
                for file_path in sorted(all_files):
                    relative_path = self.get_relative_path(source_path, file_path)
                    
                    # Track folder changes
                    parent_folder = file_path.parent
                    if parent_folder != current_folder:
                        current_folder = parent_folder
                        folder_relative = self.get_relative_path(source_path, parent_folder)
                        current_folder_display = str(folder_relative)
                    
                    # Add file to zip
                    try:
                        arcname = str(relative_path).replace('\\', '/')
                        zipf.write(file_path, arcname)
                    except Exception as e:
                        errors.append(f"{relative_path}: {str(e)}")
                    
                    # Report progress
                    processed += 1
                    if progress_callback:
                        file_display = str(relative_path)
                        try:
                            callback_result = progress_callback(processed, file_count, file_display, current_folder_display)
                            # Check if callback returned False (cancelled)
                            if callback_result is False:
                                # Remove incomplete zip and return cancelled status
                                if zip_path.exists():
                                    try:
                                        zip_path.unlink()
                                    except:
                                        pass
                                return None, {"error": "Backup cancelled by user"}
                        except Exception:
                            # If callback raises exception, continue with backup
                            pass
                    
        except KeyboardInterrupt:
            # Try to remove incomplete zip file
            if zip_path.exists():
                try:
                    zip_path.unlink()
                except:
                    pass
            return None, {"error": "Backup cancelled by user"}
        except Exception as e:
            self._log(f"Error creating backup: {e}")
            return None, {"error": str(e)}
        
        # Check if zip was created successfully
        if not zip_path.exists():
            return None, {"error": "Backup zip file was not created"}
        
        # Get final zip size
        zip_size = zip_path.stat().st_size
        
        result = {
            "success": True,
            "zip_path": zip_path,
            "files_backed_up": processed,
            "original_size": total_size,
            "compressed_size": zip_size,
            "excluded_count": excluded_count,
            "errors": errors
        }
        
        if zip_size > 0:
            result["compression_ratio"] = (1 - (zip_size / total_size)) * 100
        
        return zip_path, result
    
    def list_backups(self, backup_base_path: Path, use_version_structure: bool = True) -> List[dict]:
        """
        List all available backups.
        
        Args:
            backup_base_path: Base path where backups are stored
            use_version_structure: If True, uses MainVersion/Range/Number structure
        
        Returns:
            List of backup info dictionaries with: path, backup_number, main_version, timestamp
        """
        backups = []
        
        if not backup_base_path.exists():
            return backups
        
        if use_version_structure:
            # Scan version-based structure: base_path/MainVersion/Range/Number
            for main_version_dir in backup_base_path.iterdir():
                if not main_version_dir.is_dir():
                    continue
                
                try:
                    # Validate it's a version directory
                    version_lib.Version(main_version_dir.name)
                    main_version = main_version_dir.name
                except:
                    continue
                
                # Scan range folders
                for range_dir in main_version_dir.iterdir():
                    if not range_dir.is_dir() or '-' not in range_dir.name:
                        continue
                    
                    # Scan number folders
                    for number_dir in range_dir.iterdir():
                        if not number_dir.is_dir():
                            continue
                        
                        try:
                            backup_number = int(number_dir.name)
                            zip_path = number_dir / "backup.zip"
                            
                            if zip_path.exists():
                                # Get modification time
                                timestamp = zip_path.stat().st_mtime
                                backups.append({
                                    "path": zip_path,
                                    "backup_number": backup_number,
                                    "main_version": main_version,
                                    "range": range_dir.name,
                                    "timestamp": timestamp,
                                    "full_path": str(zip_path)
                                })
                        except ValueError:
                            continue
        else:
            # Scan simple structure: base_path/Range/Number
            for range_dir in backup_base_path.iterdir():
                if not range_dir.is_dir() or '-' not in range_dir.name:
                    continue
                
                for number_dir in range_dir.iterdir():
                    if not number_dir.is_dir():
                        continue
                    
                    try:
                        backup_number = int(number_dir.name)
                        zip_path = number_dir / "backup.zip"
                        
                        if zip_path.exists():
                            timestamp = zip_path.stat().st_mtime
                            backups.append({
                                "path": zip_path,
                                "backup_number": backup_number,
                                "main_version": None,
                                "range": range_dir.name,
                                "timestamp": timestamp,
                                "full_path": str(zip_path)
                            })
                    except ValueError:
                        continue
        
        # Sort by backup number (newest first)
        backups.sort(key=lambda x: x["backup_number"], reverse=True)
        return backups
    
    def restore_backup(self,
                      backup_zip_path: Path,
                      restore_destination: Path,
                      progress_callback: Optional[Callable[[int, int, str], None]] = None,
                      overwrite_existing: bool = True) -> tuple[bool, dict]:
        """
        Restore a backup from a zip file.
        
        Args:
            backup_zip_path: Path to the backup zip file
            restore_destination: Directory where files should be restored
            progress_callback: Optional callback(current, total, current_file) for progress updates
            overwrite_existing: If True, overwrite existing files. If False, skip existing files.
        
        Returns:
            tuple: (success: bool, result_dict with stats)
        """
        if not backup_zip_path.exists():
            self._log(f"Error: Backup file does not exist: {backup_zip_path}")
            return False, {"error": "Backup file does not exist"}
        
        # Create restore destination if it doesn't exist
        try:
            restore_destination.mkdir(parents=True, exist_ok=True)
        except Exception as e:
            self._log(f"Error creating restore destination: {e}")
            return False, {"error": str(e)}
        
        # Extract zip file
        files_restored = 0
        files_skipped = 0
        files_failed = 0
        errors = []
        
        try:
            with zipfile.ZipFile(backup_zip_path, 'r') as zipf:
                file_list = zipf.namelist()
                total_files = len(file_list)
                
                for idx, file_info in enumerate(zipf.infolist()):
                    file_path = file_info.filename
                    
                    # Skip directories
                    if file_path.endswith('/'):
                        continue
                    
                    # Resolve destination path
                    dest_path = restore_destination / file_path
                    
                    # Check if file exists and overwrite setting
                    if dest_path.exists() and not overwrite_existing:
                        files_skipped += 1
                        if progress_callback:
                            try:
                                progress_callback(idx + 1, total_files, file_path)
                            except:
                                pass
                        continue
                    
                    # Create parent directories
                    try:
                        dest_path.parent.mkdir(parents=True, exist_ok=True)
                    except Exception as e:
                        errors.append(f"{file_path}: Failed to create directory: {str(e)}")
                        files_failed += 1
                        continue
                    
                    # Extract file
                    try:
                        with zipf.open(file_info) as source:
                            with open(dest_path, 'wb') as target:
                                target.write(source.read())
                        files_restored += 1
                    except Exception as e:
                        errors.append(f"{file_path}: {str(e)}")
                        files_failed += 1
                    
                    # Report progress
                    if progress_callback:
                        try:
                            callback_result = progress_callback(idx + 1, total_files, file_path)
                            if callback_result is False:
                                return False, {"error": "Restore cancelled by user"}
                        except Exception:
                            pass
                
        except zipfile.BadZipFile:
            self._log(f"Error: Invalid zip file: {backup_zip_path}")
            return False, {"error": "Invalid zip file"}
        except Exception as e:
            self._log(f"Error restoring backup: {e}")
            return False, {"error": str(e)}
        
        result = {
            "success": True,
            "files_restored": files_restored,
            "files_skipped": files_skipped,
            "files_failed": files_failed,
            "errors": errors
        }
        
        return True, result

