"""
Background thread for searching PyPI packages
"""

from PySide6.QtCore import QThread, Signal
from Core.ExtensionsManager import ExtensionsManager
from Core.Debug import debug


class PackageSearchThread(QThread):
    """Thread for searching PyPI packages asynchronously"""
    
    # Signals
    search_complete = Signal(list, int)  # results, total
    search_error = Signal(str)
    
    def __init__(self, extensions_manager: ExtensionsManager, query: str, page: int = 1, page_size: int = 20):
        super().__init__()
        self.extensions_manager = extensions_manager
        self.query = query
        self.page = page
        self.page_size = page_size
    
    def run(self):
        """Perform search in background"""
        try:
            debug(f"Searching PyPI for '{self.query}' (page {self.page})...")
            results, total = self.extensions_manager.search_pypi(self.query, self.page, self.page_size)
            self.search_complete.emit(results, total)
        except Exception as e:
            debug(f"Error in PackageSearchThread: {e}")
            import traceback
            debug(traceback.format_exc())
            self.search_error.emit(str(e))


