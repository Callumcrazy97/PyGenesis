"""
Background thread for loading package data in Extensions Manager
"""

from PySide6.QtCore import QThread, Signal
from Core.ExtensionsManager import ExtensionsManager
from Core.Debug import debug


class PackageLoadThread(QThread):
    """Thread for loading installed packages and library data"""
    
    # Signals
    installed_libraries_loaded = Signal(list)
    top_packages_loaded = Signal(list)
    loading_finished = Signal()
    error_occurred = Signal(str)
    
    def __init__(self, extensions_manager: ExtensionsManager):
        super().__init__()
        self.extensions_manager = extensions_manager
    
    def run(self):
        """Load all package data in background"""
        try:
            # Load all installed libraries (unified list) - uses cache, fast
            debug("Loading installed libraries...")
            installed_libs = self.extensions_manager.get_all_installed_libraries()
            self.installed_libraries_loaded.emit(installed_libs)
            
            # Load top packages (cached, very fast)
            debug("Loading top packages...")
            top_packages = self.extensions_manager.get_top_packages(limit=50)
            self.top_packages_loaded.emit(top_packages)
            
            self.loading_finished.emit()
            debug("Package loading completed")
            
        except Exception as e:
            debug(f"Error in PackageLoadThread: {e}")
            import traceback
            debug(traceback.format_exc())
            self.error_occurred.emit(str(e))

