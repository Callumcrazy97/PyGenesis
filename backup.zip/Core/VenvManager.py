"""
Virtual Environment Manager for PyGenesis IDE
Based on VENVvalidator.py and VENVmaker.py - ensures proper venv setup
"""

import sys
import os
import subprocess
import venv
import site
import json
from pathlib import Path
import platform


def safe_run(cmd):
    """Run a subprocess safely without crashing."""
    try:
        return subprocess.run(cmd, capture_output=True, text=True, check=True)
    except subprocess.CalledProcessError as e:
        return None


class VenvManager:
    """Manages the PyGenesis virtual environment with validation and proper setup"""
    
    def __init__(self, app_dir=None, custom_venv_path=None):
        """
        Initialize VenvManager
        
        Args:
            app_dir: Application directory (for fallback/config)
            custom_venv_path: Optional custom path for venv (from settings)
        """
        self.app_dir = Path(app_dir) if app_dir else Path(__file__).parent.parent
        
        # Use custom venv path if provided, otherwise use user folder
        if custom_venv_path:
            custom_path = Path(custom_venv_path)
            # Accept the path even if venv doesn't exist yet (it will be created)
            # Just check that the parent directory exists or it's a valid path
            if custom_path.exists() or (custom_path.parent.exists() if custom_path.parent != custom_path else True):
                self.venv_dir = custom_path
                self.venv_base_dir = custom_path.parent
            else:
                # Invalid custom path, fall back to user folder
                if platform.system() == "Windows":
                    self.venv_base_dir = Path.home() / "pygenesis"
                else:
                    self.venv_base_dir = Path.home() / ".config" / "pygenesis"
                self.venv_dir = self.venv_base_dir / "venv"
        else:
            # Default: use user folder (C:\Users\username\pygenesis\venv on Windows)
            if platform.system() == "Windows":
                self.venv_base_dir = Path.home() / "pygenesis"
            else:
                self.venv_base_dir = Path.home() / ".config" / "pygenesis"
            self.venv_dir = self.venv_base_dir / "venv"
        
        self.config_file = self.venv_base_dir / "venv_config.json"
        
        # Detect paths
        self.paths = self._detect_paths()
    
    def _detect_paths(self):
        """Detect venv component paths (from VENVvalidator.py)"""
        # Allow both <root>/venv/ and <root>/
        cand1 = self.venv_base_dir / "venv"
        cand2 = self.venv_base_dir
        
        venv_base = cand1 if (cand1 / "pyvenv.cfg").exists() else cand2
        
        if platform.system() == "Windows":
            scripts = venv_base / "Scripts"
            python_exe = scripts / "python.exe"
            pip_exe = scripts / "pip.exe"
            site_packages = venv_base / "Lib" / "site-packages"
        else:
            scripts = venv_base / "bin"
            python_exe = scripts / "python"
            pip_exe = scripts / "pip"
            site_packages = (
                venv_base / "lib" /
                f"python{sys.version_info.major}.{sys.version_info.minor}" /
                "site-packages"
            )
        
        return {
            "base": venv_base,
            "scripts": scripts,
            "python": python_exe,
            "pip": pip_exe,
            "pyvenv_cfg": venv_base / "pyvenv.cfg",
            "site_packages": site_packages
        }
    
    def venv_exists(self):
        """Check if the venv already exists (with validation)"""
        return self.paths["pyvenv_cfg"].exists()
    
    def validate_venv(self):
        """
        Validate venv structure and functionality (from VENVvalidator.py)
        
        Returns:
            dict: Validation result with structure checks, errors, warnings
        """
        result = {
            "venv_exists": False,
            "venv_structure": {
                "Scripts_or_bin_exists": False,
                "python_exe_exists": False,
                "pip_exists": False,
                "pyvenv_cfg_exists": False,
                "site_packages_exists": False
            },
            "python_version_inside_venv": None,
            "pip_working": None,
            "errors": [],
            "warnings": []
        }
        
        # Check if venv exists
        venv_detected = self.paths["pyvenv_cfg"].exists()
        result["venv_exists"] = venv_detected
        
        if not venv_detected:
            result["errors"].append("Virtual environment not found")
            return result
        
        # Fill structure report
        s = result["venv_structure"]
        s["Scripts_or_bin_exists"] = self.paths["scripts"].exists()
        s["python_exe_exists"] = self.paths["python"].exists()
        s["pip_exists"] = self.paths["pip"].exists()
        s["pyvenv_cfg_exists"] = self.paths["pyvenv_cfg"].exists()
        s["site_packages_exists"] = self.paths["site_packages"].exists()
        
        # Check for missing components
        missing = [k for k, v in s.items() if not v]
        if missing:
            result["warnings"].append(f"Incomplete venv structure: missing {missing}")
        
        # Test python inside venv
        if self.paths["python"].exists():
            version = self._test_python_version(self.paths["python"])
            result["python_version_inside_venv"] = version
            if version is None:
                result["warnings"].append("Cannot execute python.exe inside venv.")
        else:
            result["errors"].append("python.exe not found inside venv.")
        
        # Test pip inside venv
        if self.paths["pip"].exists():
            pkgs = self._test_pip(self.paths["pip"])
            if pkgs is None:
                result["pip_working"] = False
                result["errors"].append("pip inside venv is NOT working.")
            else:
                result["pip_working"] = True
        else:
            result["errors"].append("pip.exe not found inside venv.")
        
        return result
    
    def _test_python_version(self, python_path):
        """Test Python version"""
        try:
            out = subprocess.run([python_path, "--version"], capture_output=True, text=True)
            if out.returncode == 0:
                return out.stdout.strip()
        except:
            pass
        return None
    
    def _test_pip(self, pip_path):
        """Test pip functionality"""
        try:
            out = subprocess.run([pip_path, "list", "--format=json"],
                               capture_output=True, text=True)
            if out.returncode == 0:
                return json.loads(out.stdout)
        except:
            pass
        return None
    
    def create_venv(self, base_python=None):
        """
        Create a new virtual environment using VENVmaker.py logic
        
        Args:
            base_python: Python executable to use for venv. If None, uses sys.executable
        
        Returns:
            bool: True if successful, False otherwise
        """
        if base_python is None:
            base_python = sys.executable
        
        venv_path = self.venv_dir
        
        # Determine interpreter paths
        if platform.system() == "Windows":
            python_path = venv_path / "Scripts" / "python.exe"
            pip_path = venv_path / "Scripts" / "pip.exe"
            site_packages = venv_path / "Lib" / "site-packages"
        else:
            python_path = venv_path / "bin" / "python"
            pip_path = venv_path / "bin" / "pip"
            site_packages = (
                venv_path / "lib" /
                f"python{sys.version_info.major}.{sys.version_info.minor}" /
                "site-packages"
            )
        
        # 1. Create venv base directory if it doesn't exist
        self.venv_base_dir.mkdir(parents=True, exist_ok=True)
        
        # 2. Create venv if missing
        if not python_path.exists():
            print(f"[INFO] No venv found, creating one at: {venv_path}")
            try:
                venv.EnvBuilder(with_pip=True).create(venv_path)
            except Exception as e:
                print(f"[ERROR] Failed to create venv: {e}")
                return False
        else:
            print(f"[INFO] Existing venv detected: {venv_path}")
        
        # 3. Guarantee pip is available
        if not pip_path.exists():
            print("[INFO] pip missing → ensuring pip")
            safe_run([python_path, "-m", "ensurepip", "--upgrade"])
        
        # 4. Upgrade pip, wheel, setuptools (correct safe way)
        print("[INFO] Upgrading pip, wheel, setuptools safely")
        safe_run([python_path, "-m", "pip", "install", "--upgrade", "pip", "wheel", "setuptools"])
        
        # 5. Write a .pth file inside user's site-packages (from VENVmaker.py)
        user_site = Path(site.getusersitepackages())
        user_site.mkdir(parents=True, exist_ok=True)
        
        pth_file = user_site / "pygenesis_venv_redirect.pth"
        print(f"[INFO] Writing redirect .pth file: {pth_file}")
        
        try:
            with open(pth_file, "w", encoding="utf-8") as f:
                f.write(str(site_packages).replace("\\", "/") + "\n")
            print("[INFO] PyGenesis venv is active and globally linked.")
        except Exception as e:
            print(f"[WARNING] Could not write .pth file: {e}")
        
        # 6. Install core requirements
        if python_path.exists():
            self._install_core_requirements(python_path)
        
        # Update paths after creation
        self.paths = self._detect_paths()
        
        # Save configuration
        self._save_config(base_python)
        
        return True
    
    def _install_core_requirements(self, python_path):
        """Install core requirements from requirements.txt (single source of truth)"""
        try:
            # Find requirements.txt
            app_dir = self.venv_base_dir.parent if self.venv_base_dir.name == ".pygenesis" else self.venv_base_dir
            requirements_file = app_dir / "requirements.txt"
            
            # Try alternative locations
            if not requirements_file.exists():
                # Try relative to current file
                current_file = Path(__file__)
                requirements_file = current_file.parent.parent / "requirements.txt"
            
            if not requirements_file.exists():
                print(f"[WARNING] requirements.txt not found at {requirements_file}")
                return False
            
            print(f"[INFO] Installing requirements from {requirements_file}")
            
            # Use pip install -r requirements.txt directly (simpler and more reliable)
            cmd = [str(python_path), "-m", "pip", "install", "-r", str(requirements_file)]
            
            try:
                result = subprocess.run(
                    cmd,
                    capture_output=True,
                    text=True,
                    timeout=600  # 10 minute timeout
                )
                
                if result.returncode == 0:
                    print("[INFO] Requirements installed successfully")
                    return True
                else:
                    print(f"[WARNING] pip install returned code {result.returncode}")
                    print(f"[WARNING] stderr: {result.stderr[:500]}")
                    # Don't fail completely - some packages might already be installed
                    return True  # Continue anyway
                    
            except subprocess.TimeoutExpired:
                print("[WARNING] Requirements installation timed out")
                return False
            except Exception as e:
                print(f"[WARNING] Error installing requirements: {e}")
                return False
            
            # Old JSON-based approach (kept as fallback comment)
            # This code is no longer used but kept for reference
            if False:  # Disabled - use requirements.txt instead
                with open(requirements_file, 'r') as f:
                    core_requirements = json.load(f)
                    libraries = core_requirements.get("libraries", [])
                
                # Build requirements list
                requirements = []
                for lib in libraries:
                    package_name = lib.get("name", "")
                    version = lib.get("version", "")
                    if package_name:
                        if version:
                            requirements.append(f"{package_name}{version}")
                        else:
                            requirements.append(package_name)
                
                # Old code - disabled
                pass
            
        except Exception as e:
            print(f"[ERROR] Failed to install core requirements: {e}")
            import traceback
            traceback.print_exc()
            return False
    
    def _save_config(self, base_python):
        """Save venv configuration to file"""
        config = {
            "venv_path": str(self.venv_dir),
            "python_executable": str(self.paths["python"]),
            "base_python": str(base_python),
            "python_version": sys.version
        }
        
        try:
            with open(self.config_file, 'w') as f:
                json.dump(config, f, indent=2)
            print(f"[INFO] Saved venv configuration to: {self.config_file}")
        except Exception as e:
            print(f"[WARNING] Could not save venv config: {e}")
    
    def get_python_executable(self):
        """Get the Python executable to use (venv Python if available, else sys.executable)"""
        if self.venv_exists() and self.paths["python"].exists():
            return str(self.paths["python"])
        else:
            return sys.executable
    
    def get_pip_executable(self):
        """Get the pip executable to use"""
        if self.venv_exists() and self.paths["pip"].exists():
            return str(self.paths["pip"])
        else:
            # Fallback to python -m pip
            python_exe = self.get_python_executable()
            return [python_exe, "-m", "pip"]
    
    def activate_venv(self):
        """
        Activate the virtual environment by modifying sys.path
        """
        if not self.venv_exists():
            return False
        
        site_packages = self.paths["site_packages"]
        
        if site_packages.exists():
            # Add to sys.path if not already there
            site_packages_str = str(site_packages)
            # Remove any existing venv path entries first to avoid duplicates
            sys.path = [p for p in sys.path if not p.startswith(str(self.venv_dir))]
            # Insert at the beginning to prioritize venv packages
            sys.path.insert(0, site_packages_str)
            print(f"[INFO] Added venv site-packages to path (priority): {site_packages_str}")
        
        return True
    
    def install_package(self, package_name):
        """
        Install a package into the venv
        
        Args:
            package_name: Name of the package to install
        
        Returns:
            bool: True if successful
        """
        python_exe = self.get_python_executable()
        
        try:
            print(f"[INFO] Installing {package_name} using: {python_exe}")
            result = subprocess.run(
                [python_exe, "-m", "pip", "install", package_name],
                capture_output=True,
                text=True,
                check=True
            )
            return True
        except subprocess.CalledProcessError as e:
            print(f"[ERROR] Failed to install {package_name}: {e.stderr}")
            return False
    
    def verify_venv(self):
        """Verify that the venv is working correctly (uses validation)"""
        validation = self.validate_venv()
        
        if not validation["venv_exists"]:
            return False
        
        if validation["errors"]:
            print(f"[ERROR] Venv validation errors: {validation['errors']}")
            return False
        
        if validation["pip_working"] is False:
            return False
        
        return True
    
    def get_status(self):
        """Get status information about the venv"""
        validation = self.validate_venv()
        status = {
            "exists": validation["venv_exists"],
            "venv_path": str(self.venv_dir),
            "python_executable": str(self.paths["python"]) if validation["venv_exists"] else None,
            "current_python": sys.executable,
            "using_venv": validation["venv_exists"] and self.paths["python"].exists(),
            "validation": validation
        }
        return status
