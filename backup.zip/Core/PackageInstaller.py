"""
Unified Package Installer for PyGenesis
Handles package installation with permission error handling and admin elevation
"""

import subprocess
import sys
import os
from pathlib import Path
from typing import Tuple, Optional
from PySide6.QtCore import QThread, Signal


class UnifiedPackageInstaller(QThread):
    """
    Unified package installer that handles:
    - Normal installation
    - Permission errors with admin elevation
    - User directory installation as fallback
    - Better error messages
    """
    progress = Signal(str)
    finished = Signal(bool, str)  # success, message
    
    def __init__(self, venv_manager, package_name: str, operation: str = "install", 
                 use_user_install: bool = False, timeout: int = 300):
        """
        Initialize package installer
        
        Args:
            venv_manager: VenvManager instance
            package_name: Package to install/update/uninstall
            operation: "install", "update", or "uninstall"
            use_user_install: If True, use --user flag (installs to user site-packages)
            timeout: Timeout in seconds for installation
        """
        super().__init__()
        self.venv_manager = venv_manager
        self.package_name = package_name
        self.operation = operation
        self.use_user_install = use_user_install
        self.timeout = timeout
    
    def run(self):
        """Execute package operation in background"""
        try:
            python_exe = self.venv_manager.get_python_executable()
            
            # Ensure we have the full absolute path
            python_exe = str(Path(python_exe).resolve())
            
            if self.operation == "install":
                self._install_package(python_exe)
            elif self.operation == "update":
                self._update_package(python_exe)
            elif self.operation == "uninstall":
                self._uninstall_package(python_exe)
            else:
                self.finished.emit(False, f"Unknown operation: {self.operation}")
                
        except Exception as e:
            error_msg = str(e)
            self.finished.emit(False, f"Error: {error_msg}")
    
    def _install_package(self, python_exe: str):
        """Install a package with permission error handling"""
        self.progress.emit(f"Installing {self.package_name}...")
        
        # Build pip command
        if self.use_user_install:
            cmd = [python_exe, "-m", "pip", "install", "--user", "--no-cache-dir", self.package_name]
            self.progress.emit("Installing to user directory...")
        else:
            cmd = [python_exe, "-m", "pip", "install", "--no-cache-dir", self.package_name]
            self.progress.emit("Installing to venv...")
        
        try:
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                check=True,
                timeout=self.timeout
            )
            # Invalidate import cache after installation
            import importlib
            importlib.invalidate_caches()
            self.finished.emit(True, f"Successfully installed {self.package_name}")
            
        except subprocess.CalledProcessError as e:
            # Check if it's a permission error
            error_text = (e.stderr or e.stdout or "").lower()
            
            if "access is denied" in error_text or "permission denied" in error_text or "winerror 5" in error_text:
                # Permission error - try user install as fallback (if not already using it)
                if not self.use_user_install:
                    self.progress.emit("Permission error detected. Trying user install...")
                    try:
                        result = subprocess.run(
                            [python_exe, "-m", "pip", "install", "--user", "--no-cache-dir", self.package_name],
                            capture_output=True,
                            text=True,
                            check=True,
                            timeout=self.timeout
                        )
                        self.finished.emit(True, f"Successfully installed {self.package_name} to user directory")
                    except subprocess.CalledProcessError as user_error:
                        # Both venv and user install failed
                        error_msg = user_error.stderr or user_error.stdout or str(user_error)
                        self.finished.emit(False, 
                            f"Installation failed with permission errors.\n\n"
                            f"Original error: {e.stderr or e.stdout}\n\n"
                            f"User install error: {error_msg}\n\n"
                            f"Try running manually in terminal:\n"
                            f'"{python_exe}" -m pip install {self.package_name}'
                        )
                else:
                    # User install also failed
                    error_msg = e.stderr or e.stdout or str(e)
                    self.finished.emit(False,
                        f"Installation failed: {error_msg}\n\n"
                        f"Try running manually in terminal:\n"
                        f'"{python_exe}" -m pip install --user {self.package_name}'
                    )
            else:
                # Non-permission error
                error_msg = e.stderr or e.stdout or str(e)
                self.finished.emit(False, f"Failed to install {self.package_name}: {error_msg}")
                
        except subprocess.TimeoutExpired:
            self.finished.emit(False, f"Installation timed out after {self.timeout} seconds")
    
    def _update_package(self, python_exe: str):
        """Update a package"""
        self.progress.emit(f"Updating {self.package_name}...")
        
        cmd = [python_exe, "-m", "pip", "install", "--upgrade", "--no-cache-dir", self.package_name]
        
        try:
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                check=True,
                timeout=self.timeout
            )
            self.finished.emit(True, f"Successfully updated {self.package_name}")
            
        except subprocess.CalledProcessError as e:
            error_msg = e.stderr or e.stdout or str(e)
            self.finished.emit(False, f"Failed to update {self.package_name}: {error_msg}")
            
        except subprocess.TimeoutExpired:
            self.finished.emit(False, f"Update timed out after {self.timeout} seconds")
    
    def _uninstall_package(self, python_exe: str):
        """Uninstall a package"""
        self.progress.emit(f"Uninstalling {self.package_name}...")
        
        cmd = [python_exe, "-m", "pip", "uninstall", "-y", self.package_name]
        
        try:
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                check=True,
                timeout=self.timeout
            )
            self.finished.emit(True, f"Successfully uninstalled {self.package_name}")
            
        except subprocess.CalledProcessError as e:
            error_msg = e.stderr or e.stdout or str(e)
            self.finished.emit(False, f"Failed to uninstall {self.package_name}: {error_msg}")
            
        except subprocess.TimeoutExpired:
            self.finished.emit(False, f"Uninstall timed out after {self.timeout} seconds")

