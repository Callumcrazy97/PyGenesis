"""
Background thread for loading PyPI package index
"""

from PySide6.QtCore import QThread, Signal
from Core.ExtensionsManager import ExtensionsManager
from Core.Debug import debug


class PyPILoadThread(QThread):
    """Thread for loading PyPI package index in background"""
    
    # Signals
    pypi_names_loaded = Signal()
    error_occurred = Signal(str)
    
    def __init__(self, extensions_manager: ExtensionsManager):
        super().__init__()
        self.extensions_manager = extensions_manager
    
    def run(self):
        """Load PyPI package names in background"""
        try:
            debug("Loading PyPI package index in background thread...")
            self.extensions_manager.load_pypi_names()
            self.pypi_names_loaded.emit()
            debug("PyPI package index loaded successfully")
        except Exception as e:
            debug(f"Error in PyPILoadThread: {e}")
            import traceback
            debug(traceback.format_exc())
            self.error_occurred.emit(str(e))

