"""
Extensions Manager for PyGenesis IDE
Backend logic for package installation, updates, PyPI queries, fuzzy search,
and installed/available package metadata.

This version:
- Keeps your architecture and types.
- Adds robust outdated-package detection via pip list --outdated.
- Integrates fuzzy search and store pagination.
"""

import json
import subprocess
import sys
import importlib
import urllib.request
import re
import requests
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from PySide6.QtCore import QObject, Signal

from Core.Debug import debug
from Core.PackageInstaller import UnifiedPackageInstaller as PackageInstallThread


# ------------------------------
# Fuzzy scoring function (from GPT.py, already integrated)
# ------------------------------
def fuzzy_score(query: str, name: str) -> int:
    """Lightweight fuzzy matching for package search."""
    q = query.lower()
    n = name.lower()

    if n.startswith(q):                 # Highest priority
        return 200 + len(q)

    if q in n:                          # Substring
        return 150 + len(q)

    # Simple similarity: number of matching characters in order
    score = 0
    qi = 0
    for ch in n:
        if qi < len(q) and ch == q[qi]:
            score += 10
            qi += 1

    return score


# ------------------------------
# Fetch all PyPI package names (from GPT.py)
# ------------------------------
def fetch_all_pypi_names() -> List[str]:
    """
    Grabs PyPI simple index (~hundreds of thousands of names).
    Done once per run; cached in-memory via ExtensionsManager.store_all_packages.
    """
    try:
        html = urllib.request.urlopen("https://pypi.org/simple/", timeout=10).read().decode("utf-8")
        names = re.findall(r'<a href=.*?>(.*?)</a>', html)
        return names
    except Exception as e:
        debug(f"Error fetching PyPI package list: {e}")
        return []


# ------------------------------
# Get PyPI info (from GPT.py)
# ------------------------------
def get_pypi_info(pkg: str) -> Optional[dict]:
    """Get package info from PyPI JSON API."""
    try:
        r = requests.get(f"https://pypi.org/pypi/{pkg}/json", timeout=5)
        if r.status_code != 200:
            return None
        return r.json()
    except Exception as e:
        debug(f"Error fetching PyPI info for {pkg}: {e}")
        return None


class ExtensionsManager(QObject):
    """Manages Python package extensions using PyPI JSON API and venv pip."""

    # Signals
    package_installed = Signal(str)
    package_updated = Signal(str)
    package_uninstalled = Signal(str)
    operation_progress = Signal(str)

    def __init__(self, venv_manager, app_dir):
        super().__init__()
        self.venv_manager = venv_manager
        self.app_dir = Path(app_dir) if app_dir else Path(__file__).parent.parent
        self.config_dir = self.app_dir / "Config"

        # PyPI metadata cache
        self.pypi_cache: Dict[str, dict] = {}
        self._load_pypi_cache()

        # Installed packages cache
        self._installed_packages_cache: Optional[Dict[str, str]] = None
        self._installed_packages_cache_time: Optional[datetime] = None
        self._cache_duration = 300  # seconds

        # Outdated packages cache
        self._outdated_cache: Optional[Dict[str, dict]] = None
        self._outdated_cache_time: Optional[datetime] = None
        self._outdated_cache_duration = 300  # seconds

        # Load installed packages cache from disk
        self._load_installed_packages_cache()

        # Store tab state (for fuzzy search / top packages)
        self.store_all_packages: List[str] = []   # all PyPI names minus installed
        self.store_filtered: List[str] = []       # filtered by search
        self.store_current_page: int = 0
        self.store_page_size: int = 30

        # Popular packages list for quick access (curated list like OtherExtensionsManager)
        self.popular_packages: List[str] = [
            "requests", "numpy", "pandas", "matplotlib", "scipy", "scikit-learn",
            "pillow", "opencv-python", "django", "flask", "fastapi", "tornado",
            "pytest", "setuptools", "wheel", "pip", "pyside6", "pyqt5", "pyqt6",
            "pygame", "moderngl", "panda3d", "pyglet", "arcade", "pygame-ce",
            "beautifulsoup4", "lxml", "sqlalchemy", "psycopg2", "pymongo",
            "redis", "celery", "jinja2", "click", "pyyaml", "toml", "python-dotenv",
            "aiohttp", "httpx", "urllib3", "certifi", "charset-normalizer",
            "idna", "packaging", "pyparsing", "six", "python-dateutil",
            "pytz", "babel", "pytesseract", "opencv-contrib-python",
            "tensorflow", "torch", "torchvision", "torchaudio", "transformers",
            "jupyter", "ipython", "notebook", "jupyterlab", "pandas-profiling",
            "seaborn", "plotly", "bokeh", "dash", "streamlit", "gradio",
            "black", "flake8", "pylint", "mypy", "autopep8", "yapf",
            "sphinx", "mkdocs", "pydantic", "marshmallow", "cerberus",
            "python-jose", "passlib", "bcrypt", "cryptography", "pyjwt",
            "gunicorn", "uvicorn", "waitress", "cherrypy", "bottle",
            "web2py", "pyramid", "zope", "twisted", "asyncio",
            "gevent", "eventlet", "greenlet", "geopy", "shapely",
            "fiona", "rasterio", "gdal", "netcdf4", "h5py",
            "tables", "pyarrow", "parquet", "feather", "xlsxwriter",
            "openpyxl", "xlrd", "xlwt", "pypdf2", "reportlab",
            "qrcode", "barcode", "pyzbar", "pycryptodome", "hashlib"
        ]

    # -------------------------------------------------------------------------
    # Cache management
    # -------------------------------------------------------------------------

    def _load_pypi_cache(self):
        """Load PyPI cache from disk."""
        cache_file = self.config_dir / "PyPICache.json"
        if cache_file.exists():
            try:
                with open(cache_file, 'r', encoding="utf-8") as f:
                    self.pypi_cache = json.load(f)
            except Exception as e:
                debug(f"Error loading PyPI cache: {e}")
                self.pypi_cache = {}

    def _save_pypi_cache(self):
        """Save PyPI cache to disk."""
        cache_file = self.config_dir / "PyPICache.json"
        try:
            self.config_dir.mkdir(exist_ok=True, parents=True)
            with open(cache_file, 'w', encoding="utf-8") as f:
                json.dump(self.pypi_cache, f, indent=2)
        except Exception as e:
            debug(f"Error saving PyPI cache: {e}")

    def _load_installed_packages_cache(self):
        """Load installed packages cache from disk."""
        cache_file = self.config_dir / "InstalledPackagesCache.json"
        if cache_file.exists():
            try:
                with open(cache_file, 'r', encoding="utf-8") as f:
                    cache_data = json.load(f)
                    self._installed_packages_cache = cache_data.get("packages", {})
                    cached_time_str = cache_data.get("cached_at")
                    if cached_time_str:
                        try:
                            self._installed_packages_cache_time = datetime.fromisoformat(cached_time_str)
                            cache_age = (datetime.now() - self._installed_packages_cache_time).total_seconds()
                            if cache_age >= self._cache_duration:
                                # Cache expired
                                self._installed_packages_cache = None
                                self._installed_packages_cache_time = None
                            else:
                                debug(f"Loaded installed packages cache from disk (age: {cache_age:.1f}s)")
                        except Exception:
                            self._installed_packages_cache = None
                            self._installed_packages_cache_time = None
            except Exception as e:
                debug(f"Error loading installed packages cache: {e}")

    def _save_installed_packages_cache(self):
        """Save installed packages cache to disk."""
        if self._installed_packages_cache is None:
            return

        cache_file = self.config_dir / "InstalledPackagesCache.json"
        try:
            self.config_dir.mkdir(exist_ok=True, parents=True)
            cache_data = {
                "packages": self._installed_packages_cache,
                "cached_at": self._installed_packages_cache_time.isoformat() if self._installed_packages_cache_time else None
            }
            with open(cache_file, 'w', encoding="utf-8") as f:
                json.dump(cache_data, f, indent=2)
        except Exception as e:
            debug(f"Error saving installed packages cache: {e}")

    def clear_installed_packages_cache(self):
        """Clear the installed packages cache (call after install/uninstall/update)."""
        self._installed_packages_cache = None
        self._installed_packages_cache_time = None
        cache_file = self.config_dir / "InstalledPackagesCache.json"
        if cache_file.exists():
            try:
                cache_file.unlink()
            except Exception:
                pass

    # -------------------------------------------------------------------------
    # Core: installed & outdated packages via pip
    # -------------------------------------------------------------------------

    def get_all_installed_packages(self, use_cache: bool = True) -> Dict[str, str]:
        """
        Get all installed packages from venv using pip list (with caching).
        Returns a dict mapping lower-case package name → version.
        """
        # Cache path
        if use_cache and self._installed_packages_cache is not None:
            if self._installed_packages_cache_time is not None:
                try:
                    cache_age = (datetime.now() - self._installed_packages_cache_time).total_seconds()
                    if cache_age < self._cache_duration:
                        debug(f"Using cached installed packages (age: {cache_age:.1f}s)")
                        return self._installed_packages_cache
                except Exception:
                    pass

        # Cache miss: call pip
        try:
            python_exe = self.venv_manager.get_python_executable()
            result = subprocess.run(
                [python_exe, "-m", "pip", "list", "--format=json"],
                capture_output=True,
                text=True,
                timeout=15
            )
            if result.returncode == 0:
                packages = json.loads(result.stdout)
                package_dict: Dict[str, str] = {}
                for pkg in packages:
                    name = pkg["name"]
                    version = pkg["version"]
                    name_lower = name.lower()
                    package_dict[name_lower] = version
                    # Also store original case as alias
                    if name_lower != name:
                        package_dict[name] = version

                debug(f"Found {len(packages)} installed packages")

                # Update cache
                self._installed_packages_cache = package_dict
                self._installed_packages_cache_time = datetime.now()
                self._save_installed_packages_cache()
                return package_dict
            else:
                debug(f"pip list failed: {result.stderr}")
        except Exception as e:
            debug(f"Error getting installed packages: {e}")
            import traceback
            debug(traceback.format_exc())

        return {}

    def get_outdated_packages(self, use_cache: bool = True) -> Dict[str, Dict[str, str]]:
        """
        Return a dict of outdated packages:
        {
            "package_name_lower": {
                "name": "PackageName",
                "current_version": "x.y.z",
                "latest_version": "a.b.c"
            },
            ...
        }
        Uses `pip list --outdated --format=json`.
        """
        # Cached result
        if use_cache and self._outdated_cache is not None and self._outdated_cache_time is not None:
            try:
                age = (datetime.now() - self._outdated_cache_time).total_seconds()
                if age < self._outdated_cache_duration:
                    debug(f"Using cached outdated packages (age: {age:.1f}s)")
                    return self._outdated_cache
            except Exception:
                pass

        try:
            python_exe = self.venv_manager.get_python_executable()
            result = subprocess.run(
                [python_exe, "-m", "pip", "list", "--outdated", "--format=json"],
                capture_output=True,
                text=True,
                timeout=30
            )
            if result.returncode != 0:
                debug(f"pip list --outdated failed: {result.stderr}")
                return {}

            data = json.loads(result.stdout)
            outdated: Dict[str, Dict[str, str]] = {}
            for pkg in data:
                name = pkg.get("name", "")
                current = pkg.get("version", "")
                latest = pkg.get("latest_version", "") or pkg.get("latest_version", "")
                if not latest:
                    latest = pkg.get("latest_version", "") or pkg.get("latest_version", "")
                if name:
                    outdated[name.lower()] = {
                        "name": name,
                        "current_version": current,
                        "latest_version": latest
                    }

            self._outdated_cache = outdated
            self._outdated_cache_time = datetime.now()
            debug(f"Found {len(outdated)} outdated packages")
            return outdated

        except Exception as e:
            debug(f"Error getting outdated packages: {e}")
            import traceback
            debug(traceback.format_exc())
            return {}

    # -------------------------------------------------------------------------
    # Installed libraries → unified list with core/optional info
    # -------------------------------------------------------------------------

    def get_all_installed_libraries(self) -> List[Dict]:
        """
        Get all installed packages as a unified list with metadata from:
        - Config/CoreRequirements.json
        - Config/OptionalRequirements.json (still supported)
        """
        try:
            installed_packages = self.get_all_installed_packages()
            libraries: List[Dict] = []
            processed_packages = set()

            core_file = self.config_dir / "CoreRequirements.json"
            optional_file = self.config_dir / "OptionalRequirements.json"

            core_map = {}
            optional_map = {}

            # Load core metadata
            if core_file.exists():
                try:
                    with open(core_file, 'r', encoding="utf-8") as f:
                        data = json.load(f)
                        for lib in data.get("libraries", []):
                            key = lib.get("name", "").lower()
                            if key:
                                core_map[key] = lib
                except Exception as e:
                    debug(f"Error reading CoreRequirements.json: {e}")

            # Load optional metadata (if present)
            if optional_file.exists():
                try:
                    with open(optional_file, 'r', encoding="utf-8") as f:
                        data = json.load(f)
                        for lib in data.get("libraries", []):
                            key = lib.get("name", "").lower()
                            if key:
                                optional_map[key] = lib
                except Exception as e:
                    debug(f"Error reading OptionalRequirements.json: {e}")

            for package_name, version in installed_packages.items():
                key = package_name.lower()
                if key in processed_packages:
                    continue
                processed_packages.add(key)

                import_name = package_name
                category = "Other"
                description = ""

                # From CoreRequirements.json
                meta = core_map.get(key)
                if meta:
                    import_name = meta.get("import_name", package_name)
                    category = meta.get("category", "Core")
                    description = meta.get("description", "")

                # If not core, check optional
                if meta is None:
                    meta_opt = optional_map.get(key)
                    if meta_opt:
                        import_name = meta_opt.get("import_name", package_name)
                        category = meta_opt.get("category", "Other")
                        description = meta_opt.get("description", "")

                libraries.append({
                    "name": package_name,
                    "import_name": import_name,
                    "installed_version": version,
                    "category": category,
                    "description": description
                })

            libraries.sort(key=lambda x: x["name"].lower())
            return libraries

        except Exception as e:
            debug(f"Error getting installed libraries: {e}")
            import traceback
            debug(traceback.format_exc())
            return []

    def get_core_libraries(self) -> List[Dict]:
        """Legacy method - returns installed core libraries only."""
        all_libs = self.get_all_installed_libraries()
        return [lib for lib in all_libs if lib.get("category", "Other") == "Core"]

    def get_optional_libraries(self) -> List[Dict]:
        """Legacy method - returns installed optional libraries only."""
        all_libs = self.get_all_installed_libraries()
        return [lib for lib in all_libs if lib.get("category", "Other") != "Core"]

    # -------------------------------------------------------------------------
    # Package presence / metadata
    # -------------------------------------------------------------------------

    def check_package_installed(self, package_name: str, import_name: Optional[str] = None) -> Tuple[bool, Optional[str]]:
        """Check if a package is installed and return version (using pip list cache)."""
        installed_packages = self.get_all_installed_packages()
        package_name_lower = package_name.lower()

        # Direct match (case-insensitive)
        if package_name_lower in installed_packages:
            return True, installed_packages[package_name_lower]

        for installed_name, version in installed_packages.items():
            if installed_name.lower() == package_name_lower:
                return True, version

        # Try import name if provided
        if import_name:
            import_name_lower = import_name.lower()
            if import_name_lower in installed_packages:
                return True, installed_packages[import_name_lower]
            for installed_name, version in installed_packages.items():
                if installed_name.lower() == import_name_lower:
                    return True, version

        return False, None

    def get_package_info(self, package_name: str, use_cache: bool = True) -> Dict:
        """Get package information from PyPI JSON API (with disk cache)."""
        # Cache lookup
        if use_cache and package_name in self.pypi_cache:
            cached = self.pypi_cache[package_name]
            if "cached_at" in cached:
                try:
                    cached_time = datetime.fromisoformat(cached["cached_at"])
                    age_hours = (datetime.now() - cached_time).total_seconds() / 3600
                    if age_hours < 24:
                        return cached
                except Exception:
                    pass

        # Fetch from PyPI
        data = get_pypi_info(package_name)
        if data:
            info = {
                "name": package_name,
                "version": data.get("info", {}).get("version", "Unknown"),
                "description": data.get("info", {}).get("summary", ""),
                "homepage": data.get("info", {}).get("home_page", ""),
                "author": data.get("info", {}).get("author", ""),
                "license": data.get("info", {}).get("license", ""),
                "latest_version": data.get("info", {}).get("version", "Unknown"),
                "downloads": 0,
                "cached_at": datetime.now().isoformat()
            }
            self.pypi_cache[package_name] = info
            self._save_pypi_cache()
            return info

        # Fallback – stale cache or empty
        if package_name in self.pypi_cache:
            return self.pypi_cache[package_name]

        return {
            "name": package_name,
            "version": "Unknown",
            "description": "Error fetching package information from PyPI",
            "latest_version": "Unknown",
            "downloads": 0
        }

    # -------------------------------------------------------------------------
    # Top packages / store index
    # -------------------------------------------------------------------------

    def get_top_packages(self, limit: int = 100) -> List[Dict]:
        """
        Get top/popular packages - optimized like OtherExtensionsManager.
        Uses curated popular packages list first (fast), only uses full index if available.
        """
        # Get installed packages to filter them out
        installed = self.get_all_installed_packages()
        installed_lower = set(installed.keys())
        
        # Use curated popular packages (fast, like OtherExtensionsManager)
        available_popular = [pkg for pkg in self.popular_packages if pkg.lower() not in installed_lower]
        
        # If we have a loaded index, we could merge, but for speed, just use curated list
        # This matches OtherExtensionsManager's approach - fast initial load
        results: List[Dict] = []
        for pkg in available_popular[:limit]:
            try:
                info = self.get_package_info(pkg, use_cache=True)
                results.append({
                    "name": info.get("name", pkg),
                    "version": info.get("version", "Unknown"),
                    "description": info.get("description", "")[:150]
                })
            except Exception:
                results.append({
                    "name": pkg,
                    "version": "Unknown",
                    "description": ""
                })
        return results

    def load_pypi_names(self):
        """
        Load all PyPI package names in background (from GPT.py).
        Also precomputes a filtered top ~100 list for initial Store display.
        """
        debug("Loading PyPI package index…")
        names = fetch_all_pypi_names()
        installed = self.get_all_installed_packages()
        installed_lower = set(installed.keys())

        # Remove installed packages from the store index
        self.store_all_packages = [n for n in names if n.lower() not in installed_lower]
        debug(f"Loaded {len(self.store_all_packages)} packages into store index.")

        # Seed store_filtered with top 100
        popular_patterns = ['py', 'python', 'lib', 'tool', 'api', 'util', 'core', 'base']
        scored_initial = []
        for name in self.store_all_packages[:5000]:
            score = 0
            name_lower = name.lower()
            score += max(0, 50 - len(name))
            for pattern in popular_patterns:
                if name_lower.startswith(pattern):
                    score += 20
            scored_initial.append((score, name))

        scored_initial.sort(reverse=True, key=lambda x: x[0])
        initial_packages = [name for score, name in scored_initial[:100]]
        self.store_filtered = initial_packages.copy()
        self.store_current_page = 0

    def search_pypi(self, query: str, page: int = 1, page_size: int = 20) -> Tuple[List[Dict], int]:
        """
        Search PyPI using fuzzy matching - optimized like OtherExtensionsManager.
        Returns (results_list, total_matching_count).
        """
        query_lower = query.strip().lower()

        # No query -> return top popular packages (fast, like OtherExtensionsManager)
        if not query_lower:
            # Use curated popular packages for fast loading
            popular_packages = self.get_top_packages(limit=100)
            self.store_filtered = [pkg["name"] for pkg in popular_packages]
            
            # Return top packages (paginated)
            start = (page - 1) * page_size
            end = start + page_size
            page_items = popular_packages[start:end] if popular_packages else []
            
            # Format results
            results: List[Dict] = []
            for pkg in page_items:
                results.append({
                    "name": pkg.get("name", ""),
                    "version": pkg.get("version", "Unknown"),
                    "description": pkg.get("description", "")[:150]
                })
            
            return results, len(self.store_filtered)

        # Query provided: fuzzy match (lazy load full index only when searching)
        if not self.store_all_packages:
            # Only load full index when user actually searches (lazy loading)
            self.load_pypi_names()
        
        if not self.store_all_packages:
            # Fallback to searching popular packages if full index not loaded
            scored = []
            for pkg in self.popular_packages:
                s = fuzzy_score(query_lower, pkg)
                if s > 0:
                    scored.append((s, pkg))
            
            scored.sort(reverse=True, key=lambda x: x[0])
            self.store_filtered = [name for score, name in scored]
        else:
            # Search full index
            scored = []
            for name in self.store_all_packages:
                s = fuzzy_score(query_lower, name)
                if s > 0:
                    scored.append((s, name))
            
            scored.sort(reverse=True, key=lambda x: x[0])
            # Limit to top 1000 results
            if len(scored) > 1000:
                scored = scored[:1000]
            
            self.store_filtered = [name for score, name in scored]
        
        self.store_current_page = page - 1  # Store current page for reference

        start = (page - 1) * page_size
        end = start + page_size
        page_names = self.store_filtered[start:end]

        results: List[Dict] = []
        for name in page_names:
            try:
                info = self.get_package_info(name, use_cache=True)
                results.append({
                    "name": info.get("name", name),
                    "version": info.get("version", "Unknown"),
                    "description": info.get("description", "")[:150]
                })
            except Exception:
                results.append({
                    "name": name,
                    "version": "Unknown",
                    "description": ""
                })

        total = len(self.store_filtered)
        debug(f"Found {total} results for '{query}' (page {page}, showing {len(results)})")
        return results, total

    # -------------------------------------------------------------------------
    # Install / update / uninstall operations
    # -------------------------------------------------------------------------

    def install_package(self, package_name: str) -> PackageInstallThread:
        """Install a package via UnifiedPackageInstaller."""
        thread = PackageInstallThread(self.venv_manager, package_name, "install")
        thread.finished.connect(lambda success, msg: self._on_operation_finished(success, msg, "install", package_name))
        thread.progress.connect(self.operation_progress.emit)
        return thread

    def update_package(self, package_name: str) -> PackageInstallThread:
        """Update a package to latest version."""
        thread = PackageInstallThread(self.venv_manager, package_name, "update")
        thread.finished.connect(lambda success, msg: self._on_operation_finished(success, msg, "update", package_name))
        thread.progress.connect(self.operation_progress.emit)
        return thread

    def uninstall_package(self, package_name: str) -> PackageInstallThread:
        """Uninstall a package."""
        thread = PackageInstallThread(self.venv_manager, package_name, "uninstall")
        thread.finished.connect(lambda success, msg: self._on_operation_finished(success, msg, "uninstall", package_name))
        thread.progress.connect(self.operation_progress.emit)
        return thread

    def _on_operation_finished(self, success: bool, message: str, operation: str, package_name: str):
        """Handle completion of install/update/uninstall."""
        if success:
            # Clear caches after any change
            self.clear_installed_packages_cache()
            self._outdated_cache = None
            self._outdated_cache_time = None

            if operation == "install":
                self.package_installed.emit(package_name)
            elif operation == "update":
                self.package_updated.emit(package_name)
            elif operation == "uninstall":
                self.package_uninstalled.emit(package_name)
        else:
            self.operation_progress.emit(f"ERROR: {message}")

        debug(message)
