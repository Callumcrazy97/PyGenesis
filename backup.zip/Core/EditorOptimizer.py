"""
Editor Optimizer
Provides utilities to optimize editor initialization and prevent flashing/minimizing.
Implements best practices for fast, smooth editor opening.
"""

from PySide6.QtCore import QTimer, Qt
from PySide6.QtWidgets import QWidget
from Core.Debug import debug


class EditorOptimizer:
    """Utilities for optimizing editor initialization"""
    
    @staticmethod
    def freeze_layout_updates(widget: QWidget, callback):
        """
        Freeze layout updates while executing a callback.
        Prevents window flashing during dock/widget creation.
        """
        widget.setUpdatesEnabled(False)
        try:
            callback()
        finally:
            widget.setUpdatesEnabled(True)
    
    @staticmethod
    def defer_heavy_operation(callback, delay_ms: int = 0):
        """
        Defer a heavy operation until after the window is visible.
        Use delay_ms=0 for immediate post-show execution, or higher for delayed execution.
        """
        QTimer.singleShot(delay_ms, callback)
    
    @staticmethod
    def defer_preview_loading(editor, load_preview_callback, delay_ms: int = 50):
        """
        Defer preview loading (images, models, waveforms) until after editor is shown.
        This prevents UI freezing during preview generation.
        """
        def deferred_load():
            try:
                load_preview_callback()
            except Exception as e:
                debug(f"Error in deferred preview loading: {e}")
                import traceback
                debug(traceback.format_exc())
        
        QTimer.singleShot(delay_ms, deferred_load)
    
    @staticmethod
    def defer_opengl_initialization(editor, init_opengl_callback, delay_ms: int = 100):
        """
        Defer OpenGL context creation until after the window is visible.
        This is critical for ModelEditor to prevent flashing.
        """
        def deferred_init():
            try:
                init_opengl_callback()
            except Exception as e:
                debug(f"Error in deferred OpenGL initialization: {e}")
                import traceback
                debug(traceback.format_exc())
        
        QTimer.singleShot(delay_ms, deferred_init)
    
    @staticmethod
    def build_editor_before_show(editor: QWidget, build_callback):
        """
        Build the editor fully before showing it.
        Ensures all widgets, docks, and layouts are created before the window appears.
        """
        # Freeze updates during construction
        editor.setUpdatesEnabled(False)
        
        try:
            # Build all UI components
            build_callback()
            
            # Process events to ensure everything is laid out
            from PySide6.QtWidgets import QApplication
            QApplication.processEvents()
            
        finally:
            editor.setUpdatesEnabled(True)
    
    @staticmethod
    def restore_state_after_docks(editor, restore_callback, delay_ms: int = 10):
        """
        Restore dock state only after all docks are created.
        This prevents layout flashing.
        """
        def deferred_restore():
            try:
                restore_callback()
            except Exception as e:
                debug(f"Error restoring editor state: {e}")
        
        QTimer.singleShot(delay_ms, deferred_restore)
    
    @staticmethod
    def cache_editor_geometry(editor: QWidget, cache_key: str):
        """
        Cache editor geometry and restore it on next open.
        This makes editors open instantly with the same layout.
        """
        from PySide6.QtCore import QSettings
        
        settings = QSettings()
        
        # Save current geometry
        geometry = editor.saveGeometry()
        state = editor.saveState() if hasattr(editor, 'saveState') else None
        
        settings.setValue(f"editor_geometry/{cache_key}", geometry)
        if state:
            settings.setValue(f"editor_state/{cache_key}", state)
    
    @staticmethod
    def restore_editor_geometry(editor: QWidget, cache_key: str) -> bool:
        """
        Restore cached editor geometry.
        Returns True if geometry was restored, False otherwise.
        """
        from PySide6.QtCore import QSettings
        
        settings = QSettings()
        
        geometry = settings.value(f"editor_geometry/{cache_key}")
        state = settings.value(f"editor_state/{cache_key}")
        
        if geometry:
            editor.restoreGeometry(geometry)
            if state and hasattr(editor, 'restoreState'):
                editor.restoreState(state)
            return True
        
        return False

