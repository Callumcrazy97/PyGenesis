"""
Module Preloader for Performance Optimization
Pre-loads heavy modules at startup to avoid blocking during editor initialization
Enhanced to preload all editor modules for instant editor opening
"""
import sys
import os
from pathlib import Path
from PySide6.QtCore import QObject, Signal, QTimer, QThread
from Core.Debug import debug

class EditorPreloadThread(QThread):
    """Background thread for preloading editor modules"""
    
    preload_complete = Signal(str)  # Emits editor type when preloaded
    preload_error = Signal(str, str)  # Emits (editor_type, error_message)
    
    def __init__(self, editor_type, app_dir):
        super().__init__()
        self.editor_type = editor_type
        self.app_dir = Path(app_dir)
        
    def run(self):
        """Preload editor modules in background"""
        try:
            if self.editor_type == "image":
                self._preload_image_editor()
            elif self.editor_type == "sprite":
                self._preload_sprite_editor()
            elif self.editor_type == "sound":
                self._preload_sound_editor()
            elif self.editor_type == "model":
                self._preload_model_editor()
            elif self.editor_type == "room":
                self._preload_room_editor()
            elif self.editor_type == "object":
                self._preload_object_editor()
            elif self.editor_type == "code":
                self._preload_code_editor()
            
            self.preload_complete.emit(self.editor_type)
            
        except Exception as e:
            error_msg = str(e)
            debug(f"Error preloading {self.editor_type} editor: {error_msg}")
            self.preload_error.emit(self.editor_type, error_msg)
    
    def _preload_image_editor(self):
        """Preload ImageEditor modules"""
        image_editor_path = self.app_dir / "Editors" / "ImageEditor" / "core"
        image_editor_path_str = str(image_editor_path)
        if image_editor_path_str not in sys.path:
            sys.path.insert(0, image_editor_path_str)
        
        # Import key modules
        from ui.main_window import MainWindow
        from core.state import EditorState, state
        from ui.dialogs import UnifiedEffectDialog, NewImageDialog
    
    def _preload_sprite_editor(self):
        """Preload SpriteEditor modules"""
        from Editors.SpriteEditor.SpriteEditor import SpriteEditor
    
    def _preload_sound_editor(self):
        """Preload SoundEditor modules"""
        from Editors.SoundEditor.SoundEditor import SoundEditor
        from Editors.SoundEditor.core.WaveForge import WaveForge
    
    def _preload_model_editor(self):
        """Preload ModelEditor modules"""
        from Editors.ModelEditor.ModelEditor import ModelPreviewWindow
    
    def _preload_room_editor(self):
        """Preload RoomEditor modules"""
        from Editors.RoomEditor.RoomEditor import RoomEditor
    
    def _preload_object_editor(self):
        """Preload ObjectEditor modules"""
        from Editors.ObjectEditor.object_editor import ObjectEditor
    
    def _preload_code_editor(self):
        """Preload CodeEditor modules"""
        from Editors.CodeEditor.ScriptEditor import ScriptEditor


class ModulePreloader(QObject):
    """Pre-loads heavy modules in the background"""
    
    # Signals
    preload_complete = Signal()
    preload_error = Signal(str)
    editor_preloaded = Signal(str)  # Emits editor type when preloaded
    
    def __init__(self, app_dir):
        super().__init__()
        self.app_dir = Path(app_dir)
        self.image_editor_path = self.app_dir / "Editors" / "ImageEditor" / "core"
        self._modules_preloaded = False
        self._preload_threads = []
        self._preloaded_editors = set()
        
    def preload_image_editor_modules(self):
        """Pre-load ImageEditor modules asynchronously (legacy method)"""
        if self._modules_preloaded:
            debug("ImageEditor modules already preloaded")
            self.preload_complete.emit()
            return
        
        debug("Pre-loading ImageEditor modules in background...")
        
        # Use QTimer to defer to next event loop cycle (non-blocking)
        QTimer.singleShot(0, self._do_preload)
    
    def preload_all_editors(self):
        """Preload all editor modules in background threads with timeout"""
        try:
            from Core.Debug import debug
            debug("Starting module preloading...")
            
            self.preload_threads = []
            editors_to_preload = [
                "Editors.SpriteEditor.SpriteEditor",
                "Editors.ImageEditor.ImageEditor",
                "Editors.ObjectEditor.object_editor",
                "Editors.RoomEditor.RoomEditor",
                "Editors.SoundEditor.SoundEditor",
                "Editors.TextureEditor.TextureEditor",
                "Editors.ModelEditor.ModelEditor"
            ]
            
            for editor_type in editors_to_preload:
                try:
                    thread = ModulePreloaderThread(editor_type)
                    
                    # Add timeout guard: if preload takes >30 seconds per editor, skip it
                    def make_handler(et):
                        def handler():
                            try:
                                self._on_editor_preloaded(et)
                            except KeyboardInterrupt:
                                debug(f"Preload interrupted for {et}, continuing...")
                            except Exception as e:
                                debug(f"Error preloading {et}: {e}")
                        return handler
                    
                    thread.preload_complete.connect(make_handler(editor_type))
                    thread.start()
                    self.preload_threads.append(thread)
                    
                except Exception as e:
                    debug(f"Error starting preload thread for {editor_type}: {e}")
                    # Don't crash; continue with next editor
                    continue
            
            # Set a timeout: if preloading takes too long, abort gracefully
            def timeout_check():
                try:
                    active_threads = [t for t in self.preload_threads if t.isRunning()]
                    if active_threads:
                        debug(f"Preloading still running, will continue in background ({len(active_threads)} threads)")
                except Exception:
                    pass
            
            from PySide6.QtCore import QTimer
            QTimer.singleShot(30000, timeout_check)  # 30 second check
            
        except KeyboardInterrupt:
            debug("Module preloading interrupted by user")
        except Exception as e:
            debug(f"Error in preload_all_editors: {e}")
            # Don't crash startup if preloading fails
    
    def _on_editor_preloaded(self, editor_type):
        """Handle editor preload completion"""
        self._preloaded_editors.add(editor_type)
        self.editor_preloaded.emit(editor_type)
        debug(f"{editor_type.capitalize()} editor preloaded")
        
        # Check if all editors are preloaded
        if len(self._preloaded_editors) >= 7:  # All 7 editor types
            debug("All editors preloaded successfully")
            self.preload_complete.emit()
    
    def _do_preload(self):
        """Actually perform the module imports (legacy method)"""
        try:
            # Add Image Editor path to sys.path if not already there
            image_editor_path_str = str(self.image_editor_path)
            if image_editor_path_str not in sys.path:
                sys.path.insert(0, image_editor_path_str)
                debug(f"Added ImageEditor path to sys.path: {image_editor_path_str}")
            
            # Pre-import key ImageEditor modules
            # These are the heavy imports that cause delays
            debug("Importing ui.main_window...")
            from ui.main_window import MainWindow
            debug("Importing core.state...")
            from core.state import EditorState, state
            debug("Importing ui.dialogs...")
            from ui.dialogs import UnifiedEffectDialog, NewImageDialog
            
            # Store references to prevent garbage collection
            self._cached_modules = {
                'MainWindow': MainWindow,
                'EditorState': EditorState,
                'state': state,
                'UnifiedEffectDialog': UnifiedEffectDialog,
                'NewImageDialog': NewImageDialog
            }
            
            self._modules_preloaded = True
            debug("ImageEditor modules preloaded successfully")
            self.preload_complete.emit()
            
        except Exception as e:
            error_msg = f"Failed to preload ImageEditor modules: {str(e)}"
            debug(f"ERROR: {error_msg}")
            import traceback
            debug(traceback.format_exc())
            self.preload_error.emit(error_msg)
            # Don't fail startup if preload fails - modules will load on-demand
    
    def are_modules_preloaded(self):
        """Check if modules have been preloaded"""
        return self._modules_preloaded
    
    def is_editor_preloaded(self, editor_type):
        """Check if a specific editor type has been preloaded"""
        return editor_type in self._preloaded_editors
    
    def get_preloaded_modules(self):
        """Get cached module references"""
        if self._modules_preloaded:
            return self._cached_modules
        return None

