"""
Project Service
Business logic for project operations.
Extracted from ProjectManager to separate concerns.
"""

from typing import Dict, Any, Optional
from Core.Events import EventBus, EventType
from Core.Debug import debug

class ProjectService:
    """Service for project business logic."""
    
    def __init__(self, project_manager):
        """
        Initialize the project service.
        
        Args:
            project_manager: ProjectManager instance (data access)
        """
        self.project_manager = project_manager
        self.event_bus = EventBus()
    
    def create_project(self, project_path: str, project_name: str) -> bool:
        """
        Create a new project (business logic).
        
        Args:
            project_path: Path where project should be created
            project_name: Name of the project
            
        Returns:
            True if successful, False otherwise
        """
        # Validate inputs
        if not project_path or not project_name:
            debug("Project path and name are required")
            return False
        
        # Delegate to ProjectManager
        success = self.project_manager.create_project(project_path, project_name)
        
        if success:
            # Publish event
            self.event_bus.publish(
                EventType.PROJECT_CREATED,
                {
                    'project_path': project_path,
                    'project_name': project_name
                },
                source='ProjectService'
            )
        
        return success
    
    def load_project(self, project_path: str) -> bool:
        """
        Load a project (business logic).
        
        Args:
            project_path: Path to project file
            
        Returns:
            True if successful, False otherwise
        """
        # Validate path
        if not project_path:
            debug("Project path is required")
            return False
        
        # Delegate to ProjectManager
        success = self.project_manager.load_project(project_path)
        
        if success:
            # Publish event
            self.event_bus.publish(
                EventType.PROJECT_OPENED,
                {
                    'project_path': project_path,
                    'project_name': self.project_manager.current_project
                },
                source='ProjectService'
            )
        
        return success
    
    def save_project(self) -> bool:
        """
        Save the current project (business logic).
        
        Returns:
            True if successful, False otherwise
        """
        # Delegate to ProjectManager
        success = self.project_manager.save_project()
        
        if success:
            # Publish event
            self.event_bus.publish(
                EventType.PROJECT_SAVED,
                {
                    'project_path': self.project_manager.project_path,
                    'project_name': self.project_manager.current_project
                },
                source='ProjectService'
            )
        
        return success
    
    def close_project(self) -> bool:
        """
        Close the current project (business logic).
        
        Returns:
            True if successful, False otherwise
        """
        project_path = self.project_manager.project_path
        
        # Delegate to ProjectManager
        success = self.project_manager.close_project()
        
        if success:
            # Publish event
            self.event_bus.publish(
                EventType.PROJECT_CLOSED,
                {
                    'project_path': project_path
                },
                source='ProjectService'
            )
        
        return success

