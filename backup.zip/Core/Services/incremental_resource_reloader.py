"""
Incremental Resource Reloader
Only reloads resources that have changed, not the entire project
"""

from PySide6.QtCore import QThread, Signal, QMutex
import os
import json
from pathlib import Path
from Core.Debug import debug


class IncrementalResourceReloader(QThread):
    """Reloads only changed resources, not the entire project"""
    
    # Signals
    resource_changed = Signal(str, str, dict)  # Emits (resource_type, resource_id, new_data)
    resource_deleted = Signal(str, str)  # Emits (resource_type, resource_id)
    resource_added = Signal(str, str, dict)  # Emits (resource_type, resource_id, resource_data)
    reload_complete = Signal()  # Emits when reload is complete
    
    def __init__(self, project_path, current_runtime_resources):
        super().__init__()
        self.project_path = project_path
        self.current_runtime_resources = current_runtime_resources
        self._mutex = QMutex()
        self._stop_requested = False
        
    def stop(self):
        """Request thread to stop"""
        with QMutex(self._mutex):
            self._stop_requested = True
    
    def run(self):
        """Check for changed resources and reload only those"""
        try:
            # Load project file to get current state
            project_file = Path(self.project_path) / f"{Path(self.project_path).name}.pgproject"
            if not project_file.exists():
                self.reload_complete.emit()
                return
            
            with open(project_file, 'r', encoding='utf-8') as f:
                project_data = json.load(f)
            
            resources = project_data.get("resources", {})
            
            # Check each resource type
            for resource_type, resource_list in resources.items():
                if self._stop_requested:
                    break
                
                current_resources = self.current_runtime_resources.get(resource_type, {})
                
                # Build sets for comparison
                current_ids = set(current_resources.keys())
                new_ids = {r.get("id", "") for r in resource_list if r.get("id")}
                
                # Find deleted resources
                deleted_ids = current_ids - new_ids
                for resource_id in deleted_ids:
                    self.resource_deleted.emit(resource_type, resource_id)
                
                # Find added resources
                added_ids = new_ids - current_ids
                for resource_data in resource_list:
                    resource_id = resource_data.get("id", "")
                    if resource_id in added_ids:
                        self.resource_added.emit(resource_type, resource_id, resource_data)
                
                # Check for changed resources (compare file modification times)
                for resource_data in resource_list:
                    if self._stop_requested:
                        break
                    
                    resource_id = resource_data.get("id", "")
                    if not resource_id or resource_id not in current_ids:
                        continue
                    
                    # Check if resource file has changed
                    if self._resource_file_changed(resource_type, resource_data):
                        # Reload resource
                        new_data = self._load_resource_from_disk(resource_type, resource_data)
                        if new_data:
                            self.resource_changed.emit(resource_type, resource_id, new_data)
            
            if not self._stop_requested:
                self.reload_complete.emit()
                
        except Exception as e:
            error_msg = f"Error reloading resources: {str(e)}"
            debug(error_msg)
            import traceback
            debug(traceback.format_exc())
            self.reload_complete.emit()
    
    def _resource_file_changed(self, resource_type, resource_data):
        """Check if resource file has been modified"""
        try:
            file_path = self._get_resource_file_path(resource_type, resource_data)
            if not file_path or not os.path.exists(file_path):
                return False
            
            current_mtime = os.path.getmtime(file_path)
            resource_id = resource_data.get("id", "")
            current_resource = self.current_runtime_resources.get(resource_type, {}).get(resource_id)
            
            if not current_resource:
                return True  # New resource
            
            # Compare modification times
            cached_mtime = current_resource.get("_file_mtime", 0)
            return current_mtime > cached_mtime
            
        except Exception:
            return False
    
    def _get_resource_file_path(self, resource_type, resource_data):
        """Get the file path for a resource"""
        resource_folder_map = {
            "sprites": "Sprites",
            "backgrounds": "Backgrounds",
            "textures": "Textures",
            "objects": "Objects",
            "sounds": "Sounds",
            "models": "Models",
            "rooms": "Rooms"
        }
        
        folder = resource_folder_map.get(resource_type, "Sprites")
        parent_folder = resource_data.get("parent_folder", "")
        name = resource_data.get("name", "")
        
        base_path = Path(self.project_path) / "Resources" / folder
        if parent_folder:
            base_path = base_path / parent_folder
        
        extensions = {
            "sprites": ".sprite",
            "backgrounds": ".background",
            "textures": ".texture",
            "objects": ".object",
            "sounds": ".sound",
            "models": ".model",
            "rooms": ".room"
        }
        
        ext = extensions.get(resource_type, ".sprite")
        file_path = base_path / f"{name}{ext}"
        
        return str(file_path) if file_path.exists() else None
    
    def _load_resource_from_disk(self, resource_type, resource_data):
        """Load resource data from disk file"""
        try:
            file_path = self._get_resource_file_path(resource_type, resource_data)
            if not file_path or not os.path.exists(file_path):
                return None
            
            with open(file_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            
            # Add metadata
            data["_file_mtime"] = os.path.getmtime(file_path)
            data["_lazy_loaded"] = True
            
            return data
            
        except Exception as e:
            debug(f"Error loading resource from disk: {e}")
            return None


