"""
Resource Service
Business logic for resource operations.
Extracted from ResourceManager to separate concerns.
"""

from typing import Dict, Any, Optional
from Core.Events import EventBus, EventType
from Core.Debug import debug

class ResourceService:
    """Service for resource business logic."""
    
    def __init__(self, resource_manager, project_manager):
        """
        Initialize the resource service.
        
        Args:
            resource_manager: ResourceManager instance (data access)
            project_manager: ProjectManager instance (data access)
        """
        self.resource_manager = resource_manager
        self.project_manager = project_manager
        self.event_bus = EventBus()
    
    def create_resource(self, resource_type: str, name: str, parent_folder: str = "") -> Optional[Dict[str, Any]]:
        """
        Create a new resource (business logic).
        
        Args:
            resource_type: Type of resource to create
            name: Name of the resource
            parent_folder: Parent folder path (optional)
            
        Returns:
            Resource data dictionary or None if error
        """
        # Validate resource type
        if resource_type not in self.resource_manager.resource_types:
            debug(f"Invalid resource type: {resource_type}")
            return None
        
        # Validate name
        if not name or not name.strip():
            debug("Resource name cannot be empty")
            return None
        
        # Delegate to ResourceManager for actual creation
        resource_data = self.resource_manager.create_resource(resource_type, name, parent_folder)
        
        if resource_data:
            # Publish event
            self.event_bus.publish(
                EventType.RESOURCE_CREATED,
                {
                    'resource_type': resource_type,
                    'resource_id': resource_data.get('id'),
                    'resource_data': resource_data
                },
                source='ResourceService'
            )
        
        return resource_data
    
    def update_resource(self, resource_type: str, resource_id: str, updates: Dict[str, Any]) -> bool:
        """
        Update a resource (business logic).
        
        Args:
            resource_type: Type of resource
            resource_id: ID of resource to update
            updates: Dictionary of fields to update
            
        Returns:
            True if successful, False otherwise
        """
        # Validate updates
        if not updates:
            debug("No updates provided")
            return False
        
        # Delegate to ResourceManager
        success = self.resource_manager.update_resource(resource_type, resource_id, updates)
        
        if success:
            # Publish event
            self.event_bus.publish(
                EventType.RESOURCE_UPDATED,
                {
                    'resource_type': resource_type,
                    'resource_id': resource_id,
                    'updates': updates
                },
                source='ResourceService'
            )
        
        return success
    
    def delete_resource(self, resource_type: str, resource_id: str) -> bool:
        """
        Delete a resource (business logic).
        
        Args:
            resource_type: Type of resource
            resource_id: ID of resource to delete
            
        Returns:
            True if successful, False otherwise
        """
        # Delegate to ResourceManager
        success = self.resource_manager.delete_resource(resource_type, resource_id)
        
        if success:
            # Publish event
            self.event_bus.publish(
                EventType.RESOURCE_DELETED,
                {
                    'resource_type': resource_type,
                    'resource_id': resource_id
                },
                source='ResourceService'
            )
        
        return success
    
    def load_resource(self, resource_type: str, resource_id: str) -> Optional[Dict[str, Any]]:
        """
        Load a resource (business logic).
        
        Args:
            resource_type: Type of resource
            resource_id: ID of resource to load
            
        Returns:
            Resource data dictionary or None if not found
        """
        # Delegate to ResourceManager
        resource_data = self.resource_manager.load_resource(resource_type, resource_id)
        
        if resource_data:
            # Publish event
            self.event_bus.publish(
                EventType.RESOURCE_LOADED,
                {
                    'resource_type': resource_type,
                    'resource_id': resource_id,
                    'resource_data': resource_data
                },
                source='ResourceService'
            )
        
        return resource_data

