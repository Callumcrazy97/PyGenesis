"""
Async Project Saver
Saves project in background thread without blocking UI
"""

from PySide6.QtCore import QThread, Signal, QMutex
import os
import json
from pathlib import Path
from Core.Debug import debug


class AsyncProjectSaver(QThread):
    """Saves project asynchronously in background"""
    
    # Signals
    save_complete = Signal(bool, str)  # Emits (success, message)
    save_progress = Signal(str)  # Emits progress message
    
    def __init__(self, project_path, project_name, project_data, runtime_resources=None):
        super().__init__()
        self.project_path = project_path
        self.project_name = project_name
        self.project_data = project_data
        self.runtime_resources = runtime_resources or {}
        self._mutex = QMutex()
        self._stop_requested = False
        
    def stop(self):
        """Request thread to stop"""
        with QMutex(self._mutex):
            self._stop_requested = True
    
    def run(self):
        """Save project in background"""
        try:
            self.save_progress.emit("Preparing to save project...")
            
            # Save runtime resources to project data
            if self.runtime_resources:
                self.save_progress.emit("Saving resource metadata...")
                self._save_runtime_to_project_data()
            
            # Validate JSON serializability
            self.save_progress.emit("Validating project data...")
            try:
                json.dumps(self.project_data)
            except (TypeError, ValueError) as e:
                self.save_complete.emit(False, f"Project contains non-serializable data: {str(e)}")
                return
            
            # Save project file
            self.save_progress.emit("Writing project file...")
            project_file = os.path.join(self.project_path, f"{self.project_name}.pgproject")
            
            with open(project_file, 'w', encoding='utf-8') as f:
                json.dump(self.project_data, f, indent=4, ensure_ascii=False)
            
            # Update project index (fast)
            self.save_progress.emit("Updating project index...")
            try:
                from Core.ProjectIndexManager import ProjectIndexManager
                index_manager = ProjectIndexManager(self.project_path)
                index_manager.generate_index(self.runtime_resources)
            except Exception as e:
                debug(f"Failed to update project index: {e}")
            
            self.save_complete.emit(True, "Project saved successfully")
            
        except Exception as e:
            error_msg = f"Error saving project: {str(e)}"
            debug(error_msg)
            import traceback
            debug(traceback.format_exc())
            self.save_complete.emit(False, error_msg)
    
    def _save_runtime_to_project_data(self):
        """Save runtime resources to project data structure"""
        if not self.runtime_resources:
            return
        
        # Convert runtime resources to project data format
        resources = {}
        for resource_type, resource_dict in self.runtime_resources.items():
            resources[resource_type] = list(resource_dict.values())
        
        self.project_data["resources"] = resources


