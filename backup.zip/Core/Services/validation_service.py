"""
Validation Service
Business logic for data validation.
"""

from typing import Dict, Any, List, Optional
from Core.Debug import debug

class ValidationService:
    """Service for data validation."""
    
    def __init__(self):
        """Initialize the validation service."""
        pass
    
    def validate_resource_name(self, name: str) -> tuple[bool, Optional[str]]:
        """
        Validate a resource name.
        
        Args:
            name: Resource name to validate
            
        Returns:
            Tuple of (is_valid, error_message)
        """
        if not name or not name.strip():
            return False, "Resource name cannot be empty"
        
        if len(name) > 255:
            return False, "Resource name is too long (max 255 characters)"
        
        # Check for invalid characters
        invalid_chars = ['<', '>', ':', '"', '/', '\\', '|', '?', '*']
        for char in invalid_chars:
            if char in name:
                return False, f"Resource name contains invalid character: {char}"
        
        return True, None
    
    def validate_resource_data(self, resource_type: str, resource_data: Dict[str, Any]) -> tuple[bool, Optional[str]]:
        """
        Validate resource data.
        
        Args:
            resource_type: Type of resource
            resource_data: Resource data dictionary
            
        Returns:
            Tuple of (is_valid, error_message)
        """
        # Check required fields
        required_fields = ['id', 'name', 'type']
        for field in required_fields:
            if field not in resource_data:
                return False, f"Missing required field: {field}"
        
        # Validate resource type matches
        if resource_data.get('type') != resource_type:
            return False, f"Resource type mismatch: expected {resource_type}, got {resource_data.get('type')}"
        
        # Validate name
        name_valid, name_error = self.validate_resource_name(resource_data.get('name', ''))
        if not name_valid:
            return False, name_error
        
        return True, None
    
    def validate_project_path(self, project_path: str) -> tuple[bool, Optional[str]]:
        """
        Validate a project path.
        
        Args:
            project_path: Path to validate
            
        Returns:
            Tuple of (is_valid, error_message)
        """
        if not project_path or not project_path.strip():
            return False, "Project path cannot be empty"
        
        # Check if path is too long (Windows limit)
        if len(project_path) > 260:
            return False, "Project path is too long"
        
        return True, None

