"""
Async Editor Loader
Loads editor instances in background thread to avoid blocking UI on double-click
"""

from PySide6.QtCore import QThread, Signal
from Core.Debug import debug
from Core.EditorFactory import EditorFactory


class AsyncEditorLoader(QThread):
    """Loads editor instances asynchronously"""
    
    # Signals
    editor_ready = Signal(object, str, str)  # Emits (editor_widget, resource_type, resource_id)
    editor_error = Signal(str, str)  # Emits (error_message, resource_type)
    
    def __init__(self, resource_type, resource_data, app):
        super().__init__()
        self.resource_type = resource_type
        self.resource_data = resource_data
        self.app = app
        
    def run(self):
        """Load editor in background thread"""
        try:
            debug(f"Loading {self.resource_type} editor asynchronously...")
            
            # Create editor (this may still be slow, but at least it's not blocking UI)
            editor = EditorFactory.create_editor(
                self.resource_type,
                self.resource_data,
                self.app
            )
            
            if editor:
                resource_id = self.resource_data.get("id", "")
                debug(f"Editor loaded successfully for {self.resource_type}/{resource_id}")
                self.editor_ready.emit(editor, self.resource_type, resource_id)
            else:
                self.editor_error.emit(
                    f"Failed to create editor for {self.resource_type}",
                    self.resource_type
                )
                
        except Exception as e:
            error_msg = f"Error loading editor: {str(e)}"
            debug(error_msg)
            import traceback
            debug(traceback.format_exc())
            self.editor_error.emit(error_msg, self.resource_type)


