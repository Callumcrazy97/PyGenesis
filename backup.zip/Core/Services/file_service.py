"""
File Service
Business logic for file operations.
"""

import os
import json
from typing import Dict, Any, Optional
from Core.Debug import debug

class FileService:
    """Service for file operations."""
    
    def __init__(self):
        """Initialize the file service."""
        pass
    
    def read_json_file(self, filepath: str) -> Optional[Dict[str, Any]]:
        """
        Read a JSON file.
        
        Args:
            filepath: Path to JSON file
            
        Returns:
            Parsed JSON data or None if error
        """
        try:
            if not os.path.exists(filepath):
                debug(f"File not found: {filepath}")
                return None
            
            with open(filepath, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception as e:
            debug(f"Error reading JSON file {filepath}: {e}")
            return None
    
    def write_json_file(self, filepath: str, data: Dict[str, Any]) -> bool:
        """
        Write data to a JSON file.
        
        Args:
            filepath: Path to JSON file
            data: Data to write
            
        Returns:
            True if successful, False otherwise
        """
        try:
            # Ensure directory exists
            os.makedirs(os.path.dirname(filepath), exist_ok=True)
            
            with open(filepath, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=4, ensure_ascii=False)
            return True
        except Exception as e:
            debug(f"Error writing JSON file {filepath}: {e}")
            return False
    
    def file_exists(self, filepath: str) -> bool:
        """Check if a file exists."""
        return os.path.exists(filepath)
    
    def ensure_directory(self, dirpath: str) -> bool:
        """Ensure a directory exists, creating it if necessary."""
        try:
            os.makedirs(dirpath, exist_ok=True)
            return True
        except Exception as e:
            debug(f"Error creating directory {dirpath}: {e}")
            return False

