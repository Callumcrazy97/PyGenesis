"""
Async Project Loader
Loads project metadata first, then resources in background without blocking UI
"""

from PySide6.QtCore import QThread, Signal, QMutex
import os
import json
from pathlib import Path
from Core.Debug import debug

# Import at module level to avoid circular imports
try:
    from Core.ProjectIndexManager import ProjectIndexManager
except ImportError:
    ProjectIndexManager = None


class AsyncProjectLoader(QThread):
    """Loads project resources asynchronously in background"""
    
    # Signals
    metadata_loaded = Signal(dict)  # Emits project metadata (fast, for immediate UI update)
    resource_loaded = Signal(str, str, dict)  # Emits (resource_type, resource_id, resource_data)
    loading_complete = Signal()  # Emits when all resources are loaded
    loading_progress = Signal(int, int)  # Emits (current, total) for progress updates
    loading_error = Signal(str)  # Emits error message if loading fails
    
    def __init__(self, project_path, project_data):
        super().__init__()
        self.project_path = project_path
        self.project_data = project_data
        self._mutex = QMutex()
        self._stop_requested = False
        
    def stop(self):
        """Request thread to stop"""
        with QMutex(self._mutex):
            self._stop_requested = True
    
    def run(self):
        """Load project resources in background"""
        try:
            # Extract metadata first (fast)
            metadata = {
                "name": self.project_data.get("name", "Unknown"),
                "version": self.project_data.get("version", "1.0.0"),
                "description": self.project_data.get("description", ""),
                "project_path": self.project_path
            }
            self.metadata_loaded.emit(metadata)
            
            # Try to load from project index first (FAST PATH)
            index_manager = None
            if ProjectIndexManager:
                index_manager = ProjectIndexManager(self.project_path)
            
            if index_manager and index_manager.is_index_valid():
                debug("Loading resources from project index (fast path)...")
                index_data = index_manager.load_index()
                
                if index_data:
                    total_resources = sum(len(r) for r in index_data.values())
                    loaded_count = 0
                    
                    # Load metadata from index (much faster than reading files)
                    for resource_type, type_resources in index_data.items():
                        if self._stop_requested:
                            break
                        
                        for resource_id, metadata in type_resources.items():
                            if self._stop_requested:
                                break
                            
                            # Mark as lazy-loaded (full data loaded on demand)
                            metadata["_lazy_loaded"] = False
                            metadata["type"] = resource_type
                            self.resource_loaded.emit(resource_type, resource_id, metadata)
                            loaded_count += 1
                            self.loading_progress.emit(loaded_count, total_resources)
                    
                    if not self._stop_requested:
                        self.loading_complete.emit()
                    return
            
            # FALLBACK: Load from project data (SLOW PATH - for projects without index)
            debug("Loading resources from project data (slow path - no index found)...")
            resources = self.project_data.get("resources", {})
            total_resources = sum(len(res_list) for res_list in resources.values())
            loaded_count = 0
            
            # Load resources by type
            for resource_type, resource_list in resources.items():
                if self._stop_requested:
                    break
                    
                for resource_data in resource_list:
                    if self._stop_requested:
                        break
                    
                    # Load resource data (lazy - only metadata initially)
                    resource_id = resource_data.get("id", "")
                    if resource_id:
                        # Mark as lazy-loaded (full data loaded on demand)
                        resource_data["_lazy_loaded"] = False
                        resource_data["type"] = resource_type
                        self.resource_loaded.emit(resource_type, resource_id, resource_data)
                        loaded_count += 1
                        self.loading_progress.emit(loaded_count, total_resources)
            
            if not self._stop_requested:
                self.loading_complete.emit()
                
        except Exception as e:
            error_msg = f"Error loading project: {str(e)}"
            debug(error_msg)
            import traceback
            debug(traceback.format_exc())
            self.loading_error.emit(error_msg)

