"""
Script Checker Service for PyGenesis IDE
Validates Python scripts in the project for syntax errors, import issues, and undefined names.
Based on CodeAnalyser.py but adapted for project integration.
"""

import ast
import importlib.util
from pathlib import Path
from typing import Dict, List, Optional, Callable
from collections import defaultdict


class ScriptChecker:
    """
    Service for checking Python scripts in the project.
    Can check a single script or all scripts in the project.
    """
    
    def __init__(self, project_path: Path, output_callback: Optional[Callable[[str], None]] = None):
        """
        Initialize the script checker.
        
        Args:
            project_path: Path to the project root
            output_callback: Optional callback function to receive output messages
        """
        self.project_path = Path(project_path)
        self.output_callback = output_callback
        self.errors = []
        self.warnings = []
        self.detailed_errors = []
        self.detailed_warnings = []
        
    def _output(self, message: str):
        """Output a message via callback if available"""
        if self.output_callback:
            self.output_callback(message)
    
    def check_script(self, script_path: Path) -> Dict:
        """
        Check a single Python script for errors.
        
        Args:
            script_path: Path to the script file
            
        Returns:
            Dictionary with 'errors', 'warnings', 'passed' keys
        """
        self.errors = []
        self.warnings = []
        self.detailed_errors = []
        self.detailed_warnings = []
        
        script_path = Path(script_path)
        
        if not script_path.exists():
            error_msg = f"Script not found: {script_path}"
            self.errors.append(error_msg)
            self._output(f"❌ {error_msg}\n")
            return {
                'errors': self.errors,
                'warnings': self.warnings,
                'passed': False
            }
        
        if not script_path.suffix == '.py':
            error_msg = f"Not a Python file: {script_path}"
            self.errors.append(error_msg)
            self._output(f"❌ {error_msg}\n")
            return {
                'errors': self.errors,
                'warnings': self.warnings,
                'passed': False
            }
        
        try:
            with open(script_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            # Try to parse the file
            try:
                tree = ast.parse(content, filename=str(script_path))
            except SyntaxError as e:
                error_msg = f"Syntax error in {script_path.name}: {e.msg} (line {e.lineno})"
                self.errors.append(error_msg)
                self.detailed_errors.append({
                    'file': str(script_path),
                    'line': e.lineno,
                    'type': 'syntax_error',
                    'message': e.msg,
                    'code': content.split('\n')[e.lineno - 1] if e.lineno <= len(content.split('\n')) else ''
                })
                self._output(f"❌ {error_msg}\n")
                return {
                    'errors': self.errors,
                    'warnings': self.warnings,
                    'passed': False
                }
            
            # Extract definitions and imports
            file_definitions = self._extract_definitions(tree)
            file_imports = self._extract_imports(tree)
            
            # Analyze the file
            self._analyze_file(script_path, tree, file_definitions, file_imports)
            
            # Report results
            if self.errors:
                self._output(f"❌ {script_path.name}: {len(self.errors)} error(s) found\n")
                for error in self.errors:
                    self._output(f"   {error}\n")
            elif self.warnings:
                self._output(f"⚠️  {script_path.name}: {len(self.warnings)} warning(s) found\n")
                for warning in self.warnings:
                    self._output(f"   {warning}\n")
            else:
                self._output(f"✅ {script_path.name}: No errors found\n")
            
            return {
                'errors': self.errors,
                'warnings': self.warnings,
                'passed': len(self.errors) == 0,
                'detailed_errors': self.detailed_errors,
                'detailed_warnings': self.detailed_warnings
            }
            
        except Exception as e:
            error_msg = f"Error checking {script_path.name}: {e}"
            self.errors.append(error_msg)
            self._output(f"❌ {error_msg}\n")
            return {
                'errors': self.errors,
                'warnings': self.warnings,
                'passed': False
            }
    
    def check_all_scripts(self, scripts_folder: Optional[Path] = None) -> Dict:
        """
        Check all Python scripts in the project.
        
        Args:
            scripts_folder: Optional path to scripts folder (defaults to project_path/Scripts)
            
        Returns:
            Dictionary with 'errors', 'warnings', 'passed', 'files_checked' keys
        """
        if scripts_folder is None:
            scripts_folder = self.project_path / "Scripts"
        else:
            scripts_folder = Path(scripts_folder)
        
        if not scripts_folder.exists():
            self._output(f"⚠️  Scripts folder not found: {scripts_folder}\n")
            return {
                'errors': [],
                'warnings': [],
                'passed': True,
                'files_checked': 0
            }
        
        all_errors = []
        all_warnings = []
        files_checked = 0
        files_passed = 0
        
        self._output(f"🔍 Checking all scripts in {scripts_folder}...\n\n")
        
        # Find all Python files
        python_files = list(scripts_folder.rglob('*.py'))
        
        if not python_files:
            self._output("⚠️  No Python files found in Scripts folder\n")
            return {
                'errors': [],
                'warnings': [],
                'passed': True,
                'files_checked': 0
            }
        
        for script_path in python_files:
            # Skip __pycache__ and other system folders
            if '__pycache__' in str(script_path) or '.pyc' in str(script_path):
                continue
            
            files_checked += 1
            result = self.check_script(script_path)
            
            all_errors.extend(result['errors'])
            all_warnings.extend(result['warnings'])
            
            if result['passed']:
                files_passed += 1
        
        # Summary
        self._output(f"\n{'=' * 50}\n")
        self._output(f"📊 Summary:\n")
        self._output(f"   Files checked: {files_checked}\n")
        self._output(f"   Files passed: {files_passed}\n")
        self._output(f"   Total errors: {len(all_errors)}\n")
        self._output(f"   Total warnings: {len(all_warnings)}\n")
        
        if len(all_errors) == 0:
            self._output(f"\n✅ All scripts passed validation!\n")
        else:
            self._output(f"\n❌ Validation failed with {len(all_errors)} error(s)\n")
        
        return {
            'errors': all_errors,
            'warnings': all_warnings,
            'passed': len(all_errors) == 0,
            'files_checked': files_checked,
            'files_passed': files_passed
        }
    
    def _extract_definitions(self, tree):
        """Extract function, class, and variable definitions from AST"""
        definitions = {
            'functions': set(),
            'classes': set(),
            'variables': set()
        }
        
        for node in ast.walk(tree):
            if isinstance(node, ast.FunctionDef):
                definitions['functions'].add(node.name)
            elif isinstance(node, ast.ClassDef):
                definitions['classes'].add(node.name)
            elif isinstance(node, ast.Assign):
                for target in node.targets:
                    if isinstance(target, ast.Name):
                        definitions['variables'].add(target.id)
        
        return definitions
    
    def _extract_imports(self, tree):
        """Extract import statements from AST"""
        imports = defaultdict(dict)
        
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    module_name = alias.name
                    import_alias = alias.asname if alias.asname else alias.name
                    imports[module_name]['alias'] = import_alias
                    imports[module_name]['type'] = 'module'
            
            elif isinstance(node, ast.ImportFrom):
                module_name = node.module if node.module else ''
                imported_items = []
                
                for alias in node.names:
                    item_name = alias.name
                    item_alias = alias.asname if alias.asname else alias.name
                    imported_items.append((item_name, item_alias))
                
                imports[module_name]['items'] = imported_items
                imports[module_name]['type'] = 'from'
                imports[module_name]['level'] = node.level
        
        return dict(imports)
    
    def _analyze_file(self, file_path, tree, file_definitions, file_imports):
        """Analyze a file for undefined names and import issues"""
        # Check for undefined names
        for node in ast.walk(tree):
            if isinstance(node, ast.Name) and isinstance(node.ctx, ast.Load):
                # Skip common built-in names
                if node.id in ['self', 'cls', 'super', '__name__', '__file__', '__init__', '__main__']:
                    continue
                
                # Check if it's a built-in
                if node.id in dir(__builtins__):
                    continue
                
                # Check local definitions
                if (node.id in file_definitions.get('functions', set()) or 
                    node.id in file_definitions.get('classes', set()) or 
                    node.id in file_definitions.get('variables', set())):
                    continue
                
                # Check imports
                found_in_imports = False
                for module, import_info in file_imports.items():
                    if import_info.get('type') == 'module' and import_info.get('alias') == node.id:
                        # Check if module exists
                        if not self._module_exists(module):
                            error_msg = f"Module '{module}' not found"
                            self.errors.append(f"{file_path.name}:{node.lineno}: {error_msg}")
                            self.detailed_errors.append({
                                'file': str(file_path),
                                'line': node.lineno,
                                'type': 'missing_module',
                                'message': error_msg,
                                'code': node.id
                            })
                        found_in_imports = True
                        break
                    elif import_info.get('type') == 'from' and import_info.get('items'):
                        for item_name, item_alias in import_info['items']:
                            if item_alias == node.id:
                                found_in_imports = True
                                break
                
                if not found_in_imports:
                    # This might be a false positive, but we'll flag it as a warning
                    warning_msg = f"Potentially undefined name '{node.id}'"
                    self.warnings.append(f"{file_path.name}:{node.lineno}: {warning_msg}")
                    self.detailed_warnings.append({
                        'file': str(file_path),
                        'line': node.lineno,
                        'type': 'potentially_undefined',
                        'message': warning_msg,
                        'code': node.id
                    })
    
    def _module_exists(self, module_name):
        """Check if a module exists"""
        try:
            spec = importlib.util.find_spec(module_name)
            if spec is not None:
                return True
        except:
            pass
        
        # Check if it's a local module in the project
        module_path = self.project_path / f"{module_name.replace('.', '/')}.py"
        if module_path.exists():
            return True
        
        package_path = self.project_path / module_name.replace('.', '/') / "__init__.py"
        return package_path.exists()

