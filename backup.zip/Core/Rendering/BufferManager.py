"""
Buffer Manager for PyGenesis OpenGL Runtime
Manages VBO, VAO, and IBO creation, pooling, and cleanup
"""

from OpenGL import GL
from OpenGL.arrays import vbo
import numpy as np
from typing import Optional, Dict, Tuple, List
from Core.Debug import debug
from Core.Rendering.OpenGLRuntime import get_runtime


class BufferManager:
    """
    Manages OpenGL buffers (VBO, VAO, IBO) with pooling and automatic cleanup.
    Reduces allocation overhead by reusing buffers when possible.
    """
    
    def __init__(self):
        """Initialize the buffer manager"""
        self._vbo_pool: Dict[str, int] = {}  # identifier -> VBO ID
        self._ibo_pool: Dict[str, int] = {}  # identifier -> IBO ID
        self._vao_pool: Dict[str, int] = {}  # identifier -> VAO ID
        self._buffer_refs: Dict[str, int] = {}  # Reference counting
        self._buffer_sizes: Dict[str, int] = {}  # Track buffer sizes for pooling
        
        # VAO attribute bindings storage (for VAO recreation if needed)
        self._vao_bindings: Dict[str, Dict] = {}
        
        self.runtime = get_runtime()
    
    def create_vbo(self, data: np.ndarray, identifier: str, usage: int = GL.GL_STATIC_DRAW) -> int:
        """
        Create or reuse a Vertex Buffer Object (VBO).
        
        Args:
            data: NumPy array of vertex data (float32 or uint8)
            identifier: Unique identifier for this buffer
            usage: OpenGL usage hint (GL_STATIC_DRAW, GL_DYNAMIC_DRAW, etc.)
            
        Returns:
            OpenGL buffer ID
        """
        if not self.runtime.is_current():
            self.runtime.make_current()
        
        data_size = data.nbytes
        
        # Check if we can reuse existing buffer
        if identifier in self._vbo_pool:
            existing_size = self._buffer_sizes.get(identifier, 0)
            if existing_size >= data_size:
                # Reuse existing buffer
                vbo_id = self._vbo_pool[identifier]
                GL.glBindBuffer(GL.GL_ARRAY_BUFFER, vbo_id)
                GL.glBufferSubData(GL.GL_ARRAY_BUFFER, 0, data_size, data)
                GL.glBindBuffer(GL.GL_ARRAY_BUFFER, 0)
                self._buffer_refs[identifier] = self._buffer_refs.get(identifier, 0) + 1
                debug(f"Reusing VBO '{identifier}' (size: {data_size} bytes)")
                return vbo_id
        
        # Create new buffer
        vbo_id = GL.glGenBuffers(1)
        GL.glBindBuffer(GL.GL_ARRAY_BUFFER, vbo_id)
        GL.glBufferData(GL.GL_ARRAY_BUFFER, data_size, data, usage)
        GL.glBindBuffer(GL.GL_ARRAY_BUFFER, 0)
        
        # Register buffer
        self._vbo_pool[identifier] = vbo_id
        self._buffer_sizes[identifier] = data_size
        self._buffer_refs[identifier] = self._buffer_refs.get(identifier, 0) + 1
        self.runtime.register_buffer(f"vbo_{identifier}", vbo_id)
        
        debug(f"Created VBO '{identifier}' (ID: {vbo_id}, size: {data_size} bytes)")
        return vbo_id
    
    def create_ibo(self, data: np.ndarray, identifier: str, usage: int = GL.GL_STATIC_DRAW) -> int:
        """
        Create or reuse an Index Buffer Object (IBO/EBO).
        
        Args:
            data: NumPy array of indices (uint32 or uint16)
            identifier: Unique identifier for this buffer
            usage: OpenGL usage hint
            
        Returns:
            OpenGL buffer ID
        """
        if not self.runtime.is_current():
            self.runtime.make_current()
        
        data_size = data.nbytes
        
        # Check if we can reuse existing buffer
        if identifier in self._ibo_pool:
            existing_size = self._buffer_sizes.get(identifier, 0)
            if existing_size >= data_size:
                # Reuse existing buffer
                ibo_id = self._ibo_pool[identifier]
                GL.glBindBuffer(GL.GL_ELEMENT_ARRAY_BUFFER, ibo_id)
                GL.glBufferSubData(GL.GL_ELEMENT_ARRAY_BUFFER, 0, data_size, data)
                GL.glBindBuffer(GL.GL_ELEMENT_ARRAY_BUFFER, 0)
                self._buffer_refs[identifier] = self._buffer_refs.get(identifier, 0) + 1
                debug(f"Reusing IBO '{identifier}' (size: {data_size} bytes)")
                return ibo_id
        
        # Create new buffer
        ibo_id = GL.glGenBuffers(1)
        GL.glBindBuffer(GL.GL_ELEMENT_ARRAY_BUFFER, ibo_id)
        GL.glBufferData(GL.GL_ELEMENT_ARRAY_BUFFER, data_size, data, usage)
        GL.glBindBuffer(GL.GL_ELEMENT_ARRAY_BUFFER, 0)
        
        # Register buffer
        self._ibo_pool[identifier] = ibo_id
        self._buffer_sizes[identifier] = data_size
        self._buffer_refs[identifier] = self._buffer_refs.get(identifier, 0) + 1
        self.runtime.register_buffer(f"ibo_{identifier}", ibo_id)
        
        debug(f"Created IBO '{identifier}' (ID: {ibo_id}, size: {data_size} bytes)")
        return ibo_id
    
    def create_vao(self, identifier: str, 
                   vbo_id: Optional[int] = None,
                   ibo_id: Optional[int] = None,
                   attribute_bindings: Optional[List[Dict]] = None) -> int:
        """
        Create a Vertex Array Object (VAO).
        
        Args:
            identifier: Unique identifier for this VAO
            vbo_id: Optional VBO ID to bind
            ibo_id: Optional IBO ID to bind
            attribute_bindings: List of attribute binding configs:
                [{'index': 0, 'size': 3, 'type': GL_FLOAT, 'normalized': False, 
                  'stride': 0, 'offset': 0}, ...]
        
        Returns:
            OpenGL VAO ID
        """
        if not self.runtime.is_current():
            self.runtime.make_current()
        
        # Check if VAO already exists
        if identifier in self._vao_pool:
            self._buffer_refs[identifier] = self._buffer_refs.get(identifier, 0) + 1
            return self._vao_pool[identifier]
        
        # Generate VAO
        vao_id = GL.glGenVertexArrays(1)
        GL.glBindVertexArray(vao_id)
        
        # Bind VBO if provided
        if vbo_id is not None:
            GL.glBindBuffer(GL.GL_ARRAY_BUFFER, vbo_id)
        
        # Bind IBO if provided
        if ibo_id is not None:
            GL.glBindBuffer(GL.GL_ELEMENT_ARRAY_BUFFER, ibo_id)
        
        # Set up attribute bindings
        if attribute_bindings:
            for binding in attribute_bindings:
                index = binding['index']
                size = binding.get('size', 3)
                gl_type = binding.get('type', GL.GL_FLOAT)
                normalized = binding.get('normalized', False)
                stride = binding.get('stride', 0)
                offset = binding.get('offset', 0)
                
                GL.glEnableVertexAttribArray(index)
                GL.glVertexAttribPointer(index, size, gl_type, normalized, stride, offset)
            
            # Store bindings for potential recreation
            self._vao_bindings[identifier] = {
                'vbo_id': vbo_id,
                'ibo_id': ibo_id,
                'attributes': attribute_bindings
            }
        
        GL.glBindVertexArray(0)
        GL.glBindBuffer(GL.GL_ARRAY_BUFFER, 0)
        GL.glBindBuffer(GL.GL_ELEMENT_ARRAY_BUFFER, 0)
        
        # Register VAO
        self._vao_pool[identifier] = vao_id
        self._buffer_refs[identifier] = 1
        self.runtime.register_buffer(f"vao_{identifier}", vao_id)
        
        debug(f"Created VAO '{identifier}' (ID: {vao_id})")
        return vao_id
    
    def get_vbo(self, identifier: str) -> Optional[int]:
        """Get a VBO ID by identifier"""
        return self._vbo_pool.get(identifier)
    
    def get_ibo(self, identifier: str) -> Optional[int]:
        """Get an IBO ID by identifier"""
        return self._ibo_pool.get(identifier)
    
    def get_vao(self, identifier: str) -> Optional[int]:
        """Get a VAO ID by identifier"""
        return self._vao_pool.get(identifier)
    
    def bind_vao(self, identifier: str) -> bool:
        """
        Bind a VAO by identifier.
        
        Args:
            identifier: VAO identifier
            
        Returns:
            True if VAO was found and bound, False otherwise
        """
        vao_id = self.get_vao(identifier)
        if vao_id is not None:
            GL.glBindVertexArray(vao_id)
            return True
        return False
    
    def delete_buffer(self, identifier: str):
        """
        Delete a buffer and remove it from the pool.
        Uses reference counting - buffer is only deleted when ref count reaches 0.
        
        Args:
            identifier: Buffer identifier
        """
        if identifier not in self._buffer_refs:
            return
        
        self._buffer_refs[identifier] -= 1
        
        if self._buffer_refs[identifier] <= 0:
            # Actually delete the buffer
            if not self.runtime.is_current():
                self.runtime.make_current()
            
            # Delete VBO
            if identifier in self._vbo_pool:
                vbo_id = self._vbo_pool.pop(identifier)
                GL.glDeleteBuffers([vbo_id])
                self.runtime.unregister_buffer(f"vbo_{identifier}")
                debug(f"Deleted VBO '{identifier}'")
            
            # Delete IBO
            if identifier in self._ibo_pool:
                ibo_id = self._ibo_pool.pop(identifier)
                GL.glDeleteBuffers([ibo_id])
                self.runtime.unregister_buffer(f"ibo_{identifier}")
                debug(f"Deleted IBO '{identifier}'")
            
            # Delete VAO
            if identifier in self._vao_pool:
                vao_id = self._vao_pool.pop(identifier)
                GL.glDeleteVertexArrays([vao_id])
                self.runtime.unregister_buffer(f"vao_{identifier}")
                if identifier in self._vao_bindings:
                    del self._vao_bindings[identifier]
                debug(f"Deleted VAO '{identifier}'")
            
            # Clean up tracking
            if identifier in self._buffer_sizes:
                del self._buffer_sizes[identifier]
            del self._buffer_refs[identifier]
    
    def cleanup(self):
        """Clean up all buffers (call on shutdown)"""
        if not self.runtime.is_current():
            self.runtime.make_current()
        
        # Delete all buffers
        all_identifiers = list(self._buffer_refs.keys())
        for identifier in all_identifiers:
            self._buffer_refs[identifier] = 0  # Force deletion
            self.delete_buffer(identifier)
        
        self._vbo_pool.clear()
        self._ibo_pool.clear()
        self._vao_pool.clear()
        self._buffer_refs.clear()
        self._buffer_sizes.clear()
        self._vao_bindings.clear()
        
        debug("BufferManager cleanup complete")


# Global instance
_buffer_manager: Optional[BufferManager] = None


def get_buffer_manager() -> BufferManager:
    """Get the global BufferManager instance"""
    global _buffer_manager
    if _buffer_manager is None:
        _buffer_manager = BufferManager()
    return _buffer_manager

