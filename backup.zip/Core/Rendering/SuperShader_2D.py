"""
SuperShader_2D - GameMaker-style unified 2D shader for PyGenesis
Provides comprehensive 2D rendering capabilities with blending modes and effects
"""

from OpenGL import GL
from typing import Optional, Dict
from Core.Debug import debug
from Core.Rendering.ShaderManager import get_shader_manager


class SuperShader_2D:
    """
    Unified 2D shader system similar to GameMaker's sprite rendering.
    Supports texture rendering, color modulation, transformations, and multiple blending modes.
    """
    
    # Shader identifier
    SHADER_ID = "super_shader_2d"
    
    # Blending mode constants
    BLEND_NORMAL = "normal"
    BLEND_MULTIPLY = "multiply"
    BLEND_SCREEN = "screen"
    BLEND_ADDITIVE = "additive"
    BLEND_SUBTRACT = "subtract"
    
    # Filter mode constants
    FILTER_PIXEL_PERFECT = "pixel_perfect"
    FILTER_SMOOTH = "smooth"
    
    def __init__(self):
        """Initialize the SuperShader_2D system"""
        self.shader_manager = get_shader_manager()
        self.program_id: Optional[int] = None
        self.is_compiled = False
        
        # Default settings
        self.current_blend_mode = self.BLEND_NORMAL
        self.current_filter_mode = self.FILTER_PIXEL_PERFECT
        self.show_checkerboard = True
        
        # Uniform locations (cached after compilation)
        self._uniform_locations: Dict[str, int] = {}
    
    def compile(self) -> bool:
        """
        Compile the 2D super shader.
        
        Returns:
            True if compilation successful, False otherwise
        """
        if self.is_compiled and self.program_id:
            return True
        
        vertex_shader = self._get_vertex_shader_source()
        fragment_shader = self._get_fragment_shader_source()
        
        try:
            self.program_id = self.shader_manager.compile_shader(
                vertex_shader,
                fragment_shader,
                self.SHADER_ID
            )
            
            if self.program_id:
                self._cache_uniform_locations()
                self.is_compiled = True
                debug("SuperShader_2D compiled successfully")
                return True
            else:
                debug("SuperShader_2D compilation failed - no program ID returned")
                return False
                
        except Exception as e:
            debug(f"SuperShader_2D compilation error: {e}")
            self.is_compiled = False
            return False
    
    def _get_vertex_shader_source(self) -> str:
        """Get the vertex shader source code"""
        return """#version 330 core

// Vertex attributes
in vec2 a_position;
in vec2 a_texcoord;

// Uniforms
uniform mat3 u_model_matrix;      // Transform matrix (rotation, scale, translation)
uniform mat3 u_projection_matrix; // Projection matrix (for viewport)
uniform vec2 u_flip;              // Flip flags (x, y) - (-1, 1) or (1, -1) to flip

// Outputs
out vec2 v_texcoord;
out vec4 v_color_mod;

// Pass-through color modulation (can be set per-vertex or per-instance)
uniform vec4 u_color_mod = vec4(1.0, 1.0, 1.0, 1.0);

void main() {
    // Apply flip to texture coordinates
    vec2 flipped_texcoord = a_texcoord * u_flip;
    
    // Apply model transform (transforms quad in NDC space)
    vec3 transformed_pos = u_model_matrix * vec3(a_position, 1.0);
    
    // Apply projection (maps to clip space)
    vec3 clip_pos = u_projection_matrix * transformed_pos;
    
    // Output position (w component is important for proper rendering)
    gl_Position = vec4(clip_pos.xy, 0.0, clip_pos.z);
    v_texcoord = flipped_texcoord;
    v_color_mod = u_color_mod;
}
"""
    
    def _get_fragment_shader_source(self) -> str:
        """Get the fragment shader source code"""
        return """#version 330 core

// Inputs
in vec2 v_texcoord;
in vec4 v_color_mod;

// Uniforms
uniform sampler2D u_texture;
uniform int u_blend_mode;           // 0=normal, 1=multiply, 2=screen, 3=additive, 4=subtract
uniform bool u_use_checkerboard;    // Show checkerboard background for transparency
uniform float u_checkerboard_size;  // Checkerboard tile size
uniform bool u_pixel_perfect;       // Pixel-perfect filtering (nearest vs linear)
uniform vec4 u_tint_color;          // Overall tint color
uniform float u_alpha;              // Overall alpha multiplier
uniform bool u_use_selection_mask;  // Use selection mask texture
uniform sampler2D u_selection_mask; // Selection mask texture (optional)

// Output
out vec4 fragColor;

// Checkerboard pattern function
float checkerboard_pattern(vec2 uv, float size) {
    vec2 grid = floor(uv / size);
    float pattern = mod(grid.x + grid.y, 2.0);
    return mix(0.8, 0.9, pattern); // Light gray checkerboard
}

void main() {
    // Sample texture with appropriate filtering
    vec4 tex_color = texture(u_texture, v_texcoord);
    
    // Apply color modulation
    vec4 color = tex_color * v_color_mod * u_tint_color;
    color.a *= u_alpha;
    
    // Handle transparency with checkerboard if enabled
    if (u_use_checkerboard && color.a < 1.0) {
        float checker = checkerboard_pattern(v_texcoord * 512.0, u_checkerboard_size);
        color.rgb = mix(vec3(checker), color.rgb, color.a);
        color.a = 1.0; // Opaque after compositing with checkerboard
    }
    
    // Apply selection mask if enabled
    if (u_use_selection_mask) {
        float mask = texture(u_selection_mask, v_texcoord).r;
        color.a *= mask;
    }
    
    // Apply blending mode (for compositing with background)
    // Note: Actual blending is handled by OpenGL blend state
    // This shader prepares the color, OpenGL handles the blend equation
    
    fragColor = color;
}
"""
    
    def _cache_uniform_locations(self):
        """Cache uniform locations for faster access"""
        if not self.program_id:
            return
        
        uniform_names = [
            'u_model_matrix',
            'u_projection_matrix',
            'u_flip',
            'u_color_mod',
            'u_texture',
            'u_blend_mode',
            'u_use_checkerboard',
            'u_checkerboard_size',
            'u_pixel_perfect',
            'u_tint_color',
            'u_alpha',
            'u_use_selection_mask',
            'u_selection_mask',
        ]
        
        for name in uniform_names:
            location = self.shader_manager.get_uniform_location(self.SHADER_ID, name)
            if location is not None:
                self._uniform_locations[name] = location
    
    def use(self) -> bool:
        """
        Activate this shader program.
        
        Returns:
            True if shader is active, False otherwise
        """
        if not self.is_compiled:
            if not self.compile():
                return False
        
        if self.shader_manager.use_shader(self.SHADER_ID):
            self._set_blend_state()
            return True
        
        return False
    
    def _set_blend_state(self):
        """Set OpenGL blend state based on current blend mode"""
        GL.glEnable(GL.GL_BLEND)
        
        if self.current_blend_mode == self.BLEND_NORMAL:
            GL.glBlendFunc(GL.GL_SRC_ALPHA, GL.GL_ONE_MINUS_SRC_ALPHA)
            GL.glBlendEquation(GL.GL_FUNC_ADD)
        elif self.current_blend_mode == self.BLEND_MULTIPLY:
            GL.glBlendFunc(GL.GL_DST_COLOR, GL.GL_ZERO)
            GL.glBlendEquation(GL.GL_FUNC_ADD)
        elif self.current_blend_mode == self.BLEND_SCREEN:
            GL.glBlendFunc(GL.GL_ONE, GL.GL_ONE_MINUS_SRC_COLOR)
            GL.glBlendEquation(GL.GL_FUNC_ADD)
        elif self.current_blend_mode == self.BLEND_ADDITIVE:
            GL.glBlendFunc(GL.GL_SRC_ALPHA, GL.GL_ONE)
            GL.glBlendEquation(GL.GL_FUNC_ADD)
        elif self.current_blend_mode == self.BLEND_SUBTRACT:
            GL.glBlendFunc(GL.GL_SRC_ALPHA, GL.GL_ONE)
            GL.glBlendEquation(GL.GL_FUNC_REVERSE_SUBTRACT)
    
    def set_model_matrix(self, matrix: list):
        """
        Set the model transformation matrix (3x3).
        
        Args:
            matrix: 9-element list representing a 3x3 matrix (column-major)
        """
        if 'u_model_matrix' in self._uniform_locations:
            from OpenGL.arrays import ArrayDatatype
            import numpy as np
            
            matrix_array = np.array(matrix, dtype='f4').reshape(3, 3)
            GL.glUniformMatrix3fv(self._uniform_locations['u_model_matrix'], 1, GL.GL_FALSE, matrix_array)
    
    def set_projection_matrix(self, matrix: list):
        """
        Set the projection matrix (3x3).
        
        Args:
            matrix: 9-element list representing a 3x3 matrix (column-major)
        """
        if 'u_projection_matrix' in self._uniform_locations:
            import numpy as np
            
            matrix_array = np.array(matrix, dtype='f4').reshape(3, 3)
            GL.glUniformMatrix3fv(self._uniform_locations['u_projection_matrix'], 1, GL.GL_FALSE, matrix_array)
    
    def set_texture(self, texture_id: int, unit: int = 0):
        """
        Bind a texture to the shader.
        
        Args:
            texture_id: OpenGL texture ID
            unit: Texture unit index (default 0)
        """
        GL.glActiveTexture(GL.GL_TEXTURE0 + unit)
        GL.glBindTexture(GL.GL_TEXTURE_2D, texture_id)
        
        if 'u_texture' in self._uniform_locations:
            GL.glUniform1i(self._uniform_locations['u_texture'], unit)
    
    def set_color_modulation(self, r: float, g: float, b: float, a: float = 1.0):
        """
        Set color modulation (multiplies with texture color).
        
        Args:
            r: Red component (0.0 to 1.0)
            g: Green component (0.0 to 1.0)
            b: Blue component (0.0 to 1.0)
            a: Alpha component (0.0 to 1.0)
        """
        if 'u_color_mod' in self._uniform_locations:
            GL.glUniform4f(self._uniform_locations['u_color_mod'], r, g, b, a)
    
    def set_flip(self, flip_x: bool = False, flip_y: bool = False):
        """
        Set texture flip flags.
        
        Args:
            flip_x: Flip horizontally
            flip_y: Flip vertically
        """
        if 'u_flip' in self._uniform_locations:
            flip_x_val = -1.0 if flip_x else 1.0
            flip_y_val = -1.0 if flip_y else 1.0
            GL.glUniform2f(self._uniform_locations['u_flip'], flip_x_val, flip_y_val)
    
    def set_blend_mode(self, mode: str):
        """
        Set blending mode.
        
        Args:
            mode: One of BLEND_NORMAL, BLEND_MULTIPLY, BLEND_SCREEN, BLEND_ADDITIVE, BLEND_SUBTRACT
        """
        self.current_blend_mode = mode
        
        # Set blend mode uniform (0=normal, 1=multiply, 2=screen, 3=additive, 4=subtract)
        mode_map = {
            self.BLEND_NORMAL: 0,
            self.BLEND_MULTIPLY: 1,
            self.BLEND_SCREEN: 2,
            self.BLEND_ADDITIVE: 3,
            self.BLEND_SUBTRACT: 4,
        }
        
        if 'u_blend_mode' in self._uniform_locations:
            GL.glUniform1i(self._uniform_locations['u_blend_mode'], mode_map.get(mode, 0))
        
        # Update blend state if shader is active
        if self.shader_manager.get_shader(self.SHADER_ID) == self.program_id:
            self._set_blend_state()
    
    def set_checkerboard(self, enabled: bool, size: float = 16.0):
        """
        Enable/disable checkerboard background for transparency.
        
        Args:
            enabled: Show checkerboard background
            size: Checkerboard tile size in pixels
        """
        self.show_checkerboard = enabled
        
        if 'u_use_checkerboard' in self._uniform_locations:
            GL.glUniform1i(self._uniform_locations['u_use_checkerboard'], 1 if enabled else 0)
        
        if 'u_checkerboard_size' in self._uniform_locations:
            GL.glUniform1f(self._uniform_locations['u_checkerboard_size'], size)
    
    def set_pixel_perfect(self, enabled: bool):
        """
        Set pixel-perfect filtering mode.
        
        Args:
            enabled: True for nearest-neighbor (pixel-perfect), False for linear (smooth)
        """
        self.current_filter_mode = self.FILTER_PIXEL_PERFECT if enabled else self.FILTER_SMOOTH
        
        # Note: Filtering is set on the texture itself, not via uniform
        # This method is here for API consistency
        if 'u_pixel_perfect' in self._uniform_locations:
            GL.glUniform1i(self._uniform_locations['u_pixel_perfect'], 1 if enabled else 0)
    
    def set_alpha(self, alpha: float):
        """
        Set overall alpha multiplier.
        
        Args:
            alpha: Alpha value (0.0 to 1.0)
        """
        if 'u_alpha' in self._uniform_locations:
            GL.glUniform1f(self._uniform_locations['u_alpha'], alpha)
    
    def set_selection_mask(self, texture_id: Optional[int] = None):
        """
        Enable/disable selection mask rendering.
        
        Args:
            texture_id: Selection mask texture ID, or None to disable
        """
        if 'u_use_selection_mask' in self._uniform_locations:
            if texture_id is not None:
                GL.glUniform1i(self._uniform_locations['u_use_selection_mask'], 1)
                GL.glActiveTexture(GL.GL_TEXTURE1)
                GL.glBindTexture(GL.GL_TEXTURE_2D, texture_id)
                if 'u_selection_mask' in self._uniform_locations:
                    GL.glUniform1i(self._uniform_locations['u_selection_mask'], 1)
            else:
                GL.glUniform1i(self._uniform_locations['u_use_selection_mask'], 0)


# Global instance
_super_shader_2d: Optional[SuperShader_2D] = None


def get_super_shader_2d() -> SuperShader_2D:
    """Get the global SuperShader_2D instance"""
    global _super_shader_2d
    if _super_shader_2d is None:
        _super_shader_2d = SuperShader_2D()
    return _super_shader_2d

