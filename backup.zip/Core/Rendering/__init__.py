"""
3D Rendering Runtime for PyGenesis
Unified OpenGL rendering system shared across all editors

Phase 1 Complete: Core runtime managers
Phase 2 Complete: SuperShader_2D and Canvas_2D
Next: SuperShader_3D, Viewport_3D
"""

# Core runtime managers (Phase 1 - Complete)
from .OpenGLRuntime import OpenGLRuntime, get_runtime
from .ShaderManager import ShaderManager, get_shader_manager
from .BufferManager import BufferManager, get_buffer_manager
from .TextureManager import TextureManager, get_texture_manager

# 2D rendering components (Phase 2 - Complete)
from .SuperShader_2D import SuperShader_2D, get_super_shader_2d
from .Canvas_2D import Canvas_2D

__all__ = [
    # Unified runtime (Phase 1)
    'OpenGLRuntime',
    'get_runtime',
    'ShaderManager',
    'get_shader_manager',
    'BufferManager',
    'get_buffer_manager',
    'TextureManager',
    'get_texture_manager',
    
    # 2D rendering (Phase 2)
    'SuperShader_2D',
    'get_super_shader_2d',
    'Canvas_2D',
]

