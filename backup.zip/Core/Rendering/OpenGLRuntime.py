"""
OpenGL Runtime Manager for PyGenesis
Singleton class managing OpenGL context lifecycle and shared resources
"""

from PySide6.QtGui import QSurfaceFormat
from PySide6.QtOpenGLWidgets import QOpenGLWidget
from OpenGL import GL
import numpy as np
from typing import Optional, Dict, Any
from Core.Debug import debug


class OpenGLRuntime:
    """
    Singleton OpenGL runtime manager.
    Handles context creation, resource sharing, and cross-editor synchronization.
    """
    
    _instance: Optional['OpenGLRuntime'] = None
    _initialized = False
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(OpenGLRuntime, cls).__new__(cls)
            cls._instance._initialized = False
        return cls._instance
    
    def __init__(self):
        """Initialize the OpenGL runtime (singleton pattern)"""
        if self._initialized:
            return
        
        self._initialized = True
        self.context_widget: Optional[QOpenGLWidget] = None
        self.format: Optional[QSurfaceFormat] = None
        
        # Shared resource pools
        self._texture_cache: Dict[str, int] = {}  # path -> texture_id
        self._buffer_pool: Dict[str, int] = {}  # identifier -> buffer_id
        self._resource_refs: Dict[str, int] = {}  # Resource reference counting
        
        # State tracking
        self.is_initialized = False
        self.max_texture_size = 0
        self.max_vertex_attributes = 0
        self.gl_version = ""
        self.gl_vendor = ""
        self.gl_renderer = ""
        
        debug("OpenGLRuntime singleton created (not yet initialized)")
    
    def initialize_context(self, widget: QOpenGLWidget):
        """
        Initialize the OpenGL runtime with a QOpenGLWidget.
        This should be called once by the first QOpenGLWidget created.
        
        Args:
            widget: QOpenGLWidget instance that provides the OpenGL context
        """
        if self.is_initialized:
            debug("OpenGLRuntime: Context already initialized.")
            return
        
        self.context_widget = widget
        widget.makeCurrent()
        
        # Get format from widget
        context = widget.context()
        if context:
            self.format = context.format()
        
        # Query OpenGL capabilities
        self._query_gl_info()
        
        # Set default OpenGL state
        self._setup_default_state()
        
        self.is_initialized = True
        debug(f"OpenGLRuntime initialized - Version: {self.gl_version}, Vendor: {self.gl_vendor}")
        debug(f"Max texture size: {self.max_texture_size}x{self.max_texture_size}")
        
        widget.doneCurrent()
    
    def _query_gl_info(self):
        """Query OpenGL capabilities and information"""
        try:
            self.gl_version = GL.glGetString(GL.GL_VERSION).decode('utf-8')
            self.gl_vendor = GL.glGetString(GL.GL_VENDOR).decode('utf-8')
            self.gl_renderer = GL.glGetString(GL.GL_RENDERER).decode('utf-8')
            
            # Query max texture size
            max_size = GL.glGetIntegerv(GL.GL_MAX_TEXTURE_SIZE)
            self.max_texture_size = max_size[0] if isinstance(max_size, (list, tuple)) else max_size
            
            # Query max vertex attributes
            max_attrs = GL.glGetIntegerv(GL.GL_MAX_VERTEX_ATTRIBS)
            self.max_vertex_attributes = max_attrs[0] if isinstance(max_attrs, (list, tuple)) else max_attrs
            
        except Exception as e:
            debug(f"Error querying OpenGL info: {e}")
            # Set defaults on error
            self.max_texture_size = 4096
            self.max_vertex_attributes = 16
    
    def _setup_default_state(self):
        """Set up default OpenGL state"""
        if not self.context_widget:
            return
        
        try:
            # Enable depth testing by default
            GL.glEnable(GL.GL_DEPTH_TEST)
            GL.glDepthFunc(GL.GL_LESS)
            
            # Enable blending for transparency
            GL.glEnable(GL.GL_BLEND)
            GL.glBlendFunc(GL.GL_SRC_ALPHA, GL.GL_ONE_MINUS_SRC_ALPHA)
            
            # Set clear color to dark gray
            GL.glClearColor(0.2, 0.2, 0.25, 1.0)
            
            # Disable face culling by default (let shaders/apps decide)
            GL.glDisable(GL.GL_CULL_FACE)
            
        except Exception as e:
            debug(f"Error setting up default OpenGL state: {e}")
    
    def make_current(self) -> bool:
        """
        Make the OpenGL context current for this thread.
        
        Returns:
            True if context was made current, False otherwise
        """
        if not self.context_widget:
            debug("Warning: Cannot make context current - context widget not initialized")
            return False
        
        self.context_widget.makeCurrent()
        return True
    
    def is_current(self) -> bool:
        """Check if the OpenGL context is currently active"""
        if not self.context_widget:
            return False
        context = self.context_widget.context()
        return context and context.isCurrent()
    
    def done_current(self):
        """Release the OpenGL context from this thread"""
        if self.context_widget:
            self.context_widget.doneCurrent()
    
    def get_context_widget(self) -> Optional[QOpenGLWidget]:
        """Get the context widget"""
        return self.context_widget
    
    def register_texture(self, identifier: str, texture_id: int):
        """
        Register a texture in the shared cache.
        
        Args:
            identifier: Unique identifier for the texture (e.g., file path or resource ID)
            texture_id: OpenGL texture ID
        """
        self._texture_cache[identifier] = texture_id
        self._resource_refs[identifier] = self._resource_refs.get(identifier, 0) + 1
        debug(f"Registered texture '{identifier}' with ID {texture_id}")
    
    def get_texture(self, identifier: str) -> Optional[int]:
        """
        Get a texture ID from the cache.
        
        Args:
            identifier: Unique identifier for the texture
            
        Returns:
            Texture ID if found, None otherwise
        """
        return self._texture_cache.get(identifier)
    
    def unregister_texture(self, identifier: str):
        """
        Unregister a texture from the cache (decrements reference count).
        
        Args:
            identifier: Unique identifier for the texture
        """
        if identifier in self._resource_refs:
            self._resource_refs[identifier] -= 1
            if self._resource_refs[identifier] <= 0:
                # Texture no longer referenced, can be deleted
                if identifier in self._texture_cache:
                    texture_id = self._texture_cache.pop(identifier)
                    # Note: Actual texture deletion should be handled by TextureManager
                    debug(f"Unregistered texture '{identifier}' (ID {texture_id})")
                del self._resource_refs[identifier]
    
    def register_buffer(self, identifier: str, buffer_id: int):
        """
        Register a buffer (VBO/IBO) in the shared pool.
        
        Args:
            identifier: Unique identifier for the buffer
            buffer_id: OpenGL buffer ID
        """
        self._buffer_pool[identifier] = buffer_id
        self._resource_refs[identifier] = self._resource_refs.get(identifier, 0) + 1
    
    def get_buffer(self, identifier: str) -> Optional[int]:
        """
        Get a buffer ID from the pool.
        
        Args:
            identifier: Unique identifier for the buffer
            
        Returns:
            Buffer ID if found, None otherwise
        """
        return self._buffer_pool.get(identifier)
    
    def unregister_buffer(self, identifier: str):
        """Unregister a buffer from the pool"""
        if identifier in self._resource_refs:
            self._resource_refs[identifier] -= 1
            if self._resource_refs[identifier] <= 0:
                if identifier in self._buffer_pool:
                    buffer_id = self._buffer_pool.pop(identifier)
                    debug(f"Unregistered buffer '{identifier}' (ID {buffer_id})")
                del self._resource_refs[identifier]
    
    def cleanup(self):
        """
        Clean up all resources and release the context.
        Should be called when shutting down the application.
        """
        if not self.is_initialized:
            return
        
        debug("Cleaning up OpenGLRuntime...")
        
        # Clear caches
        self._texture_cache.clear()
        self._buffer_pool.clear()
        self._resource_refs.clear()
        
        # Release context
        if self.context:
            self.context.doneCurrent()
        
        self.is_initialized = False
        debug("OpenGLRuntime cleanup complete")
    
    def get_capabilities(self) -> Dict[str, Any]:
        """
        Get OpenGL capabilities information.
        
        Returns:
            Dictionary with capability information
        """
        return {
            'version': self.gl_version,
            'vendor': self.gl_vendor,
            'renderer': self.gl_renderer,
            'max_texture_size': self.max_texture_size,
            'max_vertex_attributes': self.max_vertex_attributes,
            'is_initialized': self.is_initialized
        }


def get_runtime() -> OpenGLRuntime:
    """
    Get the singleton OpenGLRuntime instance.
    
    Returns:
        OpenGLRuntime singleton instance
    """
    return OpenGLRuntime()

