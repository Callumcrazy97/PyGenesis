"""
Canvas_2D - GPU-accelerated 2D canvas widget for PyGenesis
Replaces QPainter-based canvas with OpenGL rendering for better performance
"""

from PySide6.QtOpenGLWidgets import QOpenGLWidget
from PySide6.QtWidgets import QWidget
from PySide6.QtCore import Qt, QPoint, QRect, Signal, QTimer
from PySide6.QtGui import QSurfaceFormat
from OpenGL import GL
import numpy as np
from typing import Optional, List, Tuple

from Core.Debug import debug
from Core.Rendering.OpenGLRuntime import get_runtime
from Core.Rendering.TextureManager import get_texture_manager
from Core.Rendering.BufferManager import get_buffer_manager
from Core.Rendering.SuperShader_2D import get_super_shader_2d


class Canvas_2D(QOpenGLWidget):
    """
    GPU-accelerated 2D canvas widget using OpenGL.
    Provides texture-based image rendering with zoom, pan, and dirty rectangle updates.
    """
    
    # Signals
    mouse_position_changed = Signal(int, int)  # Emits image coordinates (x, y)
    
    def __init__(self, parent: Optional[QWidget] = None):
        """Initialize the GPU-accelerated 2D canvas"""
        # Set OpenGL format
        format_obj = QSurfaceFormat()
        format_obj.setVersion(3, 3)  # OpenGL 3.3 Core Profile
        format_obj.setProfile(QSurfaceFormat.CoreProfile)
        format_obj.setSamples(4)  # 4x MSAA
        QSurfaceFormat.setDefaultFormat(format_obj)
        
        super().__init__(parent)
        
        # Runtime managers
        self.runtime = get_runtime()
        self.texture_manager = get_texture_manager()
        self.buffer_manager = get_buffer_manager()
        self.shader = get_super_shader_2d()
        
        # Canvas state
        self.zoom_level = 1.0
        self.min_zoom = 0.1
        self.max_zoom = 10.0
        self.zoom_step = 0.25
        self.pan_offset = QPoint(0, 0)
        self.panning = False
        self.last_pan_pos = None
        
        # Image state
        self.current_image: Optional[np.ndarray] = None
        self.image_texture_id: Optional[int] = None
        self.image_width = 0
        self.image_height = 0
        
        # Selection mask
        self.selection_mask: Optional[np.ndarray] = None
        self.selection_texture_id: Optional[int] = None
        
        # Dirty rectangle tracking
        self.dirty_rectangles: List[QRect] = []
        self.full_redraw = True
        
        # Display settings
        self.pixel_perfect = True
        self.show_checkerboard = True
        self.checkerboard_size = 16.0
        
        # Mouse tracking
        self.setMouseTracking(True)
        self.setFocusPolicy(Qt.StrongFocus)
        
        # Buffers for rendering
        self.quad_vbo_id: Optional[int] = None
        self.quad_vao_id: Optional[int] = None
        self._buffers_created = False
        
        # Animation timer for updates
        self.update_timer = QTimer()
        self.update_timer.timeout.connect(self.update)
        self.update_timer.setSingleShot(False)
        
        # Update throttling for GPU canvas (limit to 60 FPS)
        self._throttle_timer = QTimer()
        self._throttle_timer.setSingleShot(True)
        self._throttle_timer.timeout.connect(self._do_throttled_update)
        self._throttle_interval_ms = 16  # ~60 FPS
        self._pending_update = False
    
    def initializeGL(self):
        """Initialize OpenGL resources"""
        # Initialize OpenGL runtime with this widget
        self.runtime.initialize_context(self)
        
        # Make context current
        self.runtime.make_current()
        
        # Compile shader
        if not self.shader.compile():
            debug("Warning: Failed to compile SuperShader_2D")
        
        # Create rendering buffers
        self._create_quad_buffers()
        
        debug("Canvas_2D initialized")
    
    def resizeGL(self, width: int, height: int):
        """Handle viewport resize"""
        GL.glViewport(0, 0, width, height)
        
        # Update projection matrix for 2D rendering
        self._update_projection_matrix()
    
    def paintGL(self):
        """Render the canvas"""
        if not self.runtime.is_current():
            self.runtime.make_current()
        
        # Clear screen
        GL.glClearColor(0.2, 0.2, 0.25, 1.0)
        GL.glClear(GL.GL_COLOR_BUFFER_BIT)
        
        # If no image, just clear
        if self.current_image is None or self.image_texture_id is None:
            return
        
        # Use shader
        if not self.shader.use():
            return
        
        # Set shader parameters
        self.shader.set_checkerboard(self.show_checkerboard, self.checkerboard_size)
        self.shader.set_pixel_perfect(self.pixel_perfect)
        
        # Set selection mask if available
        if self.selection_texture_id is not None:
            self.shader.set_selection_mask(self.selection_texture_id)
        else:
            self.shader.set_selection_mask(None)
        
        # Bind texture
        self.shader.set_texture(self.image_texture_id, 0)
        
        # Update model matrix for zoom/pan
        self._update_model_matrix()
        
        # Bind VAO and draw quad
        if self.quad_vao_id is not None:
            GL.glBindVertexArray(self.quad_vao_id)
            GL.glDrawElements(GL.GL_TRIANGLES, 6, GL.GL_UNSIGNED_INT, None)
            GL.glBindVertexArray(0)
        
        # Clear dirty rectangles after render
        self.dirty_rectangles.clear()
        self.full_redraw = False
    
    def _create_quad_buffers(self):
        """Create vertex buffers for a full-screen quad"""
        if self._buffers_created:
            return
        
        if not self.runtime.is_current():
            self.runtime.make_current()
        
        # Full-screen quad vertices (position, texture coords)
        # Positions: (-1, -1) to (1, 1) in normalized device coordinates
        # Texture coords: (0, 0) to (1, 1)
        vertices = np.array([
            # Position (x, y), TexCoord (u, v)
            -1.0, -1.0,  0.0, 1.0,  # Bottom-left
             1.0, -1.0,  1.0, 1.0,  # Bottom-right
             1.0,  1.0,  1.0, 0.0,  # Top-right
            -1.0,  1.0,  0.0, 0.0,  # Top-left
        ], dtype='f4')
        
        # Indices for two triangles
        indices = np.array([
            0, 1, 2,  # First triangle
            2, 3, 0,  # Second triangle
        ], dtype='u4')
        
        # Create VBO
        vbo_id = self.buffer_manager.create_vbo(
            vertices,
            "canvas_2d_quad_vbo",
            GL.GL_STATIC_DRAW
        )
        
        # Create IBO
        ibo_id = self.buffer_manager.create_ibo(
            indices,
            "canvas_2d_quad_ibo",
            GL.GL_STATIC_DRAW
        )
        
        # Create VAO with attribute bindings
        # Shader expects: a_position (location 0) and a_texcoord (location 1)
        attribute_bindings = [
            {
                'index': 0,  # a_position in shader
                'size': 2,
                'type': GL.GL_FLOAT,
                'normalized': False,
                'stride': 4 * 4,  # 4 floats per vertex (16 bytes)
                'offset': 0
            },
            {
                'index': 1,  # a_texcoord in shader
                'size': 2,
                'type': GL.GL_FLOAT,
                'normalized': False,
                'stride': 4 * 4,  # 4 floats per vertex (16 bytes)
                'offset': 2 * 4  # Offset by 2 floats (8 bytes)
            }
        ]
        
        vao_id = self.buffer_manager.create_vao(
            "canvas_2d_quad_vao",
            vbo_id,
            ibo_id,
            attribute_bindings
        )
        
        self.quad_vbo_id = vbo_id
        self.quad_vao_id = vao_id
        self._buffers_created = True
        
        debug("Canvas_2D quad buffers created")
    
    def _update_projection_matrix(self):
        """Update the projection matrix for 2D rendering"""
        if not self.shader.is_compiled:
            return
        
        width = self.width()
        height = self.height()
        
        if width <= 0 or height <= 0:
            return
        
        # Orthographic projection matrix (3x3 for 2D)
        # Maps from screen pixel coordinates to normalized device coordinates (-1 to 1)
        # Simple orthographic projection: maps (0,0) at top-left to (-1,-1) at bottom-left
        # and (width, height) to (1, 1) at top-right
        projection = [
            2.0 / width,  0.0,           0.0,
            0.0,          -2.0 / height, 0.0,  # Negative Y to flip (screen Y down vs OpenGL Y up)
            -1.0,          1.0,           1.0   # Translate to move origin to top-left
        ]
        
        self.shader.set_projection_matrix(projection)
    
    def _update_model_matrix(self):
        """Update the model matrix for zoom and pan"""
        if not self.shader.is_compiled:
            return
        
        if self.current_image is None:
            return
        
        width = self.width()
        height = self.height()
        
        if width <= 0 or height <= 0:
            return
        
        # Calculate scale to fit image in viewport
        img_w = self.image_width
        img_h = self.image_height
        
        base_scale_x = width / img_w
        base_scale_y = height / img_h
        base_scale = min(base_scale_x, base_scale_y) * 0.95  # Slight padding
        
        # Apply zoom
        scale = base_scale * self.zoom_level
        
        # Calculate scaled dimensions
        scaled_w = img_w * scale
        scaled_h = img_h * scale
        
        # Calculate center position (in screen pixel coordinates)
        center_x = width / 2.0
        center_y = height / 2.0
        
        # Calculate translation (centering + pan)
        tx = center_x + self.pan_offset.x()
        ty = center_y + self.pan_offset.y()
        
        # Model matrix transforms the quad from NDC space (-1 to 1) to screen space
        # The quad is 2x2 in NDC, we want to scale it to image size and position it
        
        # Scale factor: convert from NDC size (2.0) to pixel size
        scale_x = scaled_w / 2.0
        scale_y = scaled_h / 2.0
        
        # Translation: move from center of screen (0,0 in NDC = center) to target position
        # Projection maps screen coords, so translation is in screen space
        tx_screen = tx - center_x  # Offset from center
        ty_screen = ty - center_y
        
        # Create 3x3 transformation matrix (column-major)
        # Order: Scale, then Translate
        # Matrix format: [m00, m10, m20, m01, m11, m21, m02, m12, m22]
        model_matrix = [
            scale_x,  0.0,      0.0,
            0.0,      scale_y,  0.0,
            tx_screen, -ty_screen, 1.0  # Negative Y because screen Y is flipped
        ]
        
        self.shader.set_model_matrix(model_matrix)
    
    def set_image(self, image: Optional[np.ndarray]):
        """
        Set the image to display.
        
        Args:
            image: NumPy array (RGBA, RGB, or grayscale), or None to clear
        """
        if image is None:
            self.current_image = None
            self.image_texture_id = None
            self.image_width = 0
            self.image_height = 0
            self.update()
            return
        
        # Store image
        self.current_image = image
        h, w = image.shape[:2]
        self.image_width = w
        self.image_height = h
        
        # Upload to GPU texture
        if not self.runtime.is_current():
            self.runtime.make_current()
        
        # Create or update texture
        texture_id = self.texture_manager.create_texture_from_array(
            image,
            "canvas_2d_image",
            generate_mipmaps=not self.pixel_perfect,
            filter_min=GL.GL_NEAREST if self.pixel_perfect else GL.GL_LINEAR,
            filter_mag=GL.GL_NEAREST if self.pixel_perfect else GL.GL_LINEAR
        )
        
        self.image_texture_id = texture_id
        
        # Mark for full redraw
        self.full_redraw = True
        self.update()
    
    def set_selection_mask(self, mask: Optional[np.ndarray]):
        """
        Set the selection mask for rendering.
        
        Args:
            mask: NumPy array (binary mask), or None to disable
        """
        self.selection_mask = mask
        
        if mask is None:
            if self.selection_texture_id is not None:
                self.texture_manager.delete_texture("canvas_2d_selection")
                self.selection_texture_id = None
            self.update()
            return
        
        # Upload mask to GPU texture
        if not self.runtime.is_current():
            self.runtime.make_current()
        
        texture_id = self.texture_manager.create_texture_from_array(
            mask,
            "canvas_2d_selection",
            generate_mipmaps=False,
            filter_min=GL.GL_NEAREST,
            filter_mag=GL.GL_NEAREST
        )
        
        self.selection_texture_id = texture_id
        self.update()
    
    def mark_dirty_rectangle(self, x: int, y: int, width: int, height: int):
        """
        Mark a region as dirty (needs update).
        
        Args:
            x, y: Top-left corner in image coordinates
            width, height: Size of dirty region
        """
        rect = QRect(x, y, width, height)
        self.dirty_rectangles.append(rect)
        self.update()
    
    def update_partial_texture(self, image: np.ndarray, dirty_rect: QRect):
        """
        Update a partial region of the texture using glTexSubImage2D.
        More efficient than full texture upload for small changes.
        
        Args:
            image: Full image array (RGBA)
            dirty_rect: QRect in image coordinates specifying the dirty region
        """
        if self.image_texture_id is None or image is None:
            return
        
        if not self.runtime.is_current():
            self.runtime.make_current()
        
        # Clamp dirty rectangle to image bounds
        x = max(0, min(self.image_width - 1, dirty_rect.x()))
        y = max(0, min(self.image_height - 1, dirty_rect.y()))
        w = max(1, min(dirty_rect.width(), self.image_width - x))
        h = max(1, min(dirty_rect.height(), self.image_height - y))
        
        # Extract the dirty region from the image
        dirty_region = image[y:y+h, x:x+w]
        
        if dirty_region.size == 0:
            return
        
        # Ensure contiguous array
        if not dirty_region.flags['C_CONTIGUOUS']:
            dirty_region = np.ascontiguousarray(dirty_region)
        
        if dirty_region.dtype != np.uint8:
            dirty_region = dirty_region.astype(np.uint8)
        
        # Determine format
        if len(dirty_region.shape) == 3:
            channels = dirty_region.shape[2]
            if channels == 4:
                format_type = GL.GL_RGBA
                pixel_type = GL.GL_UNSIGNED_BYTE
            elif channels == 3:
                format_type = GL.GL_RGB
                pixel_type = GL.GL_UNSIGNED_BYTE
            else:
                return  # Unsupported format
        else:
            return  # Unsupported format
        
        # Update texture sub-region
        GL.glBindTexture(GL.GL_TEXTURE_2D, self.image_texture_id)
        GL.glTexSubImage2D(
            GL.GL_TEXTURE_2D, 0,
            x, y,  # Offset in texture
            w, h,  # Size of sub-region
            format_type, pixel_type,
            dirty_region
        )
        GL.glBindTexture(GL.GL_TEXTURE_2D, 0)
        
        # Regenerate mipmaps if not pixel-perfect
        if not self.pixel_perfect:
            GL.glBindTexture(GL.GL_TEXTURE_2D, self.image_texture_id)
            GL.glGenerateMipmap(GL.GL_TEXTURE_2D)
            GL.glBindTexture(GL.GL_TEXTURE_2D, 0)
    
    def _do_throttled_update(self):
        """Perform the throttled update"""
        if self._pending_update:
            self._pending_update = False
            super().update()
    
    def update(self, rect=None):
        """
        Throttled update - limits updates to ~60 FPS to prevent excessive repaints.
        """
        self._pending_update = True
        if not self._throttle_timer.isActive():
            # First update - do it immediately
            self._pending_update = False
            if rect:
                super().update(rect)
            else:
                super().update()
            # Start throttle timer
            self._throttle_timer.start(self._throttle_interval_ms)
        # Subsequent updates within throttle interval will be batched
    
    def set_zoom(self, zoom: float):
        """Set zoom level"""
        self.zoom_level = max(self.min_zoom, min(self.max_zoom, zoom))
        self._update_model_matrix()
        self.update()
    
    def zoom_in(self):
        """Zoom in by one step"""
        self.set_zoom(self.zoom_level + self.zoom_step)
    
    def zoom_out(self):
        """Zoom out by one step"""
        self.set_zoom(self.zoom_level - self.zoom_step)
    
    def reset_zoom(self):
        """Reset zoom to fit image"""
        self.zoom_level = 1.0
        self.pan_offset = QPoint(0, 0)
        self._update_model_matrix()
        self.update()
    
    def set_pixel_perfect(self, enabled: bool):
        """Set pixel-perfect filtering mode"""
        self.pixel_perfect = enabled
        
        # Update texture filtering
        if self.image_texture_id is not None:
            if not self.runtime.is_current():
                self.runtime.make_current()
            
            GL.glBindTexture(GL.GL_TEXTURE_2D, self.image_texture_id)
            
            if enabled:
                GL.glTexParameteri(GL.GL_TEXTURE_2D, GL.GL_TEXTURE_MIN_FILTER, GL.GL_NEAREST)
                GL.glTexParameteri(GL.GL_TEXTURE_2D, GL.GL_TEXTURE_MAG_FILTER, GL.GL_NEAREST)
            else:
                GL.glTexParameteri(GL.GL_TEXTURE_2D, GL.GL_TEXTURE_MIN_FILTER, GL.GL_LINEAR_MIPMAP_LINEAR)
                GL.glTexParameteri(GL.GL_TEXTURE_2D, GL.GL_TEXTURE_MAG_FILTER, GL.GL_LINEAR)
            
            GL.glBindTexture(GL.GL_TEXTURE_2D, 0)
        
        self.update()
    
    def set_checkerboard(self, enabled: bool, size: float = 16.0):
        """Enable/disable checkerboard background"""
        self.show_checkerboard = enabled
        self.checkerboard_size = size
        self.update()
    
    def widget_to_image_coords(self, widget_x: int, widget_y: int) -> Tuple[int, int]:
        """
        Convert widget coordinates to image coordinates.
        
        Args:
            widget_x, widget_y: Widget pixel coordinates
            
        Returns:
            Image coordinates (x, y)
        """
        if self.current_image is None:
            return 0, 0
        
        width = self.width()
        height = self.height()
        
        if width <= 0 or height <= 0:
            return 0, 0
        
        # Calculate scale
        img_w = self.image_width
        img_h = self.image_height
        
        base_scale_x = width / img_w
        base_scale_y = height / img_h
        base_scale = min(base_scale_x, base_scale_y)
        scale = base_scale * self.zoom_level
        
        # Calculate image position
        scaled_w = img_w * scale
        scaled_h = img_h * scale
        
        offset_x = (width - scaled_w) / 2.0 + self.pan_offset.x()
        offset_y = (height - scaled_h) / 2.0 + self.pan_offset.y()
        
        # Convert to image coordinates
        x = int((widget_x - offset_x) / scale)
        y = int((widget_y - offset_y) / scale)
        
        # Clamp to image bounds
        x = max(0, min(img_w - 1, x))
        y = max(0, min(img_h - 1, y))
        
        return x, y
    
    def mouseMoveEvent(self, event):
        """Handle mouse movement"""
        if self.current_image is not None:
            x, y = self.widget_to_image_coords(event.x(), event.y())
            self.mouse_position_changed.emit(x, y)
        
        if self.panning and self.last_pan_pos:
            delta = event.pos() - self.last_pan_pos
            self.pan_offset += delta
            self.last_pan_pos = event.pos()
            self._update_model_matrix()
            self.update()
        
        super().mouseMoveEvent(event)
    
    def mousePressEvent(self, event):
        """Handle mouse press"""
        if event.button() == Qt.MiddleButton or (event.button() == Qt.LeftButton and event.modifiers() & Qt.SpaceModifier):
            self.panning = True
            self.last_pan_pos = event.pos()
            self.setCursor(Qt.ClosedHandCursor)
        else:
            super().mousePressEvent(event)
    
    def mouseReleaseEvent(self, event):
        """Handle mouse release"""
        if event.button() == Qt.MiddleButton or event.button() == Qt.LeftButton:
            self.panning = False
            self.last_pan_pos = None
            self.setCursor(Qt.ArrowCursor)
        
        super().mouseReleaseEvent(event)
    
    def wheelEvent(self, event):
        """Handle mouse wheel for zooming"""
        delta = event.angleDelta().y()
        if delta > 0:
            self.zoom_in()
        else:
            self.zoom_out()
        
        event.accept()
    
    def update_current_image_from_selected_layer(self):
        """
        Compatibility method: Update image from current layer/frame.
        This matches CheckerboardCanvas's interface.
        Note: The actual image fetching should be done by the caller and passed via set_image().
        This method is a no-op placeholder - the real implementation should be done
        in the editor code that has access to state.layer_manager.
        """
        # This will be overridden or the editor will call set_image() directly
        pass
    
    def update_dirty_regions(self):
        """
        Update only the dirty regions from EditorState.
        Uses partial texture updates for efficiency.
        """
        try:
            from core.state import state
            if not state.has_dirty_regions():
                return
            
            if self.current_image is None:
                self.update()
                return
            
            # Get merged dirty rectangles from EditorState
            dirty_rects = state.get_dirty_rectangles()
            
            if not dirty_rects:
                return
            
            # Check if we need full redraw (too many regions or full redraw flag)
            if state.full_redraw_needed or len(dirty_rects) > 20:
                # Too many regions - just do full update
                self.set_image(self.current_image)
                state.clear_dirty_rectangles()
                return
            
            # Update each dirty region with partial texture updates
            for dirty_rect in dirty_rects:
                self.update_partial_texture(self.current_image, dirty_rect)
            
            # Clear dirty rectangles after update
            state.clear_dirty_rectangles()
            self.update()  # Trigger repaint
            
        except Exception as e:
            from Core.Debug import debug
            debug(f"Error in update_dirty_regions: {e}")
            # Fall back to full update on error
            self.update()
    
    def force_layer_frame_switch(self):
        """Compatibility method: Force refresh after layer/frame switch"""
        self.update_current_image_from_selected_layer()
        self.update()
    
    def set_image_size(self, width, height):
        """Compatibility method: Called when canvas size changes"""
        # Canvas_2D automatically handles resizing, but we need to update
        self.update()
    
    def set_theme(self, theme, custom_colors=None):
        """Compatibility method: Update theme colors"""
        # For now, just update checkerboard if needed
        # Theme colors could affect checkerboard colors in the future
        self.update()
    
    def set_preview_box(self, preview_box):
        """Compatibility method: Store reference to preview box"""
        self.preview_box = preview_box
    
    def _update_preview_box(self):
        """Update the preview box when canvas content changes"""
        if hasattr(self, 'preview_box') and self.preview_box:
            self.preview_box.update()
    
    def zoom_reset(self):
        """Compatibility method: Reset zoom (alias for reset_zoom)"""
        self.reset_zoom()
    
    def on_undo_redo(self):
        """Compatibility method: Refresh after undo/redo"""
        self.update_current_image_from_selected_layer()
        self.update()
    
    # Placeholder methods for selection operations (not yet implemented in GPU canvas)
    def cut_selection(self):
        """Placeholder: Selection cutting not yet implemented in GPU canvas"""
        pass
    
    def copy_selection(self):
        """Placeholder: Selection copying not yet implemented in GPU canvas"""
        pass
    
    def paste_selection(self):
        """Placeholder: Selection pasting not yet implemented in GPU canvas"""
        pass
    
    def select_all(self):
        """Placeholder: Select all not yet implemented in GPU canvas"""
        pass
    
    def clear_selection(self):
        """Placeholder: Clear selection not yet implemented in GPU canvas"""
        pass
    
    def cleanup(self):
        """Clean up OpenGL resources"""
        if self.image_texture_id is not None:
            self.texture_manager.delete_texture("canvas_2d_image")
        
        if self.selection_texture_id is not None:
            self.texture_manager.delete_texture("canvas_2d_selection")

