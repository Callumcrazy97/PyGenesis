"""
Texture Manager for PyGenesis OpenGL Runtime
Manages texture creation, caching, atlas generation, and mipmaps
"""

from OpenGL import GL
from PIL import Image
import numpy as np
from typing import Optional, Dict, Tuple, List
from pathlib import Path
from Core.Debug import debug
from Core.Rendering.OpenGLRuntime import get_runtime


class TextureManager:
    """
    Manages OpenGL textures with caching, atlas generation, and mipmap support.
    Provides unified texture handling for 2D and 3D rendering.
    """
    
    def __init__(self):
        """Initialize the texture manager"""
        self._texture_cache: Dict[str, int] = {}  # identifier -> texture_id
        self._texture_info: Dict[str, Dict] = {}  # identifier -> {width, height, format, has_mipmaps}
        self._texture_refs: Dict[str, int] = {}  # Reference counting
        
        self.runtime = get_runtime()
    
    def create_texture_from_array(self, 
                                  data: np.ndarray,
                                  identifier: str,
                                  generate_mipmaps: bool = False,
                                  filter_min: int = GL.GL_LINEAR,
                                  filter_mag: int = GL.GL_LINEAR,
                                  wrap_s: int = GL.GL_CLAMP_TO_EDGE,
                                  wrap_t: int = GL.GL_CLAMP_TO_EDGE) -> int:
        """
        Create an OpenGL texture from a NumPy array.
        
        Args:
            data: NumPy array (RGBA, RGB, or grayscale)
            identifier: Unique identifier for the texture
            generate_mipmaps: Whether to generate mipmaps
            filter_min: Minification filter (GL_NEAREST, GL_LINEAR, GL_LINEAR_MIPMAP_LINEAR, etc.)
            filter_mag: Magnification filter (GL_NEAREST or GL_LINEAR)
            wrap_s: S wrapping mode (GL_REPEAT, GL_CLAMP_TO_EDGE, etc.)
            wrap_t: T wrapping mode
            
        Returns:
            OpenGL texture ID
        """
        if not self.runtime.is_current():
            self.runtime.make_current()
        
        # Determine format based on array shape
        h, w = data.shape[:2]
        
        if len(data.shape) == 3:
            channels = data.shape[2]
            if channels == 4:
                format_type = GL.GL_RGBA
                internal_format = GL.GL_RGBA8
                pixel_type = GL.GL_UNSIGNED_BYTE
            elif channels == 3:
                format_type = GL.GL_RGB
                internal_format = GL.GL_RGB8
                pixel_type = GL.GL_UNSIGNED_BYTE
            else:
                raise ValueError(f"Unsupported channel count: {channels}")
        elif len(data.shape) == 2:
            format_type = GL.GL_RED
            internal_format = GL.GL_R8
            pixel_type = GL.GL_UNSIGNED_BYTE
        else:
            raise ValueError(f"Unsupported array shape: {data.shape}")
        
        # Ensure data is contiguous and right type
        if not data.flags['C_CONTIGUOUS']:
            data = np.ascontiguousarray(data)
        
        if data.dtype != np.uint8:
            data = data.astype(np.uint8)
        
        # Check if texture already exists
        if identifier in self._texture_cache:
            # Update existing texture
            texture_id = self._texture_cache[identifier]
            GL.glBindTexture(GL.GL_TEXTURE_2D, texture_id)
            
            # Update texture data
            GL.glTexSubImage2D(GL.GL_TEXTURE_2D, 0, 0, 0, w, h, format_type, pixel_type, data)
            
            if generate_mipmaps:
                GL.glGenerateMipmap(GL.GL_TEXTURE_2D)
            
            GL.glBindTexture(GL.GL_TEXTURE_2D, 0)
            self._texture_refs[identifier] = self._texture_refs.get(identifier, 0) + 1
            debug(f"Updated existing texture '{identifier}' (ID: {texture_id})")
            return texture_id
        
        # Create new texture
        texture_id = GL.glGenTextures(1)
        GL.glBindTexture(GL.GL_TEXTURE_2D, texture_id)
        
        # Upload texture data
        GL.glTexImage2D(GL.GL_TEXTURE_2D, 0, internal_format, w, h, 0, format_type, pixel_type, data)
        
        # Set texture parameters
        GL.glTexParameteri(GL.GL_TEXTURE_2D, GL.GL_TEXTURE_MIN_FILTER, filter_min)
        GL.glTexParameteri(GL.GL_TEXTURE_2D, GL.GL_TEXTURE_MAG_FILTER, filter_mag)
        GL.glTexParameteri(GL.GL_TEXTURE_2D, GL.GL_TEXTURE_WRAP_S, wrap_s)
        GL.glTexParameteri(GL.GL_TEXTURE_2D, GL.GL_TEXTURE_WRAP_T, wrap_t)
        
        # Generate mipmaps if requested
        if generate_mipmaps:
            GL.glGenerateMipmap(GL.GL_TEXTURE_2D)
        
        GL.glBindTexture(GL.GL_TEXTURE_2D, 0)
        
        # Register texture
        self._texture_cache[identifier] = texture_id
        self._texture_info[identifier] = {
            'width': w,
            'height': h,
            'format': format_type,
            'has_mipmaps': generate_mipmaps
        }
        self._texture_refs[identifier] = 1
        self.runtime.register_texture(identifier, texture_id)
        
        debug(f"Created texture '{identifier}' (ID: {texture_id}, {w}x{h}, mipmaps: {generate_mipmaps})")
        return texture_id
    
    def create_texture_from_file(self,
                                 file_path: str,
                                 identifier: Optional[str] = None,
                                 generate_mipmaps: bool = False,
                                 filter_min: int = GL.GL_LINEAR,
                                 filter_mag: int = GL.GL_LINEAR) -> int:
        """
        Create an OpenGL texture from an image file.
        
        Args:
            file_path: Path to image file
            identifier: Optional unique identifier (defaults to file path)
            generate_mipmaps: Whether to generate mipmaps
            filter_min: Minification filter
            filter_mag: Magnification filter
            
        Returns:
            OpenGL texture ID
        """
        if identifier is None:
            identifier = str(Path(file_path).absolute())
        
        # Check cache first
        if identifier in self._texture_cache:
            self._texture_refs[identifier] = self._texture_refs.get(identifier, 0) + 1
            return self._texture_cache[identifier]
        
        # Load image file
        try:
            pil_image = Image.open(file_path)
            
            # Convert to RGBA
            if pil_image.mode != 'RGBA':
                pil_image = pil_image.convert('RGBA')
            
            # Convert to NumPy array
            img_array = np.array(pil_image, dtype=np.uint8)
            
            return self.create_texture_from_array(
                img_array, identifier, generate_mipmaps, filter_min, filter_mag
            )
        except Exception as e:
            debug(f"Error loading texture from file '{file_path}': {e}")
            raise
    
    def get_texture(self, identifier: str) -> Optional[int]:
        """Get a texture ID by identifier"""
        return self._texture_cache.get(identifier)
    
    def get_texture_info(self, identifier: str) -> Optional[Dict]:
        """Get texture information (width, height, format, etc.)"""
        return self._texture_info.get(identifier)
    
    def bind_texture(self, identifier: str, unit: int = 0) -> bool:
        """
        Bind a texture to a texture unit.
        
        Args:
            identifier: Texture identifier
            unit: Texture unit index (0-31)
            
        Returns:
            True if texture was found and bound, False otherwise
        """
        texture_id = self.get_texture(identifier)
        if texture_id is not None:
            GL.glActiveTexture(GL.GL_TEXTURE0 + unit)
            GL.glBindTexture(GL.GL_TEXTURE_2D, texture_id)
            return True
        return False
    
    def delete_texture(self, identifier: str):
        """
        Delete a texture and remove it from the cache.
        Uses reference counting - texture is only deleted when ref count reaches 0.
        
        Args:
            identifier: Texture identifier
        """
        if identifier not in self._texture_refs:
            return
        
        self._texture_refs[identifier] -= 1
        
        if self._texture_refs[identifier] <= 0:
            # Actually delete the texture
            if not self.runtime.is_current():
                self.runtime.make_current()
            
            if identifier in self._texture_cache:
                texture_id = self._texture_cache.pop(identifier)
                GL.glDeleteTextures([texture_id])
                self.runtime.unregister_texture(identifier)
                debug(f"Deleted texture '{identifier}' (ID: {texture_id})")
            
            if identifier in self._texture_info:
                del self._texture_info[identifier]
            del self._texture_refs[identifier]
    
    def generate_mipmaps(self, identifier: str) -> bool:
        """
        Generate mipmaps for an existing texture.
        
        Args:
            identifier: Texture identifier
            
        Returns:
            True if mipmaps were generated, False otherwise
        """
        texture_id = self.get_texture(identifier)
        if texture_id is None:
            return False
        
        if not self.runtime.is_current():
            self.runtime.make_current()
        
        GL.glBindTexture(GL.GL_TEXTURE_2D, texture_id)
        GL.glGenerateMipmap(GL.GL_TEXTURE_2D)
        
        # Update min filter to use mipmaps
        GL.glTexParameteri(GL.GL_TEXTURE_2D, GL.GL_TEXTURE_MIN_FILTER, GL.GL_LINEAR_MIPMAP_LINEAR)
        
        GL.glBindTexture(GL.GL_TEXTURE_2D, 0)
        
        if identifier in self._texture_info:
            self._texture_info[identifier]['has_mipmaps'] = True
        
        debug(f"Generated mipmaps for texture '{identifier}'")
        return True
    
    def cleanup(self):
        """Clean up all textures (call on shutdown)"""
        if not self.runtime.is_current():
            self.runtime.make_current()
        
        # Delete all textures
        all_identifiers = list(self._texture_refs.keys())
        for identifier in all_identifiers:
            self._texture_refs[identifier] = 0  # Force deletion
            self.delete_texture(identifier)
        
        self._texture_cache.clear()
        self._texture_info.clear()
        self._texture_refs.clear()
        
        debug("TextureManager cleanup complete")


# Global instance
_texture_manager: Optional[TextureManager] = None


def get_texture_manager() -> TextureManager:
    """Get the global TextureManager instance"""
    global _texture_manager
    if _texture_manager is None:
        _texture_manager = TextureManager()
    return _texture_manager

