"""
Shader Manager for PyGenesis OpenGL Runtime
Manages shader compilation, caching, hot-reload, and variant system
"""

from OpenGL import GL
from OpenGL.GL import shaders
from typing import Optional, Dict, Tuple
from pathlib import Path
from Core.Debug import debug
from Core.Rendering.OpenGLRuntime import get_runtime


class ShaderManager:
    """
    Manages OpenGL shader programs with compilation, caching, and hot-reload support.
    Supports shader variants for 2D/3D rendering modes.
    """
    
    def __init__(self):
        """Initialize the shader manager"""
        self._shader_cache: Dict[str, int] = {}  # identifier -> program_id
        self._shader_sources: Dict[str, Tuple[str, str]] = {}  # identifier -> (vertex, fragment)
        self._shader_refs: Dict[str, int] = {}  # Reference counting
        
        self.runtime = get_runtime()
    
    def compile_shader(self,
                      vertex_source: str,
                      fragment_source: str,
                      identifier: str,
                      geometry_source: Optional[str] = None) -> int:
        """
        Compile and link a shader program.
        
        Args:
            vertex_source: Vertex shader source code
            fragment_source: Fragment shader source code
            identifier: Unique identifier for this shader program
            geometry_source: Optional geometry shader source code
            
        Returns:
            OpenGL program ID
        """
        if not self.runtime.is_current():
            self.runtime.make_current()
        
        # Check cache first
        if identifier in self._shader_cache:
            self._shader_refs[identifier] = self._shader_refs.get(identifier, 0) + 1
            return self._shader_cache[identifier]
        
        try:
            # Compile vertex shader
            vertex_shader = shaders.compileShader(vertex_source, GL.GL_VERTEX_SHADER)
            
            # Compile fragment shader
            fragment_shader = shaders.compileShader(fragment_source, GL.GL_FRAGMENT_SHADER)
            
            # Compile geometry shader if provided
            shader_list = [vertex_shader, fragment_shader]
            if geometry_source:
                geometry_shader = shaders.compileShader(geometry_source, GL.GL_GEOMETRY_SHADER)
                shader_list.append(geometry_shader)
            
            # Link program
            program = shaders.compileProgram(*shader_list)
            
            # Store in cache
            self._shader_cache[identifier] = program
            self._shader_sources[identifier] = (vertex_source, fragment_source)
            self._shader_refs[identifier] = 1
            
            debug(f"Compiled shader program '{identifier}' (ID: {program})")
            return program
            
        except RuntimeError as e:
            error_msg = f"Shader compilation error for '{identifier}': {str(e)}"
            debug(error_msg)
            raise RuntimeError(error_msg) from e
    
    def compile_shader_from_files(self,
                                  vertex_path: str,
                                  fragment_path: str,
                                  identifier: Optional[str] = None,
                                  geometry_path: Optional[str] = None) -> int:
        """
        Compile a shader program from source files.
        
        Args:
            vertex_path: Path to vertex shader file
            fragment_path: Path to fragment shader file
            identifier: Optional unique identifier (defaults to based on file paths)
            geometry_path: Optional path to geometry shader file
            
        Returns:
            OpenGL program ID
        """
        if identifier is None:
            identifier = f"{Path(vertex_path).stem}_{Path(fragment_path).stem}"
        
        # Read shader files
        vertex_source = Path(vertex_path).read_text()
        fragment_source = Path(fragment_path).read_text()
        geometry_source = None
        if geometry_path and Path(geometry_path).exists():
            geometry_source = Path(geometry_path).read_text()
        
        return self.compile_shader(vertex_source, fragment_source, identifier, geometry_source)
    
    def get_shader(self, identifier: str) -> Optional[int]:
        """Get a shader program ID by identifier"""
        return self._shader_cache.get(identifier)
    
    def use_shader(self, identifier: str) -> bool:
        """
        Use (activate) a shader program.
        
        Args:
            identifier: Shader identifier
            
        Returns:
            True if shader was found and activated, False otherwise
        """
        program_id = self.get_shader(identifier)
        if program_id is not None:
            GL.glUseProgram(program_id)
            return True
        return False
    
    def reload_shader(self, identifier: str) -> bool:
        """
        Reload a shader program from stored source.
        Useful for shader development and hot-reloading.
        
        Args:
            identifier: Shader identifier
            
        Returns:
            True if shader was reloaded, False otherwise
        """
        if identifier not in self._shader_sources:
            debug(f"Cannot reload shader '{identifier}' - source not stored")
            return False
        
        # Delete old program
        old_program = self._shader_cache.pop(identifier, None)
        if old_program:
            GL.glDeleteProgram(old_program)
        
        # Recompile from stored source
        vertex_source, fragment_source = self._shader_sources[identifier]
        
        try:
            new_program = self.compile_shader(vertex_source, fragment_source, identifier)
            debug(f"Reloaded shader program '{identifier}'")
            return True
        except Exception as e:
            debug(f"Error reloading shader '{identifier}': {e}")
            return False
    
    def delete_shader(self, identifier: str):
        """
        Delete a shader program and remove it from the cache.
        Uses reference counting - shader is only deleted when ref count reaches 0.
        
        Args:
            identifier: Shader identifier
        """
        if identifier not in self._shader_refs:
            return
        
        self._shader_refs[identifier] -= 1
        
        if self._shader_refs[identifier] <= 0:
            # Actually delete the shader
            if not self.runtime.is_current():
                self.runtime.make_current()
            
            if identifier in self._shader_cache:
                program_id = self._shader_cache.pop(identifier)
                GL.glUseProgram(0)  # Unbind first
                GL.glDeleteProgram(program_id)
                debug(f"Deleted shader program '{identifier}' (ID: {program_id})")
            
            if identifier in self._shader_sources:
                del self._shader_sources[identifier]
            del self._shader_refs[identifier]
    
    def get_uniform_location(self, identifier: str, uniform_name: str) -> Optional[int]:
        """
        Get the location of a uniform variable in a shader program.
        
        Args:
            identifier: Shader identifier
            uniform_name: Name of the uniform variable
            
        Returns:
            Uniform location, or None if not found
        """
        program_id = self.get_shader(identifier)
        if program_id is None:
            return None
        
        location = GL.glGetUniformLocation(program_id, uniform_name)
        return location if location != -1 else None
    
    def cleanup(self):
        """Clean up all shaders (call on shutdown)"""
        if not self.runtime.is_current():
            self.runtime.make_current()
        
        # Delete all shaders
        all_identifiers = list(self._shader_refs.keys())
        for identifier in all_identifiers:
            self._shader_refs[identifier] = 0  # Force deletion
            self.delete_shader(identifier)
        
        self._shader_cache.clear()
        self._shader_sources.clear()
        self._shader_refs.clear()
        
        debug("ShaderManager cleanup complete")


# Global instance
_shader_manager: Optional[ShaderManager] = None


def get_shader_manager() -> ShaderManager:
    """Get the global ShaderManager instance"""
    global _shader_manager
    if _shader_manager is None:
        _shader_manager = ShaderManager()
    return _shader_manager

