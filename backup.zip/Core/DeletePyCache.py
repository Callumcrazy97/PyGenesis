import os
import shutil

def delete_pycache(root: str):
    """
    Recursively delete ONLY folders named exactly '__pycache__'
    starting from the given root directory.
    """
    for dirpath, dirnames, filenames in os.walk(root, topdown=False):
        for d in dirnames:
            if d == "__pycache__":  # exact match only
                full_path = os.path.join(dirpath, d)
                print(f"Deleting: {full_path}")
                shutil.rmtree(full_path, ignore_errors=True)

if __name__ == "__main__":
    start_dir = os.path.abspath(".")
    print(f"Scanning from: {start_dir}")
    delete_pycache(start_dir)
    print("Done.")
