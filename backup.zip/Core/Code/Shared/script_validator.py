"""
ScriptValidator: A shared validation system for Python code strings.

This class provides syntax checking (via ast), basic static analysis (name resolution,
import checking), and safe execution with output/state capture for Python code
entered into editors (Script, Object, Shader, etc.).
"""

import ast
import importlib.util
import inspect
import sys
import os
import traceback
from io import StringIO
from pathlib import Path
from typing import Dict, List, Optional, Callable, Any, Tuple, Set
from collections import defaultdict


# --- Constants for Built-ins and Common Names ---
# Define common built-ins for static analysis fallback
COMMON_BUILTINS: Set[str] = {
    # Types and Functions
    'print', 'len', 'str', 'int', 'float', 'bool', 'list', 'dict', 'tuple', 'set',
    'range', 'enumerate', 'zip', 'map', 'filter', 'sorted', 'reversed', 'sum', 'max', 'min',
    'abs', 'round', 'divmod', 'pow', 'all', 'any', 'isinstance', 'issubclass', 'type',
    'hasattr', 'getattr', 'setattr', 'delattr', 'vars', 'dir', 'globals', 'locals',
    'open', 'input', 'exec', 'eval', 'compile', 'repr', 'ascii', 'exit', 'quit',
    'bin', 'oct', 'hex', 'chr', 'ord', 'format', 'hash', 'id', 'iter', 'next',
    'property', 'staticmethod', 'classmethod', 'super', 'object', 'callable',
    # Constants/Keywords
    'None', 'True', 'False', 'Ellipsis', 'NotImplemented', '__debug__',
    # Exceptions (A common subset)
    'Exception', 'BaseException', 'StopIteration', 'GeneratorExit', 'SystemExit',
    'KeyboardInterrupt', 'SystemError', 'ValueError', 'TypeError', 'AttributeError',
    'NameError', 'KeyError', 'IndexError', 'IOError', 'OSError', 'FileNotFoundError',
    'NotImplementedError', 'AssertionError', 'SyntaxError', 'ImportError', 'ZeroDivisionError',
}

# Names often defined in editors' scope or implicitly available
EDITOR_SCOPE_NAMES: Set[str] = {
    'self', 'cls', 'super', '__name__', '__file__', '__init__', '__main__',
    # Common variables often pre-defined in environments (adjust as needed)
    'project', 'editor', 'object', 'shader', 'script',
}

# Object Event built-in variables (provided by game engine at runtime)
OBJECT_EVENT_BUILTINS: Set[str] = {
    # Position and movement
    'x', 'y', 'z',
    'xprevious', 'yprevious', 'zprevious',
    'xstart', 'ystart', 'zstart',
    'hspeed', 'vspeed', 'speed', 'direction',
    'gravity', 'gravity_direction',
    'friction', 'friction_direction',
    
    # Size and collision
    'width', 'height', 'depth',
    'bbox_left', 'bbox_right', 'bbox_top', 'bbox_bottom',
    'bbox_front', 'bbox_back',
    
    # Visual properties
    'image_angle', 'image_alpha', 'image_blend', 'image_index', 'image_number',
    'image_speed', 'image_xscale', 'image_yscale', 'image_xoffset', 'image_yoffset',
    'visible', 'depth', 'sprite', 'sprite_index', 'sprite_width', 'sprite_height',
    'sprite_xoffset', 'sprite_yoffset',
    
    # Object properties
    'solid', 'persistent', 'mask_index', 'parent', 'object_index',
    
    # Health and state
    'health', 'max_health', 'lives', 'score',
    
    # Room properties (commonly accessed)
    'room_width', 'room_height', 'room_depth',
    'room', 'room_index',
    
    # Common functions that might be called
    'instance_create', 'instance_destroy', 'instance_find', 'instance_exists',
    'instance_find_nearest', 'instance_find_furthest', 'instance_find_id',
    'instance_get_count', 'instance_copy', 'instance_set_active',
    'place_free', 'place_meeting', 'collision_point', 'collision_rectangle',
    'lengthdir_x', 'lengthdir_y', 'point_direction', 'point_distance',
    'draw_circle', 'draw_rectangle', 'draw_text', 'draw_sprite',
    'clamp', 'max', 'min', 'abs', 'round', 'floor', 'ceil',
    'string', 'real', 'int',
    
    # Collision event context (available in collision events)
    'other',  # The other object instance in collision
    'collision_object',  # The object type being collided with
}


class ScriptValidator:
    """
    Validates Python code strings (not just files).

    Provides static analysis for syntax and name resolution, and safe execution
    to capture runtime output and state.
    """

    def __init__(self, project_path: Optional[Path] = None, output_callback: Optional[Callable[[str], None]] = None):
        """
        Initialize the script validator.

        Args:
            project_path: Path to the project root (for module resolution)
            output_callback: Optional callback function to receive output messages
        """
        self.project_path: Optional[Path] = Path(project_path) if project_path else None
        self.output_callback = output_callback

    def _output(self, message: str) -> None:
        """Output a message via callback if available."""
        if self.output_callback:
            self.output_callback(message)

    def check_code_string(self, code: str, context_name: str = "Code", editor_context: Optional[str] = None, predefined_variables: Optional[Set[str]] = None) -> Dict[str, Any]:
        """
        Check a Python code string for errors.

        Performs:
        1. Code Cleaning
        2. Syntax Check (AST parsing)
        3. Static Analysis (Undefined names, basic imports)
        4. Safe Execution (Captures output, return value, variables)

        Args:
            code: Python code string to validate.
            context_name: Name for context (e.g., "Event: Create", "Script: main.py").
            editor_context: Optional editor context (e.g., "object_event", "script", "shader").
            predefined_variables: Optional set of variable names that are predefined (e.g., from other events).

        Returns:
            Dictionary with 'errors', 'warnings', 'passed' keys.
        """
        result: Dict[str, Any] = {
            'errors': [],
            'warnings': [],
            'passed': False
        }

        if not code or not code.strip():
            result['passed'] = True
            return result

        # 1. Code Cleaning
        code = self._clean_code_string(code)

        try:
            # 2. Syntax Check (AST parsing)
            try:
                # Compile code for execution later, and get the AST tree
                compiled_code = compile(code, "<string>", 'exec', dont_inherit=True)
                tree = ast.parse(code, filename="<string>")
            except SyntaxError as e:
                error_msg = f"Syntax error: {e.msg} (line {e.lineno})"
                result['errors'].append(error_msg)
                self._output(f"❌ {context_name}: {error_msg}\n")
                if e.text:
                    self._output(f"   {e.text.strip()}\n")
                return result

            # 3. Static Analysis
            file_definitions = self._extract_definitions(tree)
            file_imports = self._extract_imports(tree)

            self._analyze_code(
                tree, code, file_definitions, file_imports,
                result['errors'], result['warnings'], context_name,
                editor_context=editor_context,
                predefined_variables=predefined_variables
            )

            # 4. Report validation results
            if result['errors']:
                self._output(f"❌ {context_name}: {len(result['errors'])} error(s) found\n")
                for error in result['errors']:
                    self._output(f"   {error}\n")
            elif result['warnings']:
                self._output(f"⚠️ {context_name}: {len(result['warnings'])} warning(s) found\n")
                for warning in result['warnings']:
                    self._output(f"   {warning}\n")
            else:
                self._output(f"✅ {context_name}: No static errors found\n")
                result['passed'] = True

            # 5. Safe Execution (Only if no syntax/import errors)
            if len(result['errors']) == 0:
                self._execute_code(code, context_name)

            return result

        except Exception as e:
            error_msg = f"Internal Validator Error while checking {context_name}: {type(e).__name__}: {e}"
            result['errors'].append(error_msg)
            result['passed'] = False
            self._output(f"❌ {error_msg}\n")
            return result

    # --- Static Analysis Helpers ---

    def _clean_code_string(self, code: str) -> str:
        """
        Clean code string by removing non-printable characters and normalizing unicode.
        """
        import unicodedata

        cleaned_lines: List[str] = []
        # Use splitlines(keepends=True) to preserve line numbers
        for line in code.splitlines(keepends=True):
            # Remove non-printable characters except newlines, carriage returns, and tabs
            cleaned_line = ''.join(
                char for char in line
                if char.isprintable() or char in ('\n', '\r', '\t')
            )
            cleaned_lines.append(cleaned_line)

        cleaned_code = ''.join(cleaned_lines)

        # Replace common problematic unicode characters that might cause parsing issues
        replacements = {
            '\u2029': '\n',  # Paragraph separator
            '\u2028': '\n',  # Line separator
            '\u200b': '',    # Zero-width space
            '\ufeff': '',    # BOM
        }

        for old, new in replacements.items():
            cleaned_code = cleaned_code.replace(old, new)

        return cleaned_code

    def _extract_definitions(self, tree: ast.AST) -> Dict[str, Set[str]]:
        """Extract function, class, and variable definitions from AST."""
        definitions: Dict[str, Set[str]] = {
            'functions': set(),
            'classes': set(),
            'variables': set()
        }

        for node in ast.walk(tree):
            if isinstance(node, ast.FunctionDef):
                definitions['functions'].add(node.name)
            elif isinstance(node, ast.ClassDef):
                definitions['classes'].add(node.name)
            elif isinstance(node, ast.Name) and isinstance(node.ctx, ast.Store):
                # Simple variable assignment (at module level)
                # Note: This is a basic check; full scope analysis is complex
                definitions['variables'].add(node.id)
            elif isinstance(node, (ast.Assign, ast.AnnAssign, ast.AugAssign)):
                # Handle assignments (for variables)
                targets = []
                if isinstance(node, ast.Assign):
                    targets = node.targets
                elif isinstance(node, (ast.AnnAssign, ast.AugAssign)):
                    targets = [node.target]

                for target in targets:
                    if isinstance(target, ast.Name):
                        # Only consider top-level assignments in a basic check
                        definitions['variables'].add(target.id)

        return definitions

    def _extract_imports(self, tree: ast.AST) -> Dict[str, Any]:
        """Extract import statements from AST."""
        # Key: module name (e.g., 'os', 'pathlib'), Value: dict of import details
        imports: Dict[str, Any] = defaultdict(dict)

        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    module_name = alias.name
                    import_alias = alias.asname if alias.asname else module_name
                    imports[module_name] = {'alias': import_alias, 'type': 'module', 'used_name': import_alias}

            elif isinstance(node, ast.ImportFrom):
                # Relative imports are complex; only support absolute imports here
                if node.level > 0:
                    continue

                module_name = node.module if node.module else ''
                imported_items: List[Tuple[str, str]] = []

                for alias in node.names:
                    item_name = alias.name
                    item_alias = alias.asname if alias.asname else item_name
                    imported_items.append((item_name, item_alias))

                    # Map the imported item's *used name* back to its module
                    imports[item_alias] = {'module': module_name, 'type': 'from_item', 'used_name': item_alias}

                # Store module info for checking if the module exists
                if module_name and module_name not in imports:
                    imports[module_name] = {'type': 'from_module', 'items': imported_items}

        return dict(imports)

    def _analyze_code(
        self, tree: ast.AST, code: str,
        file_definitions: Dict[str, Set[str]], file_imports: Dict[str, Any],
        errors: List[str], warnings: List[str], context_name: str,
        editor_context: Optional[str] = None
    ) -> None:
        """Analyze code for undefined names and import issues."""

        # 1. Check for missing modules on import statements
        for module_name, import_info in file_imports.items():
            if import_info['type'] in ('module', 'from_module'):
                if not self._module_exists(module_name):
                    error_msg = f"Module '{module_name}' not found. Please ensure it's installed or available in the project path."
                    errors.append(error_msg)

        # 2. Check for potentially undefined names (basic static resolution)
        defined_names: Set[str] = set()
        defined_names.update(COMMON_BUILTINS)
        defined_names.update(EDITOR_SCOPE_NAMES)
        
        # Add context-specific built-ins
        if editor_context == "object_event":
            defined_names.update(OBJECT_EVENT_BUILTINS)
        
        defined_names.update(file_definitions.get('functions', set()))
        defined_names.update(file_definitions.get('classes', set()))
        defined_names.update(file_definitions.get('variables', set()))

        # Add names imported directly (import X as Y, from X import Y as Z)
        for _, import_info in file_imports.items():
            if import_info.get('used_name'):
                defined_names.add(import_info['used_name'])

        # Extract function parameters and local variables from all scopes
        # Walk the tree to collect all function parameters and local variables
        function_params: Set[str] = set()
        local_variables: Set[str] = set()
        
        for node in ast.walk(tree):
            # Extract function parameters
            if isinstance(node, ast.FunctionDef) or isinstance(node, ast.AsyncFunctionDef):
                # Add function parameters
                for arg in node.args.args:
                    function_params.add(arg.arg)
                # Also check for *args and **kwargs
                if node.args.vararg:
                    function_params.add(node.args.vararg.arg)
                if node.args.kwarg:
                    function_params.add(node.args.kwarg.arg)
            
            # Extract local variable assignments
            if isinstance(node, ast.Assign):
                for target in node.targets:
                    if isinstance(target, ast.Name):
                        local_variables.add(target.id)
            elif isinstance(node, (ast.AnnAssign, ast.AugAssign)):
                if isinstance(node.target, ast.Name):
                    local_variables.add(node.target.id)
        
        # Add function parameters and local variables to defined names
        defined_names.update(function_params)
        defined_names.update(local_variables)
        
        for node in ast.walk(tree):
            # Check only for names being *loaded* (i.e., used, not defined)
            if isinstance(node, ast.Name) and isinstance(node.ctx, ast.Load):
                name = node.id

                # Skip if already in defined names (including function params and locals)
                if name in defined_names:
                    continue

                # Fallback check for builtins that might not be in the pre-defined list
                if hasattr(sys.modules['builtins'], name):
                    defined_names.add(name)  # Add to set to skip future checks
                    continue

                # Flag as potentially undefined
                line_info = f"Line {node.lineno}"
                warning_msg = f"{line_info}: Potentially undefined name '{name}'. Check scope or spelling."
                warnings.append(warning_msg)

    def _module_exists(self, module_name: str) -> bool:
        """Check if a module exists in the environment or project path."""
        # 1. Check environment (standard library, site-packages)
        try:
            spec = importlib.util.find_spec(module_name)
            if spec is not None:
                return True
        except (ValueError, ImportError):
            pass

        # 2. Check local project files if project_path is set
        if self.project_path and self.project_path.is_dir():
            # Temporarily add project path to sys.path for local module resolution
            original_sys_path = sys.path[:]
            sys.path.insert(0, str(self.project_path))
            try:
                # Retry find_spec with updated sys.path
                spec = importlib.util.find_spec(module_name)
                if spec is not None:
                    return True
            except (ValueError, ImportError):
                pass
            finally:
                sys.path = original_sys_path

        return False

    # --- Execution Helper ---

    def _execute_code(self, code: str, context_name: str) -> None:
        """
        Execute the code and capture print output, return values, and variable state.
        Execution is performed using `exec` in a controlled namespace.
        """
        import sys
        from io import StringIO

        # Capture stdout and stderr temporarily
        old_stdout = sys.stdout
        old_stderr = sys.stderr
        sys.stdout = captured_output = StringIO()
        sys.stderr = captured_error = StringIO()

        try:
            # Create a safe execution namespace, mimicking a module scope
            exec_namespace = {
                '__name__': '__main__',
                '__builtins__': __builtins__
            }

            return_value: Any = None
            is_expression = False
            function_results: List[Tuple[str, Any]] = []

            # Try to parse as expression first (for single expressions/REPL style)
            try:
                # ast.parse(mode='eval') fails if there are multiple expressions or statements
                tree = ast.parse(code.strip(), mode='eval')
                
                # Check if it's a simple assignment that might be mistaken for an expression
                if isinstance(tree.body, ast.Expression) and isinstance(tree.body.body, ast.Call):
                     # If it's just a call (like print('hi')), it's an expression.
                     # However, running it with eval won't execute imports/defs on module level.
                     # We'll stick to 'exec' for robustness unless it's a non-call simple expression.
                     pass 
                
                # It's a single expression, evaluate it to get the return value
                return_value = eval(compile(tree, '<string>', 'eval'), exec_namespace)
                is_expression = True
            except SyntaxError:
                # Not a single expression, execute as statements
                # Execute the code ONCE - this is the actual execution
                exec(compile(code, '<string>', 'exec'), exec_namespace)

                # Post-execution: Try to get the result of the last line if it was a simple expression
                # This simulates REPL behavior, but we must be careful not to re-execute statements
                lines = [line for line in code.split('\n') if line.strip() and not line.strip().startswith('#')]
                if lines:
                    last_line = lines[-1].strip()
                    # Only evaluate if it's a simple expression (not a statement that has side effects)
                    # Skip if it's control flow, assignment, import, or function call (which has side effects)
                    if (not any(last_line.startswith(kw) for kw in ['def', 'class', 'if', 'for', 'while', 'with', 'try', 'import', 'from', 'return', 'print']) and
                        '=' not in last_line.split('#')[0] and
                        not last_line.endswith(':')):
                        try:
                            # Only evaluate if it's a pure expression (no function calls with side effects)
                            # Check if it contains function calls - if so, skip evaluation to avoid re-execution
                            last_tree = ast.parse(last_line, mode='eval')
                            # Check if the expression contains any function calls
                            has_function_calls = any(isinstance(node, ast.Call) for node in ast.walk(last_tree))
                            if not has_function_calls:
                                # Safe to evaluate - it's a pure expression
                                return_value = eval(compile(last_tree, '<string>', 'eval'), exec_namespace)
                                is_expression = True
                        except Exception:
                            pass # Not a valid expression or it failed to evaluate

                # If the code defined functions, explicitly call a common entry point like 'main'
                if 'main' in exec_namespace and callable(exec_namespace['main']):
                    try:
                        main_func = exec_namespace['main']
                        # Check for no required arguments (simple execution)
                        sig = inspect.signature(main_func)
                        if all(p.default is not inspect.Parameter.empty or p.kind in (p.VAR_POSITIONAL, p.VAR_KEYWORD) for p in sig.parameters.values()):
                             func_result = main_func()
                             function_results.append(('main()', func_result))
                    except Exception as e:
                        # Runtime error in main() call
                        self._output(f"\n⚠️ Runtime Error in 'main()': {type(e).__name__}: {e}\n")
                        traceback.print_exc(file=sys.stderr)


            # Get captured output and errors
            output = captured_output.getvalue()
            errors_out = captured_error.getvalue()

            # Display Execution Results
            self._output(f"\n--- Execution Results ({context_name}) ---")

            if output:
                self._output(f"\n📤 Standard Output:\n")
                for line in output.splitlines():
                    self._output(f"   {line}\n")
            
            if errors_out:
                self._output(f"\n🚨 Standard Error:\n")
                for line in errors_out.splitlines():
                    self._output(f"   {line}\n")

            if function_results:
                self._output(f"\n🔧 Function Results:\n")
                for func_name, func_result in function_results:
                    self._output(f"   {func_name} → {repr(func_result)}\n")

            if return_value is not None and is_expression:
                self._output(f"\n↩️ Return Value: {repr(return_value)}\n")

            # Show variable state (non-builtin, non-private)
            variables: Dict[str, Any] = {}
            if not is_expression:
                for key, value in exec_namespace.items():
                    if (not key.startswith('_') and
                            key not in COMMON_BUILTINS and
                            key not in ['__name__', '__builtins__']):
                        # Exclude modules and complex types; allow functions and classes defined in the script
                        if not inspect.ismodule(value):
                            if callable(value):
                                # Only show user-defined functions/classes
                                if value.__module__ == "__main__":
                                    variables[key] = value
                            else:
                                variables[key] = value

                if variables:
                    self._output(f"\n📊 Local Variables:\n")
                    for var_name, var_value in sorted(variables.items()):
                        try:
                            self._output(f"   {var_name} = {repr(var_value)}\n")
                        except Exception:
                            self._output(f"   {var_name} = <{type(var_value).__name__} (unrepresentable)>\n")

            if not output and not errors_out and not return_value and not function_results and not variables:
                self._output(f"\n✓ Code executed successfully (no output or visible state change)\n")


        except Exception as e:
            # Execution error (runtime error that was not caught by standard error)
            error_type = type(e).__name__
            error_msg = str(e)
            self._output(f"\n❌ Runtime Exception: {error_type}: {error_msg}\n")
            
            # Print minimal traceback to the output stream
            self._output("   --- Traceback ---\n")
            
            # Using StringIO for traceback capture
            tb_string = StringIO()
            traceback.print_exc(file=tb_string)
            tb_lines = tb_string.getvalue().splitlines()
            
            # Filter and show relevant lines (excluding the validator's own frames)
            relevant_lines = [line for line in tb_lines if 'file "<string>"' in line or 'Error Exception' in line or not line.strip().startswith('File ')]
            
            for line in relevant_lines[-6:]: # Show last 6 lines of relevant traceback
                 if line.strip():
                     self._output(f"   {line.strip()}\n")
            
        finally:
            # Restore stdout and stderr
            sys.stdout = old_stdout
            sys.stderr = old_stderr