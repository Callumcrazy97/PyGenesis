"""
Shared Script System
Common validation and checking utilities for Script, Object, and Shader editors.
"""

from .script_validator import ScriptValidator

__all__ = [
    'ScriptValidator',
]

