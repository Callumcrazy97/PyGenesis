"""
Code Autocompletion System
Provides GMS-style autocompletion dropdown for code editors
"""

from PySide6.QtWidgets import (QListWidget, QListWidgetItem, QWidget, QVBoxLayout, 
                               QLabel, QFrame)
from PySide6.QtCore import Qt, QPoint, QTimer, Signal
from PySide6.QtGui import QFont, QTextCursor
from typing import List, Dict, Optional, Tuple
import keyword
import re


class CodeCompleter(QWidget):
    """
    GMS-style autocompletion dropdown widget.
    Shows matching completions as user types.
    """
    
    completion_selected = Signal(str)  # Emitted when user selects a completion
    
    def __init__(self, parent=None):
        super().__init__(parent, Qt.Popup | Qt.FramelessWindowHint)
        self.setup_ui()
        self.completions = []
        self.filtered_completions = []
        self.current_prefix = ""
        self.selected_index = 0
        self.hide()
        
        # Timer for showing completions (debounce)
        self.show_timer = QTimer()
        self.show_timer.setSingleShot(True)
        self.show_timer.timeout.connect(self._show_completions)
    
    def setup_ui(self):
        """Setup the completer UI"""
        layout = QVBoxLayout(self)
        layout.setContentsMargins(2, 2, 2, 2)
        layout.setSpacing(0)
        
        # Completion list
        self.list_widget = QListWidget()
        self.list_widget.setFont(QFont("Consolas", 9))
        self.list_widget.setMaximumHeight(200)
        self.list_widget.setMinimumWidth(300)
        self.list_widget.itemClicked.connect(self._on_item_clicked)
        self.list_widget.itemDoubleClicked.connect(self._on_item_double_clicked)
        layout.addWidget(self.list_widget)
        
        # Documentation label (optional)
        self.doc_label = QLabel()
        self.doc_label.setWordWrap(True)
        self.doc_label.setMaximumHeight(60)
        self.doc_label.setStyleSheet("background-color: #2b2b2b; padding: 4px; border-top: 1px solid #555;")
        self.doc_label.hide()
        layout.addWidget(self.doc_label)
        
        # Style
        self.setStyleSheet("""
            QListWidget {
                background-color: #1e1e1e;
                border: 1px solid #555;
                color: #d4d4d4;
            }
            QListWidget::item {
                padding: 2px;
            }
            QListWidget::item:selected {
                background-color: #0078d4;
                color: white;
            }
            QListWidget::item:hover {
                background-color: #3e3e3e;
            }
        """)
    
    def set_completions(self, completions: List[Dict[str, str]]):
        """
        Set the list of available completions.
        
        Args:
            completions: List of dicts with keys:
                - 'text': The completion text (e.g., "Move2D_direction")
                - 'display': Display text (e.g., "Move2D_direction(direction, speed)")
                - 'doc': Documentation/tooltip (optional)
                - 'category': Category (e.g., "PGSL", "Python", "Variable")
        """
        self.completions = completions
        self.filtered_completions = completions.copy()
        self._update_list()
    
    def filter_completions(self, prefix: str):
        """
        Filter completions based on prefix.
        
        Args:
            prefix: The text prefix to filter by
        """
        self.current_prefix = prefix.lower()
        
        if not prefix:
            self.filtered_completions = self.completions.copy()
        else:
            self.filtered_completions = [
                comp for comp in self.completions
                if comp['text'].lower().startswith(self.current_prefix) or
                   comp['text'].lower().find(self.current_prefix) >= 0
            ]
        
        self.selected_index = 0
        self._update_list()
    
    def _update_list(self):
        """Update the list widget with filtered completions"""
        self.list_widget.clear()
        
        # Show top 20 matches
        for comp in self.filtered_completions[:20]:
            item = QListWidgetItem(comp.get('display', comp['text']))
            item.setData(Qt.UserRole, comp['text'])
            item.setData(Qt.UserRole + 1, comp.get('doc', ''))
            item.setData(Qt.UserRole + 2, comp.get('category', ''))
            self.list_widget.addItem(item)
        
        # Select first item
        if self.list_widget.count() > 0:
            self.list_widget.setCurrentRow(0)
            self.selected_index = 0
            self._update_doc()
    
    def _update_doc(self):
        """Update documentation label for selected item"""
        current_item = self.list_widget.currentItem()
        if current_item:
            doc = current_item.data(Qt.UserRole + 1)
            if doc:
                self.doc_label.setText(doc)
                self.doc_label.show()
            else:
                self.doc_label.hide()
        else:
            self.doc_label.hide()
    
    def _on_item_clicked(self, item: QListWidgetItem):
        """Handle item click"""
        text = item.data(Qt.UserRole)
        if text:
            self.completion_selected.emit(text)
            self.hide()
    
    def _on_item_double_clicked(self, item: QListWidgetItem):
        """Handle item double-click"""
        self._on_item_clicked(item)
    
    def show_at_position(self, position: QPoint):
        """Show completer at specified position"""
        self.move(position)
        self.show()
        self.raise_()
        self.activateWindow()
    
    def select_next(self):
        """Select next item"""
        if self.list_widget.count() > 0:
            self.selected_index = (self.selected_index + 1) % self.list_widget.count()
            self.list_widget.setCurrentRow(self.selected_index)
            self._update_doc()
    
    def select_previous(self):
        """Select previous item"""
        if self.list_widget.count() > 0:
            self.selected_index = (self.selected_index - 1) % self.list_widget.count()
            self.list_widget.setCurrentRow(self.selected_index)
            self._update_doc()
    
    def get_selected_completion(self) -> Optional[str]:
        """Get the currently selected completion text"""
        current_item = self.list_widget.currentItem()
        if current_item:
            return current_item.data(Qt.UserRole)
        return None
    
    def _show_completions(self):
        """Show completions (called by timer)"""
        # This is a placeholder - actual showing is handled by the editor
        pass


class CompletionProvider:
    """
    Provides completion suggestions for code editors.
    Includes PGSL commands, Python keywords, and context-aware completions.
    """
    
    def __init__(self, pgsl_parser=None):
        """
        Initialize completion provider.
        
        Args:
            pgsl_parser: Optional PGSLParser instance for PGSL command info
        """
        self.pgsl_parser = pgsl_parser
        self.python_keywords = self._get_python_keywords()
        self.pgsl_commands = self._get_pgsl_commands()
        self.custom_completions = []  # Can be extended with object variables, etc.
    
    def _get_python_keywords(self) -> List[Dict[str, str]]:
        """Get Python keyword completions"""
        keywords = []
        for kw in keyword.kwlist:
            keywords.append({
                'text': kw,
                'display': kw,
                'doc': f"Python keyword: {kw}",
                'category': 'Python'
            })
        return keywords
    
    def _get_pgsl_commands(self) -> List[Dict[str, str]]:
        """Get PGSL command completions"""
        commands = [
            # IDE & Runtime
            {'text': 'Run', 'display': 'Run()', 'doc': 'Starts the game', 'category': 'PGSL'},
            {'text': 'Debug_Run', 'display': 'Debug_Run()', 'doc': 'Starts the game in debug mode', 'category': 'PGSL'},
            {'text': 'Build', 'display': 'Build(target)', 'doc': 'Builds the game into a standalone executable', 'category': 'PGSL'},
            {'text': 'Validate', 'display': 'Validate(scope)', 'doc': 'Validates a file or the entire project', 'category': 'PGSL'},
            {'text': 'game_end', 'display': 'game_end()', 'doc': 'Shuts down the game safely', 'category': 'PGSL'},
            {'text': 'window_set_size', 'display': 'window_set_size(w, h)', 'doc': 'Sets the window resolution', 'category': 'PGSL'},
            {'text': 'window_set_title', 'display': 'window_set_title(text)', 'doc': 'Sets the window title bar text', 'category': 'PGSL'},
            {'text': 'game_set_speed', 'display': 'game_set_speed(fps)', 'doc': 'Sets the global FPS cap', 'category': 'PGSL'},
            {'text': 'room_set_speed', 'display': 'room_set_speed(fps)', 'doc': 'Sets room-specific FPS', 'category': 'PGSL'},
            
            # Instances & Objects
            {'text': 'create_instance', 'display': 'create_instance(x, y, z, object, amount)', 'doc': 'Creates an instance (or multiple)', 'category': 'PGSL'},
            {'text': 'instance_destroy', 'display': 'instance_destroy(id)', 'doc': 'Destroys a specific instance', 'category': 'PGSL'},
            {'text': 'instance_find', 'display': 'instance_find(object)', 'doc': 'Returns list of all instances of an object', 'category': 'PGSL'},
            {'text': 'instance_find_nearest', 'display': 'instance_find_nearest(object)', 'doc': 'Returns nearest instance ID of that object', 'category': 'PGSL'},
            {'text': 'instance_find_furthest', 'display': 'instance_find_furthest(object)', 'doc': 'Returns furthest instance ID', 'category': 'PGSL'},
            {'text': 'instance_find_id', 'display': 'instance_find_id(id)', 'doc': 'Retrieves instance reference by ID', 'category': 'PGSL'},
            {'text': 'instance_get_count', 'display': 'instance_get_count(object)', 'doc': 'Returns number of existing instances of that object', 'category': 'PGSL'},
            {'text': 'instance_exists', 'display': 'instance_exists(object)', 'doc': 'Returns true if at least one instance exists', 'category': 'PGSL'},
            {'text': 'instance_copy', 'display': 'instance_copy(id)', 'doc': 'Duplicates an instance', 'category': 'PGSL'},
            {'text': 'instance_set_motion', 'display': 'instance_set_motion(id, hsp, vsp, zsp)', 'doc': 'Sets velocity directly', 'category': 'PGSL'},
            {'text': 'instance_get_motion', 'display': 'instance_get_motion(id)', 'doc': 'Returns a tuple of (hsp, vsp, zsp)', 'category': 'PGSL'},
            {'text': 'place_free', 'display': 'place_free(x, y)', 'doc': 'Checks if 2D position is free', 'category': 'PGSL'},
            {'text': 'place_free_3d', 'display': 'place_free_3d(x, y, z)', 'doc': 'Checks if 3D position is free', 'category': 'PGSL'},
            
            # Variables & Math
            {'text': 'Variable_set', 'display': 'Variable_set(name, value)', 'doc': 'Sets an instance variable', 'category': 'PGSL'},
            {'text': 'Variable_get', 'display': 'Variable_get(name)', 'doc': 'Gets an instance variable value', 'category': 'PGSL'},
            {'text': 'Variable_exists', 'display': 'Variable_exists(name)', 'doc': 'True if variable exists', 'category': 'PGSL'},
            {'text': 'Wait', 'display': 'Wait(ms)', 'doc': 'Pauses script briefly', 'category': 'PGSL'},
            {'text': 'clamp', 'display': 'clamp(value, min, max)', 'doc': 'Constrains a number', 'category': 'PGSL'},
            {'text': 'lerp', 'display': 'lerp(a, b, t)', 'doc': 'Linear interpolation', 'category': 'PGSL'},
            {'text': 'point_direction', 'display': 'point_direction(x1, y1, x2, y2)', 'doc': 'Angle between two points', 'category': 'PGSL'},
            {'text': 'point_distance', 'display': 'point_distance(x1, y1, x2, y2)', 'doc': 'Distance between two points', 'category': 'PGSL'},
            {'text': 'random_range', 'display': 'random_range(min, max)', 'doc': 'Random float or int', 'category': 'PGSL'},
            {'text': 'random_int', 'display': 'random_int(min, max)', 'doc': 'Random integer', 'category': 'PGSL'},
            
            # Movement & Physics
            {'text': 'Move2D_direction', 'display': 'Move2D_direction(direction, speed)', 'doc': 'Moves in 2D by direction + speed', 'category': 'PGSL'},
            {'text': 'Move2D_point', 'display': 'Move2D_point(x, y, speed)', 'doc': 'Moves toward a point', 'category': 'PGSL'},
            {'text': 'Move3D_direction', 'display': 'Move3D_direction(yaw, pitch, speed)', 'doc': 'Moves based on FPS-style rotation angles', 'category': 'PGSL'},
            {'text': 'Move3D_towards', 'display': 'Move3D_towards(x, y, z, speed)', 'doc': 'Moves toward a world coordinate', 'category': 'PGSL'},
            {'text': 'Move3D_stop', 'display': 'Move3D_stop()', 'doc': 'Stops movement instantly', 'category': 'PGSL'},
            {'text': 'Move3D_add_force', 'display': 'Move3D_add_force(fx, fy, fz)', 'doc': 'Applies a 3D impulse/force', 'category': 'PGSL'},
            {'text': 'collision_point', 'display': 'collision_point(x, y, object)', 'doc': 'True if a point overlaps an object', 'category': 'PGSL'},
            {'text': 'collision_rect', 'display': 'collision_rect(x1, y1, x2, y2, object)', 'doc': 'True if rectangle overlaps an object', 'category': 'PGSL'},
            
            # Drawing & Graphics
            {'text': 'Draw_Self_2D', 'display': 'Draw_Self_2D()', 'doc': 'Draws the instance\'s sprite in world space', 'category': 'PGSL'},
            {'text': 'Draw_Sprite_2D', 'display': 'Draw_Sprite_2D(sprite, frame, x, y)', 'doc': 'Draws a specific sprite frame', 'category': 'PGSL'},
            {'text': 'Draw_Text_2D', 'display': 'Draw_Text_2D(x, y, text)', 'doc': 'Draws world-space text', 'category': 'PGSL'},
            {'text': 'Draw_Rect_2D', 'display': 'Draw_Rect_2D(x1, y1, x2, y2, color, filled)', 'doc': 'World-space rectangle', 'category': 'PGSL'},
            {'text': 'Draw_Self_3D', 'display': 'Draw_Self_3D()', 'doc': 'Draws instance\'s assigned model', 'category': 'PGSL'},
            {'text': 'Draw_Model_3D', 'display': 'Draw_Model_3D(model)', 'doc': 'Draws a 3D model resource', 'category': 'PGSL'},
            {'text': 'Draw_Text_3D', 'display': 'Draw_Text_3D(x, y, z, text)', 'doc': '3D billboard text', 'category': 'PGSL'},
            {'text': 'Draw_HUD', 'display': 'Draw_HUD(x1, y1, x2, y2, texture, repX, repY)', 'doc': 'Draws textured GUI rectangle', 'category': 'PGSL'},
            {'text': 'Draw_Bar', 'display': 'Draw_Bar(x1, y1, x2, y2, mincol, maxcol, current, max)', 'doc': 'Draws progress/HP bar', 'category': 'PGSL'},
            {'text': 'Draw_HUD_Text', 'display': 'Draw_HUD_Text(x, y, text)', 'doc': 'Draws screen-space text', 'category': 'PGSL'},
            {'text': 'Draw_HUD_Sprite', 'display': 'Draw_HUD_Sprite(sprite, frame, x, y)', 'doc': 'Draws a sprite in HUD', 'category': 'PGSL'},
            
            # Camera & Viewports
            {'text': 'Camera2D_set_position', 'display': 'Camera2D_set_position(x, y)', 'doc': 'Sets camera centre', 'category': 'PGSL'},
            {'text': 'Camera2D_follow', 'display': 'Camera2D_follow(instance, smoothing)', 'doc': 'Smoothly follows an instance', 'category': 'PGSL'},
            {'text': 'Camera2D_shake', 'display': 'Camera2D_shake(amount, duration)', 'doc': 'Screen shake effect', 'category': 'PGSL'},
            {'text': 'Camera3D_set_position', 'display': 'Camera3D_set_position(x, y, z)', 'doc': 'Sets camera location', 'category': 'PGSL'},
            {'text': 'Camera3D_set_target', 'display': 'Camera3D_set_target(x, y, z)', 'doc': 'Sets camera look-at target', 'category': 'PGSL'},
            {'text': 'Camera3D_set_angle', 'display': 'Camera3D_set_angle(pitch, yaw, roll)', 'doc': 'Rotates camera', 'category': 'PGSL'},
            {'text': 'Camera3D_follow', 'display': 'Camera3D_follow(id, distance, pitch, yaw)', 'doc': 'Chase-camera mode', 'category': 'PGSL'},
            {'text': 'Camera3D_shake', 'display': 'Camera3D_shake(amount, duration)', 'doc': '3D camera shake', 'category': 'PGSL'},
            {'text': 'Viewport_create', 'display': 'Viewport_create(name, x1, y1, x2, y2)', 'doc': 'Creates a screen region', 'category': 'PGSL'},
            {'text': 'Viewport_set_camera', 'display': 'Viewport_set_camera(name, camID)', 'doc': 'Binds camera to viewport', 'category': 'PGSL'},
            {'text': 'Viewport_activate', 'display': 'Viewport_activate(name)', 'doc': 'Sets active viewport', 'category': 'PGSL'},
            
            # Input & Audio
            {'text': 'key_check', 'display': 'key_check(key)', 'doc': 'True while the key is held', 'category': 'PGSL'},
            {'text': 'key_pressed', 'display': 'key_pressed(key)', 'doc': 'True only on initial press', 'category': 'PGSL'},
            {'text': 'key_released', 'display': 'key_released(key)', 'doc': 'True only on release', 'category': 'PGSL'},
            {'text': 'mouse_position', 'display': 'mouse_position()', 'doc': 'Returns (mx, my)', 'category': 'PGSL'},
            {'text': 'mouse_delta', 'display': 'mouse_delta()', 'doc': 'Returns (dx, dy) since last frame', 'category': 'PGSL'},
            {'text': 'mouse_button_check', 'display': 'mouse_button_check(button)', 'doc': 'True while held', 'category': 'PGSL'},
            {'text': 'mouse_button_pressed', 'display': 'mouse_button_pressed(button)', 'doc': 'True on click', 'category': 'PGSL'},
            {'text': 'Input_bind', 'display': 'Input_bind(action, key)', 'doc': 'Maps an action to a key', 'category': 'PGSL'},
            {'text': 'Input_check', 'display': 'Input_check(action)', 'doc': 'True if bound action is held', 'category': 'PGSL'},
            {'text': 'Input_pressed', 'display': 'Input_pressed(action)', 'doc': 'True on the frame of press', 'category': 'PGSL'},
            {'text': 'sound_play', 'display': 'sound_play(sound, loops)', 'doc': 'Plays a sound. Loops = -1 for infinite', 'category': 'PGSL'},
            {'text': 'sound_stop', 'display': 'sound_stop(sound)', 'doc': 'Stops one sound', 'category': 'PGSL'},
            {'text': 'sound_stop_all', 'display': 'sound_stop_all()', 'doc': 'Stops all sounds', 'category': 'PGSL'},
            {'text': 'sound_pause', 'display': 'sound_pause(sound)', 'doc': 'Pauses a sound', 'category': 'PGSL'},
            {'text': 'sound_pause_all', 'display': 'sound_pause_all()', 'doc': 'Pauses everything', 'category': 'PGSL'},
            {'text': 'sound_resume', 'display': 'sound_resume(sound)', 'doc': 'Resumes a paused sound', 'category': 'PGSL'},
            {'text': 'sound_resume_all', 'display': 'sound_resume_all()', 'doc': 'Resumes everything', 'category': 'PGSL'},
            {'text': 'sound_is_active', 'display': 'sound_is_active(sound)', 'doc': 'Checks if sound is playing', 'category': 'PGSL'},
        ]
        return commands
    
    def get_all_completions(self) -> List[Dict[str, str]]:
        """Get all available completions"""
        all_completions = []
        all_completions.extend(self.pgsl_commands)
        all_completions.extend(self.python_keywords)
        all_completions.extend(self.custom_completions)
        return all_completions
    
    def add_custom_completion(self, text: str, display: str = None, doc: str = "", category: str = "Custom"):
        """Add a custom completion (e.g., object variable)"""
        self.custom_completions.append({
            'text': text,
            'display': display or text,
            'doc': doc,
            'category': category
        })
    
    def clear_custom_completions(self):
        """Clear custom completions"""
        self.custom_completions.clear()

