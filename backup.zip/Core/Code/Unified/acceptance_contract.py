"""
Code Acceptance Contract
Defines what code can be accepted by the editor based on mode and context.

This interface allows Nova (and other code generators) to check if code
will be accepted before generating it.

Strategic Purpose:
- Prevents Nova from generating illegal code
- Simplifies Nova prompts
- Makes Simple/Advanced mode airtight
- Reduces hallucinations
"""

from typing import Tuple, List, Optional
from enum import Enum

from Core.Code.Unified.types import CodeMode, EditorContext
from Core.Code.Unified.validation_pipeline import UnifiedValidationPipeline, Diagnostic


class AcceptanceResult:
    """Result of code acceptance check"""
    
    def __init__(
        self,
        can_accept: bool,
        reason: Optional[str] = None,
        errors: Optional[List[Diagnostic]] = None,
        warnings: Optional[List[Diagnostic]] = None
    ):
        self.can_accept = can_accept
        self.reason = reason
        self.errors = errors or []
        self.warnings = warnings or []
    
    def to_dict(self) -> dict:
        """Convert to dictionary"""
        return {
            'can_accept': self.can_accept,
            'reason': self.reason,
            'error_count': len(self.errors),
            'warning_count': len(self.warnings)
        }


class CodeAcceptanceContract:
    """
    Contract that defines what code can be accepted by UnifiedCodeEditor.
    
    Nova uses this before generating code to ensure it will be accepted.
    """
    
    def __init__(self, project_path=None):
        """
        Initialize acceptance contract.
        
        Args:
            project_path: Optional project path for validation context
        """
        self.validator = UnifiedValidationPipeline(project_path)
    
    def can_accept(
        self,
        code: str,
        mode: CodeMode,
        context: EditorContext,
        strict: bool = True
    ) -> AcceptanceResult:
        """
        Check if code can be accepted by the editor.
        
        Args:
            code: Code string to check
            mode: CodeMode.PGSL or CodeMode.PYTHON
            context: EditorContext (SCRIPT, OBJECT_EVENT, etc.)
            strict: If True, warnings also prevent acceptance
        
        Returns:
            AcceptanceResult with can_accept, reason, errors, warnings
        """
        if not code or not code.strip():
            return AcceptanceResult(
                can_accept=True,
                reason="Empty code is always acceptable"
            )
        
        # Validate code
        is_valid, errors, warnings = self.validator.validate(
            code,
            mode,
            context=context.value
        )
        
        # Check if code can be accepted
        if not is_valid:
            return AcceptanceResult(
                can_accept=False,
                reason=f"Code has {len(errors)} syntax error(s)",
                errors=errors,
                warnings=warnings
            )
        
        if strict and warnings:
            return AcceptanceResult(
                can_accept=False,
                reason=f"Code has {len(warnings)} warning(s) (strict mode)",
                errors=errors,
                warnings=warnings
            )
        
        # Code is acceptable
        return AcceptanceResult(
            can_accept=True,
            reason="Code is valid and acceptable",
            errors=errors,
            warnings=warnings
        )
    
    def check_mode_compatibility(
        self,
        code: str,
        requested_mode: CodeMode,
        advanced_mode_enabled: bool
    ) -> Tuple[bool, Optional[str]]:
        """
        Check if requested mode is compatible with Advanced Mode setting.
        
        Args:
            code: Code string (may be used for detection)
            requested_mode: CodeMode being requested
            advanced_mode_enabled: Whether Advanced Mode is enabled
        
        Returns:
            (is_compatible, reason_if_not)
        """
        if requested_mode == CodeMode.PGSL:
            # PGSL is always allowed
            return (True, None)
        
        if requested_mode == CodeMode.PYTHON:
            if not advanced_mode_enabled:
                return (
                    False,
                    "Python mode requires Advanced Mode to be enabled in Preferences"
                )
            return (True, None)
        
        return (False, f"Unknown mode: {requested_mode}")
    
    def suggest_mode(
        self,
        code: str,
        advanced_mode_enabled: bool
    ) -> CodeMode:
        """
        Suggest appropriate mode for code.
        
        This is a simple heuristic - can be enhanced later.
        
        Args:
            code: Code string to analyze
            advanced_mode_enabled: Whether Advanced Mode is enabled
        
        Returns:
            Suggested CodeMode
        """
        # Simple heuristic: Check for PGSL-specific syntax
        pgsl_indicators = [
            'variable_set', 'variable_get',
            'create_instance', 'instance_destroy',
            'draw_sprite_2d', 'draw_text_2d',
            'camera2d_set_position', 'camera3d_set_position',
            'sound_play', 'key_check',
        ]
        
        code_lower = code.lower()
        has_pgsl_syntax = any(indicator in code_lower for indicator in pgsl_indicators)
        
        if has_pgsl_syntax:
            return CodeMode.PGSL
        
        # Default to Python if Advanced Mode enabled, otherwise PGSL
        if advanced_mode_enabled:
            return CodeMode.PYTHON
        else:
            return CodeMode.PGSL
    
    def validate_for_nova(
        self,
        code: str,
        mode: CodeMode,
        context: EditorContext,
        advanced_mode_enabled: bool
    ) -> AcceptanceResult:
        """
        Validate code specifically for Nova code generation.
        
        This is the method Nova should call before generating code.
        
        Args:
            code: Code string to validate
            mode: CodeMode being used
            context: EditorContext
            advanced_mode_enabled: Whether Advanced Mode is enabled
        
        Returns:
            AcceptanceResult with detailed feedback
        """
        # First check mode compatibility
        is_compatible, reason = self.check_mode_compatibility(
            code, mode, advanced_mode_enabled
        )
        
        if not is_compatible:
            return AcceptanceResult(
                can_accept=False,
                reason=reason
            )
        
        # Then check code validity
        return self.can_accept(code, mode, context, strict=True)

