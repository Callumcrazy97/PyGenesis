"""
Unified Code Editor System
Shared code editor for all PyGenesis editors (Script, Object, Shader, Particle, etc.)

Phase 1: Editor Shell + Mode Management ✅
Phase 2: Unified Validation Pipeline ✅
Phase 3: Sandboxed Test Execution (Next)
"""

from .types import EditorContext, CodeMode
from .unified_code_editor import (
    UnifiedCodeEditor, 
    DiagnosticsPanel
)
from .validation_pipeline import (
    UnifiedValidationPipeline,
    Diagnostic,
    DiagnosticType
)
from .execution_engine import (
    SandboxedExecutionEngine,
    ExecutionResult
)
from .acceptance_contract import (
    CodeAcceptanceContract,
    AcceptanceResult
)

__all__ = [
    'UnifiedCodeEditor',
    'EditorContext',
    'CodeMode',
    'DiagnosticsPanel',
    'UnifiedValidationPipeline',
    'Diagnostic',
    'DiagnosticType',
    'SandboxedExecutionEngine',
    'ExecutionResult',
    'CodeAcceptanceContract',
    'AcceptanceResult'
]

