"""
Standalone Test Harness for UnifiedCodeEditor

This is a temporary test window to verify UnifiedCodeEditor works correctly
before migrating any editors.

DO NOT integrate this into production - it's for testing only.
"""

from PySide6.QtWidgets import QMainWindow, QVBoxLayout, QWidget, QLabel, QPushButton, QTextEdit
from PySide6.QtCore import Qt

from Core.Code.Unified import UnifiedCodeEditor, EditorContext, CodeMode


class UnifiedEditorTest(QMainWindow):
    """Standalone test window for UnifiedCodeEditor"""
    
    def __init__(self, app):
        super().__init__()
        self.app = app
        self.setWindowTitle("UnifiedCodeEditor Test Harness")
        self.resize(1000, 700)
        
        # Create central widget
        central = QWidget()
        layout = QVBoxLayout(central)
        layout.setContentsMargins(10, 10, 10, 10)
        
        # Title
        title = QLabel("UnifiedCodeEditor Test Harness")
        title.setStyleSheet("font-size: 16pt; font-weight: bold; padding: 10px;")
        layout.addWidget(title)
        
        # Info label
        info = QLabel(
            "This is a test window to verify UnifiedCodeEditor works correctly.\n"
            "Test: mode switching, validation, test execution, diagnostics display."
        )
        info.setWordWrap(True)
        info.setStyleSheet("color: #888; padding: 5px;")
        layout.addWidget(info)
        
        # Create editor
        self.editor = UnifiedCodeEditor(
            app,
            context=EditorContext.SCRIPT
        )
        
        # Connect signals for testing
        self.editor.code_changed.connect(self._on_code_changed)
        self.editor.mode_changed.connect(self._on_mode_changed)
        self.editor.validation_complete.connect(self._on_validation_complete)
        
        layout.addWidget(self.editor, stretch=1)
        
        # Test controls
        controls = QWidget()
        controls_layout = QVBoxLayout(controls)
        
        # Test buttons
        test_label = QLabel("Test Controls:")
        test_label.setStyleSheet("font-weight: bold; padding: 5px;")
        controls_layout.addWidget(test_label)
        
        # Mode info
        self.mode_info = QLabel("Current Mode: PGSL")
        controls_layout.addWidget(self.mode_info)
        
        # Code info
        self.code_info = QLabel("Code Length: 0 characters")
        controls_layout.addWidget(self.code_info)
        
        # Validation info
        self.validation_info = QLabel("Validation: Not run")
        controls_layout.addWidget(self.validation_info)
        
        # Test code samples
        samples_label = QLabel("Test Samples:")
        samples_label.setStyleSheet("font-weight: bold; padding: 5px;")
        controls_layout.addWidget(samples_label)
        
        # Python sample
        python_sample_btn = QPushButton("Load Python Sample")
        python_sample_btn.clicked.connect(self._load_python_sample)
        controls_layout.addWidget(python_sample_btn)
        
        # PGSL sample
        pgsl_sample_btn = QPushButton("Load PGSL Sample")
        pgsl_sample_btn.clicked.connect(self._load_pgsl_sample)
        controls_layout.addWidget(pgsl_sample_btn)
        
        # Invalid sample
        invalid_sample_btn = QPushButton("Load Invalid Sample (for error testing)")
        invalid_sample_btn.clicked.connect(self._load_invalid_sample)
        controls_layout.addWidget(invalid_sample_btn)
        
        layout.addWidget(controls)
        
        self.setCentralWidget(central)
    
    def _on_code_changed(self):
        """Handle code changes"""
        code = self.editor.get_code()
        self.code_info.setText(f"Code Length: {len(code)} characters")
    
    def _on_mode_changed(self, mode: CodeMode):
        """Handle mode changes"""
        self.mode_info.setText(f"Current Mode: {mode.value.upper()}")
    
    def _on_validation_complete(self, is_valid: bool, errors: list, warnings: list):
        """Handle validation completion"""
        if is_valid:
            self.validation_info.setText(
                f"Validation: ✅ Passed (0 errors, {len(warnings)} warnings)"
            )
        else:
            self.validation_info.setText(
                f"Validation: ❌ Failed ({len(errors)} errors, {len(warnings)} warnings)"
            )
    
    def _load_python_sample(self):
        """Load a Python code sample"""
        sample = """# Python Sample Code
def greet(name):
    return f"Hello, {name}!"

def calculate(x, y):
    result = x + y
    print(f"{x} + {y} = {result}")
    return result

# Test the functions
greet("World")
calculate(5, 3)
"""
        self.editor.set_code(sample)
    
    def _load_pgsl_sample(self):
        """Load a PGSL code sample"""
        sample = """# PGSL Sample Code
# This is a simple PGSL example
if true:
    print("Hello from PGSL")
    variable_set("count", 10)
"""
        self.editor.set_code(sample)
        # Ensure mode is PGSL
        self.editor.set_mode(CodeMode.PGSL)
    
    def _load_invalid_sample(self):
        """Load invalid code for error testing"""
        sample = """# Invalid Code Sample
def broken_function(
    # Missing closing parenthesis
    x = 10
    return x  # Syntax error
"""
        self.editor.set_code(sample)


def create_test_window(app):
    """Create and return test window"""
    window = UnifiedEditorTest(app)
    return window

