"""
Type definitions for UnifiedCodeEditor
Separated to avoid circular imports.
"""

from enum import Enum


class EditorContext(Enum):
    """Context mode for the editor - determines validation rules, autocomplete, etc."""
    SCRIPT = "script"
    OBJECT_EVENT = "object_event"
    SHADER = "shader"
    PARTICLE = "particle"


class CodeMode(Enum):
    """Code language mode"""
    PGSL = "pgsl"  # Simple Mode - PGSL only
    PYTHON = "python"  # Advanced Mode - Python allowed

