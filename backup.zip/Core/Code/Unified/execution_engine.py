"""
Sandboxed Execution Engine
Provides safe code execution for testing without file modifications.

Phase 3: Sandboxed Test Execution
- Test Highlighted Code
- Test Code (Full File)
- Output capture
- Error reporting
- No file modifications (read-only)
"""

from typing import Dict, List, Optional, Tuple, Any
from enum import Enum
import ast
import sys
import io
import traceback
from contextlib import redirect_stdout, redirect_stderr
from pathlib import Path

from Core.Code.Unified.types import CodeMode


class ExecutionResult:
    """Result of code execution"""
    
    def __init__(
        self,
        success: bool,
        output: str = "",
        error: Optional[str] = None,
        return_value: Any = None,
        variables: Optional[Dict[str, Any]] = None
    ):
        self.success = success
        self.output = output
        self.error = error
        self.return_value = return_value
        self.variables = variables or {}
    
    def to_dict(self) -> Dict:
        """Convert to dictionary"""
        return {
            'success': self.success,
            'output': self.output,
            'error': self.error,
            'return_value': str(self.return_value) if self.return_value is not None else None,
            'variables': {k: str(v) for k, v in self.variables.items()}
        }


class SandboxedExecutionEngine:
    """
    Sandboxed execution engine for testing code.
    
    Provides safe execution that:
    - Captures output
    - Captures errors
    - Does NOT modify files
    - Does NOT have side effects on the project
    - Is read-only
    """
    
    def __init__(self, project_path: Optional[Path] = None):
        """
        Initialize execution engine.
        
        Args:
            project_path: Optional project path for context (not used for execution)
        """
        self.project_path = project_path
        self._restricted_modules = {
            'os', 'sys', 'subprocess', 'shutil', 'pathlib',
            'open', 'file', '__builtin__', 'builtins'
        }
    
    def execute(
        self,
        code: str,
        mode: CodeMode,
        context: Optional[str] = None
    ) -> ExecutionResult:
        """
        Execute code in sandboxed environment.
        
        Args:
            code: Code string to execute
            mode: CodeMode.PGSL or CodeMode.PYTHON
            context: Optional context string
        
        Returns:
            ExecutionResult with success, output, error, etc.
        """
        if not code or not code.strip():
            return ExecutionResult(
                success=True,
                output="No code to execute"
            )
        
        if mode == CodeMode.PGSL:
            # PGSL execution: First compile to Python, then execute
            return self._execute_pgsl(code, context)
        elif mode == CodeMode.PYTHON:
            # Python execution: Direct execution
            return self._execute_python(code, context)
        else:
            return ExecutionResult(
                success=False,
                error=f"Unknown code mode: {mode}"
            )
    
    def _execute_pgsl(self, code: str, context: Optional[str] = None) -> ExecutionResult:
        """
        Execute PGSL code.
        
        For Phase 3, PGSL execution is limited:
        - PGSL compiler is only 10% complete
        - We can only validate syntax, not execute
        - Future: Compile PGSL to Python, then execute
        """
        # Phase 3: PGSL execution not yet fully supported
        # For now, return a message indicating PGSL execution is not yet available
        return ExecutionResult(
            success=False,
            error="PGSL execution is not yet fully implemented. "
                  "PGSL compiler is only 10% complete. "
                  "You can validate PGSL syntax, but execution requires full compiler implementation."
        )
    
    def _execute_python(
        self, 
        code: str, 
        context: Optional[str] = None
    ) -> ExecutionResult:
        """
        Execute Python code in sandboxed environment.
        
        Safety measures:
        - Captures stdout/stderr
        - Prevents file operations (basic)
        - Captures exceptions
        - Returns execution state
        """
        # Capture output
        stdout_capture = io.StringIO()
        stderr_capture = io.StringIO()
        
        # Create isolated namespace
        namespace = {
            '__name__': '__main__',
            '__builtins__': self._get_safe_builtins(),
        }
        
        try:
            # Redirect stdout and stderr
            with redirect_stdout(stdout_capture), redirect_stderr(stderr_capture):
                # Compile code
                try:
                    compiled_code = compile(code, f"<{context or 'test'}>", 'exec')
                except SyntaxError as e:
                    return ExecutionResult(
                        success=False,
                        error=f"Syntax error: {e.msg} (line {e.lineno})",
                        output=stdout_capture.getvalue()
                    )
                
                # Execute in isolated namespace
                exec(compiled_code, namespace)
            
            # Get output
            stdout_output = stdout_capture.getvalue()
            stderr_output = stderr_capture.getvalue()
            
            # Combine outputs
            output = ""
            if stdout_output:
                output += stdout_output
            if stderr_output:
                output += f"\n[stderr]\n{stderr_output}"
            
            # Extract user-defined variables only (exclude built-ins, special names, and callables)
            variables = {}
            for k, v in namespace.items():
                # Skip special names starting with __
                if k.startswith('__'):
                    continue
                # Skip callables (functions, classes, etc.) unless they're user-defined simple types
                if callable(v) and not isinstance(v, (type, type(int), type(str))):
                    continue
                # Only include user-defined variables
                variables[k] = v
            
            # Get return value if code is an expression
            return_value = None
            try:
                # Try to evaluate as expression
                if code.strip() and not code.strip().startswith(('#', 'def ', 'class ', 'import ', 'from ')):
                    try:
                        return_value = eval(code.strip(), namespace)
                    except:
                        pass
            except:
                pass
            
            return ExecutionResult(
                success=True,
                output=output.strip() if output else "Code executed successfully (no output)",
                return_value=return_value,
                variables=variables
            )
            
        except Exception as e:
            # Capture exception
            error_msg = f"{type(e).__name__}: {str(e)}"
            error_traceback = traceback.format_exc()
            
            return ExecutionResult(
                success=False,
                output=stdout_capture.getvalue(),
                error=f"{error_msg}\n\n{error_traceback}"
            )
    
    def _get_safe_builtins(self) -> Dict:
        """
        Get safe builtins for sandboxed execution.
        
        Removes dangerous functions like:
        - open, file (file operations)
        - __import__ (module imports)
        - eval, exec (code execution)
        - etc.
        """
        import builtins
        
        safe_builtins = {
            # Safe built-in functions
            'abs', 'all', 'any', 'ascii', 'bin', 'bool', 'bytearray', 'bytes',
            'chr', 'dict', 'dir', 'divmod', 'enumerate', 'filter', 'float',
            'format', 'frozenset', 'getattr', 'hasattr', 'hash', 'hex',
            'id', 'int', 'isinstance', 'issubclass', 'iter', 'len', 'list',
            'map', 'max', 'min', 'next', 'oct', 'ord', 'pow', 'print',
            'range', 'repr', 'reversed', 'round', 'set', 'slice', 'sorted',
            'str', 'sum', 'tuple', 'type', 'vars', 'zip',
            
            # Safe constants
            'True', 'False', 'None', 'Ellipsis', 'NotImplemented',
            
            # Safe exceptions
            'Exception', 'BaseException', 'ValueError', 'TypeError',
            'AttributeError', 'NameError', 'KeyError', 'IndexError',
            'ZeroDivisionError', 'ArithmeticError',
        }
        
        safe_dict = {}
        for name in safe_builtins:
            if hasattr(builtins, name):
                safe_dict[name] = getattr(builtins, name)
        
        return safe_dict
    
    def test_code(
        self,
        code: str,
        mode: CodeMode,
        context: Optional[str] = None
    ) -> ExecutionResult:
        """
        Test code execution (alias for execute).
        
        This method exists for clarity - "test" implies read-only execution.
        """
        return self.execute(code, mode, context)

