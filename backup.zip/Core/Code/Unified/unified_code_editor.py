"""
Unified Code Editor
Shared code editor for all PyGenesis editors (Script, Object, Shader, Particle, etc.)

Phase 1: Editor Shell + Mode Management (No Execution)
- UnifiedCodeEditor widget
- Mode toggle (Simple / Advanced)
- Syntax highlighter switching
- Diagnostics panel (static/stub)
- Basic API surface
"""

from enum import Enum
from typing import Optional, List, Dict, Any
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QTextEdit, QPushButton, 
    QLabel, QFrame, QComboBox, QScrollArea, QMessageBox
)
from PySide6.QtCore import Qt, Signal, QTimer
from PySide6.QtGui import QFont, QTextCursor, QTextCharFormat, QColor, QSyntaxHighlighter
from PySide6.QtCore import QRegularExpression
from pathlib import Path

from .validation_pipeline import UnifiedValidationPipeline, Diagnostic
from .execution_engine import SandboxedExecutionEngine, ExecutionResult


# Import types from separate file to avoid circular imports
from .types import EditorContext, CodeMode


class DiagnosticsPanel(QWidget):
    """Diagnostics panel for displaying errors and warnings - collapsible"""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setup_ui()
        self._is_collapsed = True  # Start collapsed
    
    def setup_ui(self):
        """Setup the diagnostics UI"""
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)
        
        # Collapsible header button
        self.header_button = QPushButton("▼ Diagnostics")
        self.header_button.setStyleSheet("""
            QPushButton {
                background-color: #2b2b3d;
                border: 1px solid #3d3d5c;
                border-bottom: none;
                padding: 5px;
                text-align: left;
                font-weight: bold;
                font-size: 10pt;
                color: #ffffff;
            }
            QPushButton:hover {
                background-color: #353548;
            }
        """)
        self.header_button.clicked.connect(self._toggle_collapse)
        layout.addWidget(self.header_button)
        
        # Diagnostics area container (collapsed by default)
        self.diagnostics_container = QWidget()
        self.diagnostics_container.setVisible(False)
        container_layout = QVBoxLayout(self.diagnostics_container)
        container_layout.setContentsMargins(5, 5, 5, 5)
        
        # Diagnostics area
        self.diagnostics_area = QTextEdit()
        self.diagnostics_area.setReadOnly(True)
        self.diagnostics_area.setMaximumHeight(100)  # Smaller when expanded
        self.diagnostics_area.setPlaceholderText("No diagnostics yet...")
        self.diagnostics_area.setStyleSheet("""
            QTextEdit {
                background-color: #1e1e1e;
                color: #cccccc;
                border: 1px solid #3d3d3d;
                font-family: Consolas;
                font-size: 9pt;
            }
        """)
        container_layout.addWidget(self.diagnostics_area)
        layout.addWidget(self.diagnostics_container)
    
    def _toggle_collapse(self):
        """Toggle collapsed/expanded state"""
        self._is_collapsed = not self._is_collapsed
        self.diagnostics_container.setVisible(not self._is_collapsed)
        if self._is_collapsed:
            self.header_button.setText("▼ Diagnostics")
        else:
            self.header_button.setText("▲ Diagnostics")
    
    def set_diagnostics(self, errors: List[Dict], warnings: List[Dict]):
        """Set diagnostics to display and auto-expand if there are issues"""
        self.diagnostics_area.clear()
        
        if not errors and not warnings:
            self.diagnostics_area.setPlainText("✅ No errors or warnings")
            # Keep collapsed if no issues
            if not self._is_collapsed:
                self._toggle_collapse()
            return
        
        # Auto-expand if there are errors or warnings
        if self._is_collapsed:
            self._toggle_collapse()
        
        lines = []
        
        if errors:
            lines.append(f"❌ Errors ({len(errors)}):")
            for error in errors:
                line = error.get('line', 0)
                message = error.get('message', str(error))
                lines.append(f"  Line {line}: {message}")
            lines.append("")
        
        if warnings:
            lines.append(f"⚠️ Warnings ({len(warnings)}):")
            for warning in warnings:
                line = warning.get('line', 0)
                message = warning.get('message', str(warning))
                lines.append(f"  Line {line}: {message}")
        
        self.diagnostics_area.setPlainText("\n".join(lines))


class BasicSyntaxHighlighter(QSyntaxHighlighter):
    """Basic syntax highlighter (Phase 1: Placeholder - will be replaced with proper highlighters)"""
    
    def __init__(self, parent=None, mode: CodeMode = CodeMode.PGSL):
        super().__init__(parent)
        self.mode = mode
        self.setup_highlighting()
    
    def setup_highlighting(self):
        """Setup basic highlighting rules"""
        # Comments (support both # and //)
        comment_format = QTextCharFormat()
        comment_format.setForeground(QColor("#6a9955"))
        comment_format.setFontItalic(True)
        # Support both Python (#) and PGSL (//) comments
        if self.mode == CodeMode.PGSL:
            comment_pattern = QRegularExpression(r'//.*')
        else:
            comment_pattern = QRegularExpression(r'#.*')
        self.comment_format = comment_format
        self.comment_pattern = comment_pattern
        
        # Strings (same for both modes)
        string_format = QTextCharFormat()
        string_format.setForeground(QColor("#ce9178"))
        string_pattern = QRegularExpression(r'"[^"]*"|\'[^\']*\'')
        self.string_format = string_format
        self.string_pattern = string_pattern
        
        # Numbers (same for both modes)
        number_format = QTextCharFormat()
        number_format.setForeground(QColor("#b5cea8"))
        number_pattern = QRegularExpression(r'\b\d+\.?\d*\b')
        self.number_format = number_format
        self.number_pattern = number_pattern
    
    def highlightBlock(self, text: str):
        """Apply highlighting to a block of text"""
        # Ensure attributes are initialized (defensive check)
        if not hasattr(self, 'comment_pattern') or not self.comment_pattern:
            self.setup_highlighting()
        
        # Comments
        if hasattr(self, 'comment_pattern') and self.comment_pattern:
            iterator = self.comment_pattern.globalMatch(text)
            while iterator.hasNext():
                match = iterator.next()
                self.setFormat(match.capturedStart(), match.capturedLength(), self.comment_format)
        
        # Strings
        if hasattr(self, 'string_pattern') and self.string_pattern:
            iterator = self.string_pattern.globalMatch(text)
            while iterator.hasNext():
                match = iterator.next()
                self.setFormat(match.capturedStart(), match.capturedLength(), self.string_format)
        
        # Numbers
        if hasattr(self, 'number_pattern') and self.number_pattern:
            iterator = self.number_pattern.globalMatch(text)
            while iterator.hasNext():
                match = iterator.next()
                self.setFormat(match.capturedStart(), match.capturedLength(), self.number_format)


class UnifiedCodeEditor(QWidget):
    """
    Unified Code Editor - Phase 1
    Shared code editor for all PyGenesis editors.
    
    Phase 1 Features:
    - Editor widget with syntax highlighting
    - Mode toggle (Simple / Advanced)
    - Syntax highlighter switching
    - Diagnostics panel (static/stub)
    - Basic API surface
    
    Phase 1 Does NOT Include:
    - Parsing
    - Execution
    - Nova hooks
    """
    
    # Signals
    code_changed = Signal()
    mode_changed = Signal(CodeMode)
    validation_complete = Signal(bool, list, list)  # is_valid, errors, warnings
    
    def __init__(
        self, 
        app, 
        context: EditorContext = EditorContext.SCRIPT,
        parent=None
    ):
        super().__init__(parent)
        self.app = app
        self.context = context
        self._dirty = False
        self._updating_highlighter = False  # Prevent recursion
        self._highlighter_update_timer = QTimer()
        self._highlighter_update_timer.setSingleShot(True)
        self._highlighter_update_timer.timeout.connect(self._update_highlighter_debounced)
        
        # Get Advanced Mode setting
        self.advanced_mode_enabled = self._get_advanced_mode_setting()
        
        # No explicit mode - will auto-detect based on code content
        # Advanced Mode ON = supports both PGSL and Python
        # Advanced Mode OFF = PGSL only
        
        # Initialize components
        self.highlighter: Optional[QSyntaxHighlighter] = None
        self.diagnostics: List[Dict] = []
        self.warnings: List[Dict] = []
        
        # Initialize validation pipeline
        project_path = None
        if hasattr(app, 'project_manager') and hasattr(app.project_manager, 'get_project_path'):
            project_path = Path(app.project_manager.get_project_path())
        self.validator = UnifiedValidationPipeline(project_path)
        
        # Initialize execution engine (Phase 3)
        self.execution_engine = SandboxedExecutionEngine(project_path)
        
        # Real-time validation (optional, disabled by default)
        self.real_time_validation = False
        self.validation_timer = QTimer()
        self.validation_timer.setSingleShot(True)
        self.validation_timer.timeout.connect(self._perform_validation)
        
        self._build_ui()
        # Initial highlighter setup (no debounce, no recursion protection needed)
        self._update_highlighter_initial()
    
    def _get_advanced_mode_setting(self) -> bool:
        """Get Advanced Mode setting from preferences"""
        if hasattr(self.app, 'settings'):
            return self.app.settings.get("Advanced_Mode", False)
        return False
    
    def _build_ui(self):
        """Build the UI"""
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)
        
        # Toolbar
        toolbar = self._build_toolbar()
        layout.addWidget(toolbar)
        
        # Code editor area
        editor_container = QWidget()
        editor_layout = QVBoxLayout(editor_container)
        editor_layout.setContentsMargins(0, 0, 0, 0)
        
        # Code editor
        self.code_editor = QTextEdit()
        self.code_editor.setFont(QFont("Consolas", 10))
        self.code_editor.textChanged.connect(self._on_text_changed)
        self.code_editor.setStyleSheet("""
            QTextEdit {
                background-color: #1e1e1e;
                color: #d4d4d4;
                border: 1px solid #3d3d3d;
                selection-background-color: #264f78;
            }
        """)
        
        # Initialize syntax highlighter (initial setup, no debounce needed)
        # Will be set up after _build_ui completes
        
        editor_layout.addWidget(self.code_editor)
        layout.addWidget(editor_container, stretch=1)
        
        # Diagnostics panel (Phase 1: Static/Stub)
        self.diagnostics_panel = DiagnosticsPanel()
        layout.addWidget(self.diagnostics_panel)
    
    def _build_toolbar(self) -> QFrame:
        """Build the toolbar with mode toggle and buttons"""
        toolbar = QFrame()
        toolbar.setFrameShape(QFrame.StyledPanel)
        toolbar.setStyleSheet("""
            QFrame {
                background-color: #252526;
                border-bottom: 1px solid #3d3d3d;
                padding: 5px;
            }
        """)
        toolbar_layout = QHBoxLayout(toolbar)
        toolbar_layout.setContentsMargins(10, 5, 10, 5)
        toolbar_layout.setSpacing(10)
        
        # Mode is auto-detected based on code content
        # Advanced Mode ON = supports both PGSL and Python
        # Advanced Mode OFF = PGSL only
        # No mode toggle - controlled by Preferences only
        
        toolbar_layout.addStretch()
        
        # Check Selected button (Phase 2)
        self.check_selected_button = QPushButton("Check Selected")
        self.check_selected_button.setToolTip("Check only the selected/highlighted code")
        self.check_selected_button.clicked.connect(self.check_selected_code)
        toolbar_layout.addWidget(self.check_selected_button)
        
        # Check Full button (Phase 2)
        self.check_full_button = QPushButton("Check Full")
        self.check_full_button.setToolTip("Check the entire code")
        self.check_full_button.clicked.connect(self.check_full_code)
        toolbar_layout.addWidget(self.check_full_button)
        
        # Test Selected button (Phase 3)
        self.test_selected_button = QPushButton("Test Selected")
        self.test_selected_button.setToolTip("Test the selected code (runs in sandbox, no file changes)")
        self.test_selected_button.clicked.connect(self.test_selected_code)
        toolbar_layout.addWidget(self.test_selected_button)
        
        # Test Code button (Phase 3)
        self.test_code_button = QPushButton("Test Code")
        self.test_code_button.setToolTip("Test the entire code file (runs in sandbox, no file changes)")
        self.test_code_button.clicked.connect(self.test_code)
        toolbar_layout.addWidget(self.test_code_button)
        
        # Status label
        self.status_label = QLabel("Ready")
        self.status_label.setStyleSheet("color: #cccccc;")
        toolbar_layout.addWidget(self.status_label)
        
        return toolbar
    
    def _update_mode_ui(self):
        """Update UI based on Advanced Mode setting"""
        # Mode is auto-detected, no UI changes needed
        # Highlighter will be updated when code changes
        pass
    
    def _update_highlighter_initial(self):
        """Initial highlighter setup (no debounce, no recursion protection needed)"""
        # This is called only once during initialization
        try:
            code = self.code_editor.toPlainText()
            detected_mode = self._detect_code_mode(code)
            
            # Create initial highlighter
            try:
                if detected_mode == CodeMode.PGSL:
                    from Core.CodeSystem.syntax import SyntaxHighlighter as PGSLSyntaxHighlighter
                    self.highlighter = PGSLSyntaxHighlighter(self.code_editor.document())
                else:
                    from Core.Code.Base.base_syntax_highlighter import PythonSyntaxHighlighter
                    self.highlighter = PythonSyntaxHighlighter(self.code_editor.document())
            except Exception:
                # Fallback to basic highlighter
                self.highlighter = BasicSyntaxHighlighter(
                    self.code_editor.document(),
                    mode=detected_mode
                )
        except Exception:
            # Last resort
            self.highlighter = None
    
    def _detect_code_mode(self, code: str) -> CodeMode:
        """
        Auto-detect code mode based on content.
        
        Uses PGSL_Commands.py to get accurate PGSL command list.
        
        Args:
            code: Code string to analyze
            
        Returns:
            Detected CodeMode (PGSL or PYTHON)
        """
        if not code or not code.strip():
            # Empty code - default based on Advanced Mode
            return CodeMode.PGSL if not self.advanced_mode_enabled else CodeMode.PYTHON
        
        # If Advanced Mode is OFF, only PGSL is allowed
        if not self.advanced_mode_enabled:
            return CodeMode.PGSL
        
        # Advanced Mode ON - detect which language
        code_lower = code.lower()
        
        # Get PGSL commands from PGSL_Commands.py
        try:
            from Core.Code.PGSL.PGSL_Commands import get_all_command_names
            pgsl_commands = get_all_command_names()
            # Convert to lowercase for matching
            pgsl_commands_lower = [cmd.lower() for cmd in pgsl_commands]
        except Exception:
            # Fallback to hardcoded list if import fails
            pgsl_commands_lower = [
                'variable_set', 'variable_get', 'variable_exists',
                'create_instance', 'instance_destroy', 'instance_find',
                'draw_sprite_2d', 'draw_text_2d', 'draw_self_2d', 'draw_self_3d',
                'camera2d_set_position', 'camera3d_set_position',
                'sound_play', 'key_check',
                'game_end', 'game_save', 'game_load',
            ]
        
        # Check for PGSL commands (with parentheses or as identifiers)
        import re
        for cmd in pgsl_commands_lower:
            # Check for command with parentheses: "variable_set(" or "Variable_set("
            if re.search(rf'\b{re.escape(cmd)}\s*\(', code_lower, re.IGNORECASE):
                return CodeMode.PGSL
            # Check for command as identifier: "variable_set" at word boundary
            if re.search(rf'\b{re.escape(cmd)}\b', code_lower, re.IGNORECASE):
                return CodeMode.PGSL
        
        # Check for Python-specific syntax (def, class, import, etc.)
        python_indicators = [
            r'\bdef\s+\w+',  # Function definition
            r'\bclass\s+\w+',  # Class definition
            r'\bimport\s+\w+',  # Import statement
            r'\bfrom\s+\w+\s+import',  # From import
        ]
        
        has_python_syntax = any(re.search(pattern, code_lower) for pattern in python_indicators)
        
        if has_python_syntax:
            return CodeMode.PYTHON
        
        # Check for PGSL-style comments (//) vs Python-style (#)
        # If code has // comments but no # comments, likely PGSL
        has_pgsl_comment = '//' in code
        has_python_comment = '#' in code and not code.strip().startswith('#')
        
        if has_pgsl_comment and not has_python_comment:
            return CodeMode.PGSL
        
        # Default: If Advanced Mode ON, assume Python; otherwise PGSL
        return CodeMode.PYTHON if self.advanced_mode_enabled else CodeMode.PGSL
    
    def _update_highlighter(self):
        """Update syntax highlighter based on detected mode"""
        # Prevent recursion
        if self._updating_highlighter:
            return
        
        self._updating_highlighter = True
        try:
            # Block signals to prevent recursion when reading code
            self.code_editor.blockSignals(True)
            try:
                code = self.code_editor.toPlainText()
                detected_mode = self._detect_code_mode(code)
            finally:
                self.code_editor.blockSignals(False)
            
            # Remove old highlighter safely (block signals during removal)
            old_highlighter = None
            if self.highlighter:
                old_highlighter = self.highlighter
                self.highlighter = None
                try:
                    old_highlighter.setDocument(None)
                except Exception:
                    pass
        
            # Create new highlighter (block signals during creation)
            self.code_editor.blockSignals(True)
            try:
                highlighter_created = False
                try:
                    if detected_mode == CodeMode.PGSL:
                        # Try to use CodeSystem PGSL highlighter
                        from Core.CodeSystem.syntax import SyntaxHighlighter as PGSLSyntaxHighlighter
                        self.highlighter = PGSLSyntaxHighlighter(self.code_editor.document())
                        highlighter_created = True
                except Exception:
                    pass
                
                if not highlighter_created:
                    try:
                        # Try Python highlighter
                        from Core.Code.Base.base_syntax_highlighter import PythonSyntaxHighlighter
                        self.highlighter = PythonSyntaxHighlighter(self.code_editor.document())
                        highlighter_created = True
                    except Exception:
                        pass
                
                # Fallback to basic highlighter
                if not highlighter_created:
                    try:
                        self.highlighter = BasicSyntaxHighlighter(
                            self.code_editor.document(),
                            mode=detected_mode
                        )
                    except Exception:
                        # Last resort: create minimal highlighter
                        self.highlighter = None
            finally:
                self.code_editor.blockSignals(False)
        
        finally:
            self._updating_highlighter = False
    
    def _on_text_changed(self):
        """Handle text changes"""
        # Prevent recursion
        if self._updating_highlighter:
            return
        
        self._dirty = True
        self.code_changed.emit()
        
        # Update highlighter based on new code content (with debounce)
        # Debounce to prevent excessive updates and recursion
        self._highlighter_update_timer.stop()
        self._highlighter_update_timer.start(300)  # 300ms debounce
        
        # Real-time validation (if enabled)
        if self.real_time_validation:
            self.validation_timer.stop()
            self.validation_timer.start(500)  # 500ms delay
    
    def _update_highlighter_debounced(self):
        """Debounced version of _update_highlighter"""
        if not self._updating_highlighter:
            self._update_highlighter()
    
    # ------------------------------------------------------------------
    # Public API - Code Management
    # ------------------------------------------------------------------
    
    def get_code(self) -> str:
        """Get the current code content"""
        return self.code_editor.toPlainText()
    
    def set_code(self, code: str, suppress_signals: bool = False):
        """
        Set the code content
        
        Args:
            code: The code string to set
            suppress_signals: If True, don't emit code_changed signal
        """
        if suppress_signals:
            self.code_editor.blockSignals(True)
        self.code_editor.setPlainText(code)
        if suppress_signals:
            self.code_editor.blockSignals(False)
        self._dirty = True
    
    def get_selected_code(self) -> str:
        """Get the currently selected/highlighted code"""
        cursor = self.code_editor.textCursor()
        selected = cursor.selectedText()
        
        # QTextEdit.selectedText() uses paragraph separators (\u2029) instead of newlines
        selected = selected.replace('\u2029', '\n')
        
        # Clean non-printable characters
        selected = ''.join(
            char for char in selected 
            if char.isprintable() or char in ['\n', '\r', '\t']
        )
        
        return selected
    
    def clear_editor(self):
        """Clear the editor"""
        self.code_editor.clear()
        self._dirty = False
        self.diagnostics = []
        self.warnings = []
        self.diagnostics_panel.set_diagnostics([], [])
    
    def is_dirty(self) -> bool:
        """Check if there are unsaved changes"""
        return self._dirty
    
    def set_dirty(self, dirty: bool):
        """Set dirty state"""
        self._dirty = dirty
    
    # ------------------------------------------------------------------
    # Public API - Diagnostics (Phase 1: Stub)
    # ------------------------------------------------------------------
    
    def set_diagnostics(self, errors: List[Dict], warnings: List[Dict]):
        """
        Set diagnostics to display
        
        Args:
            errors: List of error dictionaries with 'line', 'message', etc.
            warnings: List of warning dictionaries with 'line', 'message', etc.
        """
        self.diagnostics = errors
        self.warnings = warnings
        self.diagnostics_panel.set_diagnostics(errors, warnings)
    
    def get_diagnostics(self) -> tuple[List[Dict], List[Dict]]:
        """Get current diagnostics"""
        return (self.diagnostics, self.warnings)
    
    def clear_diagnostics(self):
        """Clear diagnostics"""
        self.diagnostics = []
        self.warnings = []
        self.diagnostics_panel.set_diagnostics([], [])
    
    # ------------------------------------------------------------------
    # Public API - Mode Management
    # ------------------------------------------------------------------
    
    def get_mode(self) -> CodeMode:
        """Get current detected code mode"""
        code = self.get_code()
        return self._detect_code_mode(code)
    
    def set_mode(self, mode: CodeMode):
        """Set code mode - deprecated, mode is now auto-detected"""
        # Mode is now auto-detected based on code content
        # This method is kept for API compatibility but does nothing
        pass
    
    def get_context(self) -> EditorContext:
        """Get editor context"""
        return self.context
    
    def set_status(self, message: str):
        """Set status message"""
        self.status_label.setText(message)
    
    # ------------------------------------------------------------------
    # Public API - Validation (Phase 2)
    # ------------------------------------------------------------------
    
    def _output_to_terminal(self, message: str):
        """Output message to terminal widget"""
        if hasattr(self.app, 'main_window') and hasattr(self.app.main_window, 'terminal_widget'):
            self.app.main_window.terminal_widget.append_text(message)
        else:
            print(message, end='')
    
    def check_selected_code(self):
        """Validate only the selected/highlighted code"""
        selected = self.get_selected_code()
        
        if not selected or not selected.strip():
            self._output_to_terminal("⚠️ No code selected. Please select some code to check.\n")
            return
        
        self.set_status("Checking selected code...")
        self._output_to_terminal(f"\n{'='*60}\n")
        self._output_to_terminal(f"Checking selected code ({self.context.value})...\n")
        self._output_to_terminal(f"{'='*60}\n")
        
        # Get selection start line for error reporting
        cursor = self.code_editor.textCursor()
        start_pos = cursor.selectionStart()
        text = self.code_editor.toPlainText()
        start_line = text[:start_pos].count('\n')
        
        # Detect mode for selected code
        detected_mode = self._detect_code_mode(selected)
        
        # Validate
        is_valid, errors, warnings = self.validator.validate_selection(
            self.get_code(),
            selected,
            detected_mode,
            start_line,
            context=f"{self.context.value} (selected)",
            editor_context=self.context
        )
        
        # Output to terminal
        if is_valid:
            self._output_to_terminal("✅ Selected code check passed\n")
            if warnings:
                self._output_to_terminal(f"⚠️ {len(warnings)} warning(s):\n")
                for warn in warnings:
                    self._output_to_terminal(f"  Line {warn.line}: {warn.message}\n")
        else:
            self._output_to_terminal(f"❌ {len(errors)} error(s) found:\n")
            for err in errors:
                self._output_to_terminal(f"  Line {err.line}: {err.message}\n")
            if warnings:
                self._output_to_terminal(f"⚠️ {len(warnings)} warning(s):\n")
                for warn in warnings:
                    self._output_to_terminal(f"  Line {warn.line}: {warn.message}\n")
        
        # Convert to dict format for diagnostics panel
        error_dicts = [err.to_dict() for err in errors]
        warning_dicts = [warn.to_dict() for warn in warnings]
        
        self.set_diagnostics(error_dicts, warning_dicts)
        self.validation_complete.emit(is_valid, error_dicts, warning_dicts)
        
        # Update status
        if is_valid:
            self.set_status("✅ Selected code check passed")
        else:
            self.set_status(f"❌ {len(errors)} error(s) found in selection")
    
    def check_full_code(self):
        """Validate the entire code"""
        code = self.get_code()
        
        if not code or not code.strip():
            self._output_to_terminal("⚠️ No code to check. Editor is empty.\n")
            return
        
        self.set_status("Checking code...")
        self._output_to_terminal(f"\n{'='*60}\n")
        self._output_to_terminal(f"Checking full code ({self.context.value})...\n")
        self._output_to_terminal(f"{'='*60}\n")
        
        # Detect mode
        detected_mode = self._detect_code_mode(code)
        
        # If Advanced Mode ON, try both languages if first validation fails
        if self.advanced_mode_enabled:
            # Try detected mode first
            is_valid, errors, warnings = self.validator.validate(
                code,
                detected_mode,
                context=self.context.value,
                editor_context=self.context
            )
            
            # If validation failed and detected mode was Python, try PGSL as fallback
            if not is_valid and detected_mode == CodeMode.PYTHON:
                pgsl_valid, pgsl_errors, pgsl_warnings = self.validator.validate(
                    code,
                    CodeMode.PGSL,
                    context=self.context.value,
                    editor_context=self.context
                )
                # Use PGSL results if they're better (fewer errors)
                if pgsl_valid or len(pgsl_errors) < len(errors):
                    is_valid, errors, warnings = pgsl_valid, pgsl_errors, pgsl_warnings
        else:
            # Simple Mode - only PGSL
            is_valid, errors, warnings = self.validator.validate(
                code,
                CodeMode.PGSL,
                context=self.context.value
            )
        
        # Output to terminal
        if is_valid:
            self._output_to_terminal("✅ Code check passed\n")
            if warnings:
                self._output_to_terminal(f"⚠️ {len(warnings)} warning(s):\n")
                for warn in warnings:
                    self._output_to_terminal(f"  Line {warn.line}: {warn.message}\n")
        else:
            self._output_to_terminal(f"❌ {len(errors)} error(s) found:\n")
            for err in errors:
                self._output_to_terminal(f"  Line {err.line}: {err.message}\n")
            if warnings:
                self._output_to_terminal(f"⚠️ {len(warnings)} warning(s):\n")
                for warn in warnings:
                    self._output_to_terminal(f"  Line {warn.line}: {warn.message}\n")
        
        # Convert to dict format for diagnostics panel
        error_dicts = [err.to_dict() for err in errors]
        warning_dicts = [warn.to_dict() for warn in warnings]
        
        self.set_diagnostics(error_dicts, warning_dicts)
        self.validation_complete.emit(is_valid, error_dicts, warning_dicts)
        
        # Update status
        if is_valid:
            self.set_status("✅ Code check passed")
        else:
            self.set_status(f"❌ {len(errors)} error(s) found")
    
    def _perform_validation(self):
        """Perform real-time validation (called by timer)"""
        code = self.get_code()
        if not code or not code.strip():
            return
        
        # Detect mode
        detected_mode = self._detect_code_mode(code)
        
        is_valid, errors, warnings = self.validator.validate(
            code,
            detected_mode,
            context=self.context.value
        )
        
        # Convert to dict format
        error_dicts = [err.to_dict() for err in errors]
        warning_dicts = [warn.to_dict() for warn in warnings]
        
        self.set_diagnostics(error_dicts, warning_dicts)
    
    def enable_real_time_validation(self, enabled: bool = True):
        """Enable or disable real-time validation"""
        self.real_time_validation = enabled
        if not enabled:
            self.validation_timer.stop()
    
    # ------------------------------------------------------------------
    # Public API - Test Execution (Phase 3)
    # ------------------------------------------------------------------
    
    def test_selected_code(self):
        """Test the selected/highlighted code in sandbox"""
        selected = self.get_selected_code()
        
        if not selected or not selected.strip():
            self._output_to_terminal("⚠️ No code selected. Please select some code to test.\n")
            return
        
        self.set_status("Testing selected code...")
        self._output_to_terminal(f"\n{'='*60}\n")
        self._output_to_terminal(f"Testing selected code ({self.context.value})...\n")
        self._output_to_terminal(f"{'='*60}\n")
        
        # Detect mode for selected code
        detected_mode = self._detect_code_mode(selected)
        
        # First, validate syntax
        cursor = self.code_editor.textCursor()
        start_pos = cursor.selectionStart()
        text = self.code_editor.toPlainText()
        start_line = text[:start_pos].count('\n')
        
        is_valid, errors, warnings = self.validator.validate_selection(
            self.get_code(),
            selected,
            detected_mode,
            start_line,
            context=f"{self.context.value} (selected)"
        )
        
        if not is_valid:
            # Syntax errors - show validation results
            error_dicts = [err.to_dict() for err in errors]
            warning_dicts = [warn.to_dict() for warn in warnings]
            self.set_diagnostics(error_dicts, warning_dicts)
            self.set_status(f"❌ Syntax errors found - fix before testing")
            QMessageBox.warning(
                self,
                "Syntax Errors",
                f"Please fix {len(errors)} syntax error(s) before testing.\n\n"
                f"Check the diagnostics panel for details."
            )
            return
        
        # Execute in sandbox
        result = self.execution_engine.execute(
            selected,
            detected_mode,
            context=f"{self.context.value} (selected)"
        )
        
        # Display results in terminal
        self._display_execution_result_terminal(result, "Selected Code")
    
    def test_code(self):
        """Test the entire code file in sandbox"""
        code = self.get_code()
        
        if not code or not code.strip():
            self._output_to_terminal("⚠️ No code to test. Editor is empty.\n")
            return
        
        self.set_status("Testing code...")
        self._output_to_terminal(f"\n{'='*60}\n")
        self._output_to_terminal(f"Testing full code ({self.context.value})...\n")
        self._output_to_terminal(f"{'='*60}\n")
        
        # Detect mode
        detected_mode = self._detect_code_mode(code)
        
        # First, validate syntax
        is_valid, errors, warnings = self.validator.validate(
            code,
            detected_mode,
            context=self.context.value
        )
        
        if not is_valid:
            # Syntax errors - show validation results
            error_dicts = [err.to_dict() for err in errors]
            warning_dicts = [warn.to_dict() for warn in warnings]
            self.set_diagnostics(error_dicts, warning_dicts)
            self.set_status(f"❌ Syntax errors found - fix before testing")
            self._output_to_terminal(f"❌ Syntax errors found - cannot test:\n")
            for err in errors:
                self._output_to_terminal(f"  Line {err.line}: {err.message}\n")
            return
        
        # Execute in sandbox
        result = self.execution_engine.execute(
            code,
            detected_mode,
            context=self.context.value
        )
        
        # Display results in terminal
        self._display_execution_result_terminal(result, "Code")
    
    def _display_execution_result_terminal(self, result: ExecutionResult, context_name: str):
        """Display execution result in terminal - simplified output"""
        if result.success:
            # Success - show simplified output
            # If there's a return value (expression result), show that
            if result.return_value is not None:
                self._output_to_terminal(f"✅ Result: {repr(result.return_value)}\n")
            # If there's stdout output, show that
            elif result.output and result.output != "Code executed successfully (no output)":
                self._output_to_terminal(f"✅ Result:\n{result.output}\n")
            # If there are user-defined variables (and no return value), show them
            elif result.variables:
                # Filter out any remaining builtins
                user_vars = {k: v for k, v in result.variables.items() 
                            if not k.startswith('__') and k != '__builtins__'}
                if user_vars:
                    self._output_to_terminal(f"✅ Result:\n")
                    for name, value in user_vars.items():
                        self._output_to_terminal(f"  {name} = {repr(value)}\n")
                else:
                    self._output_to_terminal(f"✅ Code executed successfully\n")
            else:
                self._output_to_terminal(f"✅ Code executed successfully\n")
            
            self.set_status(f"✅ {context_name} test passed")
            
            # Clear diagnostics (no errors)
            self.clear_diagnostics()
        else:
            # Error - show error message in terminal
            error_text = result.error or "Unknown error occurred"
            self._output_to_terminal(f"❌ Error: {error_text}\n")
            
            self.set_status(f"❌ {context_name} test failed")
            
            # Show error in diagnostics
            error_dict = {
                'message': error_text,
                'line': 0,
                'column': 0,
                'type': 'error',
                'source': 'execution'
            }
            self.set_diagnostics([error_dict], [])
    
    # ------------------------------------------------------------------
    # Phase 3 Complete - Sandboxed Test Execution Done
    # ------------------------------------------------------------------
    # All core features complete:
    # ✅ Editor Shell + Mode Management
    # ✅ Unified Validation Pipeline
    # ✅ Sandboxed Test Execution
    #
    # Ready for editor integration and migration

