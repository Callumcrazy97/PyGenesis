"""
Unified Validation Pipeline
Provides consistent validation for both PGSL and Python code.

Phase 2: Unified Validation Pipeline
- PGSL validation path
- Python AST validation path
- Diagnostic normalization (same structure for both)
"""

from typing import List, Dict, Tuple, Optional
from enum import Enum

from Core.Code.Unified.types import CodeMode, EditorContext
from Core.CodeSystem.syntax import SyntaxValidator as PGSLSyntaxValidator
from Core.CodeSystem.parser import PGSLParser, ParseError

# Import ScriptValidator for Python validation
try:
    from Core.Code.Shared.script_validator import ScriptValidator
    SCRIPT_VALIDATOR_AVAILABLE = True
except ImportError:
    SCRIPT_VALIDATOR_AVAILABLE = False
    ScriptValidator = None

import ast
import traceback


class DiagnosticType(Enum):
    """Type of diagnostic"""
    ERROR = "error"
    WARNING = "warning"
    INFO = "info"


class Diagnostic:
    """Normalized diagnostic structure"""
    
    def __init__(
        self,
        message: str,
        line: int = 0,
        column: int = 0,
        type: DiagnosticType = DiagnosticType.ERROR,
        source: Optional[str] = None
    ):
        self.message = message
        self.line = line
        self.column = column
        self.type = type
        self.source = source  # 'pgsl' or 'python'
    
    def to_dict(self) -> Dict:
        """Convert to dictionary for API compatibility"""
        return {
            'message': self.message,
            'line': self.line,
            'column': self.column,
            'type': self.type.value,
            'source': self.source
        }


class UnifiedValidationPipeline:
    """
    Unified validation pipeline for PGSL and Python.
    
    Provides consistent validation interface regardless of language.
    """
    
    def __init__(self, project_path=None):
        """
        Initialize validation pipeline.
        
        Args:
            project_path: Optional project path for Python validation context
        """
        # PGSL validator
        self.pgsl_validator = PGSLSyntaxValidator()
        
        # Python validator (if available)
        self.python_validator = None
        if SCRIPT_VALIDATOR_AVAILABLE and ScriptValidator:
            try:
                self.python_validator = ScriptValidator(project_path)
            except Exception:
                # Fallback if ScriptValidator fails to initialize
                self.python_validator = None
    
    def validate(
        self, 
        code: str, 
        mode: CodeMode,
        context: Optional[str] = None,
        editor_context: Optional[EditorContext] = None,
        predefined_variables: Optional[List[str]] = None
    ) -> Tuple[bool, List[Diagnostic], List[Diagnostic]]:
        """
        Validate code based on mode.
        
        Args:
            code: Code string to validate
            mode: CodeMode.PGSL or CodeMode.PYTHON
            context: Optional context string for better error messages
            editor_context: Optional EditorContext (SCRIPT, OBJECT_EVENT, etc.)
            predefined_variables: Optional list of variable names predefined in other events
        
        Returns:
            (is_valid, errors, warnings)
        """
        if mode == CodeMode.PGSL:
            return self._validate_pgsl(code, context)
        elif mode == CodeMode.PYTHON:
            return self._validate_python(code, context, editor_context, predefined_variables)
        else:
            # Unknown mode - return error
            error = Diagnostic(
                message=f"Unknown code mode: {mode}",
                type=DiagnosticType.ERROR
            )
            return (False, [error], [])
    
    def _validate_pgsl(
        self, 
        code: str, 
        context: Optional[str] = None
    ) -> Tuple[bool, List[Diagnostic], List[Diagnostic]]:
        """
        Validate PGSL code using CodeSystem.
        
        Args:
            code: PGSL code string
            context: Optional context string
        
        Returns:
            (is_valid, errors, warnings)
        """
        errors: List[Diagnostic] = []
        warnings: List[Diagnostic] = []
        
        if not code or not code.strip():
            # Empty code is valid (no errors)
            return (True, [], [])
        
        try:
            # Use CodeSystem validator
            is_valid, validator_errors, validator_warnings = self.pgsl_validator.validate(code)
            
            # Normalize errors
            for err in validator_errors:
                error = Diagnostic(
                    message=err.get('message', str(err)),
                    line=err.get('line', 0),
                    column=err.get('column', 0),
                    type=DiagnosticType.ERROR,
                    source='pgsl'
                )
                errors.append(error)
            
            # Normalize warnings
            for warn in validator_warnings:
                warning = Diagnostic(
                    message=warn.get('message', str(warn)),
                    line=warn.get('line', 0),
                    column=warn.get('column', 0),
                    type=DiagnosticType.WARNING,
                    source='pgsl'
                )
                warnings.append(warning)
            
            # PGSL validator may be incomplete, so be lenient
            # If there are parse errors but code looks like PGSL, return warnings not errors
            if not is_valid and len(errors) > 0:
                # Check if it's a basic syntax issue vs a real error
                # For now, if PGSL validator fails, try to be helpful
                # but don't block if it's just incomplete validator
                pass
            
            return (is_valid and len(errors) == 0, errors, warnings)
            
        except ParseError as e:
            # PGSL parse error - but PGSL compiler is incomplete, so be lenient
            # Return as warning if it's a basic parse issue
            warning = Diagnostic(
                message=f"PGSL parse note: {str(e)} (PGSL compiler is ~10% complete)",
                line=e.token.line if e.token else 0,
                column=e.token.column if e.token else 0,
                type=DiagnosticType.WARNING,
                source='pgsl'
            )
            return (True, [], [warning])  # Don't block on PGSL parse errors yet
            
        except Exception as e:
            # Unexpected error - return as warning since PGSL validator is incomplete
            warning = Diagnostic(
                message=f"PGSL validation note: {str(e)} (PGSL compiler is ~10% complete)",
                line=0,
                column=0,
                type=DiagnosticType.WARNING,
                source='pgsl'
            )
            return (True, [], [warning])  # Don't block on PGSL validation errors yet
    
    def _validate_python(
        self, 
        code: str, 
        context: Optional[str] = None,
        editor_context: Optional[EditorContext] = None,
        predefined_variables: Optional[List[str]] = None
    ) -> Tuple[bool, List[Diagnostic], List[Diagnostic]]:
        """
        Validate Python code using AST and ScriptValidator.
        
        Args:
            code: Python code string
            context: Optional context string
            editor_context: Optional EditorContext (SCRIPT, OBJECT_EVENT, etc.)
            predefined_variables: Optional list of variable names predefined in other events
        
        Returns:
            (is_valid, errors, warnings)
        """
        errors: List[Diagnostic] = []
        warnings: List[Diagnostic] = []
        
        if not code or not code.strip():
            # Empty code is valid (no errors)
            return (True, [], [])
        
        # First, try AST parsing (fast syntax check)
        try:
            ast.parse(code)
        except SyntaxError as e:
            # Syntax error
            error = Diagnostic(
                message=f"Syntax error: {e.msg}",
                line=e.lineno or 0,
                column=e.offset or 0,
                type=DiagnosticType.ERROR,
                source='python'
            )
            return (False, [error], [])
        except Exception as e:
            # Other parse error
            error = Diagnostic(
                message=f"Parse error: {str(e)}",
                line=0,
                column=0,
                type=DiagnosticType.ERROR,
                source='python'
            )
            return (False, [error], [])
        
        # If ScriptValidator is available, use it for deeper validation
        if self.python_validator:
            try:
                # Pass editor_context to validator (e.g., "object_event", "script", etc.)
                editor_context_str = editor_context.value if editor_context else None
                # Convert predefined_variables list to set if provided
                predefined_vars_set = set(predefined_variables) if predefined_variables else None
                result = self.python_validator.check_code_string(
                    code, 
                    context_name=context or "Code", 
                    editor_context=editor_context_str,
                    predefined_variables=predefined_vars_set
                )
                
                if not result.get('passed', False):
                    # Convert ScriptValidator errors to normalized format
                    for err in result.get('errors', []):
                        # ScriptValidator errors may have different structure
                        if isinstance(err, dict):
                            error = Diagnostic(
                                message=err.get('message', str(err)),
                                line=err.get('line', 0),
                                column=err.get('column', 0),
                                type=DiagnosticType.ERROR,
                                source='python'
                            )
                        else:
                            error = Diagnostic(
                                message=str(err),
                                line=0,
                                column=0,
                                type=DiagnosticType.ERROR,
                                source='python'
                            )
                        errors.append(error)
                
                # Convert warnings
                for warn in result.get('warnings', []):
                    if isinstance(warn, dict):
                        warning = Diagnostic(
                            message=warn.get('message', str(warn)),
                            line=warn.get('line', 0),
                            column=warn.get('column', 0),
                            type=DiagnosticType.WARNING,
                            source='python'
                        )
                    else:
                        warning = Diagnostic(
                            message=str(warn),
                            line=0,
                            column=0,
                            type=DiagnosticType.WARNING,
                            source='python'
                        )
                    warnings.append(warning)
                
            except Exception as e:
                # ScriptValidator failed, but AST parse succeeded
                # This is a warning, not an error
                warning = Diagnostic(
                    message=f"Deep validation unavailable: {str(e)}",
                    line=0,
                    column=0,
                    type=DiagnosticType.WARNING,
                    source='python'
                )
                warnings.append(warning)
        
        # If we got here, AST parse succeeded
        is_valid = len(errors) == 0
        return (is_valid, errors, warnings)
    
    def validate_selection(
        self,
        code: str,
        selected_code: str,
        mode: CodeMode,
        start_line: int = 0,
        context: Optional[str] = None,
        editor_context: Optional[EditorContext] = None
    ) -> Tuple[bool, List[Diagnostic], List[Diagnostic]]:
        """
        Validate selected code (may need context from full code).
        
        Args:
            code: Full code string (for context)
            selected_code: Selected code to validate
            mode: CodeMode.PGSL or CodeMode.PYTHON
            start_line: Starting line number of selection (for error reporting)
            context: Optional context string
            editor_context: Optional EditorContext (SCRIPT, OBJECT_EVENT, etc.)
        
        Returns:
            (is_valid, errors, warnings)
        """
        # For now, validate selected code as-is
        # Future: Could provide better context-aware validation
        is_valid, errors, warnings = self.validate(selected_code, mode, context, editor_context)
        
        # Adjust line numbers to account for selection offset
        for error in errors:
            error.line += start_line
        for warning in warnings:
            warning.line += start_line
        
        return (is_valid, errors, warnings)

