"""
Base Code Editor Components
Shared base classes for syntax highlighting.
"""

from .base_syntax_highlighter import BaseSyntaxHighlighter, PythonSyntaxHighlighter

__all__ = [
    'BaseSyntaxHighlighter',
    'PythonSyntaxHighlighter',
]

