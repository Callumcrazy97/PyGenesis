"""
Base Syntax Highlighter
Provides syntax highlighting for code editors.
"""

from PySide6.QtGui import QTextCharFormat, QColor, QSyntaxHighlighter
from PySide6.QtCore import QRegularExpression
import re


class BaseSyntaxHighlighter(QSyntaxHighlighter):
    """Base class for syntax highlighters"""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.highlighting_rules = []
        self._setup_highlighting()
    
    def _setup_highlighting(self):
        """Override in subclasses to set up highlighting rules"""
        pass
    
    def highlightBlock(self, text):
        """Apply syntax highlighting to a block of text"""
        for pattern, format in self.highlighting_rules:
            for match in pattern.finditer(text):
                start, end = match.span()
                self.setFormat(start, end - start, format)


class PythonSyntaxHighlighter(BaseSyntaxHighlighter):
    """Python syntax highlighter"""
    
    def _setup_highlighting(self):
        # Keywords
        keyword_format = QTextCharFormat()
        keyword_format.setForeground(QColor(86, 156, 214))
        keyword_format.setFontWeight(700)
        keywords = [
            'and', 'as', 'assert', 'break', 'class', 'continue', 'def', 'del',
            'elif', 'else', 'except', 'exec', 'finally', 'for', 'from', 'global',
            'if', 'import', 'in', 'is', 'lambda', 'not', 'or', 'pass', 'print',
            'raise', 'return', 'try', 'while', 'with', 'yield', 'None', 'True', 'False'
        ]
        for keyword in keywords:
            pattern = re.compile(r'\b' + keyword + r'\b')
            self.highlighting_rules.append((pattern, keyword_format))
        
        # Strings
        string_format = QTextCharFormat()
        string_format.setForeground(QColor(206, 145, 120))
        self.highlighting_rules.append((re.compile(r'"[^"]*"'), string_format))
        self.highlighting_rules.append((re.compile(r"'[^']*'"), string_format))
        
        # Comments
        comment_format = QTextCharFormat()
        comment_format.setForeground(QColor(106, 153, 85))
        comment_format.setFontItalic(True)
        self.highlighting_rules.append((re.compile(r'#.*'), comment_format))
        
        # Numbers
        number_format = QTextCharFormat()
        number_format.setForeground(QColor(181, 206, 168))
        self.highlighting_rules.append((re.compile(r'\b[0-9]+\b'), number_format))


class ShaderSyntaxHighlighter(BaseSyntaxHighlighter):
    """GLSL/Shader syntax highlighter"""
    
    def _setup_highlighting(self):
        # GLSL Keywords
        keyword_format = QTextCharFormat()
        keyword_format.setForeground(QColor(86, 156, 214))
        keyword_format.setFontWeight(700)
        keywords = [
            'attribute', 'uniform', 'varying', 'const', 'in', 'out', 'inout',
            'float', 'int', 'bool', 'vec2', 'vec3', 'vec4', 'mat2', 'mat3', 'mat4',
            'sampler2D', 'samplerCube', 'if', 'else', 'for', 'while', 'return',
            'discard', 'void', 'struct'
        ]
        for keyword in keywords:
            pattern = re.compile(r'\b' + keyword + r'\b')
            self.highlighting_rules.append((pattern, keyword_format))
        
        # Built-in functions
        function_format = QTextCharFormat()
        function_format.setForeground(QColor(220, 220, 170))
        functions = [
            'sin', 'cos', 'tan', 'asin', 'acos', 'atan', 'atan2',
            'pow', 'exp', 'log', 'exp2', 'log2', 'sqrt', 'inversesqrt',
            'abs', 'sign', 'floor', 'ceil', 'fract', 'mod', 'min', 'max',
            'clamp', 'mix', 'step', 'smoothstep', 'length', 'distance',
            'dot', 'cross', 'normalize', 'reflect', 'refract',
            'texture2D', 'textureCube', 'texture'
        ]
        for func in functions:
            pattern = re.compile(r'\b' + func + r'\s*\(')
            self.highlighting_rules.append((pattern, function_format))
        
        # Comments
        comment_format = QTextCharFormat()
        comment_format.setForeground(QColor(106, 153, 85))
        comment_format.setFontItalic(True)
        self.highlighting_rules.append((re.compile(r'//.*'), comment_format))
        self.highlighting_rules.append((re.compile(r'/\*.*?\*/', re.DOTALL), comment_format))
        
        # Numbers
        number_format = QTextCharFormat()
        number_format.setForeground(QColor(181, 206, 168))
        self.highlighting_rules.append((re.compile(r'\b[0-9]+\.[0-9]*f?\b'), number_format))
        self.highlighting_rules.append((re.compile(r'\b[0-9]+f?\b'), number_format))

