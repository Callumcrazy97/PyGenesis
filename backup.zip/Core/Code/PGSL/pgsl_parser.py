"""
PGSL Parser - Converts PGSL commands to Python code
"""

import re
import ast
from typing import List, Tuple, Optional


class PGSLParser:
    """
    Parses PGSL (PyGenesis Shortcut Language) commands and converts them to Python.
    
    PGSL provides a simplified, GameMaker-like syntax that gets compiled to Python.
    """
    
    def __init__(self):
        """Initialize the parser"""
        # Command patterns: (regex_pattern, replacement_function)
        self.command_patterns = self._build_command_patterns()
    
    def _build_command_patterns(self) -> List[Tuple[re.Pattern, callable]]:
        """Build regex patterns for PGSL commands"""
        patterns = []
        
        # IDE & Runtime Commands
        patterns.append((re.compile(r'\bRun\(\)'), lambda m: 'pgsl_runtime.Run()'))
        patterns.append((re.compile(r'\bDebug_Run\(\)'), lambda m: 'pgsl_runtime.Debug_Run()'))
        patterns.append((re.compile(r'\bBuild\s*\(\s*([^)]+)\s*\)'), 
                         lambda m: f'pgsl_runtime.Build({m.group(1)})'))
        patterns.append((re.compile(r'\bValidate\s*\(\s*([^)]*)\s*\)'), 
                         lambda m: f'pgsl_runtime.Validate({m.group(1) if m.group(1) else "None"})'))
        patterns.append((re.compile(r'\bgame_end\(\)'), lambda m: 'pgsl_runtime.game_end()'))
        patterns.append((re.compile(r'\bwindow_set_size\s*\(\s*(\w+)\s*,\s*(\w+)\s*\)'), 
                         lambda m: f'pgsl_runtime.window_set_size({m.group(1)}, {m.group(2)})'))
        patterns.append((re.compile(r'\bwindow_set_title\s*\(\s*([^)]+)\s*\)'), 
                         lambda m: f'pgsl_runtime.window_set_title({m.group(1)})'))
        patterns.append((re.compile(r'\bgame_set_speed\s*\(\s*(\w+)\s*\)'), 
                         lambda m: f'pgsl_runtime.game_set_speed({m.group(1)})'))
        patterns.append((re.compile(r'\broom_set_speed\s*\(\s*(\w+)\s*\)'), 
                         lambda m: f'pgsl_runtime.room_set_speed({m.group(1)})'))
        
        # Instance & Object Management
        patterns.append((re.compile(r'\bcreate_instance\s*\(\s*([^)]+)\s*\)'), 
                         lambda m: f'pgsl_runtime.create_instance({m.group(1)})'))
        patterns.append((re.compile(r'\binstance_destroy\s*\(\s*([^)]+)\s*\)'), 
                         lambda m: f'pgsl_runtime.instance_destroy({m.group(1)})'))
        patterns.append((re.compile(r'\binstance_find\s*\(\s*([^)]+)\s*\)'), 
                         lambda m: f'pgsl_runtime.instance_find({m.group(1)})'))
        patterns.append((re.compile(r'\binstance_find_nearest\s*\(\s*([^)]+)\s*\)'), 
                         lambda m: f'pgsl_runtime.instance_find_nearest({m.group(1)})'))
        patterns.append((re.compile(r'\binstance_find_furthest\s*\(\s*([^)]+)\s*\)'), 
                         lambda m: f'pgsl_runtime.instance_find_furthest({m.group(1)})'))
        patterns.append((re.compile(r'\binstance_find_id\s*\(\s*([^)]+)\s*\)'), 
                         lambda m: f'pgsl_runtime.instance_find_id({m.group(1)})'))
        patterns.append((re.compile(r'\binstance_get_count\s*\(\s*([^)]+)\s*\)'), 
                         lambda m: f'pgsl_runtime.instance_get_count({m.group(1)})'))
        patterns.append((re.compile(r'\binstance_exists\s*\(\s*([^)]+)\s*\)'), 
                         lambda m: f'pgsl_runtime.instance_exists({m.group(1)})'))
        patterns.append((re.compile(r'\binstance_copy\s*\(\s*([^)]+)\s*\)'), 
                         lambda m: f'pgsl_runtime.instance_copy({m.group(1)})'))
        patterns.append((re.compile(r'\binstance_set_motion\s*\(\s*([^)]+)\s*\)'), 
                         lambda m: f'pgsl_runtime.instance_set_motion({m.group(1)})'))
        patterns.append((re.compile(r'\binstance_get_motion\s*\(\s*([^)]+)\s*\)'), 
                         lambda m: f'pgsl_runtime.instance_get_motion({m.group(1)})'))
        patterns.append((re.compile(r'\bplace_free\s*\(\s*(\w+)\s*,\s*(\w+)\s*\)'), 
                         lambda m: f'pgsl_runtime.place_free({m.group(1)}, {m.group(2)})'))
        patterns.append((re.compile(r'\bplace_free_3d\s*\(\s*(\w+)\s*,\s*(\w+)\s*,\s*(\w+)\s*\)'), 
                         lambda m: f'pgsl_runtime.place_free_3d({m.group(1)}, {m.group(2)}, {m.group(3)})'))
        
        # Variables & Math
        # Variable_set - pattern to match even with incomplete strings
        patterns.append((re.compile(r'\bVariable_set\s*\(\s*([^,)]+)\s*,\s*([^)]*?)(?:\)|$)'), 
                         lambda m: f'pgsl_runtime.Variable_set({m.group(1)}, {m.group(2)})'))
        patterns.append((re.compile(r'\bVariable_get\s*\(\s*([^)]+)\s*\)'), 
                         lambda m: f'pgsl_runtime.Variable_get({m.group(1)})'))
        patterns.append((re.compile(r'\bVariable_exists\s*\(\s*([^)]+)\s*\)'), 
                         lambda m: f'pgsl_runtime.Variable_exists({m.group(1)})'))
        patterns.append((re.compile(r'\bWait\s*\(\s*(\w+)\s*\)'), 
                         lambda m: f'pgsl_runtime.Wait({m.group(1)})'))
        patterns.append((re.compile(r'\bclamp\s*\(\s*([^,]+)\s*,\s*([^,]+)\s*,\s*([^)]+)\s*\)'), 
                         lambda m: f'pgsl_runtime.clamp({m.group(1)}, {m.group(2)}, {m.group(3)})'))
        patterns.append((re.compile(r'\blerp\s*\(\s*([^,]+)\s*,\s*([^,]+)\s*,\s*([^)]+)\s*\)'), 
                         lambda m: f'pgsl_runtime.lerp({m.group(1)}, {m.group(2)}, {m.group(3)})'))
        patterns.append((re.compile(r'\bpoint_direction\s*\(\s*([^,]+)\s*,\s*([^,]+)\s*,\s*([^,]+)\s*,\s*([^)]+)\s*\)'), 
                         lambda m: f'pgsl_runtime.point_direction({m.group(1)}, {m.group(2)}, {m.group(3)}, {m.group(4)})'))
        patterns.append((re.compile(r'\bpoint_distance\s*\(\s*([^,]+)\s*,\s*([^,]+)\s*,\s*([^,]+)\s*,\s*([^)]+)\s*\)'), 
                         lambda m: f'pgsl_runtime.point_distance({m.group(1)}, {m.group(2)}, {m.group(3)}, {m.group(4)})'))
        patterns.append((re.compile(r'\brandom_range\s*\(\s*([^,]+)\s*,\s*([^)]+)\s*\)'), 
                         lambda m: f'pgsl_runtime.random_range({m.group(1)}, {m.group(2)})'))
        patterns.append((re.compile(r'\brandom_int\s*\(\s*([^,]+)\s*,\s*([^)]+)\s*\)'), 
                         lambda m: f'pgsl_runtime.random_int({m.group(1)}, {m.group(2)})'))
        
        # Movement & Physics
        patterns.append((re.compile(r'\bMove2D_direction\s*\(\s*([^,]+)\s*,\s*([^)]+)\s*\)'), 
                         lambda m: f'pgsl_runtime.Move2D_direction({m.group(1)}, {m.group(2)})'))
        patterns.append((re.compile(r'\bMove2D_point\s*\(\s*([^,]+)\s*,\s*([^,]+)\s*,\s*([^)]+)\s*\)'), 
                         lambda m: f'pgsl_runtime.Move2D_point({m.group(1)}, {m.group(2)}, {m.group(3)})'))
        patterns.append((re.compile(r'\bMove3D_direction\s*\(\s*([^,]+)\s*,\s*([^,]+)\s*,\s*([^)]+)\s*\)'), 
                         lambda m: f'pgsl_runtime.Move3D_direction({m.group(1)}, {m.group(2)}, {m.group(3)})'))
        patterns.append((re.compile(r'\bMove3D_towards\s*\(\s*([^,]+)\s*,\s*([^,]+)\s*,\s*([^,]+)\s*,\s*([^)]+)\s*\)'), 
                         lambda m: f'pgsl_runtime.Move3D_towards({m.group(1)}, {m.group(2)}, {m.group(3)}, {m.group(4)})'))
        patterns.append((re.compile(r'\bMove3D_stop\(\)'), lambda m: 'pgsl_runtime.Move3D_stop()'))
        patterns.append((re.compile(r'\bMove3D_add_force\s*\(\s*([^,]+)\s*,\s*([^,]+)\s*,\s*([^)]+)\s*\)'), 
                         lambda m: f'pgsl_runtime.Move3D_add_force({m.group(1)}, {m.group(2)}, {m.group(3)})'))
        patterns.append((re.compile(r'\bcollision_point\s*\(\s*([^,]+)\s*,\s*([^,]+)\s*,\s*([^)]+)\s*\)'), 
                         lambda m: f'pgsl_runtime.collision_point({m.group(1)}, {m.group(2)}, {m.group(3)})'))
        patterns.append((re.compile(r'\bcollision_rect\s*\(\s*([^,]+)\s*,\s*([^,]+)\s*,\s*([^,]+)\s*,\s*([^,]+)\s*,\s*([^)]+)\s*\)'), 
                         lambda m: f'pgsl_runtime.collision_rect({m.group(1)}, {m.group(2)}, {m.group(3)}, {m.group(4)}, {m.group(5)})'))
        
        # Drawing & Graphics
        patterns.append((re.compile(r'\bDraw_Self_2D\(\)'), lambda m: 'pgsl_runtime.Draw_Self_2D(self)'))
        patterns.append((re.compile(r'\bDraw_Sprite_2D\s*\(\s*([^,]+)\s*,\s*([^,]+)\s*,\s*([^,]+)\s*,\s*([^)]+)\s*\)'), 
                         lambda m: f'pgsl_runtime.Draw_Sprite_2D({m.group(1)}, {m.group(2)}, {m.group(3)}, {m.group(4)})'))
        patterns.append((re.compile(r'\bDraw_Text_2D\s*\(\s*([^,]+)\s*,\s*([^,]+)\s*,\s*([^)]+)\s*\)'), 
                         lambda m: f'pgsl_runtime.Draw_Text_2D({m.group(1)}, {m.group(2)}, {m.group(3)})'))
        patterns.append((re.compile(r'\bDraw_Rect_2D\s*\(\s*([^,]+)\s*,\s*([^,]+)\s*,\s*([^,]+)\s*,\s*([^,]+)\s*,\s*([^,]+)\s*,\s*([^)]+)\s*\)'), 
                         lambda m: f'pgsl_runtime.Draw_Rect_2D({m.group(1)}, {m.group(2)}, {m.group(3)}, {m.group(4)}, {m.group(5)}, {m.group(6)})'))
        patterns.append((re.compile(r'\bDraw_Self_3D\(\)'), lambda m: 'pgsl_runtime.Draw_Self_3D(self)'))
        patterns.append((re.compile(r'\bDraw_Model_3D\s*\(\s*([^)]+)\s*\)'), 
                         lambda m: f'pgsl_runtime.Draw_Model_3D({m.group(1)})'))
        patterns.append((re.compile(r'\bDraw_Text_3D\s*\(\s*([^,]+)\s*,\s*([^,]+)\s*,\s*([^,]+)\s*,\s*([^)]+)\s*\)'), 
                         lambda m: f'pgsl_runtime.Draw_Text_3D({m.group(1)}, {m.group(2)}, {m.group(3)}, {m.group(4)})'))
        patterns.append((re.compile(r'\bDraw_HUD\s*\(\s*([^,]+)\s*,\s*([^,]+)\s*,\s*([^,]+)\s*,\s*([^,]+)\s*,\s*([^,]+)\s*,\s*([^,]+)\s*,\s*([^)]+)\s*\)'), 
                         lambda m: f'pgsl_runtime.Draw_HUD({m.group(1)}, {m.group(2)}, {m.group(3)}, {m.group(4)}, {m.group(5)}, {m.group(6)}, {m.group(7)})'))
        patterns.append((re.compile(r'\bDraw_Bar\s*\(\s*([^,]+)\s*,\s*([^,]+)\s*,\s*([^,]+)\s*,\s*([^,]+)\s*,\s*([^,]+)\s*,\s*([^,]+)\s*,\s*([^,]+)\s*,\s*([^)]+)\s*\)'), 
                         lambda m: f'pgsl_runtime.Draw_Bar({m.group(1)}, {m.group(2)}, {m.group(3)}, {m.group(4)}, {m.group(5)}, {m.group(6)}, {m.group(7)}, {m.group(8)})'))
        patterns.append((re.compile(r'\bDraw_HUD_Text\s*\(\s*([^,]+)\s*,\s*([^,]+)\s*,\s*([^)]+)\s*\)'), 
                         lambda m: f'pgsl_runtime.Draw_HUD_Text({m.group(1)}, {m.group(2)}, {m.group(3)})'))
        patterns.append((re.compile(r'\bDraw_HUD_Sprite\s*\(\s*([^,]+)\s*,\s*([^,]+)\s*,\s*([^,]+)\s*,\s*([^)]+)\s*\)'), 
                         lambda m: f'pgsl_runtime.Draw_HUD_Sprite({m.group(1)}, {m.group(2)}, {m.group(3)}, {m.group(4)})'))
        
        # Camera & Viewports
        patterns.append((re.compile(r'\bCamera2D_set_position\s*\(\s*([^,]+)\s*,\s*([^)]+)\s*\)'), 
                         lambda m: f'pgsl_runtime.Camera2D_set_position({m.group(1)}, {m.group(2)})'))
        patterns.append((re.compile(r'\bCamera2D_follow\s*\(\s*([^,]+)\s*,\s*([^)]+)\s*\)'), 
                         lambda m: f'pgsl_runtime.Camera2D_follow({m.group(1)}, {m.group(2)})'))
        patterns.append((re.compile(r'\bCamera2D_shake\s*\(\s*([^,]+)\s*,\s*([^)]+)\s*\)'), 
                         lambda m: f'pgsl_runtime.Camera2D_shake({m.group(1)}, {m.group(2)})'))
        patterns.append((re.compile(r'\bCamera3D_set_position\s*\(\s*([^,]+)\s*,\s*([^,]+)\s*,\s*([^)]+)\s*\)'), 
                         lambda m: f'pgsl_runtime.Camera3D_set_position({m.group(1)}, {m.group(2)}, {m.group(3)})'))
        patterns.append((re.compile(r'\bCamera3D_set_target\s*\(\s*([^,]+)\s*,\s*([^,]+)\s*,\s*([^)]+)\s*\)'), 
                         lambda m: f'pgsl_runtime.Camera3D_set_target({m.group(1)}, {m.group(2)}, {m.group(3)})'))
        patterns.append((re.compile(r'\bCamera3D_set_angle\s*\(\s*([^,]+)\s*,\s*([^,]+)\s*,\s*([^)]+)\s*\)'), 
                         lambda m: f'pgsl_runtime.Camera3D_set_angle({m.group(1)}, {m.group(2)}, {m.group(3)})'))
        patterns.append((re.compile(r'\bCamera3D_follow\s*\(\s*([^,]+)\s*,\s*([^,]+)\s*,\s*([^,]+)\s*,\s*([^)]+)\s*\)'), 
                         lambda m: f'pgsl_runtime.Camera3D_follow({m.group(1)}, {m.group(2)}, {m.group(3)}, {m.group(4)})'))
        patterns.append((re.compile(r'\bCamera3D_shake\s*\(\s*([^,]+)\s*,\s*([^)]+)\s*\)'), 
                         lambda m: f'pgsl_runtime.Camera3D_shake({m.group(1)}, {m.group(2)})'))
        patterns.append((re.compile(r'\bViewport_create\s*\(\s*([^,]+)\s*,\s*([^,]+)\s*,\s*([^,]+)\s*,\s*([^,]+)\s*,\s*([^)]+)\s*\)'), 
                         lambda m: f'pgsl_runtime.Viewport_create({m.group(1)}, {m.group(2)}, {m.group(3)}, {m.group(4)}, {m.group(5)})'))
        patterns.append((re.compile(r'\bViewport_set_camera\s*\(\s*([^,]+)\s*,\s*([^)]+)\s*\)'), 
                         lambda m: f'pgsl_runtime.Viewport_set_camera({m.group(1)}, {m.group(2)})'))
        patterns.append((re.compile(r'\bViewport_activate\s*\(\s*([^)]+)\s*\)'), 
                         lambda m: f'pgsl_runtime.Viewport_activate({m.group(1)})'))
        
        # Input & Audio
        patterns.append((re.compile(r'\bkey_check\s*\(\s*([^)]+)\s*\)'), 
                         lambda m: f'pgsl_runtime.key_check({m.group(1)})'))
        patterns.append((re.compile(r'\bkey_pressed\s*\(\s*([^)]+)\s*\)'), 
                         lambda m: f'pgsl_runtime.key_pressed({m.group(1)})'))
        patterns.append((re.compile(r'\bkey_released\s*\(\s*([^)]+)\s*\)'), 
                         lambda m: f'pgsl_runtime.key_released({m.group(1)})'))
        patterns.append((re.compile(r'\bmouse_position\(\)'), lambda m: 'pgsl_runtime.mouse_position()'))
        patterns.append((re.compile(r'\bmouse_delta\(\)'), lambda m: 'pgsl_runtime.mouse_delta()'))
        patterns.append((re.compile(r'\bmouse_button_check\s*\(\s*([^)]+)\s*\)'), 
                         lambda m: f'pgsl_runtime.mouse_button_check({m.group(1)})'))
        patterns.append((re.compile(r'\bmouse_button_pressed\s*\(\s*([^)]+)\s*\)'), 
                         lambda m: f'pgsl_runtime.mouse_button_pressed({m.group(1)})'))
        patterns.append((re.compile(r'\bInput_bind\s*\(\s*([^,]+)\s*,\s*([^)]+)\s*\)'), 
                         lambda m: f'pgsl_runtime.Input_bind({m.group(1)}, {m.group(2)})'))
        patterns.append((re.compile(r'\bInput_check\s*\(\s*([^)]+)\s*\)'), 
                         lambda m: f'pgsl_runtime.Input_check({m.group(1)})'))
        patterns.append((re.compile(r'\bInput_pressed\s*\(\s*([^)]+)\s*\)'), 
                         lambda m: f'pgsl_runtime.Input_pressed({m.group(1)})'))
        patterns.append((re.compile(r'\bsound_play\s*\(\s*([^,]+)\s*,\s*([^)]+)\s*\)'), 
                         lambda m: f'pgsl_runtime.sound_play({m.group(1)}, {m.group(2)})'))
        patterns.append((re.compile(r'\bsound_stop\s*\(\s*([^)]+)\s*\)'), 
                         lambda m: f'pgsl_runtime.sound_stop({m.group(1)})'))
        patterns.append((re.compile(r'\bsound_stop_all\(\)'), lambda m: 'pgsl_runtime.sound_stop_all()'))
        patterns.append((re.compile(r'\bsound_pause\s*\(\s*([^)]+)\s*\)'), 
                         lambda m: f'pgsl_runtime.sound_pause({m.group(1)})'))
        patterns.append((re.compile(r'\bsound_pause_all\(\)'), lambda m: 'pgsl_runtime.sound_pause_all()'))
        patterns.append((re.compile(r'\bsound_resume\s*\(\s*([^)]+)\s*\)'), 
                         lambda m: f'pgsl_runtime.sound_resume({m.group(1)})'))
        patterns.append((re.compile(r'\bsound_resume_all\(\)'), lambda m: 'pgsl_runtime.sound_resume_all()'))
        patterns.append((re.compile(r'\bsound_is_active\s*\(\s*([^)]+)\s*\)'), 
                         lambda m: f'pgsl_runtime.sound_is_active({m.group(1)})'))
        
        # Networking
        patterns.append((re.compile(r'\bnet_host\s*\(\s*(\w+)\s*\)'), 
                         lambda m: f'pgsl_runtime.net_host({m.group(1)})'))
        patterns.append((re.compile(r'\bnet_connect\s*\(\s*([^,]+)\s*,\s*(\w+)\s*\)'), 
                         lambda m: f'pgsl_runtime.net_connect({m.group(1)}, {m.group(2)})'))
        patterns.append((re.compile(r'\bnet_close\(\)'), lambda m: 'pgsl_runtime.net_close()'))
        patterns.append((re.compile(r'\bnet_send_all\s*\(\s*([^,]+)\s*,\s*([^)]+)\s*\)'), 
                         lambda m: f'pgsl_runtime.net_send_all({m.group(1)}, {m.group(2)})'))
        patterns.append((re.compile(r'\bnet_send_to\s*\(\s*([^,]+)\s*,\s*([^,]+)\s*,\s*([^)]+)\s*\)'), 
                         lambda m: f'pgsl_runtime.net_send_to({m.group(1)}, {m.group(2)}, {m.group(3)})'))
        patterns.append((re.compile(r'\bnet_get\s*\(\s*([^)]+)\s*\)'), 
                         lambda m: f'pgsl_runtime.net_get({m.group(1)})'))
        patterns.append((re.compile(r'\bnet_sync_position\s*\(\s*([^,]+)\s*,\s*([^,]+)\s*,\s*([^,]+)\s*,\s*([^)]+)\s*\)'), 
                         lambda m: f'pgsl_runtime.net_sync_position({m.group(1)}, {m.group(2)}, {m.group(3)}, {m.group(4)})'))
        patterns.append((re.compile(r'\bnet_sync_variable\s*\(\s*([^,]+)\s*,\s*([^,]+)\s*,\s*([^)]+)\s*\)'), 
                         lambda m: f'pgsl_runtime.net_sync_variable({m.group(1)}, {m.group(2)}, {m.group(3)})'))
        patterns.append((re.compile(r'\bnet_register_event\s*\(\s*([^)]+)\s*\)'), 
                         lambda m: f'pgsl_runtime.net_register_event({m.group(1)})'))
        
        # Shaders & Graphics Effects
        patterns.append((re.compile(r'\bshader_get\s*\(\s*([^)]+)\s*\)'), 
                         lambda m: f'pgsl_runtime.shader_get({m.group(1)})'))
        patterns.append((re.compile(r'\bshader_use\s*\(\s*([^)]+)\s*\)'), 
                         lambda m: f'pgsl_runtime.shader_use({m.group(1)})'))
        patterns.append((re.compile(r'\bshader_reset\(\)'), lambda m: 'pgsl_runtime.shader_reset()'))
        patterns.append((re.compile(r'\bshader_set_uniform\s*\(\s*([^,]+)\s*,\s*([^)]+)\s*\)'), 
                         lambda m: f'pgsl_runtime.shader_set_uniform({m.group(1)}, {m.group(2)})'))
        patterns.append((re.compile(r'\bshader_apply_global\s*\(\s*([^)]+)\s*\)'), 
                         lambda m: f'pgsl_runtime.shader_apply_global({m.group(1)})'))
        patterns.append((re.compile(r'\bshader_remove_global\(\)'), lambda m: 'pgsl_runtime.shader_remove_global()'))
        patterns.append((re.compile(r'\bcompute_shader_get\s*\(\s*([^)]+)\s*\)'), 
                         lambda m: f'pgsl_runtime.compute_shader_get({m.group(1)})'))
        patterns.append((re.compile(r'\bcompute_shader_run\s*\(\s*([^,]+)\s*,\s*([^)]+)\s*\)'), 
                         lambda m: f'pgsl_runtime.compute_shader_run({m.group(1)}, {m.group(2)})'))
        
        # Particles
        patterns.append((re.compile(r'\bparticle_system_create\s*\(\s*([^)]+)\s*\)'), 
                         lambda m: f'pgsl_runtime.particle_system_create({m.group(1)})'))
        patterns.append((re.compile(r'\bparticle_system_emit\s*\(\s*([^,]+)\s*,\s*([^,]+)\s*,\s*([^,]+)\s*,\s*([^,]+)\s*,\s*([^)]+)\s*\)'), 
                         lambda m: f'pgsl_runtime.particle_system_emit({m.group(1)}, {m.group(2)}, {m.group(3)}, {m.group(4)}, {m.group(5)})'))
        patterns.append((re.compile(r'\bparticle_system_set_property\s*\(\s*([^,]+)\s*,\s*([^,]+)\s*,\s*([^)]+)\s*\)'), 
                         lambda m: f'pgsl_runtime.particle_system_set_property({m.group(1)}, {m.group(2)}, {m.group(3)})'))
        
        # Scripts & External Code
        patterns.append((re.compile(r'\bscript_exists\s*\(\s*([^)]+)\s*\)'), 
                         lambda m: f'pgsl_runtime.script_exists({m.group(1)})'))
        patterns.append((re.compile(r'\bscript_call\s*\(\s*([^,]+)\s*,\s*(.+)\s*\)'), 
                         lambda m: f'pgsl_runtime.script_call({m.group(1)}, {m.group(2)})'))
        patterns.append((re.compile(r'\bscript_get\s*\(\s*([^)]+)\s*\)'), 
                         lambda m: f'pgsl_runtime.script_get({m.group(1)})'))
        
        return patterns
    
    def parse(self, code: str) -> str:
        """
        Parse PGSL code and convert to Python.
        
        Args:
            code: PGSL code string
            
        Returns:
            Python code with PGSL commands replaced
        """
        if not code or not code.strip():
            return code
        
        # Apply all patterns
        result = code
        for pattern, replacement_func in self.command_patterns:
            result = pattern.sub(replacement_func, result)
        
        return result
    
    def parse_file(self, file_path: str) -> str:
        """
        Parse a PGSL file and return Python code.
        
        Args:
            file_path: Path to PGSL file
            
        Returns:
            Python code
        """
        with open(file_path, 'r', encoding='utf-8') as f:
            code = f.read()
        return self.parse(code)

