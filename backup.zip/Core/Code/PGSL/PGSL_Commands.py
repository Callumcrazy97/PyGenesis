# pgsl_commands.py
from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List

try:
    import numpy
except ImportError:
    numpy = None  # Optional dependency


@dataclass
class PGSLCommandSpec:
    """
    Specification for a single PGSL command.

    - name: PGSL command name (without parentheses)
    - signature: ordered list of parameter names
    - python_template: Python code template with {param} placeholders
      (e.g. "pgsl_runtime.point_distance({x1}, {y1}, {x2}, {y2})")
    - description: short human-readable description
    """
    name: str
    signature: List[str]
    python_template: str
    description: str = ""


# ---- Core Runtime, Math, & Instances ----------------------------------------

_COMMAND_SPECS: List[PGSLCommandSpec] = [
    # IDE & Runtime Commands
    PGSLCommandSpec(
        name="Run",
        signature=[],
        python_template="pgsl_runtime.Run()",
        description="Start the main game loop."
    ),
    PGSLCommandSpec(
        name="Debug_Run",
        signature=[],
        python_template="pgsl_runtime.Debug_Run()",
        description="Start the game in debug mode."
    ),
    PGSLCommandSpec(
        name="Build",
        signature=["target"],
        python_template="pgsl_runtime.Build({target})",
        description="Build the game for a target platform."
    ),
    PGSLCommandSpec(
        name="Validate",
        signature=["scope"],
        python_template="pgsl_runtime.Validate({scope})",
        description="Validate code or project."
    ),
    PGSLCommandSpec(
        name="game_end",
        signature=[],
        python_template="pgsl_runtime.game_end()",
        description="End the game."
    ),
    PGSLCommandSpec(
        name="window_set_size",
        signature=["w", "h"],
        python_template="pgsl_runtime.window_set_size({w}, {h})",
        description="Set the window size."
    ),
    PGSLCommandSpec(
        name="window_set_title",
        signature=["text"],
        python_template="pgsl_runtime.window_set_title({text})",
        description="Set the window title."
    ),
    PGSLCommandSpec(
        name="game_set_speed",
        signature=["fps"],
        python_template="pgsl_runtime.game_set_speed({fps})",
        description="Set the game FPS."
    ),
    PGSLCommandSpec(
        name="room_set_speed",
        signature=["fps"],
        python_template="pgsl_runtime.room_set_speed({fps})",
        description="Set the room FPS."
    ),
    PGSLCommandSpec(
        name="game_save",
        signature=["slot"],
        python_template="pgsl_runtime.game_save({slot})",
        description="Save the game state."
    ),
    PGSLCommandSpec(
        name="Wait",
        signature=["ms"],
        python_template="pgsl_runtime.Wait({ms})",
        description="Wait for milliseconds."
    ),
    
    # Variables
    PGSLCommandSpec(
        name="Variable_set",
        signature=["name", "value"],
        python_template="pgsl_runtime.Variable_set({name}, {value})",
        description="Set an instance variable."
    ),
    PGSLCommandSpec(
        name="Variable_get",
        signature=["name"],
        python_template="pgsl_runtime.Variable_get({name})",
        description="Get an instance variable value."
    ),
    PGSLCommandSpec(
        name="Variable_exists",
        signature=["name"],
        python_template="pgsl_runtime.Variable_exists({name})",
        description="Check if a variable exists."
    ),
    
    # Math Functions
    PGSLCommandSpec(
        name="clamp",
        signature=["value", "min_val", "max_val"],
        python_template="pgsl_runtime.clamp({value}, {min_val}, {max_val})",
        description="Constrain a number."
    ),
    PGSLCommandSpec(
        name="lerp",
        signature=["a", "b", "t"],
        python_template="pgsl_runtime.lerp({a}, {b}, {t})",
        description="Linear interpolation."
    ),
    PGSLCommandSpec(
        name="point_direction",
        signature=["x1", "y1", "x2", "y2"],
        python_template="pgsl_runtime.point_direction({x1}, {y1}, {x2}, {y2})",
        description="Angle between two 2D points in degrees."
    ),
    PGSLCommandSpec(
        name="point_distance",
        signature=["x1", "y1", "x2", "y2"],
        python_template="pgsl_runtime.point_distance({x1}, {y1}, {x2}, {y2})",
        description="Distance between two 2D points."
    ),
    PGSLCommandSpec(
        name="random_range",
        signature=["min_val", "max_val"],
        python_template="pgsl_runtime.random_range({min_val}, {max_val})",
        description="Random float or int."
    ),
    PGSLCommandSpec(
        name="random_int",
        signature=["min_val", "max_val"],
        python_template="pgsl_runtime.random_int({min_val}, {max_val})",
        description="Random integer."
    ),
    
    # Instances
    PGSLCommandSpec(
        name="create_instance",
        signature=["obj_class", "x", "y", "z"],
        python_template="pgsl_runtime.create_instance({obj_class}, {x}, {y}, {z})",
        description="Create an instance and set its initial position."
    ),
    PGSLCommandSpec(
        name="instance_find",
        signature=["type_"],
        python_template="pgsl_runtime.instance_find({type_})",
        description="Return all instances of a given Python type."
    ),
    PGSLCommandSpec(
        name="place_free",
        signature=["x", "y", "z", "self_obj"],
        python_template="pgsl_runtime.place_free({x}, {y}, {z}, {self_obj})",
        description="3D collision check at a target position."
    ),

    # ---- Drawing, Shaders, & Appearance -------------------------------------

    PGSLCommandSpec(
        name="Draw_Self_2D",
        signature=["self_obj"],
        python_template="pgsl_runtime.Draw_Self_2D({self_obj})",
        description="Draw the current instance's sprite in 2D."
    ),
    PGSLCommandSpec(
        name="Draw_Rect_2D",
        signature=["x1", "y1", "x2", "y2", "color", "filled"],
        python_template="pgsl_runtime.Draw_Rect_2D({x1}, {y1}, {x2}, {y2}, {color}, {filled})",
        description="Draw a 2D rectangle."
    ),
    PGSLCommandSpec(
        name="Draw_Clear",
        signature=["color"],
        python_template="pgsl_runtime.Draw_Clear({color})",
        description="Clear the screen with a color."
    ),
    PGSLCommandSpec(
        name="Draw_Update",
        signature=[],
        python_template="pgsl_runtime.Draw_Update()",
        description="Update the display and handle events."
    ),
    PGSLCommandSpec(
        name="Draw_Wait",
        signature=["ms"],
        python_template="pgsl_runtime.Draw_Wait({ms})",
        description="Wait while keeping window responsive."
    ),
    PGSLCommandSpec(
        name="Draw_Self_3D",
        signature=["self_obj"],
        python_template="pgsl_runtime.Draw_Self_3D({self_obj})",
        description="Queue the current instance for 3D drawing."
    ),
    PGSLCommandSpec(
        name="sprite_set_alpha",
        signature=["self_obj", "alpha"],
        python_template="pgsl_runtime.sprite_set_alpha({self_obj}, {alpha})",
        description="Set per-instance sprite alpha (0–1 or 0–255)."
    ),
    PGSLCommandSpec(
        name="model_set_3d_scale",
        signature=["self_obj", "sx", "sy", "sz"],
        python_template="pgsl_runtime.model_set_3d_scale({self_obj}, {sx}, {sy}, {sz})",
        description="Set 3D scale vector for a model instance."
    ),
    PGSLCommandSpec(
        name="shader_use",
        signature=["shader"],
        python_template="pgsl_runtime.shader_use({shader})",
        description="Select a global post-process shader."
    ),
    PGSLCommandSpec(
        name="shader_set_uniform",
        signature=["name", "value"],
        python_template="pgsl_runtime.shader_set_uniform({name}, {value})",
        description="Set a uniform for the active post-process shader."
    ),
    PGSLCommandSpec(
        name="shader_use_object",
        signature=["obj", "shader"],
        python_template="pgsl_runtime.shader_use_object({obj}, {shader})",
        description="Set a per-object shader (non-instanced draw only)."
    ),

    # ---- High-Performance Voxel & Compute -----------------------------------

    PGSLCommandSpec(
        name="compute_shader_load",
        signature=["resource"],
        python_template="pgsl_runtime.compute_shader_load({resource})",
        description="Compile and return a compute shader program id."
    ),
    PGSLCommandSpec(
        name="compute_shader_run",
        signature=["shader_id", "work_size", "local_group_size"],
        python_template="pgsl_runtime.compute_shader_run({shader_id}, {work_size}, {local_group_size})",
        description="Dispatch a compute shader and sync memory."
    ),
    PGSLCommandSpec(
        name="compute_buffer_create",
        signature=["size_bytes"],
        python_template="pgsl_runtime.compute_buffer_create({size_bytes})",
        description="Create an SSBO of given byte size."
    ),
    PGSLCommandSpec(
        name="bake_mesh_from_map",
        signature=["buffer_data"],
        python_template="pgsl_runtime.bake_mesh_from_map({buffer_data})",
        description="Run voxel meshing on CPU and upload to GPU."
    ),
    PGSLCommandSpec(
        name="chunk_set_position",
        signature=["chunk_mesh", "worldX", "worldY", "worldZ"],
        python_template="pgsl_runtime.chunk_set_position({chunk_mesh}, {worldX}, {worldY}, {worldZ})",
        description="Position a chunk mesh in world space."
    ),

    # ---- Input, Audio, & Networking -----------------------------------------

    PGSLCommandSpec(
        name="key_check",
        signature=["key"],
        python_template="pgsl_runtime.key_check({key})",
        description="Return True if the key is currently held."
    ),
    PGSLCommandSpec(
        name="mouse_delta",
        signature=[],
        python_template="pgsl_runtime.mouse_delta()",
        description="Return relative mouse movement (dx, dy)."
    ),
    PGSLCommandSpec(
        name="sound_play",
        signature=["name", "loops"],
        python_template="pgsl_runtime.sound_play({name}, {loops})",
        description="Play a sound resource with loop count."
    ),
    PGSLCommandSpec(
        name="net_host",
        signature=["port"],
        python_template="pgsl_runtime.net_host({port})",
        description="Start a network server for the current game state."
    ),
    PGSLCommandSpec(
        name="net_peers",
        signature=[],
        python_template="pgsl_runtime.net_peers()",
        description="Return the list of connected peers."
    ),
    PGSLCommandSpec(
        name="net_sync_position",
        signature=["obj_id"],
        python_template="pgsl_runtime.net_sync_position({obj_id})",
        description="Synchronise an object's position over the network."
    ),

    # ---- Particles -----------------------------------------------------------

    PGSLCommandSpec(
        name="particle_system_create",
        signature=["name"],
        python_template="pgsl_runtime.particle_system_create({name})",
        description="Create a named particle system."
    ),
    PGSLCommandSpec(
        name="particle_system_emit",
        signature=["system", "x", "y", "z", "amount"],
        python_template="pgsl_runtime.particle_system_emit({system}, {x}, {y}, {z}, {amount})",
        description="Emit a number of particles from a position."
    ),
    PGSLCommandSpec(
        name="particle_set_color_range",
        signature=["system", "r1", "g1", "b1", "a1", "r2", "g2", "b2", "a2"],
        python_template="pgsl_runtime.particle_set_color_range({system}, {r1}, {g1}, {b1}, {a1}, {r2}, {g2}, {b2}, {a2})",
        description="Set start and end colours for particles."
    ),
]


PGSL_COMMANDS: Dict[str, PGSLCommandSpec] = {
    spec.name: spec for spec in _COMMAND_SPECS
}


def get_all_command_names() -> List[str]:
    """Convenience: list of all PGSL command names (for autocomplete)."""
    return sorted(PGSL_COMMANDS.keys())


def get_manual_entries() -> List[PGSLCommandSpec]:
    """Return all specs for use in a help/manual UI."""
    return list(_COMMAND_SPECS)
