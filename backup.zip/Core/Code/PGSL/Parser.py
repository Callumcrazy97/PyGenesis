# Parser.py
from __future__ import annotations

import io
import math
import sys
from contextlib import redirect_stdout
from typing import Dict, Tuple

try:
    import numpy  # used in some templates
except ImportError:
    numpy = None  # Optional dependency

try:
    from .PGSL_Commands import PGSL_COMMANDS, PGSLCommandSpec
except ImportError:
    # For standalone testing
    from PGSL_Commands import PGSL_COMMANDS, PGSLCommandSpec


class PGSLParserError(Exception):
    pass


def _parse_call(line: str) -> Tuple[str, str]:
    """
    Very small helper: parse a line that *looks* like Command(...)
    Returns (command_name, arg_string) or raises PGSLParserError.
    """
    stripped = line.strip()
    if not stripped.endswith(")"):
        raise PGSLParserError(f"Not a PGSL call: {line!r}")

    idx = stripped.find("(")
    if idx <= 0:
        raise PGSLParserError(f"Not a PGSL call: {line!r}")

    cmd = stripped[:idx].strip()
    args = stripped[idx + 1:-1].strip()  # inside parentheses
    return cmd, args


def _split_args(arg_string: str) -> list:
    """
    Naive comma splitter.
    Good enough for simple expressions; you can replace with a
    proper parser later if you add more complex syntax.
    """
    if not arg_string:
        return []
    parts = []
    depth = 0
    current = []
    for ch in arg_string:
        if ch == "," and depth == 0:
            parts.append("".join(current).strip())
            current = []
        else:
            if ch in "([{" and depth >= 0:
                depth += 1
            elif ch in ")]}" and depth > 0:
                depth -= 1
            current.append(ch)
    if current:
        parts.append("".join(current).strip())
    return parts


def transpile_line(line: str) -> str:
    """
    Transpile a single line of PGSL to Python.
    If the line is not recognised as a PGSL command, it is returned as-is.
    """
    stripped = line.strip()
    if not stripped or stripped.startswith("#"):
        return line  # comments / blank lines pass through

    # Handle assignments: "result = Command(...)"
    assignment_prefix = ""
    if "=" in stripped:
        parts = stripped.split("=", 1)
        if len(parts) == 2:
            assignment_prefix = parts[0].strip() + " = "
            stripped = parts[1].strip()
    
    # Try to parse as a command call
    try:
        cmd_name, arg_str = _parse_call(stripped)
    except PGSLParserError:
        # Not a clean Command(...) call: just return the line
        return line

    spec: PGSLCommandSpec | None = PGSL_COMMANDS.get(cmd_name)
    if spec is None:
        # Unknown command, treat as plain Python
        return line

    args = _split_args(arg_str)
    if len(args) != len(spec.signature):
        raise PGSLParserError(
            f"{cmd_name} expects {len(spec.signature)} arg(s) but got {len(args)}: {line!r}"
        )

    mapping: Dict[str, str] = dict(zip(spec.signature, args))

    try:
        python_code = spec.python_template.format(**mapping)
    except KeyError as exc:
        raise PGSLParserError(
            f"Template for {cmd_name} missing placeholder {exc}."
        ) from exc

    # Prepend assignment prefix if there was one
    return assignment_prefix + python_code


def transpile(pgsl_source: str) -> str:
    """
    Transpile multi-line PGSL source into Python source.
    """
    out_lines = []
    for line in pgsl_source.splitlines():
        py_line = transpile_line(line)
        out_lines.append(py_line)
    return "\n".join(out_lines)


def execute_pgsl(pgsl_source: str, globals_dict: Dict | None = None) -> Tuple[str, Dict]:
    """
    Transpile the given PGSL source and execute it with exec().

    Returns (captured_stdout, globals_after_execution).

    You are expected to inject your own 'Core', 'pygame', 'Numba', etc. into
    `globals_dict` before calling this in a real engine context.
    """
    python_source = transpile(pgsl_source)

    if globals_dict is None:
        globals_dict = {}

    # Provide some obvious default imports.
    globals_dict.setdefault("math", math)
    globals_dict.setdefault("numpy", numpy)

    # You must inject Core / pygame / etc. yourself from the host application.
    buf = io.StringIO()
    with redirect_stdout(buf):
        exec(python_source, globals_dict, globals_dict)

    stdout_value = buf.getvalue()
    return stdout_value, globals_dict


if __name__ == "__main__":
    # Quick ad-hoc test
    sample = """
# Sample PGSL script
Run()
dist = point_distance(0, 0, 10, 10)
print("Distance =", dist)
"""
    out, g = execute_pgsl(sample, globals_dict={})
    sys.stdout.write("=== Captured stdout ===\n")
    sys.stdout.write(out)
