"""
Project Manager for Python Game IDE
Handles project creation, loading, and management
"""

import os
import json
import shutil
from datetime import datetime
from PySide6.QtCore import QObject, Signal
from PySide6.QtWidgets import QMessageBox
from Core.Debug import debug

class ProjectManager(QObject):
    # Signals
    project_loaded = Signal(str)  # project_path
    project_created = Signal(str)  # project_path
    project_saved = Signal(str)  # project_path
    resources_loaded = Signal()  # Emitted when all resources finish loading asynchronously
    
    def __init__(self):
        super().__init__()
        self.current_project = None
        self.project_path = None
        self.project_data = {}
        self.runtime_resources = {}  # {resource_type: {resource_id: resource_data}}
        self.is_dirty = False
        
        # Initialize service layer (optional - for future use)
        try:
            from Core.Services.project_service import ProjectService
            self.project_service = ProjectService(self)
        except ImportError:
            self.project_service = None
    
    def create_project(self, project_path, project_name):
        """Create a new project"""
        try:
            # Create project directory structure
            os.makedirs(project_path, exist_ok=True)
            os.makedirs(os.path.join(project_path, "Resources"), exist_ok=True)
            os.makedirs(os.path.join(project_path, "Resources", "Sprites"), exist_ok=True)
            os.makedirs(os.path.join(project_path, "Resources", "Backgrounds"), exist_ok=True)
            os.makedirs(os.path.join(project_path, "Resources", "Objects"), exist_ok=True)
            os.makedirs(os.path.join(project_path, "Resources", "Sounds"), exist_ok=True)
            os.makedirs(os.path.join(project_path, "Resources", "Models"), exist_ok=True)
            os.makedirs(os.path.join(project_path, "Resources", "Rooms"), exist_ok=True)
            os.makedirs(os.path.join(project_path, "Resources", "Textures"), exist_ok=True)
            os.makedirs(os.path.join(project_path, "Scripts"), exist_ok=True)
            os.makedirs(os.path.join(project_path, "Output"), exist_ok=True)
            os.makedirs(os.path.join(project_path, "Recordings"), exist_ok=True)
            
            # Create project virtual environment
            from Core.VenvManager import VenvManager
            VenvManager.create_project_venv(project_path)
            
            # Create project file
            project_data = {
                "name": project_name,
                "version": "1.0.0",
                "description": "A Python game project",
                "settings": {
                    "default_room_size": [1024, 768],
                    "default_sprite_size": 32,
                    "grid_size": 32,
                    "snap_to_grid": True
                },
                "resources": {
                    "sprites": [],
                    "backgrounds": [],
                    "objects": [],
                    "sounds": [],
                    "models": [],
                    "rooms": [],
                    "textures": []
                },
                "dependencies": []  # Project-specific Python packages
            }
            
            project_file = os.path.join(project_path, f"{project_name}.pgproject")
            with open(project_file, 'w') as f:
                json.dump(project_data, f, indent=4)
            
            # Store old project info for deferred purging (non-blocking)
            old_project_to_purge = None
            if hasattr(self, 'project_path') and self.project_path and self.project_path != project_path:
                # Store references to the old project for deferred purging
                old_project_to_purge = {
                    'project_path': self.project_path,
                    'project_data': self.project_data.copy(),
                    'current_project': self.current_project
                }
            
            self.current_project = project_name
            self.project_path = project_path
            self.project_data = project_data
            
            # Initialize runtime resources from project data
            self._load_runtime_resources()
            
            # Emit signal so UI can update immediately
            self.project_created.emit(project_path)
            
            # Defer file purging to after project creation (non-blocking)
            # This prevents blocking the UI during project creation
            if old_project_to_purge:
                # Use QTimer to defer purging to next event loop cycle
                from PySide6.QtCore import QTimer
                def deferred_purge():
                    try:
                        # Store current project state
                        current_project_path = self.project_path
                        current_project_data = self.project_data.copy()
                        current_project = self.current_project
                        
                        # Temporarily restore old project state for purging
                        self.project_path = old_project_to_purge['project_path']
                        self.project_data = old_project_to_purge['project_data']
                        self.current_project = old_project_to_purge['current_project']
                        
                        # Close all editor tabs before purging to avoid file locks
                        if hasattr(self, 'app') and hasattr(self.app, 'main_window'):
                            self.app.main_window.close_all_editor_tabs()
                        
                        # Purge files not in the OLD project's metadata
                        from Core.Debug import debug
                        debug("Starting deferred file purge for previous project...")
                        self.purge_files_not_in_project()
                        debug("File purge completed")
                        
                        # Restore current project state
                        self.project_path = current_project_path
                        self.project_data = current_project_data
                        self.current_project = current_project
                    except Exception as e:
                        from Core.Debug import debug
                        debug(f"Error during deferred file purge: {e}")
                        import traceback
                        debug(traceback.format_exc())
                
                # Defer to next event loop cycle (non-blocking)
                QTimer.singleShot(100, deferred_purge)
            
            return True
            
        except Exception as e:
            QMessageBox.critical(None, "Error", f"Failed to create project: {str(e)}")
            return False
    
    def load_project(self, project_path):
        """Load an existing project (async - loads metadata first, then resources in background)"""
        try:
            if not os.path.exists(project_path):
                QMessageBox.critical(None, "Error", "Project file not found")
                return False
            
            # Read file content first to check for issues
            with open(project_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            # Check if file is empty or contains only whitespace
            if not content.strip():
                QMessageBox.critical(None, "Error", "Project file is empty or corrupted")
                return False
            
            # Try to parse JSON with better error reporting
            try:
                self.project_data = json.loads(content)
            except json.JSONDecodeError as json_error:
                # Provide more detailed error information and attempt recovery
                error_msg = f"JSON parsing error at line {json_error.lineno}, column {json_error.colno}: {json_error.msg}"
                
                # Try to create a backup and attempt recovery
                if self._attempt_project_recovery(project_path, content, json_error):
                    # If recovery succeeded, try loading again
                    return self.load_project(project_path)
                else:
                    QMessageBox.critical(None, "Project File Error", 
                        f"Failed to load project: {error_msg}\n\n"
                        f"The project file is corrupted and could not be automatically recovered.\n"
                        f"A backup has been created. You may need to manually restore from backup or recreate the project.")
                    return False
            
            # If JSON parsing succeeded, continue with project loading
            new_project_path = os.path.dirname(project_path)
            
            # Store old project info for deferred purging (non-blocking)
            old_project_to_purge = None
            if hasattr(self, 'project_path') and self.project_path and self.project_path != new_project_path:
                # Store references to the old project for deferred purging
                old_project_to_purge = {
                    'project_path': self.project_path,
                    'project_data': self.project_data.copy(),
                    'current_project': self.current_project
                }
            
            # Update project data for the new project FIRST (non-blocking)
            self.project_path = new_project_path
            self.current_project = self.project_data.get("name", "Unknown")
            
            # Ensure all resource folders exist
            self._ensure_resource_folders()
            
            # Initialize runtime resources structure (empty initially)
            self.runtime_resources = {
                "sprites": {},
                "backgrounds": {},
                "objects": {},
                "sounds": {},
                "models": {},
                "rooms": {},
                "textures": {},
                "shaders": {},
                "particles": {},
                "scripts": {}
            }
            
            # Load project asynchronously (metadata first, then resources in background)
            from Core.Services.async_project_loader import AsyncProjectLoader
            self._async_loader = AsyncProjectLoader(new_project_path, self.project_data)
            
            # Connect signals
            self._async_loader.metadata_loaded.connect(self._on_metadata_loaded)
            self._async_loader.resource_loaded.connect(self._on_resource_loaded)
            self._async_loader.loading_complete.connect(self._on_loading_complete)
            self._async_loader.loading_error.connect(self._on_loading_error)
            
            # Start async loading
            self._async_loader.start()
            
            # Emit signal immediately with metadata (UI can update right away)
            # Full resources will be loaded in background
            self.project_loaded.emit(project_path)
            
            # Defer file purging to after project loads (non-blocking)
            # This prevents blocking the UI during project load
            if old_project_to_purge:
                # Use QTimer to defer purging to next event loop cycle
                from PySide6.QtCore import QTimer
                def deferred_purge():
                    try:
                        # Store current project state
                        current_project_path = self.project_path
                        current_project_data = self.project_data.copy()
                        current_project = self.current_project
                        
                        # Temporarily restore old project state for purging
                        self.project_path = old_project_to_purge['project_path']
                        self.project_data = old_project_to_purge['project_data']
                        self.current_project = old_project_to_purge['current_project']
                        
                        # Close all editor tabs before purging to avoid file locks
                        if hasattr(self, 'app') and hasattr(self.app, 'main_window'):
                            self.app.main_window.close_all_editor_tabs()
                        
                        # Purge files not in the OLD project's metadata
                        from Core.Debug import debug
                        debug("Starting deferred file purge for previous project...")
                        self.purge_files_not_in_project()
                        debug("File purge completed")
                        
                        # Restore current project state
                        self.project_path = current_project_path
                        self.project_data = current_project_data
                        self.current_project = current_project
                    except Exception as e:
                        from Core.Debug import debug
                        debug(f"Error during deferred file purge: {e}")
                        import traceback
                        debug(traceback.format_exc())
                
                # Defer to next event loop cycle (non-blocking)
                QTimer.singleShot(100, deferred_purge)
            
            return True
            
        except Exception as e:
            QMessageBox.critical(None, "Error", f"Failed to load project: {str(e)}")
            return False
    
    def _on_metadata_loaded(self, metadata):
        """Handle metadata loaded signal (fast - for immediate UI update)"""
        from Core.Debug import debug
        debug(f"Project metadata loaded: {metadata.get('name', 'Unknown')}")
        # UI can update immediately with project name, etc.
    
    def _on_resource_loaded(self, resource_type, resource_id, resource_data):
        """Handle resource loaded signal (background loading)"""
        # Add resource to runtime (lazy-loaded - full data loaded when editor opens)
        if resource_type in self.runtime_resources:
            resource_data["_lazy_loaded"] = False  # Metadata only
            self.runtime_resources[resource_type][resource_id] = resource_data
    
    def _on_loading_complete(self):
        """Handle loading complete signal"""
        from Core.Debug import debug
        total_resources = sum(len(r) for r in self.runtime_resources.values())
        debug(f"Project loading complete: {total_resources} resources loaded")
        
        # Emit resources_loaded signal so ResourceTree can refresh with loaded resources
        self.resources_loaded.emit()
        
        # Generate index for next time (in background)
        try:
            from Core.ProjectIndexManager import ProjectIndexManager
            index_manager = ProjectIndexManager(self.project_path)
            index_manager.generate_index(self.runtime_resources)
        except Exception as e:
            debug(f"Failed to generate project index: {e}")
    
    def _on_loading_error(self, error_msg):
        """Handle loading error signal"""
        from Core.Debug import debug
        debug(f"Error loading project resources: {error_msg}")
        QMessageBox.warning(None, "Loading Warning", 
            f"Some resources failed to load:\n{error_msg}\n\n"
            f"The project may be partially loaded.")
    
    def save_project(self):
        """Save current project (async - saves in background without blocking UI)"""
        if not self.project_path:
            return False
        
        try:
            # Save runtime resources to project data (synchronous - fast)
            self._save_runtime_to_project_data()
            
            # Release file handles from all open editors before renaming
            if hasattr(self, 'app') and hasattr(self.app, 'main_window'):
                self._release_editor_file_handles()
            
            # Rename files on disk to match runtime data (synchronous - fast)
            self._rename_files_to_match_runtime()
            
            # Start async save (file writing happens in background)
            from Core.Services.async_project_saver import AsyncProjectSaver
            self._async_saver = AsyncProjectSaver(
                self.project_path,
                self.current_project,
                self.project_data,
                self.runtime_resources
            )
            
            # Connect signals
            self._async_saver.save_complete.connect(self._on_save_complete)
            self._async_saver.save_progress.connect(self._on_save_progress)
            
            # Start async save
            self._async_saver.start()
            
            # Return True immediately (save is in progress)
            return True
            
        except Exception as e:
            QMessageBox.critical(None, "Error", f"Failed to start project save: {str(e)}")
            return False
    
    def _on_save_complete(self, success, message):
        """Handle save complete signal"""
        from Core.Debug import debug
        if success:
            # Clear dirty flag after successful save
            self.is_dirty = False
            
            # Run cleanup AFTER saving project file (in background)
            debug("Running cleanup after saving project file")
            from PySide6.QtCore import QTimer
            QTimer.singleShot(100, self.purge_files_not_in_project)
            
            self.project_saved.emit(self.project_path)
            debug("Project saved successfully")
        else:
            QMessageBox.critical(None, "Save Error", f"Failed to save project:\n{message}")
    
    def _on_save_progress(self, message):
        """Handle save progress signal"""
        from Core.Debug import debug
        debug(f"Save progress: {message}")
    
    
    def purge_files_not_in_project(self):
        """Delete all files that are not referenced in the current project"""
        if not self.project_path:
            return
        
        try:
            # Read the current project file from disk to get the actual state
            project_file = os.path.join(self.project_path, f"{self.current_project}.pgproject")
            if not os.path.exists(project_file):
                from Core.Debug import debug
                debug(f"Project file not found: {project_file}")
                return
            
            from Core.Debug import debug
            debug(f"Purging files for project: {self.current_project}")
            debug(f"Project file: {project_file}")
            
            with open(project_file, 'r', encoding='utf-8') as f:
                current_project_data = json.load(f)
            
            # Get all files that SHOULD exist (referenced in project)
            valid_files = set()
            
            # Check all sprite resources by reading their .sprite files
            sprites = current_project_data.get("resources", {}).get("sprites", [])
            from Core.Debug import debug
            debug(f"Found {len(sprites)} sprites in project:")
            
            for sprite_ref in sprites:
                debug(f"- {sprite_ref.get('name', 'NO_NAME')}")
                
                # Get the parent folder path
                parent_folder = sprite_ref.get("parent_folder", "")
                if parent_folder:
                    sprite_folder = os.path.join(self.project_path, "Resources", "Sprites", parent_folder)
                else:
                    sprite_folder = os.path.join(self.project_path, "Resources", "Sprites")
                
                # Construct path to .sprite file
                sprite_file = os.path.join(sprite_folder, f"{sprite_ref['name']}.sprite")
                debug(f"  Sprite file: {sprite_file}")
                
                if os.path.exists(sprite_file):
                    # Add the .sprite file itself
                    valid_files.add(sprite_file)
                    debug(f"  Added .sprite file to valid_files: {sprite_file}")
                    
                    # Read the .sprite file to get referenced frame files
                    try:
                        with open(sprite_file, 'r', encoding='utf-8') as f:
                            sprite_data = json.load(f)
                        
                        debug(f"  Sprite data from file: frames count: {len(sprite_data.get('frames', []))}")
                        
                        # Add referenced frame files
                        frames = sprite_data.get("frames", [])
                        for frame in frames:
                            if "file" in frame:
                                frame_file = os.path.join(sprite_folder, frame["file"])
                                if os.path.exists(frame_file):
                                    valid_files.add(frame_file)
                                    debug(f"  Added frame file to valid_files: {frame_file}")
                        
                    except Exception as e:
                        debug(f"  Error reading sprite file: {e}")
                else:
                    debug(f"  .sprite file not found: {sprite_file}")
            
            # Check all sound resources by reading their .sound files
            sounds = current_project_data.get("resources", {}).get("sounds", [])
            debug(f"Found {len(sounds)} sounds in project:")
            debug(f" Project data structure: {current_project_data.get('resources', {}).keys()}")
            
            for sound_ref in sounds:
                debug(f" - {sound_ref.get('name', 'NO_NAME')}")
                
                # Get the parent folder path
                parent_folder = sound_ref.get("parent_folder", "")
                if parent_folder:
                    sound_folder = os.path.join(self.project_path, "Resources", "Sounds", parent_folder)
                else:
                    sound_folder = os.path.join(self.project_path, "Resources", "Sounds")
                
                # Construct path to .sound file
                sound_file = os.path.join(sound_folder, f"{sound_ref['name']}.sound")
                debug(f"   Sound file: {sound_file}")
                
                if os.path.exists(sound_file):
                    # Add the .sound file itself
                    valid_files.add(sound_file)
                    debug(f"   Added .sound file to valid_files: {sound_file}")
                    
                    # Read the .sound file to get referenced audio files
                    try:
                        with open(sound_file, 'r', encoding='utf-8') as f:
                            sound_data = json.load(f)
                        
                        debug(f"   Sound data from file: {sound_data}")
                        
                        # Add referenced audio files
                        audio_file = sound_data.get("audio_file")
                        if audio_file:
                            audio_path = os.path.join(sound_folder, audio_file)
                            debug(f"   Audio file: '{audio_file}'")
                            debug(f"   Audio path: '{audio_path}'")
                            if os.path.exists(audio_path):
                                valid_files.add(audio_path)
                                debug(f"   Added audio file to valid_files: {audio_path}")
                            else:
                                debug(f"   Audio file not found: {audio_path}")
                        
                        # Add original_audio_file if it exists
                        original_audio_file = sound_data.get("original_audio_file")
                        if original_audio_file and os.path.exists(original_audio_file):
                            valid_files.add(original_audio_file)
                            debug(f"   Added original_audio_file to valid_files: {original_audio_file}")
                        
                    except Exception as e:
                        debug(f"   Error reading sound file: {e}")
                else:
                    debug(f"   .sound file not found: {sound_file}")
            
            # Check all model resources by reading their .model files
            models = current_project_data.get("resources", {}).get("models", [])
            debug(f" Found {len(models)} models in project:")
            
            for model_ref in models:
                debug(f" - {model_ref.get('name', 'NO_NAME')}")
                
                # Get the parent folder path
                parent_folder = model_ref.get("parent_folder", "")
                if parent_folder:
                    model_folder = os.path.join(self.project_path, "Resources", "Models", parent_folder)
                else:
                    model_folder = os.path.join(self.project_path, "Resources", "Models")
                
                # Construct path to .model file
                model_file = os.path.join(model_folder, f"{model_ref['name']}.model")
                debug(f"   Model file: {model_file}")
                
                if os.path.exists(model_file):
                    # Add the .model file itself
                    valid_files.add(model_file)
                    debug(f"   Added .model file to valid_files: {model_file}")
                    
                    # Read the .model file to get referenced model files
                    try:
                        with open(model_file, 'r', encoding='utf-8') as f:
                            model_data = json.load(f)
                        
                        debug(f"   Model data from file: {model_data}")
                        
                        # Add referenced model files (.obj, .glb, .gltf, .dae)
                        # Always use model_file (relative filename) to construct path
                        model_file_ref = model_data.get("model_file")
                        
                        if model_file_ref:
                            # model_file should be just the filename
                            model_filename = os.path.basename(model_file_ref)  # Safety: extract filename
                            # Try exact match first
                            model_path = os.path.join(model_folder, model_filename)
                            if os.path.exists(model_path):
                                valid_files.add(model_path)
                                debug(f"   Added model file to valid_files: {model_path}")
                            else:
                                # Try with common model extensions if filename doesn't have one
                                if not os.path.splitext(model_filename)[1]:
                                    for ext in ['.obj', '.glb', '.gltf', '.dae']:
                                        model_path_with_ext = os.path.join(model_folder, model_filename + ext)
                                        if os.path.exists(model_path_with_ext):
                                            valid_files.add(model_path_with_ext)
                                            debug(f"   Added model file to valid_files (with extension): {model_path_with_ext}")
                                            break
                        
                        # Add MTL file if it exists
                        mtl_file_ref = model_data.get("mtl_file")
                        if mtl_file_ref:
                            mtl_filename = os.path.basename(mtl_file_ref)
                            # Try exact match first
                            mtl_path = os.path.join(model_folder, mtl_filename)
                            if os.path.exists(mtl_path):
                                valid_files.add(mtl_path)
                                debug(f"   Added MTL file to valid_files: {mtl_path}")
                            else:
                                # Try with .mtl extension if filename doesn't have one
                                if not os.path.splitext(mtl_filename)[1]:
                                    mtl_path_with_ext = os.path.join(model_folder, mtl_filename + '.mtl')
                                    if os.path.exists(mtl_path_with_ext):
                                        valid_files.add(mtl_path_with_ext)
                                        debug(f"   Added MTL file to valid_files (with extension): {mtl_path_with_ext}")
                        
                        # Add texture files if they exist
                        # First check texture_paths (new organized structure: Textures/ModelName/texture.png)
                        texture_paths_ref = model_data.get("texture_paths", [])
                        textures_base_folder = os.path.join(self.project_path, "Resources", "Textures")
                        for tex_path_rel in texture_paths_ref:
                            if tex_path_rel:
                                # texture_paths are relative to Resources/Textures (e.g., "Link/Tex_0012_0.png")
                                full_tex_path = os.path.join(textures_base_folder, tex_path_rel)
                                if os.path.exists(full_tex_path):
                                    valid_files.add(full_tex_path)
                                    debug(f"   Added texture file from texture_paths to valid_files: {full_tex_path}")
                        
                        # Then check texture_files (backwards compatibility: filenames in Models folder or Textures/ModelName)
                        texture_files_ref = model_data.get("texture_files", [])
                        model_name = model_ref.get("name", "")
                        textures_model_folder = os.path.join(textures_base_folder, model_name) if model_name else None
                        
                        for tex_file_ref in texture_files_ref:
                            if tex_file_ref:
                                tex_filename = os.path.basename(tex_file_ref)
                                
                                # First try Textures/ModelName folder (new organized structure)
                                if textures_model_folder:
                                    tex_path_in_textures = os.path.join(textures_model_folder, tex_filename)
                                    if os.path.exists(tex_path_in_textures):
                                        valid_files.add(tex_path_in_textures)
                                        debug(f"   Added texture file from Textures/{model_name} to valid_files: {tex_path_in_textures}")
                                        continue
                                
                                # Fallback: try Models folder (backwards compatibility)
                                tex_path = os.path.join(model_folder, tex_filename)
                                if os.path.exists(tex_path):
                                    valid_files.add(tex_path)
                                    debug(f"   Added texture file from Models folder to valid_files: {tex_path}")
                                else:
                                    # Try with common texture extensions if filename doesn't have one
                                    if not os.path.splitext(tex_filename)[1]:
                                        # Try in Textures/ModelName first
                                        if textures_model_folder:
                                            for ext in ['.png', '.jpg', '.jpeg', '.bmp', '.tga', '.dds']:
                                                tex_path_with_ext = os.path.join(textures_model_folder, tex_filename + ext)
                                                if os.path.exists(tex_path_with_ext):
                                                    valid_files.add(tex_path_with_ext)
                                                    debug(f"   Added texture file to valid_files (with extension in Textures): {tex_path_with_ext}")
                                                    break
                                        # Then try Models folder
                                        for ext in ['.png', '.jpg', '.jpeg', '.bmp', '.tga', '.dds']:
                                            tex_path_with_ext = os.path.join(model_folder, tex_filename + ext)
                                            if os.path.exists(tex_path_with_ext):
                                                valid_files.add(tex_path_with_ext)
                                                debug(f"   Added texture file to valid_files (with extension in Models): {tex_path_with_ext}")
                                                break
                                    else:
                                        # Try without extension (in case stored with extension but file doesn't have it)
                                        base_name = os.path.splitext(tex_filename)[0]
                                        # Try in Textures/ModelName first
                                        if textures_model_folder:
                                            for ext in ['.png', '.jpg', '.jpeg', '.bmp', '.tga', '.dds']:
                                                tex_path_no_ext = os.path.join(textures_model_folder, base_name + ext)
                                                if os.path.exists(tex_path_no_ext):
                                                    valid_files.add(tex_path_no_ext)
                                                    debug(f"   Added texture file to valid_files (without stored extension in Textures): {tex_path_no_ext}")
                                                    break
                                        # Then try Models folder
                                        for ext in ['.png', '.jpg', '.jpeg', '.bmp', '.tga', '.dds']:
                                            tex_path_no_ext = os.path.join(model_folder, base_name + ext)
                                            if os.path.exists(tex_path_no_ext):
                                                valid_files.add(tex_path_no_ext)
                                                debug(f"   Added texture file to valid_files (without stored extension in Models): {tex_path_no_ext}")
                                                break
                        
                        # Note: original_model_file is now just a reference filename, not used for paths
                        
                    except Exception as e:
                        debug(f"   Error reading model file: {e}")
                else:
                    debug(f"   .model file not found: {model_file}")
            
            # Check all texture resources by reading their .texture files
            textures = current_project_data.get("resources", {}).get("textures", [])
            debug(f" Found {len(textures)} textures in project:")
            
            for texture_ref in textures:
                debug(f" - {texture_ref.get('name', 'NO_NAME')}")
                
                # Get the parent folder path
                parent_folder = texture_ref.get("parent_folder", "")
                if parent_folder:
                    texture_folder = os.path.join(self.project_path, "Resources", "Textures", parent_folder)
                else:
                    texture_folder = os.path.join(self.project_path, "Resources", "Textures")
                
                # Construct path to .texture file
                texture_file = os.path.join(texture_folder, f"{texture_ref['name']}.texture")
                debug(f"   Texture file: {texture_file}")
                
                if os.path.exists(texture_file):
                    # Add the .texture file itself
                    valid_files.add(texture_file)
                    debug(f"   Added .texture file to valid_files: {texture_file}")
                    
                    # Read the .texture file to get referenced texture image files (from frames array)
                    try:
                        with open(texture_file, 'r', encoding='utf-8') as f:
                            texture_data = json.load(f)
                        
                        debug(f"   Texture data from file: frames count: {len(texture_data.get('frames', []))}")
                        
                        # Add referenced texture image files from frames array
                        frames = texture_data.get("frames", [])
                        for frame in frames:
                            if "file" in frame:
                                # Frame file is relative to texture_folder
                                frame_file = frame["file"]
                                frame_path = os.path.join(texture_folder, frame_file)
                                if os.path.exists(frame_path):
                                    valid_files.add(frame_path)
                                    debug(f"   Added texture frame file to valid_files: {frame_path}")
                                else:
                                    debug(f"   Warning - Texture frame file not found: {frame_path}")
                        
                        # Legacy support: also check for texture_file field (old format)
                        texture_file_ref = texture_data.get("texture_file")
                        if texture_file_ref:
                            texture_filename = os.path.basename(texture_file_ref)
                            texture_img_path = os.path.join(texture_folder, texture_filename)
                            if os.path.exists(texture_img_path):
                                valid_files.add(texture_img_path)
                                debug(f"   Added texture image file to valid_files (legacy): {texture_img_path}")
                        
                    except Exception as e:
                        debug(f"   Error reading texture file: {e}")
                        import traceback
                        traceback.print_exc()
                else:
                    debug(f"   .texture file not found: {texture_file}")
            
            # Check all script resources by reading their .script files
            scripts = current_project_data.get("resources", {}).get("scripts", [])
            debug(f" Found {len(scripts)} scripts in project:")
            
            for script_ref in scripts:
                debug(f" - {script_ref.get('name', 'NO_NAME')}")
                
                # Get the parent folder path
                parent_folder = script_ref.get("parent_folder", "")
                if parent_folder:
                    script_folder = os.path.join(self.project_path, "Resources", "Scripts", parent_folder)
                else:
                    script_folder = os.path.join(self.project_path, "Resources", "Scripts")
                
                # Construct path to .script file
                script_file = os.path.join(script_folder, f"{script_ref['name']}.script")
                debug(f"   Script file: {script_file}")
                
                if os.path.exists(script_file):
                    # Add the .script file itself
                    valid_files.add(script_file)
                    debug(f"   Added .script file to valid_files: {script_file}")
                else:
                    debug(f"   .script file not found: {script_file}")
            
            # Check all background resources by reading their .background files
            backgrounds = current_project_data.get("resources", {}).get("backgrounds", [])
            debug(f" Found {len(backgrounds)} backgrounds in project:")
            
            for background_ref in backgrounds:
                debug(f" - {background_ref.get('name', 'NO_NAME')}")
                
                # Get the parent folder path
                parent_folder = background_ref.get("parent_folder", "")
                if parent_folder:
                    background_folder = os.path.join(self.project_path, "Resources", "Backgrounds", parent_folder)
                else:
                    background_folder = os.path.join(self.project_path, "Resources", "Backgrounds")
                
                # Construct path to .background file
                background_file = os.path.join(background_folder, f"{background_ref['name']}.background")
                debug(f"   Background file: {background_file}")
                
                if os.path.exists(background_file):
                    # Add the .background file itself
                    valid_files.add(background_file)
                    debug(f"   Added .background file to valid_files: {background_file}")
                    
                    # Read the .background file to get referenced background image files (from frames array)
                    try:
                        with open(background_file, 'r', encoding='utf-8') as f:
                            background_data = json.load(f)
                        
                        debug(f"   Background data from file: frames count: {len(background_data.get('frames', []))}")
                        
                        # Add referenced background image files from frames array
                        frames = background_data.get("frames", [])
                        for frame in frames:
                            if "file" in frame:
                                # Frame file is relative to background_folder
                                frame_file = frame["file"]
                                frame_path = os.path.join(background_folder, frame_file)
                                if os.path.exists(frame_path):
                                    valid_files.add(frame_path)
                                    debug(f"   Added background frame file to valid_files: {frame_path}")
                                else:
                                    debug(f"   Warning - Background frame file not found: {frame_path}")
                        
                        # Legacy support: also check for image_file field (old format)
                        image_file_ref = background_data.get("image_file")
                        if image_file_ref:
                            image_filename = os.path.basename(image_file_ref)
                            image_path = os.path.join(background_folder, image_filename)
                            if os.path.exists(image_path):
                                valid_files.add(image_path)
                                debug(f"   Added background image file to valid_files (legacy): {image_path}")
                        
                    except Exception as e:
                        debug(f"   Error reading background file: {e}")
                        import traceback
                        traceback.print_exc()
                else:
                    debug(f"   .background file not found: {background_file}")
            
            # Check all object resources by reading their .object files
            objects = current_project_data.get("resources", {}).get("objects", [])
            debug(f" Found {len(objects)} objects in project:")
            
            for object_ref in objects:
                object_name = object_ref.get('name', '')
                if not object_name:
                    debug(f"   Skipping object with no name: {object_ref}")
                    continue
                
                debug(f" - {object_name}")
                
                # Get the parent folder path
                parent_folder = object_ref.get("parent_folder", "")
                if parent_folder:
                    object_folder = os.path.join(self.project_path, "Resources", "Objects", parent_folder)
                else:
                    object_folder = os.path.join(self.project_path, "Resources", "Objects")
                
                # Construct path to .object file
                object_file = os.path.join(object_folder, f"{object_name}.object")
                debug(f"   Object file: {object_file}")
                
                if os.path.exists(object_file):
                    # Add the .object file itself
                    valid_files.add(object_file)
                    debug(f"   Added .object file to valid_files: {object_file}")
                    
                    # Read the .object file to get referenced .pgsl event files
                    try:
                        with open(object_file, 'r', encoding='utf-8') as f:
                            object_data = json.load(f)
                        
                        debug(f"   Object data from file: events count: {len(object_data.get('events', {}))}")
                        
                        # Add referenced .pgsl event files
                        events = object_data.get("events", {})
                        for event_id, event_ref in events.items():
                            if event_ref and event_ref.endswith(".pgsl"):
                                # event_ref is a filename (e.g., "Object2_Create.pgsl")
                                pgsl_path = os.path.join(object_folder, event_ref)
                                if os.path.exists(pgsl_path):
                                    valid_files.add(pgsl_path)
                                    debug(f"   Added event file to valid_files: {pgsl_path}")
                                else:
                                    debug(f"   Event file not found: {pgsl_path}")
                    except Exception as e:
                        debug(f"   Error reading object file: {e}")
                else:
                    debug(f"   .object file not found: {object_file}")
            
            # Check all room resources by reading their .room files
            rooms = current_project_data.get("resources", {}).get("rooms", [])
            debug(f" Found {len(rooms)} rooms in project:")
            
            for room_ref in rooms:
                debug(f" - {room_ref.get('name', 'NO_NAME')}")
                
                # Get the parent folder path
                parent_folder = room_ref.get("parent_folder", "")
                if parent_folder:
                    room_folder = os.path.join(self.project_path, "Resources", "Rooms", parent_folder)
                else:
                    room_folder = os.path.join(self.project_path, "Resources", "Rooms")
                
                # Construct path to .room file
                room_file = os.path.join(room_folder, f"{room_ref['name']}.room")
                debug(f"   Room file: {room_file}")
                
                if os.path.exists(room_file):
                    # Add the .room file itself
                    valid_files.add(room_file)
                    debug(f"   Added .room file to valid_files: {room_file}")
                else:
                    debug(f"   .room file not found: {room_file}")
            
            # Get all files that DO exist in Resources folder
            resources_folder = os.path.join(self.project_path, "Resources")
            all_files = set()
            
            if os.path.exists(resources_folder):
                for root, dirs, files in os.walk(resources_folder):
                    for file in files:
                        if file.endswith(('.png', '.jpg', '.jpeg', '.bmp', '.sprite', '.object', '.sound', '.model', '.room', 
                                         '.wav', '.mp3', '.ogg', '.flac', '.m4a', '.midi', '.mid', '.obj', '.glb', '.gltf', 
                                         '.texture', '.background', '.tga', '.dds', '.pgsl', '.shader', '.particle', '.script',
                                         '.glsl', '.compute', '.vert', '.frag', '.geom', '.comp')):
                            all_files.add(os.path.join(root, file))
            
            # Find files that exist but are not in the project
            files_to_delete = all_files - valid_files
            
            # Additional check for orphaned frame files (PNG files without corresponding .sprite files)
            sprites_folder = os.path.join(self.project_path, "Resources", "Sprites")
            if os.path.exists(sprites_folder):
                for root, dirs, files in os.walk(sprites_folder):
                    for file in files:
                        if file.endswith('.png'):
                            # Check if this is a frame file (pattern: name_number.png)
                            import re
                            match = re.match(r'^(.+)_(\d+)\.png$', file)
                            if match:
                                sprite_name = match.group(1)
                                # Look for corresponding .sprite file in the same directory
                                sprite_file = os.path.join(root, f"{sprite_name}.sprite")
                                if not os.path.exists(sprite_file):
                                    # This is an orphaned frame file
                                    orphaned_file = os.path.join(root, file)
                                    if orphaned_file not in valid_files:
                                        files_to_delete.add(orphaned_file)
                                        print(f"Found orphaned frame file: {os.path.relpath(orphaned_file, self.project_path)}")
                            else:
                                # Check if this PNG file is referenced by any sprite in the project
                                png_file = os.path.join(root, file)
                                if png_file not in valid_files:
                                    # This PNG file is not referenced by any sprite
                                    files_to_delete.add(png_file)
                                    print(f"Found unreferenced PNG file: {os.path.relpath(png_file, self.project_path)}")
            
            # Additional check for orphaned audio files (audio files without corresponding .sound files)
            sounds_folder = os.path.join(self.project_path, "Resources", "Sounds")
            if os.path.exists(sounds_folder):
                debug(f" Checking sounds folder: {sounds_folder}")
                debug(f" Valid files so far: {len(valid_files)} files")
                for root, dirs, files in os.walk(sounds_folder):
                    for file in files:
                        if file.endswith(('.wav', '.mp3', '.ogg', '.flac', '.m4a', '.midi', '.mid')):
                            # Check if this audio file is referenced by any sound in the project
                            audio_file = os.path.join(root, file)
                            debug(f" Checking audio file: {audio_file}")
                            debug(f" Is in valid_files: {audio_file in valid_files}")
                            if audio_file not in valid_files:
                                # This audio file is not referenced by any sound
                                files_to_delete.add(audio_file)
                                print(f"Found unreferenced audio file: {os.path.relpath(audio_file, self.project_path)}")
                            else:
                                debug(f" Audio file is valid: {os.path.relpath(audio_file, self.project_path)}")
            
            # Additional check for orphaned files in Models folder (MTL, model files, texture files)
            models_folder = os.path.join(self.project_path, "Resources", "Models")
            if os.path.exists(models_folder):
                debug(f" Checking Models folder for orphaned files: {models_folder}")
                for root, dirs, files in os.walk(models_folder):
                    for file in files:
                        # Check for MTL files, model files (.obj, .glb, .gltf, .dae), and texture files
                        if file.endswith(('.mtl', '.obj', '.glb', '.gltf', '.dae', '.png', '.jpg', '.jpeg', '.bmp', '.tga', '.dds')):
                            file_path = os.path.join(root, file)
                            if file_path not in valid_files:
                                # This file is not referenced by any model
                                files_to_delete.add(file_path)
                                print(f"Found orphaned file in Models folder: {os.path.relpath(file_path, self.project_path)}")
            
            # Additional check for orphaned .pgsl files (.pgsl files without corresponding .object files)
            objects_folder = os.path.join(self.project_path, "Resources", "Objects")
            if os.path.exists(objects_folder):
                debug(f" Checking Objects folder for orphaned .pgsl files: {objects_folder}")
                for root, dirs, files in os.walk(objects_folder):
                    for file in files:
                        if file.endswith('.pgsl'):
                            # Check if this .pgsl file is referenced by any object in the project
                            pgsl_file = os.path.join(root, file)
                            if pgsl_file not in valid_files:
                                # This .pgsl file is not referenced by any object
                                files_to_delete.add(pgsl_file)
                                print(f"Found orphaned .pgsl file: {os.path.relpath(pgsl_file, self.project_path)}")
            
            # Delete files not in project
            for file_to_delete in files_to_delete:
                try:
                    os.remove(file_to_delete)
                    rel_path = os.path.relpath(file_to_delete, self.project_path)
                    print(f"Purged file not in project: {rel_path}")
                except Exception as e:
                    print(f"Failed to delete file {file_to_delete}: {e}")
            
            if files_to_delete:
                print(f"Purged {len(files_to_delete)} files not in project")
            
        except Exception as e:
            print(f"Error purging files: {e}")
    
    def get_project_name(self):
        """Get current project name"""
        return self.current_project
    
    def get_project_path(self):
        """Get current project path"""
        return self.project_path
    
    def get_project_data(self):
        """Get current project data"""
        return self.project_data
    
    def _ensure_resource_folders(self):
        """Ensure all resource folders exist"""
        if not self.project_path:
            return
        
        resource_folders = [
            "Sprites", "Backgrounds", "Textures", "Sounds", "Models",
            "Rooms", "Objects", "Shaders", "Particles", "Scripts"
        ]
        
        resources_base = os.path.join(self.project_path, "Resources")
        os.makedirs(resources_base, exist_ok=True)
        
        for folder in resource_folders:
            folder_path = os.path.join(resources_base, folder)
            os.makedirs(folder_path, exist_ok=True)
    
    def _load_runtime_resources(self):
        """Load resources from project data into runtime - OPTIMIZED with project index"""
        
        # Ensure all resource folders exist (especially Models and Textures which might be missing in old projects)
        if self.project_path:
            resources_base = os.path.join(self.project_path, "Resources")
            os.makedirs(os.path.join(resources_base, "Models"), exist_ok=True)
            os.makedirs(os.path.join(resources_base, "Textures"), exist_ok=True)
        
        self.runtime_resources = {
            "sprites": {},
            "backgrounds": {},
            "objects": {},
            "sounds": {},
            "models": {},
            "rooms": {},
            "textures": {},
            "shaders": {},
            "particles": {},
            "scripts": {}
        }
        
        # Try to load from project index first (FAST PATH)
        from Core.ProjectIndexManager import ProjectIndexManager
        index_manager = ProjectIndexManager(self.project_path)
        
        if index_manager.is_index_valid():
            debug("Loading resources from project index (fast path)...")
            index_data = index_manager.load_index()
            
            if index_data:
                # Load metadata from index - this is much faster than reading all files
                for resource_type, type_resources in index_data.items():
                    for resource_id, metadata in type_resources.items():
                        # Store metadata in runtime (lazy loading - full data loaded when editor opens)
                        metadata["type"] = resource_type
                        metadata["_lazy_loaded"] = False  # Flag to indicate full data not loaded yet
                        self.runtime_resources[resource_type][resource_id] = metadata
                
                debug(f" Loaded {sum(len(r) for r in self.runtime_resources.values())} resources from index (metadata only)")
                return
        
        # FALLBACK: Load from project data (SLOW PATH - for projects without index)
        debug("Loading resources from project data (slow path - no index found)...")
        
        # Load resources from project data
        # For objects and rooms, we need to load from actual files to get full data (including events)
        for resource_type, resources in self.project_data.get("resources", {}).items():
            for resource in resources:
                resource_id = resource.get("id")
                if resource_id:
                    # For objects and rooms, load from actual file to get full data including events
                    if resource_type in ["objects", "rooms"]:
                        # Load from the actual .object or .room file
                        resource_name = resource.get("name", "")
                        parent_folder = resource.get("parent_folder", "")
                        
                        if resource_name:
                            # Construct file path
                            folder = "Objects" if resource_type == "objects" else "Rooms"
                            extension = ".object" if resource_type == "objects" else ".room"
                            
                            if parent_folder:
                                file_path = os.path.join(
                                    self.project_path, "Resources", folder, parent_folder, f"{resource_name}{extension}"
                                )
                            else:
                                file_path = os.path.join(
                                    self.project_path, "Resources", folder, f"{resource_name}{extension}"
                                )
                            
                            # Load from file if it exists
                            if os.path.exists(file_path):
                                try:
                                    with open(file_path, 'r', encoding='utf-8') as f:
                                        file_data = json.load(f)
                                    # Use file data (which has events) but keep id from project data
                                    file_data["id"] = resource_id
                                    file_data["type"] = resource_type
                                    file_data["_lazy_loaded"] = True  # Full data loaded
                                    self.runtime_resources[resource_type][resource_id] = file_data
                                    continue
                                except Exception as e:
                                    debug(f"Failed to load {resource_type} file {file_path}: {e}")
                    
                    # For other resource types or if file loading failed, use project data
                    resource_copy = resource.copy()
                    resource_copy["type"] = resource_type
                    resource_copy["_lazy_loaded"] = True  # Full data loaded
                    self.runtime_resources[resource_type][resource_id] = resource_copy
        
        debug(f" Loaded {sum(len(r) for r in self.runtime_resources.values())} resources into runtime")
        
        # Generate index for next time (in background)
        # This will make future loads much faster
        try:
            index_manager.generate_index(self.runtime_resources)
        except Exception as e:
            debug(f"Failed to generate project index: {e}")
    
    def _save_runtime_to_project_data(self):
        """Save runtime resources to project data (simplified - only basic info)"""
        for resource_type, resources in self.runtime_resources.items():
            simplified_resources = []
            for resource in resources.values():
                # Create a simplified version with only basic info
                simplified_resource = {
                    "id": resource.get("id"),
                    "name": resource.get("name"),
                    "type": resource.get("type"),
                    "parent_folder": resource.get("parent_folder", ""),
                    "created": resource.get("created"),
                    "modified": resource.get("modified")
                }
                
                # Add type-specific basic properties only
                if resource_type == "sprites":
                    simplified_resource.update({
                        "width": resource.get("width"),
                        "height": resource.get("height"),
                        "origin_x": resource.get("origin_x"),
                        "origin_y": resource.get("origin_y"),
                        "collision_mask": resource.get("collision_mask"),
                        "tile_horizontal": resource.get("tile_horizontal"),
                        "tile_vertical": resource.get("tile_vertical"),
                        "used_3d": resource.get("used_3d"),
                        "texture_group": resource.get("texture_group")
                    })
                elif resource_type == "sounds":
                    simplified_resource.update({
                        "volume": resource.get("volume"),
                        "loop": resource.get("loop"),
                        "preload": resource.get("preload"),
                        "frequency": resource.get("frequency")
                    })
                elif resource_type == "objects":
                    # Include all object data including events
                    simplified_resource.update({
                        "sprite": resource.get("sprite", ""),
                        "solid": resource.get("solid", False),
                        "depth": resource.get("depth", 0),
                        "persistent": resource.get("persistent", False),
                        "parent": resource.get("parent", ""),
                        "events": resource.get("events", {}),  # CRITICAL: Include events!
                        "frames": resource.get("frames", [])
                    })
                elif resource_type == "rooms":
                    # Include room data
                    simplified_resource.update({
                        "width": resource.get("width"),
                        "height": resource.get("height"),
                        "instances": resource.get("instances", []),
                        "background_color": resource.get("background_color"),
                        "room_order": resource.get("room_order", 0)
                    })
                # Add other resource types as needed
                
                simplified_resources.append(simplified_resource)
            
            self.project_data["resources"][resource_type] = simplified_resources
        
        debug(f" Saved {sum(len(r) for r in self.runtime_resources.values())} simplified resources from runtime to project data")
    
    def get_runtime_resources(self, resource_type):
        """Get all runtime resources of a type"""
        return self.runtime_resources.get(resource_type, {})
    
    def get_runtime_resource(self, resource_type, resource_id):
        """Get a specific runtime resource"""
        return self.runtime_resources.get(resource_type, {}).get(resource_id)
    
    def add_runtime_resource(self, resource_type, resource_id, resource_data):
        """Add a resource to runtime"""
        if resource_type not in self.runtime_resources:
            self.runtime_resources[resource_type] = {}
        
        self.runtime_resources[resource_type][resource_id] = resource_data.copy()
        self.is_dirty = True
        debug(f" Added {resource_type} {resource_id} to runtime")
    
    def update_runtime_resource(self, resource_type, resource_id, resource_data):
        """Update a resource in runtime"""
        debug(f" update_runtime_resource called for {resource_type} {resource_id}")
        debug(f" Resource data audio_file: {resource_data.get('audio_file')}")
        
        if resource_type in self.runtime_resources and resource_id in self.runtime_resources[resource_type]:
            self.runtime_resources[resource_type][resource_id] = resource_data.copy()
            self.is_dirty = True
            debug(f" Updated {resource_type} {resource_id} in runtime")
            debug(f" Runtime data now has audio_file: {self.runtime_resources[resource_type][resource_id].get('audio_file')}")
        else:
            debug(f" Resource {resource_id} not found in runtime {resource_type}")
    
    def remove_runtime_resource(self, resource_type, resource_id):
        """Remove a resource from runtime"""
        if resource_type in self.runtime_resources and resource_id in self.runtime_resources[resource_type]:
            del self.runtime_resources[resource_type][resource_id]
            self.is_dirty = True
            debug(f" Removed {resource_type} {resource_id} from runtime")
    
    def has_pending_changes(self):
        """Check if there are pending changes"""
        return self.is_dirty
    
    def mark_project_dirty(self):
        """Mark the project as having unsaved changes"""
        self.is_dirty = True
        debug(f" Project marked as dirty")
    
    def _release_editor_file_handles(self):
        """Release file handles from all open editors"""
        if not hasattr(self, 'app') or not hasattr(self.app, 'main_window'):
            return
        
        # Get all open editor tabs
        for i in range(self.app.main_window.editor_tabs.count()):
            editor = self.app.main_window.editor_tabs.widget(i)
            if hasattr(editor, 'release_file_handles'):
                try:
                    editor.release_file_handles()
                    debug(f" Released file handles from editor {i}")
                except Exception as e:
                    debug(f" Failed to release file handles from editor {i}: {e}")
    
    def _rename_files_to_match_runtime(self):
        """Rename files on disk to match runtime data"""
        import os
        import shutil
        import glob
        import json
        
        debug(" Renaming files on disk to match runtime data")
        
        for resource_type, resources in self.runtime_resources.items():
            for resource_id, resource_data in resources.items():
                current_name = resource_data.get("name", "")
                if not current_name:
                    continue
                
                # Find the actual file on disk (it might have the old name)
                resource_folder_map = {
                    "sprites": "Sprites",
                    "backgrounds": "Backgrounds", 
                    "objects": "Objects",
                    "sounds": "Sounds",
                    "rooms": "Rooms"
                }
                
                resource_folder = resource_folder_map.get(resource_type, "Sprites")
                parent_folder = resource_data.get("parent_folder", "")
                
                # Build the search path
                search_path = os.path.join(self.project_path, "Resources", resource_folder)
                if parent_folder:
                    search_path = os.path.join(search_path, parent_folder)
                
                # Look for any file with this resource ID in the metadata
                extension = self._get_resource_extension(resource_type)
                pattern = os.path.join(search_path, f"*{extension}")
                matching_files = glob.glob(pattern)
                
                for file_path in matching_files:
                    try:
                        # Check if this file contains our resource ID
                        with open(file_path, 'r', encoding='utf-8') as f:
                            file_data = json.load(f)
                        
                        if file_data.get("id") == resource_id:
                            # Found the file for this resource
                            current_file_name = os.path.basename(file_path)
                            expected_file_name = f"{current_name}{extension}"
                            
                            if current_file_name != expected_file_name:
                                # File needs to be renamed
                                new_file_path = os.path.join(os.path.dirname(file_path), expected_file_name)
                                debug(f" Renaming {current_file_name} to {expected_file_name}")
                                
                                # Update the file content with the new name and frame references
                                file_data["name"] = current_name
                                
                                # For sprites, also update frame file references
                                if resource_type == "sprites":
                                    old_name = current_file_name.replace(extension, '')
                                    frames = file_data.get("frames", [])
                                    for frame in frames:
                                        if isinstance(frame, dict) and "file" in frame:
                                            old_frame_file = frame["file"]
                                            new_frame_file = old_frame_file.replace(old_name, current_name, 1)
                                            frame["file"] = new_frame_file
                                    
                                    # Rename the actual frame files on disk
                                    self._rename_sprite_frame_files(resource_data, old_name, current_name)
                                
                                # For objects, also update .pgsl event file references
                                if resource_type == "objects":
                                    old_name = current_file_name.replace(extension, '')
                                    events = file_data.get("events", {})
                                    for event_id, event_ref in list(events.items()):
                                        if event_ref and event_ref.endswith(".pgsl"):
                                            # event_ref is a filename (e.g., "Object2_Create.pgsl")
                                            # Generate new filename: {new_object_name}_{event_id}.pgsl
                                            new_pgsl_filename = f"{current_name}_{event_id}.pgsl"
                                            
                                            # Rename the actual .pgsl file on disk
                                            old_pgsl_path = os.path.join(os.path.dirname(file_path), event_ref)
                                            new_pgsl_path = os.path.join(os.path.dirname(file_path), new_pgsl_filename)
                                            
                                            if os.path.exists(old_pgsl_path):
                                                try:
                                                    os.rename(old_pgsl_path, new_pgsl_path)
                                                    debug(f"Renamed event file: {event_ref} -> {new_pgsl_filename}")
                                                except Exception as e:
                                                    debug(f"Failed to rename event file {event_ref}: {e}")
                                            
                                            # Update the event reference in the object data
                                            events[event_id] = new_pgsl_filename
                                
                                # Write the updated content to the new file
                                with open(new_file_path, 'w', encoding='utf-8') as f:
                                    json.dump(file_data, f, indent=4, ensure_ascii=False)
                                
                                # Delete the old file
                                os.remove(file_path)
                                
                                debug(f" Successfully renamed {current_file_name} to {expected_file_name} and updated content")
                            
                            break  # Found the file, no need to check others
                            
                    except Exception as e:
                        debug(f" Error checking file {file_path}: {e}")
                        continue
    
    def _get_resource_file_path(self, resource_type, resource_data):
        """Get the file path for a resource"""
        if not self.project_path:
            return None
        
        resource_folder_map = {
            "sprites": "Sprites",
            "backgrounds": "Backgrounds", 
            "objects": "Objects",
            "sounds": "Sounds",
            "models": "Models",
            "rooms": "Rooms",
            "textures": "Textures"
        }
        
        resource_folder = resource_folder_map.get(resource_type, "Sprites")
        parent_folder = resource_data.get("parent_folder", "")
        
        # Build the file path
        file_path = os.path.join(self.project_path, "Resources", resource_folder)
        if parent_folder:
            file_path = os.path.join(file_path, parent_folder)
        
        # Add the resource file name
        resource_name = resource_data.get("name", "")
        if resource_name:
            file_extension = self._get_resource_extension(resource_type)
            file_path = os.path.join(file_path, f"{resource_name}{file_extension}")
        
        return file_path
    
    def _get_resource_extension(self, resource_type):
        """Get the file extension for a resource type"""
        extensions = {
            "sprites": ".sprite",
            "backgrounds": ".background",
            "objects": ".object",
            "textures": ".texture", 
            "sounds": ".sound",
            "rooms": ".room"
        }
        return extensions.get(resource_type, ".sprite")
    
    def _rename_sprite_frame_files(self, sprite_resource, old_name, new_name):
        """Rename all frame files when sprite is renamed"""
        import os
        import shutil
        
        if not self.project_path:
            return
        
        # Get the sprites folder path
        sprites_folder = os.path.join(self.project_path, "Resources", "Sprites")
        parent_folder = sprite_resource.get("parent_folder", "")
        if parent_folder:
            sprites_folder = os.path.join(sprites_folder, parent_folder)
        
        # Rename each frame file
        frames = sprite_resource.get("frames", [])
        for frame in frames:
            if isinstance(frame, dict) and "file" in frame:
                old_frame_file = frame["file"]
                # Calculate the new frame file name
                new_frame_file = old_frame_file.replace(old_name, new_name, 1)
                
                # Rename the actual file on disk
                old_frame_path = os.path.join(sprites_folder, old_frame_file)
                new_frame_path = os.path.join(sprites_folder, new_frame_file)
                
                if os.path.exists(old_frame_path):
                    try:
                        shutil.move(old_frame_path, new_frame_path)
                        debug(f" Renamed frame file {old_frame_file} to {new_frame_file}")
                    except Exception as e:
                        debug(f" Failed to rename frame file {old_frame_file}: {e}")
    
    
    
    def _delete_sprite_files(self, resource_id):
        """Delete sprite files on disk"""
        import os
        
        if not self.project_path:
            return
        
        # Find the resource to get its name and parent folder
        resources = self.project_data.get("resources", {}).get("sprites", [])
        resource = None
        for r in resources:
            if r.get("id") == resource_id:
                resource = r
                break
        
        if not resource:
            return
        
        sprite_name = resource.get("name")
        parent_folder = resource.get("parent_folder", "")
        
        # Build sprite folder path
        sprites_folder = os.path.join(self.project_path, "Resources", "Sprites")
        if parent_folder:
            sprites_folder = os.path.join(sprites_folder, parent_folder)
        
        # Delete sprite file
        sprite_file = os.path.join(sprites_folder, f"{sprite_name}.sprite")
        if os.path.exists(sprite_file):
            os.remove(sprite_file)
        
        # Delete frame files
        frames = resource.get("frames", [])
        for frame in frames:
            if "file" in frame:
                frame_file = os.path.join(sprites_folder, frame["file"])
                if os.path.exists(frame_file):
                    os.remove(frame_file)
    
    def add_resource(self, resource_type, resource_data):
        """Add a resource to the project (in memory only, not saved to disk)"""
        if resource_type in self.project_data["resources"]:
            self.project_data["resources"][resource_type].append(resource_data)
            # Note: Don't auto-save here - only save when user explicitly saves
    
    def remove_resource(self, resource_type, resource_id):
        """Remove a resource from the project"""
        if resource_type in self.project_data["resources"]:
            self.project_data["resources"][resource_type] = [
                r for r in self.project_data["resources"][resource_type] 
                if r.get("id") != resource_id
            ]
            self.save_project()
    
    def get_resources(self, resource_type):
        """Get all resources of a specific type"""
        return self.project_data["resources"].get(resource_type, [])
    
    def _attempt_project_recovery(self, project_path, content, json_error):
        """Attempt to recover a corrupted project file"""
        try:
            # Create backup of corrupted file
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            backup_path = f"{project_path}.corrupted_{timestamp}.backup"
            shutil.copy2(project_path, backup_path)
            
            # Try to fix common JSON issues
            fixed_content = self._fix_common_json_issues(content, json_error)
            
            if fixed_content and fixed_content != content:
                # Try to parse the fixed content
                try:
                    json.loads(fixed_content)
                    # If parsing succeeds, write the fixed content
                    with open(project_path, 'w', encoding='utf-8') as f:
                        f.write(fixed_content)
                    return True
                except json.JSONDecodeError:
                    pass
            
            return False
            
        except Exception as e:
            print(f"Recovery attempt failed: {e}")
            return False
    
    def _fix_common_json_issues(self, content, json_error):
        """Attempt to fix common JSON corruption issues"""
        try:
            lines = content.split('\n')
            
            # If error is at a specific line, try to fix that line
            if json_error.lineno <= len(lines):
                error_line = lines[json_error.lineno - 1]
                
                # Common fixes for JSON issues
                fixed_line = error_line
                
                # Fix trailing commas
                if fixed_line.strip().endswith(','):
                    fixed_line = fixed_line.rstrip().rstrip(',')
                
                # Fix missing quotes around keys
                if ':' in fixed_line and not any(c in fixed_line for c in ['"', "'"]):
                    # This is a more complex fix that would need careful implementation
                    pass
                
                # Fix unescaped quotes
                if fixed_line.count('"') % 2 != 0:
                    # Try to fix unescaped quotes
                    fixed_line = fixed_line.replace('"', '\\"')
                
                # If we made changes, update the content
                if fixed_line != error_line:
                    lines[json_error.lineno - 1] = fixed_line
                    return '\n'.join(lines)
            
            return content
            
        except Exception:
            return content
