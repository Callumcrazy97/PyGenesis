"""
Parser for PGSL (PyGenesis Scripting Language)
Parses tokens into an Abstract Syntax Tree (AST).
"""

from typing import List, Optional
from .lexer import Lexer, Token, TokenType
from .ast import (
    ASTNode, ProgramNode, BlockNode, LiteralNode, IdentifierNode,
    BinaryOpNode, UnaryOpNode, FunctionCallNode, VariableDeclNode,
    AssignmentNode, IfStatementNode, WhileLoopNode, ForLoopNode,
    FunctionDefNode, ReturnStatementNode
)


class ParseError(Exception):
    """Raised when parsing fails"""
    
    def __init__(self, message: str, token: Optional[Token] = None):
        self.message = message
        self.token = token
        if token:
            super().__init__(f"{message} at line {token.line}, column {token.column}")
        else:
            super().__init__(message)


class PGSLParser:
    """Parser for PGSL code"""
    
    def __init__(self, source: str):
        self.lexer = Lexer(source)
        self.tokens: List[Token] = []
        self.current = 0
    
    def parse(self) -> ProgramNode:
        """Parse the source code into an AST"""
        self.tokens = self.lexer.tokenize()
        self.current = 0
        statements = []
        
        while not self.is_at_end():
            if self.match(TokenType.NEWLINE):
                continue
            # Skip comments
            if self.match(TokenType.COMMENT):
                continue
            stmt = self.statement()
            if stmt:
                statements.append(stmt)
        
        return ProgramNode(statements)
    
    def is_at_end(self) -> bool:
        """Check if we've consumed all tokens"""
        return self.peek().type == TokenType.EOF
    
    def peek(self) -> Token:
        """Peek at current token"""
        if self.current >= len(self.tokens):
            return self.tokens[-1] if self.tokens else Token(TokenType.EOF, "", 0, 0)
        return self.tokens[self.current]
    
    def previous(self) -> Token:
        """Get previous token"""
        return self.tokens[self.current - 1]
    
    def advance(self) -> Token:
        """Advance and return current token"""
        if not self.is_at_end():
            self.current += 1
        return self.previous()
    
    def check(self, token_type: TokenType) -> bool:
        """Check if current token matches type"""
        if self.is_at_end():
            return False
        return self.peek().type == token_type
    
    def match(self, *token_types: TokenType) -> bool:
        """Check if current token matches any of the given types"""
        for token_type in token_types:
            if self.check(token_type):
                self.advance()
                return True
        return False
    
    def consume(self, token_type: TokenType, message: str) -> Token:
        """Consume token of expected type or raise error"""
        if self.check(token_type):
            return self.advance()
        raise ParseError(message, self.peek())
    
    def statement(self) -> Optional[ASTNode]:
        """Parse a statement"""
        if self.match(TokenType.IF):
            return self.if_statement()
        elif self.match(TokenType.WHILE):
            return self.while_statement()
        elif self.match(TokenType.FOR):
            return self.for_statement()
        elif self.match(TokenType.RETURN):
            return self.return_statement()
        elif self.match(TokenType.VAR, TokenType.CONST):
            return self.variable_declaration()
        elif self.match(TokenType.FUNCTION):
            return self.function_declaration()
        else:
            return self.expression_statement()
    
    def if_statement(self) -> IfStatementNode:
        """Parse an if statement"""
        line = self.previous().line
        column = self.previous().column
        
        condition = self.expression()
        self.consume(TokenType.COLON, "Expected ':' after if condition")
        
        then_block = self.block()
        else_block = None
        
        if self.match(TokenType.ELIF):
            else_block = self.if_statement()  # elif is just another if
        elif self.match(TokenType.ELSE):
            self.consume(TokenType.COLON, "Expected ':' after else")
            else_block = self.block()
        
        return IfStatementNode(condition, then_block, else_block, line, column)
    
    def while_statement(self) -> WhileLoopNode:
        """Parse a while statement"""
        line = self.previous().line
        column = self.previous().column
        
        condition = self.expression()
        self.consume(TokenType.COLON, "Expected ':' after while condition")
        body = self.block()
        
        return WhileLoopNode(condition, body, line, column)
    
    def for_statement(self) -> ForLoopNode:
        """Parse a for statement"""
        line = self.previous().line
        column = self.previous().column
        
        var_token = self.consume(TokenType.IDENTIFIER, "Expected variable name in for loop")
        variable = var_token.value
        
        self.consume(TokenType.IN, "Expected 'in' in for loop")
        iterable = self.expression()
        self.consume(TokenType.COLON, "Expected ':' after for loop")
        body = self.block()
        
        return ForLoopNode(variable, iterable, body, line, column)
    
    def return_statement(self) -> ReturnStatementNode:
        """Parse a return statement"""
        line = self.previous().line
        column = self.previous().column
        
        value = None
        if not self.check(TokenType.NEWLINE) and not self.check(TokenType.EOF):
            value = self.expression()
        
        return ReturnStatementNode(value, line, column)
    
    def variable_declaration(self) -> VariableDeclNode:
        """Parse a variable declaration"""
        line = self.previous().line
        column = self.previous().column
        var_type = self.previous().value  # 'var' or 'const'
        
        name_token = self.consume(TokenType.IDENTIFIER, "Expected variable name")
        name = name_token.value
        
        initializer = None
        if self.match(TokenType.ASSIGN):
            initializer = self.expression()
        
        return VariableDeclNode(name, var_type, initializer, line, column)
    
    def function_declaration(self) -> FunctionDefNode:
        """Parse a function declaration"""
        line = self.previous().line
        column = self.previous().column
        
        name_token = self.consume(TokenType.IDENTIFIER, "Expected function name")
        name = name_token.value
        
        self.consume(TokenType.LEFT_PAREN, "Expected '(' after function name")
        
        parameters = []
        if not self.check(TokenType.RIGHT_PAREN):
            while True:
                param_token = self.consume(TokenType.IDENTIFIER, "Expected parameter name")
                parameters.append(param_token.value)
                
                if not self.match(TokenType.COMMA):
                    break
        
        self.consume(TokenType.RIGHT_PAREN, "Expected ')' after parameters")
        self.consume(TokenType.COLON, "Expected ':' after function declaration")
        
        body = self.block()
        
        return FunctionDefNode(name, parameters, body, line, column)
    
    def expression_statement(self) -> Optional[ASTNode]:
        """Parse an expression statement"""
        expr = self.expression()
        # Expression statements are just expressions
        return expr
    
    def block(self) -> BlockNode:
        """Parse a block of statements"""
        line = self.previous().line if self.tokens else 0
        column = self.previous().column if self.tokens else 0
        
        # Handle indentation
        if self.match(TokenType.INDENT):
            statements = []
            while not self.check(TokenType.DEDENT) and not self.is_at_end():
                if self.match(TokenType.NEWLINE):
                    continue
                # Skip comments in blocks
                if self.match(TokenType.COMMENT):
                    continue
                stmt = self.statement()
                if stmt:
                    statements.append(stmt)
            
            self.consume(TokenType.DEDENT, "Expected dedent after block")
            return BlockNode(statements, line, column)
        else:
            # Single statement (no indentation)
            stmt = self.statement()
            return BlockNode([stmt] if stmt else [], line, column)
    
    def expression(self) -> ASTNode:
        """Parse an expression"""
        return self.assignment()
    
    def assignment(self) -> ASTNode:
        """Parse an assignment expression"""
        expr = self.or_expr()
        
        if self.match(TokenType.ASSIGN):
            equals = self.previous()
            value = self.assignment()
            
            if isinstance(expr, IdentifierNode):
                return AssignmentNode(expr, value, equals.line, equals.column)
            
            raise ParseError("Invalid assignment target", equals)
        
        return expr
    
    def or_expr(self) -> ASTNode:
        """Parse an OR expression"""
        expr = self.and_expr()
        
        while self.match(TokenType.OR):
            operator = self.previous()
            right = self.and_expr()
            expr = BinaryOpNode(operator.value, expr, right, operator.line, operator.column)
        
        return expr
    
    def and_expr(self) -> ASTNode:
        """Parse an AND expression"""
        expr = self.equality()
        
        while self.match(TokenType.AND):
            operator = self.previous()
            right = self.equality()
            expr = BinaryOpNode(operator.value, expr, right, operator.line, operator.column)
        
        return expr
    
    def equality(self) -> ASTNode:
        """Parse equality expressions"""
        expr = self.comparison()
        
        while self.match(TokenType.EQUALS, TokenType.NOT_EQUALS):
            operator = self.previous()
            right = self.comparison()
            expr = BinaryOpNode(operator.value, expr, right, operator.line, operator.column)
        
        return expr
    
    def comparison(self) -> ASTNode:
        """Parse comparison expressions"""
        expr = self.term()
        
        while self.match(TokenType.GREATER_THAN, TokenType.GREATER_EQUAL,
                         TokenType.LESS_THAN, TokenType.LESS_EQUAL):
            operator = self.previous()
            right = self.term()
            expr = BinaryOpNode(operator.value, expr, right, operator.line, operator.column)
        
        return expr
    
    def term(self) -> ASTNode:
        """Parse addition and subtraction"""
        expr = self.factor()
        
        while self.match(TokenType.PLUS, TokenType.MINUS):
            operator = self.previous()
            right = self.factor()
            expr = BinaryOpNode(operator.value, expr, right, operator.line, operator.column)
        
        return expr
    
    def factor(self) -> ASTNode:
        """Parse multiplication, division, and modulo"""
        expr = self.unary()
        
        while self.match(TokenType.MULTIPLY, TokenType.DIVIDE, TokenType.MODULO):
            operator = self.previous()
            right = self.unary()
            expr = BinaryOpNode(operator.value, expr, right, operator.line, operator.column)
        
        return expr
    
    def unary(self) -> ASTNode:
        """Parse unary expressions"""
        if self.match(TokenType.NOT, TokenType.MINUS):
            operator = self.previous()
            right = self.unary()
            return UnaryOpNode(operator.value, right, operator.line, operator.column)
        
        return self.call()
    
    def call(self) -> ASTNode:
        """Parse function calls and primary expressions"""
        expr = self.primary()
        
        while True:
            if self.match(TokenType.LEFT_PAREN):
                expr = self.finish_call(expr)
            elif self.match(TokenType.DOT):
                name = self.consume(TokenType.IDENTIFIER, "Expected property name after '.'")
                # For now, treat property access as a function call
                expr = FunctionCallNode(name.value, [expr], name.line, name.column)
            else:
                break
        
        return expr
    
    def finish_call(self, callee: ASTNode) -> ASTNode:
        """Finish parsing a function call"""
        arguments = []
        
        if not self.check(TokenType.RIGHT_PAREN):
            while True:
                arguments.append(self.expression())
                if not self.match(TokenType.COMMA):
                    break
        
        paren = self.consume(TokenType.RIGHT_PAREN, "Expected ')' after arguments")
        
        if isinstance(callee, IdentifierNode):
            return FunctionCallNode(callee.name, arguments, callee.line, callee.column)
        else:
            # Anonymous function call
            return FunctionCallNode("", arguments, paren.line, paren.column)
    
    def primary(self) -> ASTNode:
        """Parse primary expressions"""
        if self.match(TokenType.TRUE):
            return LiteralNode(True, "boolean", self.previous().line, self.previous().column)
        if self.match(TokenType.FALSE):
            return LiteralNode(False, "boolean", self.previous().line, self.previous().column)
        if self.match(TokenType.NONE):
            return LiteralNode(None, "none", self.previous().line, self.previous().column)
        
        if self.match(TokenType.NUMBER):
            value = float(self.previous().value) if '.' in self.previous().value else int(self.previous().value)
            return LiteralNode(value, "number", self.previous().line, self.previous().column)
        
        if self.match(TokenType.STRING):
            return LiteralNode(self.previous().value, "string", self.previous().line, self.previous().column)
        
        if self.match(TokenType.IDENTIFIER):
            token = self.previous()
            return IdentifierNode(token.value, token.line, token.column)
        
        if self.match(TokenType.LEFT_PAREN):
            expr = self.expression()
            self.consume(TokenType.RIGHT_PAREN, "Expected ')' after expression")
            return expr
        
        raise ParseError("Expected expression", self.peek())

