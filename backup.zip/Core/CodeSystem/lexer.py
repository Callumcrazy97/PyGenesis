"""
Lexer for PGSL (PyGenesis Scripting Language)
Tokenizes source code into tokens for parsing.
"""

import re
from enum import Enum
from typing import List, Optional, Tuple


class TokenType(Enum):
    """Token types for PGSL"""
    # Literals
    NUMBER = "NUMBER"
    STRING = "STRING"
    IDENTIFIER = "IDENTIFIER"
    BOOLEAN = "BOOLEAN"
    
    # Keywords
    IF = "IF"
    ELSE = "ELSE"
    ELIF = "ELIF"
    WHILE = "WHILE"
    FOR = "FOR"
    FUNCTION = "FUNCTION"
    RETURN = "RETURN"
    VAR = "VAR"
    CONST = "CONST"
    TRUE = "TRUE"
    FALSE = "FALSE"
    NONE = "NONE"
    AND = "AND"
    OR = "OR"
    NOT = "NOT"
    IN = "IN"
    
    # Operators
    PLUS = "PLUS"
    MINUS = "MINUS"
    MULTIPLY = "MULTIPLY"
    DIVIDE = "DIVIDE"
    MODULO = "MODULO"
    POWER = "POWER"
    ASSIGN = "ASSIGN"
    EQUALS = "EQUALS"
    NOT_EQUALS = "NOT_EQUALS"
    LESS_THAN = "LESS_THAN"
    GREATER_THAN = "GREATER_THAN"
    LESS_EQUAL = "LESS_EQUAL"
    GREATER_EQUAL = "GREATER_EQUAL"
    
    # Delimiters
    LEFT_PAREN = "LEFT_PAREN"
    RIGHT_PAREN = "RIGHT_PAREN"
    LEFT_BRACKET = "LEFT_BRACKET"
    RIGHT_BRACKET = "RIGHT_BRACKET"
    LEFT_BRACE = "LEFT_BRACE"
    RIGHT_BRACE = "RIGHT_BRACE"
    COMMA = "COMMA"
    DOT = "DOT"
    COLON = "COLON"
    SEMICOLON = "SEMICOLON"
    
    # Special
    NEWLINE = "NEWLINE"
    INDENT = "INDENT"
    DEDENT = "DEDENT"
    EOF = "EOF"
    COMMENT = "COMMENT"
    WHITESPACE = "WHITESPACE"


class Token:
    """Represents a token in the source code"""
    
    def __init__(self, type: TokenType, value: str, line: int, column: int):
        self.type = type
        self.value = value
        self.line = line
        self.column = column
    
    def __repr__(self):
        return f"Token({self.type.name}, {self.value!r}, {self.line}, {self.column})"
    
    def __eq__(self, other):
        if not isinstance(other, Token):
            return False
        return (self.type == other.type and 
                self.value == other.value and
                self.line == other.line and
                self.column == other.column)


class Lexer:
    """Lexer for PGSL - tokenizes source code"""
    
    # Keyword mapping
    KEYWORDS = {
        'if': TokenType.IF,
        'else': TokenType.ELSE,
        'elif': TokenType.ELIF,
        'while': TokenType.WHILE,
        'for': TokenType.FOR,
        'function': TokenType.FUNCTION,
        'return': TokenType.RETURN,
        'var': TokenType.VAR,
        'const': TokenType.CONST,
        'true': TokenType.TRUE,
        'false': TokenType.FALSE,
        'none': TokenType.NONE,
        'and': TokenType.AND,
        'or': TokenType.OR,
        'not': TokenType.NOT,
        'in': TokenType.IN,
    }
    
    def __init__(self, source: str):
        self.source = source
        self.pos = 0
        self.line = 1
        self.column = 1
        self.indent_stack = [0]  # Track indentation levels
        self.tokens: List[Token] = []
    
    def current_char(self) -> Optional[str]:
        """Get current character"""
        if self.pos >= len(self.source):
            return None
        return self.source[self.pos]
    
    def peek_char(self, offset: int = 1) -> Optional[str]:
        """Peek ahead at character"""
        pos = self.pos + offset
        if pos >= len(self.source):
            return None
        return self.source[pos]
    
    def advance(self) -> Optional[str]:
        """Advance position and return current character"""
        if self.pos >= len(self.source):
            return None
        
        char = self.source[self.pos]
        self.pos += 1
        
        if char == '\n':
            self.line += 1
            self.column = 1
        else:
            self.column += 1
        
        return char
    
    def skip_whitespace(self):
        """Skip whitespace (except newlines)"""
        while self.current_char() and self.current_char() in ' \t\r':
            self.advance()
    
    def read_number(self) -> str:
        """Read a number (integer or float)"""
        num_str = ""
        has_dot = False
        
        while self.current_char() and (self.current_char().isdigit() or self.current_char() == '.'):
            if self.current_char() == '.':
                if has_dot:
                    break
                has_dot = True
            num_str += self.advance()
        
        return num_str
    
    def read_string(self, quote_char: str) -> str:
        """Read a string literal"""
        string = ""
        self.advance()  # Skip opening quote
        
        while self.current_char() and self.current_char() != quote_char:
            if self.current_char() == '\\':
                self.advance()  # Skip escape character
                if self.current_char():
                    # Handle escape sequences
                    char = self.advance()
                    if char == 'n':
                        string += '\n'
                    elif char == 't':
                        string += '\t'
                    elif char == 'r':
                        string += '\r'
                    elif char == '\\':
                        string += '\\'
                    elif char == quote_char:
                        string += quote_char
                    else:
                        string += '\\' + char
            else:
                string += self.advance()
        
        if self.current_char() == quote_char:
            self.advance()  # Skip closing quote
        
        return string
    
    def read_identifier(self) -> str:
        """Read an identifier or keyword"""
        ident = ""
        while self.current_char() and (self.current_char().isalnum() or self.current_char() == '_'):
            ident += self.advance()
        return ident
    
    def read_comment(self) -> str:
        """Read a # comment (from # to end of line)"""
        comment = "#"
        self.advance()  # Skip #
        while self.current_char() and self.current_char() != '\n':
            comment += self.advance()
        return comment
    
    def read_pgsl_comment(self) -> str:
        """Read a // comment (from // to end of line)"""
        comment = "//"
        self.advance()  # Skip first /
        self.advance()  # Skip second /
        while self.current_char() and self.current_char() != '\n':
            comment += self.advance()
        return comment
    
    def calculate_indent(self, line: str) -> int:
        """Calculate indentation level (spaces)"""
        indent = 0
        for char in line:
            if char == ' ':
                indent += 1
            elif char == '\t':
                indent += 4  # Treat tab as 4 spaces
            else:
                break
        return indent
    
    def tokenize(self) -> List[Token]:
        """Tokenize the source code"""
        self.tokens = []
        self.pos = 0
        self.line = 1
        self.column = 1
        self.indent_stack = [0]
        
        pending_indents = []
        in_line = False
        
        while self.pos < len(self.source):
            # Skip whitespace (but track for indentation)
            if self.current_char() == '\n':
                in_line = False
                self.advance()
                self.tokens.append(Token(TokenType.NEWLINE, '\n', self.line - 1, self.column))
                continue
            
            if self.current_char() in ' \t\r':
                if not in_line:
                    # Calculate indentation at start of line
                    start_pos = self.pos
                    line_start = self.pos
                    while self.pos < len(self.source) and self.source[self.pos] in ' \t':
                        self.pos += 1
                    
                    if self.pos < len(self.source) and self.source[self.pos] != '\n':
                        # Not a blank line
                        indent = self.calculate_indent(self.source[line_start:self.pos])
                        current_indent = self.indent_stack[-1]
                        
                        if indent > current_indent:
                            # Increase indentation
                            pending_indents.append(indent)
                            self.indent_stack.append(indent)
                            self.tokens.append(Token(TokenType.INDENT, '', self.line, 1))
                        elif indent < current_indent:
                            # Decrease indentation
                            while self.indent_stack and self.indent_stack[-1] > indent:
                                self.indent_stack.pop()
                                self.tokens.append(Token(TokenType.DEDENT, '', self.line, 1))
                        
                        in_line = True
                    else:
                        # Blank line, skip
                        self.pos = start_pos
                        self.advance()
                else:
                    self.skip_whitespace()
                continue
            
            # Comments (support both # and //)
            if self.current_char() == '#':
                comment = self.read_comment()
                self.tokens.append(Token(TokenType.COMMENT, comment, self.line, self.column))
                continue
            
            # PGSL-style comments (//)
            if self.current_char() == '/' and self.peek_char() == '/':
                comment = self.read_pgsl_comment()
                self.tokens.append(Token(TokenType.COMMENT, comment, self.line, self.column))
                continue
            
            # Numbers
            if self.current_char() and self.current_char().isdigit():
                num = self.read_number()
                self.tokens.append(Token(TokenType.NUMBER, num, self.line, self.column - len(num)))
                in_line = True
                continue
            
            # Strings
            if self.current_char() in ('"', "'"):
                quote = self.current_char()
                string = self.read_string(quote)
                self.tokens.append(Token(TokenType.STRING, string, self.line, self.column - len(string) - 2))
                in_line = True
                continue
            
            # Identifiers and keywords
            if self.current_char() and (self.current_char().isalpha() or self.current_char() == '_'):
                ident = self.read_identifier()
                token_type = self.KEYWORDS.get(ident.lower(), TokenType.IDENTIFIER)
                self.tokens.append(Token(token_type, ident, self.line, self.column - len(ident)))
                in_line = True
                continue
            
            # Operators and delimiters
            char = self.current_char()
            if char == '+':
                self.tokens.append(Token(TokenType.PLUS, self.advance(), self.line, self.column - 1))
            elif char == '-':
                self.tokens.append(Token(TokenType.MINUS, self.advance(), self.line, self.column - 1))
            elif char == '*':
                if self.peek_char() == '*':
                    self.advance()
                    self.tokens.append(Token(TokenType.POWER, '**', self.line, self.column - 2))
                    self.advance()
                else:
                    self.tokens.append(Token(TokenType.MULTIPLY, self.advance(), self.line, self.column - 1))
            elif char == '/':
                self.tokens.append(Token(TokenType.DIVIDE, self.advance(), self.line, self.column - 1))
            elif char == '%':
                self.tokens.append(Token(TokenType.MODULO, self.advance(), self.line, self.column - 1))
            elif char == '=':
                if self.peek_char() == '=':
                    self.advance()
                    self.tokens.append(Token(TokenType.EQUALS, '==', self.line, self.column - 2))
                    self.advance()
                else:
                    self.tokens.append(Token(TokenType.ASSIGN, self.advance(), self.line, self.column - 1))
            elif char == '!':
                if self.peek_char() == '=':
                    self.advance()
                    self.tokens.append(Token(TokenType.NOT_EQUALS, '!=', self.line, self.column - 2))
                    self.advance()
                else:
                    self.tokens.append(Token(TokenType.NOT, self.advance(), self.line, self.column - 1))
            elif char == '<':
                if self.peek_char() == '=':
                    self.advance()
                    self.tokens.append(Token(TokenType.LESS_EQUAL, '<=', self.line, self.column - 2))
                    self.advance()
                else:
                    self.tokens.append(Token(TokenType.LESS_THAN, self.advance(), self.line, self.column - 1))
            elif char == '>':
                if self.peek_char() == '=':
                    self.advance()
                    self.tokens.append(Token(TokenType.GREATER_EQUAL, '>=', self.line, self.column - 2))
                    self.advance()
                else:
                    self.tokens.append(Token(TokenType.GREATER_THAN, self.advance(), self.line, self.column - 1))
            elif char == '(':
                self.tokens.append(Token(TokenType.LEFT_PAREN, self.advance(), self.line, self.column - 1))
            elif char == ')':
                self.tokens.append(Token(TokenType.RIGHT_PAREN, self.advance(), self.line, self.column - 1))
            elif char == '[':
                self.tokens.append(Token(TokenType.LEFT_BRACKET, self.advance(), self.line, self.column - 1))
            elif char == ']':
                self.tokens.append(Token(TokenType.RIGHT_BRACKET, self.advance(), self.line, self.column - 1))
            elif char == '{':
                self.tokens.append(Token(TokenType.LEFT_BRACE, self.advance(), self.line, self.column - 1))
            elif char == '}':
                self.tokens.append(Token(TokenType.RIGHT_BRACE, self.advance(), self.line, self.column - 1))
            elif char == ',':
                self.tokens.append(Token(TokenType.COMMA, self.advance(), self.line, self.column - 1))
            elif char == '.':
                self.tokens.append(Token(TokenType.DOT, self.advance(), self.line, self.column - 1))
            elif char == ':':
                self.tokens.append(Token(TokenType.COLON, self.advance(), self.line, self.column - 1))
            elif char == ';':
                self.tokens.append(Token(TokenType.SEMICOLON, self.advance(), self.line, self.column - 1))
            else:
                # Unknown character, skip
                self.advance()
            
            in_line = True
        
        # Add final dedents and EOF
        while len(self.indent_stack) > 1:
            self.indent_stack.pop()
            self.tokens.append(Token(TokenType.DEDENT, '', self.line, self.column))
        
        self.tokens.append(Token(TokenType.EOF, '', self.line, self.column))
        
        return self.tokens

