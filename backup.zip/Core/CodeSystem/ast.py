"""
Abstract Syntax Tree (AST) for PGSL
Represents the parsed structure of PGSL code.
"""

from abc import ABC, abstractmethod
from typing import List, Optional, Any, Dict
from enum import Enum


class ASTNodeType(Enum):
    """Types of AST nodes"""
    PROGRAM = "PROGRAM"
    STATEMENT = "STATEMENT"
    EXPRESSION = "EXPRESSION"
    FUNCTION_DEF = "FUNCTION_DEF"
    VARIABLE_DECL = "VARIABLE_DECL"
    ASSIGNMENT = "ASSIGNMENT"
    IF_STATEMENT = "IF_STATEMENT"
    WHILE_LOOP = "WHILE_LOOP"
    FOR_LOOP = "FOR_LOOP"
    RETURN_STATEMENT = "RETURN_STATEMENT"
    BINARY_OP = "BINARY_OP"
    UNARY_OP = "UNARY_OP"
    FUNCTION_CALL = "FUNCTION_CALL"
    LITERAL = "LITERAL"
    IDENTIFIER = "IDENTIFIER"
    BLOCK = "BLOCK"


class ASTNode(ABC):
    """Base class for AST nodes"""
    
    def __init__(self, node_type: ASTNodeType, line: int = 0, column: int = 0):
        self.node_type = node_type
        self.line = line
        self.column = column
        self.children: List[ASTNode] = []
        self.parent: Optional[ASTNode] = None
    
    def add_child(self, child: 'ASTNode'):
        """Add a child node"""
        child.parent = self
        self.children.append(child)
    
    @abstractmethod
    def accept(self, visitor: 'ASTVisitor'):
        """Accept a visitor for traversal"""
        pass
    
    def __repr__(self):
        return f"{self.__class__.__name__}(line={self.line}, column={self.column})"


class ProgramNode(ASTNode):
    """Root node representing a complete program"""
    
    def __init__(self, statements: List[ASTNode], line: int = 0, column: int = 0):
        super().__init__(ASTNodeType.PROGRAM, line, column)
        self.statements = statements
        for stmt in statements:
            self.add_child(stmt)
    
    def accept(self, visitor: 'ASTVisitor'):
        return visitor.visit_program(self)


class BlockNode(ASTNode):
    """Represents a block of statements"""
    
    def __init__(self, statements: List[ASTNode], line: int = 0, column: int = 0):
        super().__init__(ASTNodeType.BLOCK, line, column)
        self.statements = statements
        for stmt in statements:
            self.add_child(stmt)
    
    def accept(self, visitor: 'ASTVisitor'):
        return visitor.visit_block(self)


class LiteralNode(ASTNode):
    """Represents a literal value"""
    
    def __init__(self, value: Any, literal_type: str, line: int = 0, column: int = 0):
        super().__init__(ASTNodeType.LITERAL, line, column)
        self.value = value
        self.literal_type = literal_type  # 'number', 'string', 'boolean', 'none'
    
    def accept(self, visitor: 'ASTVisitor'):
        return visitor.visit_literal(self)


class IdentifierNode(ASTNode):
    """Represents an identifier (variable name, function name, etc.)"""
    
    def __init__(self, name: str, line: int = 0, column: int = 0):
        super().__init__(ASTNodeType.IDENTIFIER, line, column)
        self.name = name
    
    def accept(self, visitor: 'ASTVisitor'):
        return visitor.visit_identifier(self)


class BinaryOpNode(ASTNode):
    """Represents a binary operation"""
    
    def __init__(self, operator: str, left: ASTNode, right: ASTNode, line: int = 0, column: int = 0):
        super().__init__(ASTNodeType.BINARY_OP, line, column)
        self.operator = operator
        self.left = left
        self.right = right
        self.add_child(left)
        self.add_child(right)
    
    def accept(self, visitor: 'ASTVisitor'):
        return visitor.visit_binary_op(self)


class UnaryOpNode(ASTNode):
    """Represents a unary operation"""
    
    def __init__(self, operator: str, operand: ASTNode, line: int = 0, column: int = 0):
        super().__init__(ASTNodeType.UNARY_OP, line, column)
        self.operator = operator
        self.operand = operand
        self.add_child(operand)
    
    def accept(self, visitor: 'ASTVisitor'):
        return visitor.visit_unary_op(self)


class FunctionCallNode(ASTNode):
    """Represents a function call"""
    
    def __init__(self, name: str, arguments: List[ASTNode], line: int = 0, column: int = 0):
        super().__init__(ASTNodeType.FUNCTION_CALL, line, column)
        self.name = name
        self.arguments = arguments
        for arg in arguments:
            self.add_child(arg)
    
    def accept(self, visitor: 'ASTVisitor'):
        return visitor.visit_function_call(self)


class VariableDeclNode(ASTNode):
    """Represents a variable declaration"""
    
    def __init__(self, name: str, var_type: str, initializer: Optional[ASTNode], line: int = 0, column: int = 0):
        super().__init__(ASTNodeType.VARIABLE_DECL, line, column)
        self.name = name
        self.var_type = var_type  # 'var' or 'const'
        self.initializer = initializer
        if initializer:
            self.add_child(initializer)
    
    def accept(self, visitor: 'ASTVisitor'):
        return visitor.visit_variable_decl(self)


class AssignmentNode(ASTNode):
    """Represents an assignment statement"""
    
    def __init__(self, target: IdentifierNode, value: ASTNode, line: int = 0, column: int = 0):
        super().__init__(ASTNodeType.ASSIGNMENT, line, column)
        self.target = target
        self.value = value
        self.add_child(target)
        self.add_child(value)
    
    def accept(self, visitor: 'ASTVisitor'):
        return visitor.visit_assignment(self)


class IfStatementNode(ASTNode):
    """Represents an if statement"""
    
    def __init__(self, condition: ASTNode, then_block: ASTNode, 
                 else_block: Optional[ASTNode] = None, line: int = 0, column: int = 0):
        super().__init__(ASTNodeType.IF_STATEMENT, line, column)
        self.condition = condition
        self.then_block = then_block
        self.else_block = else_block
        self.add_child(condition)
        self.add_child(then_block)
        if else_block:
            self.add_child(else_block)
    
    def accept(self, visitor: 'ASTVisitor'):
        return visitor.visit_if_statement(self)


class WhileLoopNode(ASTNode):
    """Represents a while loop"""
    
    def __init__(self, condition: ASTNode, body: ASTNode, line: int = 0, column: int = 0):
        super().__init__(ASTNodeType.WHILE_LOOP, line, column)
        self.condition = condition
        self.body = body
        self.add_child(condition)
        self.add_child(body)
    
    def accept(self, visitor: 'ASTVisitor'):
        return visitor.visit_while_loop(self)


class ForLoopNode(ASTNode):
    """Represents a for loop"""
    
    def __init__(self, variable: str, iterable: ASTNode, body: ASTNode, line: int = 0, column: int = 0):
        super().__init__(ASTNodeType.FOR_LOOP, line, column)
        self.variable = variable
        self.iterable = iterable
        self.body = body
        self.add_child(iterable)
        self.add_child(body)
    
    def accept(self, visitor: 'ASTVisitor'):
        return visitor.visit_for_loop(self)


class FunctionDefNode(ASTNode):
    """Represents a function definition"""
    
    def __init__(self, name: str, parameters: List[str], body: ASTNode, line: int = 0, column: int = 0):
        super().__init__(ASTNodeType.FUNCTION_DEF, line, column)
        self.name = name
        self.parameters = parameters
        self.body = body
        self.add_child(body)
    
    def accept(self, visitor: 'ASTVisitor'):
        return visitor.visit_function_def(self)


class ReturnStatementNode(ASTNode):
    """Represents a return statement"""
    
    def __init__(self, value: Optional[ASTNode] = None, line: int = 0, column: int = 0):
        super().__init__(ASTNodeType.RETURN_STATEMENT, line, column)
        self.value = value
        if value:
            self.add_child(value)
    
    def accept(self, visitor: 'ASTVisitor'):
        return visitor.visit_return_statement(self)


class ASTVisitor(ABC):
    """Visitor pattern for traversing AST nodes"""
    
    @abstractmethod
    def visit_program(self, node: ProgramNode):
        pass
    
    @abstractmethod
    def visit_block(self, node: BlockNode):
        pass
    
    @abstractmethod
    def visit_literal(self, node: LiteralNode):
        pass
    
    @abstractmethod
    def visit_identifier(self, node: IdentifierNode):
        pass
    
    @abstractmethod
    def visit_binary_op(self, node: BinaryOpNode):
        pass
    
    @abstractmethod
    def visit_unary_op(self, node: UnaryOpNode):
        pass
    
    @abstractmethod
    def visit_function_call(self, node: FunctionCallNode):
        pass
    
    @abstractmethod
    def visit_variable_decl(self, node: VariableDeclNode):
        pass
    
    @abstractmethod
    def visit_assignment(self, node: AssignmentNode):
        pass
    
    @abstractmethod
    def visit_if_statement(self, node: IfStatementNode):
        pass
    
    @abstractmethod
    def visit_while_loop(self, node: WhileLoopNode):
        pass
    
    @abstractmethod
    def visit_for_loop(self, node: ForLoopNode):
        pass
    
    @abstractmethod
    def visit_function_def(self, node: FunctionDefNode):
        pass
    
    @abstractmethod
    def visit_return_statement(self, node: ReturnStatementNode):
        pass

