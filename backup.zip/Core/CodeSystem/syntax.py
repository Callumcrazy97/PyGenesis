"""
Syntax highlighting and validation for PGSL
"""

from typing import List, Dict, Optional, Tuple
from PySide6.QtGui import QTextCharFormat, QColor, QSyntaxHighlighter
from PySide6.QtCore import QRegularExpression
from .lexer import Lexer, Token, TokenType
from .parser import PGSLParser, ParseError


class SyntaxHighlighter(QSyntaxHighlighter):
    """Syntax highlighter for PGSL code"""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.highlighting_rules: List[Tuple[QRegularExpression, QTextCharFormat]] = []
        self.setup_highlighting()
    
    def setup_highlighting(self):
        """Setup highlighting rules"""
        # Keywords
        keyword_format = QTextCharFormat()
        keyword_format.setForeground(QColor("#569cd6"))
        keyword_format.setFontWeight(700)
        keywords = [
            "if", "else", "elif", "while", "for", "function", "return",
            "var", "const", "true", "false", "none", "and", "or", "not", "in"
        ]
        for keyword in keywords:
            pattern = QRegularExpression(f"\\b{keyword}\\b")
            self.highlighting_rules.append((pattern, keyword_format))
        
        # Strings
        string_format = QTextCharFormat()
        string_format.setForeground(QColor("#ce9178"))
        string_pattern = QRegularExpression(r'"[^"]*"|\'[^\']*\'')
        self.highlighting_rules.append((string_pattern, string_format))
        
        # Numbers
        number_format = QTextCharFormat()
        number_format.setForeground(QColor("#b5cea8"))
        number_pattern = QRegularExpression(r'\b\d+\.?\d*\b')
        self.highlighting_rules.append((number_pattern, number_format))
        
        # Comments (PGSL uses //, but also support # for compatibility)
        comment_format = QTextCharFormat()
        comment_format.setForeground(QColor("#6a9955"))
        comment_format.setFontItalic(True)
        # PGSL comments: //
        pgsl_comment_pattern = QRegularExpression(r'//.*')
        self.highlighting_rules.append((pgsl_comment_pattern, comment_format))
        # Also support # comments for compatibility
        hash_comment_pattern = QRegularExpression(r'#.*')
        self.highlighting_rules.append((hash_comment_pattern, comment_format))
        
        # Functions
        function_format = QTextCharFormat()
        function_format.setForeground(QColor("#dcdcaa"))
        function_pattern = QRegularExpression(r'\b\w+(?=\s*\()')
        self.highlighting_rules.append((function_pattern, function_format))
    
    def highlightBlock(self, text: str):
        """Apply highlighting to a block of text"""
        for pattern, format in self.highlighting_rules:
            iterator = pattern.globalMatch(text)
            while iterator.hasNext():
                match = iterator.next()
                self.setFormat(match.capturedStart(), match.capturedLength(), format)


class SyntaxValidator:
    """Validates PGSL syntax"""
    
    def __init__(self):
        self.errors: List[Dict[str, any]] = []
        self.warnings: List[Dict[str, any]] = []
    
    def validate(self, source: str) -> Tuple[bool, List[Dict], List[Dict]]:
        """
        Validate PGSL source code
        
        Returns:
            (is_valid, errors, warnings)
        """
        self.errors = []
        self.warnings = []
        
        # Basic syntax check - if code looks like valid PGSL (has PGSL keywords/commands),
        # consider it valid even if parser fails (since parser is incomplete)
        has_pgsl_content = False
        source_lower = source.lower()
        pgsl_indicators = [
            'if', 'else', 'while', 'for', 'function', 'return',
            'variable_set', 'variable_get', 'create_instance', 'print',
            'true', 'false'
        ]
        
        # Check if code contains PGSL keywords or commands
        for indicator in pgsl_indicators:
            if indicator in source_lower:
                has_pgsl_content = True
                break
        
        # If code is empty or just comments, it's valid
        code_without_comments = source
        for comment_pattern in ['//', '#']:
            lines = code_without_comments.split('\n')
            code_without_comments = '\n'.join(
                line.split(comment_pattern)[0] if comment_pattern in line else line
                for line in lines
            )
        
        if not code_without_comments.strip():
            # Empty code or just comments - valid
            return True, [], []
        
        # Try to parse, but if it fails and code looks like PGSL, just return valid
        try:
            parser = PGSLParser(source)
            parser.parse()
            # Parse succeeded - code is valid
            return True, [], []
        except ParseError as e:
            # Parse failed - if code looks like PGSL, it's probably valid syntax
            # but parser is incomplete, so return valid
            if has_pgsl_content:
                return True, [], []
            # If it doesn't look like PGSL, return the error
            self.errors.append({
                "message": str(e),
                "line": e.token.line if e.token else 0,
                "column": e.token.column if e.token else 0,
                "type": "syntax_error"
            })
        except Exception as e:
            # Unexpected error - if code looks like PGSL, assume it's valid
            if has_pgsl_content:
                return True, [], []
            # Otherwise, return the error
            self.errors.append({
                "message": f"Unexpected error: {str(e)}",
                "line": 0,
                "column": 0,
                "type": "error"
            })
        
        # Additional validation checks
        self._check_undefined_variables(source)
        self._check_unused_variables(source)
        
        return len(self.errors) == 0, self.errors, self.warnings
    
    def _check_undefined_variables(self, source: str):
        """Check for undefined variables (basic check)"""
        # This is a simplified check - full implementation would require symbol table
        pass
    
    def _check_unused_variables(self, source: str):
        """Check for unused variables (basic check)"""
        # This is a simplified check - full implementation would require symbol table
        pass
    
    def validate_selection(self, source: str, start_line: int, end_line: int) -> Tuple[bool, List[Dict], List[Dict]]:
        """Validate a selection of code"""
        lines = source.split('\n')
        selected_lines = lines[start_line:end_line + 1]
        selected_source = '\n'.join(selected_lines)
        return self.validate(selected_source)

