"""
Editor Factory for PyGenesis IDE
Creates appropriate editor instances based on resource type
"""

from typing import Dict, Optional
from PySide6.QtWidgets import QWidget, QTextEdit
import json

from Core.EditorInterface import EditorInterface
from Core.Debug import debug


class EditorFactory:
    """
    Factory class for creating editor instances.
    
    This centralizes editor creation logic and reduces coupling
    between MainWindow and individual editor implementations.
    """
    
    @staticmethod
    def create_editor(resource_type: str, resource_data: Dict, app) -> Optional[QWidget]:
        """
        Create an appropriate editor for the given resource type.
        
        Args:
            resource_type: Type of resource (e.g., "sprites", "rooms", "sounds")
            resource_data: Dictionary containing resource data
            app: Application instance (for accessing project_manager, etc.)
            
        Returns:
            Editor widget instance, or None if resource type not supported
        """
        try:
            if resource_type == "sprites":
                return EditorFactory._create_sprite_editor(app, resource_data)
            elif resource_type == "backgrounds":
                return EditorFactory._create_background_editor(app, resource_data)
            elif resource_type == "rooms":
                return EditorFactory._create_room_editor(app, resource_data)
            elif resource_type == "sounds":
                return EditorFactory._create_sound_editor(app, resource_data)
            elif resource_type == "models":
                return EditorFactory._create_model_editor(app, resource_data)
            elif resource_type == "textures":
                return EditorFactory._create_texture_editor(app, resource_data)
            elif resource_type == "objects":
                return EditorFactory._create_object_editor(app, resource_data)
            elif resource_type == "scripts":
                return EditorFactory._create_code_editor(app, resource_data)
            else:
                debug(f"Unknown resource type: {resource_type}, using generic text editor")
                return EditorFactory._create_generic_editor(resource_data)
        except Exception as e:
            debug(f"Error creating editor for {resource_type}: {e}")
            import traceback
            traceback.print_exc()
            return None
    
    @staticmethod
    def _create_sprite_editor(app, resource_data: Dict) -> QWidget:
        """Create a SpriteEditor instance"""
        from Editors.SpriteEditor.SpriteEditor import SpriteEditor
        return SpriteEditor(app, resource_data)
    
    @staticmethod
    def _create_room_editor(app, resource_data: Dict) -> QWidget:
        """Create a RoomEditor instance"""
        from Editors.RoomEditor.RoomEditor import RoomEditor
        return RoomEditor(app, resource_data)
    
    @staticmethod
    def _create_sound_editor(app, resource_data: Dict) -> QWidget:
        """Create a SoundEditor instance"""
        from Editors.SoundEditor.SoundEditor import SoundEditor
        return SoundEditor(app, resource_data)
    
    @staticmethod
    def _create_model_editor(app, resource_data: Dict) -> QWidget:
        """Create a ModelEditor instance"""
        from Editors.ModelEditor.ModelEditor import ModelPreviewWindow
        # ModelPreviewWindow may need parent parameter
        return ModelPreviewWindow(app=app, resource_data=resource_data, parent=None)
    
    @staticmethod
    def _create_texture_editor(app, resource_data: Dict) -> QWidget:
        """Create a TextureEditor instance"""
        from Editors.TextureEditor.TextureEditor import TextureEditor
        return TextureEditor(app, resource_data)
    
    @staticmethod
    def _create_background_editor(app, resource_data: Dict) -> QWidget:
        """Create a BackgroundEditor instance"""
        from Editors.BackgroundEditor.BackgroundEditor import BackgroundEditor
        return BackgroundEditor(app, resource_data)
    
    @staticmethod
    def _create_object_editor(app, resource_data: Dict) -> QWidget:
        """Create an ObjectEditor instance"""
        from Editors.ObjectEditor.object_editor import ObjectEditor
        return ObjectEditor(app, resource_data)
    
    @staticmethod
    def _create_code_editor(app, resource_data: Dict) -> QWidget:
        """Create a ScriptEditor instance"""
        from Editors.CodeEditor.ScriptEditor import ScriptEditor
        return ScriptEditor(app, resource_data)
    
    @staticmethod
    def _create_generic_editor(resource_data: Dict) -> QWidget:
        """Create a generic text editor for unknown resource types"""
        editor = QTextEdit()
        editor.setPlainText(json.dumps(resource_data, indent=2))
        return editor
    
    @staticmethod
    def get_editor_name(resource_type: str) -> str:
        """
        Get a human-readable name for an editor type.
        
        Args:
            resource_type: Type of resource
            
        Returns:
            Editor name string
        """
        editor_names = {
            "sprites": "Sprite Editor",
            "rooms": "Room Editor",
            "sounds": "Sound Editor",
            "models": "Model Editor",
            "textures": "Texture Editor",
            "objects": "Object Editor",
            "scripts": "Code Editor"
        }
        return editor_names.get(resource_type, "Editor")
    
    @staticmethod
    def is_editor_type_supported(resource_type: str) -> bool:
        """
        Check if a resource type has a dedicated editor.
        
        Args:
            resource_type: Type of resource to check
            
        Returns:
            True if editor exists, False otherwise
        """
        supported_types = ["sprites", "backgrounds", "rooms", "sounds", "models", "textures", "objects", "scripts"]
        return resource_type in supported_types


