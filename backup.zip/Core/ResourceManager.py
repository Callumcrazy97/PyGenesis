"""
Resource Manager for Python Game IDE
Handles resource creation, editing, and management
"""

import os
import json
import uuid
from PySide6.QtCore import QObject, Signal
from PySide6.QtWidgets import QMessageBox
from Core.Debug import debug

class ResourceManager(QObject):
    # Signals
    resource_created = Signal(str, dict)  # resource_type, resource_data
    resource_updated = Signal(str, dict)  # resource_type, resource_data
    resource_deleted = Signal(str, str)   # resource_type, resource_id
    
    def __init__(self, project_manager):
        super().__init__()
        self.project_manager = project_manager
        self.undo_redo_manager = None  # Will be set later
        
        # Initialize service layer (optional - for future use)
        try:
            from Core.Services.resource_service import ResourceService
            self.resource_service = ResourceService(self, project_manager)
        except ImportError:
            self.resource_service = None
        
        # Resource caching system
        # Texture cache: maps file path -> (texture_id, ref_count, metadata)
        self._texture_cache = {}  # {path: {"id": gl_id, "ref_count": int, "width": int, "height": int, "format": str}}
        
        # Material cache: maps resource_id -> material_data (normalized UnifiedMaterial)
        self._material_cache = {}  # {resource_id: {material_name: material_data}}
        
        # Parsed model cache: maps file path -> parsed geometry data
        self._model_cache = {}  # {path: {"vertices": array, "indices": array, "mtime": float}}
        
        self.resource_types = {
            "sprites": {
                "extension": ".sprite",
                "folder": "Sprites",
                "default_data": {
                    "frames": [],
                    "width": 32,
                    "height": 32,
                    "collision_mask": "precise"
                }
            },
            "backgrounds": {
                "extension": ".background",
                "folder": "Backgrounds",
                "default_data": {
                    "width": 1024,
                    "height": 768,
                    "tile_width": 32,
                    "tile_height": 32
                }
            },
            "objects": {
                "extension": ".object",
                "folder": "Objects",
                "default_data": {
                    "sprite": None,
                    "events": {},
                    "properties": {}
                }
            },
            "sounds": {
                "extension": ".sound",
                "folder": "Sounds",
                "default_data": {
                    "volume": 1.0,
                    "loop": False,
                    "preload": True,
                    "frequency": 44100,
                    "audio_file": None,
                    "duration": 0.0,
                    "sample_rate": 44100,
                    "bit_depth": 16,
                    "channels": 2
                }
            },
            "models": {
                "extension": ".model",
                "folder": "Models",
                "default_data": {
                    "model_file": None,
                    "original_model_file": None,
                    "format": None,  # "obj", "glb", "gltf", "dae"
                    "mtl_file": None,  # Material library file (for OBJ models)
                    "texture_files": [],  # List of texture filenames
                    "scale": 1.0,
                    "position": {"x": 0.0, "y": 0.0, "z": 0.0},
                    "rotation": {"x": 0.0, "y": 0.0, "z": 0.0}
                }
            },
            "rooms": {
                "extension": ".room",
                "folder": "Rooms",
                "default_data": {
                    "width": 1024,
                    "height": 768,
                    "instances": [],
                    "backgrounds": [],
                    "tiles": []
                }
            },
            "textures": {
                "extension": ".texture",
                "folder": "Textures",
                "default_data": {
                    "frames": [],  # List of texture frame files (similar to sprites)
                    "width": 256,
                    "height": 256,
                    "format": "png",
                    "units_per_pixel": 1.0,  # For 3D preview scaling
                    "preview_shape": "box",  # "box", "plane", "cylinder"
                    "animated": False  # Whether this texture has multiple frames
                }
            },
            "shaders": {
                "extension": ".shader",
                "folder": "Shaders",
                "default_data": {
                    "shader_type": "graphical",  # "graphical" or "compute"
                    "vertex_code": "",
                    "fragment_code": "",
                    "compute_code": "",
                    "uniforms": []
                }
            },
            "particles": {
                "extension": ".particle",
                "folder": "Particles",
                "default_data": {
                    "emitter_type": "point",
                    "max_particles": 100,
                    "lifetime": 1.0,
                    "spawn_rate": 10.0,
                    "velocity": {"x": 0.0, "y": 0.0},
                    "acceleration": {"x": 0.0, "y": 0.0},
                    "color": {"r": 1.0, "g": 1.0, "b": 1.0, "a": 1.0},
                    "size": 1.0
                }
            },
            "scripts": {
                "extension": ".script",
                "folder": "Scripts",
                "default_data": {
                    "code": "",
                    "language": "pgsl"  # PGSL (PyGenesis Scripting Language)
                }
            }
        }
    
    def create_resource(self, resource_type, name, parent_folder=""):
        """Create a new resource"""
        if resource_type not in self.resource_types:
            QMessageBox.critical(None, "Error", f"Unknown resource type: {resource_type}")
            return None
        
        # Check for duplicate names
        existing_resources = self.project_manager.get_resources(resource_type)
        for resource in existing_resources:
            if (resource.get("name") == name and 
                resource.get("parent_folder", "") == parent_folder):
                QMessageBox.warning(None, "Name Exists", 
                    f"A {resource_type} with the name '{name}' already exists in this folder.")
                return None
        
        try:
            # Generate unique ID
            resource_id = str(uuid.uuid4())
            
            # Create resource data
            resource_data = {
                "id": resource_id,
                "name": name,
                "type": resource_type,
                "parent_folder": parent_folder,
                "created": self._get_timestamp(),
                "modified": self._get_timestamp(),
                **self.resource_types[resource_type]["default_data"]
            }
            
            # Create file path
            folder_path = os.path.join(
                self.project_manager.get_project_path(),
                "Resources",
                self.resource_types[resource_type]["folder"]
            )
            
            if parent_folder:
                folder_path = os.path.join(folder_path, parent_folder)
                os.makedirs(folder_path, exist_ok=True)
            
            file_path = os.path.join(
                folder_path,
                f"{name}{self.resource_types[resource_type]['extension']}"
            )
            
            # Check if file already exists (additional safety check)
            if os.path.exists(file_path):
                QMessageBox.warning(None, "File Exists", 
                    f"A file with the name '{name}' already exists. Please choose a different name.")
                return None
            
            # Validate that resource_data is JSON serializable
            try:
                json.dumps(resource_data)
            except (TypeError, ValueError) as e:
                QMessageBox.critical(None, "Save Error", 
                    f"Resource contains non-serializable data: {str(e)}\n\n"
                    f"Please check your resource for any unsupported data types.")
                return None
            
            # Save resource file
            with open(file_path, 'w', encoding='utf-8') as f:
                json.dump(resource_data, f, indent=4, ensure_ascii=False)
            
            # Add to runtime (not saved to disk until project save)
            self.project_manager.add_runtime_resource(resource_type, resource_id, resource_data)
            
            # Record to undo stack
            if self.undo_redo_manager:
                self.undo_redo_manager.record_create(resource_type, resource_data)
            
            self.resource_created.emit(resource_type, resource_data)
            return resource_data
            
        except Exception as e:
            QMessageBox.critical(None, "Error", f"Failed to create resource: {str(e)}")
            return None
    
    def load_resource(self, resource_type, resource_id):
        """
        Load a resource by ID (from runtime or disk).
        Supports lazy loading - if resource has _lazy_loaded=False, loads full data from disk.
        """
        import copy
        resource = self.project_manager.get_runtime_resource(resource_type, resource_id)
        if not resource:
            return None
        
        # Check if this is a lazy-loaded resource (metadata only)
        is_lazy_loaded = resource.get("_lazy_loaded", True)
        
        # For objects and rooms, or if lazy-loaded, load full data from disk
        if resource_type in ["objects", "rooms"] or not is_lazy_loaded:
            # Load full resource data from disk file
            disk_resource = self.load_resource_from_disk(resource_type, resource_id)
            if disk_resource:
                # Merge runtime metadata with disk data (runtime has latest metadata like modified time)
                merged = copy.deepcopy(disk_resource)
                # Update with any runtime-only fields (if needed)
                merged["id"] = resource.get("id", merged.get("id"))
                merged["name"] = resource.get("name", merged.get("name"))
                merged["type"] = resource.get("type", merged.get("type"))
                merged["parent_folder"] = resource.get("parent_folder", merged.get("parent_folder", ""))
                merged["_lazy_loaded"] = True  # Mark as fully loaded
                
                # Update runtime with full data
                self.project_manager.update_runtime_resource(resource_type, resource_id, merged)
                
                return merged
            else:
                # Fallback to runtime data if disk load fails
                from Core.Debug import debug
                debug(f" Failed to load {resource_type} {resource_id} from disk, using runtime data")
                return copy.deepcopy(resource)
        
        # For other types with full data already loaded, return runtime data as-is
        return copy.deepcopy(resource)
    
    def load_resource_from_disk(self, resource_type, resource_id):
        """Load a resource by ID from disk file"""
        try:
            # Get the resource from runtime to get basic info (name, parent_folder)
            runtime_resource = self.project_manager.get_runtime_resource(resource_type, resource_id)
            if not runtime_resource:
                return None
            
            # Construct the file path
            file_path = self.get_resource_file_path(resource_type, runtime_resource)
            
            # Load from disk
            if os.path.exists(file_path):
                with open(file_path, 'r', encoding='utf-8') as f:
                    import json
                    return json.load(f)
            else:
                from Core.Debug import debug
                debug(f" Resource file not found: {file_path}")
                return None
                
        except Exception as e:
            from Core.Debug import debug
            debug(f" Error loading resource from disk: {e}")
            return None
    
    def get_resource_file_path(self, resource_type, resource_data):
        """Get the file path for a resource"""
        folder_path = os.path.join(
            self.project_manager.get_project_path(),
            "Resources",
            self.resource_types[resource_type]["folder"]
        )
        
        if resource_data.get("parent_folder"):
            folder_path = os.path.join(folder_path, resource_data["parent_folder"])
        
        file_path = os.path.join(
            folder_path,
            f"{resource_data['name']}{self.resource_types[resource_type]['extension']}"
        )
        
        return file_path

    def _convert_numpy_types(self, obj):
        """Recursively convert numpy types to native Python types for JSON serialization"""
        import numpy as np
        
        # Check for numpy numeric types using abstract base classes (compatible with NumPy 1.x and 2.x)
        if isinstance(obj, np.integer):
            return int(obj)
        elif isinstance(obj, np.floating):
            return float(obj)
        elif isinstance(obj, np.bool_):
            return bool(obj)
        elif isinstance(obj, np.ndarray):
            return obj.tolist()
        elif isinstance(obj, dict):
            return {key: self._convert_numpy_types(value) for key, value in obj.items()}
        elif isinstance(obj, (list, tuple)):
            return [self._convert_numpy_types(item) for item in obj]
        else:
            return obj
    
    def update_resource(self, resource_type, resource_id, updates):
        """Update a resource with new property values"""
        try:
            # Load the resource
            resource_data = self.load_resource(resource_type, resource_id)
            if not resource_data:
                return False
            
            # Apply updates
            resource_data.update(updates)
            
            # Save the updated resource
            return self.save_resource(resource_type, resource_data)
            
        except Exception as e:
            QMessageBox.critical(None, "Error", f"Failed to update resource: {str(e)}")
            return False
    
    def save_resource(self, resource_type, resource_data, file_path=None):
        """Save a resource"""
        try:
            # Update modified timestamp
            resource_data["modified"] = self._get_timestamp()
            
            # Convert numpy types to native Python types before serialization
            resource_data = self._convert_numpy_types(resource_data)
            
            # Use provided file path or create one
            if file_path is None:
                file_path = self.get_resource_file_path(resource_type, resource_data)
            
            # Validate that resource_data is JSON serializable
            try:
                json.dumps(resource_data)
            except (TypeError, ValueError) as e:
                QMessageBox.critical(None, "Save Error", 
                    f"Resource contains non-serializable data: {str(e)}\n\n"
                    f"Please check your resource for any unsupported data types.")
                return False
            
            # Save resource file
            with open(file_path, 'w', encoding='utf-8') as f:
                json.dump(resource_data, f, indent=4, ensure_ascii=False)
            
            # Update runtime resources (CRITICAL: This ensures events are in runtime_resources)
            self.project_manager.update_runtime_resource(resource_type, resource_data.get("id"), resource_data)
            
            # Update project data
            resources = self.project_manager.get_resources(resource_type)
            for i, resource in enumerate(resources):
                if resource.get("id") == resource_data["id"]:
                    resources[i] = resource_data
                    break
            
            self.resource_updated.emit(resource_type, resource_data)
            return True
            
        except Exception as e:
            QMessageBox.critical(None, "Error", f"Failed to save resource: {str(e)}")
            return False
    
    def save_resource_file_only(self, resource_type, resource_data, file_path=None):
        """Save only the resource file without updating project data or emitting signals"""
        try:
            # Update modified timestamp
            resource_data["modified"] = self._get_timestamp()
            
            # Convert numpy types to native Python types before serialization
            resource_data = self._convert_numpy_types(resource_data)
            
            # Use provided file path or create one
            if file_path is None:
                file_path = self.get_resource_file_path(resource_type, resource_data)
            
            # Validate that resource_data is JSON serializable
            try:
                json.dumps(resource_data)
            except (TypeError, ValueError) as e:
                QMessageBox.critical(None, "Save Error", 
                    f"Resource contains non-serializable data: {str(e)}\n\n"
                    f"Please check your resource for any unsupported data types.")
                return False
            
            # Save resource file only (no project data update, no signal emission)
            with open(file_path, 'w', encoding='utf-8') as f:
                json.dump(resource_data, f, indent=4, ensure_ascii=False)
            
            return True
            
        except Exception as e:
            QMessageBox.critical(None, "Error", f"Failed to save resource file: {str(e)}")
            return False
    
    def delete_resource(self, resource_type, resource_id, skip_undo_record=False):
        """Delete a resource"""
        try:
            # Find resource
            resource = self.load_resource(resource_type, resource_id)
            if not resource:
                return False
            
            # Record to undo stack (before deleting)
            if self.undo_redo_manager and not skip_undo_record:
                self.undo_redo_manager.record_delete(resource_type, resource_id, resource)
            
            # Special handling for resource types with associated files
            if resource_type == "sprites":
                self._delete_sprite_frame_files(resource)
            elif resource_type == "sounds":
                self._delete_sound_audio_files(resource)
            elif resource_type == "models":
                self._delete_model_files(resource)
            elif resource_type == "objects":
                self._delete_object_event_files(resource)
                # Handle parent-child dependencies: update children when parent is deleted
                self._update_object_children_on_parent_delete(resource)
            
            # Delete main resource file
            folder_path = os.path.join(
                self.project_manager.get_project_path(),
                "Resources",
                self.resource_types[resource_type]["folder"]
            )
            
            if resource.get("parent_folder"):
                folder_path = os.path.join(folder_path, resource["parent_folder"])
            
            file_path = os.path.join(
                folder_path,
                f"{resource['name']}{self.resource_types[resource_type]['extension']}"
            )
            
            if os.path.exists(file_path):
                os.remove(file_path)
            
            # Remove from runtime
            self.project_manager.remove_runtime_resource(resource_type, resource_id)
            
            self.resource_deleted.emit(resource_type, resource_id)
            return True
            
        except Exception as e:
            QMessageBox.critical(None, "Error", f"Failed to delete resource: {str(e)}")
            return False
    
    def _update_object_children_on_parent_delete(self, deleted_object):
        """Update all child objects when their parent is deleted"""
        deleted_object_name = deleted_object.get("name", "")
        if not deleted_object_name:
            return
        
        # Find all objects that have this object as their parent
        runtime_resources = self.project_manager.runtime_resources
        objects = runtime_resources.get("objects", {})
        
        affected_children = []
        for child_id, child_data in objects.items():
            parent_name = child_data.get("parent", "")
            if parent_name == deleted_object_name:
                affected_children.append((child_id, child_data))
        
        # Update each affected child: clear parent field
        for child_id, child_data in affected_children:
            child_data["parent"] = ""
            child_data["modified"] = self._get_timestamp()
            
            # Save the updated child
            self.save_resource("objects", child_data)
            
            # Emit update signal for each affected child
            self.resource_updated.emit("objects", child_data)
            
            from Core.Debug import debug
            debug(f"Updated child object '{child_data.get('name', 'Unknown')}' after parent '{deleted_object_name}' was deleted")
    
    def _delete_sprite_frame_files(self, sprite_resource):
        """Delete all frame files associated with a sprite"""
        import os
        
        # Get the sprites folder path, including parent folder if specified
        sprites_folder = os.path.join(
            self.project_manager.get_project_path(),
            "Resources", "Sprites"
        )
        
        parent_folder = sprite_resource.get("parent_folder", "")
        if parent_folder:
            sprites_folder = os.path.join(sprites_folder, parent_folder)
        
        # Delete all frame files
        frames = sprite_resource.get("frames", [])
        for frame in frames:
            if "file" in frame:
                frame_path = os.path.join(sprites_folder, frame["file"])
                if os.path.exists(frame_path):
                    try:
                        os.remove(frame_path)
                        print(f"Deleted frame file: {frame['file']}")
                    except Exception as e:
                        print(f"Failed to delete frame file {frame['file']}: {e}")
    
    def _delete_object_event_files(self, object_resource):
        """Delete all .pgsl event files associated with an object"""
        import os
        
        # Get the objects folder path, including parent folder if specified
        objects_folder = os.path.join(
            self.project_manager.get_project_path(),
            "Resources", "Objects"
        )
        
        parent_folder = object_resource.get("parent_folder", "")
        if parent_folder:
            objects_folder = os.path.join(objects_folder, parent_folder)
        
        # Delete all .pgsl event files
        events = object_resource.get("events", {})
        for event_id, event_ref in events.items():
            if event_ref and event_ref.endswith(".pgsl"):
                # event_ref is a filename (e.g., "Object2_Create.pgsl")
                pgsl_path = os.path.join(objects_folder, event_ref)
                if os.path.exists(pgsl_path):
                    try:
                        os.remove(pgsl_path)
                        from Core.Debug import debug
                        debug(f"Deleted event file: {event_ref}")
                    except Exception as e:
                        from Core.Debug import debug
                        debug(f"Failed to delete event file {event_ref}: {e}")
    
    def _rename_object_event_files(self, object_resource, old_name, new_name):
        """Rename all .pgsl event files when object is renamed"""
        import os
        
        # Get the objects folder path, including parent folder if specified
        objects_folder = os.path.join(
            self.project_manager.get_project_path(),
            "Resources", "Objects"
        )
        
        parent_folder = object_resource.get("parent_folder", "")
        if parent_folder:
            objects_folder = os.path.join(objects_folder, parent_folder)
        
        # Rename all .pgsl event files
        events = object_resource.get("events", {})
        for event_id, event_ref in list(events.items()):
            if event_ref and event_ref.endswith(".pgsl"):
                # event_ref is a filename (e.g., "Object2_Create.pgsl")
                old_pgsl_path = os.path.join(objects_folder, event_ref)
                
                if os.path.exists(old_pgsl_path):
                    # Generate new filename: {new_object_name}_{event_id}.pgsl
                    new_pgsl_filename = f"{new_name}_{event_id}.pgsl"
                    new_pgsl_path = os.path.join(objects_folder, new_pgsl_filename)
                    
                    try:
                        # Rename the file
                        os.rename(old_pgsl_path, new_pgsl_path)
                        # Update the event reference in the object data
                        events[event_id] = new_pgsl_filename
                        from Core.Debug import debug
                        debug(f"Renamed event file: {event_ref} -> {new_pgsl_filename}")
                    except Exception as e:
                        from Core.Debug import debug
                        debug(f"Failed to rename event file {event_ref}: {e}")
                        import traceback
                        traceback.print_exc()
                else:
                    # File doesn't exist, but update reference anyway
                    new_pgsl_filename = f"{new_name}_{event_id}.pgsl"
                    events[event_id] = new_pgsl_filename
    
    def rename_resource(self, resource_type, resource_id, new_name, skip_undo_record=False):
        """Rename a resource in runtime"""
        try:
            # Get the resource directly from runtime (not a copy)
            resource = self.project_manager.get_runtime_resource(resource_type, resource_id)
            if not resource:
                from Core.Debug import debug
                debug(f" Resource {resource_id} not found in runtime")
                return False
            
            old_name = resource["name"]
            
            # Check for duplicate names (skip if name hasn't changed)
            if new_name != old_name:
                existing_resources = self.project_manager.get_resources(resource_type)
                for existing_resource in existing_resources:
                    if (existing_resource.get("name") == new_name and 
                        existing_resource.get("id") != resource_id and
                        existing_resource.get("parent_folder", "") == resource.get("parent_folder", "")):
                        QMessageBox.warning(None, "Name Exists", 
                            f"A {resource_type} with the name '{new_name}' already exists in this folder.")
                        return False
            
            from Core.Debug import debug
            debug(f" Renaming {resource_type} {resource_id} from '{old_name}' to '{new_name}'")
            
            # Record to undo stack
            if self.undo_redo_manager and not skip_undo_record:
                self.undo_redo_manager.record_rename(resource_type, resource_id, old_name, new_name)
            
            # Special handling for resource types with associated files
            if resource_type == "sprites":
                self._rename_sprite_frame_files(resource, old_name, new_name)
            elif resource_type == "sounds":
                self._rename_sound_audio_file(resource, old_name, new_name)
            elif resource_type == "models":
                self._rename_model_file(resource, old_name, new_name)
            elif resource_type == "objects":
                self._rename_object_event_files(resource, old_name, new_name)
            
            # Update the resource directly in runtime
            resource["name"] = new_name
            resource["modified"] = self._get_timestamp()
            
            # If this is an object being renamed, update children's parent field
            if resource_type == "objects":
                self._update_object_children_on_parent_rename(old_name, new_name)
            
            # Mark as dirty
            self.project_manager.is_dirty = True
            
            # Save the resource file to update the name on disk
            folder_path = os.path.join(
                self.project_manager.get_project_path(),
                "Resources",
                self.resource_types[resource_type]["folder"]
            )
            
            if resource.get("parent_folder"):
                folder_path = os.path.join(folder_path, resource["parent_folder"])
            
            # Old file path
            old_file_path = os.path.join(
                folder_path,
                f"{old_name}{self.resource_types[resource_type]['extension']}"
            )
            
            # New file path
            new_file_path = os.path.join(
                folder_path,
                f"{new_name}{self.resource_types[resource_type]['extension']}"
            )
            
            # Rename the resource file if it exists
            if os.path.exists(old_file_path) and old_file_path != new_file_path:
                try:
                    os.rename(old_file_path, new_file_path)
                    from Core.Debug import debug
                    debug(f" Renamed resource file: {old_name} -> {new_name}")
                except Exception as e:
                    print(f"ERROR: Failed to rename resource file: {e}")
            
            # Save the updated resource data to the new file
            self.save_resource(resource_type, resource, new_file_path)
            
            # Emit signal to update UI
            self.resource_updated.emit(resource_type, resource)
            
            # Update window title to show dirty state
            if hasattr(self.project_manager, 'app') and hasattr(self.project_manager.app, 'main_window'):
                project_name = self.project_manager.get_project_name()
                self.project_manager.app.main_window.update_window_title(project_name)
            
            from Core.Debug import debug
            debug(f" Successfully renamed {resource_type} {resource_id} from '{old_name}' to '{new_name}' in runtime")
            return True
            
        except Exception as e:
            QMessageBox.critical(None, "Error", f"Failed to rename resource: {str(e)}")
            import traceback
            traceback.print_exc()
            return False
    
    def _rename_sprite_frame_files(self, sprite_resource, old_name, new_name):
        """Rename all frame files when sprite is renamed"""
        import os
        
        # Get the sprites folder path, including parent folder if specified
        sprites_folder = os.path.join(
            self.project_manager.get_project_path(),
            "Resources", "Sprites"
        )
        
        parent_folder = sprite_resource.get("parent_folder", "")
        if parent_folder:
            sprites_folder = os.path.join(sprites_folder, parent_folder)
        
        # Rename all frame files
        frames = sprite_resource.get("frames", [])
        for i, frame in enumerate(frames):
            if "file" in frame:
                old_frame_path = os.path.join(sprites_folder, frame["file"])
                if os.path.exists(old_frame_path):
                    # Generate new filename based on sprite name and frame index
                    # Extract extension from old filename
                    old_ext = os.path.splitext(frame["file"])[1]
                    # Create new filename: {sprite_name}_{frame_index}.{ext}
                    new_frame_filename = f"{new_name}_{i}{old_ext}"
                    new_frame_path = os.path.join(sprites_folder, new_frame_filename)
                    
                    try:
                        # Rename the file
                        os.rename(old_frame_path, new_frame_path)
                        # Update the frame reference in the sprite data
                        frame["file"] = new_frame_filename
                        from Core.Debug import debug
                        debug(f"Renamed frame file: {frame['file']} -> {new_frame_filename}")
                    except Exception as e:
                        from Core.Debug import debug
                        debug(f"Failed to rename frame file {frame['file']}: {e}")
                        import traceback
                        traceback.print_exc()
                else:
                    from Core.Debug import debug
                    debug(f"Frame file not found for renaming: {old_frame_path}")
    
    def _copy_sprite_frame_files(self, source_sprite_resource, target_sprite_resource):
        """Copy all frame files when sprite is copied"""
        import os
        import shutil
        
        # Get the sprites folder path
        sprites_folder = os.path.join(
            self.project_manager.get_project_path(),
            "Resources", "Sprites"
        )
        
        # Handle parent folders
        source_parent = source_sprite_resource.get("parent_folder", "")
        target_parent = target_sprite_resource.get("parent_folder", "")
        
        source_folder = os.path.join(sprites_folder, source_parent) if source_parent else sprites_folder
        target_folder = os.path.join(sprites_folder, target_parent) if target_parent else sprites_folder
        
        # Ensure target folder exists
        os.makedirs(target_folder, exist_ok=True)
        
        source_name = source_sprite_resource.get("name", "")
        target_name = target_sprite_resource.get("name", "")
        
        # Copy all frame files
        source_frames = source_sprite_resource.get("frames", [])
        target_frames = []
        
        for frame in source_frames:
            if "file" in frame:
                source_frame_path = os.path.join(source_folder, frame["file"])
                
                if os.path.exists(source_frame_path):
                    # Generate new filename based on target sprite name
                    # Extract frame number/index from filename if possible
                    frame_filename = frame["file"]
                    _, ext = os.path.splitext(frame_filename)
                    
                    # Try to extract frame number (e.g., "sprite_Luigi1_0.png" -> "_0")
                    # If the filename contains the source name, replace it with target name
                    if source_name in frame_filename:
                        new_frame_filename = frame_filename.replace(source_name, target_name)
                    else:
                        # Generate a new filename based on frame index
                        frame_index = len(target_frames)
                        new_frame_filename = f"{target_name}_{frame_index}{ext}"
                    
                    target_frame_path = os.path.join(target_folder, new_frame_filename)
                    
                    # Handle filename conflicts
                    counter = 1
                    original_new_filename = new_frame_filename
                    while os.path.exists(target_frame_path):
                        base_name, ext = os.path.splitext(original_new_filename)
                        new_frame_filename = f"{base_name}_{counter}{ext}"
                        target_frame_path = os.path.join(target_folder, new_frame_filename)
                        counter += 1
                    
                    try:
                        # Copy the file
                        shutil.copy2(source_frame_path, target_frame_path)
                        
                        # Create new frame entry with updated filename
                        new_frame = frame.copy()
                        new_frame["file"] = new_frame_filename
                        target_frames.append(new_frame)
                        
                        print(f"Copied frame file: {frame['file']} -> {new_frame_filename}")
                    except Exception as e:
                        print(f"Failed to copy frame file {frame['file']}: {e}")
        
        # Update target sprite resource with new frames
        target_sprite_resource["frames"] = target_frames
        return True
    
    def _copy_sound_audio_file_for_copy(self, source_sound_resource, target_sound_resource):
        """Copy audio file when sound resource is copied"""
        import os
        import shutil
        
        # Get the sounds folder path
        sounds_folder = os.path.join(
            self.project_manager.get_project_path(),
            "Resources", "Sounds"
        )
        
        # Handle parent folders
        source_parent = source_sound_resource.get("parent_folder", "")
        target_parent = target_sound_resource.get("parent_folder", "")
        
        source_folder = os.path.join(sounds_folder, source_parent) if source_parent else sounds_folder
        target_folder = os.path.join(sounds_folder, target_parent) if target_parent else sounds_folder
        
        # Ensure target folder exists
        os.makedirs(target_folder, exist_ok=True)
        
        # Determine source audio file path
        audio_file = source_sound_resource.get("audio_file")
        original_audio_file = source_sound_resource.get("original_audio_file")
        
        if not audio_file and not original_audio_file:
            # No audio file to copy
            return False
        
        # Find the source file
        source_audio_path = None
        if original_audio_file and os.path.exists(original_audio_file):
            source_audio_path = original_audio_file
        elif audio_file:
            source_audio_path = os.path.join(source_folder, audio_file)
            if not os.path.exists(source_audio_path):
                # Try without parent folder
                source_audio_path = os.path.join(sounds_folder, audio_file)
        
        if not source_audio_path or not os.path.exists(source_audio_path):
            from Core.Debug import debug
            debug(f" Source audio file not found: {source_audio_path}")
            return False
        
        # Generate target filename
        target_name = target_sound_resource.get("name", "sound")
        _, ext = os.path.splitext(source_audio_path)
        target_filename = f"{target_name}{ext}"
        target_audio_path = os.path.join(target_folder, target_filename)
        
        # Handle filename conflicts
        counter = 1
        while os.path.exists(target_audio_path):
            target_filename = f"{target_name}_{counter}{ext}"
            target_audio_path = os.path.join(target_folder, target_filename)
            counter += 1
        
        try:
            # Copy the audio file
            shutil.copy2(source_audio_path, target_audio_path)
            
            # Update target sound resource
            target_sound_resource["audio_file"] = target_filename
            target_sound_resource["original_audio_file"] = target_audio_path
            
            print(f"Copied audio file: {os.path.basename(source_audio_path)} -> {target_filename}")
            return True
            
        except Exception as e:
            print(f"ERROR: Failed to copy audio file: {e}")
            return False
    
    def _delete_sound_audio_files(self, sound_resource):
        """Delete audio file associated with a sound resource"""
        import os
        
        # Get the sounds folder path, including parent folder if specified
        sounds_folder = os.path.join(
            self.project_manager.get_project_path(),
            "Resources", "Sounds"
        )
        
        parent_folder = sound_resource.get("parent_folder", "")
        if parent_folder:
            sounds_folder = os.path.join(sounds_folder, parent_folder)
        
        # Delete the audio file if it exists
        audio_file = sound_resource.get("audio_file")
        original_audio_file = sound_resource.get("original_audio_file")
        
        # Try to find and delete the audio file
        if original_audio_file and os.path.exists(original_audio_file):
            try:
                os.remove(original_audio_file)
                print(f"Deleted audio file: {os.path.basename(original_audio_file)}")
            except Exception as e:
                print(f"Failed to delete audio file {original_audio_file}: {e}")
        elif audio_file:
            # Extract just the filename from the path
            audio_filename = os.path.basename(audio_file)
            audio_path = os.path.join(sounds_folder, audio_filename)
            if os.path.exists(audio_path):
                try:
                    os.remove(audio_path)
                    print(f"Deleted audio file: {audio_filename}")
                except Exception as e:
                    print(f"Failed to delete audio file {audio_filename}: {e}")
    
    def _copy_sound_audio_file(self, sound_resource, source_audio_path):
        """Copy audio file to the sounds folder and update resource data"""
        import os
        import shutil
        
        from Core.Debug import debug
        debug(f" _copy_sound_audio_file called for resource '{sound_resource.get('name')}' from '{source_audio_path}'")
        
        if not os.path.exists(source_audio_path):
            print(f"ERROR: Original audio file not found: {source_audio_path}")
            return False
        
        # Get the sounds folder path
        sounds_folder = os.path.join(
            self.project_manager.get_project_path(),
            "Resources", "Sounds"
        )
        
        debug(f" Target sounds folder: {sounds_folder}")
        
        # Ensure sounds folder exists
        os.makedirs(sounds_folder, exist_ok=True)
        
        # Generate destination filename
        source_filename = os.path.basename(source_audio_path)
        name = sound_resource.get("name", "sound")
        
        debug(f" Source filename: {source_filename}, Resource name: {name}")
        
        # Create a unique filename to avoid conflicts
        base_name, ext = os.path.splitext(source_filename)
        dest_filename = f"{name}{ext}"
        dest_path = os.path.join(sounds_folder, dest_filename)
        
        debug(f" Initial dest filename: {dest_filename}")
        
        # Handle filename conflicts
        counter = 1
        while os.path.exists(dest_path):
            dest_filename = f"{name}_{counter}{ext}"
            dest_path = os.path.join(sounds_folder, dest_filename)
            counter += 1
            debug(f" Filename conflict, trying: {dest_filename}")
        
        debug(f" Final dest path: {dest_path}")
        
        try:
            # Normalize destination path to avoid mixed slashes
            dest_path = os.path.normpath(dest_path)
            
            # Ensure target directory exists
            dest_dir = os.path.dirname(dest_path)
            os.makedirs(dest_dir, exist_ok=True)
            
            # Copy the audio file
            debug(f" Attempting to copy from '{source_audio_path}' to '{dest_path}'")
            shutil.copy2(source_audio_path, dest_path)
            
            # Verify copy succeeded
            if not os.path.exists(dest_path):
                print(f"ERROR: File copy verification failed: {dest_path}")
                return False
            
            # Update resource data with the new file path (normalized)
            sound_resource["audio_file"] = dest_filename
            sound_resource["original_audio_file"] = dest_path  # Store the copied file path, not the source
            
            debug(f" Successfully copied audio file: {source_filename} -> {dest_filename}")
            debug(f" Updated resource data - audio_file: {sound_resource['audio_file']}")
            debug(f" Updated resource data - original_audio_file: {sound_resource['original_audio_file']}")
            return True
            
        except Exception as e:
            print(f"ERROR: Failed to copy audio file {source_filename}: {e}")
            return False
    
    def _copy_model_file(self, model_resource, source_model_path):
        """Copy model file, MTL file, and textures to the models folder and update resource data"""
        import os
        import shutil
        
        from Core.Debug import debug
        debug(f" _copy_model_file called for resource '{model_resource.get('name')}' from '{source_model_path}'")
        
        if not os.path.exists(source_model_path):
            print(f"ERROR: Original model file not found: {source_model_path}")
            return False
        
        # Get the models folder path
        models_folder = os.path.join(
            self.project_manager.get_project_path(),
            "Resources", "Models"
        )
        
        parent_folder = model_resource.get("parent_folder", "")
        if parent_folder:
            models_folder = os.path.join(models_folder, parent_folder)
        
        debug(f" Target models folder: {models_folder}")
        
        # Ensure models folder exists
        os.makedirs(models_folder, exist_ok=True)
        
        # Get source directory
        source_dir = os.path.dirname(os.path.abspath(source_model_path))
        
        # Generate destination filename
        source_filename = os.path.basename(source_model_path)
        name = model_resource.get("name", "model")
        
        debug(f" Source filename: {source_filename}, Resource name: {name}")
        
        # Create a unique filename to avoid conflicts
        base_name, ext = os.path.splitext(source_filename)
        dest_filename = f"{name}{ext}"
        dest_path = os.path.join(models_folder, dest_filename)
        
        debug(f" Initial dest filename: {dest_filename}")
        
        # Handle filename conflicts
        counter = 1
        while os.path.exists(dest_path):
            dest_filename = f"{name}_{counter}{ext}"
            dest_path = os.path.join(models_folder, dest_filename)
            counter += 1
            debug(f" Filename conflict, trying: {dest_filename}")
        
        debug(f" Final dest path: {dest_path}")
        
        try:
            # Normalize destination path to avoid mixed slashes
            dest_path = os.path.normpath(dest_path)
            
            # Ensure target directory exists
            dest_dir = os.path.dirname(dest_path)
            os.makedirs(dest_dir, exist_ok=True)
            
            # Copy the model file
            debug(f" Attempting to copy from '{source_model_path}' to '{dest_path}'")
            shutil.copy2(source_model_path, dest_path)
            
            # Verify copy succeeded
            if not os.path.exists(dest_path):
                print(f"ERROR: File copy verification failed: {dest_path}")
                return False
            
            # Update resource data with the new file path (normalized)
            model_resource["model_file"] = dest_filename
            # Store original source filename for reference only (not the full path)
            model_resource["original_model_file"] = source_filename
            
            # Determine format
            ext_lower = ext.lower().lstrip('.')
            if ext_lower in ('obj', 'glb', 'gltf', 'dae'):
                model_resource["format"] = ext_lower
            
            # For OBJ files, look for MTL file and textures
            texture_files = []
            mtl_file = None
            
            if ext_lower == 'obj':
                # Look for MTL file (same name as OBJ, or referenced in OBJ)
                # First, try same name with .mtl extension
                mtl_candidates = [
                    os.path.join(source_dir, base_name + '.mtl'),
                    os.path.join(source_dir, os.path.splitext(source_filename)[0] + '.mtl')
                ]
                
                # Also check OBJ file for mtllib reference
                try:
                    with open(source_model_path, 'r', encoding='utf-8', errors='ignore') as f:
                        for line in f:
                            if line.strip().startswith('mtllib '):
                                mtl_ref = line.split()[1] if len(line.split()) > 1 else None
                                if mtl_ref:
                                    mtl_candidates.insert(0, os.path.join(source_dir, mtl_ref))
                                break
                except Exception as e:
                    debug(f" Error reading OBJ for mtllib: {e}")
                
                # Check if MTL file exists
                mtl_found = False
                
                # Find and copy MTL file
                for mtl_candidate in mtl_candidates:
                    if os.path.exists(mtl_candidate):
                        mtl_found = True
                        mtl_filename = os.path.basename(mtl_candidate)
                        mtl_dest = os.path.join(models_folder, mtl_filename)
                        
                        # Handle filename conflicts
                        mtl_counter = 1
                        original_mtl_filename = mtl_filename
                        while os.path.exists(mtl_dest) and mtl_dest != os.path.normpath(mtl_candidate):
                            base, ext_mtl = os.path.splitext(original_mtl_filename)
                            mtl_filename = f"{base}_{mtl_counter}{ext_mtl}"
                            mtl_dest = os.path.join(models_folder, mtl_filename)
                            mtl_counter += 1
                        
                        if mtl_dest != os.path.normpath(mtl_candidate):
                            shutil.copy2(mtl_candidate, mtl_dest)
                            debug(f" Copied MTL file: {os.path.basename(mtl_candidate)} -> {mtl_filename}")
                            mtl_file = mtl_filename
                        else:
                            # File already in destination, just use filename
                            mtl_file = mtl_filename
                        break
                
                if not mtl_found:
                    debug(f" No MTL file found for OBJ model - textures may need manual loading")
                
                # If MTL file was found, parse it for texture references
                if mtl_file:
                    # Use copied MTL file in destination folder
                    mtl_path = os.path.join(models_folder, mtl_file)
                    # But also keep reference to source MTL for parsing if copied MTL doesn't exist yet
                    source_mtl_path = None
                    for mtl_candidate in mtl_candidates:
                        if os.path.exists(mtl_candidate):
                            source_mtl_path = mtl_candidate
                            break
                    
                    texture_candidates = []
                    
                    # Parse MTL for texture references (use source MTL if dest doesn't exist, otherwise use dest)
                    mtl_to_parse = source_mtl_path if source_mtl_path and not os.path.exists(mtl_path) else mtl_path
                    if os.path.exists(mtl_to_parse):
                        try:
                            with open(mtl_to_parse, 'r', encoding='utf-8', errors='ignore') as f:
                                for line in f:
                                    line = line.strip()
                                    # Look for texture map declarations
                                    if line.startswith('map_Kd ') or line.startswith('map_diffuse ') or \
                                       line.startswith('map_Ks ') or line.startswith('map_specular ') or \
                                       line.startswith('map_Ka ') or line.startswith('map_ambient ') or \
                                       line.startswith('map_bump ') or line.startswith('map_normal ') or \
                                       line.startswith('map_d ') or line.startswith('map_opacity '):
                                        tex_ref = ' '.join(line.split()[1:])  # Handle spaces in filename
                                        if tex_ref:
                                            # Try multiple possible paths (source directory)
                                            tex_paths = [
                                                os.path.join(source_dir, tex_ref),
                                                os.path.join(source_dir, os.path.basename(tex_ref))
                                            ]
                                            for tex_path in tex_paths:
                                                if os.path.exists(tex_path) and tex_path not in texture_candidates:
                                                    texture_candidates.append(tex_path)
                                                    break
                        except Exception as e:
                            debug(f" Error reading MTL for textures: {e}")
                    
                    # Also scan source directory for common texture formats if no textures found in MTL
                    if not texture_candidates:
                        texture_extensions = ['.png', '.jpg', '.jpeg', '.bmp', '.tga', '.tiff', '.tif']
                        if os.path.exists(source_dir):
                            try:
                                for filename in os.listdir(source_dir):
                                    if any(filename.lower().endswith(ext) for ext in texture_extensions):
                                        tex_path = os.path.join(source_dir, filename)
                                        if tex_path not in texture_candidates:
                                            texture_candidates.append(tex_path)
                            except Exception as e:
                                debug(f" Error scanning source directory for textures: {e}")
                    
                    # Copy texture files
                    for tex_path in texture_candidates:
                        tex_filename = os.path.basename(tex_path)
                        tex_dest = os.path.join(models_folder, tex_filename)
                        
                        # Handle filename conflicts
                        tex_counter = 1
                        original_tex_filename = tex_filename
                        while os.path.exists(tex_dest) and tex_dest != os.path.normpath(tex_path):
                            base, ext_tex = os.path.splitext(original_tex_filename)
                            tex_filename = f"{base}_{tex_counter}{ext_tex}"
                            tex_dest = os.path.join(models_folder, tex_filename)
                            tex_counter += 1
                        
                        if tex_dest != os.path.normpath(tex_path):
                            shutil.copy2(tex_path, tex_dest)
                            debug(f" Copied texture file: {os.path.basename(tex_path)} -> {tex_filename}")
                            texture_files.append(tex_filename)
                        else:
                            # File already in destination
                            texture_files.append(tex_filename)
            
            # Update resource data
            model_resource["mtl_file"] = mtl_file
            model_resource["texture_files"] = texture_files
            
            debug(f" Successfully copied model file: {source_filename} -> {dest_filename}")
            if mtl_file:
                debug(f" MTL file: {mtl_file}")
            if texture_files:
                debug(f" Texture files: {texture_files}")
            debug(f" Updated resource data - model_file: {model_resource['model_file']}")
            debug(f" Updated resource data - original_model_file: {model_resource['original_model_file']}")
            
            # Import textures: copy to Textures folder, create .Texture files, and update references
            if texture_files:
                self._import_textures_for_model(model_resource, models_folder, texture_files, mtl_file)
            
            return True
            
        except Exception as e:
            print(f"ERROR: Failed to copy model file {source_filename}: {e}")
            import traceback
            traceback.print_exc()
            return False
    
    def _import_textures_for_model(self, model_resource, models_folder, texture_files, mtl_file):
        """
        Import textures for a model: copy to organized Textures folder and update MTL references.
        
        Simple approach: Keep OBJ→PNG references working, just organize textures in folders.
        - Copies textures to Textures/ModelName/texture.png
        - Updates MTL to point to Textures/ModelName/texture.png (still PNG, not .Texture)
        - Creates optional .Texture files for metadata/management (not required for rendering)
        
        Args:
            model_resource: The model resource data dict
            models_folder: Path to the Models folder containing the textures
            texture_files: List of texture filenames found in the model
            mtl_file: MTL filename (if any)
        """
        import os
        import shutil
        from PIL import Image
        
        model_name = model_resource.get("name", "Model")
        debug(f" _import_textures_for_model: Processing {len(texture_files)} textures for model '{model_name}'")
        
        # Get Textures folder - organized by model name
        textures_base_folder = os.path.join(
            self.project_manager.get_project_path(),
            "Resources", "Textures"
        )
        model_textures_folder = os.path.join(textures_base_folder, model_name)
        os.makedirs(model_textures_folder, exist_ok=True)
        
        # Track texture mapping: original_filename -> new_path_in_textures_folder
        texture_mapping = {}  # {original_texture_name: new_texture_path_in_textures_folder}
        
        # Process each unique texture
        unique_textures = list(set(texture_files))  # Remove duplicates
        
        for tex_filename in unique_textures:
            # Source texture in Models folder
            source_tex_path = os.path.join(models_folder, tex_filename)
            
            if not os.path.exists(source_tex_path):
                debug(f" Texture file not found: {source_tex_path}, skipping")
                continue
            
            # Copy to Textures/ModelName/ - use original filename for simplicity
            # This keeps MTL references simple: Textures/ModelName/texture.png
            dest_tex_filename = tex_filename  # Keep original name for easy MTL updates
            dest_tex_path = os.path.join(model_textures_folder, dest_tex_filename)
            
            if not os.path.exists(dest_tex_path):
                shutil.copy2(source_tex_path, dest_tex_path)
                debug(f" Copied texture {tex_filename} -> {dest_tex_path}")
            else:
                debug(f" Texture already exists: {dest_tex_path}")
            
            # Store mapping: original filename -> path relative to Textures folder
            # Format: ModelName/texture.png (relative to Resources/Textures)
            texture_mapping[tex_filename] = f"{model_name}/{dest_tex_filename}"
            
            # OPTIONAL: Create .Texture file for metadata/management (not required for rendering)
            # This allows users to add animation frames, edit textures, etc. via TextureEditor
            # OBJ/MTL still reference PNG directly, but .Texture file provides management layer
            tex_base_name = os.path.splitext(dest_tex_filename)[0]
            tex_ext = os.path.splitext(dest_tex_filename)[1]
            
            try:
                img = Image.open(dest_tex_path)
                width, height = img.size
            except Exception as e:
                debug(f" Failed to get texture dimensions: {e}")
                width, height = 256, 256
            
            # Create .Texture file for management (optional - OBJ can still use PNG directly)
            # Store in Textures/ModelName/ folder for organization
            texture_resource_name = f"{model_name}_{os.path.splitext(tex_filename)[0]}"
            
            # Check if texture resource already exists
            all_textures = self.project_manager.get_resources("textures")
            existing_texture = None
            for tex in all_textures:
                if tex.get("name") == texture_resource_name:
                    existing_texture = tex
                    break
            
            if not existing_texture:
                # Create .Texture resource file for management (stored in Textures/ModelName/ folder)
                texture_resource = self.create_resource("textures", texture_resource_name, model_name)  # parent_folder = model_name
                
                if texture_resource:
                    # Set up frames array - initially just the one PNG file
                    texture_resource["frames"] = [
                        {
                            "id": "frame_0",
                            "file": dest_tex_filename,  # Relative to Textures/ModelName/ folder
                            "duration": 0.0  # Static texture by default
                        }
                    ]
                    texture_resource["width"] = width
                    texture_resource["height"] = height
                    texture_resource["format"] = tex_ext.lstrip('.').lower()
                    texture_resource["animated"] = False
                    
                    # Save texture resource (will be saved to Textures/ModelName/ folder via parent_folder)
                    self.save_resource("textures", texture_resource)
                    debug(f" Created .Texture file for management: {texture_resource_name}.texture in {model_name}/")
            else:
                # Update existing texture resource - ensure frame_0 points to current PNG
                # Check if frame_0 exists and update it, or add it if missing
                frames = existing_texture.get("frames", [])
                frame_0_exists = any(f.get("id") == "frame_0" for f in frames)
                
                if not frame_0_exists:
                    # Add frame_0
                    if not frames:
                        frames = []
                    frames.insert(0, {
                        "id": "frame_0",
                        "file": dest_tex_filename,
                        "duration": 0.0
                    })
                else:
                    # Update frame_0 file reference
                    for frame in frames:
                        if frame.get("id") == "frame_0":
                            frame["file"] = dest_tex_filename
                            break
                
                existing_texture["frames"] = frames
                existing_texture["width"] = width
                existing_texture["height"] = height
                self.save_resource("textures", existing_texture)
                debug(f" Updated .Texture file: {texture_resource_name}.texture")
        
        # Update MTL file to point to Textures/ModelName/texture.png (still PNG, just organized)
        if mtl_file and texture_mapping:
            mtl_path = os.path.join(models_folder, mtl_file)
            if os.path.exists(mtl_path):
                try:
                    self._update_mtl_texture_references_simple(mtl_path, texture_mapping)
                except Exception as e:
                    debug(f" Failed to update MTL texture references: {e}")
                    import traceback
                    traceback.print_exc()
        
        # Update model resource with texture paths - THIS IS THE SINGLE SOURCE OF TRUTH
        # texture_paths stores paths like "ModelName/texture.png" relative to Resources/Textures
        if texture_mapping:
            # Set texture_paths as the primary source (single source of truth)
            model_resource["texture_paths"] = list(texture_mapping.values())
            debug(f" Set texture_paths (single source of truth): {len(model_resource['texture_paths'])} texture(s)")
            
            # Also store texture resource names for management features (optional)
            texture_resource_names = []
            for tex_filename in unique_textures:
                if tex_filename in texture_mapping:
                    tex_base_name = os.path.splitext(tex_filename)[0]
                    texture_resource_name = f"{model_name}_{tex_base_name}"
                    texture_resource_names.append(texture_resource_name)
            
            if texture_resource_names:
                model_resource["texture_resources"] = texture_resource_names
            
            # Keep texture_files for backwards compatibility, but texture_paths is the source of truth
            # texture_files should match what's in texture_paths (just the filenames)
            # This helps with old code that might still reference texture_files
            model_resource["texture_files"] = unique_textures
            
            try:
                self.save_resource_file_only("models", model_resource)
                debug(f" Saved model resource with texture_paths as single source of truth")
            except Exception as e:
                debug(f" Failed to save model resource: {e}")
                import traceback
                traceback.print_exc()
    
    def _update_mtl_texture_references_simple(self, mtl_path, texture_mapping):
        """
        Update MTL file to reference PNG files in Textures folder (not .Texture files).
        Keeps OBJ→PNG references working, just updates paths to organized location.
        
        Args:
            mtl_path: Path to the MTL file
            texture_mapping: Dict mapping original texture names to new paths (e.g., "ModelName/texture.png")
        """
        import os
        
        try:
            # Read MTL file
            with open(mtl_path, 'r', encoding='utf-8', errors='ignore') as f:
                lines = f.readlines()
            
            # Update texture references
            updated_lines = []
            for line in lines:
                line_stripped = line.strip()
                
                # Check if this line references a texture
                if any(line_stripped.startswith(prefix) for prefix in 
                       ['map_Kd ', 'map_diffuse ', 'map_Ks ', 'map_specular ', 
                        'map_Ka ', 'map_ambient ', 'map_bump ', 'map_normal ', 
                        'map_d ', 'map_opacity ']):
                    # Extract texture reference
                    parts = line_stripped.split()
                    if len(parts) >= 2:
                        original_tex_ref = ' '.join(parts[1:])  # Handle spaces in filename
                        original_tex_name = os.path.basename(original_tex_ref)
                        
                        # Check if we have a mapping for this texture
                        if original_tex_name in texture_mapping:
                            new_tex_path = texture_mapping[original_tex_name]  # e.g., "ModelName/texture.png"
                            # Update to reference PNG in Textures folder
                            # Format: Textures\ModelName\texture.png (Windows) or Textures/ModelName/texture.png (Unix)
                            if os.name == 'nt':  # Windows
                                new_tex_ref = f"Textures\\{new_tex_path}".replace('/', '\\')
                            else:  # Unix/Linux/Mac
                                new_tex_ref = f"Textures/{new_tex_path}".replace('\\', '/')
                            # Replace the texture reference (preserve the map_Kd prefix)
                            line = parts[0] + " " + new_tex_ref + "\n"
                            debug(f" Updated MTL texture reference: {original_tex_name} -> {new_tex_ref}")
                
                updated_lines.append(line)
            
            # Write updated MTL file
            with open(mtl_path, 'w', encoding='utf-8') as f:
                f.writelines(updated_lines)
            
            debug(f" Updated MTL file: {mtl_path}")
            
        except Exception as e:
            debug(f" Error updating MTL file: {e}")
            raise
    
    def _rename_sound_audio_file(self, sound_resource, old_name, new_name):
        """Rename the audio file when sound is renamed"""
        import os
        
        # Get the current audio file path from the resource
        audio_file = sound_resource.get("audio_file")
        original_audio_file = sound_resource.get("original_audio_file")
        
        if not audio_file and not original_audio_file:
            debug(f" No audio file to rename for sound '{old_name}'")
            return
        
        # Get the sounds folder path
        sounds_folder = os.path.join(
            self.project_manager.get_project_path(),
            "Resources", "Sounds"
        )
        
        # Determine the old file path
        old_audio_path = None
        if original_audio_file and os.path.exists(original_audio_file):
            # Use the original_audio_file path if it exists
            old_audio_path = original_audio_file
        elif audio_file:
            # Use audio_file relative to sounds folder
            old_audio_path = os.path.join(sounds_folder, audio_file)
        
        if not old_audio_path or not os.path.exists(old_audio_path):
            debug(f" Audio file not found for renaming: {old_audio_path}")
            return
        
        # Get the file extension
        _, ext = os.path.splitext(old_audio_path)
        
        # Generate new filename
        new_audio_filename = f"{new_name}{ext}"
        new_audio_path = os.path.join(sounds_folder, new_audio_filename)
        
        # Handle filename conflicts
        counter = 1
        while os.path.exists(new_audio_path) and new_audio_path != old_audio_path:
            new_audio_filename = f"{new_name}_{counter}{ext}"
            new_audio_path = os.path.join(sounds_folder, new_audio_filename)
            counter += 1
        
        try:
            # Rename the audio file
            if old_audio_path != new_audio_path:
                os.rename(old_audio_path, new_audio_path)
                debug(f" Renamed audio file: {os.path.basename(old_audio_path)} -> {new_audio_filename}")
            
            # Update resource data
            sound_resource["audio_file"] = new_audio_filename
            sound_resource["original_audio_file"] = new_audio_path
            
            debug(f" Updated resource data - audio_file: {sound_resource['audio_file']}")
            debug(f" Updated resource data - original_audio_file: {sound_resource['original_audio_file']}")
            
        except Exception as e:
            print(f"ERROR: Failed to rename audio file: {e}")
            import traceback
            traceback.print_exc()
    
    def _delete_model_files(self, model_resource):
        """Delete model file, MTL file, and textures associated with a model resource"""
        import os
        
        # Get the models folder path, including parent folder if specified
        models_folder = os.path.join(
            self.project_manager.get_project_path(),
            "Resources", "Models"
        )
        
        parent_folder = model_resource.get("parent_folder", "")
        if parent_folder:
            models_folder = os.path.join(models_folder, parent_folder)
        
        # Delete the model file if it exists
        model_file = model_resource.get("model_file")
        
        # Always use model_file (relative filename) to construct path
        if model_file:
            # model_file should already be just the filename
            model_filename = os.path.basename(model_file)  # Safety: extract filename
            model_path = os.path.join(models_folder, model_filename)
            if os.path.exists(model_path):
                try:
                    os.remove(model_path)
                    debug(f" Deleted model file: {model_filename}")
                except Exception as e:
                    debug(f" Failed to delete model file {model_filename}: {e}")
        
        # Delete MTL file if it exists
        mtl_file = model_resource.get("mtl_file")
        if mtl_file:
            mtl_filename = os.path.basename(mtl_file)
            mtl_path = os.path.join(models_folder, mtl_filename)
            if os.path.exists(mtl_path):
                try:
                    os.remove(mtl_path)
                    debug(f" Deleted MTL file: {mtl_filename}")
                except Exception as e:
                    debug(f" Failed to delete MTL file {mtl_filename}: {e}")
        
        # Delete texture files if they exist
        texture_files = model_resource.get("texture_files", [])
        for tex_file in texture_files:
            if tex_file:
                tex_filename = os.path.basename(tex_file)
                tex_path = os.path.join(models_folder, tex_filename)
                if os.path.exists(tex_path):
                    try:
                        os.remove(tex_path)
                        debug(f" Deleted texture file: {tex_filename}")
                    except Exception as e:
                        debug(f" Failed to delete texture file {tex_filename}: {e}")
    
    def _rename_model_file(self, model_resource, old_name, new_name):
        """Rename the model file, MTL file, and textures when model is renamed"""
        import os
        
        # Get the current model file path from the resource
        model_file = model_resource.get("model_file")
        
        if not model_file:
            debug(f" No model file to rename for model '{old_name}'")
            return
        
        # Get the models folder path
        models_folder = os.path.join(
            self.project_manager.get_project_path(),
            "Resources", "Models"
        )
        
        parent_folder = model_resource.get("parent_folder", "")
        if parent_folder:
            models_folder = os.path.join(models_folder, parent_folder)
        
        # Use model_file (should be just filename) to construct path
        model_filename = os.path.basename(model_file)  # Safety: extract filename
        old_model_path = os.path.join(models_folder, model_filename)
        
        if not os.path.exists(old_model_path):
            debug(f" Model file not found for renaming: {old_model_path}")
            return
        
        # Get the file extension
        _, ext = os.path.splitext(old_model_path)
        
        # Generate new filename
        new_model_filename = f"{new_name}{ext}"
        new_model_path = os.path.join(models_folder, new_model_filename)
        
        # Handle filename conflicts
        counter = 1
        while os.path.exists(new_model_path) and new_model_path != old_model_path:
            new_model_filename = f"{new_name}_{counter}{ext}"
            new_model_path = os.path.join(models_folder, new_model_filename)
            counter += 1
        
        try:
            # Rename the model file
            if old_model_path != new_model_path:
                os.rename(old_model_path, new_model_path)
                debug(f" Renamed model file: {os.path.basename(old_model_path)} -> {new_model_filename}")
            
            # Update resource data - store only the filename
            model_resource["model_file"] = new_model_filename
            # Keep original_model_file as reference (don't update it on rename)
            
            # Note: MTL and texture files keep their original names
            # They are referenced by filename in the resource data, not by model name
            # This matches how sprites work - frame files keep their names
            
            debug(f" Updated resource data - model_file: {model_resource['model_file']}")
            
        except Exception as e:
            print(f"ERROR: Failed to rename model file: {e}")
            import traceback
            traceback.print_exc()
    
    def move_resource(self, resource_type, resource_id, new_parent_folder):
        """Move a resource to a different folder"""
        try:
            resource = self.load_resource(resource_type, resource_id)
            if not resource:
                return False
            
            old_parent = resource.get("parent_folder", "")
            resource["parent_folder"] = new_parent_folder
            resource["modified"] = self._get_timestamp()
            
            # Move file
            old_folder = os.path.join(
                self.project_manager.get_project_path(),
                "Resources",
                self.resource_types[resource_type]["folder"],
                old_parent
            )
            new_folder = os.path.join(
                self.project_manager.get_project_path(),
                "Resources",
                self.resource_types[resource_type]["folder"],
                new_parent_folder
            )
            
            os.makedirs(new_folder, exist_ok=True)
            
            old_file = os.path.join(
                old_folder,
                f"{resource['name']}{self.resource_types[resource_type]['extension']}"
            )
            new_file = os.path.join(
                new_folder,
                f"{resource['name']}{self.resource_types[resource_type]['extension']}"
            )
            
            if os.path.exists(old_file):
                os.rename(old_file, new_file)
            
            # Update project data
            self.save_resource(resource_type, resource)
            return True
            
        except Exception as e:
            QMessageBox.critical(None, "Error", f"Failed to move resource: {str(e)}")
            return False
    
    def get_cached_texture(self, texture_path: str):
        """Get a cached texture by path, or None if not cached.
        
        Args:
            texture_path: Full path to the texture file
            
        Returns:
            dict with keys: "id" (OpenGL texture ID), "width", "height", "format", "ref_count"
            or None if not cached
        """
        # Normalize path for consistent lookups
        normalized_path = os.path.normpath(os.path.abspath(texture_path))
        if normalized_path in self._texture_cache:
            entry = self._texture_cache[normalized_path].copy()
            # Increment reference count
            self._texture_cache[normalized_path]["ref_count"] += 1
            entry["ref_count"] = self._texture_cache[normalized_path]["ref_count"]
            return entry
        return None
    
    def cache_texture(self, texture_path: str, texture_id: int, width: int, height: int, format: str = "RGBA"):
        """Cache a loaded texture with reference counting.
        
        Args:
            texture_path: Full path to the texture file
            texture_id: OpenGL texture ID
            width: Texture width in pixels
            height: Texture height in pixels
            format: Texture format (e.g., "RGBA", "RGB")
        """
        normalized_path = os.path.normpath(os.path.abspath(texture_path))
        if normalized_path in self._texture_cache:
            # Already cached, increment ref count
            self._texture_cache[normalized_path]["ref_count"] += 1
        else:
            # New cache entry
            self._texture_cache[normalized_path] = {
                "id": texture_id,
                "ref_count": 1,
                "width": width,
                "height": height,
                "format": format
            }
    
    def release_texture(self, texture_path: str):
        """Release a reference to a cached texture. If ref_count reaches 0, texture is not deleted
        but can be garbage collected by the caller.
        
        Args:
            texture_path: Full path to the texture file
            
        Returns:
            True if texture should be deleted (ref_count reached 0), False otherwise
        """
        normalized_path = os.path.normpath(os.path.abspath(texture_path))
        if normalized_path in self._texture_cache:
            self._texture_cache[normalized_path]["ref_count"] -= 1
            if self._texture_cache[normalized_path]["ref_count"] <= 0:
                # Return texture info for deletion, but don't delete from cache yet
                # (in case it gets requested again before cleanup)
                return True
        return False
    
    def remove_texture_from_cache(self, texture_path: str):
        """Remove a texture from cache entirely (after OpenGL deletion).
        
        Args:
            texture_path: Full path to the texture file
        """
        normalized_path = os.path.normpath(os.path.abspath(texture_path))
        if normalized_path in self._texture_cache:
            del self._texture_cache[normalized_path]
    
    def get_cached_materials(self, resource_id: str):
        """Get cached materials for a resource.
        
        Args:
            resource_id: Resource ID
            
        Returns:
            dict of material_name -> material_data, or None if not cached
        """
        if resource_id in self._material_cache:
            import copy
            return copy.deepcopy(self._material_cache[resource_id])
        return None
    
    def cache_materials(self, resource_id: str, materials: dict):
        """Cache normalized materials for a resource.
        
        Args:
            resource_id: Resource ID
            materials: dict of material_name -> UnifiedMaterial (or dict format)
        """
        import copy
        self._material_cache[resource_id] = copy.deepcopy(materials)
    
    def remove_materials_from_cache(self, resource_id: str):
        """Remove cached materials for a resource.
        
        Args:
            resource_id: Resource ID
        """
        if resource_id in self._material_cache:
            del self._material_cache[resource_id]
    
    def get_cached_model(self, model_path: str):
        """Get cached parsed model geometry, if file hasn't been modified.
        
        Args:
            model_path: Full path to model file
            
        Returns:
            dict with "vertices", "indices", "mtime", or None if not cached or modified
        """
        normalized_path = os.path.normpath(os.path.abspath(model_path))
        if normalized_path in self._model_cache:
            # Check if file modification time matches
            if os.path.exists(normalized_path):
                current_mtime = os.path.getmtime(normalized_path)
                cached_mtime = self._model_cache[normalized_path].get("mtime", 0)
                if abs(current_mtime - cached_mtime) < 0.1:  # Allow small floating point differences
                    import copy
                    return copy.deepcopy(self._model_cache[normalized_path])
                else:
                    # File modified, remove from cache
                    del self._model_cache[normalized_path]
        return None
    
    def cache_model(self, model_path: str, vertices, indices, **kwargs):
        """Cache parsed model geometry.
        
        Args:
            model_path: Full path to model file
            vertices: Vertex array
            indices: Index array
            **kwargs: Additional data to cache (e.g., normals, tex_coords)
        """
        normalized_path = os.path.normpath(os.path.abspath(model_path))
        import copy
        import numpy as np
        
        # Store minimal data (avoid deep copying large arrays in cache)
        cache_entry = {
            "mtime": os.path.getmtime(normalized_path) if os.path.exists(normalized_path) else 0,
            **kwargs
        }
        # Note: We don't cache the actual arrays here to save memory
        # This cache is primarily for tracking what's been parsed
        # The ModelEditor will re-parse but skip if already loaded
        self._model_cache[normalized_path] = cache_entry
    
    def clear_cache(self, cache_type: str = "all"):
        """Clear resource caches.
        
        Args:
            cache_type: "textures", "materials", "models", or "all"
        """
        if cache_type in ("textures", "all"):
            self._texture_cache.clear()
        if cache_type in ("materials", "all"):
            self._material_cache.clear()
        if cache_type in ("models", "all"):
            self._model_cache.clear()
    
    def get_cache_stats(self):
        """Get statistics about cached resources.
        
        Returns:
            dict with cache statistics
        """
        total_texture_refs = sum(entry["ref_count"] for entry in self._texture_cache.values())
        return {
            "textures": {
                "count": len(self._texture_cache),
                "total_refs": total_texture_refs
            },
            "materials": {
                "count": len(self._material_cache)
            },
            "models": {
                "count": len(self._model_cache)
            }
        }
    
    def set_undo_redo_manager(self, undo_redo_manager):
        """Set the undo/redo manager reference"""
        self.undo_redo_manager = undo_redo_manager
    
    def restore_resource(self, resource_type, resource_data, skip_undo_record=False):
        """Restore a resource from saved data (for undo/redo)"""
        try:
            # Create resource file
            folder_path = os.path.join(
                self.project_manager.get_project_path(),
                "Resources",
                self.resource_types[resource_type]["folder"]
            )
            
            parent_folder = resource_data.get("parent_folder", "")
            if parent_folder:
                folder_path = os.path.join(folder_path, parent_folder)
                os.makedirs(folder_path, exist_ok=True)
            
            file_path = os.path.join(
                folder_path,
                f"{resource_data['name']}{self.resource_types[resource_type]['extension']}"
            )
            
            # Save resource file
            with open(file_path, 'w', encoding='utf-8') as f:
                json.dump(resource_data, f, indent=4, ensure_ascii=False)
            
            # Add to runtime
            self.project_manager.add_runtime_resource(resource_type, resource_data["id"], resource_data)
            
            # Restore associated files (sprites, sounds, models)
            # Note: This is complex as files may have been deleted
            # For now, just restore the metadata
            
            self.resource_created.emit(resource_type, resource_data)
            return True
            
        except Exception as e:
            debug(f"Failed to restore resource: {str(e)}")
            return False
    
    def _get_timestamp(self):
        """Get current timestamp"""
        import datetime
        return datetime.datetime.now().isoformat()
