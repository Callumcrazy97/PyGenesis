"""
Thumbnail Cache Manager
Stores and loads cached thumbnails to avoid regenerating them every time.
Only regenerates thumbnails for files that have changed.
"""

import os
import json
import hashlib
from pathlib import Path
from typing import Optional, Tuple
from PySide6.QtGui import QPixmap, QIcon, QImage
from PySide6.QtCore import QSize, Qt
from Core.Debug import debug


class ThumbnailCache:
    """Manages cached thumbnails for resources"""
    
    CACHE_FOLDER = ".project_cache"
    THUMBNAILS_FOLDER = "thumbnails"
    CACHE_INDEX_FILE = "thumbcache_index.json"
    THUMBNAIL_SIZE = 24  # 24x24 pixels
    
    def __init__(self, project_path: str):
        self.project_path = Path(project_path)
        self.cache_path = self.project_path / self.CACHE_FOLDER
        self.thumbnails_path = self.cache_path / self.THUMBNAILS_FOLDER
        self.index_path = self.cache_path / self.CACHE_INDEX_FILE
        
        # Ensure cache directories exist
        self.thumbnails_path.mkdir(parents=True, exist_ok=True)
        
        # Load cache index
        self.cache_index = self._load_cache_index()
    
    def get_thumbnail(self, resource_type: str, resource_id: str, image_path: str) -> Optional[QIcon]:
        """
        Get cached thumbnail if available and up-to-date, otherwise return None.
        Returns QIcon if cached thumbnail is valid, None if needs regeneration.
        """
        if not image_path or not os.path.exists(image_path):
            return None
        
        # Get cache key
        cache_key = self._get_cache_key(resource_type, resource_id, image_path)
        
        # Check if thumbnail exists in cache
        cached_thumbnail_path = self.thumbnails_path / f"{cache_key}.png"
        
        if not cached_thumbnail_path.exists():
            return None
        
        # Check if cache entry exists in index
        if cache_key not in self.cache_index:
            return None
        
        cache_entry = self.cache_index[cache_key]
        
        # Check if source file has changed
        try:
            current_mtime = os.path.getmtime(image_path)
            current_size = os.path.getsize(image_path)
            
            if (cache_entry.get("mtime") != current_mtime or 
                cache_entry.get("size") != current_size):
                # Source file changed, cache is invalid
                debug(f"Thumbnail cache invalid for {resource_type}/{resource_id}: file changed")
                return None
            
            # Load cached thumbnail
            pixmap = QPixmap(str(cached_thumbnail_path))
            if not pixmap.isNull():
                icon = QIcon(pixmap)
                debug(f"Loaded cached thumbnail for {resource_type}/{resource_id}")
                return icon
            
        except Exception as e:
            debug(f"Error loading cached thumbnail: {e}")
            return None
        
        return None
    
    def save_thumbnail(self, resource_type: str, resource_id: str, image_path: str, icon: QIcon) -> bool:
        """
        Save thumbnail to cache.
        """
        if not image_path or not os.path.exists(image_path):
            return False
        
        try:
            # Get cache key
            cache_key = self._get_cache_key(resource_type, resource_id, image_path)
            
            # Get pixmap from icon
            pixmap = icon.pixmap(self.THUMBNAIL_SIZE, self.THUMBNAIL_SIZE)
            if pixmap.isNull():
                return False
            
            # Save thumbnail image
            cached_thumbnail_path = self.thumbnails_path / f"{cache_key}.png"
            pixmap.save(str(cached_thumbnail_path), "PNG")
            
            # Update cache index
            self.cache_index[cache_key] = {
                "resource_type": resource_type,
                "resource_id": resource_id,
                "image_path": str(image_path),
                "mtime": os.path.getmtime(image_path),
                "size": os.path.getsize(image_path)
            }
            
            # Save cache index
            self._save_cache_index()
            
            debug(f"Cached thumbnail for {resource_type}/{resource_id}")
            return True
            
        except Exception as e:
            debug(f"Error saving thumbnail to cache: {e}")
            return False
    
    def clear_cache(self):
        """Clear all cached thumbnails"""
        try:
            # Delete all thumbnail files
            for thumbnail_file in self.thumbnails_path.glob("*.png"):
                thumbnail_file.unlink()
            
            # Clear index
            self.cache_index = {}
            self._save_cache_index()
            
            debug("Thumbnail cache cleared")
            
        except Exception as e:
            debug(f"Error clearing thumbnail cache: {e}")
    
    def cleanup_orphaned_cache(self, valid_resources: dict):
        """
        Remove cached thumbnails for resources that no longer exist.
        valid_resources: {resource_type: {resource_id: resource_data}}
        """
        try:
            # Build set of valid cache keys
            valid_keys = set()
            for resource_type, resources in valid_resources.items():
                for resource_id, resource_data in resources.items():
                    # Try to determine image path for this resource
                    image_path = self._get_resource_image_path(resource_type, resource_data)
                    if image_path:
                        cache_key = self._get_cache_key(resource_type, resource_id, image_path)
                        valid_keys.add(cache_key)
            
            # Remove orphaned cache entries
            keys_to_remove = []
            for cache_key in self.cache_index.keys():
                if cache_key not in valid_keys:
                    keys_to_remove.append(cache_key)
            
            for cache_key in keys_to_remove:
                # Delete thumbnail file
                cached_thumbnail_path = self.thumbnails_path / f"{cache_key}.png"
                if cached_thumbnail_path.exists():
                    cached_thumbnail_path.unlink()
                
                # Remove from index
                del self.cache_index[cache_key]
            
            if keys_to_remove:
                self._save_cache_index()
                debug(f"Cleaned up {len(keys_to_remove)} orphaned thumbnail cache entries")
            
        except Exception as e:
            debug(f"Error cleaning up orphaned cache: {e}")
    
    def _get_cache_key(self, resource_type: str, resource_id: str, image_path: str) -> str:
        """Generate a unique cache key for a resource thumbnail"""
        # Use hash of resource type, ID, and image path
        key_string = f"{resource_type}:{resource_id}:{image_path}"
        return hashlib.md5(key_string.encode('utf-8')).hexdigest()
    
    def _get_resource_image_path(self, resource_type: str, resource_data: dict) -> Optional[str]:
        """Get the image path for a resource (for cache key generation)"""
        # This is a simplified version - actual implementation would need
        # to resolve paths similar to ThumbnailLoader._load_thumbnail
        # For now, return None to skip cleanup for complex resources
        return None
    
    def _load_cache_index(self) -> dict:
        """Load cache index from disk"""
        if not self.index_path.exists():
            return {}
        
        try:
            with open(self.index_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception as e:
            debug(f"Error loading cache index: {e}")
            return {}
    
    def _save_cache_index(self):
        """Save cache index to disk"""
        try:
            with open(self.index_path, 'w', encoding='utf-8') as f:
                json.dump(self.cache_index, f, indent=2, ensure_ascii=False)
        except Exception as e:
            debug(f"Error saving cache index: {e}")

