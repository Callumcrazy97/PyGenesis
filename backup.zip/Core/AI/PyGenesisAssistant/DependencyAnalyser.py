#!/usr/bin/env python3
"""
Python Code Flow Visualizer
Analyzes Python files to show:
- What functions/classes are created in each script
- What functions/classes are imported/called by each script  
- Visual workflow showing dependencies and usage patterns
"""

import os
import ast
import sys
import tkinter as tk
from tkinter import ttk, filedialog, messagebox, scrolledtext
from pathlib import Path
from typing import Dict, List, Set, Tuple, Optional
from collections import defaultdict
import threading
import json

class CodeFlowVisualizerGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Python Code Flow Visualizer")
        self.root.geometry("1400x900")
        
        # Analysis data
        self.analyzer = None
        self.selected_files = []
        self.analysis_running = False
        
        # Create GUI
        self.create_widgets()
        
    def create_widgets(self):
        """Create the GUI widgets"""
        # Main frame
        main_frame = ttk.Frame(self.root, padding="10")
        main_frame.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        
        # Configure grid weights
        self.root.columnconfigure(0, weight=1)
        self.root.rowconfigure(0, weight=1)
        main_frame.columnconfigure(1, weight=1)
        main_frame.rowconfigure(3, weight=1)
        
        # Title
        title_label = ttk.Label(main_frame, text="🔄 Python Code Flow Visualizer", 
                               font=('Arial', 16, 'bold'))
        title_label.grid(row=0, column=0, columnspan=3, pady=(0, 20))
        
        # File Selection Section
        selection_frame = ttk.LabelFrame(main_frame, text="📁 File Selection", padding="10")
        selection_frame.grid(row=1, column=0, columnspan=3, sticky=(tk.W, tk.E), pady=(0, 10))
        selection_frame.columnconfigure(1, weight=1)
        
        # Folder selection
        ttk.Label(selection_frame, text="Root Folder:").grid(row=0, column=0, sticky=tk.W)
        self.folder_var = tk.StringVar(value=os.getcwd())
        folder_entry = ttk.Entry(selection_frame, textvariable=self.folder_var, width=50)
        folder_entry.grid(row=0, column=1, sticky=(tk.W, tk.E), padx=(5, 5))
        ttk.Button(selection_frame, text="Browse", 
                  command=self.browse_folder).grid(row=0, column=2, padx=(5, 0))
        
        # File selection listbox
        files_frame = ttk.Frame(selection_frame)
        files_frame.grid(row=1, column=0, columnspan=3, sticky=(tk.W, tk.E, tk.N, tk.S), pady=(10, 0))
        files_frame.columnconfigure(0, weight=1)
        files_frame.rowconfigure(0, weight=1)
        
        ttk.Label(files_frame, text="Python Files:").grid(row=0, column=0, sticky=tk.W)
        
        # Listbox with scrollbar
        listbox_frame = ttk.Frame(files_frame)
        listbox_frame.grid(row=1, column=0, columnspan=3, sticky=(tk.W, tk.E, tk.N, tk.S), pady=(5, 0))
        listbox_frame.columnconfigure(0, weight=1)
        listbox_frame.rowconfigure(0, weight=1)
        
        self.files_listbox = tk.Listbox(listbox_frame, selectmode=tk.EXTENDED, height=6)
        scrollbar = ttk.Scrollbar(listbox_frame, orient=tk.VERTICAL, command=self.files_listbox.yview)
        self.files_listbox.configure(yscrollcommand=scrollbar.set)
        
        self.files_listbox.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        scrollbar.grid(row=0, column=1, sticky=(tk.N, tk.S))
        
        # File selection buttons
        button_frame = ttk.Frame(files_frame)
        button_frame.grid(row=2, column=0, columnspan=3, pady=(5, 0))
        
        ttk.Button(button_frame, text="Refresh Files", 
                  command=self.refresh_files).grid(row=0, column=0, padx=(0, 5))
        ttk.Button(button_frame, text="Select All", 
                  command=self.select_all_files).grid(row=0, column=1, padx=(0, 5))
        ttk.Button(button_frame, text="Select None", 
                  command=self.select_no_files).grid(row=0, column=2, padx=(0, 5))
        
        # Analysis Section
        analysis_frame = ttk.Frame(main_frame)
        analysis_frame.grid(row=2, column=0, columnspan=3, sticky=(tk.W, tk.E), pady=(0, 10))
        
        self.analyze_button = ttk.Button(analysis_frame, text="🔄 Analyze Code Flow", 
                                        command=self.start_analysis, style='Accent.TButton')
        self.analyze_button.grid(row=0, column=0, padx=(0, 10))
        
        self.progress_var = tk.StringVar(value="Ready to analyze")
        self.progress_label = ttk.Label(analysis_frame, textvariable=self.progress_var)
        self.progress_label.grid(row=0, column=1, sticky=tk.W)
        
        self.progress_bar = ttk.Progressbar(analysis_frame, mode='indeterminate')
        self.progress_bar.grid(row=0, column=2, sticky=(tk.W, tk.E), padx=(10, 0))
        analysis_frame.columnconfigure(2, weight=1)
        
        # Results Section with Notebook
        self.results_notebook = ttk.Notebook(main_frame)
        self.results_notebook.grid(row=3, column=0, columnspan=3, sticky=(tk.W, tk.E, tk.N, tk.S), pady=(0, 10))
        
        # Create tabs
        self.create_overview_tab()
        self.create_definitions_tab()
        self.create_dependencies_tab()
        self.create_workflow_tab()
        self.create_unused_tab()
        
        # Initialize
        self.refresh_files()
    
    def create_overview_tab(self):
        """Create overview tab"""
        self.overview_frame = ttk.Frame(self.results_notebook)
        self.results_notebook.add(self.overview_frame, text="📊 Overview")
        
        self.overview_text = scrolledtext.ScrolledText(self.overview_frame, wrap=tk.WORD, height=20)
        self.overview_text.pack(fill="both", expand=True, padx=10, pady=10)
        
        # Configure tags
        self.overview_text.tag_configure("header", font=('Arial', 12, 'bold'), foreground="darkblue")
        self.overview_text.tag_configure("subheader", font=('Arial', 10, 'bold'), foreground="darkgreen")
        self.overview_text.tag_configure("file", font=('Arial', 9, 'bold'), foreground="purple")
        self.overview_text.tag_configure("function", foreground="blue")
        self.overview_text.tag_configure("class", foreground="red")
        self.overview_text.tag_configure("variable", foreground="orange")
    
    def create_definitions_tab(self):
        """Create definitions tab"""
        self.definitions_frame = ttk.Frame(self.results_notebook)
        self.results_notebook.add(self.definitions_frame, text="🏗️ Definitions")
        
        self.definitions_text = scrolledtext.ScrolledText(self.definitions_frame, wrap=tk.WORD, height=20)
        self.definitions_text.pack(fill="both", expand=True, padx=10, pady=10)
        
        # Configure tags
        self.definitions_text.tag_configure("file", font=('Arial', 10, 'bold'), foreground="darkgreen")
        self.definitions_text.tag_configure("function", foreground="blue")
        self.definitions_text.tag_configure("class", foreground="red")
        self.definitions_text.tag_configure("variable", foreground="orange")
    
    def create_dependencies_tab(self):
        """Create dependencies tab"""
        self.dependencies_frame = ttk.Frame(self.results_notebook)
        self.results_notebook.add(self.dependencies_frame, text="🔗 Dependencies")
        
        self.dependencies_text = scrolledtext.ScrolledText(self.dependencies_frame, wrap=tk.WORD, height=20)
        self.dependencies_text.pack(fill="both", expand=True, padx=10, pady=10)
        
        # Configure tags
        self.dependencies_text.tag_configure("file", font=('Arial', 10, 'bold'), foreground="darkgreen")
        self.dependencies_text.tag_configure("import", foreground="blue")
        self.dependencies_text.tag_configure("call", foreground="purple")
        self.dependencies_text.tag_configure("missing", foreground="red")
    
    def create_workflow_tab(self):
        """Create workflow visualization tab"""
        self.workflow_frame = ttk.Frame(self.results_notebook)
        self.results_notebook.add(self.workflow_frame, text="🔄 Workflow")
        
        # Workflow controls
        controls_frame = ttk.Frame(self.workflow_frame)
        controls_frame.pack(fill="x", padx=10, pady=(10, 5))
        
        ttk.Label(controls_frame, text="Show workflow for:").pack(side="left")
        self.workflow_filter_var = tk.StringVar()
        self.workflow_filter_combo = ttk.Combobox(controls_frame, textvariable=self.workflow_filter_var,
                                                 width=30, state="readonly")
        self.workflow_filter_combo.pack(side="left", padx=(5, 10))
        self.workflow_filter_combo.bind('<<ComboboxSelected>>', self.update_workflow)
        
        ttk.Button(controls_frame, text="Show All", 
                  command=self.show_all_workflow).pack(side="left", padx=(0, 5))
        ttk.Button(controls_frame, text="Export Diagram", 
                  command=self.export_workflow).pack(side="left")
        
        # Workflow display
        self.workflow_text = scrolledtext.ScrolledText(self.workflow_frame, wrap=tk.WORD, height=20)
        self.workflow_text.pack(fill="both", expand=True, padx=10, pady=(5, 10))
        
        # Configure tags
        self.workflow_text.tag_configure("creator", font=('Arial', 10, 'bold'), foreground="darkgreen")
        self.workflow_text.tag_configure("caller", font=('Arial', 10), foreground="blue")
        self.workflow_text.tag_configure("function", font=('Arial', 10, 'bold'), foreground="red")
        self.workflow_text.tag_configure("arrow", font=('Arial', 10), foreground="gray")
    
    def create_unused_tab(self):
        """Create unused code tab"""
        self.unused_frame = ttk.Frame(self.results_notebook)
        self.results_notebook.add(self.unused_frame, text="🗑️ Unused Code")
        
        self.unused_text = scrolledtext.ScrolledText(self.unused_frame, wrap=tk.WORD, height=20)
        self.unused_text.pack(fill="both", expand=True, padx=10, pady=10)
        
        # Configure tags
        self.unused_text.tag_configure("file", font=('Arial', 10, 'bold'), foreground="darkgreen")
        self.unused_text.tag_configure("unused", foreground="red")
        self.unused_text.tag_configure("info", foreground="blue", font=('Arial', 9, 'italic'))
    
    def browse_folder(self):
        """Browse for folder"""
        folder = filedialog.askdirectory(initialdir=self.folder_var.get())
        if folder:
            self.folder_var.set(folder)
            self.refresh_files()
    
    def refresh_files(self):
        """Refresh the list of Python files"""
        self.files_listbox.delete(0, tk.END)
        
        root_path = Path(self.folder_var.get())
        if not root_path.exists():
            return
        
        try:
            python_files = []
            for file_path in root_path.rglob('*.py'):
                # Skip __pycache__ directories
                if '__pycache__' not in str(file_path):
                    rel_path = file_path.relative_to(root_path)
                    python_files.append((str(rel_path), file_path))
            
            # Sort files
            python_files.sort()
            
            for rel_path, full_path in python_files:
                self.files_listbox.insert(tk.END, rel_path)
            
            # Select all by default
            self.select_all_files()
            
        except Exception as e:
            messagebox.showerror("Error", f"Error refreshing files: {e}")
    
    def select_all_files(self):
        """Select all files in the listbox"""
        self.files_listbox.select_set(0, tk.END)
    
    def select_no_files(self):
        """Deselect all files"""
        self.files_listbox.select_clear(0, tk.END)
    
    def start_analysis(self):
        """Start the analysis in a separate thread"""
        if self.analysis_running:
            return
        
        selected_indices = self.files_listbox.curselection()
        if not selected_indices:
            messagebox.showwarning("Warning", "Please select at least one file to analyze")
            return
        
        self.analysis_running = True
        self.analyze_button.config(state='disabled')
        self.progress_bar.start()
        self.clear_results()
        
        # Start analysis thread
        thread = threading.Thread(target=self.run_analysis)
        thread.daemon = True
        thread.start()
    
    def run_analysis(self):
        """Run the analysis (called in separate thread)"""
        try:
            # Get selected files
            selected_indices = self.files_listbox.curselection()
            root_path = Path(self.folder_var.get())
            
            selected_files = []
            for i in selected_indices:
                rel_path = self.files_listbox.get(i)
                full_path = root_path / rel_path
                selected_files.append(full_path)
            
            # Initialize analyzer
            self.analyzer = CodeFlowAnalyzer(
                root_path=root_path,
                selected_files=selected_files,
                progress_callback=self.update_progress
            )
            
            # Run analysis
            self.analyzer.analyze()
            
            # Update UI in main thread
            self.root.after(0, self.analysis_complete)
            
        except Exception as e:
            self.root.after(0, self.analysis_error, str(e))
    
    def update_progress(self, message):
        """Update progress message"""
        self.root.after(0, lambda: self.progress_var.set(message))
    
    def analysis_complete(self):
        """Handle analysis completion"""
        self.analysis_running = False
        self.analyze_button.config(state='normal')
        self.progress_bar.stop()
        self.progress_var.set("Analysis complete")
        
        # Display results
        self.display_results()
    
    def analysis_error(self, error_msg):
        """Handle analysis error"""
        self.analysis_running = False
        self.analyze_button.config(state='normal')
        self.progress_bar.stop()
        self.progress_var.set("Analysis failed")
        messagebox.showerror("Analysis Error", f"Analysis failed: {error_msg}")
    
    def display_results(self):
        """Display all analysis results"""
        if not self.analyzer:
            return
        
        self.display_overview()
        self.display_definitions()
        self.display_dependencies()
        self.display_workflow()
        self.display_unused()
        
        # Update workflow filter options
        functions = list(self.analyzer.function_definitions.keys())
        classes = list(self.analyzer.class_definitions.keys())
        all_items = [""] + functions + classes
        self.workflow_filter_combo['values'] = all_items
    
    def display_overview(self):
        """Display overview of the analysis"""
        self.overview_text.delete(1.0, tk.END)
        
        # Header
        header = "🔄 CODE FLOW ANALYSIS OVERVIEW\n"
        header += "=" * 50 + "\n\n"
        self.overview_text.insert(tk.END, header, "header")
        
        # Statistics
        stats = f"📊 STATISTICS\n"
        stats += f"Files analyzed: {len(self.analyzer.selected_files)}\n"
        stats += f"Functions defined: {len(self.analyzer.function_definitions)}\n"
        stats += f"Classes defined: {len(self.analyzer.class_definitions)}\n"
        stats += f"Variables defined: {len(self.analyzer.variable_definitions)}\n"
        stats += f"Function calls found: {len(self.analyzer.function_calls)}\n"
        stats += f"Imports found: {len(self.analyzer.imports)}\n\n"
        
        self.overview_text.insert(tk.END, stats, "subheader")
        
        # File breakdown
        self.overview_text.insert(tk.END, "📁 FILE BREAKDOWN\n", "subheader")
        
        for file_path in self.analyzer.selected_files:
            rel_path = file_path.relative_to(self.analyzer.root_path)
            self.overview_text.insert(tk.END, f"\n📄 {rel_path}\n", "file")
            
            # Functions in this file
            funcs = [name for name, data in self.analyzer.function_definitions.items() 
                    if data['file'] == file_path]
            if funcs:
                self.overview_text.insert(tk.END, f"  Functions: {', '.join(funcs)}\n", "function")
            
            # Classes in this file
            classes = [name for name, data in self.analyzer.class_definitions.items() 
                      if data['file'] == file_path]
            if classes:
                self.overview_text.insert(tk.END, f"  Classes: {', '.join(classes)}\n", "class")
            
            # Imports in this file
            imports = [imp for imp, data in self.analyzer.imports.items() 
                      if data['file'] == file_path]
            if imports:
                self.overview_text.insert(tk.END, f"  Imports: {', '.join(imports[:5])}", "variable")
                if len(imports) > 5:
                    self.overview_text.insert(tk.END, f" ... and {len(imports)-5} more", "variable")
                self.overview_text.insert(tk.END, "\n")
    
    def display_definitions(self):
        """Display all definitions by file"""
        self.definitions_text.delete(1.0, tk.END)
        
        self.definitions_text.insert(tk.END, "🏗️ ALL DEFINITIONS BY FILE\n", "header")
        self.definitions_text.insert(tk.END, "=" * 40 + "\n\n")
        
        for file_path in self.analyzer.selected_files:
            rel_path = file_path.relative_to(self.analyzer.root_path)
            self.definitions_text.insert(tk.END, f"📄 {rel_path}\n", "file")
            
            # Functions
            funcs = [(name, data) for name, data in self.analyzer.function_definitions.items() 
                    if data['file'] == file_path]
            if funcs:
                self.definitions_text.insert(tk.END, "  Functions:\n")
                for name, data in sorted(funcs):
                    line_info = f" (line {data['line']})" if 'line' in data else ""
                    self.definitions_text.insert(tk.END, f"    • {name}{line_info}\n", "function")
            
            # Classes
            classes = [(name, data) for name, data in self.analyzer.class_definitions.items() 
                      if data['file'] == file_path]
            if classes:
                self.definitions_text.insert(tk.END, "  Classes:\n")
                for name, data in sorted(classes):
                    line_info = f" (line {data['line']})" if 'line' in data else ""
                    self.definitions_text.insert(tk.END, f"    • {name}{line_info}\n", "class")
                    
                    # Show methods
                    if 'methods' in data:
                        for method in data['methods']:
                            self.definitions_text.insert(tk.END, f"      - {method}\n", "function")
            
            # Variables
            vars = [(name, data) for name, data in self.analyzer.variable_definitions.items() 
                   if data['file'] == file_path]
            if vars:
                self.definitions_text.insert(tk.END, "  Variables:\n")
                for name, data in sorted(vars):
                    line_info = f" (line {data['line']})" if 'line' in data else ""
                    self.definitions_text.insert(tk.END, f"    • {name}{line_info}\n", "variable")
            
            self.definitions_text.insert(tk.END, "\n")
    
    def display_dependencies(self):
        """Display dependencies and function calls"""
        self.dependencies_text.delete(1.0, tk.END)
        
        self.dependencies_text.insert(tk.END, "🔗 DEPENDENCIES AND CALLS\n", "header")
        self.dependencies_text.insert(tk.END, "=" * 40 + "\n\n")
        
        for file_path in self.analyzer.selected_files:
            rel_path = file_path.relative_to(self.analyzer.root_path)
            self.dependencies_text.insert(tk.END, f"📄 {rel_path}\n", "file")
            
            # Imports
            imports = [(name, data) for name, data in self.analyzer.imports.items() 
                      if data['file'] == file_path]
            if imports:
                self.dependencies_text.insert(tk.END, "  Imports:\n")
                for name, data in sorted(imports):
                    import_type = data.get('type', 'unknown')
                    self.dependencies_text.insert(tk.END, f"    📦 {name} ({import_type})\n", "import")
            
            # Function calls
            calls = [(name, data) for name, data in self.analyzer.function_calls.items() 
                    if data['file'] == file_path]
            if calls:
                self.dependencies_text.insert(tk.END, "  Function Calls:\n")
                for name, data in sorted(calls):
                    line_info = f" (line {data['line']})" if 'line' in data else ""
                    
                    # Check if function is defined locally
                    if name in self.analyzer.function_definitions:
                        def_file = self.analyzer.function_definitions[name]['file']
                        def_rel_path = def_file.relative_to(self.analyzer.root_path)
                        self.dependencies_text.insert(tk.END, f"    📞 {name}{line_info} → defined in {def_rel_path}\n", "call")
                    else:
                        self.dependencies_text.insert(tk.END, f"    📞 {name}{line_info} → external/unknown\n", "missing")
            
            self.dependencies_text.insert(tk.END, "\n")
    
    def display_workflow(self):
        """Display workflow visualization"""
        self.show_all_workflow()
    
    def show_all_workflow(self):
        """Show complete workflow"""
        self.workflow_text.delete(1.0, tk.END)
        
        self.workflow_text.insert(tk.END, "🔄 COMPLETE WORKFLOW\n", "header")
        self.workflow_text.insert(tk.END, "=" * 40 + "\n\n")
        
        # Show all function workflows
        for func_name, func_data in self.analyzer.function_definitions.items():
            self._display_function_workflow(func_name)
    
    def update_workflow(self, event=None):
        """Update workflow display based on filter"""
        selected = self.workflow_filter_var.get()
        if not selected:
            self.show_all_workflow()
            return
        
        self.workflow_text.delete(1.0, tk.END)
        self._display_function_workflow(selected)
    
    def _display_function_workflow(self, func_name):
        """Display workflow for a specific function"""
        if func_name not in self.analyzer.function_definitions:
            return
        
        func_data = self.analyzer.function_definitions[func_name]
        file_path = func_data['file']
        rel_path = file_path.relative_to(self.analyzer.root_path)
        
        # Function definition
        self.workflow_text.insert(tk.END, f"🏗️ FUNCTION: {func_name}\n", "function")
        self.workflow_text.insert(tk.END, f"   📄 Created in: {rel_path} (line {func_data.get('line', '?')})\n", "creator")
        
        # Find who calls this function
        callers = []
        for call_name, call_data in self.analyzer.function_calls.items():
            if call_name == func_name:
                caller_file = call_data['file']
                caller_rel_path = caller_file.relative_to(self.analyzer.root_path)
                callers.append((caller_rel_path, call_data.get('line', '?')))
        
        if callers:
            self.workflow_text.insert(tk.END, f"   📞 Called by:\n", "caller")
            for caller_file, line in callers:
                self.workflow_text.insert(tk.END, f"      • {caller_file} (line {line})\n", "caller")
        else:
            self.workflow_text.insert(tk.END, f"   ⚠️  Never called (potentially unused)\n", "missing")
        
        # Show what this function calls
        calls_made = []
        for call_name, call_data in self.analyzer.function_calls.items():
            if call_data['file'] == file_path:
                calls_made.append((call_name, call_data.get('line', '?')))
        
        if calls_made:
            self.workflow_text.insert(tk.END, f"   🔗 This function calls:\n", "arrow")
            for called_func, line in calls_made:
                if called_func in self.analyzer.function_definitions:
                    def_file = self.analyzer.function_definitions[called_func]['file']
                    def_rel_path = def_file.relative_to(self.analyzer.root_path)
                    self.workflow_text.insert(tk.END, f"      • {called_func} → {def_rel_path}\n", "call")
                else:
                    self.workflow_text.insert(tk.END, f"      • {called_func} → external/unknown\n", "missing")
        
        self.workflow_text.insert(tk.END, "\n")
    
    def display_unused(self):
        """Display potentially unused code"""
        self.unused_text.delete(1.0, tk.END)
        
        self.unused_text.insert(tk.END, "🗑️ POTENTIALLY UNUSED CODE\n", "header")
        self.unused_text.insert(tk.END, "=" * 40 + "\n\n")
        
        # Find unused functions
        called_functions = set(self.analyzer.function_calls.keys())
        defined_functions = set(self.analyzer.function_definitions.keys())
        unused_functions = defined_functions - called_functions
        
        if unused_functions:
            self.unused_text.insert(tk.END, "📋 Unused Functions:\n", "subheader")
            for func_name in sorted(unused_functions):
                func_data = self.analyzer.function_definitions[func_name]
                file_path = func_data['file']
                rel_path = file_path.relative_to(self.analyzer.root_path)
                line = func_data.get('line', '?')
                self.unused_text.insert(tk.END, f"  • {func_name} in {rel_path} (line {line})\n", "unused")
        else:
            self.unused_text.insert(tk.END, "✅ All functions are being used!\n", "info")
        
        self.unused_text.insert(tk.END, "\n")
        
        # Find unused classes
        # (This is more complex as classes can be instantiated in various ways)
        self.unused_text.insert(tk.END, "📋 Defined Classes:\n", "subheader")
        for class_name, class_data in sorted(self.analyzer.class_definitions.items()):
            file_path = class_data['file']
            rel_path = file_path.relative_to(self.analyzer.root_path)
            line = class_data.get('line', '?')
            self.unused_text.insert(tk.END, f"  • {class_name} in {rel_path} (line {line})\n", "class")
            self.unused_text.insert(tk.END, f"    Note: Check manually if instantiated\n", "info")
    
    def export_workflow(self):
        """Export workflow to text file"""
        if not self.analyzer:
            messagebox.showwarning("Warning", "No analysis results to export")
            return
        
        filename = filedialog.asksaveasfilename(
            defaultextension=".txt",
            filetypes=[("Text files", "*.txt"), ("JSON files", "*.json"), ("All files", "*.*")],
            title="Export Workflow"
        )
        
        if filename:
            try:
                if filename.endswith('.json'):
                    self._export_json(filename)
                else:
                    self._export_text(filename)
                messagebox.showinfo("Success", f"Workflow exported to {filename}")
            except Exception as e:
                messagebox.showerror("Error", f"Error exporting workflow: {e}")
    
    def _export_text(self, filename):
        """Export workflow as text file"""
        with open(filename, 'w', encoding='utf-8') as f:
            f.write("PYTHON CODE FLOW ANALYSIS\n")
            f.write("=" * 50 + "\n\n")
            
            # Overview
            f.write("OVERVIEW:\n")
            f.write(f"Files analyzed: {len(self.analyzer.selected_files)}\n")
            f.write(f"Functions defined: {len(self.analyzer.function_definitions)}\n")
            f.write(f"Classes defined: {len(self.analyzer.class_definitions)}\n\n")
            
            # Workflow
            f.write("WORKFLOW:\n")
            f.write("-" * 20 + "\n")
            
            for func_name, func_data in self.analyzer.function_definitions.items():
                file_path = func_data['file']
                rel_path = file_path.relative_to(self.analyzer.root_path)
                
                f.write(f"\nFunction: {func_name}\n")
                f.write(f"  Created in: {rel_path} (line {func_data.get('line', '?')})\n")
                
                # Find callers
                callers = []
                for call_name, call_data in self.analyzer.function_calls.items():
                    if call_name == func_name:
                        caller_file = call_data['file']
                        caller_rel_path = caller_file.relative_to(self.analyzer.root_path)
                        callers.append((caller_rel_path, call_data.get('line', '?')))
                
                if callers:
                    f.write("  Called by:\n")
                    for caller_file, line in callers:
                        f.write(f"    - {caller_file} (line {line})\n")
                else:
                    f.write("  Never called (potentially unused)\n")
    
    def _export_json(self, filename):
        """Export workflow as JSON file"""
        data = {
            'overview': {
                'files_analyzed': len(self.analyzer.selected_files),
                'functions_defined': len(self.analyzer.function_definitions),
                'classes_defined': len(self.analyzer.class_definitions),
                'function_calls': len(self.analyzer.function_calls)
            },
            'definitions': {
                'functions': {name: {
                    'file': str(data['file'].relative_to(self.analyzer.root_path)),
                    'line': data.get('line', 0)
                } for name, data in self.analyzer.function_definitions.items()},
                'classes': {name: {
                    'file': str(data['file'].relative_to(self.analyzer.root_path)),
                    'line': data.get('line', 0),
                    'methods': data.get('methods', [])
                } for name, data in self.analyzer.class_definitions.items()}
            },
            'calls': {name: {
                'file': str(data['file'].relative_to(self.analyzer.root_path)),
                'line': data.get('line', 0)
            } for name, data in self.analyzer.function_calls.items()},
            'workflow': {}
        }
        
        # Build workflow data
        for func_name, func_data in self.analyzer.function_definitions.items():
            callers = []
            for call_name, call_data in self.analyzer.function_calls.items():
                if call_name == func_name:
                    caller_file = call_data['file']
                    caller_rel_path = str(caller_file.relative_to(self.analyzer.root_path))
                    callers.append({
                        'file': caller_rel_path,
                        'line': call_data.get('line', 0)
                    })
            
            data['workflow'][func_name] = {
                'definition': {
                    'file': str(func_data['file'].relative_to(self.analyzer.root_path)),
                    'line': func_data.get('line', 0)
                },
                'called_by': callers
            }
        
        with open(filename, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
    
    def clear_results(self):
        """Clear all results"""
        for text_widget in [self.overview_text, self.definitions_text, 
                           self.dependencies_text, self.workflow_text, self.unused_text]:
            text_widget.delete(1.0, tk.END)
        
        # Clear workflow filter
        self.workflow_filter_combo['values'] = []
        self.workflow_filter_var.set("")


class CodeFlowAnalyzer:
    """Core analyzer for code flow and dependencies"""
    
    def __init__(self, root_path, selected_files, progress_callback=None):
        self.root_path = Path(root_path)
        self.selected_files = selected_files
        self.progress_callback = progress_callback
        
        # Analysis results
        self.function_definitions = {}  # func_name -> {file, line, args}
        self.class_definitions = {}     # class_name -> {file, line, methods}
        self.variable_definitions = {}  # var_name -> {file, line}
        self.function_calls = {}        # func_name -> {file, line}
        self.imports = {}              # module_name -> {file, type, items}
        
    def analyze(self):
        """Main analysis function"""
        self._update_progress("Starting code flow analysis...")
        
        # Step 1: Parse all files and extract definitions
        self._update_progress("Extracting definitions...")
        self._extract_definitions()
        
        # Step 2: Find function calls and imports
        self._update_progress("Analyzing function calls and imports...")
        self._analyze_calls_and_imports()
        
        self._update_progress("Analysis complete")
    
    def _update_progress(self, message):
        """Update progress if callback provided"""
        if self.progress_callback:
            self.progress_callback(message)
    
    def _extract_definitions(self):
        """Extract all function, class, and variable definitions"""
        for i, file_path in enumerate(self.selected_files):
            self._update_progress(f"Parsing {file_path.name} ({i+1}/{len(self.selected_files)})")
            
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    content = f.read()
                
                tree = ast.parse(content, filename=str(file_path))
                self._extract_from_ast(tree, file_path)
                
            except Exception as e:
                print(f"Error parsing {file_path}: {e}")
    
    def _extract_from_ast(self, tree, file_path):
        """Extract definitions from AST"""
        for node in ast.walk(tree):
            if isinstance(node, ast.FunctionDef):
                # Extract function definition
                func_name = node.name
                args = [arg.arg for arg in node.args.args]
                
                self.function_definitions[func_name] = {
                    'file': file_path,
                    'line': node.lineno,
                    'args': args,
                    'is_method': self._is_method(tree, node)
                }
            
            elif isinstance(node, ast.ClassDef):
                # Extract class definition
                class_name = node.name
                methods = []
                
                # Find methods in this class
                for class_node in node.body:
                    if isinstance(class_node, ast.FunctionDef):
                        methods.append(class_node.name)
                
                self.class_definitions[class_name] = {
                    'file': file_path,
                    'line': node.lineno,
                    'methods': methods
                }
            
            elif isinstance(node, ast.Assign):
                # Extract variable assignments (top-level only)
                if self._is_toplevel_assignment(tree, node):
                    for target in node.targets:
                        if isinstance(target, ast.Name):
                            var_name = target.id
                            self.variable_definitions[var_name] = {
                                'file': file_path,
                                'line': node.lineno
                            }
    
    def _is_method(self, tree, func_node):
        """Check if a function is a method (inside a class)"""
        for node in ast.walk(tree):
            if isinstance(node, ast.ClassDef):
                if func_node in node.body:
                    return True
        return False
    
    def _is_toplevel_assignment(self, tree, assign_node):
        """Check if assignment is at top level (not inside function/class)"""
        # This is a simplified check - in practice, you might want more sophisticated logic
        for node in ast.walk(tree):
            if isinstance(node, (ast.FunctionDef, ast.ClassDef)):
                if assign_node.lineno > node.lineno and hasattr(node, 'end_lineno'):
                    if assign_node.lineno <= node.end_lineno:
                        return False
        return True
    
    def _analyze_calls_and_imports(self):
        """Analyze function calls and imports in all files"""
        for i, file_path in enumerate(self.selected_files):
            self._update_progress(f"Analyzing calls in {file_path.name} ({i+1}/{len(self.selected_files)})")
            
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    content = f.read()
                
                tree = ast.parse(content, filename=str(file_path))
                self._analyze_ast_calls_imports(tree, file_path)
                
            except Exception as e:
                print(f"Error analyzing {file_path}: {e}")
    
    def _analyze_ast_calls_imports(self, tree, file_path):
        """Analyze calls and imports from AST"""
        for node in ast.walk(tree):
            if isinstance(node, ast.Call):
                # Function call
                func_name = self._get_function_name(node.func)
                if func_name:
                    # Store the call (we might have multiple calls to same function)
                    call_key = f"{func_name}_{file_path}_{node.lineno}"
                    self.function_calls[call_key] = {
                        'function': func_name,
                        'file': file_path,
                        'line': node.lineno
                    }
            
            elif isinstance(node, ast.Import):
                # Import statement
                for alias in node.names:
                    module_name = alias.name
                    import_alias = alias.asname if alias.asname else alias.name
                    
                    import_key = f"{module_name}_{file_path}"
                    self.imports[import_key] = {
                        'module': module_name,
                        'file': file_path,
                        'line': node.lineno,
                        'type': 'import',
                        'alias': import_alias
                    }
            
            elif isinstance(node, ast.ImportFrom):
                # From import statement
                module_name = node.module if node.module else ''
                items = []
                
                for alias in node.names:
                    item_name = alias.name
                    item_alias = alias.asname if alias.asname else alias.name
                    items.append((item_name, item_alias))
                
                import_key = f"{module_name}_{file_path}_{node.lineno}"
                self.imports[import_key] = {
                    'module': module_name,
                    'file': file_path,
                    'line': node.lineno,
                    'type': 'from',
                    'items': items,
                    'level': node.level
                }
    
    def _get_function_name(self, func_node):
        """Extract function name from call node"""
        if isinstance(func_node, ast.Name):
            return func_node.id
        elif isinstance(func_node, ast.Attribute):
            # Method call like obj.method()
            if isinstance(func_node.value, ast.Name):
                return f"{func_node.value.id}.{func_node.attr}"
            else:
                return func_node.attr
        return None
    
    def get_function_workflow(self, func_name):
        """Get complete workflow for a specific function"""
        if func_name not in self.function_definitions:
            return None
        
        workflow = {
            'definition': self.function_definitions[func_name],
            'called_by': [],
            'calls': []
        }
        
        # Find who calls this function
        for call_key, call_data in self.function_calls.items():
            if call_data['function'] == func_name:
                workflow['called_by'].append(call_data)
        
        # Find what this function calls (functions called from the same file)
        def_file = self.function_definitions[func_name]['file']
        for call_key, call_data in self.function_calls.items():
            if call_data['file'] == def_file:
                workflow['calls'].append(call_data)
        
        return workflow
    
    def get_unused_functions(self):
        """Find functions that are defined but never called"""
        called_functions = set()
        for call_data in self.function_calls.values():
            called_functions.add(call_data['function'])
        
        defined_functions = set(self.function_definitions.keys())
        return defined_functions - called_functions


def main():
    """Main function"""
    root = tk.Tk()
    
    # Configure style
    style = ttk.Style()
    style.theme_use('clam')
    
    app = CodeFlowVisualizerGUI(root)
    root.mainloop()


if __name__ == "__main__":
    main()