#!/usr/bin/env python3
"""
GUI Python Code Analyzer - Enhanced
Enhanced version with collapsible sections, summaries, color coding, and better reporting
"""

import os
import ast
import sys
import importlib.util
import tkinter as tk
from tkinter import ttk, filedialog, messagebox, scrolledtext
from pathlib import Path
from typing import Dict, List, Set, Tuple, Optional
from collections import defaultdict
import threading
import re

class CollapsibleFrame(ttk.Frame):
    """A collapsible frame widget"""
    
    def __init__(self, parent, text="", *args, **kwargs):
        ttk.Frame.__init__(self, parent, *args, **kwargs)
        
        self.show = tk.BooleanVar(value=True)
        self.show.trace('w', self.toggle)
        
        # Header frame
        self.header_frame = ttk.Frame(self)
        self.header_frame.pack(fill="x", expand=False)
        
        # Toggle button and label
        self.toggle_button = ttk.Checkbutton(
            self.header_frame, width=2, text='▼', command=self.toggle,
            variable=self.show, style='Toolbutton'
        )
        self.toggle_button.pack(side="left")
        
        self.title_label = ttk.Label(self.header_frame, text=text, font=('Arial', 10, 'bold'))
        self.title_label.pack(side="left", padx=(5, 0))
        
        # Content frame
        self.content_frame = ttk.Frame(self)
        self.content_frame.pack(fill="both", expand=True)
        
    def toggle(self, *args):
        if self.show.get():
            self.content_frame.pack(fill="both", expand=True)
            self.toggle_button.configure(text='▼')
        else:
            self.content_frame.pack_forget()
            self.toggle_button.configure(text='▶')
    
    def set_title(self, text):
        self.title_label.configure(text=text)

class CodeAnalyzerGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Python Code Analyzer - Enhanced")
        self.root.geometry("1200x800")
        
        # Analysis data
        self.errors = []
        self.warnings = []
        self.file_definitions = {}
        self.file_imports = {}
        self.selected_files = []
        self.analysis_running = False
        
        # Create GUI
        self.create_widgets()
        
    def create_widgets(self):
        """Create the GUI widgets"""
        # Main frame
        main_frame = ttk.Frame(self.root, padding="10")
        main_frame.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        
        # Configure grid weights
        self.root.columnconfigure(0, weight=1)
        self.root.rowconfigure(0, weight=1)
        main_frame.columnconfigure(1, weight=1)
        main_frame.rowconfigure(4, weight=1)
        
        # Title
        title_label = ttk.Label(main_frame, text="🔍 Python Code Analyzer - Enhanced", 
                               font=('Arial', 16, 'bold'))
        title_label.grid(row=0, column=0, columnspan=3, pady=(0, 20))
        
        # File/Folder Selection Section
        selection_frame = ttk.LabelFrame(main_frame, text="📁 File Selection", padding="10")
        selection_frame.grid(row=1, column=0, columnspan=3, sticky=(tk.W, tk.E), pady=(0, 10))
        selection_frame.columnconfigure(1, weight=1)
        
        # Folder selection
        ttk.Label(selection_frame, text="Root Folder:").grid(row=0, column=0, sticky=tk.W)
        self.folder_var = tk.StringVar(value=os.getcwd())
        folder_entry = ttk.Entry(selection_frame, textvariable=self.folder_var, width=50)
        folder_entry.grid(row=0, column=1, sticky=(tk.W, tk.E), padx=(5, 5))
        ttk.Button(selection_frame, text="Browse", 
                  command=self.browse_folder).grid(row=0, column=2, padx=(5, 0))
        
        # File selection listbox
        files_frame = ttk.Frame(selection_frame)
        files_frame.grid(row=1, column=0, columnspan=3, sticky=(tk.W, tk.E, tk.N, tk.S), pady=(10, 0))
        files_frame.columnconfigure(0, weight=1)
        files_frame.rowconfigure(0, weight=1)
        
        ttk.Label(files_frame, text="Python Files:").grid(row=0, column=0, sticky=tk.W)
        
        # Listbox with scrollbar
        listbox_frame = ttk.Frame(files_frame)
        listbox_frame.grid(row=1, column=0, columnspan=3, sticky=(tk.W, tk.E, tk.N, tk.S), pady=(5, 0))
        listbox_frame.columnconfigure(0, weight=1)
        listbox_frame.rowconfigure(0, weight=1)
        
        self.files_listbox = tk.Listbox(listbox_frame, selectmode=tk.EXTENDED, height=6)
        scrollbar = ttk.Scrollbar(listbox_frame, orient=tk.VERTICAL, command=self.files_listbox.yview)
        self.files_listbox.configure(yscrollcommand=scrollbar.set)
        
        self.files_listbox.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        scrollbar.grid(row=0, column=1, sticky=(tk.N, tk.S))
        
        # File selection buttons
        button_frame = ttk.Frame(files_frame)
        button_frame.grid(row=2, column=0, columnspan=3, pady=(5, 0))
        
        ttk.Button(button_frame, text="Refresh Files", 
                  command=self.refresh_files).grid(row=0, column=0, padx=(0, 5))
        ttk.Button(button_frame, text="Select All", 
                  command=self.select_all_files).grid(row=0, column=1, padx=(0, 5))
        ttk.Button(button_frame, text="Select None", 
                  command=self.select_no_files).grid(row=0, column=2, padx=(0, 5))
        
        # Filter Section
        filter_frame = ttk.LabelFrame(main_frame, text="🔧 Options & Filters", padding="10")
        filter_frame.grid(row=2, column=0, columnspan=3, sticky=(tk.W, tk.E), pady=(0, 10))
        filter_frame.columnconfigure(1, weight=1)
        
        # Include/Exclude patterns
        ttk.Label(filter_frame, text="Include patterns:").grid(row=0, column=0, sticky=tk.W)
        self.include_var = tk.StringVar(value="*.py")
        ttk.Entry(filter_frame, textvariable=self.include_var, width=40).grid(row=0, column=1, sticky=(tk.W, tk.E), padx=(5, 5))
        ttk.Label(filter_frame, text="(e.g., *.py, main.py, test_*)").grid(row=0, column=2, sticky=tk.W)
        
        ttk.Label(filter_frame, text="Exclude patterns:").grid(row=1, column=0, sticky=tk.W)
        self.exclude_var = tk.StringVar(value="__pycache__,*.pyc,.git,venv,env")
        ttk.Entry(filter_frame, textvariable=self.exclude_var, width=40).grid(row=1, column=1, sticky=(tk.W, tk.E), padx=(5, 5))
        ttk.Label(filter_frame, text="(e.g., test_*, __pycache__, .git)").grid(row=1, column=2, sticky=tk.W)
        
        # Options row 1
        options_frame1 = ttk.Frame(filter_frame)
        options_frame1.grid(row=2, column=0, columnspan=3, pady=(10, 5))
        
        self.check_external_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(options_frame1, text="Check external imports", 
                       variable=self.check_external_var).grid(row=0, column=0, sticky=tk.W)
        
        self.check_attributes_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(options_frame1, text="Check module attributes", 
                       variable=self.check_attributes_var).grid(row=0, column=1, sticky=tk.W, padx=(20, 0))
        
        self.verbose_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(options_frame1, text="Verbose output", 
                       variable=self.verbose_var).grid(row=0, column=2, sticky=tk.W, padx=(20, 0))
        
        # Summary and Display options
        options_frame2 = ttk.Frame(filter_frame)
        options_frame2.grid(row=3, column=0, columnspan=3, pady=(5, 0))
        
        ttk.Label(options_frame2, text="Summary Type:").grid(row=0, column=0, sticky=tk.W)
        
        self.summary_type_var = tk.StringVar(value="basic")
        ttk.Radiobutton(options_frame2, text="Basic", variable=self.summary_type_var, 
                       value="basic").grid(row=0, column=1, sticky=tk.W, padx=(10, 0))
        ttk.Radiobutton(options_frame2, text="Advanced", 
                       variable=self.summary_type_var, value="advanced").grid(row=0, column=2, sticky=tk.W, padx=(10, 0))
        
        # New display options
        ttk.Label(options_frame2, text="Display:").grid(row=0, column=3, sticky=tk.W, padx=(30, 0))
        
        self.group_issues_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(options_frame2, text="Group similar issues", 
                       variable=self.group_issues_var).grid(row=0, column=4, sticky=tk.W, padx=(10, 0))
        
        self.show_recommendations_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(options_frame2, text="Show recommendations", 
                       variable=self.show_recommendations_var).grid(row=0, column=5, sticky=tk.W, padx=(10, 0))
        
        # Analysis Section
        analysis_frame = ttk.Frame(main_frame)
        analysis_frame.grid(row=3, column=0, columnspan=3, sticky=(tk.W, tk.E), pady=(0, 10))
        
        self.analyze_button = ttk.Button(analysis_frame, text="🔍 Analyze Code", 
                                        command=self.start_analysis, style='Accent.TButton')
        self.analyze_button.grid(row=0, column=0, padx=(0, 10))
        
        self.progress_var = tk.StringVar(value="Ready to analyze")
        self.progress_label = ttk.Label(analysis_frame, textvariable=self.progress_var)
        self.progress_label.grid(row=0, column=1, sticky=tk.W)
        
        self.progress_bar = ttk.Progressbar(analysis_frame, mode='indeterminate')
        self.progress_bar.grid(row=0, column=2, sticky=(tk.W, tk.E), padx=(10, 0))
        analysis_frame.columnconfigure(2, weight=1)
        
        # Results Section with Notebook for tabs
        self.results_notebook = ttk.Notebook(main_frame)
        self.results_notebook.grid(row=4, column=0, columnspan=3, sticky=(tk.W, tk.E, tk.N, tk.S), pady=(0, 10))
        
        # Summary tab
        self.summary_frame = ttk.Frame(self.results_notebook)
        self.results_notebook.add(self.summary_frame, text="📊 Summary")
        
        # Create summary content
        self.create_summary_tab()
        
        # Detailed Results tab
        self.detailed_frame = ttk.Frame(self.results_notebook)
        self.results_notebook.add(self.detailed_frame, text="🔍 Detailed Results")
        
        # Create detailed results content
        self.create_detailed_tab()
        
        # Initialize
        self.refresh_files()
        
    def create_summary_tab(self):
        """Create the summary tab content"""
        # Main summary text
        self.summary_text = scrolledtext.ScrolledText(self.summary_frame, wrap=tk.WORD, height=10)
        self.summary_text.pack(fill="both", expand=True, padx=10, pady=10)
        
        # Configure tags for color coding
        self.summary_text.tag_configure("error", foreground="red", font=('Arial', 9, 'bold'))
        self.summary_text.tag_configure("warning", foreground="orange", font=('Arial', 9))
        self.summary_text.tag_configure("recommendation", foreground="blue", font=('Arial', 9, 'italic'))
        self.summary_text.tag_configure("header", foreground="black", font=('Arial', 10, 'bold'))
        self.summary_text.tag_configure("file", foreground="darkgreen", font=('Arial', 9, 'bold'))
        
        # Buttons
        summary_button_frame = ttk.Frame(self.summary_frame)
        summary_button_frame.pack(fill="x", padx=10, pady=(0, 10))
        
        ttk.Button(summary_button_frame, text="Save Summary", 
                  command=self.save_summary).pack(side="left", padx=(0, 10))
        ttk.Button(summary_button_frame, text="Copy to Clipboard", 
                  command=self.copy_summary).pack(side="left")
    
    def create_detailed_tab(self):
        """Create the detailed results tab content"""
        # Create main frame for collapsible sections
        main_detailed_frame = ttk.Frame(self.detailed_frame)
        main_detailed_frame.pack(fill="both", expand=True, padx=10, pady=10)
        
        # Errors section
        self.errors_section = CollapsibleFrame(main_detailed_frame, "🚨 Errors (0)")
        self.errors_section.pack(fill="x", pady=(0, 10))
        
        self.errors_text = scrolledtext.ScrolledText(self.errors_section.content_frame, 
                                                    wrap=tk.WORD, height=8)
        self.errors_text.pack(fill="both", expand=True)
        self.errors_text.tag_configure("error", foreground="red")
        self.errors_text.tag_configure("file", foreground="darkgreen", font=('Arial', 9, 'bold'))
        
        # Warnings section
        self.warnings_section = CollapsibleFrame(main_detailed_frame, "⚠️ Warnings (0)")
        self.warnings_section.pack(fill="x", pady=(0, 10))
        
        self.warnings_text = scrolledtext.ScrolledText(self.warnings_section.content_frame, 
                                                      wrap=tk.WORD, height=8)
        self.warnings_text.pack(fill="both", expand=True)
        self.warnings_text.tag_configure("warning", foreground="orange")
        self.warnings_text.tag_configure("file", foreground="darkgreen", font=('Arial', 9, 'bold'))
        
        # Imports section
        self.imports_section = CollapsibleFrame(main_detailed_frame, "📦 Import Analysis (0)")
        self.imports_section.pack(fill="x")
        
        self.imports_text = scrolledtext.ScrolledText(self.imports_section.content_frame, 
                                                     wrap=tk.WORD, height=8)
        self.imports_text.pack(fill="both", expand=True)
        self.imports_text.tag_configure("import_ok", foreground="green")
        self.imports_text.tag_configure("import_missing", foreground="red")
        self.imports_text.tag_configure("import_local", foreground="blue")
        self.imports_text.tag_configure("file", foreground="darkgreen", font=('Arial', 9, 'bold'))
        
        # Detailed results buttons
        detailed_button_frame = ttk.Frame(self.detailed_frame)
        detailed_button_frame.pack(fill="x", padx=10, pady=(0, 10))
        
        ttk.Button(detailed_button_frame, text="Save Report", 
                  command=self.save_report).pack(side="left", padx=(0, 10))
        ttk.Button(detailed_button_frame, text="Export JSON", 
                  command=self.export_json).pack(side="left", padx=(0, 10))
        ttk.Button(detailed_button_frame, text="Clear All", 
                  command=self.clear_results).pack(side="left")
    
    def browse_folder(self):
        """Browse for folder"""
        folder = filedialog.askdirectory(initialdir=self.folder_var.get())
        if folder:
            self.folder_var.set(folder)
            self.refresh_files()
    
    def refresh_files(self):
        """Refresh the list of Python files"""
        self.files_listbox.delete(0, tk.END)
        
        root_path = Path(self.folder_var.get())
        if not root_path.exists():
            return
        
        exclude_patterns = [p.strip() for p in self.exclude_var.get().split(',') if p.strip()]
        
        try:
            python_files = []
            for file_path in root_path.rglob('*.py'):
                # Check exclude patterns
                should_exclude = False
                for pattern in exclude_patterns:
                    if pattern in str(file_path):
                        should_exclude = True
                        break
                
                if not should_exclude:
                    rel_path = file_path.relative_to(root_path)
                    python_files.append((str(rel_path), file_path))
            
            # Sort files
            python_files.sort()
            
            for rel_path, full_path in python_files:
                self.files_listbox.insert(tk.END, rel_path)
            
            # Select all by default
            self.select_all_files()
            
        except Exception as e:
            messagebox.showerror("Error", f"Error refreshing files: {e}")
    
    def select_all_files(self):
        """Select all files in the listbox"""
        self.files_listbox.select_set(0, tk.END)
    
    def select_no_files(self):
        """Deselect all files"""
        self.files_listbox.select_clear(0, tk.END)
    
    def start_analysis(self):
        """Start the analysis in a separate thread"""
        if self.analysis_running:
            return
        
        selected_indices = self.files_listbox.curselection()
        if not selected_indices:
            messagebox.showwarning("Warning", "Please select at least one file to analyze")
            return
        
        self.analysis_running = True
        self.analyze_button.config(state='disabled')
        self.progress_bar.start()
        self.clear_results()
        
        # Start analysis thread
        thread = threading.Thread(target=self.run_analysis)
        thread.daemon = True
        thread.start()
    
    def run_analysis(self):
        """Run the analysis (called in separate thread)"""
        try:
            # Get selected files
            selected_indices = self.files_listbox.curselection()
            root_path = Path(self.folder_var.get())
            
            selected_files = []
            for i in selected_indices:
                rel_path = self.files_listbox.get(i)
                full_path = root_path / rel_path
                selected_files.append(full_path)
            
            # Initialize analyzer
            analyzer = CodeAnalyzer(
                root_path=root_path,
                selected_files=selected_files,
                check_external=self.check_external_var.get(),
                check_attributes=self.check_attributes_var.get(),
                verbose=self.verbose_var.get(),
                summary_type=self.summary_type_var.get(),
                progress_callback=self.update_progress
            )
            
            # Run analysis
            analyzer.analyze()
            
            # Update UI in main thread
            self.root.after(0, self.analysis_complete, analyzer)
            
        except Exception as e:
            self.root.after(0, self.analysis_error, str(e))
    
    def update_progress(self, message):
        """Update progress message"""
        self.root.after(0, lambda: self.progress_var.set(message))
    
    def analysis_complete(self, analyzer):
        """Handle analysis completion"""
        self.analysis_running = False
        self.analyze_button.config(state='normal')
        self.progress_bar.stop()
        self.progress_var.set("Analysis complete")
        
        # Display results
        self.display_results(analyzer)
    
    def analysis_error(self, error_msg):
        """Handle analysis error"""
        self.analysis_running = False
        self.analyze_button.config(state='normal')
        self.progress_bar.stop()
        self.progress_var.set("Analysis failed")
        messagebox.showerror("Analysis Error", f"Analysis failed: {error_msg}")
    
    def display_results(self, analyzer):
        """Display analysis results in both tabs"""
        # Store analyzer for later use
        self.last_analyzer = analyzer
        
        # Update summary tab
        self.display_summary(analyzer)
        
        # Update detailed tab
        self.display_detailed_results(analyzer)
    
    def display_summary(self, analyzer):
        """Display summarized results"""
        self.summary_text.delete(1.0, tk.END)
        
        # Header
        summary_type_display = "Advanced" if analyzer.summary_type == "advanced" else "Basic"
        header = f"📊 ANALYSIS SUMMARY ({summary_type_display})\n"
        header += f"{'=' * 50}\n"
        header += f"📁 Root: {analyzer.root_path.name}\n"
        header += f"📄 Files: {len(analyzer.selected_files)} | ❌ Errors: {len(analyzer.grouped_errors)} | ⚠️ Warnings: {len(analyzer.grouped_warnings)}\n\n"
        
        self.summary_text.insert(tk.END, header, "header")
        
        if not analyzer.grouped_errors and not analyzer.grouped_warnings:
            self.summary_text.insert(tk.END, "✅ No issues found! All imports and references look good.\n", "header")
            return
        
        # Group and display issues
        if self.group_issues_var.get():
            self._display_grouped_summary(analyzer)
        else:
            self._display_basic_summary(analyzer)
    
    def _display_grouped_summary(self, analyzer):
        """Display grouped/summarized issues"""
        # Display grouped errors
        if analyzer.grouped_errors:
            self.summary_text.insert(tk.END, "🚨 CRITICAL ISSUES:\n", "error")
            self.summary_text.insert(tk.END, "-" * 30 + "\n")
            
            for issue_key, issue_data in analyzer.grouped_errors.items():
                file_lines = defaultdict(list)
                for item in issue_data['items']:
                    file_path = Path(item['file']).relative_to(analyzer.root_path)
                    file_lines[str(file_path)].append(str(item['line']))
                
                # Display issue summary
                self.summary_text.insert(tk.END, f"• {issue_data['message']}\n", "error")
                
                for file_path, lines in file_lines.items():
                    lines_str = ", ".join(sorted(lines, key=int))
                    self.summary_text.insert(tk.END, f"  📄 {file_path}: Lines {lines_str}\n", "file")
                
                # Show recommendation if enabled
                if self.show_recommendations_var.get() and issue_data.get('recommendation'):
                    self.summary_text.insert(tk.END, f"  💡 {issue_data['recommendation']}\n", "recommendation")
                
                self.summary_text.insert(tk.END, "\n")
        
        # Display grouped warnings
        if analyzer.grouped_warnings:
            self.summary_text.insert(tk.END, "⚠️ WARNINGS:\n", "warning")
            self.summary_text.insert(tk.END, "-" * 30 + "\n")
            
            for issue_key, issue_data in analyzer.grouped_warnings.items():
                file_lines = defaultdict(list)
                for item in issue_data['items']:
                    file_path = Path(item['file']).relative_to(analyzer.root_path)
                    file_lines[str(file_path)].append(str(item['line']))
                
                self.summary_text.insert(tk.END, f"• {issue_data['message']}\n", "warning")
                
                for file_path, lines in file_lines.items():
                    lines_str = ", ".join(sorted(lines, key=int))
                    self.summary_text.insert(tk.END, f"  📄 {file_path}: Lines {lines_str}\n", "file")
                
                if self.show_recommendations_var.get() and issue_data.get('recommendation'):
                    self.summary_text.insert(tk.END, f"  💡 {issue_data['recommendation']}\n", "recommendation")
                
                self.summary_text.insert(tk.END, "\n")
    
    def _display_basic_summary(self, analyzer):
        """Display basic summary format"""
        if analyzer.errors:
            self.summary_text.insert(tk.END, "🚨 ERRORS:\n", "error")
            for error in analyzer.errors:
                self.summary_text.insert(tk.END, f"{error}\n", "error")
            self.summary_text.insert(tk.END, "\n")
        
        if analyzer.warnings:
            self.summary_text.insert(tk.END, "⚠️ WARNINGS:\n", "warning")
            for warning in analyzer.warnings:
                self.summary_text.insert(tk.END, f"{warning}\n", "warning")
    
    def display_detailed_results(self, analyzer):
        """Display detailed results in collapsible sections"""
        # Update section titles
        self.errors_section.set_title(f"🚨 Errors ({len(analyzer.errors)})")
        self.warnings_section.set_title(f"⚠️ Warnings ({len(analyzer.warnings)})")
        self.imports_section.set_title(f"📦 Import Analysis ({len(analyzer.import_analysis)})")
        
        # Clear previous content
        self.errors_text.delete(1.0, tk.END)
        self.warnings_text.delete(1.0, tk.END)
        self.imports_text.delete(1.0, tk.END)
        
        # Display errors
        if analyzer.detailed_errors:
            self._display_detailed_errors(analyzer)
        else:
            self.errors_text.insert(tk.END, "✅ No errors found!")
        
        # Display warnings
        if analyzer.detailed_warnings:
            self._display_detailed_warnings(analyzer)
        else:
            self.warnings_text.insert(tk.END, "✅ No warnings found!")
        
        # Display import analysis
        self._display_import_analysis(analyzer)
    
    def _display_detailed_errors(self, analyzer):
        """Display detailed error information with collapsible file sections"""
        if analyzer.summary_type == "advanced":
            # Group by file
            errors_by_file = defaultdict(list)
            for error in analyzer.detailed_errors:
                errors_by_file[error['file']].append(error)
            
            if not errors_by_file:
                self.errors_text.insert(tk.END, "✅ No errors found!")
                return
            
            # Create collapsible sections for each file
            for file_path, file_errors in sorted(errors_by_file.items()):
                rel_path = Path(file_path).relative_to(analyzer.root_path)
                error_count = len(file_errors)
                
                # Create a collapsible section for this file
                self._insert_collapsible_file_section(
                    self.errors_text, 
                    str(rel_path), 
                    error_count, 
                    "error",
                    file_errors
                )
        else:
            for error in analyzer.errors:
                self.errors_text.insert(tk.END, f"{error}\n", "error")
    
    def _display_detailed_warnings(self, analyzer):
        """Display detailed warning information with collapsible file sections"""
        if analyzer.summary_type == "advanced":
            warnings_by_file = defaultdict(list)
            for warning in analyzer.detailed_warnings:
                warnings_by_file[warning['file']].append(warning)
            
            if not warnings_by_file:
                self.errors_text.insert(tk.END, "✅ No warnings found!")
                return
            
            for file_path, file_warnings in sorted(warnings_by_file.items()):
                rel_path = Path(file_path).relative_to(analyzer.root_path)
                warning_count = len(file_warnings)
                
                # Create a collapsible section for this file
                self._insert_collapsible_file_section(
                    self.warnings_text, 
                    str(rel_path), 
                    warning_count, 
                    "warning",
                    file_warnings
                )
        else:
            for warning in analyzer.warnings:
                self.warnings_text.insert(tk.END, f"{warning}\n", "warning")
    
    def _insert_collapsible_file_section(self, text_widget, file_name, issue_count, issue_type, issues):
        """Insert a collapsible file section into a text widget"""
        # Insert clickable header
        start_pos = text_widget.index(tk.INSERT)
        header_text = f"\n▼ 📄 {file_name} ({issue_count} {issue_type}s)\n"
        text_widget.insert(tk.END, header_text, "file_header")
        end_pos = text_widget.index(tk.INSERT)
        
        # Insert the content (initially visible)
        content_start = text_widget.index(tk.INSERT)
        for issue in sorted(issues, key=lambda x: x['line']):
            line_text = f"   Line {issue['line']:3d}: {issue['message']}\n"
            code_text = f"            Code: '{issue['code']}'\n"
            text_widget.insert(tk.END, line_text, issue_type)
            text_widget.insert(tk.END, code_text)
        content_end = text_widget.index(tk.INSERT)
        
        # Store the content range and collapsed state
        section_id = f"section_{len(getattr(text_widget, '_sections', []))}"
        if not hasattr(text_widget, '_sections'):
            text_widget._sections = {}
        
        text_widget._sections[section_id] = {
            'header_start': start_pos,
            'header_end': end_pos,
            'content_start': content_start,
            'content_end': content_end,
            'collapsed': False,
            'file_name': file_name
        }
        
        # Make header clickable
        text_widget.tag_add(f"clickable_{section_id}", start_pos, end_pos)
        text_widget.tag_bind(f"clickable_{section_id}", "<Button-1>", 
                           lambda e, sid=section_id: self._toggle_file_section(text_widget, sid))
        
        # Style the clickable header
        text_widget.tag_configure(f"clickable_{section_id}", 
                                 foreground="darkblue", 
                                 font=('Arial', 9, 'bold'),
                                 underline=True)
    
    def _toggle_file_section(self, text_widget, section_id):
        """Toggle the visibility of a file section"""
        if section_id not in text_widget._sections:
            return
        
        section = text_widget._sections[section_id]
        
        if section['collapsed']:
            # Expand: show content and change arrow
            self._show_file_content(text_widget, section_id)
            # Update header arrow
            header_start = section['header_start']
            header_end = section['header_end']
            current_text = text_widget.get(header_start, header_end)
            new_text = current_text.replace("▶", "▼")
            text_widget.delete(header_start, header_end)
            text_widget.insert(header_start, new_text, "file_header")
            section['collapsed'] = False
        else:
            # Collapse: hide content and change arrow
            self._hide_file_content(text_widget, section_id)
            # Update header arrow
            header_start = section['header_start']
            header_end = section['header_end']
            current_text = text_widget.get(header_start, header_end)
            new_text = current_text.replace("▼", "▶")
            text_widget.delete(header_start, header_end)
            text_widget.insert(header_start, new_text, "file_header")
            section['collapsed'] = True
        
        # Update tag binding after text change
        text_widget.tag_add(f"clickable_{section_id}", 
                           section['header_start'], 
                           section['header_end'])
    
    def _hide_file_content(self, text_widget, section_id):
        """Hide the content of a file section"""
        section = text_widget._sections[section_id]
        
        # Store the content before hiding
        content = text_widget.get(section['content_start'], section['content_end'])
        section['hidden_content'] = content
        
        # Delete the content
        text_widget.delete(section['content_start'], section['content_end'])
        
        # Update content positions for all sections after this one
        deleted_lines = content.count('\n')
        for other_id, other_section in text_widget._sections.items():
            if other_id != section_id:
                # Check if this section comes after the current one
                if text_widget.compare(other_section['header_start'], '>', section['header_start']):
                    # Adjust positions
                    other_section['header_start'] = self._adjust_text_index(
                        other_section['header_start'], -deleted_lines)
                    other_section['header_end'] = self._adjust_text_index(
                        other_section['header_end'], -deleted_lines)
                    other_section['content_start'] = self._adjust_text_index(
                        other_section['content_start'], -deleted_lines)
                    other_section['content_end'] = self._adjust_text_index(
                        other_section['content_end'], -deleted_lines)
        
        # Update this section's content positions
        section['content_end'] = section['content_start']
    
    def _show_file_content(self, text_widget, section_id):
        """Show the content of a file section"""
        section = text_widget._sections[section_id]
        
        if 'hidden_content' not in section:
            return
        
        # Insert the hidden content
        content = section['hidden_content']
        text_widget.insert(section['content_start'], content)
        
        # Update content end position
        section['content_end'] = text_widget.index(f"{section['content_start']} + {len(content.splitlines())}l")
        
        # Update positions for all sections after this one
        added_lines = content.count('\n')
        for other_id, other_section in text_widget._sections.items():
            if other_id != section_id:
                # Check if this section comes after the current one
                if text_widget.compare(other_section['header_start'], '>', section['header_start']):
                    # Adjust positions
                    other_section['header_start'] = self._adjust_text_index(
                        other_section['header_start'], added_lines)
                    other_section['header_end'] = self._adjust_text_index(
                        other_section['header_end'], added_lines)
                    other_section['content_start'] = self._adjust_text_index(
                        other_section['content_start'], added_lines)
                    other_section['content_end'] = self._adjust_text_index(
                        other_section['content_end'], added_lines)
        
        # Remove the stored content
        del section['hidden_content']
    
    def _adjust_text_index(self, index_str, line_delta):
        """Adjust a text widget index by a number of lines"""
        try:
            line, char = index_str.split('.')
            new_line = int(line) + line_delta
            return f"{new_line}.{char}"
        except:
            return index_str
    
    def _display_import_analysis(self, analyzer):
        """Display import analysis with collapsible file sections"""
        if not analyzer.import_analysis:
            self.imports_text.insert(tk.END, "No import analysis available.")
            return
        
        for file_path, imports in analyzer.import_analysis.items():
            rel_path = Path(file_path).relative_to(analyzer.root_path)
            import_count = len(imports)
            
            if import_count == 0:
                continue
            
            # Create collapsible section for this file
            start_pos = self.imports_text.index(tk.INSERT)
            header_text = f"\n▼ 📄 {rel_path} ({import_count} imports)\n"
            self.imports_text.insert(tk.END, header_text, "file_header")
            end_pos = self.imports_text.index(tk.INSERT)
            
            # Insert import content
            content_start = self.imports_text.index(tk.INSERT)
            for module_name, import_info in imports.items():
                if import_info['exists']:
                    if import_info['is_local']:
                        self.imports_text.insert(tk.END, f"   📦 {module_name} (local)\n", "import_local")
                    else:
                        self.imports_text.insert(tk.END, f"   ✅ {module_name} (external)\n", "import_ok")
                else:
                    self.imports_text.insert(tk.END, f"   ❌ {module_name} (not found)\n", "import_missing")
            content_end = self.imports_text.index(tk.INSERT)
            
            # Set up collapsible functionality
            section_id = f"import_section_{len(getattr(self.imports_text, '_sections', []))}"
            if not hasattr(self.imports_text, '_sections'):
                self.imports_text._sections = {}
            
            self.imports_text._sections[section_id] = {
                'header_start': start_pos,
                'header_end': end_pos,
                'content_start': content_start,
                'content_end': content_end,
                'collapsed': False,
                'file_name': str(rel_path)
            }
            
            # Make header clickable
            self.imports_text.tag_add(f"clickable_{section_id}", start_pos, end_pos)
            self.imports_text.tag_bind(f"clickable_{section_id}", "<Button-1>", 
                                     lambda e, sid=section_id: self._toggle_file_section(self.imports_text, sid))
            
            # Style the clickable header
            self.imports_text.tag_configure(f"clickable_{section_id}", 
                                          foreground="darkblue", 
                                          font=('Arial', 9, 'bold'),
                                          underline=True)
    
    def save_summary(self):
        """Save the summary to a file"""
        if not hasattr(self, 'last_analyzer'):
            messagebox.showwarning("Warning", "No analysis results to save")
            return
        
        filename = filedialog.asksaveasfilename(
            defaultextension=".txt",
            filetypes=[("Text files", "*.txt"), ("All files", "*.*")],
            title="Save Summary Report"
        )
        
        if filename:
            try:
                with open(filename, 'w', encoding='utf-8') as f:
                    f.write(self.summary_text.get(1.0, tk.END))
                messagebox.showinfo("Success", f"Summary saved to {filename}")
            except Exception as e:
                messagebox.showerror("Error", f"Error saving summary: {e}")
    
    def copy_summary(self):
        """Copy summary to clipboard"""
        if not hasattr(self, 'last_analyzer'):
            messagebox.showwarning("Warning", "No analysis results to copy")
            return
        
        try:
            self.root.clipboard_clear()
            self.root.clipboard_append(self.summary_text.get(1.0, tk.END))
            messagebox.showinfo("Success", "Summary copied to clipboard")
        except Exception as e:
            messagebox.showerror("Error", f"Error copying to clipboard: {e}")
    
    def clear_results(self):
        """Clear all results"""
        self.summary_text.delete(1.0, tk.END)
        self.errors_text.delete(1.0, tk.END)
        self.warnings_text.delete(1.0, tk.END)
        self.imports_text.delete(1.0, tk.END)
        
        # Clear section tracking
        for text_widget in [self.errors_text, self.warnings_text, self.imports_text]:
            if hasattr(text_widget, '_sections'):
                text_widget._sections = {}
        
        # Reset section titles
        self.errors_section.set_title("🚨 Errors (0)")
        self.warnings_section.set_title("⚠️ Warnings (0)")
        self.imports_section.set_title("📦 Import Analysis (0)")
    
    def save_report(self):
        """Save the detailed analysis report to a file"""
        if not hasattr(self, 'last_analyzer'):
            messagebox.showwarning("Warning", "No analysis results to save")
            return
        
        filename = filedialog.asksaveasfilename(
            defaultextension=".txt",
            filetypes=[("Text files", "*.txt"), ("All files", "*.*")],
            title="Save Detailed Report"
        )
        
        if filename:
            try:
                with open(filename, 'w', encoding='utf-8') as f:
                    # Write header
                    f.write("PYTHON CODE ANALYSIS - DETAILED REPORT\n")
                    f.write("=" * 50 + "\n\n")
                    
                    # Write errors
                    f.write("ERRORS:\n")
                    f.write("-" * 20 + "\n")
                    f.write(self.errors_text.get(1.0, tk.END))
                    f.write("\n")
                    
                    # Write warnings
                    f.write("WARNINGS:\n")
                    f.write("-" * 20 + "\n")
                    f.write(self.warnings_text.get(1.0, tk.END))
                    f.write("\n")
                    
                    # Write imports
                    f.write("IMPORTS:\n")
                    f.write("-" * 20 + "\n")
                    f.write(self.imports_text.get(1.0, tk.END))
                
                messagebox.showinfo("Success", f"Detailed report saved to {filename}")
            except Exception as e:
                messagebox.showerror("Error", f"Error saving report: {e}")
    
    def export_json(self):
        """Export results as JSON"""
        if not hasattr(self, 'last_analyzer'):
            messagebox.showwarning("Warning", "No analysis results to export")
            return
        
        filename = filedialog.asksaveasfilename(
            defaultextension=".json",
            filetypes=[("JSON files", "*.json"), ("All files", "*.*")],
            title="Export Analysis Data"
        )
        
        if filename:
            try:
                import json
                data = {
                    'root_path': str(self.last_analyzer.root_path),
                    'summary_type': self.last_analyzer.summary_type,
                    'files_analyzed': [str(f) for f in self.last_analyzer.selected_files],
                    'errors': self.last_analyzer.errors,
                    'warnings': self.last_analyzer.warnings,
                    'grouped_errors': dict(self.last_analyzer.grouped_errors),
                    'grouped_warnings': dict(self.last_analyzer.grouped_warnings),
                    'import_analysis': {str(k): v for k, v in self.last_analyzer.import_analysis.items()},
                    'summary': {
                        'total_files': len(self.last_analyzer.selected_files),
                        'total_errors': len(self.last_analyzer.errors),
                        'total_warnings': len(self.last_analyzer.warnings)
                    }
                }
                
                # Add detailed information if advanced summary
                if self.last_analyzer.summary_type == "advanced":
                    data['detailed_errors'] = self.last_analyzer.detailed_errors
                    data['detailed_warnings'] = self.last_analyzer.detailed_warnings
                
                with open(filename, 'w', encoding='utf-8') as f:
                    json.dump(data, f, indent=2, ensure_ascii=False)
                messagebox.showinfo("Success", f"Analysis data exported to {filename}")
            except Exception as e:
                messagebox.showerror("Error", f"Error exporting JSON: {e}")


class CodeAnalyzer:
    """Enhanced core analysis engine with grouping and recommendations"""
    
    def __init__(self, root_path, selected_files, check_external=True, 
                 check_attributes=True, verbose=False, summary_type="basic", progress_callback=None):
        self.root_path = Path(root_path)
        self.selected_files = selected_files
        self.check_external = check_external
        self.check_attributes = check_attributes
        self.verbose = verbose
        self.summary_type = summary_type
        self.progress_callback = progress_callback
        
        self.errors = []
        self.warnings = []
        self.file_definitions = {}
        self.file_imports = {}
        self.detailed_errors = []
        self.detailed_warnings = []
        self.grouped_errors = {}
        self.grouped_warnings = {}
        self.import_analysis = {}
        
        # Recommendation templates
        self.recommendations = {
            'undefined_name': 'Define "{}" before using it, or add the appropriate import statement.',
            'missing_module': 'Install the "{}" module using pip install, or check if the module name is correct.',
            'missing_attribute': 'Check the documentation for "{}" module to verify if "{}" attribute exists.',
            'missing_local_import': 'Ensure "{}" is defined in the target file, or check the import path.'
        }
    
    def analyze(self):
        """Main analysis function with enhanced processing"""
        self._update_progress("Starting analysis...")
        
        # Step 1: Parse all files
        self._update_progress("Parsing files...")
        self._parse_all_files()
        
        # Step 2: Analyze imports
        self._update_progress("Analyzing imports...")
        self._analyze_imports()
        
        # Step 3: Analyze each file
        self._update_progress("Analyzing code...")
        self._analyze_files()
        
        # Step 4: Group similar issues
        self._update_progress("Grouping issues...")
        self._group_issues()
        
        self._update_progress("Analysis complete")
    
    def _update_progress(self, message):
        """Update progress if callback provided"""
        if self.progress_callback:
            self.progress_callback(message)
    
    def _parse_all_files(self):
        """Parse all selected files"""
        for i, file_path in enumerate(self.selected_files):
            self._update_progress(f"Parsing {file_path.name} ({i+1}/{len(self.selected_files)})")
            
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    content = f.read()
                
                tree = ast.parse(content, filename=str(file_path))
                
                # Extract definitions and imports
                self.file_definitions[file_path] = self._extract_definitions(tree)
                self.file_imports[file_path] = self._extract_imports(tree)
                
            except Exception as e:
                self.errors.append(f"❌ Failed to parse {file_path}: {e}")
    
    def _extract_definitions(self, tree):
        """Extract definitions from AST"""
        definitions = {
            'functions': set(),
            'classes': set(),
            'variables': set()
        }
        
        for node in ast.walk(tree):
            if isinstance(node, ast.FunctionDef):
                definitions['functions'].add(node.name)
            elif isinstance(node, ast.ClassDef):
                definitions['classes'].add(node.name)
            elif isinstance(node, ast.Assign):
                for target in node.targets:
                    if isinstance(target, ast.Name):
                        definitions['variables'].add(target.id)
        
        return definitions
    
    def _extract_imports(self, tree):
        """Extract imports from AST"""
        imports = defaultdict(dict)
        
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    module_name = alias.name
                    import_alias = alias.asname if alias.asname else alias.name
                    imports[module_name]['alias'] = import_alias
                    imports[module_name]['type'] = 'module'
            
            elif isinstance(node, ast.ImportFrom):
                module_name = node.module if node.module else ''
                imported_items = []
                
                for alias in node.names:
                    item_name = alias.name
                    item_alias = alias.asname if alias.asname else alias.name
                    imported_items.append((item_name, item_alias))
                
                imports[module_name]['items'] = imported_items
                imports[module_name]['type'] = 'from'
                imports[module_name]['level'] = node.level
        
        return dict(imports)
    
    def _analyze_imports(self):
        """Analyze all imports across files"""
        for file_path, imports in self.file_imports.items():
            file_import_analysis = {}
            
            for module_name, import_info in imports.items():
                if module_name:  # Skip empty module names
                    exists = self._module_exists(module_name)
                    is_local = self._is_local_module(module_name)
                    
                    file_import_analysis[module_name] = {
                        'exists': exists,
                        'is_local': is_local,
                        'type': import_info.get('type', 'unknown')
                    }
            
            self.import_analysis[file_path] = file_import_analysis
    
    def _analyze_files(self):
        """Analyze all files for issues"""
        for i, file_path in enumerate(self.selected_files):
            self._update_progress(f"Analyzing {file_path.name} ({i+1}/{len(self.selected_files)})")
            
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    content = f.read()
                
                tree = ast.parse(content, filename=str(file_path))
                self._analyze_file(file_path, tree)
                
            except Exception as e:
                self.errors.append(f"❌ Error analyzing {file_path}: {e}")
    
    def _analyze_file(self, file_path, tree):
        """Analyze a single file"""
        file_imports = self.file_imports.get(file_path, {})
        
        # Check for undefined names/attributes
        for node in ast.walk(tree):
            if isinstance(node, ast.Name) and isinstance(node.ctx, ast.Load):
                # Skip common built-in names that might cause false positives
                if node.id not in ['self', 'cls', 'super', '__name__', '__file__']:
                    self._check_name_usage(file_path, node.id, file_imports, node.lineno)
            elif isinstance(node, ast.Attribute) and self.check_attributes:
                self._check_attribute_usage(file_path, node, file_imports, node.lineno)
    
    def _check_name_usage(self, file_path, name, file_imports, line_no=None):
        """Check if a name is properly imported or defined"""
        # Check built-ins
        if name in dir(__builtins__):
            return
        
        # Check local definitions
        file_defs = self.file_definitions.get(file_path, {})
        if (name in file_defs.get('functions', set()) or 
            name in file_defs.get('classes', set()) or 
            name in file_defs.get('variables', set())):
            return
        
        # Check imports
        for module, import_info in file_imports.items():
            if import_info.get('type') == 'module' and import_info.get('alias') == name:
                if self.check_external and not self._module_exists(module):
                    error_msg = f"❌ {file_path.name}: Module '{module}' not found"
                    self.errors.append(error_msg)
                    if self.summary_type == "advanced" and line_no:
                        detailed_error = {
                            'file': str(file_path),
                            'line': line_no,
                            'type': 'missing_module',
                            'message': f"Module '{module}' not found",
                            'code': name,
                            'module': module
                        }
                        self.detailed_errors.append(detailed_error)
                return
            elif import_info.get('type') == 'from' and import_info.get('items'):
                for item_name, item_alias in import_info['items']:
                    if item_alias == name:
                        return
        
        error_msg = f"❌ {file_path.name}: Undefined name '{name}'"
        self.errors.append(error_msg)
        if self.summary_type == "advanced" and line_no:
            detailed_error = {
                'file': str(file_path),
                'line': line_no,
                'type': 'undefined_name',
                'message': f"Undefined name '{name}'",
                'code': name
            }
            self.detailed_errors.append(detailed_error)
    
    def _check_attribute_usage(self, file_path, node, file_imports, line_no=None):
        """Check attribute usage"""
        if isinstance(node.value, ast.Name):
            base_name = node.value.id
            attr_name = node.attr
            
            for module, import_info in file_imports.items():
                if import_info.get('type') == 'module' and import_info.get('alias') == base_name:
                    if self.check_external and self._module_exists(module):
                        if not self._module_has_attribute(module, attr_name):
                            warning_msg = f"⚠️  {file_path.name}: '{base_name}.{attr_name}' - attribute '{attr_name}' not found in module '{module}'"
                            self.warnings.append(warning_msg)
                            if self.summary_type == "advanced" and line_no:
                                detailed_warning = {
                                    'file': str(file_path),
                                    'line': line_no,
                                    'type': 'missing_attribute',
                                    'message': f"Attribute '{attr_name}' not found in module '{module}'",
                                    'code': f"{base_name}.{attr_name}",
                                    'module': module,
                                    'attribute': attr_name
                                }
                                self.detailed_warnings.append(detailed_warning)
                    break
    
    def _group_issues(self):
        """Group similar issues together"""
        # Group errors
        error_groups = defaultdict(list)
        for error in self.detailed_errors:
            key = f"{error['type']}:{error.get('code', 'unknown')}"
            error_groups[key].append(error)
        
        for key, items in error_groups.items():
            issue_type = items[0]['type']
            code = items[0].get('code', 'unknown')
            
            if issue_type == 'undefined_name':
                message = f"'{code}' is not defined"
                recommendation = self.recommendations['undefined_name'].format(code)
            elif issue_type == 'missing_module':
                module = items[0].get('module', code)
                message = f"Module '{module}' not found"
                recommendation = self.recommendations['missing_module'].format(module)
            else:
                message = items[0]['message']
                recommendation = f"Review the usage of '{code}'"
            
            self.grouped_errors[key] = {
                'type': issue_type,
                'code': code,
                'message': message,
                'recommendation': recommendation,
                'count': len(items),
                'items': items
            }
        
        # Group warnings
        warning_groups = defaultdict(list)
        for warning in self.detailed_warnings:
            key = f"{warning['type']}:{warning.get('code', 'unknown')}"
            warning_groups[key].append(warning)
        
        for key, items in warning_groups.items():
            issue_type = items[0]['type']
            code = items[0].get('code', 'unknown')
            
            if issue_type == 'missing_attribute':
                module = items[0].get('module', 'unknown')
                attribute = items[0].get('attribute', 'unknown')
                message = f"'{attribute}' attribute not found in '{module}'"
                recommendation = self.recommendations['missing_attribute'].format(module, attribute)
            else:
                message = items[0]['message']
                recommendation = f"Review the usage of '{code}'"
            
            self.grouped_warnings[key] = {
                'type': issue_type,
                'code': code,
                'message': message,
                'recommendation': recommendation,
                'count': len(items),
                'items': items
            }
    
    def _module_exists(self, module_name):
        """Check if module exists"""
        try:
            spec = importlib.util.find_spec(module_name)
            return spec is not None
        except:
            return self._is_local_module(module_name)
    
    def _is_local_module(self, module_name):
        """Check if it's a local module"""
        module_path = self.root_path / f"{module_name.replace('.', '/')}.py"
        if module_path.exists():
            return True
        
        package_path = self.root_path / module_name.replace('.', '/') / "__init__.py"
        return package_path.exists()
    
    def _module_has_attribute(self, module_name, attr_name):
        """Check if module has attribute"""
        try:
            module = importlib.import_module(module_name)
            return hasattr(module, attr_name)
        except:
            return True  # Assume okay to avoid false positives


def main():
    """Main function"""
    root = tk.Tk()
    
    # Configure style
    style = ttk.Style()
    style.theme_use('clam')
    
    app = CodeAnalyzerGUI(root)
    root.mainloop()


if __name__ == "__main__":
    main()