import ast
from pathlib import Path
from typing import Dict, List, Set, Any, Optional
from collections import defaultdict

# ---------------------
# Base Visitor for AST Traversal
# ---------------------

class Visitor(ast.NodeVisitor):
    """Base Visitor for analysis."""
    def __init__(self, file_path: Path):
        self.file_path = file_path
        self.errors: List[str] = []
        self.warnings: List[str] = []
        # Common built-ins to ignore during undefined name checks
        self.BUILTINS = {'print', 'len', 'range', 'str', 'int', 'dict', 'list', 'set', 
                         'Path', 'os', 'sys', 're', 'json', 'time', 'random', 'defaultdict',
                         'super', 'enumerate', 'zip', 'open', 'exit', 'input', 'bool', 'float',
                         'Exception', 'NameError', 'TypeError'}


# ---------------------
# Lightweight Code Analyzer (Simplified Linting)
# ---------------------

class LightweightCodeAnalyser(Visitor):
    """
    Refactored CodeAnalyser for basic structure and name checking.
    """
    def __init__(self, file_path: Path):
        super().__init__(file_path)
        self.defined_names: Set[str] = set()
        
    def analyze(self, code_content: str) -> Dict[str, Any]:
        """Run the analysis."""
        self.errors.clear()
        self.warnings.clear()
        self.defined_names.clear()
        
        try:
            tree = ast.parse(code_content, filename=str(self.file_path))
            # Pass 1: Collect definitions
            self._collect_definitions(tree) 
            # Pass 2: Check for undefined names
            self._check_undefined_names(tree) 
        except SyntaxError as e:
            self.errors.append(f"Syntax Error at line {e.lineno}: {e.msg}")
        except Exception as e:
            self.errors.append(f"Fatal Error during analysis: {e.__class__.__name__}: {e}")
        
        return {
            "file": str(self.file_path),
            "errors": self.errors,
            "warnings": self.warnings,
        }

    def _collect_definitions(self, tree: ast.AST):
        """Collects defined functions, classes, and variables (simplified)."""
        for node in ast.walk(tree):
            if isinstance(node, ast.FunctionDef) or isinstance(node, ast.AsyncFunctionDef):
                self.defined_names.add(node.name)
            elif isinstance(node, ast.ClassDef):
                self.defined_names.add(node.name)
            elif isinstance(node, (ast.Import, ast.ImportFrom)):
                for alias in node.names:
                    self.defined_names.add(alias.asname or alias.name)
            elif isinstance(node, ast.Assign):
                for target in node.targets:
                    if isinstance(target, ast.Name):
                        self.defined_names.add(target.id)

    def _check_undefined_names(self, tree: ast.AST):
        """Simple check for names used before they are defined/imported."""
        for node in ast.walk(tree):
            if isinstance(node, ast.Name) and isinstance(node.ctx, ast.Load):
                if node.id not in self.defined_names and node.id not in self.BUILTINS:
                     self.errors.append(f"Error (line {node.lineno}): Undefined name '{node.id}'")


# ---------------------
# Lightweight Dependency Analyzer (Flow/Usage Checks)
# ---------------------

class LightweightDependencyAnalyser(Visitor):
    """
    Refactored DependencyAnalyser to extract definitions and function calls.
    Used primarily to check for unused definitions.
    """
    def __init__(self, file_path: Path):
        super().__init__(file_path)
        self.function_definitions: Dict[str, Any] = {}
        self.class_definitions: Dict[str, Any] = {}
        self.function_calls: List[Dict[str, Any]] = []

    def analyze(self, code_content: str) -> Dict[str, Any]:
        """Run the analysis."""
        self.function_definitions.clear()
        self.class_definitions.clear()
        self.function_calls.clear()
        self.errors.clear()
        
        try:
            tree = ast.parse(code_content, filename=str(self.file_path))
            self.visit(tree)
        except Exception as e:
            self.errors.append(f"Fatal Error during analysis: {e.__class__.__name__}: {e}")

        return {
            "file": str(self.file_path),
            "function_definitions": self.function_definitions,
            "class_definitions": self.class_definitions,
            "function_calls": self.function_calls,
            "errors": self.errors
        }
    
    def visit_FunctionDef(self, node: ast.FunctionDef):
        """Collects function definitions."""
        self.function_definitions[node.name] = {
            'file': str(self.file_path.name), 'line': node.lineno, 'type': 'function'
        }
        self.generic_visit(node)
        
    def visit_ClassDef(self, node: ast.ClassDef):
        """Collects class definitions."""
        self.class_definitions[node.name] = {
            'file': str(self.file_path.name), 'line': node.lineno, 'type': 'class'
        }
        self.generic_visit(node)

    def visit_Call(self, node: ast.Call):
        """Identify function calls."""
        func_name: Optional[str] = None
        if isinstance(node.func, ast.Name):
            func_name = node.func.id
        elif isinstance(node.func, ast.Attribute):
            # Handle object.method or module.function (simplistic identification)
            if isinstance(node.func.value, ast.Name):
                func_name = f"{node.func.value.id}.{node.func.attr}"
            else:
                func_name = node.func.attr
        
        if func_name and func_name not in self.BUILTINS:
            self.function_calls.append({
                'file': str(self.file_path.name),
                'line': node.lineno,
                'function': func_name
            })
        self.generic_visit(node)
        

# ---------------------
# Code Analysis Module (Orchestrator)
# ---------------------

class CodeAnalysisModule:
    """A high-level module to manage lightweight analysis across a project."""
    
    def run_analysis(self, root_path: str, file_pattern: str = "*.py") -> Dict[str, Any]:
        """Scans a directory for files and runs both analyses."""
        root = Path(root_path)
        if not root.is_dir():
            return {"error": f"Path is not a valid directory: {root_path}"}
            
        lca_results: List[Dict[str, Any]] = []
        dda_results: List[Dict[str, Any]] = []
        all_defined_functions: Dict[str, Any] = {}
        all_called_functions: Set[str] = set()
        
        file_paths = list(root.rglob(file_pattern))
        
        for file_path in file_paths:
            try:
                code_content = file_path.read_text(encoding="utf-8")
            except Exception as e:
                lca_results.append({"file": str(file_path), "errors": [f"File read error: {e}"]})
                continue
            
            # 1. Run Lightweight Code Analyser
            lca = LightweightCodeAnalyser(file_path)
            lca_results.append(lca.analyze(code_content))
            
            # 2. Run Lightweight Dependency Analyser
            dda = LightweightDependencyAnalyser(file_path)
            dda_result = dda.analyze(code_content)
            dda_results.append(dda_result)

            # Aggregate definitions and calls for whole-project analysis
            for func_name, data in dda_result['function_definitions'].items():
                # Use a unique key (e.g., function_name@filename) to track definitions 
                # This simplistic model only tracks non-duplex definitions (i.e., not methods)
                if func_name not in all_defined_functions:
                    all_defined_functions[func_name] = data
                    
            for call_data in dda_result['function_calls']:
                # Simplify call name for usage check (removes module/object prefix)
                simple_name = call_data['function'].split('.')[-1]
                all_called_functions.add(simple_name)

        # 3. Post-analysis: Identify potentially unused functions (project-wide)
        summary_unused_functions: List[str] = []
        for func_name, data in all_defined_functions.items():
            if func_name not in all_called_functions:
                summary_unused_functions.append(f"{func_name} (defined in {data['file']} at line {data['line']})")


        return {
            "root_path": root_path,
            "files_analyzed": len(file_paths),
            "lca_results": lca_results,
            "dda_results": dda_results,
            "summary_unused_functions": summary_unused_functions
        }