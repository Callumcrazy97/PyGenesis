"""
Conversation Management System for Nova

Handles storage, loading, and management of conversation histories.
"""
import json
import uuid
import re
from datetime import datetime
from pathlib import Path
from typing import List, Dict, Optional, Any
from dataclasses import dataclass, asdict
from core.models import ChatMessage, Sender


@dataclass
class Conversation:
    """Represents a single conversation."""
    id: str
    title: str
    created_at: str
    updated_at: str
    messages: List[Dict[str, Any]]
    is_global: bool = False  # If True, conversation is available across all projects
    
    def to_dict(self) -> Dict:
        """Convert to dictionary for JSON serialization."""
        return asdict(self)
    
    @classmethod
    def from_dict(cls, data: Dict) -> 'Conversation':
        """Create from dictionary."""
        # Handle backward compatibility - old conversations don't have is_global
        if 'is_global' not in data:
            data['is_global'] = False
        return cls(**data)


class ConversationManager:
    """Manages conversations: storage, loading, CRUD operations."""
    
    def __init__(self, storage_dir: Optional[Path] = None, global_storage_dir: Optional[Path] = None):
        """
        Initialize conversation manager.
        
        Args:
            storage_dir: Directory to store project-specific conversations. Defaults to Nova/data/conversations/
            global_storage_dir: Directory to store global conversations. Defaults to Nova/data/conversations/global/
        """
        if storage_dir is None:
            # Default to Nova/data/conversations/
            nova_dir = Path(__file__).parent.parent.parent
            storage_dir = nova_dir / "data" / "conversations"
        
        if global_storage_dir is None:
            # Default global storage
            nova_dir = Path(__file__).parent.parent.parent
            global_storage_dir = nova_dir / "data" / "conversations" / "global"
        
        self.storage_dir = Path(storage_dir)
        self.storage_dir.mkdir(parents=True, exist_ok=True)
        
        self.global_storage_dir = Path(global_storage_dir)
        self.global_storage_dir.mkdir(parents=True, exist_ok=True)
        
        self.current_conversation_id: Optional[str] = None
        self._conversations_cache: Dict[str, Conversation] = {}
    
    def create_conversation(self, title: Optional[str] = None, is_global: bool = False) -> Conversation:
        """
        Create a new conversation.
        
        Args:
            title: Optional title. If None, will be auto-generated.
            is_global: If True, create as a global conversation (available across all projects).
            
        Returns:
            New Conversation object
        """
        conversation_id = str(uuid.uuid4())
        now = datetime.now().isoformat()
        
        conversation = Conversation(
            id=conversation_id,
            title=title or "New Chat",
            created_at=now,
            updated_at=now,
            messages=[],
            is_global=is_global
        )
        
        self._conversations_cache[conversation_id] = conversation
        self._save_conversation(conversation)
        
        return conversation
    
    def get_conversation(self, conversation_id: str) -> Optional[Conversation]:
        """Get conversation by ID (checks both project-specific and global storage)."""
        if conversation_id in self._conversations_cache:
            return self._conversations_cache[conversation_id]
        
        # Try loading from project-specific storage first
        conversation_file = self.storage_dir / f"{conversation_id}.json"
        if conversation_file.exists():
            try:
                with open(conversation_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                conversation = Conversation.from_dict(data)
                self._conversations_cache[conversation_id] = conversation
                return conversation
            except Exception as e:
                print(f"Error loading conversation {conversation_id}: {e}")
        
        # Try loading from global storage
        global_conversation_file = self.global_storage_dir / f"{conversation_id}.json"
        if global_conversation_file.exists():
            try:
                with open(global_conversation_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                conversation = Conversation.from_dict(data)
                conversation.is_global = True  # Ensure flag is set
                self._conversations_cache[conversation_id] = conversation
                return conversation
            except Exception as e:
                print(f"Error loading global conversation {conversation_id}: {e}")
        
        return None
    
    def get_current_conversation(self) -> Optional[Conversation]:
        """Get the currently active conversation."""
        if self.current_conversation_id:
            return self.get_conversation(self.current_conversation_id)
        return None
    
    def ensure_conversation_exists(self) -> Conversation:
        """
        Ensure at least one conversation exists.
        If no conversations exist, creates a new one.
        If current conversation is None but conversations exist, sets the first one as current.
        
        Returns:
            The current (or newly created) Conversation
        """
        # Check if current conversation exists
        current = self.get_current_conversation()
        if current:
            return current
        
        # No current conversation - check if any exist
        conversations = self.list_conversations()
        if conversations:
            # Use the most recent one
            self.set_current_conversation(conversations[0].id)
            return conversations[0]
        
        # No conversations at all - create a new one
        new_conversation = self.create_conversation()
        self.set_current_conversation(new_conversation.id)
        return new_conversation
    
    def set_current_conversation(self, conversation_id: str):
        """Set the current active conversation."""
        self.current_conversation_id = conversation_id
    
    def list_conversations(self) -> List[Conversation]:
        """
        List all conversations (both project-specific and global), sorted by updated_at (newest first).
        
        Returns:
            List of Conversation objects
        """
        conversations = []
        
        # Load project-specific conversations
        for conversation_file in self.storage_dir.glob("*.json"):
            try:
                conversation_id = conversation_file.stem
                if conversation_id in self._conversations_cache:
                    conv = self._conversations_cache[conversation_id]
                    if not conv.is_global:  # Only add if not already marked as global
                        conversations.append(conv)
                else:
                    with open(conversation_file, 'r', encoding='utf-8') as f:
                        data = json.load(f)
                    conversation = Conversation.from_dict(data)
                    conversation.is_global = False  # Project-specific
                    self._conversations_cache[conversation_id] = conversation
                    conversations.append(conversation)
            except Exception as e:
                print(f"Error loading conversation from {conversation_file}: {e}")
        
        # Load global conversations
        for conversation_file in self.global_storage_dir.glob("*.json"):
            try:
                conversation_id = conversation_file.stem
                if conversation_id in self._conversations_cache:
                    conv = self._conversations_cache[conversation_id]
                    if conv.is_global:
                        conversations.append(conv)
                else:
                    with open(conversation_file, 'r', encoding='utf-8') as f:
                        data = json.load(f)
                    conversation = Conversation.from_dict(data)
                    conversation.is_global = True  # Mark as global
                    self._conversations_cache[conversation_id] = conversation
                    conversations.append(conversation)
            except Exception as e:
                print(f"Error loading global conversation from {conversation_file}: {e}")
        
        # Sort by updated_at (newest first)
        conversations.sort(key=lambda c: c.updated_at, reverse=True)
        return conversations
    
    def add_message(self, conversation_id: str, message: ChatMessage):
        """
        Add a message to a conversation.
        
        Args:
            conversation_id: ID of the conversation
            message: ChatMessage to add
        """
        conversation = self.get_conversation(conversation_id)
        if not conversation:
            # Conversation doesn't exist - ensure one exists and use it
            conversation = self.ensure_conversation_exists()
            if not conversation:
                return
        
        # Convert message to dict
        message_dict = {
            "sender": message.sender.name if isinstance(message.sender, Sender) else str(message.sender),
            "text": message.text,
            "timestamp": message.timestamp.isoformat() if hasattr(message.timestamp, 'isoformat') else str(message.timestamp),
            "thinking_content": message.thinking_content,
            "operation_plan": None,  # Don't store operation plans in conversations
            "clarification_context": None,  # Don't store clarification context
            "intent": message.intent.name if message.intent and hasattr(message.intent, 'name') else (message.intent.value if message.intent else None)  # Store intent for context awareness
        }
        
        conversation.messages.append(message_dict)
        conversation.updated_at = datetime.now().isoformat()
        
        self._save_conversation(conversation)
    
    def rename_conversation(self, conversation_id: str, new_title: str):
        """Rename a conversation."""
        conversation = self.get_conversation(conversation_id)
        if conversation:
            conversation.title = new_title
            conversation.updated_at = datetime.now().isoformat()
            self._save_conversation(conversation)
    
    def delete_conversation(self, conversation_id: str):
        """Delete a conversation (from both project-specific and global storage)."""
        # Remove from cache
        if conversation_id in self._conversations_cache:
            conv = self._conversations_cache[conversation_id]
            del self._conversations_cache[conversation_id]
            # Delete from appropriate location
            if conv.is_global:
                conversation_file = self.global_storage_dir / f"{conversation_id}.json"
            else:
                conversation_file = self.storage_dir / f"{conversation_id}.json"
        else:
            # Try both locations
            conversation_file = self.storage_dir / f"{conversation_id}.json"
            global_file = self.global_storage_dir / f"{conversation_id}.json"
            
            if global_file.exists():
                global_file.unlink()
            if conversation_file.exists():
                conversation_file.unlink()
            return
        
        # Delete file
        if conversation_file.exists():
            conversation_file.unlink()
        
        # Also check the other location (in case of inconsistency)
        other_file = self.global_storage_dir / f"{conversation_id}.json" if not conv.is_global else self.storage_dir / f"{conversation_id}.json"
        if other_file.exists():
            other_file.unlink()
        
        # Clear current conversation if it was deleted
        if self.current_conversation_id == conversation_id:
            self.current_conversation_id = None
    
    def generate_summary(self, conversation: Conversation, intent_router=None) -> str:
        """
        Generate a summary/title for a conversation based on its messages.
        Uses intent classification and smart naming patterns.
        
        Args:
            conversation: Conversation to summarize
            intent_router: Optional IntentRouter for intent classification
            
        Returns:
            Summary string (max 50 characters)
        """
        if not conversation.messages:
            return "New Chat"
        
        # Get first user message (usually contains the main topic)
        first_user_message = None
        for msg in conversation.messages:
            if msg.get("sender") == "USER":
                first_user_message = msg.get("text", "").strip()
                if first_user_message:
                    break
        
        if not first_user_message:
            # Fallback: use first message regardless of sender
            if conversation.messages:
                first_user_message = conversation.messages[0].get("text", "").strip()
        
        if not first_user_message:
            return "New Chat"
        
        # Try to classify intent for smarter naming
        intent_name = None
        if intent_router:
            try:
                intent_result = intent_router.classify(first_user_message)
                intent_name = intent_result.primary_intent.value if intent_result.primary_intent else None
            except Exception:
                pass  # Fallback to pattern-based naming
        
        # Smart naming based on intent and patterns
        text_lower = first_user_message.lower()
        
        # Intent-based naming (check FIRST, before patterns)
        if intent_name:
            intent_names = {
                "math_query": "Math Question",
                "research_query": "Research Query",
                "code_query": "Code Question",
                "code_search": "Code Search",
                "project_modification": "Project Edit",
                "resource_operation": "Resource Operation",
                "dictionary_lookup": "Dictionary Lookup",
                "thesaurus_lookup": "Thesaurus Lookup",
                "graph_visualization": "Dependency Graph",
                "general_chat": None,  # Will use pattern-based fallback
            }
            if intent_name in intent_names and intent_names[intent_name]:
                return intent_names[intent_name]
        
        # Greeting patterns (only check if not already classified as something else)
        greeting_patterns = [
            (r'^(hi|hello|hey|greetings|good morning|good afternoon|good evening)[\s,!.]*$', "Nova Greeting"),
            (r'^(how are you|how\'?s it going|what\'?s up)[\s,!.]*$', "Nova Greeting"),
        ]
        
        for pattern, name in greeting_patterns:
            if re.match(pattern, text_lower):
                return name
        
        # Pattern-based naming for common queries
        patterns = [
            (r'\b(what is|what\'?s|define|explain)\s+(\w+)', lambda m: f"About {m.group(2).title()}"),
            (r'\b(how to|how do|how does)\s+(\w+)', lambda m: f"How to {m.group(2).title()}"),
            (r'\b(create|make|add|new)\s+(\w+)', lambda m: f"Create {m.group(2).title()}"),
            (r'\b(edit|modify|change|update)\s+(\w+)', lambda m: f"Edit {m.group(2).title()}"),
            (r'\b(delete|remove)\s+(\w+)', lambda m: f"Delete {m.group(2).title()}"),
            (r'\b(find|search|look for)\s+(\w+)', lambda m: f"Find {m.group(2).title()}"),
            (r'\b(calculate|solve|compute)\s+(.+)', lambda m: "Math Calculation"),
            (r'\b(sprite|object|room|sound|model|texture|background)\b', lambda m: "Resource Question"),
        ]
        
        for pattern, name_func in patterns:
            match = re.search(pattern, text_lower)
            if match:
                try:
                    name = name_func(match)
                    if name and len(name) <= 50:
                        return name
                except Exception:
                    pass
        
        # Extract key words (nouns, important terms)
        # Remove common stop words
        stop_words = {'the', 'a', 'an', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for', 'of', 'with', 'by', 'is', 'are', 'was', 'were', 'be', 'been', 'being', 'have', 'has', 'had', 'do', 'does', 'did', 'will', 'would', 'could', 'should', 'may', 'might', 'must', 'can', 'this', 'that', 'these', 'those', 'i', 'you', 'he', 'she', 'it', 'we', 'they', 'what', 'which', 'who', 'where', 'when', 'why', 'how'}
        
        words = re.findall(r'\b\w+\b', text_lower)
        important_words = [w for w in words if w not in stop_words and len(w) > 2][:3]
        
        if important_words:
            # Capitalize first letter of each word
            title = ' '.join(w.capitalize() for w in important_words)
            if len(title) <= 50:
                return title
        
        # Fallback: use first 50 characters
        summary = first_user_message[:50]
        if len(first_user_message) > 50:
            summary += "..."
        return summary
    
    def update_conversation_summary(self, conversation_id: str, intent_router=None):
        """
        Update conversation title with auto-generated summary.
        
        Args:
            conversation_id: ID of conversation to update
            intent_router: Optional IntentRouter for intent classification
        """
        conversation = self.get_conversation(conversation_id)
        if conversation:
            # Only auto-update if it's still the default title
            default_titles = ["New Chat", "New Conversation", ""]
            if conversation.title in default_titles or not conversation.title:
                conversation.title = self.generate_summary(conversation, intent_router)
                conversation.updated_at = datetime.now().isoformat()
                self._save_conversation(conversation)
    
    def _save_conversation(self, conversation: Conversation):
        """Save conversation to disk (project-specific or global based on is_global flag)."""
        if conversation.is_global:
            conversation_file = self.global_storage_dir / f"{conversation.id}.json"
            # Remove from project-specific storage if it exists there
            project_file = self.storage_dir / f"{conversation.id}.json"
            if project_file.exists():
                try:
                    project_file.unlink()
                except Exception:
                    pass
        else:
            conversation_file = self.storage_dir / f"{conversation.id}.json"
            # Remove from global storage if it exists there
            global_file = self.global_storage_dir / f"{conversation.id}.json"
            if global_file.exists():
                try:
                    global_file.unlink()
                except Exception:
                    pass
        
        try:
            with open(conversation_file, 'w', encoding='utf-8') as f:
                json.dump(conversation.to_dict(), f, indent=2, ensure_ascii=False)
        except Exception as e:
            print(f"Error saving conversation {conversation.id}: {e}")
    
    def toggle_global(self, conversation_id: str) -> bool:
        """
        Toggle the global status of a conversation.
        
        Args:
            conversation_id: ID of the conversation to toggle
            
        Returns:
            New is_global status (True if now global, False if now project-specific)
        """
        conversation = self.get_conversation(conversation_id)
        if not conversation:
            return False
        
        # Toggle the flag
        conversation.is_global = not conversation.is_global
        conversation.updated_at = datetime.now().isoformat()
        
        # Save to new location (will handle moving the file)
        self._save_conversation(conversation)
        
        return conversation.is_global
    
    def export_for_training(self, conversation_id: str, intent_router=None) -> List[Dict[str, str]]:
        """
        Export conversation messages for training (if enabled).
        
        Args:
            conversation_id: ID of conversation to export
            intent_router: Optional IntentRouter instance for classifying messages
            
        Returns:
            List of {"text": str, "intent": str} dictionaries
        """
        from settings import SETTINGS
        
        # Only export if training on chats is enabled
        if not SETTINGS.TrainOnChats:
            return []
        
        conversation = self.get_conversation(conversation_id)
        if not conversation:
            return []
        
        training_data = []
        # Extract user messages and classify intent
        
        for msg in conversation.messages:
            if msg.get("sender") == "USER":
                text = msg.get("text", "").strip()
                if text:
                    # Try to classify intent if router is available
                    if intent_router:
                        try:
                            intent_result = intent_router.classify(text)
                            intent_name = intent_result.primary_intent.value
                        except Exception:
                            intent_name = "chat"  # Fallback
                    else:
                        intent_name = "chat"  # Default fallback
                    
                    training_data.append({
                        "text": text,
                        "intent": intent_name
                    })
        
        return training_data
    
    def export_all_for_training(self) -> List[Dict[str, str]]:
        """Export all conversations for training."""
        all_data = []
        for conversation in self.list_conversations():
            all_data.extend(self.export_for_training(conversation.id))
        return all_data

