"""
Integrated Codebase Analyzer for Nova
Uses Python AST to analyze code-containing files in PyGenesis projects
"""

import ast
import os
from pathlib import Path
from typing import Dict, List, Set, Any, Optional
from collections import Counter, defaultdict


class CodebaseAnalyzer:
    """Analyzes codebase using Python AST"""
    
    def __init__(self):
        self.code_extensions = {'.object', '.script', '.shader', '.pgsl', '.py'}
        self.ignored_dirs = {
            '.git', '.idea', '.vscode', '__pycache__', 'venv', '.venv',
            'env', '.env', 'node_modules', 'dist', 'build', '.mypy_cache',
            '.pytest_cache', '.tox'
        }
    
    def find_code_files(self, root_path: str) -> List[str]:
        """Find all code-containing files in the project"""
        root = Path(root_path)
        code_files = []
        
        # Search in Resources folder
        resources_path = root / "Resources"
        if resources_path.exists():
            for ext in self.code_extensions:
                for file_path in resources_path.rglob(f"*{ext}"):
                    if file_path.is_file():
                        # Skip ignored directories
                        if any(ignored in file_path.parts for ignored in self.ignored_dirs):
                            continue
                        code_files.append(str(file_path))
        
        return sorted(code_files)
    
    def analyze_codebase(self, root_path: str) -> Dict[str, Any]:
        """Analyze the codebase and return summary"""
        root = Path(root_path)
        code_files = self.find_code_files(root_path)
        
        if not code_files:
            return {
                "no_code": True,
                "code_files": [],
                "root_path": str(root_path)
            }
        
        file_ext_counts = Counter()
        total_files = 0
        total_bytes = 0
        python_files = []
        pgsl_files = []
        errors = []
        warnings = []
        functions = []
        classes = []
        imports = []
        
        for file_path_str in code_files:
            file_path = Path(file_path_str)
            try:
                ext = file_path.suffix.lower()
                file_ext_counts[ext or "<no-ext>"] += 1
                total_files += 1
                
                size = file_path.stat().st_size
                total_bytes += size
                
                # Try to parse as Python/PGSL code
                try:
                    content = file_path.read_text(encoding="utf-8", errors="ignore")
                    
                    # Parse with AST if it's Python code
                    if ext == '.py':
                        tree = ast.parse(content, filename=str(file_path))
                        python_files.append({
                            "path": str(file_path.relative_to(root)),
                            "size": size,
                            "lines": len(content.splitlines())
                        })
                        
                        # Extract functions, classes, imports
                        for node in ast.walk(tree):
                            if isinstance(node, ast.FunctionDef):
                                functions.append({
                                    "name": node.name,
                                    "file": str(file_path.relative_to(root)),
                                    "line": node.lineno
                                })
                            elif isinstance(node, ast.ClassDef):
                                classes.append({
                                    "name": node.name,
                                    "file": str(file_path.relative_to(root)),
                                    "line": node.lineno
                                })
                            elif isinstance(node, (ast.Import, ast.ImportFrom)):
                                if isinstance(node, ast.Import):
                                    for alias in node.names:
                                        imports.append(alias.name)
                                else:
                                    imports.append(node.module or "")
                    
                    elif ext in {'.object', '.script', '.shader', '.pgsl'}:
                        # PGSL files - count lines and basic info
                        pgsl_files.append({
                            "path": str(file_path.relative_to(root)),
                            "size": size,
                            "lines": len(content.splitlines())
                        })
                
                except SyntaxError as e:
                    errors.append(f"{file_path.relative_to(root)}: Syntax error at line {e.lineno}: {e.msg}")
                except Exception as e:
                    warnings.append(f"{file_path.relative_to(root)}: {str(e)}")
            
            except Exception as e:
                errors.append(f"{file_path}: {str(e)}")
        
        # Calculate summary stats
        kb = total_bytes / 1024 if total_bytes else 0
        mb = kb / 1024 if kb else 0
        size_str = f"{mb:.1f} MB" if mb >= 1 else f"{kb:.1f} KB"
        
        return {
            "no_code": False,
            "code_files": code_files,
            "root_path": str(root_path),
            "total_files": total_files,
            "total_size": size_str,
            "file_extensions": dict(file_ext_counts),
            "python_files": python_files[:20],  # Top 20
            "pgsl_files": pgsl_files[:20],  # Top 20
            "functions": functions,
            "classes": classes,
            "imports": list(set(imports))[:50],  # Unique imports, top 50
            "errors": errors,
            "warnings": warnings
        }
    
    def analyze_dependencies(self, root_path: str) -> Dict[str, Any]:
        """Analyze dependencies between code files"""
        code_files = self.find_code_files(root_path)
        
        if not code_files:
            return {
                "no_code": True,
                "code_files": []
            }
        
        root = Path(root_path)
        dependencies = defaultdict(list)
        file_imports = {}
        
        for file_path_str in code_files:
            file_path = Path(file_path_str)
            if file_path.suffix != '.py':
                continue
            
            try:
                content = file_path.read_text(encoding="utf-8", errors="ignore")
                tree = ast.parse(content, filename=str(file_path))
                
                file_imports[str(file_path.relative_to(root))] = []
                
                for node in ast.walk(tree):
                    if isinstance(node, ast.Import):
                        for alias in node.names:
                            module = alias.name
                            file_imports[str(file_path.relative_to(root))].append(module)
                            dependencies[module].append(str(file_path.relative_to(root)))
                    elif isinstance(node, ast.ImportFrom):
                        if node.module:
                            file_imports[str(file_path.relative_to(root))].append(node.module)
                            dependencies[node.module].append(str(file_path.relative_to(root)))
            
            except Exception:
                pass
        
        return {
            "no_code": False,
            "code_files": code_files,
            "dependencies": dict(dependencies),
            "file_imports": file_imports
        }

