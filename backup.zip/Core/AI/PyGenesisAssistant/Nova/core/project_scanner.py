"""
Project Scanner - Discovers and scans Python projects.
Integrates with AST Scanner to build project knowledge.
"""
import os
from typing import Dict, List, Optional, Set
from pathlib import Path

from core.ast_scanner import ASTScanner, FileAnalysis


class ProjectScanner:
    """Scans entire Python projects and builds knowledge base."""
    
    def __init__(self, root_directory: Optional[str] = None):
        """
        Initialize project scanner.
        
        Args:
            root_directory: Root directory of the project (defaults to current directory)
        """
        self.root_directory = root_directory or os.getcwd()
        self.ast_scanner = ASTScanner()
        self.project_structure: Optional[Dict] = None
        self.has_scanned = False  # Cache flag to prevent repeated scans
    
    def scan_project(self, directory: Optional[str] = None) -> Dict:
        """
        Scan the entire project.
        
        Args:
            directory: Directory to scan (defaults to root_directory)
            
        Returns:
            Project structure dictionary
        """
        scan_dir = directory or self.root_directory
        
        if not os.path.exists(scan_dir):
            return {
                "error": f"Directory not found: {scan_dir}",
                "root": scan_dir,
                "files": {},
                "statistics": {}
            }
        
        self.project_structure = self.ast_scanner.get_project_structure(scan_dir)
        return self.project_structure
    
    def find_class(self, class_name: str) -> List[Dict]:
        """
        Find all classes with a given name.
        
        Args:
            class_name: Name of the class to find
            
        Returns:
            List of class information dictionaries
        """
        if not self.project_structure:
            self.scan_project()
        
        results = []
        for cls_info in self.project_structure.get("classes", []):
            if cls_info["name"].lower() == class_name.lower():
                results.append(cls_info)
        
        return results
    
    def find_function(self, function_name: str) -> List[Dict]:
        """
        Find all functions with a given name.
        
        Args:
            function_name: Name of the function to find
            
        Returns:
            List of function information dictionaries
        """
        if not self.project_structure:
            self.scan_project()
        
        results = []
        for func_info in self.project_structure.get("functions", []):
            if func_info["name"].lower() == function_name.lower():
                results.append(func_info)
        
        return results
    
    def get_file_analysis(self, file_path: str) -> Optional[FileAnalysis]:
        """
        Get analysis for a specific file.
        
        Args:
            file_path: Path to the file (relative or absolute)
            
        Returns:
            FileAnalysis object or None if not found
        """
        # Try relative path first
        rel_path = os.path.join(self.root_directory, file_path)
        if os.path.exists(rel_path):
            return self.ast_scanner.scan_file(rel_path)
        
        # Try absolute path
        if os.path.exists(file_path):
            return self.ast_scanner.scan_file(file_path)
        
        return None
    
    def get_dependencies(self, file_path: Optional[str] = None) -> Dict[str, List[str]]:
        """
        Get import dependencies.
        
        Args:
            file_path: Specific file to analyze (None for entire project)
            
        Returns:
            Dictionary mapping modules to files that import them
        """
        if file_path:
            analysis = self.get_file_analysis(file_path)
            if analysis:
                deps = {}
                for imp in analysis.imports:
                    if imp.module not in deps:
                        deps[imp.module] = []
                    deps[imp.module].append(file_path)
                return deps
        
        if not self.project_structure:
            self.scan_project()
        
        return self.project_structure.get("imports", {})
    
    def get_class_methods(self, class_name: str, file_path: Optional[str] = None) -> List[Dict]:
        """
        Get methods of a specific class.
        
        Args:
            class_name: Name of the class
            file_path: Specific file to check (None for all files)
            
        Returns:
            List of method information dictionaries
        """
        if file_path:
            analysis = self.get_file_analysis(file_path)
            if analysis:
                for cls in analysis.classes:
                    if cls.name == class_name:
                        return [
                            {
                                "name": m.name,
                                "line": m.line_start,
                                "args": m.args,
                                "docstring": m.docstring,
                            }
                            for m in cls.methods
                        ]
            return []
        
        # Search all files
        classes = self.find_class(class_name)
        methods = []
        
        for cls_info in classes:
            analysis = self.get_file_analysis(cls_info["file"])
            if analysis:
                for cls in analysis.classes:
                    if cls.name == class_name:
                        for m in cls.methods:
                            methods.append({
                                "name": m.name,
                                "file": cls_info["file"],
                                "line": m.line_start,
                                "args": m.args,
                                "docstring": m.docstring,
                            })
        
        return methods
    
    def get_statistics(self) -> Dict:
        """Get project statistics."""
        if not self.project_structure:
            self.scan_project()
        
        return self.project_structure.get("statistics", {})

