"""
API Surface Manifest - Nova's "Constitution"

Defines all legal PyGenesis operations that Nova can perform.
This is the single source of truth for capability validation.

Every operation Nova plans must validate against this manifest.
"""

from typing import Dict, List, Tuple, Optional, Any
from dataclasses import dataclass


@dataclass
class APIMethod:
    """Represents a single API method definition."""
    name: str
    params: List[str]
    returns: str
    description: str
    signals: List[str] = None  # Qt signals emitted
    requires_project: bool = False  # Requires open project
    requires_resource: bool = False  # Requires specific resource
    side_effects: List[str] = None  # What this operation affects


# API Surface Manifest
# This defines all legal operations Nova can perform
API_SURFACE = {
    "ResourceManager": {
        "create_resource": APIMethod(
            name="create_resource",
            params=["resource_type", "name", "parent_folder"],
            returns="dict",
            description="Creates a new resource with default properties",
            signals=["resource_created"],
            requires_project=True,
            side_effects=["file_system", "runtime_resources", "project_data"]
        ),
        "load_resource": APIMethod(
            name="load_resource",
            params=["resource_type", "resource_id"],
            returns="dict",
            description="Loads a resource by ID from runtime or disk",
            requires_project=True,
            side_effects=[]  # Read-only
        ),
        "load_resource_from_disk": APIMethod(
            name="load_resource_from_disk",
            params=["resource_type", "resource_id"],
            returns="dict",
            description="Loads a resource directly from disk file",
            requires_project=True,
            side_effects=[]  # Read-only
        ),
        "get_resource_file_path": APIMethod(
            name="get_resource_file_path",
            params=["resource_type", "resource_data"],
            returns="str",
            description="Gets the file path for a resource",
            requires_project=True,
            side_effects=[]  # Read-only
        ),
        "update_resource": APIMethod(
            name="update_resource",
            params=["resource_type", "resource_id", "updates"],
            returns="bool",
            description="Updates resource properties",
            signals=["resource_updated"],
            requires_project=True,
            requires_resource=True,
            side_effects=["file_system", "runtime_resources", "project_data"]
        ),
        "save_resource": APIMethod(
            name="save_resource",
            params=["resource_type", "resource_data", "file_path"],
            returns="bool",
            description="Saves a resource to disk and updates runtime",
            signals=["resource_updated"],
            requires_project=True,
            side_effects=["file_system", "runtime_resources", "project_data"]
        ),
        "save_resource_file_only": APIMethod(
            name="save_resource_file_only",
            params=["resource_type", "resource_data", "file_path"],
            returns="bool",
            description="Saves only the resource file without updating project data",
            requires_project=True,
            side_effects=["file_system"]
        ),
        "delete_resource": APIMethod(
            name="delete_resource",
            params=["resource_type", "resource_id", "skip_undo_record"],
            returns="bool",
            description="Deletes a resource and its associated files",
            signals=["resource_deleted"],
            requires_project=True,
            requires_resource=True,
            side_effects=["file_system", "runtime_resources", "project_data"]
        ),
        "rename_resource": APIMethod(
            name="rename_resource",
            params=["resource_type", "resource_id", "new_name", "skip_undo_record"],
            returns="bool",
            description="Renames a resource and updates associated files",
            signals=["resource_updated"],
            requires_project=True,
            requires_resource=True,
            side_effects=["file_system", "runtime_resources", "project_data"]
        ),
        "move_resource": APIMethod(
            name="move_resource",
            params=["resource_type", "resource_id", "new_parent_folder"],
            returns="bool",
            description="Moves a resource to a different folder",
            signals=["resource_updated"],
            requires_project=True,
            requires_resource=True,
            side_effects=["file_system", "runtime_resources", "project_data"]
        ),
        "get_cached_texture": APIMethod(
            name="get_cached_texture",
            params=["texture_path"],
            returns="dict",
            description="Gets a cached texture by path",
            side_effects=[]  # Read-only
        ),
        "cache_texture": APIMethod(
            name="cache_texture",
            params=["texture_path", "texture_id", "width", "height", "format"],
            returns="None",
            description="Caches a loaded texture with reference counting",
            side_effects=["texture_cache"]
        ),
        "release_texture": APIMethod(
            name="release_texture",
            params=["texture_path"],
            returns="bool",
            description="Releases a reference to a cached texture",
            side_effects=["texture_cache"]
        ),
        "remove_texture_from_cache": APIMethod(
            name="remove_texture_from_cache",
            params=["texture_path"],
            returns="None",
            description="Removes a texture from cache entirely",
            side_effects=["texture_cache"]
        ),
        "get_cached_materials": APIMethod(
            name="get_cached_materials",
            params=["resource_id"],
            returns="dict",
            description="Gets cached materials for a resource",
            side_effects=[]  # Read-only
        ),
        "cache_materials": APIMethod(
            name="cache_materials",
            params=["resource_id", "materials"],
            returns="None",
            description="Caches normalized materials for a resource",
            side_effects=["material_cache"]
        ),
        "remove_materials_from_cache": APIMethod(
            name="remove_materials_from_cache",
            params=["resource_id"],
            returns="None",
            description="Removes cached materials for a resource",
            side_effects=["material_cache"]
        ),
        "get_cached_model": APIMethod(
            name="get_cached_model",
            params=["model_path"],
            returns="dict",
            description="Gets cached parsed model geometry",
            side_effects=[]  # Read-only
        ),
        "cache_model": APIMethod(
            name="cache_model",
            params=["model_path", "vertices", "indices"],
            returns="None",
            description="Caches parsed model geometry",
            side_effects=["model_cache"]
        ),
        "clear_cache": APIMethod(
            name="clear_cache",
            params=["cache_type"],
            returns="None",
            description="Clears resource caches",
            side_effects=["texture_cache", "material_cache", "model_cache"]
        ),
        "get_cache_stats": APIMethod(
            name="get_cache_stats",
            params=[],
            returns="dict",
            description="Gets statistics about cached resources",
            side_effects=[]  # Read-only
        ),
        "set_undo_redo_manager": APIMethod(
            name="set_undo_redo_manager",
            params=["undo_redo_manager"],
            returns="None",
            description="Sets the undo/redo manager reference",
            side_effects=["undo_redo_manager"]
        ),
        "restore_resource": APIMethod(
            name="restore_resource",
            params=["resource_type", "resource_data", "skip_undo_record"],
            returns="bool",
            description="Restores a resource from saved data (for undo/redo)",
            signals=["resource_created"],
            requires_project=True,
            side_effects=["file_system", "runtime_resources", "project_data"]
        ),
    },
    
    "ProjectManager": {
        "create_project": APIMethod(
            name="create_project",
            params=["project_path", "project_name"],
            returns="bool",
            description="Creates a new project with directory structure",
            signals=["project_created"],
            side_effects=["file_system", "project_state"]
        ),
        "load_project": APIMethod(
            name="load_project",
            params=["project_path"],
            returns="bool",
            description="Loads an existing project (async)",
            signals=["project_loaded", "resources_loaded"],
            side_effects=["project_state", "runtime_resources"]
        ),
        "save_project": APIMethod(
            name="save_project",
            params=[],
            returns="bool",
            description="Saves the current project",
            signals=["project_saved"],
            requires_project=True,
            side_effects=["file_system", "project_data"]
        ),
        "purge_files_not_in_project": APIMethod(
            name="purge_files_not_in_project",
            params=[],
            returns="None",
            description="Removes files not referenced in project metadata",
            requires_project=True,
            side_effects=["file_system"]
        ),
        "get_project_name": APIMethod(
            name="get_project_name",
            params=[],
            returns="str",
            description="Gets the current project name",
            requires_project=True,
            side_effects=[]  # Read-only
        ),
        "get_project_path": APIMethod(
            name="get_project_path",
            params=[],
            returns="str",
            description="Gets the current project path",
            requires_project=True,
            side_effects=[]  # Read-only
        ),
        "get_project_data": APIMethod(
            name="get_project_data",
            params=[],
            returns="dict",
            description="Gets the current project data",
            requires_project=True,
            side_effects=[]  # Read-only
        ),
        "get_runtime_resources": APIMethod(
            name="get_runtime_resources",
            params=["resource_type"],
            returns="list",
            description="Gets all runtime resources of a type",
            requires_project=True,
            side_effects=[]  # Read-only
        ),
        "get_runtime_resource": APIMethod(
            name="get_runtime_resource",
            params=["resource_type", "resource_id"],
            returns="dict",
            description="Gets a specific runtime resource",
            requires_project=True,
            side_effects=[]  # Read-only
        ),
        "add_runtime_resource": APIMethod(
            name="add_runtime_resource",
            params=["resource_type", "resource_id", "resource_data"],
            returns="None",
            description="Adds a resource to runtime",
            requires_project=True,
            side_effects=["runtime_resources", "project_state"]
        ),
        "update_runtime_resource": APIMethod(
            name="update_runtime_resource",
            params=["resource_type", "resource_id", "resource_data"],
            returns="None",
            description="Updates a resource in runtime",
            requires_project=True,
            side_effects=["runtime_resources", "project_state"]
        ),
        "remove_runtime_resource": APIMethod(
            name="remove_runtime_resource",
            params=["resource_type", "resource_id"],
            returns="None",
            description="Removes a resource from runtime",
            requires_project=True,
            side_effects=["runtime_resources", "project_state"]
        ),
        "has_pending_changes": APIMethod(
            name="has_pending_changes",
            params=[],
            returns="bool",
            description="Checks if there are pending changes",
            requires_project=True,
            side_effects=[]  # Read-only
        ),
        "mark_project_dirty": APIMethod(
            name="mark_project_dirty",
            params=[],
            returns="None",
            description="Marks the project as having unsaved changes",
            requires_project=True,
            side_effects=["project_state"]
        ),
        "add_resource": APIMethod(
            name="add_resource",
            params=["resource_type", "resource_data"],
            returns="None",
            description="Adds a resource to project data",
            requires_project=True,
            side_effects=["project_data"]
        ),
        "remove_resource": APIMethod(
            name="remove_resource",
            params=["resource_type", "resource_id"],
            returns="None",
            description="Removes a resource from project data",
            requires_project=True,
            side_effects=["project_data"]
        ),
        "get_resources": APIMethod(
            name="get_resources",
            params=["resource_type"],
            returns="list",
            description="Gets all resources of a type from project data",
            requires_project=True,
            side_effects=[]  # Read-only
        ),
    }
}


# Resource types that Nova can work with
RESOURCE_TYPES = [
    "sprites",
    "backgrounds",
    "objects",
    "sounds",
    "models",
    "rooms",
    "textures",
    "shaders",
    "particles",
    "scripts"
]


class APIManifestValidator:
    """Validates operations against the API Surface Manifest."""
    
    def __init__(self):
        self.api_surface = API_SURFACE
        self.resource_types = RESOURCE_TYPES
    
    def validate_operation(
        self,
        operation: Dict[str, Any],
        project_open: bool = False,
        resource_exists: Optional[Tuple[str, str]] = None
    ) -> Tuple[bool, Optional[str]]:
        """
        Validate an operation against the API surface.
        
        Args:
            operation: Dict with keys:
                - "component": str (e.g., "ResourceManager")
                - "method": str (e.g., "create_resource")
                - "params": dict (method parameters)
            project_open: Whether a project is currently open
            resource_exists: Optional tuple of (resource_type, resource_id) if operation requires a resource
        
        Returns:
            Tuple of (is_valid, error_message)
        """
        if not isinstance(operation, dict):
            return False, "Operation must be a dictionary"
        
        component = operation.get("component")
        method = operation.get("method")
        params = operation.get("params", {})
        
        if not component or not method:
            return False, "Operation must specify 'component' and 'method'"
        
        if component not in self.api_surface:
            return False, f"Unknown component: {component}"
        
        if method not in self.api_surface[component]:
            return False, f"Unknown method '{method}' in component '{component}'"
        
        # Get method definition
        method_def = self.api_surface[component][method]
        
        # Check if project is required
        if method_def.requires_project and not project_open:
            return False, f"Method '{method}' requires an open project"
        
        # Check if resource is required
        if method_def.requires_resource:
            if not resource_exists:
                return False, f"Method '{method}' requires an existing resource"
            # Could add additional validation here (e.g., resource_type matches)
        
        # Validate parameters
        param_validation = self._validate_params(method_def, params)
        if not param_validation[0]:
            return param_validation
        
        return True, None
    
    def _validate_params(self, method_def: APIMethod, params: Dict[str, Any]) -> Tuple[bool, Optional[str]]:
        """Validate that required parameters are present."""
        # Check required parameters
        required_params = method_def.params
        
        # Some parameters are optional (have defaults in the method signature)
        # For now, we'll check that at least the non-optional params are present
        # This is a simplified validation - could be enhanced with type checking
        
        # Check resource_type if it's in params
        if "resource_type" in required_params:
            if "resource_type" not in params:
                return False, f"Missing required parameter: resource_type"
            if params["resource_type"] not in self.resource_types:
                return False, f"Invalid resource_type: {params['resource_type']}. Must be one of {self.resource_types}"
        
        # Check resource_id if it's in params
        if "resource_id" in required_params:
            if "resource_id" not in params:
                return False, f"Missing required parameter: resource_id"
            if not isinstance(params["resource_id"], str):
                return False, f"resource_id must be a string"
        
        return True, None
    
    def get_method_info(self, component: str, method: str) -> Optional[APIMethod]:
        """Get information about a specific API method."""
        if component not in self.api_surface:
            return None
        if method not in self.api_surface[component]:
            return None
        return self.api_surface[component][method]
    
    def list_available_methods(self, component: Optional[str] = None) -> Dict[str, List[str]]:
        """List all available methods, optionally filtered by component."""
        if component:
            if component not in self.api_surface:
                return {}
            return {component: list(self.api_surface[component].keys())}
        return {comp: list(methods.keys()) for comp, methods in self.api_surface.items()}
    
    def get_resource_types(self) -> List[str]:
        """Get list of valid resource types."""
        return self.resource_types.copy()
    
    def is_valid_resource_type(self, resource_type: str) -> bool:
        """Check if a resource type is valid."""
        return resource_type in self.resource_types


# Global validator instance
_validator = None


def get_validator() -> APIManifestValidator:
    """Get the global API manifest validator instance."""
    global _validator
    if _validator is None:
        _validator = APIManifestValidator()
    return _validator


def validate_operation(
    operation: Dict[str, Any],
    project_open: bool = False,
    resource_exists: Optional[Tuple[str, str]] = None
) -> Tuple[bool, Optional[str]]:
    """
    Convenience function to validate an operation.
    
    Example:
        operation = {
            "component": "ResourceManager",
            "method": "create_resource",
            "params": {
                "resource_type": "sprites",
                "name": "MySprite",
                "parent_folder": ""
            }
        }
        is_valid, error = validate_operation(operation, project_open=True)
    """
    validator = get_validator()
    return validator.validate_operation(operation, project_open, resource_exists)

