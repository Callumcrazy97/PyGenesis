"""
Feedback Handler - Handles user feedback for mistakes and undo requests.
"""
import re
from typing import Optional, Tuple, Dict, Any
from datetime import datetime
from pathlib import Path
import json

from core.models import Intent
from core.transaction_manager import TransactionManager
from pathlib import Path

# Path to misclassification log (same location as neural model)
MODEL_DIR = Path(__file__).parent / "slm" / "models"
MISCLASSIFICATION_LOG = MODEL_DIR / "misclassifications.json"


class FeedbackHandler:
    """Handles user feedback, undo requests, and misinformation logging."""
    
    # Patterns for detecting feedback/undo requests
    FEEDBACK_PATTERNS = [
        r'\b(revert|undo|un do)\b',
        r'\b(no|wrong|incorrect|bad|mistake|error)\b.*\b(this|that|it)\b',
        r'\b(this|that|it)\b.*\b(wrong|incorrect|bad|mistake|error)\b',
        r'\b(undo this|undo that|undo it|revert this|revert that)\b',
        r'\b(that\'?s wrong|this is wrong|it\'?s wrong)\b',
        r'\b(don\'?t do that|don\'?t do this|stop)\b',
        r'\b(cancel|abort|stop)\b',
        r'\b(not what i wanted|not what i asked|not what i meant)\b',
    ]
    
    def __init__(self, transaction_manager: TransactionManager, app=None):
        """
        Initialize feedback handler.
        
        Args:
            transaction_manager: TransactionManager instance for undo operations
            app: Application instance
        """
        self.transaction_manager = transaction_manager
        self.app = app
        self.last_transaction_id: Optional[str] = None
        self.last_operation_context: Optional[Dict[str, Any]] = None
    
    def is_feedback_request(self, text: str) -> bool:
        """
        Check if text is a feedback/undo request.
        
        Args:
            text: User input text
            
        Returns:
            True if this looks like feedback/undo request
        """
        text_lower = text.lower().strip()
        
        for pattern in self.FEEDBACK_PATTERNS:
            if re.search(pattern, text_lower, re.IGNORECASE):
                return True
        
        return False
    
    def handle_feedback(
        self,
        text: str,
        last_user_query: Optional[str] = None,
        last_intent: Optional[Intent] = None,
        last_transaction_id: Optional[str] = None
    ) -> Tuple[bool, str, Optional[Dict[str, Any]]]:
        """
        Handle user feedback/undo request.
        
        Args:
            text: User feedback text
            last_user_query: The original query that led to the mistake
            last_intent: The intent that was used
            last_transaction_id: Transaction ID to undo
            
        Returns:
            Tuple of (handled: bool, response_message: str, misinformation_data: Optional[Dict])
        """
        if not self.is_feedback_request(text):
            return False, "", None
        
        # Try to undo last transaction if available
        transaction_id = last_transaction_id or self.last_transaction_id
        undo_success = False
        undo_message = ""
        
        if transaction_id:
            try:
                transaction_state = self.transaction_manager.get_transaction_state(transaction_id)
                if transaction_state and transaction_state.get("status") == "committed":
                    # Rollback the transaction
                    self.transaction_manager.rollback(transaction_id, reason="User requested undo/feedback")
                    undo_success = True
                    undo_message = "✓ Changes have been reverted."
                else:
                    undo_message = "No recent changes to undo."
            except Exception as e:
                undo_message = f"Error undoing changes: {e}"
        else:
            undo_message = "No recent changes to undo."
        
        # Prepare misinformation data for logging
        misinformation_data = None
        if last_user_query and last_intent:
            misinformation_data = {
                "user_query": last_user_query,
                "feedback_text": text,
                "predicted_intent": last_intent.value if isinstance(last_intent, Intent) else str(last_intent),
                "correct_intent": None,  # We don't know the correct intent, just that this was wrong
                "confidence": None,  # We don't have confidence for feedback
                "timestamp": datetime.now().isoformat(),
                "reason": "user_feedback",
                "action": "undo_requested"
            }
            
            # Log to misinformation file
            self._log_misinformation(misinformation_data)
        
        # Generate response
        if undo_success:
            response = f"**Reverted Changes**\n\n{undo_message}\n\nI've logged this feedback to avoid similar mistakes in the future."
        else:
            response = f"**Feedback Received**\n\n{undo_message}\n\nI've logged this feedback to improve future responses."
        
        return True, response, misinformation_data
    
    def record_operation_context(
        self,
        transaction_id: str,
        user_query: str,
        intent: Intent,
        operation_plan: Optional[Any] = None
    ):
        """
        Record context about the last operation for potential undo.
        
        Args:
            transaction_id: Transaction ID
            user_query: Original user query
            intent: Intent that was used
            operation_plan: Operation plan that was executed
        """
        self.last_transaction_id = transaction_id
        self.last_operation_context = {
            "transaction_id": transaction_id,
            "user_query": user_query,
            "intent": intent.value if isinstance(intent, Intent) else str(intent),
            "operation_plan": operation_plan,
            "timestamp": datetime.now().isoformat()
        }
    
    def _log_misinformation(self, data: Dict[str, Any]):
        """
        Log misinformation/feedback to file for training avoidance.
        
        Args:
            data: Misinformation data dictionary
        """
        if not MISCLASSIFICATION_LOG.exists():
            MISCLASSIFICATION_LOG.parent.mkdir(parents=True, exist_ok=True)
            misinformation_log = []
        else:
            try:
                with open(MISCLASSIFICATION_LOG, 'r', encoding='utf-8') as f:
                    misinformation_log = json.load(f)
            except Exception:
                misinformation_log = []
        
        # Add new entry
        misinformation_log.append(data)
        
        # Keep only last 1000 entries
        if len(misinformation_log) > 1000:
            misinformation_log = misinformation_log[-1000:]
        
        # Save
        try:
            with open(MISCLASSIFICATION_LOG, 'w', encoding='utf-8') as f:
                json.dump(misinformation_log, f, indent=2, ensure_ascii=False)
        except Exception as e:
            print(f"Error logging misinformation: {e}")


# Global feedback handler instance (will be initialized by workflow)
_feedback_handler: Optional[FeedbackHandler] = None


def get_feedback_handler(transaction_manager: TransactionManager = None, app=None) -> FeedbackHandler:
    """Get or create feedback handler instance."""
    global _feedback_handler
    if _feedback_handler is None and transaction_manager:
        _feedback_handler = FeedbackHandler(transaction_manager, app)
    return _feedback_handler

