"""
Transaction Manager - Handles atomic, multi-file operations with rollback.

All project modifications must be transactional:
- Either all changes apply, or none apply
- Automatic rollback on failure
- Multi-file transaction support
"""

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any, Callable
from enum import Enum
from datetime import datetime
from uuid import uuid4
import os
import shutil
import json


class TransactionStatus(Enum):
    """Transaction status."""
    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    COMMITTED = "committed"
    ROLLED_BACK = "rolled_back"
    FAILED = "failed"


@dataclass
class OperationRecord:
    """Record of a single operation in a transaction."""
    operation_id: str
    component: str  # e.g., "ResourceManager"
    method: str  # e.g., "create_resource"
    params: Dict[str, Any]
    rollback_method: Optional[str] = None  # Method to call for rollback
    rollback_params: Optional[Dict[str, Any]] = None  # Parameters for rollback
    backup_data: Optional[Dict[str, Any]] = None  # Data to restore on rollback
    file_backups: List[str] = field(default_factory=list)  # Backup file paths


@dataclass
class Transaction:
    """Represents a transaction with multiple operations."""
    transaction_id: str
    status: TransactionStatus = TransactionStatus.PENDING
    created_at: datetime = field(default_factory=datetime.now)
    operations: List[OperationRecord] = field(default_factory=list)
    error_message: Optional[str] = None
    rollback_reason: Optional[str] = None


class TransactionManager:
    """
    Manages atomic transactions for project modifications.
    
    Ensures that either all operations in a transaction succeed,
    or all are rolled back.
    """
    
    def __init__(self, app=None):
        """
        Initialize transaction manager.
        
        Args:
            app: Application instance (for accessing ResourceManager, etc.)
        """
        self.app = app
        self.transactions: Dict[str, Transaction] = {}
        self.backup_dir: Optional[str] = None
        self._setup_backup_dir()
    
    def _setup_backup_dir(self):
        """Setup backup directory for transaction rollbacks."""
        if self.app and hasattr(self.app, 'project_manager'):
            project_path = self.app.project_manager.get_project_path()
            if project_path:
                self.backup_dir = os.path.join(project_path, ".nova_backups")
                os.makedirs(self.backup_dir, exist_ok=True)
    
    def begin_transaction(self, operation_plan) -> str:
        """
        Start a new transaction for an operation plan.
        
        Args:
            operation_plan: OperationPlan to execute transactionally
        
        Returns:
            transaction_id: Unique ID for this transaction
        """
        transaction_id = str(uuid4())
        
        transaction = Transaction(
            transaction_id=transaction_id,
            status=TransactionStatus.PENDING,
        )
        
        # Convert operations to operation records
        for op in operation_plan.operations:
            operation_record = OperationRecord(
                operation_id=str(uuid4()),
                component=op.component,
                method=op.method,
                params=op.params,
            )
            transaction.operations.append(operation_record)
        
        self.transactions[transaction_id] = transaction
        return transaction_id
    
    def add_operation(
        self,
        transaction_id: str,
        component: str,
        method: str,
        params: Dict[str, Any],
        rollback_method: Optional[str] = None,
        rollback_params: Optional[Dict[str, Any]] = None
    ) -> str:
        """
        Add an operation to a transaction.
        
        Args:
            transaction_id: ID of the transaction
            component: Component name (e.g., "ResourceManager")
            method: Method name (e.g., "create_resource")
            params: Method parameters
            rollback_method: Optional method to call for rollback
            rollback_params: Optional parameters for rollback
        
        Returns:
            operation_id: Unique ID for this operation
        """
        transaction = self.transactions.get(transaction_id)
        if not transaction:
            raise ValueError(f"Transaction {transaction_id} not found")
        
        if transaction.status != TransactionStatus.PENDING:
            raise ValueError(f"Transaction {transaction_id} is not in PENDING state")
        
        operation_id = str(uuid4())
        operation_record = OperationRecord(
            operation_id=operation_id,
            component=component,
            method=method,
            params=params,
            rollback_method=rollback_method,
            rollback_params=rollback_params,
        )
        
        transaction.operations.append(operation_record)
        return operation_id
    
    def _backup_file(self, file_path: str) -> Optional[str]:
        """
        Backup a file before modification.
        
        Args:
            file_path: Path to file to backup
        
        Returns:
            backup_path: Path to backup file, or None if backup failed
        """
        if not self.backup_dir or not os.path.exists(file_path):
            return None
        
        try:
            # Create backup filename with timestamp
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
            filename = os.path.basename(file_path)
            backup_filename = f"{timestamp}_{filename}"
            backup_path = os.path.join(self.backup_dir, backup_filename)
            
            # Copy file
            shutil.copy2(file_path, backup_path)
            return backup_path
        except Exception as e:
            print(f"Failed to backup file {file_path}: {e}")
            return None
    
    def _backup_resource(self, resource_type: str, resource_id: str) -> Optional[Dict[str, Any]]:
        """
        Backup a resource before modification.
        
        Args:
            resource_type: Type of resource
            resource_id: ID of resource
        
        Returns:
            backup_data: Resource data backup, or None if backup failed
        """
        if not self.app or not hasattr(self.app, 'resource_manager'):
            return None
        
        try:
            resource_manager = self.app.resource_manager
            resource_data = resource_manager.load_resource(resource_type, resource_id)
            if resource_data:
                import copy
                return copy.deepcopy(resource_data)
        except Exception as e:
            print(f"Failed to backup resource {resource_type}/{resource_id}: {e}")
        
        return None
    
    def _prepare_operation_rollback(self, operation_record: OperationRecord):
        """
        Prepare rollback data for an operation.
        
        Args:
            operation_record: Operation to prepare rollback for
        """
        # Backup files that will be modified
        if operation_record.method in ["save_resource", "update_resource"]:
            # Get file path from params
            resource_type = operation_record.params.get("resource_type")
            resource_id = operation_record.params.get("resource_id")
            
            if resource_type and resource_id:
                # Backup resource data
                backup_data = self._backup_resource(resource_type, resource_id)
                if backup_data:
                    operation_record.backup_data = backup_data
                
                # Backup resource file
                if self.app and hasattr(self.app, 'resource_manager'):
                    resource_manager = self.app.resource_manager
                    resource_data = resource_manager.load_resource(resource_type, resource_id)
                    if resource_data:
                        file_path = resource_manager.get_resource_file_path(resource_type, resource_data)
                        if file_path and os.path.exists(file_path):
                            backup_path = self._backup_file(file_path)
                            if backup_path:
                                operation_record.file_backups.append(backup_path)
        
        elif operation_record.method == "create_resource":
            # For create operations, rollback is deletion
            operation_record.rollback_method = "delete_resource"
            operation_record.rollback_params = {
                "resource_type": operation_record.params.get("resource_type"),
                "resource_id": None,  # Will be set after creation
            }
        
        elif operation_record.method == "delete_resource":
            # For delete operations, backup the resource before deletion
            resource_type = operation_record.params.get("resource_type")
            resource_id = operation_record.params.get("resource_id")
            
            if resource_type and resource_id:
                backup_data = self._backup_resource(resource_type, resource_id)
                if backup_data:
                    operation_record.backup_data = backup_data
                
                # Backup file
                if self.app and hasattr(self.app, 'resource_manager'):
                    resource_manager = self.app.resource_manager
                    resource_data = resource_manager.load_resource(resource_type, resource_id)
                    if resource_data:
                        file_path = resource_manager.get_resource_file_path(resource_type, resource_data)
                        if file_path and os.path.exists(file_path):
                            backup_path = self._backup_file(file_path)
                            if backup_path:
                                operation_record.file_backups.append(backup_path)
    
    def commit(self, transaction_id: str) -> bool:
        """
        Commit all operations in a transaction atomically.
        
        Args:
            transaction_id: ID of the transaction
        
        Returns:
            success: True if all operations succeeded, False otherwise
        """
        transaction = self.transactions.get(transaction_id)
        if not transaction:
            return False
        
        if transaction.status != TransactionStatus.PENDING:
            return False
        
        transaction.status = TransactionStatus.IN_PROGRESS
        
        executed_operations = []
        
        try:
            # Prepare rollback for all operations first
            for operation in transaction.operations:
                self._prepare_operation_rollback(operation)
            
            # Execute all operations
            for operation in transaction.operations:
                success = self._execute_operation(operation)
                if not success:
                    # Operation failed - rollback all executed operations
                    self._rollback_operations(executed_operations)
                    transaction.status = TransactionStatus.FAILED
                    transaction.error_message = f"Operation {operation.operation_id} failed"
                    return False
                
                executed_operations.append(operation)
            
            # All operations succeeded
            transaction.status = TransactionStatus.COMMITTED
            return True
            
        except Exception as e:
            # Exception occurred - rollback all executed operations
            self._rollback_operations(executed_operations)
            transaction.status = TransactionStatus.FAILED
            transaction.error_message = str(e)
            return False
    
    def _execute_operation(self, operation: OperationRecord) -> bool:
        """
        Execute a single operation.
        
        Args:
            operation: Operation to execute
        
        Returns:
            success: True if operation succeeded
        """
        if not self.app:
            return False
        
        try:
            # Get the component (e.g., ResourceManager)
            if operation.component == "ResourceManager":
                component = self.app.resource_manager
            elif operation.component == "ProjectManager":
                component = self.app.project_manager
            else:
                return False
            
            # Get the method
            method = getattr(component, operation.method, None)
            if not method:
                return False
            
            # Execute the method
            result = method(**operation.params)
            
            # Check if result indicates success
            if result is False:
                return False
            
            # For create_resource, store the resource_id for rollback
            if operation.method == "create_resource" and isinstance(result, dict):
                resource_id = result.get("id")
                if resource_id and operation.rollback_params:
                    operation.rollback_params["resource_id"] = resource_id
            
            return True
            
        except Exception as e:
            print(f"Error executing operation {operation.operation_id}: {e}")
            return False
    
    def _rollback_operations(self, operations: List[OperationRecord]):
        """
        Rollback a list of operations in reverse order.
        
        Args:
            operations: List of operations to rollback
        """
        # Rollback in reverse order
        for operation in reversed(operations):
            self._rollback_operation(operation)
    
    def _rollback_operation(self, operation: OperationRecord):
        """
        Rollback a single operation.
        
        Args:
            operation: Operation to rollback
        """
        try:
            # Restore file backups
            if operation.file_backups:
                # Get original file path from backup filename
                # Backup format: timestamp_filename
                for backup_path in operation.file_backups:
                    if os.path.exists(backup_path):
                        # Extract original filename (remove timestamp prefix)
                        backup_filename = os.path.basename(backup_path)
                        # Format: timestamp_filename, so split after first underscore
                        parts = backup_filename.split("_", 2)
                        if len(parts) >= 3:
                            original_filename = "_".join(parts[2:])
                            # Find original file path
                            if self.app and hasattr(self.app, 'resource_manager'):
                                # Try to find file in resource folders
                                resource_manager = self.app.resource_manager
                                project_path = self.app.project_manager.get_project_path()
                                if project_path:
                                    # Search in Resources folders
                                    for resource_type, config in resource_manager.resource_types.items():
                                        folder = config.get("folder", "")
                                        search_path = os.path.join(project_path, "Resources", folder)
                                        if os.path.exists(search_path):
                                            for root, dirs, files in os.walk(search_path):
                                                if original_filename in files:
                                                    original_path = os.path.join(root, original_filename)
                                                    # Restore file
                                                    shutil.copy2(backup_path, original_path)
                                                    break
            
            # Restore resource data
            if operation.backup_data:
                resource_type = operation.params.get("resource_type")
                resource_id = operation.params.get("resource_id")
                
                if resource_type and resource_id and self.app:
                    resource_manager = self.app.resource_manager
                    # Restore resource data
                    resource_manager.save_resource(resource_type, operation.backup_data)
            
            # Execute rollback method if specified
            if operation.rollback_method and operation.rollback_params:
                if self.app:
                    if operation.component == "ResourceManager":
                        component = self.app.resource_manager
                    elif operation.component == "ProjectManager":
                        component = self.app.project_manager
                    else:
                        return
                    
                    method = getattr(component, operation.rollback_method, None)
                    if method:
                        method(**operation.rollback_params)
            
            # For create operations, delete the created resource
            if operation.method == "create_resource":
                resource_type = operation.params.get("resource_type")
                resource_id = operation.rollback_params.get("resource_id") if operation.rollback_params else None
                
                if resource_type and resource_id and self.app:
                    resource_manager = self.app.resource_manager
                    resource_manager.delete_resource(resource_type, resource_id, skip_undo_record=True)
            
        except Exception as e:
            print(f"Error rolling back operation {operation.operation_id}: {e}")
    
    def rollback(self, transaction_id: str, reason: Optional[str] = None):
        """
        Rollback all operations in a transaction.
        
        Args:
            transaction_id: ID of the transaction
            reason: Optional reason for rollback
        """
        transaction = self.transactions.get(transaction_id)
        if not transaction:
            return
        
        if transaction.status == TransactionStatus.COMMITTED:
            # Rollback committed transaction
            self._rollback_operations(transaction.operations)
        
        transaction.status = TransactionStatus.ROLLED_BACK
        transaction.rollback_reason = reason
    
    def get_transaction_state(self, transaction_id: str) -> Optional[Dict[str, Any]]:
        """
        Get current transaction state.
        
        Args:
            transaction_id: ID of the transaction
        
        Returns:
            state: Dictionary with transaction state, or None if not found
        """
        transaction = self.transactions.get(transaction_id)
        if not transaction:
            return None
        
        return {
            "transaction_id": transaction.transaction_id,
            "status": transaction.status.value,
            "created_at": transaction.created_at.isoformat(),
            "operations_count": len(transaction.operations),
            "error_message": transaction.error_message,
            "rollback_reason": transaction.rollback_reason,
        }
    
    def cleanup_backups(self, older_than_days: int = 7):
        """
        Clean up old backup files.
        
        Args:
            older_than_days: Delete backups older than this many days
        """
        if not self.backup_dir or not os.path.exists(self.backup_dir):
            return
        
        try:
            from datetime import timedelta
            cutoff_time = datetime.now() - timedelta(days=older_than_days)
            
            for filename in os.listdir(self.backup_dir):
                file_path = os.path.join(self.backup_dir, filename)
                if os.path.isfile(file_path):
                    file_time = datetime.fromtimestamp(os.path.getmtime(file_path))
                    if file_time < cutoff_time:
                        os.remove(file_path)
        except Exception as e:
            print(f"Error cleaning up backups: {e}")

