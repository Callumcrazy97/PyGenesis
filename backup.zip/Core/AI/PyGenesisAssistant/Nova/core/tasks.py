"""
Task System - Manages tasks for Nova's workflow.
Every user interaction creates a task that goes through: Pending → Active → Completed
"""
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import List, Optional
from uuid import uuid4


class TaskStatus(Enum):
    """Task status enumeration."""
    PENDING = "pending"
    ACTIVE = "active"
    COMPLETED = "completed"


class TaskPriority(Enum):
    """Task priority enumeration."""
    LOW = "low"
    NORMAL = "normal"
    HIGH = "high"
    URGENT = "urgent"


@dataclass
class Task:
    """Represents a single task with support for hierarchical structure."""
    id: str = field(default_factory=lambda: str(uuid4()))
    name: str = ""
    description: str = ""
    status: TaskStatus = TaskStatus.PENDING
    priority: TaskPriority = TaskPriority.NORMAL
    created_at: datetime = field(default_factory=datetime.now)
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    user_input: Optional[str] = None  # Original user input that created this task
    intent: Optional[str] = None  # Intent type (e.g., MATH_QUERY, GENERAL_CHAT)
    result: Optional[str] = None  # Task result/output
    
    # Hierarchical task support
    parent_id: Optional[str] = None  # ID of parent task (None for root tasks)
    children_ids: List[str] = field(default_factory=list)  # IDs of child tasks
    task_number: Optional[str] = None  # Hierarchical number (e.g., "1", "1.1", "1.2.3")
    is_header: bool = False  # True if this is a header/grouping task
    
    def start(self):
        """Mark task as active."""
        self.status = TaskStatus.ACTIVE
        self.started_at = datetime.now()
    
    def complete(self, result: Optional[str] = None):
        """Mark task as completed."""
        self.status = TaskStatus.COMPLETED
        self.completed_at = datetime.now()
        if result:
            self.result = result
    
    def to_dict(self) -> dict:
        """Convert task to dictionary for serialization."""
        return {
            "id": self.id,
            "name": self.name,
            "description": self.description,
            "status": self.status.value,
            "priority": self.priority.value,
            "created_at": self.created_at.isoformat(),
            "started_at": self.started_at.isoformat() if self.started_at else None,
            "completed_at": self.completed_at.isoformat() if self.completed_at else None,
            "user_input": self.user_input,
            "intent": self.intent,
            "result": self.result,
            "parent_id": self.parent_id,
            "children_ids": self.children_ids,
            "task_number": self.task_number,
            "is_header": self.is_header,
        }
    
    @classmethod
    def from_dict(cls, data: dict) -> "Task":
        """Create task from dictionary."""
        task = cls(
            id=data.get("id", str(uuid4())),
            name=data.get("name", ""),
            description=data.get("description", ""),
            status=TaskStatus(data.get("status", "pending")),
            priority=TaskPriority(data.get("priority", "normal")),
            created_at=datetime.fromisoformat(data.get("created_at", datetime.now().isoformat())),
            user_input=data.get("user_input"),
            intent=data.get("intent"),
            result=data.get("result"),
            parent_id=data.get("parent_id"),
            children_ids=data.get("children_ids", []),
            task_number=data.get("task_number"),
            is_header=data.get("is_header", False),
        )
        if data.get("started_at"):
            task.started_at = datetime.fromisoformat(data["started_at"])
        if data.get("completed_at"):
            task.completed_at = datetime.fromisoformat(data["completed_at"])
        return task


class TaskManager:
    """Manages tasks - CRUD operations, filtering, ordering, hierarchical support."""
    
    def __init__(self):
        self.tasks: List[Task] = []
        self._next_order = 0
        self._task_counter = {}  # Track task numbers per parent: {parent_id: count}
    
    def create_task(
        self,
        name: str,
        description: str = "",
        user_input: Optional[str] = None,
        intent: Optional[str] = None,
        priority: TaskPriority = TaskPriority.NORMAL,
        parent_id: Optional[str] = None,
        is_header: bool = False,
    ) -> Task:
        """
        Create a new task with optional hierarchical support.
        
        Args:
            name: Task name
            description: Task description
            user_input: Original user input
            intent: Intent type
            priority: Task priority
            parent_id: ID of parent task (None for root tasks)
            is_header: True if this is a header/grouping task
        
        Returns:
            Created task with assigned task_number
        """
        task = Task(
            name=name,
            description=description,
            user_input=user_input,
            intent=intent,
            priority=priority,
            parent_id=parent_id,
            is_header=is_header,
        )
        
        # Assign task number
        task.task_number = self._generate_task_number(parent_id)
        
        # Add to parent's children if parent exists
        if parent_id:
            parent = self.get_task(parent_id)
            if parent:
                parent.children_ids.append(task.id)
        
        self.tasks.append(task)
        return task
    
    def _generate_task_number(self, parent_id: Optional[str] = None) -> str:
        """
        Generate hierarchical task number (e.g., "1", "1.1", "1.2.3").
        
        Args:
            parent_id: ID of parent task (None for root tasks)
        
        Returns:
            Task number string
        """
        if parent_id is None:
            # Root task - use sequential number
            count = self._task_counter.get(None, 0) + 1
            self._task_counter[None] = count
            return str(count)
        else:
            # Child task - get parent's number and append child number
            parent = self.get_task(parent_id)
            if not parent:
                # Parent not found, treat as root
                count = self._task_counter.get(None, 0) + 1
                self._task_counter[None] = count
                return str(count)
            
            parent_number = parent.task_number or "0"
            child_count = self._task_counter.get(parent_id, 0) + 1
            self._task_counter[parent_id] = child_count
            return f"{parent_number}.{child_count}"
    
    def get_task(self, task_id: str) -> Optional[Task]:
        """Get task by ID."""
        for task in self.tasks:
            if task.id == task_id:
                return task
        return None
    
    def get_tasks(
        self,
        status: Optional[TaskStatus] = None,
        priority: Optional[TaskPriority] = None,
    ) -> List[Task]:
        """Get tasks with optional filtering."""
        filtered = self.tasks
        
        if status:
            filtered = [t for t in filtered if t.status == status]
        
        if priority:
            filtered = [t for t in filtered if t.priority == priority]
        
        return filtered
    
    def get_pending_tasks(self) -> List[Task]:
        """Get all pending tasks."""
        return self.get_tasks(status=TaskStatus.PENDING)
    
    def get_active_tasks(self) -> List[Task]:
        """Get all active tasks."""
        return self.get_tasks(status=TaskStatus.ACTIVE)
    
    def get_completed_tasks(self) -> List[Task]:
        """Get all completed tasks."""
        return self.get_tasks(status=TaskStatus.COMPLETED)
    
    def delete_task(self, task_id: str) -> bool:
        """Delete a task."""
        for i, task in enumerate(self.tasks):
            if task.id == task_id:
                self.tasks.pop(i)
                return True
        return False
    
    def reorder_task(self, task_id: str, new_index: int) -> bool:
        """Reorder a task to a new position."""
        task = self.get_task(task_id)
        if not task:
            return False
        
        # Remove from current position
        self.tasks.remove(task)
        
        # Insert at new position
        self.tasks.insert(new_index, task)
        return True
    
    def start_task(self, task_id: str) -> bool:
        """Start a task (mark as active)."""
        task = self.get_task(task_id)
        if task:
            task.start()
            return True
        return False
    
    def complete_task(self, task_id: str, result: Optional[str] = None) -> bool:
        """Complete a task."""
        task = self.get_task(task_id)
        if task:
            task.complete(result)
            return True
        return False
    
    def get_current_task(self) -> Optional[Task]:
        """Get the currently active task (if any)."""
        active = self.get_active_tasks()
        return active[0] if active else None
    
    def get_root_tasks(self) -> List[Task]:
        """Get all root tasks (tasks without parents)."""
        return [task for task in self.tasks if task.parent_id is None]
    
    def get_child_tasks(self, parent_id: str) -> List[Task]:
        """Get all child tasks of a parent task."""
        parent = self.get_task(parent_id)
        if not parent:
            return []
        return [self.get_task(child_id) for child_id in parent.children_ids if self.get_task(child_id)]
    
    def get_task_tree(self, task_id: str) -> Optional[Task]:
        """Get a task with all its children recursively."""
        task = self.get_task(task_id)
        if not task:
            return None
        # Children are already linked via children_ids
        return task
    
    def get_all_tasks_hierarchical(self) -> List[Task]:
        """
        Get all tasks in hierarchical order (root tasks first, then children).
        Returns tasks in depth-first order.
        """
        result = []
        root_tasks = self.get_root_tasks()
        
        def add_task_and_children(task: Task):
            result.append(task)
            for child_id in task.children_ids:
                child = self.get_task(child_id)
                if child:
                    add_task_and_children(child)
        
        for root in root_tasks:
            add_task_and_children(root)
        
        return result
    
    def delete_task(self, task_id: str, delete_children: bool = True) -> bool:
        """
        Delete a task and optionally its children.
        
        Args:
            task_id: ID of task to delete
            delete_children: If True, also delete all child tasks
        
        Returns:
            True if task was deleted
        """
        task = self.get_task(task_id)
        if not task:
            return False
        
        # Remove from parent's children
        if task.parent_id:
            parent = self.get_task(task.parent_id)
            if parent and task_id in parent.children_ids:
                parent.children_ids.remove(task_id)
        
        # Delete children if requested
        if delete_children:
            for child_id in task.children_ids[:]:  # Copy list to avoid modification during iteration
                self.delete_task(child_id, delete_children=True)
        
        # Remove task
        self.tasks.remove(task)
        return True


