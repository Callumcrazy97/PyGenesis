"""
Language Utilities - Handles language preferences, spell checking, and word corrections.
Supports EN-UK (default) and EN-US.
"""
import re
from typing import Optional, List, Tuple
from enum import Enum

# Try to import spell checker
try:
    from spellchecker import SpellChecker
    SPELLCHECKER_AVAILABLE = True
except ImportError:
    SPELLCHECKER_AVAILABLE = False
    SpellChecker = None


class Language(Enum):
    """Supported languages."""
    EN_UK = "en_uk"  # British English (default)
    EN_US = "en_us"  # American English


# Common spelling differences between UK and US English
SPELLING_DIFFERENCES = {
    # UK -> US mappings
    "colour": "color",
    "favour": "favor",
    "honour": "honor",
    "behaviour": "behavior",
    "labour": "labor",
    "neighbour": "neighbor",
    "organise": "organize",
    "organised": "organized",
    "organising": "organizing",
    "organisation": "organization",
    "recognise": "recognize",
    "recognised": "recognized",
    "recognising": "recognizing",
    "recognisation": "recognition",
    "realise": "realize",
    "realised": "realized",
    "realising": "realizing",
    "realisation": "realization",
    "analyse": "analyze",
    "analysed": "analyzed",
    "analysing": "analyzing",
    "analysis": "analysis",  # Same in both
    "centre": "center",
    "metre": "meter",
    "theatre": "theater",
    "fibre": "fiber",
    "defence": "defense",
    "licence": "license",  # Noun
    "licenced": "licensed",  # Verb/adjective
    "licencing": "licensing",
    "programme": "program",  # Except for computer programs
    "travelled": "traveled",
    "travelling": "traveling",
    "traveller": "traveler",
    "cancelled": "canceled",
    "cancelling": "canceling",
    "cancellation": "cancellation",  # Same in both
    "labelled": "labeled",
    "labelling": "labeling",
    "modelling": "modeling",
    "modelled": "modeled",
    "dialogue": "dialog",
    "catalogue": "catalog",
    "analogue": "analog",
    "monologue": "monolog",
    "sceptical": "skeptical",
    "scepticism": "skepticism",
    "pyjamas": "pajamas",
    "speciality": "specialty",
    "tyre": "tire",
    "aluminium": "aluminum",
    "whilst": "while",
    "amongst": "among",
    "whilst": "while",
}

# Reverse mapping (US -> UK)
US_TO_UK = {v: k for k, v in SPELLING_DIFFERENCES.items()}


class LanguageUtils:
    """Utilities for language handling, spell checking, and word correction."""
    
    def __init__(self, language: Language = Language.EN_UK):
        """
        Initialize language utilities.
        
        Args:
            language: Language preference (EN_UK or EN_US)
        """
        self.language = language
        self.spell_checker = None
        
        if SPELLCHECKER_AVAILABLE:
            try:
                # Use appropriate dictionary based on language
                if language == Language.EN_UK:
                    # Try to use UK dictionary, fallback to US
                    try:
                        self.spell_checker = SpellChecker(language='en_GB')
                    except:
                        self.spell_checker = SpellChecker(language='en')
                else:
                    self.spell_checker = SpellChecker(language='en')
            except Exception:
                self.spell_checker = None
    
    def correct_spelling(self, text: str, preserve_code: bool = True) -> str:
        """
        Correct spelling in text according to language preference.
        Preserves code blocks by default.
        
        Args:
            text: Text to correct
            preserve_code: If True, don't modify code blocks (```code```)
            
        Returns:
            Corrected text
        """
        if not text:
            return text
        
        if preserve_code:
            # Split text into code blocks and regular text
            parts = []
            code_pattern = r'```[\s\S]*?```|`[^`]+`'
            last_end = 0
            
            for match in re.finditer(code_pattern, text):
                # Add text before code block
                if match.start() > last_end:
                    parts.append(('text', text[last_end:match.start()]))
                # Add code block (preserve as-is)
                parts.append(('code', match.group()))
                last_end = match.end()
            
            # Add remaining text
            if last_end < len(text):
                parts.append(('text', text[last_end:]))
            
            # Process only text parts
            result_parts = []
            for part_type, content in parts:
                if part_type == 'code':
                    result_parts.append(content)
                else:
                    result_parts.append(self._correct_text_spelling(content))
            
            return ''.join(result_parts)
        else:
            return self._correct_text_spelling(text)
    
    def _correct_text_spelling(self, text: str) -> str:
        """Correct spelling in text (without code blocks)."""
        # Convert to target language spelling
        words = re.findall(r'\b\w+\b|\W+', text)
        corrected_words = []
        
        for word in words:
            if not re.match(r'\w+', word):
                # Non-word character, keep as-is
                corrected_words.append(word)
                continue
            
            word_lower = word.lower()
            original_case = self._get_case_pattern(word)
            
            # Check if word needs conversion
            if self.language == Language.EN_UK:
                # Convert US -> UK
                if word_lower in US_TO_UK:
                    corrected = US_TO_UK[word_lower]
                else:
                    corrected = word_lower
            else:
                # Convert UK -> US
                if word_lower in SPELLING_DIFFERENCES:
                    corrected = SPELLING_DIFFERENCES[word_lower]
                else:
                    corrected = word_lower
            
            # Apply original case pattern
            corrected = self._apply_case_pattern(corrected, original_case)
            corrected_words.append(corrected)
        
        return ''.join(corrected_words)
    
    def _get_case_pattern(self, word: str) -> str:
        """Get the case pattern of a word (e.g., 'Title', 'UPPER', 'lower')."""
        if word.isupper():
            return 'upper'
        elif word.islower():
            return 'lower'
        elif word.istitle():
            return 'title'
        elif word[0].isupper():
            return 'capitalize'
        else:
            return 'lower'
    
    def _apply_case_pattern(self, word: str, pattern: str) -> str:
        """Apply case pattern to word."""
        if pattern == 'upper':
            return word.upper()
        elif pattern == 'lower':
            return word.lower()
        elif pattern == 'title':
            return word.title()
        elif pattern == 'capitalize':
            return word.capitalize()
        else:
            return word
    
    def check_spelling(self, word: str) -> Tuple[bool, Optional[List[str]]]:
        """
        Check if a word is spelled correctly and suggest corrections.
        
        Args:
            word: Word to check
            
        Returns:
            Tuple of (is_correct, suggestions)
        """
        if not self.spell_checker:
            # No spell checker available, use basic dictionary check
            word_lower = word.lower()
            # Check if word exists in either UK or US spelling
            is_correct = (
                word_lower in SPELLING_DIFFERENCES or
                word_lower in US_TO_UK or
                word_lower in [v.lower() for v in SPELLING_DIFFERENCES.values()]
            )
            return (is_correct, None)
        
        try:
            # Check spelling
            unknown = self.spell_checker.unknown([word])
            is_correct = word not in unknown
            
            if not is_correct:
                # Get suggestions
                suggestions = self.spell_checker.candidates(word)
                if suggestions:
                    # Filter to match language preference
                    filtered = []
                    for sug in list(suggestions)[:5]:  # Top 5
                        if self.language == Language.EN_UK:
                            # Prefer UK spellings
                            if sug in SPELLING_DIFFERENCES or sug not in US_TO_UK:
                                filtered.append(sug)
                        else:
                            # Prefer US spellings
                            if sug in US_TO_UK or sug not in SPELLING_DIFFERENCES:
                                filtered.append(sug)
                    return (False, filtered[:5] if filtered else list(suggestions)[:5])
            
            return (True, None)
        except Exception:
            return (True, None)  # Assume correct if check fails
    
    def get_language_name(self) -> str:
        """Get human-readable language name."""
        if self.language == Language.EN_UK:
            return "English (UK)"
        else:
            return "English (US)"
    
    @staticmethod
    def get_language_from_setting(setting_value: str) -> Language:
        """Get Language enum from setting value."""
        if setting_value and setting_value.lower() in ['en_us', 'us', 'american']:
            return Language.EN_US
        return Language.EN_UK  # Default

