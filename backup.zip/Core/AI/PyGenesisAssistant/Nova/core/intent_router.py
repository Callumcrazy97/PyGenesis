"""
Intent Router - Classifies user input into intent types.
Uses SLM (Small Language Model) with keyword-based fallback.
Implements 4-layer Intent Resolution Stack for deterministic disambiguation.
"""
import re
from typing import Optional, List, Dict, Any

from core.models import Intent, IntentResult, ClarificationContext, UserMode, ConfidenceBand

# Try to import CustomNeuralModel (new neural network), fallback to TinyIntentModel if needed
try:
    from core.slm.custom_neural_model import CustomNeuralModel
    CUSTOM_NEURAL_AVAILABLE = True
except (ImportError, Exception):
    CustomNeuralModel = None
    CUSTOM_NEURAL_AVAILABLE = False

# Fallback to old TinyIntentModel if CustomNeuralModel not available
try:
    from core.slm.tiny_intent_model import TinyIntentModel
    TINY_INTENT_AVAILABLE = True
except (ImportError, Exception):
    TinyIntentModel = None
    TINY_INTENT_AVAILABLE = False

# Determine which SLM to use (prefer CustomNeuralModel)
SLM_AVAILABLE = CUSTOM_NEURAL_AVAILABLE or TINY_INTENT_AVAILABLE


class IntentRouter:
    """Routes user input to appropriate intent type using 4-layer resolution stack."""
    
    def __init__(self, use_slm: bool = True, project_scanner=None):
        """
        Initialize intent router.
        Args:
            use_slm: If True, use SLM for classification (default: True)
            project_scanner: Optional ProjectScanner instance for context-aware routing
        """
        self.use_slm = use_slm and SLM_AVAILABLE
        self.slm = None
        self.slm_type = None  # Track which model we're using
        self.project_scanner = project_scanner  # For checking if entities exist in project
        
        # Try CustomNeuralModel first (new, better model)
        if self.use_slm and CUSTOM_NEURAL_AVAILABLE and CustomNeuralModel:
            try:
                self.slm = CustomNeuralModel()
                self.slm_type = "custom_neural"
            except Exception as e:
                print(f"CustomNeuralModel not available, trying fallback: {e}")
                self.slm = None
        
        # Fallback to TinyIntentModel if CustomNeuralModel failed
        if self.slm is None and self.use_slm and TINY_INTENT_AVAILABLE and TinyIntentModel:
            try:
                self.slm = TinyIntentModel()
                self.slm_type = "tiny_intent"
                print("Using TinyIntentModel (fallback)")
            except Exception as e:
                # Fallback to keyword-based if SLM fails
                self.use_slm = False
                self.slm = None
                self.slm_type = None
                print(f"SLM not available, using keyword-based routing: {e}")
        
        # Intent detection patterns (fallback)
        self.patterns = {
            Intent.GENERAL_CHAT: [
                r'\b(hi|hello|hey|greetings|good morning|good afternoon|good evening)\b',
                r'\b(hi|hello|hey)\s+nova\b',  # Explicit greetings to Nova
                r'^\s*(hi|hello|hey|greetings)\s*$',  # Standalone greetings
            ],
            Intent.MATH_QUERY: [
                r'\bsolve\b', r'\bcalculate\b', r'\bcompute\b',
                r'[0-9]+\s*[+\-*/]\s*[0-9]+',  # Simple math expressions
                r'\bwhat is\s+[0-9]',  # "What is 2 + 2"
                r'\bwhat\'?s\s+[0-9]',  # "What's 2 + 2"
                r'[+\-*/=]',  # Math operators
            ],
            Intent.RESEARCH_QUERY: [
                r'\bresearch\b', r'\bstudy\b', r'\blearn about\b',
                r'\bwhat is\b', r'\bwhat are\b', r'\bwho is\b',
                r'\bwhy\b', r'\bhow does\b', r'\bexplain\b',
            ],
            Intent.DICTIONARY_LOOKUP: [
                r'\bdefine\b', r'\bdefinition of\b', r'\bwhat does .+ mean\b',
                r'\bwhat do .+ mean\b', r'\bmeaning of\b', r'\bwhat is the meaning\b',
                r'\bwhat is the meaning of\b', r'\btell me what .+ means\b',
            ],
            Intent.THESAURUS_LOOKUP: [
                r'\bsynonym\b', r'\bbetter word for\b', r'\banother word for\b',
                r'\bsimilar to\b', r'\balternative to\b',
            ],
            Intent.CODE_QUERY: [
                r'\bhow does .+ work\b', r'\bhow does .+ interact\b',
                r'\bexplain .+ code\b', r'\bwhat does .+ do\b',
                r'\bclass\b', r'\bfunction\b', r'\bimport\b',
                r'\bcode\b', r'\bimplementation\b',
            ],
            Intent.CODE_SEARCH: [
                r'\bwhere is .+ defined\b', r'\bwhere is .+ located\b',
                r'\bfind .+\b', r'\bsearch for .+\b',
                r'\blocate .+\b', r'\bwhere can i find .+\b',
                r'\bwhere\s+is\s+["\']?[\w]+["\']?\s+(?:defined|located)',
            ],
            Intent.RESOURCE_OPERATION: [
                r'\bcreate\s+(?:a\s+)?(?:sprite|object|room|sound|background|model|texture|shader|script|particle|folder)',
                r'\brename\s+(?:sprite|object|room|sound|background|model|texture|shader|script|particle|folder)',
                r'\bdelete\s+(?:sprite|object|room|sound|background|model|texture|shader|script|particle|folder)',
                r'\bmove\s+(?:sprite|object|room|sound|background|model|texture|shader|script|particle)',
                r'\bcopy\s+(?:sprite|object|room|sound|background|model|texture|shader|script|particle)',
                r'\bedit\s+(?:sprite|object|room|sound|background|model|texture|shader|script|particle)',
                r'\badd\s+(?:a\s+)?(?:sprite|object|room|sound|background|model|texture|shader|script|particle)',
                r'\b(?:create|delete|rename)\s+folder',
            ],
            Intent.PROJECT_MODIFICATION: [
                r'\bmodify\b', r'\bchange\b',
                r'\bupdate\b', r'\bremove\b',
                r'\brefactor\b', r'\bimplement\b',
            ],
            Intent.GRAPH_VISUALIZATION: [
                r'\bgraph\b', r'\bdependency\b', r'\bdependencies\b',
                r'\bvisualize\b', r'\bshow relationships\b',
                r'\bconnection\b', r'\blinks\b',
            ],
        }
    
    def classify(
        self, 
        text: str, 
        previous_clarification: Optional[ClarificationContext] = None,
        conversation_history: Optional[List[Dict[str, Any]]] = None
    ) -> IntentResult:
        """
        4-Layer Intent Resolution Stack (ChatGPT's recommendation):
        
        Layer 1: Context Dominance (hard override)
        Layer 2: Actionability Detection (verbs dominate definitions)
        Layer 3: Capability-Aware Answer Shaping
        Layer 4: Escalation only when necessary
        
        Args:
            text: User input text
            previous_clarification: Optional clarification context from previous message
            conversation_history: Optional list of previous messages for context awareness
        
        Returns IntentResult with confidence and clarification needs.
        """
        text_lower = text.lower()
        
        # PRE-ANALYSIS: Quick pattern check for obvious cases (before SLM)
        # This catches simple math queries like "What is 2 * 16" before they get misclassified
        quick_check = self._quick_pattern_check(text_lower)
        if quick_check and quick_check.confidence >= 0.85:
            # High confidence quick check - use it directly
            return quick_check
        
        # Handle clarification responses
        if previous_clarification:
            return self._handle_clarification_response(text, previous_clarification)
        
        # Extract entity for context checking
        entity = self._extract_potential_entity(text)
        
        # Check if project is actually loaded (has valid structure)
        project_open = self._is_project_loaded()
        
        # LAYER 1: Context Dominance (hard override)
        # Only check project if it's actually loaded
        if project_open:
            # Check for explicit project indicators FIRST (highest confidence)
            if self._is_project_specific_query(text_lower):
                if self._is_implementation_query(text_lower):
                    return IntentResult(
                        primary_intent=Intent.PROJECT_MODIFICATION,
                        confidence=0.9
                    )
                elif self._is_code_search_query(text_lower):
                    return IntentResult(
                        primary_intent=Intent.CODE_SEARCH,
                        confidence=0.9
                    )
                else:
                    return IntentResult(
                        primary_intent=Intent.CODE_QUERY,
                        confidence=0.9
                    )
            
            # If entity exists in project, ask for clarification (don't assume)
            if entity and self._entity_exists_in_project(entity):
                # Entity exists → Ask if they mean project knowledge
                return IntentResult(
                    primary_intent=Intent.RESEARCH_QUERY,  # Default to research, but ask
                    confidence=0.5,
                    requires_clarification=True,
                    clarification_question=self._generate_project_clarification_question(text, entity),
                    entity=entity
                )
        
        # LAYER 2: Actionability Detection (verbs dominate definitions)
        # Implementation verbs override "what is" patterns
        # BUT: If no project is loaded, route to research instead
        if self._is_implementation_query(text_lower):
            # Check if this is a "how would you implement" query (research/educational)
            # vs "implement X in my project" (project modification)
            is_how_would_you = re.search(r'\bhow would you\b', text_lower, re.IGNORECASE)
            is_how_to = re.search(r'\bhow to\b', text_lower, re.IGNORECASE)
            has_project_context = self._is_project_specific_query(text_lower) or (project_open and entity and self._entity_exists_in_project(entity))
            
            # If it's "how would you implement" or "how to implement" without project context,
            # treat it as a research/educational query
            if (is_how_would_you or is_how_to) and not has_project_context:
                return IntentResult(
                    primary_intent=Intent.RESEARCH_QUERY,
                    confidence=0.8,
                    fallback_intents=[Intent.PROJECT_MODIFICATION],
                    entity=entity
                )
            
            # Otherwise, it's a project modification request
            if project_open:
                return IntentResult(
                    primary_intent=Intent.PROJECT_MODIFICATION,
                    confidence=0.85,
                    fallback_intents=[Intent.CODE_QUERY, Intent.RESEARCH_QUERY]
                )
            else:
                # No project loaded, but they want to implement something
                # Route to research so we can provide guidance
                return IntentResult(
                    primary_intent=Intent.RESEARCH_QUERY,
                    confidence=0.75,
                    fallback_intents=[Intent.PROJECT_MODIFICATION],
                    entity=entity
                )
        
        # LAYER 2.5: Check for dictionary/thesaurus/math/research queries BEFORE SLM
        # These should take priority over SLM classification for clear patterns
        
        # Dictionary lookup patterns (check first)
        if re.search(r'\b(?:what does|what do)\s+.+\s+mean\b', text_lower):
            return IntentResult(
                primary_intent=Intent.DICTIONARY_LOOKUP,
                confidence=0.9,
                entity=self.extract_entity(text, Intent.DICTIONARY_LOOKUP)
            )
        
        # Math query patterns (check before "what is" research patterns)
        # Also check for contextual math references like "divide again by 10", "divide that by 10"
        if (re.search(r'[0-9]+\s*[+\-*/]\s*[0-9]+', text_lower) or 
            re.search(r'\b(?:what is|what\'?s|calculate|solve|compute)\s+[0-9]', text_lower) or
            re.search(r'\b(?:divide|multiply|add|subtract)\s+(?:that|this|it|again)?\s*(?:by|to|with)\s*\d+', text_lower) or
            re.search(r'\b(?:plus|minus|times)\s+\d+', text_lower)):
            return IntentResult(
                primary_intent=Intent.MATH_QUERY,
                confidence=0.9,
                entity=self.extract_entity(text, Intent.MATH_QUERY)
            )
        
        # RESEARCH QUERY patterns - "What is X" (where X is NOT a number)
        # This catches "What is Godot", "What is Python", etc.
        research_match = re.search(r'\b(?:what is|what are|what\'s|who is|tell me about|explain)\s+([a-zA-Z][a-zA-Z0-9\s]*)', text_lower)
        if research_match:
            topic = research_match.group(1).strip()
            # Make sure it's not a math query (no numbers at start)
            if topic and not topic[0].isdigit():
                return IntentResult(
                    primary_intent=Intent.RESEARCH_QUERY,
                    confidence=0.85,
                    entity=topic
                )
        
        # Time/Date questions (should be general chat, not dictionary)
        if re.search(r'\b(?:what day|what date|what time|when is|current date|today|now)\b', text_lower):
            return IntentResult(
                primary_intent=Intent.GENERAL_CHAT,
                confidence=0.85
            )
        
        # Explicit greeting detection (only for simple greetings)
        simple_greetings = ['hi', 'hello', 'hey', 'greetings', 'hi nova', 'hello nova', 'hey nova']
        text_clean = text_lower.strip()
        if text_clean in simple_greetings or any(greeting == text_clean for greeting in simple_greetings):
            return IntentResult(
                primary_intent=Intent.GENERAL_CHAT,
                confidence=0.95,
                fallback_intents=[],
                requires_clarification=False
            )
        
        # LAYER 3: SLM-based classification (if available) with pattern fallback
        scores = {}
        slm_result = None
        slm_confidence = 0.0
        
        # Try SLM first (CustomNeuralModel or TinyIntentModel)
        if self.use_slm and self.slm:
            try:
                slm_intent, slm_confidence = self.slm.predict(text)
                slm_result = (slm_intent, slm_confidence)
                
                # Apply conversation context weighting
                if conversation_history:
                    slm_confidence = self._apply_context_weighting(
                        slm_intent, slm_confidence, conversation_history
                    )
                
                # CONFIDENCE-BASED FALLBACK: If SLM confidence is low, try pattern-based
                if slm_confidence < 0.4:
                    pattern_result = self._pattern_classify_with_confidence(text_lower)
                    if pattern_result and pattern_result[1] > slm_confidence:
                        # Pattern-based has higher confidence, use it instead
                        pattern_intent, pattern_conf = pattern_result
                        slm_intent = pattern_intent
                        slm_confidence = pattern_conf
                        slm_result = (pattern_intent, pattern_conf)
                
                # Convert SLM confidence to score (0-3 scale for consistency)
                if slm_confidence >= 0.8:
                    score = 3  # High confidence
                elif slm_confidence >= 0.6:
                    score = 2  # Medium confidence
                else:
                    score = 1  # Low confidence
                
                scores[slm_intent] = score
                
                # If SLM confidence is high enough, use it as primary
                if slm_confidence >= 0.6:
                    # Still check patterns for fallback intents
                    pattern_scores = {}
                    for intent, patterns in self.patterns.items():
                        pattern_score = 0
                        for pattern in patterns:
                            if re.search(pattern, text_lower, re.IGNORECASE):
                                pattern_score += 1
                        if pattern_score > 0:
                            pattern_scores[intent] = pattern_score
                    
                    # Use SLM result as primary, patterns as fallbacks
                    primary = slm_intent
                    confidence = slm_confidence
                    fallbacks = [intent for intent in pattern_scores.keys() if intent != primary][:2]
                    
                    # CRITICAL: Prevent math queries from being misclassified as project modification
                    if primary == Intent.MATH_QUERY:
                        # Math queries should NEVER trigger project modification
                        return IntentResult(
                            primary_intent=Intent.MATH_QUERY,
                            confidence=min(0.95, confidence + 0.1),  # Boost confidence for math
                            fallback_intents=[],
                            entity=entity
                        )
                    
                    # CRITICAL: Prevent "where is" location queries from being misclassified as GRAPH_VISUALIZATION
                    if primary == Intent.GRAPH_VISUALIZATION and re.search(r'\bwhere is\b', text_lower):
                        # "Where is X" should be RESEARCH_QUERY (location), not graph visualization
                        # Check if it's clearly NOT a code query
                        code_indicators = ['defined', 'located in', 'in my code', 'in the code', 
                                         'in this project', 'function', 'class', 'method', 'variable',
                                         'dependency', 'graph', 'visualize']
                        if not any(indicator in text_lower for indicator in code_indicators):
                            # It's a location query, override to RESEARCH_QUERY
                            return IntentResult(
                                primary_intent=Intent.RESEARCH_QUERY,
                                confidence=0.85,
                                fallback_intents=[Intent.GRAPH_VISUALIZATION],
                                entity=entity
                            )
                    
                    # Special case: "What is X" queries need clarification if ambiguous
                    if primary == Intent.RESEARCH_QUERY and project_open and entity and self._entity_exists_in_project(entity):
                        return IntentResult(
                            primary_intent=primary,
                            confidence=0.5,
                            fallback_intents=fallbacks,
                            requires_clarification=True,
                            clarification_question=self._generate_project_clarification_question(text, entity),
                            entity=entity
                        )
                    
                    return IntentResult(
                        primary_intent=primary,
                        confidence=confidence,
                        fallback_intents=fallbacks,
                        entity=entity
                    )
            except Exception as e:
                # SLM failed, fall through to pattern matching
                pass
        
        # Fallback: Pattern-based classification with confidence scoring
        for intent, patterns in self.patterns.items():
            score = 0
            for pattern in patterns:
                if re.search(pattern, text_lower, re.IGNORECASE):
                    score += 1
            if score > 0:
                scores[intent] = score
        
        # Calculate confidence based on score strength
        if scores:
            max_score = max(scores.values())
            total_score = sum(scores.values())
            
            # High confidence: single strong match
            if max_score >= 2 and len(scores) == 1:
                primary = max(scores.items(), key=lambda x: x[1])[0]
                confidence = min(0.9, 0.6 + (max_score * 0.1))
                fallbacks = [intent for intent in scores.keys() if intent != primary]
                
                # Special case: "What is X" queries need clarification if ambiguous
                # Only ask if project is loaded AND entity exists in project
                if primary == Intent.RESEARCH_QUERY and project_open and entity and self._entity_exists_in_project(entity):
                    # Ambiguous: entity exists in project, ask for clarification
                    return IntentResult(
                        primary_intent=primary,
                        confidence=0.5,  # Medium confidence
                        fallback_intents=fallbacks,
                        requires_clarification=True,
                        clarification_question=self._generate_project_clarification_question(text, entity),
                        entity=entity
                    )
                
                return IntentResult(
                    primary_intent=primary,
                    confidence=confidence,
                    fallback_intents=fallbacks[:2],  # Top 2 fallbacks
                    entity=entity
                )
            
            # Medium confidence: multiple matches
            elif len(scores) > 1:
                primary = max(scores.items(), key=lambda x: x[1])[0]
                confidence = 0.6
                fallbacks = [intent for intent in scores.keys() if intent != primary]
                
                # If RESEARCH_QUERY is primary but project is open AND entity exists, ask for clarification
                if primary == Intent.RESEARCH_QUERY and project_open and entity and self._entity_exists_in_project(entity):
                    return IntentResult(
                        primary_intent=primary,
                        confidence=0.5,
                        fallback_intents=fallbacks,
                        requires_clarification=True,
                        clarification_question=self._generate_project_clarification_question(text, entity),
                        entity=entity
                    )
                
                return IntentResult(
                    primary_intent=primary,
                    confidence=confidence,
                    fallback_intents=fallbacks[:2],
                    entity=entity
                )
            
            # Low confidence: weak match
            else:
                primary = max(scores.items(), key=lambda x: x[1])[0]
                # Only ask for clarification if project is loaded and entity exists
                needs_clarification = project_open and entity and self._entity_exists_in_project(entity)
                return IntentResult(
                    primary_intent=primary,
                    confidence=0.4,
                    fallback_intents=[],
                    requires_clarification=needs_clarification,
                    clarification_question=self._generate_project_clarification_question(text, entity) if needs_clarification else None,
                    entity=entity
                )
        
        # LAYER 4: Escalation - General chat fallback
        # If we have conversation history, try to infer from context
        if conversation_history:
            context_intent = self._infer_from_context(conversation_history)
            if context_intent:
                return IntentResult(
                    primary_intent=context_intent,
                    confidence=0.5,  # Medium confidence from context
                    fallback_intents=[Intent.GENERAL_CHAT]
                )
        
        return IntentResult(
            primary_intent=Intent.GENERAL_CHAT,
            confidence=0.3,
            fallback_intents=[],
            requires_clarification=False
        )
    
    def _handle_clarification_response(self, text: str, clarification: ClarificationContext) -> IntentResult:
        """
        Parse user's response to a clarification question and resume original task.
        """
        text_lower = text.lower()
        
        # Extract entity from original query
        original_entity = self._extract_potential_entity(clarification.original_query) or clarification.original_query.split()[-1]
        
        # Parse clarification response patterns
        # Option 1: General knowledge / research ("as a general concept", "the language", "look it up")
        general_indicators = [
            'general', 'concept', 'language', 'programming language', 
            'what is', 'look it up', 'research', 'wikipedia', 'definition'
        ]
        if any(indicator in text_lower for indicator in general_indicators):
            return IntentResult(
                primary_intent=Intent.RESEARCH_QUERY,
                confidence=0.95,
                entity=original_entity
            )
        
        # Option 2: Project-specific ("in my project", "my code", "project", "analyze my code")
        project_indicators = [
            'project', 'my code', 'my', 'this project', 'in my project',
            'analyze', 'my code', 'code', 'class', 'function'
        ]
        if any(indicator in text_lower for indicator in project_indicators):
            return IntentResult(
                primary_intent=Intent.CODE_QUERY,
                confidence=0.95,
                entity=original_entity
            )
        
        # Option 3: Specific entity mentioned (check if it exists in project)
        entity = self._extract_potential_entity(text)
        if entity and self._entity_exists_in_project(entity):
            return IntentResult(
                primary_intent=Intent.CODE_QUERY,
                confidence=0.95,
                entity=entity
            )
        
        # Default: assume general knowledge if unclear
        return IntentResult(
            primary_intent=Intent.RESEARCH_QUERY,
            confidence=0.7,
            entity=original_entity
        )
    
    def _generate_clarification_question(self, text: str, entity: Optional[str]) -> str:
        """Generate a clarification question for ambiguous queries (no project context)."""
        if entity:
            return f"Do you mean:\n• {entity} as a general concept (I'll look it up)\n• Something else?"
        else:
            # Extract topic from "what is X" pattern
            match = re.search(r'\bwhat is\s+(.+?)(?:\?|$)', text.lower())
            if match:
                topic = match.group(1).strip()
                return f"Do you mean:\n• {topic} as a general concept (I'll look it up)\n• Something else?"
            return "Could you clarify what you're looking for?"
    
    def _generate_project_clarification_question(self, text: str, entity: Optional[str]) -> str:
        """Generate a clarification question when entity exists in project."""
        if entity:
            return f"I found '{entity}' in your project. Do you mean:\n• {entity} as a general concept (I'll look it up)\n• {entity} in your project (I'll analyze your code)\n• Something else?"
        else:
            # Extract topic from "what is X" pattern
            match = re.search(r'\bwhat is\s+(.+?)(?:\?|$)', text.lower())
            if match:
                topic = match.group(1).strip()
                return f"I found '{topic}' in your project. Do you mean:\n• {topic} as a general concept (I'll look it up)\n• {topic} in your project (I'll analyze your code)\n• Something else?"
            return "Could you clarify what you're looking for?"
    
    def _is_project_loaded(self) -> bool:
        """
        Check if a project is actually loaded (has valid structure).
        Returns True only if project scanner exists AND has scanned structure.
        """
        if not self.project_scanner:
            return False
        
        # Check if project has been scanned and has valid structure
        if not hasattr(self.project_scanner, 'has_scanned') or not self.project_scanner.has_scanned:
            # Try a quick scan to see if project exists
            try:
                import os
                if not os.path.exists(self.project_scanner.root_directory):
                    return False
                # Check if Resources folder exists (PyGenesis project indicator)
                resources_path = os.path.join(self.project_scanner.root_directory, "Resources")
                if not os.path.exists(resources_path):
                    return False
                # Quick structure check
                structure = self.project_scanner.scan_project()
                if structure and not structure.get("error"):
                    self.project_scanner.has_scanned = True
                    return True
            except Exception:
                return False
        
        # Project is loaded if structure exists and is valid
        return (
            self.project_scanner.project_structure is not None and
            not self.project_scanner.project_structure.get("error")
        )
    
    def extract_entity(self, text: str, intent: Intent) -> Optional[str]:
        """
        Extract relevant entity from text based on intent.
        E.g., word for dictionary lookup, equation for math, etc.
        """
        text_lower = text.lower()
        
        if intent == Intent.DICTIONARY_LOOKUP:
            # Extract word after "define" or "definition of"
            match = re.search(r'\b(?:define|definition of|meaning of)\s+(\w+)', text_lower)
            if match:
                return match.group(1)
        
        elif intent == Intent.THESAURUS_LOOKUP:
            # Extract word after "synonym for" or "better word for"
            match = re.search(r'\b(?:synonym|better word|another word)\s+(?:for|of)\s+(\w+)', text_lower)
            if match:
                return match.group(1)
        
        elif intent == Intent.MATH_QUERY:
            # Extract math expression - more flexible pattern
            match = re.search(r'([0-9+\-*/().\s^%]+)', text)
            if match:
                expr = match.group(1).strip()
                expr = re.sub(r'^(what is|solve|calculate|compute|find|evaluate)\s+', '', expr, flags=re.IGNORECASE)
                expr = re.sub(r'\b(what|is|solve|calculate|compute|find|evaluate|the|of|a|an)\b', '', expr, flags=re.IGNORECASE)
                expr = expr.strip()
                if expr:
                    return expr
            return text.strip()
        
        elif intent == Intent.RESEARCH_QUERY:
            # Extract research topic (remove question words and punctuation)
            topic = re.sub(r'\b(what|who|why|how|is|are|does|do|research|study|learn about|tell me about)\b', '', text_lower)
            topic = re.sub(r'[?!.,;:]+$', '', topic)
            return topic.strip()
        
        return None
    
    def _is_project_specific_query(self, text_lower: str) -> bool:
        """Detect if query is about the user's project/code (not general knowledge)."""
        project_indicators = [
            r'\bin my project\b',
            r'\bin this project\b',
            r'\bmy code\b',
            r'\bmy class\b',
            r'\bmy function\b',
            r'\bmy script\b',
            r'\bmy object\b',
            r'\bmy sprite\b',
            r'\bmy shader\b',
            r'\bthe player\b',
            r'\bthe game\b',
        ]
        
        for pattern in project_indicators:
            if re.search(pattern, text_lower, re.IGNORECASE):
                return True
        
        return False
    
    def _is_implementation_query(self, text_lower: str) -> bool:
        """Detect if query is asking how to implement/add/create something."""
        implementation_patterns = [
            r'\bhow do i implement\b',
            r'\bhow to implement\b',
            r'\bhow to add\b',
            r'\bhow to create\b',
            r'\bhow to build\b',
            r'\bhow to make\b',
            r'\bimplement\b',
            r'\badd\b.*\bto my\b',
            r'\bcreate\b.*\bfor my\b',
            r'\bbuild\b.*\bfor my\b',
        ]
        
        for pattern in implementation_patterns:
            if re.search(pattern, text_lower, re.IGNORECASE):
                return True
        
        return False
    
    def _is_code_search_query(self, text_lower: str) -> bool:
        """Detect if query is asking where to find something in the code."""
        # Code-specific patterns - must have code-related context
        code_search_patterns = [
            r'\bwhere is\s+.+\s+(?:defined|located|in my code|in the code|in this project|in my project)',
            r'\bwhere can i find\s+.+\s+(?:in my|in the|in this)',
            r'\bfind\b.*\bin my\b',
            r'\bsearch for\b.*\bin my\b',
            r'\blocate\b.*\bin my\b',
            r'\bwhere is\s+[A-Z][a-zA-Z0-9_]+\s+(?:defined|located)',  # Class/function names
        ]
        
        # Check for code-related keywords that indicate code search
        code_keywords = ['defined', 'located', 'in my code', 'in the code', 'in this project', 
                        'function', 'class', 'method', 'variable', 'file']
        
        # First check explicit code patterns
        for pattern in code_search_patterns:
            if re.search(pattern, text_lower, re.IGNORECASE):
                return True
        
        # If "where is" appears, check if it's followed by code-related terms
        if re.search(r'\bwhere is\b', text_lower):
            # Check if the query contains code-related keywords
            if any(keyword in text_lower for keyword in code_keywords):
                return True
            # Check if it's a capitalized word (likely a class/function name)
            if re.search(r'\bwhere is\s+[A-Z][a-zA-Z0-9_]+\b', text_lower):
                return True
        
        return False
    
    def _extract_potential_entity(self, text: str) -> Optional[str]:
        """Extract potential code entity (class/function name) from query."""
        patterns = [
            r'\bwhat is\s+([A-Z][a-zA-Z0-9_]+)\b',
            r'\bwhat is\s+the\s+([A-Z][a-zA-Z0-9_]+)\b',
            r'\bexplain\s+([A-Z][a-zA-Z0-9_]+)\b',
            r'\bhow does\s+([A-Z][a-zA-Z0-9_]+)\s+work\b',
            r'\b([A-Z][a-zA-Z0-9_]+)\s+class\b',
            r'\b([A-Z][a-zA-Z0-9_]+)\s+function\b',
            r'\b([A-Z][a-zA-Z0-9_]+)\s+in my\b',
            # Also handle lowercase for common terms
            r'\bwhat is\s+(python|java|javascript|c\+\+|rust|go)\b',
        ]
        
        for pattern in patterns:
            match = re.search(pattern, text)
            if match:
                entity = match.group(1)
                if entity.lower() not in ['the', 'this', 'that', 'what', 'how', 'why', 'when', 'where']:
                    return entity
        
        return None
    
    def _entity_exists_in_project(self, entity: str) -> bool:
        """Check if an entity (class/function) exists in the project."""
        if not self.project_scanner:
            return False
        
        try:
            # Quick scan if not already done (with caching check)
            if not hasattr(self.project_scanner, 'has_scanned') or not self.project_scanner.has_scanned:
                self.project_scanner.scan_project()
                self.project_scanner.has_scanned = True
            
            structure = self.project_scanner.project_structure
            if not structure:
                return False
            
            # Check classes
            for cls_info in structure.get("classes", []):
                if cls_info.get("name", "").lower() == entity.lower():
                    return True
            
            # Check functions
            for func_info in structure.get("functions", []):
                if func_info.get("name", "").lower() == entity.lower():
                    return True
            
            # Check file names (for resources)
            for file_path in structure.get("files", {}):
                file_name = file_path.split('/')[-1].split('.')[0]
                if file_name.lower() == entity.lower():
                    return True
            
        except Exception:
            return False
        
        return False
    
    def _quick_pattern_check(self, text_lower: str) -> Optional[IntentResult]:
        """
        Quick pattern check for obvious cases before SLM classification.
        Returns high-confidence result for clear cases like math queries.
        """
        # Math queries - highest priority to prevent misclassification
        if (re.search(r'[0-9]+\s*[+\-*/]\s*[0-9]+', text_lower) or 
            re.search(r'\b(?:what is|what\'?s|calculate|solve|compute)\s+[0-9]', text_lower) or
            re.search(r'\b(?:divide|multiply|add|subtract|plus|minus|times)\s+(?:again\s+)?(?:by|to|with)\s+\d+', text_lower)):
            return IntentResult(
                primary_intent=Intent.MATH_QUERY,
                confidence=0.95,  # Very high confidence for math
                entity=self.extract_entity(text_lower, Intent.MATH_QUERY)
            )
        
        # Contextual math references: "divide that by 10", "multiply it by 5"
        if re.search(r'\b(?:divide|multiply|add|subtract)\s+(?:that|this|it|again)?\s*(?:by|to|with)\s*\d+', text_lower):
            return IntentResult(
                primary_intent=Intent.MATH_QUERY,
                confidence=0.95,
                entity=text_lower  # The whole expression is the entity
            )
        
        # Dictionary lookups
        if re.search(r'\b(?:what does|what do)\s+.+\s+mean\b', text_lower):
            return IntentResult(
                primary_intent=Intent.DICTIONARY_LOOKUP,
                confidence=0.9,
                entity=self.extract_entity(text_lower, Intent.DICTIONARY_LOOKUP)
            )
        
        # Research queries: "Where is X" (location/place questions)
        # Check BEFORE code search to prioritize research for location queries
        if re.search(r'\bwhere is\b', text_lower):
            # Check if it's clearly NOT a code query (no code keywords)
            code_indicators = ['defined', 'located in', 'in my code', 'in the code', 
                             'in this project', 'function', 'class', 'method', 'variable']
            has_code_indicator = any(indicator in text_lower for indicator in code_indicators)
            
            if not has_code_indicator:
                # Extract the entity after "where is"
                match = re.search(r'\bwhere is\s+([A-Za-z][A-Za-z0-9\s]+?)(?:\?|$)', text_lower)
                if match:
                    entity = match.group(1).strip()
                    # If it's a single capitalized word, check if it exists in project
                    # Otherwise, treat as research query (location/place)
                    if ' ' in entity or not entity[0].isupper():
                        # Multi-word or lowercase - likely a location/research query
                        return IntentResult(
                            primary_intent=Intent.RESEARCH_QUERY,
                            confidence=0.9,  # High confidence for location queries
                            entity=entity
                        )
                    # Single capitalized word - could be code or location
                    # Default to research (location) unless project context suggests code
                    # Use high confidence to prevent SLM misclassification
                    return IntentResult(
                        primary_intent=Intent.RESEARCH_QUERY,
                        confidence=0.85,  # High enough to be caught by quick check
                        entity=entity
                    )
        
        # RESEARCH QUERIES: "What is X" where X is NOT a number
        # This MUST run before Layer 1 to prevent misclassification
        research_match = re.search(r'\b(?:what is|what are|what\'s|who is|tell me about|explain)\s+([a-zA-Z][a-zA-Z0-9\s]*)', text_lower)
        if research_match:
            topic = research_match.group(1).strip()
            if topic and not topic[0].isdigit():
                return IntentResult(
                    primary_intent=Intent.RESEARCH_QUERY,
                    confidence=0.9,  # High confidence for clear research questions
                    entity=topic
                )
        
        # "How would you" / "How do you" / "How can I" type questions - these are research/guidance
        how_would_match = re.search(r'\b(?:how would you|how do you|how can i|how should i|how do i)\s+(.+?)(?:\?|$)', text_lower)
        if how_would_match:
            topic = how_would_match.group(1).strip()
            if topic:
                return IntentResult(
                    primary_intent=Intent.RESEARCH_QUERY,
                    confidence=0.9,
                    entity=topic
                )
        
        # Simple greetings
        simple_greetings = ['hi', 'hello', 'hey', 'greetings', 'hi nova', 'hello nova', 'hey nova']
        text_clean = text_lower.strip()
        if text_clean in simple_greetings:
            return IntentResult(
                primary_intent=Intent.GENERAL_CHAT,
                confidence=0.95,
                fallback_intents=[],
                requires_clarification=False
            )
        
        return None
    
    def _pattern_classify_with_confidence(self, text_lower: str) -> Optional[tuple[Intent, float]]:
        """
        Pattern-based classification with confidence scoring.
        Returns (Intent, confidence) tuple or None.
        """
        best_intent = None
        best_score = 0
        
        for intent, patterns in self.patterns.items():
            score = 0
            matches = 0
            for pattern in patterns:
                if re.search(pattern, text_lower, re.IGNORECASE):
                    score += 1
                    matches += 1
            
            if matches > 0:
                # Calculate confidence based on match strength
                confidence = min(0.9, 0.5 + (score * 0.1))
                if score > best_score:
                    best_score = score
                    best_intent = (intent, confidence)
        
        return best_intent if best_intent else None
    
    def _apply_context_weighting(
        self, 
        intent: Intent, 
        confidence: float, 
        conversation_history: List[Dict[str, Any]]
    ) -> float:
        """
        Apply conversation context weighting to boost confidence for intents
        that match recent conversation context.
        """
        if not conversation_history:
            return confidence
        
        # Extract recent intents from conversation history (last 3 messages)
        recent_intents = []
        for msg in conversation_history[-3:]:
            # Try to extract intent from message metadata
            if 'intent' in msg and msg['intent']:
                intent_str = msg['intent']
                # Convert string to Intent enum
                try:
                    if isinstance(intent_str, str):
                        # Try to find matching Intent by name or value
                        for intent_enum in Intent:
                            if intent_enum.name == intent_str.upper() or intent_enum.value == intent_str.lower():
                                recent_intents.append(intent_enum)
                                break
                    else:
                        recent_intents.append(intent_str)
                except:
                    pass
            
            # Fallback: Infer intent from Nova's response patterns
            if not recent_intents and msg.get('sender') in ['NOVA', 'Nova']:
                text = msg.get('text', '').lower()
                if any(word in text for word in ['answer is', 'result is', 'equals', 'calculated']):
                    recent_intents.append(Intent.MATH_QUERY)
                elif any(word in text for word in ['definition', 'means', 'refers to']):
                    recent_intents.append(Intent.DICTIONARY_LOOKUP)
        
        # Boost confidence if current intent matches recent context
        if recent_intents and intent in recent_intents:
            # Same intent as recent conversation - boost confidence
            boost = 0.15  # 15% boost
            return min(1.0, confidence + boost)
        elif recent_intents:
            # Different intent - slight penalty (but not too much)
            penalty = 0.05
            return max(0.0, confidence - penalty)
        
        return confidence
    
    def _infer_from_context(self, conversation_history: List[Dict[str, Any]]) -> Optional[Intent]:
        """
        Infer intent from conversation context when classification is uncertain.
        """
        if not conversation_history:
            return None
        
        # Look at last few messages to infer context
        recent_messages = conversation_history[-3:]
        
        # Count intent occurrences
        intent_counts = {}
        for msg in recent_messages:
            if 'intent' in msg:
                intent = msg['intent']
                intent_counts[intent] = intent_counts.get(intent, 0) + 1
        
        # Return most common intent if it appears multiple times
        if intent_counts:
            most_common = max(intent_counts.items(), key=lambda x: x[1])
            if most_common[1] >= 2:  # Appears at least twice
                return most_common[0]
        
        return None
    
    # =========================================================================
    # USER MODE DETECTION
    # =========================================================================
    
    def detect_user_mode(
        self, 
        text: str, 
        intent: Intent,
        conversation_state: Optional[Any] = None
    ) -> UserMode:
        """
        Detect user's conversational phase.
        This is what makes Nova understand WHAT the user is trying to do,
        not just what they're saying.
        
        Args:
            text: User input text
            intent: Classified intent
            conversation_state: Optional ConversationState for context
            
        Returns:
            UserMode indicating user's phase
        """
        text_lower = text.lower().strip()
        
        # Check if user is responding to pending confirmation
        if conversation_state and conversation_state.awaiting_confirmation:
            # ACTING indicators (user confirms pending action)
            if re.search(r'^(yes|yeah|yep|ok|okay|sure|go ahead|do it|proceed|execute|make it|create it|run it)\.?!?$', text_lower):
                return UserMode.ACTING
            # CORRECTING indicators (user rejects/changes)
            if re.search(r'^(no|nope|cancel|stop|wait|actually|instead|change|different)', text_lower):
                return UserMode.CORRECTING
        
        # ACTING indicators (strongest - user wants action NOW)
        acting_patterns = [
            r'^(do it|go ahead|proceed|execute|run|make it|create it)\.?!?$',
            r'^(yes|yeah|yep|ok|okay|sure)[\s,]*(please|do it|go ahead)?\.?!?$',
            r'\b(now|immediately|right now|asap)\b',
            r'^(add|create|delete|remove|modify|change|update|implement|build|make)\s+.+',
        ]
        for pattern in acting_patterns:
            if re.search(pattern, text_lower):
                return UserMode.ACTING
        
        # VERIFYING indicators
        verifying_patterns = [
            r'\b(is that|is this|are you sure|correct|right|sure|confirm)\s*\??$',
            r'^(right|correct)\s*\??$',
            r'\b(did you|have you|will it)\b.*\?$',
        ]
        for pattern in verifying_patterns:
            if re.search(pattern, text_lower):
                return UserMode.VERIFYING
        
        # CORRECTING indicators
        correcting_patterns = [
            r'^(no|wrong|incorrect|actually|wait|stop)\b',
            r'\b(not that|i meant|i mean|instead|rather)\b',
            r'\b(undo|revert|cancel|rollback)\b',
        ]
        for pattern in correcting_patterns:
            if re.search(pattern, text_lower):
                return UserMode.CORRECTING
        
        # EXPLORING indicators (before PLANNING - more open-ended)
        exploring_patterns = [
            r'\b(what if|could we|can we|maybe|perhaps)\b',
            r'\b(options|alternatives|ideas|possibilities|ways)\b',
            r'\b(explore|brainstorm|think about)\b',
        ]
        for pattern in exploring_patterns:
            if re.search(pattern, text_lower):
                return UserMode.EXPLORING
        
        # PLANNING indicators
        planning_patterns = [
            r'\b(how would|how should|how can|how do i|how to)\b',
            r'\b(approach|strategy|plan|best way|better way)\b',
            r'\b(should i|would it be|is it better)\b',
        ]
        for pattern in planning_patterns:
            if re.search(pattern, text_lower):
                return UserMode.PLANNING
        
        # LEARNING indicators
        learning_patterns = [
            r'\b(what is|what are|what does|what do)\b',
            r'\b(explain|tell me|describe|define|meaning)\b',
            r'\b(how does|why does|why is|why are)\b',
            r'\b(understand|learn|know about)\b',
        ]
        for pattern in learning_patterns:
            if re.search(pattern, text_lower):
                return UserMode.LEARNING
        
        # CONVERSATION fallback (greetings, thanks, small talk)
        conversation_patterns = [
            r'^(hi|hello|hey|greetings|good morning|good afternoon|good evening)\b',
            r'^(thanks|thank you|thx|ty)\b',
            r'^(how are you|whats up|what\'s up)\b',
            r'^(bye|goodbye|see you|later)\b',
        ]
        for pattern in conversation_patterns:
            if re.search(pattern, text_lower):
                return UserMode.CONVERSATION
        
        # Default based on intent
        intent_mode_map = {
            Intent.PROJECT_MODIFICATION: UserMode.ACTING,
            Intent.RESOURCE_OPERATION: UserMode.ACTING,
            Intent.CODE_QUERY: UserMode.LEARNING,
            Intent.CODE_SEARCH: UserMode.LEARNING,
            Intent.RESEARCH_QUERY: UserMode.LEARNING,
            Intent.DICTIONARY_LOOKUP: UserMode.LEARNING,
            Intent.THESAURUS_LOOKUP: UserMode.LEARNING,
            Intent.MATH_QUERY: UserMode.ACTING,  # Math is usually direct
            Intent.GENERAL_CHAT: UserMode.CONVERSATION,
            Intent.GRAPH_VISUALIZATION: UserMode.LEARNING,
        }
        
        return intent_mode_map.get(intent, UserMode.CONVERSATION)
    
    def get_confidence_band(self, confidence: float) -> ConfidenceBand:
        """
        Get confidence band for nuanced behavior.
        
        Args:
            confidence: Classification confidence (0.0 to 1.0)
            
        Returns:
            ConfidenceBand for appropriate behavior
        """
        if confidence >= 0.8:
            return ConfidenceBand.HIGH
        elif confidence >= 0.5:
            return ConfidenceBand.MEDIUM
        else:
            return ConfidenceBand.LOW
