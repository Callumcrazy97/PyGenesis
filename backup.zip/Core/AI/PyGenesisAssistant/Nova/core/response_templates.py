"""
Response Templates - Natural, collaborative response formats.
These make Nova feel like a collaborator, not a command-line tool.
"""

from core.models import ResponseStrategy, Intent, UserMode


# Template strings for different response strategies
RESPONSE_TEMPLATES = {
    
    # OPTIONS_PRESENTATION: When user is exploring/planning
    ResponseStrategy.OPTIONS_PRESENTATION: """There are a couple of approaches we could take:

**Option A:** {option_a}
**Option B:** {option_b}
{option_c}
Which direction would you like to go?""",

    # PLAN_PREVIEW: Show plan before executing
    ResponseStrategy.PLAN_PREVIEW: """Here's what I'm planning to do:

{plan_summary}

**Expected outcome:** {outcome}

Would you like me to proceed, or should we adjust the approach?""",

    # EXPLANATION: Teaching mode
    ResponseStrategy.EXPLANATION: """{topic_intro}

{explanation}

{example_section}
{follow_up}""",

    # CONFIRMATION_REQUIRED: Verify understanding
    ResponseStrategy.CONFIRMATION_REQUIRED: """Just to make sure I understand:

You want me to **{action_summary}**

Is that correct?""",

    # CLARIFY_FIRST: Need more info
    ResponseStrategy.CLARIFY_FIRST: """Before I proceed, I need a bit more information:

{clarification_question}""",

    # GUIDED_DIALOGUE: Conversational flow
    ResponseStrategy.GUIDED_DIALOGUE: """{response}

{follow_up_question}""",

    # EXECUTE_AND_REPORT: After successful execution
    ResponseStrategy.EXECUTE_AND_REPORT: """Done! Here's what I did:

{action_summary}

{result_details}""",

    # DIRECT_ANSWER: Simple, direct responses
    ResponseStrategy.DIRECT_ANSWER: """{answer}""",
}


# Greeting responses (conversational)
GREETING_RESPONSES = [
    "Hello! I'm Nova, your AI assistant. How can I help you today?",
    "Hi there! What would you like to work on?",
    "Hey! Ready to help. What's on your mind?",
    "Hello! I'm here to help with coding, planning, or just chatting. What do you need?",
]

# Affirmative responses (when user says "do it", "yes", etc.)
AFFIRMATIVE_RESPONSES = {
    "executing": "Got it! Executing now...",
    "proceeding": "Alright, proceeding with the plan.",
    "understood": "Understood. Let me work on that.",
}

# Clarification templates for different intents
CLARIFICATION_TEMPLATES = {
    Intent.PROJECT_MODIFICATION: "Before I make any changes:\n{question}",
    Intent.RESOURCE_OPERATION: "Just to confirm the resource operation:\n{question}",
    Intent.CODE_QUERY: "To give you the most helpful answer:\n{question}",
    Intent.RESEARCH_QUERY: "To provide accurate information:\n{question}",
}

# Meta-response prefixes (make responses feel more natural)
META_PREFIXES = {
    UserMode.PLANNING: [
        "Let me think about the best approach...",
        "There are a few ways we could do this...",
        "Here's how I'd approach this...",
    ],
    UserMode.LEARNING: [
        "Great question!",
        "Let me explain...",
        "Here's how that works...",
    ],
    UserMode.EXPLORING: [
        "That's an interesting idea!",
        "We could definitely explore that...",
        "Here are some possibilities...",
    ],
    UserMode.VERIFYING: [
        "Let me confirm...",
        "To clarify...",
        "Yes, that's correct!" if True else "Actually...",  # Placeholder logic
    ],
    UserMode.CORRECTING: [
        "I understand, let me adjust...",
        "Got it, I'll change that...",
        "No problem, let's try a different approach...",
    ],
}

# Follow-up questions to keep conversation flowing
FOLLOW_UP_QUESTIONS = {
    Intent.RESEARCH_QUERY: [
        "Would you like me to explain any part in more detail?",
        "Do you want to see how this applies to your project?",
        "Is there anything else you'd like to know about this?",
    ],
    Intent.CODE_QUERY: [
        "Would you like me to show you an example?",
        "Should I explain how this interacts with other parts?",
        "Want me to search for where this is used in your project?",
    ],
    Intent.PROJECT_MODIFICATION: [
        "Should I proceed with this change?",
        "Would you like to see a preview first?",
        "Any adjustments before I make the changes?",
    ],
    Intent.MATH_QUERY: [
        "Need any other calculations?",
        "Would you like me to show the steps?",
    ],
    Intent.GENERAL_CHAT: [
        "Is there anything else I can help with?",
        "What would you like to work on?",
    ],
}


def get_template(strategy: ResponseStrategy) -> str:
    """Get the template string for a response strategy."""
    return RESPONSE_TEMPLATES.get(strategy, RESPONSE_TEMPLATES[ResponseStrategy.DIRECT_ANSWER])


def format_options_response(options: list, intro: str = None) -> str:
    """Format a list of options for presentation."""
    template = RESPONSE_TEMPLATES[ResponseStrategy.OPTIONS_PRESENTATION]
    
    option_a = options[0] if len(options) > 0 else ""
    option_b = options[1] if len(options) > 1 else ""
    option_c = f"**Option C:** {options[2]}\n" if len(options) > 2 else ""
    
    result = template.format(
        option_a=option_a,
        option_b=option_b,
        option_c=option_c
    )
    
    if intro:
        result = f"{intro}\n\n{result}"
    
    return result


def format_explanation_response(
    topic: str, 
    explanation: str, 
    example: str = None,
    follow_up: str = None
) -> str:
    """Format an explanation response."""
    template = RESPONSE_TEMPLATES[ResponseStrategy.EXPLANATION]
    
    topic_intro = f"**{topic}**" if topic else ""
    example_section = f"\n**Example:**\n{example}" if example else ""
    follow_up_text = f"\n{follow_up}" if follow_up else ""
    
    return template.format(
        topic_intro=topic_intro,
        explanation=explanation,
        example_section=example_section,
        follow_up=follow_up_text
    ).strip()


def format_plan_preview(plan_summary: str, outcome: str) -> str:
    """Format a plan preview response."""
    template = RESPONSE_TEMPLATES[ResponseStrategy.PLAN_PREVIEW]
    return template.format(
        plan_summary=plan_summary,
        outcome=outcome
    )


def format_confirmation_request(action: str) -> str:
    """Format a confirmation request."""
    template = RESPONSE_TEMPLATES[ResponseStrategy.CONFIRMATION_REQUIRED]
    return template.format(action_summary=action)


def format_clarification_request(question: str, intent: Intent = None) -> str:
    """Format a clarification request."""
    if intent and intent in CLARIFICATION_TEMPLATES:
        return CLARIFICATION_TEMPLATES[intent].format(question=question)
    return RESPONSE_TEMPLATES[ResponseStrategy.CLARIFY_FIRST].format(
        clarification_question=question
    )


def format_execution_report(action: str, details: str = "") -> str:
    """Format an execution report."""
    template = RESPONSE_TEMPLATES[ResponseStrategy.EXECUTE_AND_REPORT]
    return template.format(
        action_summary=action,
        result_details=details
    ).strip()


def get_follow_up_question(intent: Intent) -> str:
    """Get an appropriate follow-up question for an intent."""
    import random
    questions = FOLLOW_UP_QUESTIONS.get(intent, FOLLOW_UP_QUESTIONS[Intent.GENERAL_CHAT])
    return random.choice(questions)


def get_meta_prefix(user_mode: UserMode) -> str:
    """Get a natural prefix for a response based on user mode."""
    import random
    prefixes = META_PREFIXES.get(user_mode, [])
    return random.choice(prefixes) if prefixes else ""


def get_greeting_response() -> str:
    """Get a random greeting response."""
    import random
    return random.choice(GREETING_RESPONSES)

