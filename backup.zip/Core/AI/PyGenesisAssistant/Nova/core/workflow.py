"""
Core Workflow Pipeline - The main processing pipeline for Nova.
Handles the complete order of operations for user interactions.

Enhanced with UserMode, ResponseStrategy, and ConversationState
for smarter, more natural conversations.
"""
from typing import Optional, Dict, Any, List
from dataclasses import dataclass

from core.models import (
    Intent, UserMode, ResponseStrategy, ConfidenceBand, 
    ConversationState, ClarificationContext
)
from core.intent_router import IntentRouter
from core.tasks import TaskManager, TaskStatus
from core.task_name_generator import TaskNameGenerator
from core.project_scanner import ProjectScanner
from core.transaction_manager import TransactionManager
from core.response_templates import (
    format_options_response, format_explanation_response,
    format_plan_preview, format_confirmation_request,
    format_clarification_request, format_execution_report,
    get_follow_up_question, get_meta_prefix, get_greeting_response
)
from core.language_utils import LanguageUtils, Language
from settings import SETTINGS


@dataclass
class WorkflowContext:
    """Context passed through the workflow pipeline."""
    user_input: str
    intent: Optional[Intent] = None
    entity: Optional[str] = None
    user_mode: Optional[UserMode] = None  # User's conversational phase
    response_strategy: Optional[ResponseStrategy] = None  # How to respond
    confidence: float = 0.0  # Classification confidence
    confidence_band: Optional[ConfidenceBand] = None  # Confidence band
    ast_context: Optional[Dict[str, Any]] = None
    kb_context: Optional[Dict[str, Any]] = None
    capabilities: Optional[Dict[str, Any]] = None  # Capability discovery results
    operation_plan: Optional[Any] = None  # OperationPlan from OperationPlanner
    result: Optional[str] = None
    file_changes: list = None  # List of file operations performed
    task_id: Optional[str] = None  # Associated task ID
    clarification_context: Optional[Any] = None  # ClarificationContext for next message
    app: Optional[Any] = None  # Application instance for accessing PyGenesis settings
    thinking_content: Optional[str] = None  # Thinking process (for research/implementation queries)
    example_code: Optional[str] = None  # Example code preview (for research queries)
    conversation_context: Optional[Dict[str, Any]] = None  # Context from conversation history


class WorkflowPipeline:
    """
    Main workflow pipeline implementing Nova's Order of Operations.
    
    Pipeline Steps:
    1. User Input (already received)
    2. SLM Decider / Intent Routing
    3. Project Knowledge Scan (if code-related)
    4. Capability Discovery (API Surface validation)
    5. Global Knowledge Lookup
    6. Operation Planning (for modification intents)
    7. Cloud AI Fallback (if needed)
    8. Deterministic Execution
    9. UI Feedback (handled by caller)
    """
    
    def __init__(self, task_manager: Optional[TaskManager] = None, project_root: Optional[str] = None, app=None):
        self.project_scanner = ProjectScanner(project_root)
        # Pass project_scanner to IntentRouter for context-aware routing
        self.intent_router = IntentRouter(project_scanner=self.project_scanner)
        self.task_manager = task_manager or TaskManager()
        self.task_name_generator = TaskNameGenerator()
        self.app = app  # Application instance for API access
        
        # Initialize Operation Planner
        from core.operation_planner import OperationPlanner
        self.operation_planner = OperationPlanner(self.task_manager, app)
        
        # Initialize Transaction Manager
        self.transaction_manager = TransactionManager(app)
        
        # Initialize Context Analyzer for conversation awareness
        from core.context_analyzer import ContextAnalyzer
        self.context_analyzer = ContextAnalyzer()
        
        # Initialize Conversation State - tracks context across messages
        self.conversation_state = ConversationState()
        
        # Track last operation for feedback/undo
        self._last_user_query: Optional[str] = None
        self._last_intent: Optional[Intent] = None
        self._last_transaction_id: Optional[str] = None
        
        # Initialize language utils
        self.language_utils = None
        self._init_language_utils()
        
        # Engines will be added incrementally
        self.engines = {}
        self.executors = {}
    
    def register_engine(self, intent: Intent, engine):
        """Register an engine for a specific intent type."""
        self.engines[intent] = engine
    
    def register_executor(self, intent: Intent, executor):
        """Register an executor for a specific intent type."""
        self.executors[intent] = executor
    
    def _init_language_utils(self):
        """Initialize language utilities from settings."""
        try:
            if self.app and hasattr(self.app, 'settings'):
                language_setting = self.app.settings.get("Language", "en_uk")
                language = LanguageUtils.get_language_from_setting(language_setting)
                self.language_utils = LanguageUtils(language)
            else:
                # Default to UK English
                self.language_utils = LanguageUtils(Language.EN_UK)
        except Exception:
            # Fallback to UK English
            self.language_utils = LanguageUtils(Language.EN_UK)
    
    def process(
        self, 
        user_input: str, 
        previous_clarification: Optional[Any] = None,
        conversation_history: Optional[List[Dict[str, Any]]] = None
    ) -> WorkflowContext:
        """
        Process user input through the complete workflow pipeline.
        Returns WorkflowContext with result and metadata.
        
        Args:
            user_input: User's input text
            previous_clarification: Optional ClarificationContext from previous message
            conversation_history: Optional list of previous messages for context awareness
        """
        # Step 1: Analyze conversation context
        enhanced_input = user_input
        context_info = {}
        
        if conversation_history:
            context_info = self.context_analyzer.analyze_context(user_input, conversation_history)
            if context_info.get('has_reference'):
                enhanced_input = self.context_analyzer.enhance_query_with_context(user_input, context_info)
                # If it's a math operation reference, we can handle it directly
                if context_info.get('reference_type') == 'math_operation' and context_info.get('extracted_value') is not None:
                    # Direct math result - create a simple response
                    result_value = context_info['extracted_value']
                    context = WorkflowContext(user_input=user_input, app=self.app)
                    context.intent = Intent.MATH_QUERY
                    context.user_mode = UserMode.ACTING
                    context.result = f"The answer is {result_value}"
                    # Create task
                    task_name = self.task_name_generator.generate_task_name(
                        user_input, context.intent, None
                    )
                    task = self.task_manager.create_task(
                        name=task_name,
                        description=f"Processing: {user_input[:100]}",
                        user_input=user_input,
                        intent=context.intent.value
                    )
                    context.task_id = task.id
                    task.start()
                    task.complete(context.result)
                    return context
        
        context = WorkflowContext(user_input=enhanced_input, app=self.app)
        context.conversation_context = context_info  # Store context info
        
        # Step 0: Check for feedback/undo requests FIRST (before intent routing)
        from core.feedback_handler import FeedbackHandler
        feedback_handler = FeedbackHandler(self.transaction_manager, self.app)
        if feedback_handler.is_feedback_request(user_input):
            # Handle feedback
            handled, response, misinformation_data = feedback_handler.handle_feedback(
                user_input,
                last_user_query=getattr(self, '_last_user_query', None),
                last_intent=getattr(self, '_last_intent', None),
                last_transaction_id=getattr(self, '_last_transaction_id', None)
            )
            if handled:
                context.result = response
                context.intent = Intent.GENERAL_CHAT  # Feedback is treated as chat
                context.user_mode = UserMode.CORRECTING
                
                # Create task for feedback
                task_name = self.task_name_generator.generate_task_name(
                    user_input, context.intent, None
                )
                task = self.task_manager.create_task(
                    name=task_name,
                    description=f"Processing feedback: {user_input[:100]}",
                    user_input=user_input,
                    intent=context.intent.value
                )
                context.task_id = task.id
                task.start()
                task.complete(response)
                return context
        
        # Step 0.5: Check for pending plan confirmation ("do it", "yes", etc.)
        if self.conversation_state.has_pending_plan():
            user_mode = self.intent_router.detect_user_mode(
                user_input, Intent.PROJECT_MODIFICATION, self.conversation_state
            )
            if user_mode == UserMode.ACTING:
                # User confirmed - execute the pending plan
                context.intent = self.conversation_state.last_intent or Intent.PROJECT_MODIFICATION
                context.user_mode = UserMode.ACTING
                context.operation_plan = self.conversation_state.pending_plan
                context.entity = self.conversation_state.last_entity
                
                # Clear pending plan
                self.conversation_state.clear_pending_plan()
                
                # Create task and execute
                task_name = self.task_name_generator.generate_task_name(
                    user_input, context.intent, context.entity
                )
                task = self.task_manager.create_task(
                    name=task_name,
                    description=f"Executing confirmed plan",
                    user_input=user_input,
                    intent=context.intent.value if context.intent else None,
                )
                context.task_id = task.id
                task.start()
                
                # Execute the plan
                context.result = self._execute_with_plan(context)
                task.complete(context.result)
                
                # Update conversation state
                self.conversation_state.update(
                    intent=context.intent,
                    entity=context.entity,
                    user_mode=context.user_mode,
                    result=context.result,
                    user_query=user_input
                )
                return context
            
            elif user_mode == UserMode.CORRECTING:
                # User rejected - clear pending plan
                self.conversation_state.clear_pending_plan()
                context.intent = Intent.GENERAL_CHAT
                context.user_mode = UserMode.CORRECTING
                context.result = "No problem, I've cancelled that. What would you like to do instead?"
                
                task_name = self.task_name_generator.generate_task_name(
                    user_input, context.intent, None
                )
                task = self.task_manager.create_task(
                    name=task_name,
                    description=f"Plan cancelled",
                    user_input=user_input,
                    intent=context.intent.value,
                )
                context.task_id = task.id
                task.start()
                task.complete(context.result)
                return context
        
        # Step 2: SLM Decider / Intent Routing (with 4-layer resolution stack)
        # Pass conversation history for context-aware classification
        intent_result = self.intent_router.classify(
            user_input, 
            previous_clarification,
            conversation_history
        )
        context.intent = intent_result.primary_intent
        context.entity = intent_result.entity or self.intent_router.extract_entity(user_input, context.intent)
        context.confidence = intent_result.confidence
        context.confidence_band = self.intent_router.get_confidence_band(intent_result.confidence)
        
        # Step 2.5: Detect User Mode (GPT Pillar 1)
        context.user_mode = self.intent_router.detect_user_mode(
            user_input, context.intent, self.conversation_state
        )
        
        # Step 2.6: Determine Response Strategy (GPT Pillar 2)
        context.response_strategy = self._determine_response_strategy(
            context.intent, context.user_mode, context.confidence
        )
        
        # Store for potential feedback handling
        self._last_user_query = user_input
        self._last_intent = context.intent
        
        # Step 3: Create task for this request
        task_name = self.task_name_generator.generate_task_name(
            user_input, context.intent, context.entity
        )
        task = self.task_manager.create_task(
            name=task_name,
            description=f"Processing: {user_input[:100]}",
            user_input=user_input,
            intent=context.intent.value if context.intent else None,
        )
        context.task_id = task.id
        
        # Handle clarification requests (after task creation)
        if intent_result.requires_clarification and intent_result.clarification_question:
            clarification = ClarificationContext(
                original_query=user_input,
                original_intent=context.intent,
                clarification_question=intent_result.clarification_question,
                clarification_options=[],  # Can be populated if needed
                task_id=task.id
            )
            context.result = format_clarification_request(
                intent_result.clarification_question, context.intent
            )
            # Store clarification context for next message
            context.clarification_context = clarification
            self.conversation_state.awaiting_clarification = True
            task.start()
            return context
        
        # Handle response strategy: CLARIFY_FIRST
        if context.response_strategy == ResponseStrategy.CLARIFY_FIRST:
            question = self._generate_smart_clarification(context)
            context.result = format_clarification_request(question, context.intent)
            self.conversation_state.awaiting_clarification = True
            task.start()
            return context
        
        # Mark task as active (we're working on it)
        task.start()
        
        # Step 4: Project Knowledge Scan (if code-related)
        # Note: For async scanning, we use cached results if available
        # Full async scanning is handled by the caller if needed
        if context.intent in [Intent.CODE_QUERY, Intent.CODE_SEARCH, Intent.PROJECT_MODIFICATION, Intent.RESOURCE_OPERATION, Intent.GRAPH_VISUALIZATION]:
            # Use cached scan if available, otherwise do quick scan
            context.ast_context = self._scan_project_cached()
        
        # Step 5: Capability Discovery (API Surface validation)
        if context.intent in [Intent.PROJECT_MODIFICATION, Intent.RESOURCE_OPERATION]:
            context.capabilities = self._discover_capabilities(context)
        
        # Step 6: Global Knowledge Lookup
        context.kb_context = self._lookup_knowledge(user_input, context.intent)
        
        # Step 7: Operation Planning (for modification intents ONLY)
        # IMPORTANT: Do NOT create operation plans for GENERAL_CHAT, MATH_QUERY, RESEARCH_QUERY, etc.
        # Only create plans for actual modification/resource operations
        
        # SAFEGUARD: Check if this looks like a research/learning query
        # These should NEVER get operation plans
        text_lower = context.user_input.lower().strip()
        research_patterns = [
            'what is', 'what are', 'who is', 'what does', 'explain', 
            'tell me about', 'how does', 'why', 'define'
        ]
        is_research_query = any(text_lower.startswith(p) or f' {p} ' in f' {text_lower} ' for p in research_patterns)
        
        # Override intent if it looks like research but was misclassified
        if is_research_query and context.intent in [Intent.PROJECT_MODIFICATION, Intent.RESOURCE_OPERATION]:
            # This is clearly a research query, not a modification
            context.intent = Intent.RESEARCH_QUERY
            context.response_strategy = ResponseStrategy.EXPLANATION
        
        if context.intent in [Intent.PROJECT_MODIFICATION, Intent.RESOURCE_OPERATION]:
            # Double-check: Don't create plans for simple greetings or chat
            simple_greetings = ['hi', 'hello', 'hey', 'greetings', 'hi nova', 'hello nova']
            if text_lower in simple_greetings or any(greeting in text_lower for greeting in simple_greetings):
                # This is a greeting, not a modification request
                # Skip operation planning and go straight to execution
                context.operation_plan = None
            else:
                context.operation_plan = self.operation_planner.plan(context)
            
            # Validate plan
            if context.operation_plan:
                is_valid, error = self.operation_planner.validate_plan(context.operation_plan)
                if not is_valid:
                    # Plan is invalid, return error
                    context.result = f"⚠️ Operation plan validation failed: {error}\n\nPlease check your request and try again."
                    if context.task_id:
                        task = self.task_manager.get_task(context.task_id)
                        if task:
                            task.complete(context.result)
                    return context
                
                # Handle based on UserMode and ResponseStrategy
                # If user is PLANNING or EXPLORING, show options instead of executing
                if context.user_mode in [UserMode.PLANNING, UserMode.EXPLORING]:
                    plan_summary = self.operation_planner.get_plan_summary(context.operation_plan)
                    context.result = format_plan_preview(
                        plan_summary,
                        context.operation_plan.expected_outcome
                    )
                    # Store plan for later execution when user says "do it"
                    self.conversation_state.set_pending_plan(
                        context.operation_plan,
                        context.user_input,
                        []
                    )
                    if context.task_id:
                        task = self.task_manager.get_task(context.task_id)
                        if task:
                            task.complete(context.result)
                    return context
                
                # If CONFIRMATION_REQUIRED strategy or plan requires confirmation
                if (context.response_strategy == ResponseStrategy.CONFIRMATION_REQUIRED or 
                    context.operation_plan.requires_confirmation):
                    plan_summary = self.operation_planner.get_plan_summary(context.operation_plan)
                    context.result = format_confirmation_request(plan_summary)
                    # Store plan for later execution
                    self.conversation_state.set_pending_plan(
                        context.operation_plan,
                        context.user_input,
                        []
                    )
                    if context.task_id:
                        task = self.task_manager.get_task(context.task_id)
                        if task:
                            task.complete(context.result)
                    return context
        
        # Step 8: Cloud AI Fallback (if needed)
        if self._should_use_cloud(context.intent):
            # TODO: Implement cloud AI integration
            context.result = self._cloud_ai_process(context)
            return context
        
        # Step 9: Deterministic Execution
        if context.operation_plan:
            # Execute using operation plan
            context.result = self._execute_with_plan(context)
        else:
            # Execute normally (no plan needed)
            context.result = self._execute(context)
        
        # Step 9.5: Apply language correction to result (preserve code blocks)
        if context.result and self.language_utils:
            context.result = self.language_utils.correct_spelling(context.result, preserve_code=True)
        
        # Step 10: Update Conversation State
        self.conversation_state.update(
            intent=context.intent,
            entity=context.entity,
            user_mode=context.user_mode,
            result=context.result,
            user_query=user_input
        )
        
        # Step 11: Complete task
        if context.task_id:
            task = self.task_manager.get_task(context.task_id)
            if task:
                task.complete(context.result)
        
        return context
    
    def _scan_project(self) -> Optional[Dict[str, Any]]:
        """Step 3: Scan project using AST (synchronous, blocking)."""
        try:
            # Scan project and return structure
            structure = self.project_scanner.scan_project()
            return {
                "structure": structure,
                "scanner": self.project_scanner,  # Pass scanner for detailed queries
            }
        except Exception as e:
            return {"error": str(e)}
    
    def _scan_project_cached(self) -> Optional[Dict[str, Any]]:
        """Get cached project scan or perform quick scan if not available."""
        try:
            # Check if we have a cached scan
            if (self.project_scanner.has_scanned and 
                self.project_scanner.project_structure and
                not self.project_scanner.project_structure.get("error")):
                return {
                    "structure": self.project_scanner.project_structure,
                    "scanner": self.project_scanner,
                    "cached": True
                }
            
            # Otherwise, do a quick scan (this is still blocking, but faster)
            # For full async scanning, use ProjectScanWorker from async_scanner
            structure = self.project_scanner.scan_project()
            return {
                "structure": structure,
                "scanner": self.project_scanner,
                "cached": False
            }
        except Exception as e:
            return {"error": str(e)}
    
    def _lookup_knowledge(self, query: str, intent: Intent) -> Optional[Dict[str, Any]]:
        """Step 4: Lookup in PyGenesis knowledge base."""
        try:
            from pathlib import Path
            import os
            
            # Find knowledge base file
            nova_dir = Path(__file__).parent.parent
            kb_path = nova_dir / "data" / "PyGenesis_KnowledgeBase.md"
            
            if kb_path.exists():
                kb_content = kb_path.read_text(encoding="utf-8")
                return {
                    "knowledge_base": kb_content,
                    "path": str(kb_path)
                }
        except Exception as e:
            # If knowledge base lookup fails, continue without it
            pass
        
        return None
    
    def _should_use_cloud(self, intent: Intent) -> bool:
        """Step 5: Determine if cloud AI should be used."""
        # Only use cloud if:
        # 1. Cloud Mode is ON
        # 2. Intent requires complex reasoning
        if SETTINGS.Mode != "Cloud":
            return False
        
        complex_intents = [
            Intent.CODE_QUERY,
            Intent.CODE_SEARCH,
            Intent.PROJECT_MODIFICATION,
            Intent.RESOURCE_OPERATION,
            Intent.GRAPH_VISUALIZATION,
        ]
        
        return intent in complex_intents
    
    def _cloud_ai_process(self, context: WorkflowContext) -> str:
        """Step 5: Process using cloud AI (stub for now)."""
        # TODO: Implement Gemini/OpenAI integration
        return "(Cloud AI processing not yet implemented)"
    
    def _discover_capabilities(self, context: WorkflowContext) -> Optional[Dict[str, Any]]:
        """Step 4: Discover available capabilities via API Surface."""
        from core.api_manifest import get_validator
        
        validator = get_validator()
        
        # Check if project is open
        project_open = False
        if self.app and hasattr(self.app, 'project_manager'):
            project_open = bool(self.app.project_manager.get_project_path())
        
        # Get available methods
        available_methods = validator.list_available_methods()
        
        return {
            "project_open": project_open,
            "available_methods": available_methods,
            "resource_types": validator.get_resource_types(),
        }
    
    def _execute(self, context: WorkflowContext) -> str:
        """Step 8: Execute deterministic action based on intent (non-plan execution)."""
        # Check if we have an executor for this intent
        if context.intent in self.executors:
            executor = self.executors[context.intent]
            return executor.execute(context)
        
        # Check if we have an engine for this intent
        if context.intent in self.engines:
            engine = self.engines[context.intent]
            return engine.process(context)
        
        # Fallback response
        return f"I received your {context.intent.value} request, but this feature is not yet implemented."
    
    def _execute_with_plan(self, context: WorkflowContext) -> str:
        """Step 8: Execute using operation plan (plan-based execution with transactions)."""
        if not context.operation_plan:
            return "No operation plan available for execution."
        
        plan = context.operation_plan
        
        # Begin transaction
        transaction_id = self.transaction_manager.begin_transaction(plan)
        
        try:
            # Execute all operations in transaction
            for operation in plan.operations:
                # Add operation to transaction
                self.transaction_manager.add_operation(
                    transaction_id=transaction_id,
                    component=operation.component,
                    method=operation.method,
                    params=operation.params,
                )
            
            # Commit transaction (all or nothing)
            success = self.transaction_manager.commit(transaction_id)
            
            # Store transaction ID for potential feedback/undo
            self._last_transaction_id = transaction_id
            
            if success:
                # All operations succeeded
                results = []
                for operation in plan.operations:
                    results.append(f"✓ {operation.description}")
                
                summary = f"**Operation Complete**\n\n"
                summary += "\n".join(results)
                summary += f"\n\n**Expected Outcome:** {plan.expected_outcome}"
                return summary
            else:
                # Transaction failed - all operations rolled back
                transaction_state = self.transaction_manager.get_transaction_state(transaction_id)
                error_msg = transaction_state.get("error_message", "Unknown error")
                return f"⚠️ **Operation Failed**\n\nAll changes have been rolled back.\n\nError: {error_msg}"
        
        except Exception as e:
            # Exception occurred - rollback
            self.transaction_manager.rollback(transaction_id, reason=str(e))
            return f"⚠️ **Operation Failed**\n\nAll changes have been rolled back.\n\nError: {str(e)}"
    
    def _determine_response_strategy(
        self, 
        intent: Intent, 
        user_mode: UserMode, 
        confidence: float
    ) -> ResponseStrategy:
        """
        Determine how to respond based on intent, user mode, and confidence.
        This is GPT Pillar 2 - Response Strategy Layer.
        
        Args:
            intent: Classified intent
            user_mode: User's conversational phase
            confidence: Classification confidence
            
        Returns:
            ResponseStrategy for how Nova should respond
        """
        # For non-modification intents, just try to answer - don't ask for clarification
        # Only modification intents need high confidence to proceed
        safe_intents = [
            Intent.GENERAL_CHAT, Intent.MATH_QUERY, Intent.RESEARCH_QUERY,
            Intent.DICTIONARY_LOOKUP, Intent.THESAURUS_LOOKUP, Intent.CODE_QUERY,
            Intent.CODE_SEARCH, Intent.GRAPH_VISUALIZATION
        ]
        
        # For safe intents (no file changes), always try to answer
        if intent in safe_intents:
            if user_mode == UserMode.LEARNING:
                return ResponseStrategy.EXPLANATION
            elif user_mode == UserMode.EXPLORING:
                return ResponseStrategy.OPTIONS_PRESENTATION
            elif user_mode == UserMode.CONVERSATION:
                return ResponseStrategy.GUIDED_DIALOGUE
            else:
                return ResponseStrategy.DIRECT_ANSWER
        
        # Only ask for clarification for modification intents with low confidence
        if confidence < 0.5 and intent in [Intent.PROJECT_MODIFICATION, Intent.RESOURCE_OPERATION]:
            return ResponseStrategy.CLARIFY_FIRST
        
        # ACTING mode with modification intent -> check confidence
        if user_mode == UserMode.ACTING:
            if intent in [Intent.PROJECT_MODIFICATION, Intent.RESOURCE_OPERATION]:
                if confidence >= 0.8:
                    return ResponseStrategy.EXECUTE_AND_REPORT
                else:
                    return ResponseStrategy.CONFIRMATION_REQUIRED
            else:
                return ResponseStrategy.DIRECT_ANSWER
        
        # PLANNING mode -> always show options/plan
        if user_mode == UserMode.PLANNING:
            if intent in [Intent.PROJECT_MODIFICATION, Intent.RESOURCE_OPERATION]:
                return ResponseStrategy.PLAN_PREVIEW
            else:
                return ResponseStrategy.OPTIONS_PRESENTATION
        
        # EXPLORING mode -> present options
        if user_mode == UserMode.EXPLORING:
            return ResponseStrategy.OPTIONS_PRESENTATION
        
        # LEARNING mode -> explain
        if user_mode == UserMode.LEARNING:
            return ResponseStrategy.EXPLANATION
        
        # VERIFYING mode -> confirm understanding
        if user_mode == UserMode.VERIFYING:
            return ResponseStrategy.CONFIRMATION_REQUIRED
        
        # CORRECTING mode -> clarify what they want
        if user_mode == UserMode.CORRECTING:
            return ResponseStrategy.CLARIFY_FIRST
        
        # CONVERSATION -> guided dialogue
        if user_mode == UserMode.CONVERSATION:
            return ResponseStrategy.GUIDED_DIALOGUE
        
        return ResponseStrategy.DIRECT_ANSWER
    
    def _generate_smart_clarification(self, context: WorkflowContext) -> str:
        """
        Generate a smart clarification question based on context.
        
        Args:
            context: Current workflow context
            
        Returns:
            Clarification question string
        """
        intent = context.intent
        entity = context.entity
        confidence = context.confidence
        
        # Low confidence - general clarification
        if confidence < 0.5:
            return f"I'm not quite sure what you're asking. Could you rephrase that, or tell me more about what you'd like to do?"
        
        # Intent-specific clarifications
        if intent == Intent.PROJECT_MODIFICATION:
            if entity:
                return f"Before I make any changes, I want to make sure I understand:\n\nYou want me to modify **{entity}** in your project?\n\nCould you be more specific about what changes you'd like?"
            else:
                return "I understand you want to modify something, but I need more details:\n\n• What would you like me to change?\n• Where should I make these changes?"
        
        elif intent == Intent.RESOURCE_OPERATION:
            return "I can help with that resource operation. Could you specify:\n\n• What type of resource (sprite, object, script, etc.)?\n• What action (create, rename, delete)?"
        
        elif intent == Intent.CODE_QUERY:
            if entity:
                return f"I'd like to help you understand **{entity}**. Are you asking about:\n\n• How it works in your project?\n• The general concept?"
            else:
                return "What aspect of the code would you like me to explain?"
        
        elif intent == Intent.RESEARCH_QUERY:
            if entity:
                return f"I can tell you about **{entity}**. Would you like:\n\n• A general explanation?\n• How it applies to game development?\n• Examples?"
            else:
                return "What would you like to learn about?"
        
        # Default clarification
        return "Could you tell me more about what you'd like to do?"
    
    def get_conversation_state(self) -> ConversationState:
        """Get the current conversation state."""
        return self.conversation_state
    
    def reset_conversation_state(self):
        """Reset the conversation state for a new conversation."""
        self.conversation_state = ConversationState()

