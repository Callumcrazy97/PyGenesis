"""
Pattern-Driven Synthetic Data Generator for Nova's Neural Network.

Generates thousands of training examples from declarative templates.
This replaces manual enumeration with scalable pattern-based generation.
"""
import json
import random
from pathlib import Path
from typing import List, Dict, Any


def generate_from_templates(
    templates: Dict[str, Any],
    samples_per_template: int = 300,
    seed: int = 42
) -> List[Dict[str, str]]:
    """
    Generate training data from intent templates.
    
    Args:
        templates: Dictionary of intent templates (from intent_templates.json)
        samples_per_template: Number of samples to generate per template
        seed: Random seed for reproducibility
        
    Returns:
        List of {"text": str, "intent": str} dictionaries
    """
    random.seed(seed)
    data = []
    
    for intent, spec in templates.items():
        tmpl_list = spec["templates"]
        vars_dict = spec.get("variables", {})
        
        for tmpl in tmpl_list:
            for _ in range(samples_per_template):
                text = tmpl
                
                # Replace variables in template
                for var_name, var_values in vars_dict.items():
                    if isinstance(var_values, list):
                        # Check if it's a range [min, max] (2 numbers)
                        if len(var_values) == 2 and all(isinstance(v, (int, float)) for v in var_values):
                            # Range: [min, max]
                            value = random.randint(int(var_values[0]), int(var_values[1]))
                        else:
                            # Choose from list
                            value = random.choice(var_values)
                    else:
                        # Single value or fallback
                        value = var_values
                    
                    text = text.replace(f"{{{var_name}}}", str(value))
                
                # Only add if template was fully resolved (no remaining {})
                if "{" not in text:
                    data.append({
                        "text": text,
                        "intent": intent
                    })
    
    return data


def load_manual_examples(manual_file: Path) -> List[Dict[str, str]]:
    """
    Load manually curated examples (edge cases, ambiguous phrases, etc.).
    
    Args:
        manual_file: Path to manual_examples.json
        
    Returns:
        List of examples
    """
    if not manual_file.exists():
        return []
    
    with open(manual_file, 'r', encoding='utf-8') as f:
        return json.load(f)


def main():
    """Generate training data from templates."""
    script_dir = Path(__file__).parent
    
    # Paths
    templates_file = script_dir / "intent_templates.json"
    manual_file = script_dir / "manual_examples.json"
    output_file = script_dir / "training_data.json"
    
    print("=" * 70)
    print("Nova Training Data Generator")
    print("=" * 70)
    print()
    
    # Load templates
    if not templates_file.exists():
        print(f"ERROR: Templates file not found: {templates_file}")
        print("   Please create intent_templates.json first.")
        return
    
    print(f"[*] Loading templates from: {templates_file}")
    with open(templates_file, 'r', encoding='utf-8') as f:
        templates = json.load(f)
    
    # Count templates
    total_templates = sum(len(spec["templates"]) for spec in templates.values())
    print(f"   Found {len(templates)} intents with {total_templates} templates")
    print()
    
    # Generate synthetic data
    print("[*] Generating synthetic training data...")
    samples_per_template = 300
    synthetic_data = generate_from_templates(templates, samples_per_template=samples_per_template)
    print(f"   Generated {len(synthetic_data)} synthetic examples")
    print()
    
    # Load manual examples (edge cases)
    print(f"[*] Loading manual examples from: {manual_file}")
    manual_data = load_manual_examples(manual_file)
    if manual_data:
        print(f"   Loaded {len(manual_data)} manual examples")
    else:
        print("   No manual examples found (this is okay)")
    print()
    
    # Combine data
    all_data = synthetic_data + manual_data
    
    # Shuffle for better training
    random.shuffle(all_data)
    
    # Save
    print(f"[*] Saving to: {output_file}")
    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump(all_data, f, indent=2, ensure_ascii=False)
    
    # Statistics
    print()
    print("=" * 70)
    print("Generation Complete!")
    print("=" * 70)
    print(f"Total examples: {len(all_data)}")
    print(f"  - Synthetic: {len(synthetic_data)}")
    print(f"  - Manual: {len(manual_data)}")
    print()
    print("Intent distribution:")
    intent_counts = {}
    for item in all_data:
        intent = item["intent"]
        intent_counts[intent] = intent_counts.get(intent, 0) + 1
    
    for intent, count in sorted(intent_counts.items()):
        percentage = (count / len(all_data)) * 100
        print(f"  {intent:15s}: {count:5d} ({percentage:5.1f}%)")
    print("=" * 70)


if __name__ == "__main__":
    main()

