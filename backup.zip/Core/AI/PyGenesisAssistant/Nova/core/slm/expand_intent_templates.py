import json
import itertools
import random

def expand(intent_spec, samples_per_pattern=300):
    results = []

    axes = intent_spec.get("axes", {})
    patterns = intent_spec.get("patterns", [])
    variables = intent_spec.get("variables", {})

    axis_keys = list(axes.keys())
    axis_values = list(axes.values())

    axis_combinations = list(itertools.product(*axis_values)) or [()]

    for pattern in patterns:
        for combo in axis_combinations:
            mapping = dict(zip(axis_keys, combo))

            for _ in range(samples_per_pattern):
                text = pattern

                # Replace axis tokens
                for k, v in mapping.items():
                    text = text.replace(f"{{{k}}}", v)

                # Replace numeric / list variables
                for var, vals in variables.items():
                    if isinstance(vals, list):
                        value = random.choice(vals)
                    else:
                        value = random.randint(vals[0], vals[1])
                    text = text.replace(f"{{{var}}}", str(value))

                results.append(text)

    return results


def generate_all(input_file, output_file):
    with open(input_file, "r", encoding="utf-8") as f:
        intents = json.load(f)

    dataset = []

    for intent, spec in intents.items():
        texts = expand(spec)
        dataset.extend({"text": t, "intent": intent} for t in texts)

    with open(output_file, "w", encoding="utf-8") as f:
        json.dump(dataset, f, indent=2)


if __name__ == "__main__":
    generate_all("intent_templates.json", "training_data.json")
