"""
Training script for Custom Neural Network Model.
Modular training pipeline supporting automated retraining and incremental updates.
"""
import json
import sys
import subprocess
from pathlib import Path
from typing import List, Tuple, Optional, Dict

# Check for numpy first
try:
    import numpy as np
except ImportError:
    print("⚠️  numpy is not installed. Attempting to install...")
    try:
        subprocess.check_call([sys.executable, "-m", "pip", "install", "numpy"])
        import numpy as np
        print("✅ numpy installed successfully")
    except subprocess.CalledProcessError:
        print("❌ Failed to install numpy automatically.")
        print("   Please install manually: pip install numpy")
        sys.exit(1)

# Add parent directory to path for imports
sys.path.insert(0, str(Path(__file__).parent.parent))

from slm.custom_neural_model import CustomNeuralModel, MISCLASSIFICATION_LOG


def load_training_data(data_file: Path) -> List[Tuple[str, str]]:
    """
    Load training data from JSON file.
    
    Args:
        data_file: Path to training_data.json
        
    Returns:
        List of (text, intent_name) tuples
    """
    if not data_file.exists():
        print(f"Training data file not found: {data_file}")
        return []
    
    with open(data_file, 'r') as f:
        data = json.load(f)
    
    examples = []
    for item in data:
        text = item.get("text", "")
        intent = item.get("intent", "")
        if text and intent:
            examples.append((text, intent))
    
    return examples


def augment_training_data(examples: List[Tuple[str, str]]) -> List[Tuple[str, str]]:
    """
    Augment training data with variations.
    
    Args:
        examples: Original training examples
        
    Returns:
        Augmented list with variations
    """
    augmented = list(examples)  # Start with original
    
    # Add variations with different capitalization
    for text, intent in examples:
        # Uppercase
        augmented.append((text.upper(), intent))
        # Title case
        augmented.append((text.title(), intent))
        # Add punctuation variations
        if not text.endswith(('.', '!', '?')):
            augmented.append((text + '.', intent))
            augmented.append((text + '?', intent))
    
    return augmented


def load_misclassifications() -> List[Dict]:
    """
    Load misclassified examples from quarantine log file.
    
    NOTE: These are quarantined for manual review, not automatically used.
    Review and promote selectively to manual_examples.json before retraining.
    
    Returns:
        List of misclassification dictionaries
    """
    if not MISCLASSIFICATION_LOG.exists():
        return []
    
    with open(MISCLASSIFICATION_LOG, 'r') as f:
        return json.load(f)


def clear_misclassifications():
    """
    Clear the misclassification quarantine log.
    
    WARNING: Only clear if you've reviewed and promoted good examples
    to manual_examples.json. Otherwise you'll lose valuable training data.
    """
    if MISCLASSIFICATION_LOG.exists():
        MISCLASSIFICATION_LOG.unlink()


def create_model(architecture: Optional[Dict] = None) -> CustomNeuralModel:
    """
    Create a new model instance.
    
    Args:
        architecture: Optional dict with hidden_size_1, hidden_size_2
        
    Returns:
        CustomNeuralModel instance
    """
    if architecture is None:
        architecture = {"hidden_size_1": 128, "hidden_size_2": 64}
    
    return CustomNeuralModel(
        hidden_size_1=architecture.get("hidden_size_1", 128),
        hidden_size_2=architecture.get("hidden_size_2", 64)
    )


def prepare_training_data(
    data_file: Path,
    include_misclassifications: bool = False,  # Changed default to False - require explicit opt-in
    regenerate_if_missing: bool = True
) -> List[Tuple[str, str]]:
    """
    Load and prepare training data.
    
    NOTE: include_misclassifications defaults to False to prevent automatic
    training on unverified data. Only set to True after reviewing and curating
    misclassifications.json.
    
    Args:
        data_file: Path to training_data.json
        include_misclassifications: If True, include misclassified examples (requires review first)
        regenerate_if_missing: If True, generate data from templates if file missing
        
    Returns:
        List of (text, intent) tuples
    """
    # Check if training data exists, regenerate if missing
    if not data_file.exists() and regenerate_if_missing:
        print(f"⚠️  Training data not found: {data_file}")
        print("   Attempting to generate from templates...")
        try:
            # Import generator
            script_dir = data_file.parent
            generator_script = script_dir / "generate_training_data.py"
            if generator_script.exists():
                import subprocess
                import sys
                subprocess.run([sys.executable, str(generator_script)], check=True)
                print("   ✅ Training data generated successfully")
            else:
                print("   ⚠️  Generator script not found, skipping regeneration")
        except Exception as e:
            print(f"   ❌ Failed to generate training data: {e}")
            print("   Please run generate_training_data.py manually")
    
    # Load main training data
    examples = load_training_data(data_file)
    
    # Optionally include misclassifications
    if include_misclassifications:
        misclassifications = load_misclassifications()
        for item in misclassifications:
            examples.append((item["text"], item["correct_intent"]))
    
    return examples


def train_model(
    model: CustomNeuralModel,
    examples: List[Tuple[str, str]],
    epochs: int = 200,
    learning_rate: float = 0.01,
    batch_size: int = 16,
    validation_split: float = 0.15
) -> Dict:
    """
    Train a model and return training statistics.
    
    Args:
        model: Model instance to train
        examples: Training examples
        epochs: Number of training epochs
        learning_rate: Learning rate
        batch_size: Batch size
        validation_split: Validation split ratio
        
    Returns:
        Dictionary with training statistics
    """
    # Augment data
    augmented_examples = augment_training_data(examples)
    
    # Train
    model.train(
        examples=augmented_examples,
        epochs=epochs,
        learning_rate=learning_rate,
        batch_size=batch_size,
        validation_split=validation_split
    )
    
    # Return stats
    return {
        "original_examples": len(examples),
        "augmented_examples": len(augmented_examples),
        "collision_rate": model.get_collision_rate(),
        "metadata": model.metadata
    }


def test_model(model: CustomNeuralModel, test_queries: Optional[List[str]] = None) -> List[Dict]:
    """
    Test model with sample queries.
    
    Args:
        model: Model to test
        test_queries: Optional list of test queries
        
    Returns:
        List of test results
    """
    if test_queries is None:
        test_queries = [
            "what is 5 + 3",
            "create a sprite",
            "hello nova",
            "what is python",
            "modify the code",
            "show dependencies",
            "define shader",
            "synonym for fast"
        ]
    
    results = []
    for query in test_queries:
        intent, confidence = model.predict(query)
        results.append({
            "query": query,
            "intent": intent.value,
            "confidence": confidence
        })
    
    return results


def main():
    """Main training function."""
    print("=" * 60)
    print("Nova Neural Network Training")
    print("=" * 60)
    
    # Paths
    script_dir = Path(__file__).parent
    data_file = script_dir / "training_data.json"
    
    # Load training data
    print(f"\nLoading training data from: {data_file}")
    # NOTE: include_misclassifications=False by default - only set True after reviewing quarantine log
    examples = prepare_training_data(data_file, include_misclassifications=False)
    
    if len(examples) == 0:
        print("ERROR: No training data found!")
        return
    
    print(f"Loaded {len(examples)} training examples")
    
    # Initialize model
    print("\nInitializing neural network model...")
    model = create_model()
    print(f"Model architecture:")
    print(f"  Input: {model.feature_dim} features (hash-based)")
    print(f"  Hidden Layer 1: {model.hidden_size_1} neurons")
    print(f"  Hidden Layer 2: {model.hidden_size_2} neurons")
    print(f"  Output: {model.num_intents} intents")
    
    # Train model
    print("\n" + "=" * 60)
    print("Starting training...")
    print("=" * 60)
    
    stats = train_model(
        model=model,
        examples=examples,
        epochs=200,
        learning_rate=0.01,
        batch_size=16,
        validation_split=0.15
    )
    
    print("\n" + "=" * 60)
    print("Training complete!")
    print("=" * 60)
    print(f"Training examples: {stats['original_examples']} → {stats['augmented_examples']} (augmented)")
    print(f"Hash collision rate: {stats['collision_rate']:.2%}")
    
    # Test model
    print("\nTesting model with sample queries:")
    print("-" * 60)
    
    test_results = test_model(model)
    for result in test_results:
        print(f"Query: '{result['query']}'")
        print(f"  → Intent: {result['intent']} (confidence: {result['confidence']:.2%})")
        print()


if __name__ == "__main__":
    main()

