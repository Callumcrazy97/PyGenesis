"""Small Language Model components for intent classification."""

