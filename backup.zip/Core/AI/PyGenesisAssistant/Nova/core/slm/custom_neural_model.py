"""
Custom Neural Network Model - A from-scratch neural network for intent classification.
No TensorFlow/PyTorch dependencies. Uses numpy for matrix operations.
Size ~2MB, runs entirely locally.
"""
import json
import math
from datetime import datetime
from typing import Tuple, List, Dict, Optional, Union
from pathlib import Path
from collections import defaultdict

try:
    import numpy as np
    NUMPY_AVAILABLE = True
except ImportError:
    NUMPY_AVAILABLE = False
    np = None
    # Try to install numpy automatically
    try:
        import subprocess
        import sys
        print("⚠️  numpy is not installed. Attempting to install...")
        subprocess.check_call([sys.executable, "-m", "pip", "install", "numpy"],
                            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        import numpy as np
        NUMPY_AVAILABLE = True
        print("✅ numpy installed successfully")
    except (subprocess.CalledProcessError, ImportError):
        pass  # Will raise error in __init__ if still not available

# Import Intent - handle both direct and relative imports
import sys
from pathlib import Path

# Add parent directory to path for imports
_core_dir = Path(__file__).parent.parent
if str(_core_dir) not in sys.path:
    sys.path.insert(0, str(_core_dir))

try:
    from core.models import Intent
except ImportError:
    # Fallback: try from models directly
    try:
        from models import Intent
    except ImportError:
        # Last resort: define a minimal Intent enum
        from enum import Enum
        class Intent(Enum):
            MATH_QUERY = "math_query"
            RESEARCH_QUERY = "research_query"
            GENERAL_CHAT = "general_chat"
            CODE_QUERY = "code_query"
            DICTIONARY_LOOKUP = "dictionary_lookup"
            THESAURUS_LOOKUP = "thesaurus_lookup"
            PROJECT_MODIFICATION = "project_modification"
            RESOURCE_OPERATION = "resource_operation"
            GRAPH_VISUALIZATION = "graph_visualization"


MODEL_DIR = Path(__file__).parent / "models"
MODEL_DIR.mkdir(exist_ok=True)
MODEL_FILE = MODEL_DIR / "neural_model.json"
VOCAB_FILE = MODEL_DIR / "neural_vocab.json"  # Legacy, no longer used
MISCLASSIFICATION_LOG = MODEL_DIR / "misclassifications.json"  # Log for retraining


class CustomNeuralModel:
    """
    Feedforward neural network for intent classification.
    Architecture: Input → Hidden(128) → Hidden(64) → Output(9)
    Uses ReLU activation for hidden layers, Softmax for output.
    """
    
    # Map our Intent enum to model intents
    INTENT_MAP = {
        "math": Intent.MATH_QUERY,
        "research": Intent.RESEARCH_QUERY,
        "chat": Intent.GENERAL_CHAT,
        "code": Intent.CODE_QUERY,
        "dictionary": Intent.DICTIONARY_LOOKUP,
        "thesaurus": Intent.THESAURUS_LOOKUP,
        "project": Intent.PROJECT_MODIFICATION,
        "resource": Intent.RESOURCE_OPERATION,
        "graph": Intent.GRAPH_VISUALIZATION,
    }
    
    # Intent → Nova Capability Mapping
    INTENT_CAPABILITIES = {
        "math": ["calculate", "solve_math", "compute"],
        "research": ["web_search", "knowledge_base", "explain"],
        "chat": ["greet", "converse", "assist"],
        "code": ["analyze_code", "explain_code", "code_search"],
        "dictionary": ["word_definition", "lookup"],
        "thesaurus": ["find_synonyms", "word_alternatives"],
        "project": ["modify_files", "refactor", "edit_code"],
        "resource": ["create_resource", "manage_assets"],
        "graph": ["visualize_dependencies", "show_relationships"],
    }
    
    def __init__(self, hidden_size_1: int = 128, hidden_size_2: int = 64):
        """
        Initialize neural network model.
        
        Args:
            hidden_size_1: Number of neurons in first hidden layer (default: 128)
            hidden_size_2: Number of neurons in second hidden layer (default: 64)
        """
        if not NUMPY_AVAILABLE:
            raise ImportError("numpy is required for neural model. Install with: pip install numpy")
        
        self.intents = list(self.INTENT_MAP.keys())
        self.num_intents = len(self.intents)
        self.hidden_size_1 = hidden_size_1
        self.hidden_size_2 = hidden_size_2
        
        # Model weights and biases (initialized later)
        self.W1 = None  # Input → Hidden1
        self.b1 = None  # Bias for Hidden1
        self.W2 = None  # Hidden1 → Hidden2
        self.b2 = None  # Bias for Hidden2
        self.W3 = None  # Hidden2 → Output
        self.b3 = None  # Bias for Output
        
        # Hash-based features (no fixed vocabulary)
        self.feature_dim = 1024  # Fixed feature dimension
        self.is_production = False  # Production models are read-only
        
        # Hash collision tracking
        self.hash_collisions = defaultdict(set)  # idx -> set of words that hash to it
        self.collision_stats = {"total_words": 0, "collisions": 0}
        
        # Model metadata
        self.metadata = {
            "version": "1.0",
            "created_at": None,
            "trained_at": None,
            "training_examples": 0,
            "nova_version": None,  # Will be set by Nova
        }
        
        # Confidence threshold (calibrated)
        self.confidence_threshold = 0.5  # Below this, ask for clarification
        
        if MODEL_FILE.exists():
            self._load()
        else:
            self._bootstrap()
    
    def _bootstrap(self):
        """Initialize model with hash-based features (no fixed vocabulary)."""
        # Initialize weights using Xavier/Glorot initialization
        # W1: feature_dim → hidden_size_1
        self.W1 = self._xavier_init(self.feature_dim, self.hidden_size_1)
        self.b1 = np.zeros(self.hidden_size_1)
        
        # W2: hidden_size_1 → hidden_size_2
        self.W2 = self._xavier_init(self.hidden_size_1, self.hidden_size_2)
        self.b2 = np.zeros(self.hidden_size_2)
        
        # W3: hidden_size_2 → num_intents
        self.W3 = self._xavier_init(self.hidden_size_2, self.num_intents)
        self.b3 = np.zeros(self.num_intents)
        
        # Save model
        self._save()
    
    def _xavier_init(self, fan_in: int, fan_out: int):
        """
        Xavier/Glorot weight initialization.
        Helps with gradient flow in deep networks.
        """
        limit = math.sqrt(6.0 / (fan_in + fan_out))
        return np.random.uniform(-limit, limit, (fan_in, fan_out))
    
    def _relu(self, x):
        """ReLU activation function: max(0, x)"""
        return np.maximum(0, x)
    
    def _relu_derivative(self, x):
        """Derivative of ReLU: 1 where x > 0, else 0"""
        return (x > 0).astype(float)
    
    def _softmax(self, x):
        """
        Batch-safe softmax activation function.
        Works for both single vectors and batches.
        """
        # Ensure x is at least 2D (batch dimension)
        if x.ndim == 1:
            x = x[np.newaxis, :]
            squeeze_output = True
        else:
            squeeze_output = False
        
        # Numerical stability: subtract max along last axis
        x = x - np.max(x, axis=-1, keepdims=True)
        exp_x = np.exp(x)
        probs = exp_x / np.sum(exp_x, axis=-1, keepdims=True)
        
        # Squeeze if input was 1D
        if squeeze_output:
            probs = probs[0]
        
        return probs
    
    def _forward(self, x):
        """
        Forward propagation through the network.
        
        Returns:
            (z1, a1, z2, a2, z3, output_probs)
            where z = pre-activation, a = post-activation
        """
        # Input → Hidden1
        z1 = x @ self.W1 + self.b1
        a1 = self._relu(z1)
        
        # Hidden1 → Hidden2
        z2 = a1 @ self.W2 + self.b2
        a2 = self._relu(z2)
        
        # Hidden2 → Output
        z3 = a2 @ self.W3 + self.b3
        output_probs = self._softmax(z3)
        
        return z1, a1, z2, a2, z3, output_probs
    
    def _text_to_features(self, text: str, track_collisions: bool = False):
        """
        Convert text to feature vector using hash-based bag-of-words.
        Uses hashing trick: hash(word) % feature_dim
        
        Args:
            text: Input text to convert
            track_collisions: If True, track hash collisions for analysis
        
        Returns:
            Feature vector of size feature_dim
        """
        x = np.zeros(self.feature_dim)
        text_lower = text.lower()
        
        # Tokenize: split on whitespace and punctuation
        import re
        words = re.findall(r'\b\w+\b', text_lower)
        
        # Hash each word to a feature index
        for word in words:
            # Use Python's built-in hash (deterministic within a session)
            # For production, consider using a stable hash like xxhash
            hash_val = hash(word)
            idx = abs(hash_val) % self.feature_dim
            
            # Track collisions if requested
            if track_collisions:
                self.collision_stats["total_words"] += 1
                if word not in self.hash_collisions[idx]:
                    if len(self.hash_collisions[idx]) > 0:
                        self.collision_stats["collisions"] += 1
                    self.hash_collisions[idx].add(word)
            
            x[idx] += 1.0  # Count occurrences (can also use binary: x[idx] = 1.0)
        
        # Also hash bigrams (two-word phrases) for better context
        for i in range(len(words) - 1):
            bigram = f"{words[i]}_{words[i+1]}"
            hash_val = hash(bigram)
            idx = abs(hash_val) % self.feature_dim
            x[idx] += 0.5  # Lower weight for bigrams
        
        # Normalize to prevent feature explosion
        norm = np.linalg.norm(x)
        if norm > 0:
            x = x / norm
        
        return x
    
    def get_collision_rate(self) -> float:
        """
        Get hash collision rate (for monitoring).
        
        Returns:
            Collision rate as a float (0.0 to 1.0)
        """
        if self.collision_stats["total_words"] == 0:
            return 0.0
        return self.collision_stats["collisions"] / self.collision_stats["total_words"]
    
    def predict(self, text: str, return_explanation: bool = False) -> Union[Tuple[Intent, float], Tuple[Intent, float, Dict]]:
        """
        Predict intent from text with optional explanation.
        
        Args:
            text: User input text
            return_explanation: If True, return explanation dict
            
        Returns:
            If return_explanation=False: (Intent, confidence_score)
            If return_explanation=True: (Intent, confidence_score, explanation_dict)
        """
        # Convert text to features
        x = self._text_to_features(text)
        
        # Forward propagation
        _, a1, _, a2, _, probs = self._forward(x)
        
        # Get highest probability intent
        idx = int(np.argmax(probs))
        intent_name = self.intents[idx]
        confidence = float(probs[idx])
        
        # Map to Intent enum
        intent = self.INTENT_MAP.get(intent_name, Intent.GENERAL_CHAT)
        
        # Return early if no explanation needed (backward compatibility)
        if not return_explanation:
            return intent, confidence
        
        # Build explanation if requested
        # Get top 3 predictions
        top_indices = np.argsort(probs)[::-1][:3]
        top_predictions = [
            {
                "intent": self.intents[i],
                "confidence": float(probs[i]),
                "confidence_band": self.get_confidence_band(float(probs[i]))
            }
            for i in top_indices
        ]
        
        # Calculate entropy (uncertainty measure)
        entropy = -sum(p * math.log(p + 1e-9) for p in probs)
        max_entropy = math.log(len(probs))
        entropy_ratio = entropy / max_entropy if max_entropy > 0 else 0
        
        # Get active features
        active_features = int(np.sum(x > 0.01))
        
        explanation = {
            "predicted_intent": intent_name,
            "confidence": confidence,
            "confidence_band": self.get_confidence_band(confidence),
            "meets_threshold": confidence >= self.confidence_threshold,
            "top_predictions": top_predictions,
            "entropy": float(entropy),
            "entropy_ratio": float(entropy_ratio),
            "uncertainty": "High" if entropy_ratio > 0.7 else "Low" if entropy_ratio < 0.3 else "Medium",
            "active_features": active_features,
            "capabilities": self.INTENT_CAPABILITIES.get(intent_name, []),
            "layer_activations": {
                "hidden1_active": int(np.sum(a1 > 0.01)),
                "hidden2_active": int(np.sum(a2 > 0.01)),
            }
        }
        
        return intent, confidence, explanation
    
    def explain_prediction(self, text: str) -> Dict:
        """
        Explain why a particular intent was predicted.
        
        Args:
            text: User input text
            
        Returns:
            Explanation dictionary with reasoning
        """
        _, _, explanation = self.predict(text, return_explanation=True)
        return explanation
    
    def log_misclassification(self, text: str, predicted_intent: str, correct_intent: str, confidence: float):
        """
        Log a misclassification to quarantine for manual review.
        
        IMPORTANT: This does NOT automatically retrain the model.
        Retraining should be done manually as a build step after reviewing
        quarantined misclassifications.
        
        Workflow:
        1. Misclassifications logged here → misclassifications.json
        2. Review periodically (manual)
        3. Promote good examples to manual_examples.json
        4. Regenerate: python generate_training_data.py
        5. Retrain: python train_model.py
        
        Args:
            text: The input text
            predicted_intent: What the model predicted
            correct_intent: What it should have been
            confidence: Confidence score of the prediction
        """
        if not MISCLASSIFICATION_LOG.exists():
            misclassifications = []
        else:
            with open(MISCLASSIFICATION_LOG, 'r') as f:
                misclassifications = json.load(f)
        
        misclassifications.append({
            "text": text,
            "predicted_intent": predicted_intent,
            "correct_intent": correct_intent,
            "confidence": confidence,
            "timestamp": datetime.now().isoformat()
        })
        
        # Keep only last 1000 misclassifications
        if len(misclassifications) > 1000:
            misclassifications = misclassifications[-1000:]
        
        with open(MISCLASSIFICATION_LOG, 'w') as f:
            json.dump(misclassifications, f, indent=2)
    
    def get_capabilities_for_intent(self, intent: Intent) -> List[str]:
        """
        Get Nova capabilities for a given intent.
        
        Args:
            intent: Intent enum value
            
        Returns:
            List of capability strings
        """
        # Find intent name from enum
        intent_name = None
        for name, intent_enum in self.INTENT_MAP.items():
            if intent_enum == intent:
                intent_name = name
                break
        
        return self.INTENT_CAPABILITIES.get(intent_name, [])
    
    def train(self, examples: List[Tuple[str, str]], epochs: int = 50, 
              learning_rate: float = 0.001, batch_size: int = 32, 
              validation_split: float = 0.2):
        """
        Train model with examples using backpropagation.
        
        Args:
            examples: List of (text, intent_name) tuples
            epochs: Number of training epochs
            learning_rate: Learning rate for gradient descent
            batch_size: Batch size for training
            validation_split: Fraction of data to use for validation
            
        Note:
            Production models (is_production=True) cannot be trained.
            Train offline, then promote to production.
        """
        if self.is_production:
            raise RuntimeError(
                "Cannot train a production model. Production models are read-only. "
                "Train a new model offline, validate it, then promote it to production."
            )
        if len(examples) < 10:
            print("Warning: Need at least 10 examples for training")
            return
        
        # Convert examples to feature vectors and labels
        X = []
        y = []
        
        # Reset collision tracking for this training session
        self.hash_collisions = defaultdict(set)
        self.collision_stats = {"total_words": 0, "collisions": 0}
        
        for text, intent_name in examples:
            # Feature vector (hash-based, no vocab needed) - track collisions during training
            x = self._text_to_features(text, track_collisions=True)
            X.append(x)
            
            # Label (one-hot)
            if intent_name in self.intents:
                label = np.zeros(self.num_intents)
                label[self.intents.index(intent_name)] = 1.0
                y.append(label)
            else:
                # Skip invalid intents
                continue
        
        if len(X) == 0:
            print("Warning: No valid examples for training")
            return
        
        X = np.array(X)
        y = np.array(y)
        
        # Split into train and validation
        n_train = int(len(X) * (1 - validation_split))
        X_train, X_val = X[:n_train], X[n_train:]
        y_train, y_val = y[:n_train], y[n_train:]
        
        # Training loop
        best_val_loss = float('inf')
        patience = 20  # Increased patience - allow more epochs before stopping
        patience_counter = 0
        min_delta = 0.001  # Minimum change to qualify as improvement
        
        for epoch in range(epochs):
            # Shuffle training data
            indices = np.random.permutation(len(X_train))
            X_train_shuffled = X_train[indices]
            y_train_shuffled = y_train[indices]
            
            # Mini-batch training
            epoch_loss = 0.0
            n_batches = (len(X_train) + batch_size - 1) // batch_size
            
            for i in range(0, len(X_train), batch_size):
                batch_X = X_train_shuffled[i:i+batch_size]
                batch_y = y_train_shuffled[i:i+batch_size]
                
                # Forward pass
                z1, a1, z2, a2, z3, probs = self._forward_batch(batch_X)
                
                # Compute loss (cross-entropy)
                loss = -np.mean(np.sum(batch_y * np.log(probs + 1e-8), axis=1))
                epoch_loss += loss
                
                # Backward pass (backpropagation)
                self._backward(batch_X, batch_y, z1, a1, z2, a2, z3, probs, learning_rate)
            
            epoch_loss /= n_batches
            
            # Validation
            if len(X_val) > 0:
                _, _, _, _, _, val_probs = self._forward_batch(X_val)
                val_loss = -np.mean(np.sum(y_val * np.log(val_probs + 1e-8), axis=1))
                
                # Early stopping with minimum delta
                if val_loss < (best_val_loss - min_delta):
                    best_val_loss = val_loss
                    patience_counter = 0
                else:
                    patience_counter += 1
                    if patience_counter >= patience:
                        print(f"Early stopping at epoch {epoch+1} (no improvement for {patience} epochs)")
                        break
                
                if (epoch + 1) % 10 == 0:
                    # Calculate accuracy for monitoring
                    val_preds = np.argmax(val_probs, axis=1)
                    val_labels = np.argmax(y_val, axis=1)
                    val_accuracy = np.mean(val_preds == val_labels)
                    print(f"Epoch {epoch+1}/{epochs} - Loss: {epoch_loss:.4f}, Val Loss: {val_loss:.4f}, Val Acc: {val_accuracy:.2%}")
            else:
                if (epoch + 1) % 10 == 0:
                    print(f"Epoch {epoch+1}/{epochs} - Loss: {epoch_loss:.4f}")
        
        # Update metadata
        self.metadata["training_examples"] = len(examples)
        
        # Report collision statistics
        collision_rate = self.get_collision_rate()
        if collision_rate > 0.1:  # Warn if collision rate > 10%
            print(f"⚠️  Warning: Hash collision rate is {collision_rate:.2%} (>10% may affect accuracy)")
        else:
            print(f"✅ Hash collision rate: {collision_rate:.2%}")
        
        # Save updated model
        self._save()
        print("Training complete!")
    
    def _forward_batch(self, X):
        """Forward propagation for a batch of examples."""
        # Input → Hidden1
        z1 = X @ self.W1 + self.b1
        a1 = self._relu(z1)
        
        # Hidden1 → Hidden2
        z2 = a1 @ self.W2 + self.b2
        a2 = self._relu(z2)
        
        # Hidden2 → Output
        z3 = a2 @ self.W3 + self.b3
        output_probs = np.array([self._softmax(z) for z in z3])
        
        return z1, a1, z2, a2, z3, output_probs
    
    def _backward(self, X, y, z1, a1, z2, a2, z3, probs, learning_rate):
        """
        Backpropagation to compute gradients and update weights.
        """
        batch_size = len(X)
        
        # Output layer error
        dZ3 = probs - y
        
        # Gradient for W3 and b3
        dW3 = (a2.T @ dZ3) / batch_size
        db3 = np.mean(dZ3, axis=0)
        
        # Backpropagate to Hidden2
        dA2 = dZ3 @ self.W3.T
        dZ2 = dA2 * self._relu_derivative(z2)
        
        # Gradient for W2 and b2
        dW2 = (a1.T @ dZ2) / batch_size
        db2 = np.mean(dZ2, axis=0)
        
        # Backpropagate to Hidden1
        dA1 = dZ2 @ self.W2.T
        dZ1 = dA1 * self._relu_derivative(z1)
        
        # Gradient for W1 and b1
        dW1 = (X.T @ dZ1) / batch_size
        db1 = np.mean(dZ1, axis=0)
        
        # Update weights (gradient descent)
        self.W3 -= learning_rate * dW3
        self.b3 -= learning_rate * db3
        self.W2 -= learning_rate * dW2
        self.b2 -= learning_rate * db2
        self.W1 -= learning_rate * dW1
        self.b1 -= learning_rate * db1
    
    def _save(self):
        """Save model weights and metadata to disk."""
        # Update metadata
        if self.metadata["created_at"] is None:
            self.metadata["created_at"] = datetime.now().isoformat()
        self.metadata["trained_at"] = datetime.now().isoformat()
        self.metadata["intent_list"] = self.intents
        self.metadata["intent_count"] = len(self.intents)
        
        # Save weights as JSON (convert numpy arrays to lists)
        model_data = {
            # Weights and biases
            "W1": self.W1.tolist(),
            "b1": self.b1.tolist(),
            "W2": self.W2.tolist(),
            "b2": self.b2.tolist(),
            "W3": self.W3.tolist(),
            "b3": self.b3.tolist(),
            # Architecture
            "hidden_size_1": self.hidden_size_1,
            "hidden_size_2": self.hidden_size_2,
            "feature_dim": self.feature_dim,
            # Model state
            "is_production": self.is_production,
            # Comprehensive metadata
            "metadata": self.metadata,
            # Intent mapping (for compatibility)
            "intent_map": {k: v.value for k, v in self.INTENT_MAP.items()},
            # Hash collision stats
            "collision_stats": self.collision_stats,
            # Confidence threshold
            "confidence_threshold": self.confidence_threshold,
        }
        
        with open(MODEL_FILE, 'w') as f:
            json.dump(model_data, f, indent=2)
    
    def _load(self):
        """Load model weights and metadata from disk."""
        # Load model weights
        with open(MODEL_FILE, 'r') as f:
            model_data = json.load(f)
        
        self.W1 = np.array(model_data["W1"])
        self.b1 = np.array(model_data["b1"])
        self.W2 = np.array(model_data["W2"])
        self.b2 = np.array(model_data["b2"])
        self.W3 = np.array(model_data["W3"])
        self.b3 = np.array(model_data["b3"])
        self.hidden_size_1 = model_data.get("hidden_size_1", 128)
        self.hidden_size_2 = model_data.get("hidden_size_2", 64)
        self.feature_dim = model_data.get("feature_dim", 1024)
        self.is_production = model_data.get("is_production", False)
        
        # Load metadata
        if "metadata" in model_data:
            self.metadata.update(model_data["metadata"])
        else:
            # Backward compatibility: create metadata from available info
            self.metadata["version"] = model_data.get("version", "1.0")
        
        # Load confidence threshold
        self.confidence_threshold = model_data.get("confidence_threshold", 0.5)
        
        # Load collision stats if available
        if "collision_stats" in model_data:
            self.collision_stats = model_data["collision_stats"]
        
        # Validate model compatibility
        if "intent_list" in self.metadata:
            saved_intents = self.metadata.get("intent_list", [])
            if set(saved_intents) != set(self.intents):
                print(f"Warning: Model intent list differs from current. Saved: {saved_intents}, Current: {self.intents}")
        
        # Backward compatibility: if old vocab-based model exists, migrate
        if VOCAB_FILE.exists() and not hasattr(self, 'vocab'):
            # Old model detected - would need migration, but for now just warn
            print("Warning: Old vocab-based model detected. Please retrain with new hash-based model.")
    
    def promote_to_production(self):
        """
        Mark this model as production (read-only).
        Production models cannot be trained to prevent accidental modifications.
        """
        self.is_production = True
        self._save()
        print("Model promoted to production. It is now read-only.")
    
    def get_confidence_band(self, confidence: float) -> str:
        """
        Get confidence band label (LOW/MEDIUM/HIGH).
        
        Args:
            confidence: Confidence score (0.0 to 1.0)
            
        Returns:
            Confidence band string
        """
        if confidence < 0.45:
            return "LOW"
        elif confidence < 0.7:
            return "MEDIUM"
        else:
            return "HIGH"
    
    def should_ask_clarification(self, confidence: float) -> bool:
        """
        Determine if Nova should ask for clarification based on confidence.
        
        Args:
            confidence: Confidence score (0.0 to 1.0)
            
        Returns:
            True if clarification should be requested
        """
        return confidence < self.confidence_threshold
    
    def set_confidence_threshold(self, threshold: float):
        """
        Set the confidence threshold for asking clarification.
        
        Args:
            threshold: Confidence threshold (0.0 to 1.0)
        """
        if not 0.0 <= threshold <= 1.0:
            raise ValueError("Confidence threshold must be between 0.0 and 1.0")
        self.confidence_threshold = threshold
        self._save()

