"""
Tiny Intent Model - A small statistical language model for intent classification.
Uses logistic regression with bag-of-words features.
Size ~1MB, runs entirely locally.
"""
import os
from typing import Tuple, List
from pathlib import Path

try:
    import numpy as np
    NUMPY_AVAILABLE = True
except ImportError:
    NUMPY_AVAILABLE = False
    np = None

from core.models import Intent


MODEL_DIR = Path(__file__).parent / "models"
MODEL_DIR.mkdir(exist_ok=True)
MODEL_FILE = MODEL_DIR / "intent_model.npz"


class TinyIntentModel:
    """
    Logistic regression intent classifier.
    Uses bag-of-words + softmax.
    Size ~1MB.
    """
    
    # Map our Intent enum to model intents
    INTENT_MAP = {
        "math": Intent.MATH_QUERY,
        "research": Intent.RESEARCH_QUERY,
        "chat": Intent.GENERAL_CHAT,
        "code": Intent.CODE_QUERY,
        "dictionary": Intent.DICTIONARY_LOOKUP,
        "thesaurus": Intent.THESAURUS_LOOKUP,
        "project": Intent.PROJECT_MODIFICATION,
        "graph": Intent.GRAPH_VISUALIZATION,
    }
    
    def __init__(self):
        if not NUMPY_AVAILABLE:
            raise ImportError("numpy is required for SLM. Install with: pip install numpy")
        
        self.intents = list(self.INTENT_MAP.keys())
        if MODEL_FILE.exists():
            self._load()
        else:
            self._bootstrap()
    
    def _bootstrap(self):
        """Initialize model with basic vocabulary and random weights."""
        # Expanded vocabulary for better classification
        vocab = [
            # Math keywords
            "solve", "calculate", "compute", "what is", "equals", "plus", "minus",
            "times", "multiply", "divide", "add", "subtract", "+", "-", "*", "/", "=",
            # Research keywords
            "what", "who", "why", "how", "research", "study", "learn", "explain",
            "tell me about", "information about",
            # Code keywords
            "code", "class", "function", "import", "how does", "implementation",
            "interact", "work",
            # Dictionary keywords
            "define", "definition", "meaning", "what does mean",
            # Thesaurus keywords
            "synonym", "similar", "alternative", "another word",
            # Project keywords
            "create", "add", "modify", "change", "edit", "delete",
            # Graph keywords
            "graph", "dependency", "visualize", "relationships",
            # Chat keywords
            "hello", "hi", "thanks", "thank you", "help",
        ]
        
        # Initialize weights randomly (small values)
        W = np.random.randn(len(self.intents), len(vocab)) * 0.01
        b = np.zeros(len(self.intents))
        
        # Save model
        np.savez(MODEL_FILE, W=W, b=b, vocab=vocab)
        
        self.vocab = vocab
        self.W = W
        self.b = b
    
    def _load(self):
        """Load saved model from disk."""
        data = np.load(MODEL_FILE, allow_pickle=True)
        self.W = data["W"]
        self.b = data["b"]
        self.vocab = list(data["vocab"])
    
    def predict(self, text: str) -> Tuple[Intent, float]:
        """
        Predict intent from text.
        Returns (Intent, confidence_score).
        """
        # Create bag-of-words feature vector
        x = np.zeros(len(self.vocab))
        text_lower = text.lower()
        
        for i, word in enumerate(self.vocab):
            if word in text_lower:
                x[i] = 1.0
        
        # Compute logits: W @ x + b
        logits = self.W @ x + self.b
        
        # Softmax to get probabilities
        exp_logits = np.exp(logits - np.max(logits))  # Numerical stability
        probs = exp_logits / np.sum(exp_logits)
        
        # Get highest probability intent
        idx = int(np.argmax(probs))
        intent_name = self.intents[idx]
        confidence = float(probs[idx])
        
        # Map to Intent enum
        intent = self.INTENT_MAP.get(intent_name, Intent.GENERAL_CHAT)
        
        return intent, confidence
    
    def train(self, examples: List[Tuple[str, str]], epochs: int = 10, lr: float = 0.01):
        """
        Fine-tune model with examples.
        examples: List of (text, intent_name) tuples.
        """
        # Convert examples to feature vectors and labels
        X = []
        y = []
        
        for text, intent_name in examples:
            # Feature vector
            x = np.zeros(len(self.vocab))
            text_lower = text.lower()
            for i, word in enumerate(self.vocab):
                if word in text_lower:
                    x[i] = 1.0
            X.append(x)
            
            # Label (one-hot)
            if intent_name in self.intents:
                label = np.zeros(len(self.intents))
                label[self.intents.index(intent_name)] = 1.0
                y.append(label)
        
        X = np.array(X)
        y = np.array(y)
        
        # Simple gradient descent training
        for epoch in range(epochs):
            # Forward pass
            logits = X @ self.W.T + self.b
            exp_logits = np.exp(logits - np.max(logits, axis=1, keepdims=True))
            probs = exp_logits / np.sum(exp_logits, axis=1, keepdims=True)
            
            # Backward pass (gradient)
            error = probs - y
            dW = error.T @ X / len(X)
            db = np.mean(error, axis=0)
            
            # Update weights
            self.W -= lr * dW
            self.b -= lr * db
        
        # Save updated model
        np.savez(MODEL_FILE, W=self.W, b=self.b, vocab=self.vocab)

