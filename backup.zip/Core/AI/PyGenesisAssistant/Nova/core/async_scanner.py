"""
Async Project Scanner - Non-blocking project scanning using QThread.
"""
from PySide6.QtCore import QThread, Signal
from typing import Optional, Dict, Any
from core.project_scanner import ProjectScanner


class ProjectScanWorker(QThread):
    """Worker thread for scanning projects without blocking UI."""
    
    # Signals
    scan_complete = Signal(dict)  # Emits scan result
    scan_progress = Signal(str)   # Emits progress messages
    scan_error = Signal(str)      # Emits error messages
    
    def __init__(self, project_root: Optional[str] = None):
        super().__init__()
        self.project_root = project_root
        self.scanner = ProjectScanner(project_root)
        self._cancelled = False
    
    def run(self):
        """Run the project scan in background thread."""
        try:
            if self._cancelled:
                return
            
            self.scan_progress.emit("Scanning project structure...")
            
            # Perform the scan
            structure = self.scanner.scan_project()
            
            if self._cancelled:
                return
            
            if structure and not structure.get("error"):
                self.scan_progress.emit("Scan complete")
                self.scan_complete.emit({
                    "structure": structure,
                    "scanner": self.scanner,
                })
            else:
                error_msg = structure.get("error", "Unknown error during scan")
                self.scan_error.emit(error_msg)
                
        except Exception as e:
            if not self._cancelled:
                self.scan_error.emit(str(e))
    
    def cancel(self):
        """Cancel the scan operation."""
        self._cancelled = True

