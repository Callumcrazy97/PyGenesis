"""
Task Name Generator - Generates descriptive task names from user input and intent.
Uses intent classification to create meaningful task names.
"""
from typing import Optional
from core.models import Intent


class TaskNameGenerator:
    """Generates task names based on user input and intent."""
    
    @staticmethod
    def generate_task_name(user_input: str, intent: Intent, entity: Optional[str] = None) -> str:
        """
        Generate a descriptive task name from user input and intent.
        
        Args:
            user_input: Original user input
            intent: Classified intent
            entity: Extracted entity (e.g., equation, word, topic)
        
        Returns:
            Descriptive task name
        """
        user_input_lower = user_input.lower().strip()
        
        if intent == Intent.MATH_QUERY:
            if entity:
                return f"Solve Math: {entity}"
            # Extract math expression from input
            import re
            match = re.search(r'([0-9+\-*/().\s^%]+)', user_input)
            if match:
                expr = match.group(1).strip()
                return f"Solve Math: {expr}"
            return f"Solve Math Problem"
        
        elif intent == Intent.RESEARCH_QUERY:
            if entity:
                return f"Research: {entity.title()}"
            # Extract topic
            topic = user_input_lower.replace("what is", "").replace("who is", "").replace("research", "").strip()
            if topic:
                return f"Research: {topic.title()}"
            return "Research Topic"
        
        elif intent == Intent.DICTIONARY_LOOKUP:
            if entity:
                return f"Define Word: {entity.title()}"
            return "Lookup Word Definition"
        
        elif intent == Intent.THESAURUS_LOOKUP:
            if entity:
                return f"Find Synonyms: {entity.title()}"
            return "Lookup Synonyms"
        
        elif intent == Intent.CODE_QUERY:
            # Extract code-related keywords
            if "class" in user_input_lower:
                return "Analyze Code: Class Structure"
            elif "function" in user_input_lower:
                return "Analyze Code: Function"
            elif "how does" in user_input_lower:
                return "Analyze Code: How It Works"
            return "Analyze Code"
        
        elif intent == Intent.PROJECT_MODIFICATION:
            if "create" in user_input_lower:
                return "Create File/Project"
            elif "edit" in user_input_lower or "modify" in user_input_lower:
                return "Edit File/Project"
            elif "delete" in user_input_lower or "remove" in user_input_lower:
                return "Delete File/Project"
            return "Modify Project"
        
        elif intent == Intent.GRAPH_VISUALIZATION:
            return "Generate Dependency Graph"
        
        elif intent == Intent.GENERAL_CHAT:
            # Generate conversational task name
            if any(word in user_input_lower for word in ["hello", "hi", "hey"]):
                return "Converse: Greeting"
            elif "help" in user_input_lower:
                return "Converse: Help Request"
            elif "thanks" in user_input_lower or "thank you" in user_input_lower:
                return "Converse: Acknowledgment"
            else:
                # Use first few words of input
                words = user_input.split()[:5]
                preview = " ".join(words)
                if len(user_input) > len(preview):
                    preview += "..."
                return f"Converse: {preview}"
        
        # Fallback
        return f"Process: {user_input[:50]}"

