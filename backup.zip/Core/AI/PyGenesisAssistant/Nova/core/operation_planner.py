"""
Operation Planner - Generates operation plans from user intent.

This is the SINGLE SOURCE OF TRUTH for all planning at the workflow level.
Executors are dumb - they only validate, execute, and rollback.
The planner decides what to do.
"""

from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional, Tuple
from enum import Enum

from core.workflow import WorkflowContext
from core.models import Intent
from core.api_manifest import get_validator, validate_operation, API_SURFACE
from core.tasks import TaskManager, Task, TaskPriority


class RiskLevel(Enum):
    """Risk level for operations."""
    LOW = "Low"
    MEDIUM = "Medium"
    HIGH = "High"
    CRITICAL = "Critical"


@dataclass
class Operation:
    """Represents a single engine operation."""
    component: str  # e.g., "ResourceManager"
    method: str  # e.g., "create_resource"
    params: Dict[str, Any]  # Method parameters
    description: str  # Human-readable description
    task_id: Optional[str] = None  # Associated task ID


@dataclass
class OperationPlan:
    """Single source of truth for all planned operations."""
    root_task_id: str  # Root task for this plan
    operations: List[Operation] = field(default_factory=list)  # List of validated engine operations
    affected_systems: List[str] = field(default_factory=list)  # ["ResourceManager", "ProjectManager", etc.]
    affected_files: List[str] = field(default_factory=list)  # File paths that will change
    rationale: str = ""  # Why these operations are needed
    risk_level: RiskLevel = RiskLevel.MEDIUM  # Risk level
    expected_outcome: str = ""  # What will happen
    rollback_plan: Optional[Dict[str, Any]] = None  # How to undo
    requires_confirmation: bool = False  # User approval needed?
    task_structure: Dict[str, Any] = field(default_factory=dict)  # Hierarchical task structure


class OperationPlanner:
    """
    Generates operation plans from workflow context.
    This is where reasoning happens - converts intent into validated operations.
    """
    
    def __init__(self, task_manager: TaskManager, app=None):
        """
        Initialize operation planner.
        
        Args:
            task_manager: TaskManager instance for creating hierarchical tasks
            app: Application instance (for checking project state, etc.)
        """
        self.task_manager = task_manager
        self.app = app
        self.validator = get_validator()
    
    def plan(self, context: WorkflowContext) -> OperationPlan:
        """
        Generate operation plan from context.
        This is where reasoning happens.
        
        Args:
            context: WorkflowContext with user input, intent, entity, etc.
        
        Returns:
            OperationPlan with all planned operations
        """
        # Create root task for this operation plan
        root_task = self.task_manager.create_task(
            name=self._generate_plan_name(context),
            description=f"Operation plan for: {context.user_input[:100]}",
            user_input=context.user_input,
            intent=context.intent.value if context.intent else None,
            priority=self._determine_priority(context),
            is_header=True,  # Root task is a header
        )
        
        # Initialize plan
        plan = OperationPlan(
            root_task_id=root_task.id,
            rationale=self._generate_rationale(context),
            risk_level=self._assess_risk(context),
            expected_outcome=self._generate_expected_outcome(context),
            requires_confirmation=self._requires_confirmation(context),
        )
        
        # Generate operations based on intent
        if context.intent == Intent.RESOURCE_OPERATION:
            plan = self._plan_resource_operation(context, plan)
        elif context.intent == Intent.PROJECT_MODIFICATION:
            plan = self._plan_project_modification(context, plan)
        elif context.intent == Intent.CODE_QUERY:
            plan = self._plan_code_query(context, plan)
        else:
            # For other intents, create a simple plan
            plan = self._plan_simple_operation(context, plan)
        
        # Validate all operations
        validation_result = self.validate_plan(plan)
        if not validation_result[0]:
            # Add validation error to plan
            plan.rationale += f"\n\n⚠️ Validation Warning: {validation_result[1]}"
        
        return plan
    
    def _generate_plan_name(self, context: WorkflowContext) -> str:
        """Generate a name for the operation plan."""
        if context.intent == Intent.RESOURCE_OPERATION:
            return f"Resource Operation: {context.user_input[:50]}"
        elif context.intent == Intent.PROJECT_MODIFICATION:
            return f"Project Modification: {context.user_input[:50]}"
        else:
            return f"Operation: {context.user_input[:50]}"
    
    def _determine_priority(self, context: WorkflowContext) -> TaskPriority:
        """Determine task priority based on context."""
        # High priority for destructive operations
        if context.intent in [Intent.PROJECT_MODIFICATION]:
            user_input_lower = context.user_input.lower()
            if any(word in user_input_lower for word in ["delete", "remove", "destroy"]):
                return TaskPriority.HIGH
        return TaskPriority.NORMAL
    
    def _generate_rationale(self, context: WorkflowContext) -> str:
        """Generate rationale for the operation plan."""
        return f"Executing: {context.user_input}"
    
    def _assess_risk(self, context: WorkflowContext) -> RiskLevel:
        """Assess risk level for the operation."""
        if context.intent == Intent.RESOURCE_OPERATION:
            user_input_lower = context.user_input.lower()
            if "delete" in user_input_lower or "remove" in user_input_lower:
                return RiskLevel.HIGH
            elif "create" in user_input_lower or "add" in user_input_lower:
                return RiskLevel.LOW
            else:
                return RiskLevel.MEDIUM
        elif context.intent == Intent.PROJECT_MODIFICATION:
            return RiskLevel.HIGH
        else:
            return RiskLevel.LOW
    
    def _generate_expected_outcome(self, context: WorkflowContext) -> str:
        """Generate expected outcome description."""
        if context.intent == Intent.RESOURCE_OPERATION:
            return "Resource operation will be completed successfully"
        elif context.intent == Intent.PROJECT_MODIFICATION:
            return "Project files will be modified as requested"
        else:
            return "Operation will complete successfully"
    
    def _requires_confirmation(self, context: WorkflowContext) -> bool:
        """Determine if operation requires user confirmation."""
        # Check if user has allowed high-risk operations
        allow_high_risk = False
        if self.app and hasattr(self.app, 'settings'):
            allow_high_risk = self.app.settings.get("AI_Allow_High_Risk", False)
            # Convert string to bool if needed
            if isinstance(allow_high_risk, str):
                allow_high_risk = allow_high_risk.lower() == "true"
        
        # If high-risk is allowed, skip confirmation
        if allow_high_risk:
            return False
        
        # Require confirmation for high-risk operations
        if context.intent == Intent.PROJECT_MODIFICATION:
            return True
        if context.intent == Intent.RESOURCE_OPERATION:
            user_input_lower = context.user_input.lower()
            if any(word in user_input_lower for word in ["delete", "remove", "destroy"]):
                return True
        return False
    
    def _plan_resource_operation(self, context: WorkflowContext, plan: OperationPlan) -> OperationPlan:
        """Plan a resource operation."""
        # Create header task for resource operation
        header_task = self.task_manager.create_task(
            name="Resource Operation",
            description="Planning resource operation steps",
            parent_id=plan.root_task_id,
            is_header=True,
        )
        
        # Add discovery step
        discovery_task = self.task_manager.create_task(
            name="1.1 Discovery",
            description="Discover existing resources and validate operation",
            parent_id=header_task.id,
        )
        
        # Add validation step
        validation_task = self.task_manager.create_task(
            name="1.2 Validation",
            description="Validate operation against API manifest",
            parent_id=header_task.id,
        )
        
        # Add execution step
        execution_task = self.task_manager.create_task(
            name="1.3 Execution",
            description="Execute resource operation",
            parent_id=header_task.id,
        )
        
        # Parse resource operation from context
        # This would use the ResourceOperationExecutor's parsing logic
        # For now, create a placeholder operation
        operation = Operation(
            component="ResourceManager",
            method="create_resource",  # This would be determined by parsing
            params={
                "resource_type": "sprites",  # This would be parsed
                "name": "NewSprite",  # This would be parsed
                "parent_folder": "",  # This would be parsed
            },
            description="Create resource as requested",
            task_id=execution_task.id,
        )
        
        plan.operations.append(operation)
        plan.affected_systems.append("ResourceManager")
        
        # Store task structure
        plan.task_structure = {
            "header": header_task.id,
            "discovery": discovery_task.id,
            "validation": validation_task.id,
            "execution": execution_task.id,
        }
        
        return plan
    
    def _plan_project_modification(self, context: WorkflowContext, plan: OperationPlan) -> OperationPlan:
        """Plan a project modification operation."""
        # Create header task
        header_task = self.task_manager.create_task(
            name="Project Modification",
            description="Planning project modification steps",
            parent_id=plan.root_task_id,
            is_header=True,
        )
        
        # Add analysis step
        analysis_task = self.task_manager.create_task(
            name="1.1 Analysis",
            description="Analyze project structure and identify files to modify",
            parent_id=header_task.id,
        )
        
        # Add planning step
        planning_task = self.task_manager.create_task(
            name="1.2 Planning",
            description="Plan specific modifications",
            parent_id=header_task.id,
        )
        
        # Add validation step
        validation_task = self.task_manager.create_task(
            name="1.3 Validation",
            description="Validate modifications against API manifest",
            parent_id=header_task.id,
        )
        
        # Add execution step
        execution_task = self.task_manager.create_task(
            name="1.4 Execution",
            description="Execute modifications",
            parent_id=header_task.id,
        )
        
        # Store task structure
        plan.task_structure = {
            "header": header_task.id,
            "analysis": analysis_task.id,
            "planning": planning_task.id,
            "validation": validation_task.id,
            "execution": execution_task.id,
        }
        
        plan.affected_systems.append("ProjectManager")
        plan.risk_level = RiskLevel.HIGH
        plan.requires_confirmation = True
        
        return plan
    
    def _plan_code_query(self, context: WorkflowContext, plan: OperationPlan) -> OperationPlan:
        """Plan a code query operation (read-only)."""
        # Code queries are read-only, so simpler plan
        query_task = self.task_manager.create_task(
            name="Code Analysis",
            description="Analyze code structure",
            parent_id=plan.root_task_id,
        )
        
        plan.task_structure = {
            "query": query_task.id,
        }
        
        return plan
    
    def _plan_simple_operation(self, context: WorkflowContext, plan: OperationPlan) -> OperationPlan:
        """Plan a simple operation (non-modification)."""
        simple_task = self.task_manager.create_task(
            name="Process Request",
            description="Process user request",
            parent_id=plan.root_task_id,
        )
        
        plan.task_structure = {
            "process": simple_task.id,
        }
        
        return plan
    
    def validate_plan(self, plan: OperationPlan) -> Tuple[bool, Optional[str]]:
        """
        Validate operation plan against API surface and knowledge base.
        
        Args:
            plan: OperationPlan to validate
        
        Returns:
            Tuple of (is_valid, error_message)
        """
        # Check if project is open (for operations that require it)
        project_open = False
        if self.app and hasattr(self.app, 'project_manager'):
            project_open = bool(self.app.project_manager.get_project_path())
        
        # Validate each operation
        for operation in plan.operations:
            operation_dict = {
                "component": operation.component,
                "method": operation.method,
                "params": operation.params,
            }
            
            is_valid, error = validate_operation(
                operation_dict,
                project_open=project_open,
            )
            
            if not is_valid:
                return False, f"Operation '{operation.component}.{operation.method}' is invalid: {error}"
        
        return True, None
    
    def get_plan_summary(self, plan: OperationPlan) -> str:
        """
        Generate human-readable summary of the operation plan.
        
        Args:
            plan: OperationPlan to summarize
        
        Returns:
            Human-readable summary string
        """
        lines = [
            f"**Operation Plan** (Task #{plan.root_task_id[:8]})",
            "",
            f"**Rationale:** {plan.rationale}",
            f"**Risk Level:** {plan.risk_level.value}",
            f"**Expected Outcome:** {plan.expected_outcome}",
            "",
            f"**Affected Systems:** {', '.join(plan.affected_systems) if plan.affected_systems else 'None'}",
            f"**Affected Files:** {len(plan.affected_files)} file(s)" if plan.affected_files else "**Affected Files:** None",
            "",
            f"**Operations:** {len(plan.operations)} operation(s)",
        ]
        
        for i, operation in enumerate(plan.operations, 1):
            lines.append(f"  {i}. {operation.component}.{operation.method}({', '.join(operation.params.keys())})")
            lines.append(f"     {operation.description}")
        
        if plan.requires_confirmation:
            lines.append("")
            lines.append("⚠️ **This operation requires confirmation before execution.**")
        
        return "\n".join(lines)

