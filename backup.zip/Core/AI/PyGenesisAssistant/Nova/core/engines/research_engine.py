"""
Research Engine - Handles research queries using safe sites.
Fetches actual information from safe sites and returns it with citations.
"""
import json
import os
import re
from typing import Optional, List, Dict, Any
from urllib.parse import quote_plus

try:
    import requests
    REQUESTS_AVAILABLE = True
except ImportError:
    REQUESTS_AVAILABLE = False

from core.engines.base_engine import BaseEngine
from core.workflow import WorkflowContext


class SafeSite:
    """Represents a safe site configuration."""
    
    def __init__(self, config: Dict):
        self.name = config.get("name", "")
        self.url = config.get("url", "")
        self.type = config.get("type", "")
        self.enabled = config.get("enabled", True)
        self.description = config.get("description", "")
    
    def get_search_url(self, query: str) -> str:
        """Get the search URL for a query."""
        # For Wikipedia, use direct article format (no URL encoding needed for article names)
        if "wikipedia.org/wiki/" in self.url:
            # Wikipedia article URLs should be direct: /wiki/Pi not /wiki/Pi%3F
            # Replace spaces with underscores and capitalize properly
            article_name = query.replace(' ', '_')
            return self.url.replace("{query}", article_name)
        else:
            # For other sites, use URL encoding
            return self.url.replace("{query}", quote_plus(query))


class ResearchEngine(BaseEngine):
    """Handles research queries using safe sites."""
    
    def __init__(self):
        self.safe_sites: List[SafeSite] = []
        self.search_strategy = {}
        self._load_safe_sites()
    
    def _load_safe_sites(self):
        """Load safe sites from JSON file."""
        try:
            # Get the directory of this file
            current_dir = os.path.dirname(os.path.abspath(__file__))
            # Go up to 'core', then to 'data'
            data_dir = os.path.join(os.path.dirname(os.path.dirname(current_dir)), "data")
            safe_sites_path = os.path.join(data_dir, "safe_sites.json")
            
            if os.path.exists(safe_sites_path):
                with open(safe_sites_path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    
                self.safe_sites = [
                    SafeSite(site_config) 
                    for site_config in data.get("sites", [])
                    if site_config.get("enabled", True)
                ]
                self.search_strategy = data.get("search_strategy", {})
            else:
                # Fallback: create default safe sites
                self._create_default_sites()
        except Exception as e:
            print(f"Error loading safe sites: {e}")
            self._create_default_sites()
    
    def _create_default_sites(self):
        """Create default safe sites if JSON file doesn't exist."""
        default_sites = [
            {
                "name": "Wikipedia",
                "url": "https://en.wikipedia.org/wiki/{query}",
                "type": "encyclopedia",
                "enabled": True,
                "description": "General knowledge and encyclopedia articles"
            }
        ]
        self.safe_sites = [SafeSite(site) for site in default_sites]
        self.search_strategy = {
            "primary": "wikipedia",
            "fallback_order": ["encyclopedia", "documentation", "tutorial"],
            "max_results": 3,
            "timeout_seconds": 5
        }
    
    def process(self, context: WorkflowContext) -> str:
        """
        Process research query using safe sites.
        Fetches actual information and returns it with citations.
        """
        if not REQUESTS_AVAILABLE:
            return "The 'requests' library is required for research. Please install it: pip install requests"
        
        original_query = context.user_input or ""
        query = context.entity or context.user_input
        
        # Detect if this is an implementation query ("how would you implement", "how to implement")
        is_implementation_query = self._is_implementation_query(original_query)
        
        # Detect if this is a "best way to" / "how to use" question (guidance, not just facts)
        is_guidance_query = self._is_guidance_query(original_query)
        
        # Detect if this is a "what is" question (general knowledge, even for programming terms)
        is_what_is_question = self._is_what_is_question(original_query) and not is_guidance_query
        
        # Clean up query
        query = self._clean_query(query)
        
        if not query:
            return "I need a topic to research. What would you like me to look up?"
        
        # Handle implementation queries specially (research + example code)
        if is_implementation_query:
            return self._handle_implementation_query(context, query, original_query)
        
        # Handle guidance queries (best way to, how to use, etc.)
        if is_guidance_query:
            return self._handle_guidance_query(context, query, original_query)
        
        # Determine which sites to use (prioritize best source first)
        # For "what is" questions, always prioritize Wikipedia/encyclopedia
        sites_to_use = self._select_sites(query, force_general_knowledge=is_what_is_question)
        
        if not sites_to_use:
            return "I don't have any safe sites configured for research. Please configure safe_sites.json."
        
        # Check if auto followup is enabled (we'll use this for fallback behavior)
        allow_auto_followup = self._get_allow_auto_followup(context)
        
        # Try to fetch information from sites in priority order
        for site in sites_to_use:
            try:
                info = self._fetch_site_info(site, query)
                
                # If direct fetch failed and auto followup is enabled, try search API
                if not info and allow_auto_followup and "wikipedia.org" in site.url:
                    # Try search API as fallback for this site
                    info = self._search_wikipedia_article(query, 5, {
                        'User-Agent': 'Nova AI Assistant (PyGenesis IDE) - Research Engine'
                    })
                    if info and len(info.strip()) > 50:
                        # We got info from search API, add disclaimer
                        citation_url = site.get_search_url(query)
                        return (
                            f"⚠️ *Note: I couldn't fetch the direct article for '{query}', but I found this information "
                            f"using {site.name}'s search. This may not be 100% accurate or complete.*\n\n"
                            f"{info}\n\n"
                            f"*Source: [{site.name}]({citation_url})*"
                        )
                
                if info:
                    # Check if info is too short or looks like a disambiguation stub
                    info_lower = info.lower().strip()
                    is_stub = (
                        len(info.strip()) < 50 or
                        info_lower.startswith('may refer to') or
                        info_lower.startswith('may refer to:') or
                        'may refer to' in info_lower[:100]  # Check first 100 chars
                    )
                    
                    # If it's a stub/disambiguation, try search API for better result
                    if is_stub and "wikipedia.org" in site.url:
                        better_info = self._search_wikipedia_article(query, 5, {
                            'User-Agent': 'Nova AI Assistant (PyGenesis IDE) - Research Engine'
                        })
                        if better_info and len(better_info.strip()) > 50 and 'may refer to' not in better_info.lower()[:100]:
                            info = better_info
                        elif is_stub:
                            if allow_auto_followup:
                                # Try to get best match anyway and add disclaimer
                                best_match = self._search_wikipedia_article(query, 5, {
                                    'User-Agent': 'Nova AI Assistant (PyGenesis IDE) - Research Engine'
                                })
                                if best_match and len(best_match.strip()) > 50:
                                    citation_url = site.get_search_url(query)
                                    return (
                                        f"⚠️ *Note: '{query}' can refer to multiple topics. I'm providing information "
                                        f"about the most likely match, but this may not be 100% accurate.*\n\n"
                                        f"{best_match}\n\n"
                                        f"*Source: [{site.name}]({citation_url})*"
                                    )
                            
                            # If still a stub or auto followup disabled, provide helpful message
                            citation_url = site.get_search_url(query)
                            return (
                                f"'{query}' can refer to multiple topics. "
                                f"I found a disambiguation page, but couldn't determine the specific topic you're asking about.\n\n"
                                f"*Source: [{site.name}]({citation_url})*\n\n"
                                f"*Tip: Try being more specific, e.g., 'Godot game engine' or 'Godot (play)'*"
                            )
                    
                    # Check if this is an uncertain result (disambiguation handling, low confidence match)
                    # and add disclaimer if auto followup is enabled
                    is_uncertain = (
                        'may refer to' in info.lower()[:200] or
                        len(info.strip()) < 100  # Short results might be incomplete
                    )
                    
                    # Format response with information and citation
                    citation_url = site.get_search_url(query)
                    
                    if is_uncertain and allow_auto_followup:
                        # Add disclaimer for uncertain results
                        response = (
                            f"⚠️ *Note: I'm not 100% certain this is the exact information you're looking for, "
                            f"but I found this on {site.name}:*\n\n"
                            f"{info}\n\n"
                            f"*Source: [{site.name}]({citation_url})*"
                        )
                    else:
                        response = f"{info}\n\n*Source: [{site.name}]({citation_url})*"
                    
                    return response
            except Exception as e:
                # Try next site if this one fails
                continue
        
        # If all direct fetches failed, try harder with auto followup enabled
        if allow_auto_followup:
            # Try Wikipedia search API as a last resort
            for site in sites_to_use:
                if "wikipedia.org" in site.url:
                    try:
                        # Use search API to find best match
                        search_info = self._search_wikipedia_article(query, 5, {
                            'User-Agent': 'Nova AI Assistant (PyGenesis IDE) - Research Engine'
                        })
                        
                        if search_info and len(search_info.strip()) > 50:
                            citation_url = site.get_search_url(query)
                            return (
                                f"⚠️ *Note: I couldn't fetch the direct article, but I found this information "
                                f"using {site.name}'s search. This may not be 100% accurate or complete.*\n\n"
                                f"{search_info}\n\n"
                                f"*Source: [{site.name}]({citation_url})*"
                            )
                    except Exception:
                        continue
        
        # If all sites failed (and auto followup didn't help), return links as fallback
        response_parts = [
            f"I couldn't fetch information directly, but here are safe sources for '{query}':\n"
        ]
        
        for site in sites_to_use:
            search_url = site.get_search_url(query)
            response_parts.append(
                f"• **{site.name}** ({site.type}): {search_url}"
            )
        
        return "\n".join(response_parts)
    
    def _clean_query(self, query: str) -> str:
        """Clean and normalize the research query."""
        if not query:
            return ""
        
        # Remove question marks and other punctuation that shouldn't be in URLs
        query = query.replace('?', '').replace('!', '').replace('.', '').replace(',', '')
        
        # Remove common question words
        query = re.sub(
            r'\b(what|who|why|how|is|are|does|do|research|study|learn about|tell me about)\b',
            '',
            query,
            flags=re.IGNORECASE
        )
        
        # Clean up whitespace
        query = re.sub(r'\s+', ' ', query).strip()
        
        # Capitalize first letter for Wikipedia-style URLs
        if query:
            query = query[0].upper() + query[1:] if len(query) > 1 else query.upper()
        
        return query
    
    def _select_sites(self, query: str, force_general_knowledge: bool = False) -> List[SafeSite]:
        """Select which safe sites to use for a query based on query type."""
        max_results = self.search_strategy.get("max_results", 3)
        
        # Detect if this is a programming/code query or general knowledge query
        query_lower = query.lower()
        is_programming_query = self._is_programming_query(query_lower) and not force_general_knowledge
        
        selected = []
        
        if is_programming_query:
            # Programming query: prioritize documentation, tutorials, Q&A
            priority_order = ["documentation", "tutorial", "qna", "code", "encyclopedia", "wiki"]
        else:
            # General knowledge query: prioritize encyclopedia/wiki first
            priority_order = ["encyclopedia", "wiki", "documentation", "tutorial", "qna"]
        
        # Select sites in priority order
        for site_type in priority_order:
            if len(selected) >= max_results:
                break
            
            for site in self.safe_sites:
                if site.type == site_type and site not in selected:
                    selected.append(site)
                    break
        
        # If we still don't have enough, add any remaining enabled sites
        for site in self.safe_sites:
            if len(selected) >= max_results:
                break
            if site not in selected:
                selected.append(site)
        
        return selected[:max_results]
    
    def _is_what_is_question(self, query: str) -> bool:
        """
        Detect if query is asking "what is X" (general knowledge question).
        These should prioritize Wikipedia even if X is a programming term.
        """
        query_lower = query.lower().strip()
        
        # Patterns that indicate "what is" questions
        what_is_patterns = [
            r'^what\s+is\s+',
            r'^what\s+are\s+',
            r'^what\s+was\s+',
            r'^what\s+were\s+',
            r'^tell\s+me\s+about\s+',
            r'^explain\s+',
            r'^describe\s+',
            r'^define\s+',
            r'^what\s+does\s+.+\s+mean',
            r'^what\s+is\s+.+\s+\?',
        ]
        
        for pattern in what_is_patterns:
            if re.search(pattern, query_lower):
                return True
        
        return False
    
    def _is_programming_query(self, query: str) -> bool:
        """
        Detect if query is about programming/coding or general knowledge.
        Returns True for programming queries, False for general knowledge.
        """
        # Programming-related keywords
        programming_keywords = [
            'python', 'javascript', 'java', 'code', 'coding', 'programming',
            'function', 'class', 'method', 'variable', 'array', 'list', 'dict',
            'loop', 'recursion', 'algorithm', 'data structure', 'api', 'library',
            'framework', 'module', 'import', 'syntax', 'error', 'exception',
            'debug', 'compile', 'runtime', 'sql', 'database', 'html', 'css',
            'react', 'django', 'flask', 'pandas', 'numpy', 'tensorflow', 'pytorch',
            'git', 'docker', 'kubernetes', 'aws', 'azure', 'linux', 'windows',
            'qt', 'pyside', 'pyqt', 'gui', 'widget', 'opengl', 'shader',
            'how to', 'how do i', 'implement', 'create', 'build', 'install'
        ]
        
        # General knowledge keywords (these should go to Wikipedia)
        general_keywords = [
            'history', 'science', 'math', 'physics', 'chemistry', 'biology',
            'geography', 'country', 'city', 'person', 'company', 'animal',
            'plant', 'food', 'music', 'art', 'literature', 'philosophy',
            'religion', 'culture', 'language', 'sport', 'game', 'movie', 'book',
            'pi', 'euler', 'fibonacci', 'prime', 'golden ratio', 'infinity',
            'planet', 'star', 'galaxy', 'atom', 'molecule', 'element'
        ]
        
        query = query.lower()
        
        # Check for general knowledge keywords first
        for keyword in general_keywords:
            if keyword in query:
                return False
        
        # Check for programming keywords
        for keyword in programming_keywords:
            if keyword in query:
                return True
        
        # Default to general knowledge (encyclopedia) for short/simple queries
        return False
    
    def _fetch_site_info(self, site: SafeSite, query: str) -> Optional[str]:
        """
        Fetch information from a safe site.
        Returns extracted text content, or None if fetch fails.
        """
        timeout = self.search_strategy.get("timeout_seconds", 5)
        
        # Special handling for Wikipedia (use API)
        if "wikipedia.org" in site.url:
            return self._fetch_wikipedia_info(query, timeout)
        
        # For other sites, try to fetch and extract text
        # (Most other sites are search pages, so we'll focus on Wikipedia for now)
        return None
    
    def _fetch_wikipedia_info(self, query: str, timeout: int = 5) -> Optional[str]:
        """
        Fetch information from Wikipedia using their REST API.
        Handles disambiguation pages by finding the most relevant article.
        Returns the extract (summary) from the article.
        """
        try:
            # Use Wikipedia REST API for clean JSON response
            # Format: https://en.wikipedia.org/api/rest_v1/page/summary/{title}
            article_title = query.replace(' ', '_')
            api_url = f"https://en.wikipedia.org/api/rest_v1/page/summary/{article_title}"
            
            headers = {
                'User-Agent': 'Nova AI Assistant (PyGenesis IDE) - Research Engine'
            }
            
            response = requests.get(api_url, headers=headers, timeout=timeout)
            
            if response.status_code == 200:
                data = response.json()
                
                # Check if this is a disambiguation page
                page_type = data.get('type', '')
                extract = data.get('extract', '')
                
                # Detect disambiguation pages
                is_disambiguation = (
                    page_type == 'disambiguation' or
                    'may refer to' in extract.lower() or
                    extract.lower().startswith('may refer to:') or
                    'usually refers to' in extract.lower()
                )
                
                if is_disambiguation:
                    # Try to find the most relevant article using search
                    return self._handle_disambiguation(query, timeout, headers)
                
                if extract:
                    # Clean up the extract (remove reference markers, etc.)
                    extract = self._clean_extract(extract)
                    return extract
                else:
                    # Try to get description if extract is empty
                    description = data.get('description', '')
                    if description:
                        return description
            
            # If direct article not found, try search
            elif response.status_code == 404:
                # Try Wikipedia search API to find best match
                return self._search_wikipedia_article(query, timeout, headers)
            
        except requests.exceptions.Timeout:
            return None
        except requests.exceptions.RequestException:
            return None
        except (json.JSONDecodeError, KeyError):
            return None
        
        return None
    
    def _handle_disambiguation(self, query: str, timeout: int, headers: dict) -> Optional[str]:
        """
        Handle Wikipedia disambiguation pages by finding the most relevant article.
        For game development context (PyGenesis), prioritizes game engines, software, programming tools.
        """
        query_lower = query.lower()
        
        # Context-aware patterns based on query type
        # For game engines/software terms, prioritize technical articles
        if query_lower in ['godot', 'unity', 'unreal', 'cocos', 'phaser', 'construct', 'gamemaker']:
            # Game engine/software terms
            patterns = [
                f"{query} (game engine)",
                f"{query} (software)",
                f"{query} (engine)",
            ]
        elif any(term in query_lower for term in ['engine', 'framework', 'library', 'tool']):
            # Technical terms
            patterns = [
                f"{query} (software)",
                f"{query} (programming)",
                f"{query} (engine)",
            ]
        else:
            # General terms - try common patterns
            patterns = [
                f"{query} (software)",
                f"{query} (programming)",
                f"{query} (game engine)",
            ]
        
        # Also try capitalized version
        query_capitalized = query.title()
        patterns.extend([
            f"{query_capitalized} (game engine)",
            f"{query_capitalized} (software)",
        ])
        
        # Try each pattern
        for pattern in patterns:
            article_title = pattern.replace(' ', '_')
            api_url = f"https://en.wikipedia.org/api/rest_v1/page/summary/{article_title}"
            
            try:
                response = requests.get(api_url, headers=headers, timeout=timeout)
                if response.status_code == 200:
                    data = response.json()
                    extract = data.get('extract', '')
                    if extract and 'may refer to' not in extract.lower():
                        return self._clean_extract(extract)
            except Exception:
                continue
        
        # If no specific article found, use search API to find best match
        return self._search_wikipedia_article(query, timeout, headers)
    
    def _search_wikipedia_article(self, query: str, timeout: int, headers: dict) -> Optional[str]:
        """
        Search Wikipedia for the best matching article.
        Uses Wikipedia's search API to find the most relevant result.
        """
        try:
            # Use Wikipedia search API
            search_api_url = f"https://en.wikipedia.org/api/rest_v1/page/search/{quote_plus(query)}"
            search_response = requests.get(search_api_url, headers=headers, timeout=timeout, params={'limit': 3})
            
            if search_response.status_code == 200:
                search_data = search_response.json()
                pages = search_data.get('pages', [])
                
                if pages:
                    # Get the first (most relevant) result
                    best_match = pages[0]
                    page_key = best_match.get('key', '')
                    
                    if page_key:
                        # Fetch the full summary for the best match
                        summary_url = f"https://en.wikipedia.org/api/rest_v1/page/summary/{page_key}"
                        summary_response = requests.get(summary_url, headers=headers, timeout=timeout)
                        
                        if summary_response.status_code == 200:
                            summary_data = summary_response.json()
                            extract = summary_data.get('extract', '')
                            
                            # Skip if it's still a disambiguation
                            if extract and 'may refer to' not in extract.lower():
                                return self._clean_extract(extract)
                            
                            # If first result is disambiguation, try second result
                            if len(pages) > 1:
                                second_match = pages[1]
                                page_key = second_match.get('key', '')
                                if page_key:
                                    summary_url = f"https://en.wikipedia.org/api/rest_v1/page/summary/{page_key}"
                                    summary_response = requests.get(summary_url, headers=headers, timeout=timeout)
                                    if summary_response.status_code == 200:
                                        summary_data = summary_response.json()
                                        extract = summary_data.get('extract', '')
                                        if extract and 'may refer to' not in extract.lower():
                                            return self._clean_extract(extract)
        
        except Exception:
            pass
        
        return None
    
    def _is_implementation_query(self, query: str) -> bool:
        """Detect if query is asking how to implement something."""
        implementation_patterns = [
            r'\bhow would you implement\b',
            r'\bhow to implement\b',
            r'\bhow do i implement\b',
            r'\bhow would i implement\b',
        ]
        query_lower = query.lower()
        for pattern in implementation_patterns:
            if re.search(pattern, query_lower, re.IGNORECASE):
                return True
        return False
    
    def _is_guidance_query(self, query: str) -> bool:
        """Detect if query is asking for guidance/advice (best way to, how to use, etc.)."""
        guidance_patterns = [
            r'\bbest way to\b',
            r'\bbest ways to\b',
            r'\bhow to use\b',
            r'\bhow do you use\b',
            r'\bhow should i use\b',
            r'\bwhat is the best\b',
            r'\bwhat are the best\b',
            r'\bhow can i\b',
            r'\bhow do i\b',
            r'\bhow would you\b',  # "How would you extract..."
            r'\bhow would i\b',
            r'\bwhen should i use\b',
            r'\bwhy should i use\b',
            r'\btips for\b',
            r'\bguide to\b',
            r'\btutorial on\b',
        ]
        query_lower = query.lower()
        for pattern in guidance_patterns:
            if re.search(pattern, query_lower, re.IGNORECASE):
                return True
        return False
    
    def _handle_guidance_query(self, context: WorkflowContext, query: str, original_query: str) -> str:
        """
        Handle guidance/advice queries like "best way to use X in Python".
        Provides practical guidance with research and examples.
        """
        # Check if query contains multiple questions (separated by "and")
        query_lower = original_query.lower()
        if ' and ' in query_lower or ' and how' in query_lower:
            # Split into multiple questions
            parts = re.split(r'\s+and\s+', original_query, flags=re.IGNORECASE)
            if len(parts) >= 2:
                return self._handle_multi_part_guidance(context, parts, original_query)
        
        # Extract the core topic from the query
        topic = self._extract_guidance_topic(original_query)
        
        # Research the topic for background
        topic_info = self._research_topic(topic, context)
        
        # Check for existing code in the project
        project_analysis = self._analyze_project_for_topic(context, topic)
        
        # Build a helpful guidance response
        response_parts = []
        
        # Title - use a cleaner title based on the main topic, fix common misspellings
        clean_title = topic if topic else "Guidance"
        clean_title = clean_title.replace("Frustrum", "Frustum").replace("frustrum", "Frustum")
        response_parts.append(f"## {clean_title}\n\n")
        
        # Background info from research
        if topic_info:
            response_parts.append("### Background\n\n")
            response_parts.append(f"{topic_info}\n\n")
        
        # Guidance section
        response_parts.append("### Guidance\n\n")
        
        # Generate practical guidance based on the topic
        guidance = self._generate_guidance(topic, original_query)
        response_parts.append(f"{guidance}\n\n")
        
        # Project-specific improvements if code was found
        if project_analysis and project_analysis.get('found_code'):
            response_parts.append("### Your Project Code Analysis\n\n")
            improvements = self._generate_project_improvements(topic, project_analysis, original_query)
            response_parts.append(f"{improvements}\n\n")
        
        # Example code - always show for graphics/rendering topics
        should_show_example = (
            self._is_programming_query(topic.lower()) or
            'culling' in topic.lower() or
            'frustum' in topic.lower() or
            'frustrum' in topic.lower() or
            'render' in topic.lower() or
            'opengl' in topic.lower()
        )
        
        if should_show_example:
            example_code = self._generate_example_code(topic, topic_info, None)
            if example_code and "TODO" not in example_code:  # Skip generic examples
                response_parts.append("### Example Code\n\n")
                response_parts.append("```python\n")
                response_parts.append(example_code)
                response_parts.append("\n```\n\n")
        
        response_parts.append("*Note: For detailed tutorials, check official documentation or community resources.*")
        
        return "".join(response_parts)
    
    def _handle_multi_part_guidance(self, context: WorkflowContext, query_parts: List[str], original_query: str) -> str:
        """
        Handle guidance queries with multiple questions (e.g., "X and how to Y").
        """
        response_parts = []
        
        # Determine main topic from first part - use a cleaner title
        first_topic = self._extract_guidance_topic(query_parts[0])
        # Clean up title - remove "in Python" etc. and fix common misspellings
        clean_title = first_topic.replace(" in Python", "").replace(" in python", "").strip()
        # Fix common misspellings
        clean_title = clean_title.replace("Frustrum", "Frustum").replace("frustrum", "Frustum")
        if not clean_title:
            clean_title = "Guidance"
        response_parts.append(f"## {clean_title}\n\n")
        
        # Handle first question (general guidance)
        first_topic = self._extract_guidance_topic(query_parts[0])
        topic_info = self._research_topic(first_topic, context)
        project_analysis = self._analyze_project_for_topic(context, first_topic)
        
        if topic_info:
            response_parts.append("### Background\n\n")
            response_parts.append(f"{topic_info}\n\n")
        
        response_parts.append("### Guidance\n\n")
        guidance = self._generate_guidance(first_topic, query_parts[0])
        response_parts.append(f"{guidance}\n\n")
        
        # Project-specific improvements
        if project_analysis and project_analysis.get('found_code'):
            response_parts.append("### Your Project Code Analysis\n\n")
            improvements = self._generate_project_improvements(first_topic, project_analysis, query_parts[0])
            response_parts.append(f"{improvements}\n\n")
        
        # Handle second question (specific implementation)
        if len(query_parts) >= 2:
            second_topic = self._extract_guidance_topic(query_parts[1])
            # Use a clearer section title
            if 'extract' in second_topic.lower():
                section_title = "Extracting Frustum Planes"
            else:
                section_title = second_topic
            response_parts.append(f"### {section_title}\n\n")
            
            # Generate specific guidance for the second question
            second_guidance = self._generate_guidance(second_topic, query_parts[1])
            response_parts.append(f"{second_guidance}\n\n")
            
            # Check for project code related to second question
            second_analysis = self._analyze_project_for_topic(context, second_topic)
            if second_analysis and second_analysis.get('found_code'):
                response_parts.append("### Your Project Code Analysis (Implementation)\n\n")
                second_improvements = self._generate_project_improvements(second_topic, second_analysis, query_parts[1])
                response_parts.append(f"{second_improvements}\n\n")
        
        # Example code - always show for graphics/rendering topics
        should_show_example = (
            self._is_programming_query(first_topic.lower()) or
            'culling' in first_topic.lower() or
            'frustum' in first_topic.lower() or
            'frustrum' in first_topic.lower() or
            'render' in first_topic.lower() or
            'opengl' in first_topic.lower()
        )
        
        if should_show_example:
            example_code = self._generate_example_code(first_topic, topic_info, None)
            if example_code and "TODO" not in example_code:
                response_parts.append("### Example Code\n\n")
                response_parts.append("```python\n")
                response_parts.append(example_code)
                response_parts.append("\n```\n\n")
        
        response_parts.append("*Note: For detailed tutorials, check official documentation or community resources.*")
        
        return "".join(response_parts)
    
    def _extract_guidance_topic(self, query: str) -> str:
        """Extract the main topic from a guidance query."""
        query_lower = query.lower()
        
        # Remove common prefixes
        prefixes = [
            r'^what is the best way to use\s+',
            r'^what are the best ways to use\s+',
            r'^the best way to use\s+',
            r'^best way to use\s+',
            r'^how would you\s+',
            r'^how would i\s+',
            r'^how do you\s+',
            r'^how to use\s+',
            r'^how should i use\s+',
            r'^how can i use\s+',
            r'^how do i\s+',
            r'^how can i\s+',
            r'^how to\s+',
        ]
        
        topic = query
        for prefix in prefixes:
            topic = re.sub(prefix, '', topic, flags=re.IGNORECASE)
        
        # Remove trailing " in python" or similar
        topic = re.sub(r'\s+in\s+(python|javascript|java|c\+\+|rust|go)[\?\s]*$', '', topic, flags=re.IGNORECASE)
        
        # Remove "from the" / "from a" type phrases at the end
        topic = re.sub(r'\s+from\s+(?:the|a|an)\s+.+$', '', topic, flags=re.IGNORECASE)
        
        # Clean up
        topic = topic.strip('? ').strip()
        
        # Capitalize first letter
        if topic:
            topic = topic[0].upper() + topic[1:] if len(topic) > 1 else topic.upper()
        
        return topic
    
    def _generate_guidance(self, topic: str, original_query: str) -> str:
        """Generate practical guidance for a topic."""
        topic_lower = topic.lower()
        original_lower = original_query.lower()
        
        # Specific: extracting frustum planes
        if 'extract' in topic_lower and ('frustum' in topic_lower or 'frustrum' in topic_lower or 'frustum' in original_lower or 'frustrum' in original_lower):
            return """**Extracting Frustum Planes from the View-Projection Matrix**

The combined view-projection matrix (P × V) encodes all 6 frustum planes in clip space. Here's how to extract them:

**The Math:**
Each plane is extracted by combining rows of the matrix. The plane equation is `ax + by + cz + d = 0`, where `[a, b, c]` is the normal vector:

```
Left:   row4 + row1  (normal points right)
Right:  row4 - row1  (normal points left)
Bottom: row4 + row2 (normal points up)
Top:    row4 - row2 (normal points down)
Near:   row4 + row3 (normal points away from camera)
Far:    row4 - row3 (normal points toward camera)
```

**Python/NumPy Implementation:**

```python
import numpy as np

def extract_frustum_planes(view_proj_matrix):
    '''
    Extract 6 frustum planes from combined view-projection matrix.
    
    Args:
        view_proj_matrix: 4x4 numpy array (P × V, column-major, OpenGL convention)
    
    Returns:
        List of 6 planes, each as [a, b, c, d] where [a,b,c] is normalized normal
    '''
    m = view_proj_matrix
    planes = []
    
    # Extract planes (OpenGL convention, column-major)
    planes.append(m[3] + m[0])  # Left
    planes.append(m[3] - m[0])   # Right
    planes.append(m[3] + m[1])   # Bottom
    planes.append(m[3] - m[1])   # Top
    planes.append(m[3] + m[2])   # Near
    planes.append(m[3] - m[2])   # Far
    
    # Normalize each plane (normalize the normal vector [a, b, c])
    for i, plane in enumerate(planes):
        normal_length = np.linalg.norm(plane[:3])
        if normal_length > 0:
            planes[i] = plane / normal_length
    
    return planes
```

**Usage:**
```python
view_matrix = get_camera_view_matrix()  # 4x4 matrix
proj_matrix = get_projection_matrix()   # 4x4 matrix
vp = proj_matrix @ view_matrix          # P × V (OpenGL order)
planes = extract_frustum_planes(vp)

# Test a point
point = np.array([x, y, z, 1.0])
for plane in planes:
    distance = np.dot(plane, point)  # Signed distance to plane
    if distance < 0:
        # Point is outside this plane (culled)
        break
```

**Important Notes:**
- **Matrix format**: Column-major (OpenGL standard)
- **Matrix order**: `P × V` (projection × view), not `V × P`
- **Coordinate system**: Assumes right-handed OpenGL (Y-up, Z-backward)
- **Normalization**: Only normalizes the normal vector `[a, b, c]`, not the distance `d`
- **Reversed-Z**: For modern OpenGL with reversed-Z depth buffers, near/far plane signs may need adjustment
- **Update frequency**: Recalculate planes whenever camera or projection changes"""
        
        # Graphics/rendering topics
        if 'culling' in topic_lower:
            if 'frustum' in topic_lower or 'frustrum' in topic_lower:
                return """**Frustum Culling** is an optimization technique that skips rendering objects outside the camera's view.

**Best practices in Python/OpenGL:**

1. **Extract frustum planes** from your view-projection matrix
2. **Test bounding volumes** (spheres or boxes) against the 6 frustum planes
3. **Early rejection** - if an object is outside ANY plane, skip it
4. **Use spatial structures** like octrees/BVHs for large scenes
5. **Cache results** when camera hasn't moved

**When to use:**
- Scenes with many objects (100+)
- Large open worlds
- Objects with expensive shaders

**Performance tips:**
- Use bounding spheres for fast initial tests
- Only test AABBs for objects that pass sphere tests
- Update frustum planes only when camera moves"""
            elif 'occlusion' in topic_lower:
                return """**Occlusion Culling** skips rendering objects hidden behind other objects.

**Best practices in Python/OpenGL:**

1. **Hardware occlusion queries** (GL_ARB_occlusion_query)
2. **Two-pass approach**: Test with bounding boxes, then render visible objects
3. **Temporal coherence**: Assume objects visible last frame are still visible

**When to use:**
- Indoor scenes with walls/rooms
- Dense environments (cities, forests)
- Many overlapping objects

**Warning:** Occlusion queries have GPU latency. Consider:
- Using previous frame's results
- Only testing large/expensive objects"""
        
        # General programming guidance
        return f"""For **{topic}**, here are general best practices:

1. **Understand the concept** - Research how it works before implementing
2. **Start simple** - Get a basic version working first
3. **Profile before optimizing** - Measure to know if optimization helps
4. **Check existing libraries** - Don't reinvent the wheel
5. **Read documentation** - Official docs are your best friend

*For specific implementation details, consult the official documentation or tutorials for your framework.*"""
    
    def _handle_implementation_query(self, context: WorkflowContext, query: str, original_query: str) -> str:
        """
        Handle "how would you implement X" queries with research and example code.
        This is used when no project is loaded - provides educational/research response.
        """
        # Extract the topic (e.g., "Occlusion Culling" from "How would you implement Occlusion Culling?")
        topic = query.strip()
        
        # Research the main topic
        topic_info = self._research_topic(topic, context)
        
        # Research PyOpenGL context (for graphics-related queries)
        pyopengl_info = None
        graphics_keywords = ['culling', 'occlusion', 'rendering', 'shader', 'opengl', 'graphics', 'gpu']
        if any(keyword in topic.lower() for keyword in graphics_keywords):
            pyopengl_info = self._research_topic("PyOpenGL", context)
        
        # Build thinking content (research findings)
        thinking_parts = [
            f"**Research Plan for: {topic}**\n\n",
            "1. **Understanding the Concept**\n",
            f"   Researching '{topic}' to understand the core principles and techniques.\n\n"
        ]
        
        if topic_info:
            thinking_parts.append(f"   Found information about {topic}:\n")
            # Truncate to first 300 chars for thinking
            info_preview = topic_info[:300] + "..." if len(topic_info) > 300 else topic_info
            thinking_parts.append(f"   {info_preview}\n\n")
        
        if pyopengl_info:
            thinking_parts.append("2. **PyOpenGL Context**\n")
            thinking_parts.append("   Researching PyOpenGL to understand the Python OpenGL bindings.\n\n")
            info_preview = pyopengl_info[:300] + "..." if len(pyopengl_info) > 300 else pyopengl_info
            thinking_parts.append(f"   {info_preview}\n\n")
        
        thinking_parts.append("3. **Implementation Strategy**\n")
        thinking_parts.append("   Based on research, creating example implementation code.\n")
        
        thinking_content = "".join(thinking_parts)
        
        # Generate example code based on topic
        example_code = self._generate_example_code(topic, topic_info, pyopengl_info)
        
        # Build response with thinking and code preview
        response_parts = [
            f"## How to Implement {topic}\n\n",
            "### Research Findings\n\n"
        ]
        
        if topic_info:
            response_parts.append(f"{topic_info}\n\n")
        
        if pyopengl_info:
            response_parts.append("### PyOpenGL Context\n\n")
            response_parts.append(f"{pyopengl_info}\n\n")
        
        response_parts.append("### Example Implementation\n\n")
        response_parts.append("Here's example code showing how you might implement this:\n\n")
        response_parts.append("```python\n")
        response_parts.append(example_code)
        response_parts.append("\n```\n\n")
        response_parts.append("*Note: This is example code. Adapt it to your specific project needs.*")
        
        # Store thinking and code in context for UI display
        # The workflow will handle displaying this in "Show Thinking" and "Show Preview"
        context.thinking_content = thinking_content
        context.example_code = example_code
        
        return "".join(response_parts)
    
    def _research_topic(self, topic: str, context: WorkflowContext) -> Optional[str]:
        """Research a topic and return information."""
        # Use the same logic as regular research
        sites_to_use = self._select_sites(topic, force_general_knowledge=True)
        allow_auto_followup = self._get_allow_auto_followup(context)
        
        for site in sites_to_use:
            try:
                info = self._fetch_site_info(site, topic)
                
                # If direct fetch failed and auto followup is enabled, try search API
                if not info and allow_auto_followup and "wikipedia.org" in site.url:
                    info = self._search_wikipedia_article(topic, 5, {
                        'User-Agent': 'Nova AI Assistant (PyGenesis IDE) - Research Engine'
                    })
                    if info and len(info.strip()) > 50:
                        return info
                
                if info and len(info.strip()) > 50:
                    return info
            except Exception:
                continue
        
        return None
    
    def _generate_example_code(self, topic: str, topic_info: Optional[str], pyopengl_info: Optional[str]) -> str:
        """Generate example code based on the topic and research."""
        topic_lower = topic.lower()
        
        # Occlusion Culling example
        if 'occlusion' in topic_lower and 'culling' in topic_lower:
            return """import OpenGL.GL as gl
from OpenGL.GL import *
import numpy as np

class OcclusionCulling:
    def __init__(self):
        self.query_objects = {}
        self.occlusion_queries = {}
        
    def create_occlusion_query(self, object_id):
        '''Create an occlusion query for an object.'''
        query_id = gl.glGenQueries(1)
        self.query_objects[object_id] = query_id
        return query_id
    
    def begin_occlusion_query(self, object_id):
        '''Begin rendering the bounding box for occlusion testing.'''
        if object_id in self.query_objects:
            gl.glBeginQuery(GL_SAMPLES_PASSED, self.query_objects[object_id])
            gl.glColorMask(False, False, False, False)  # Disable color writes
            gl.glDepthMask(False)  # Disable depth writes
    
    def end_occlusion_query(self, object_id):
        '''End the occlusion query.'''
        if object_id in self.query_objects:
            gl.glEndQuery(GL_SAMPLES_PASSED)
            gl.glColorMask(True, True, True, True)  # Re-enable color writes
            gl.glDepthMask(True)  # Re-enable depth writes
    
    def is_visible(self, object_id):
        '''Check if an object passed the occlusion test.'''
        if object_id not in self.query_objects:
            return True  # Default to visible if no query
        
        query_id = self.query_objects[object_id]
        result = gl.glGetQueryObjectuiv(query_id, GL_QUERY_RESULT)
        return result > 0  # Visible if samples passed > 0
    
    def render_with_occlusion_culling(self, objects):
        '''Render objects with occlusion culling.'''
        # First pass: Test occlusion for each object
        for obj in objects:
            self.begin_occlusion_query(obj.id)
            obj.render_bounding_box()  # Render only bounding box
            self.end_occlusion_query(obj.id)
        
        # Second pass: Render only visible objects
        for obj in objects:
            if self.is_visible(obj.id):
                obj.render_full()  # Render full object

# Usage example
culling = OcclusionCulling()
objects = [Object1(), Object2(), Object3()]
culling.render_with_occlusion_culling(objects)"""
        
        # Frustum Culling example
        elif 'frustum' in topic_lower and 'culling' in topic_lower:
            return """import OpenGL.GL as gl
import numpy as np
from mathutils import Matrix, Vector

class FrustumCulling:
    def __init__(self):
        self.frustum_planes = [None] * 6
    
    def extract_frustum_planes(self, view_matrix, projection_matrix):
        '''Extract the 6 frustum planes from view and projection matrices.'''
        # Combine matrices
        clip_matrix = projection_matrix @ view_matrix
        
        # Extract planes (left, right, bottom, top, near, far)
        self.frustum_planes[0] = clip_matrix[3] + clip_matrix[0]  # Left
        self.frustum_planes[1] = clip_matrix[3] - clip_matrix[0]  # Right
        self.frustum_planes[2] = clip_matrix[3] + clip_matrix[1]  # Bottom
        self.frustum_planes[3] = clip_matrix[3] - clip_matrix[1]  # Top
        self.frustum_planes[4] = clip_matrix[3] + clip_matrix[2]  # Near
        self.frustum_planes[5] = clip_matrix[3] - clip_matrix[2]  # Far
        
        # Normalize planes
        for i in range(6):
            length = np.linalg.norm(self.frustum_planes[i][:3])
            if length > 0:
                self.frustum_planes[i] /= length
    
    def is_sphere_visible(self, center, radius):
        '''Check if a sphere is inside the frustum.'''
        for plane in self.frustum_planes:
            distance = np.dot(plane[:3], center) + plane[3]
            if distance < -radius:
                return False  # Sphere is outside frustum
        return True
    
    def is_box_visible(self, min_point, max_point):
        '''Check if an AABB (Axis-Aligned Bounding Box) is visible.'''
        # Check if any corner of the box is inside the frustum
        corners = [
            [min_point[0], min_point[1], min_point[2]],
            [max_point[0], min_point[1], min_point[2]],
            [min_point[0], max_point[1], min_point[2]],
            [max_point[0], max_point[1], min_point[2]],
            [min_point[0], min_point[1], max_point[2]],
            [max_point[0], min_point[1], max_point[2]],
            [min_point[0], max_point[1], max_point[2]],
            [max_point[0], max_point[1], max_point[2]],
        ]
        
        for plane in self.frustum_planes:
            inside = False
            for corner in corners:
                distance = np.dot(plane[:3], corner) + plane[3]
                if distance >= 0:
                    inside = True
                    break
            if not inside:
                return False  # Box is completely outside this plane
        return True

# Usage example
culling = FrustumCulling()
view_matrix = get_view_matrix()  # Your view matrix
projection_matrix = get_projection_matrix()  # Your projection matrix
culling.extract_frustum_planes(view_matrix, projection_matrix)

objects = [Object1(), Object2(), Object3()]
for obj in objects:
    if culling.is_sphere_visible(obj.center, obj.radius):
        obj.render()"""
        
        # Default generic implementation example
        else:
            func_name = topic.lower().replace(' ', '_')
            return f"""# Example implementation for {topic}

def implement_{func_name}():
    \"\"\"
    Implementation of {topic}.
    
    Based on research findings, this is a basic example.
    Adapt to your specific needs.
    \"\"\"
    # TODO: Implement {topic}
    pass

# Usage
implement_{func_name}()"""
    
    def _analyze_project_for_topic(self, context: WorkflowContext, topic: str) -> Optional[Dict[str, Any]]:
        """
        Analyze the project for code related to the topic.
        Returns analysis dict with found code and suggestions.
        """
        if not context.app:
            return None
        
        try:
            # Get project path
            project_path = context.app.project_manager.get_project_path() if hasattr(context.app, 'project_manager') else None
            if not project_path:
                return None
            
            from pathlib import Path
            from core.codebase_analyzer import CodebaseAnalyzer
            
            analyzer = CodebaseAnalyzer()
            code_files = analyzer.find_code_files(project_path)
            
            if not code_files:
                return {"found_code": False}
            
            # Search for relevant code based on topic
            topic_lower = topic.lower()
            relevant_files = []
            rendering_code = []
            culling_code = []
            
            # Keywords to search for
            rendering_keywords = ['render', 'draw', 'opengl', 'gl.', 'glDraw', 'shader', 'vertex', 'fragment', 'camera', 'view', 'projection']
            culling_keywords = ['cull', 'frustum', 'frustrum', 'occlusion', 'visible', 'bounding', 'sphere', 'aabb', 'box']
            
            for file_path in code_files:
                try:
                    path_obj = Path(file_path)
                    if path_obj.suffix not in {'.py', '.object', '.script'}:
                        continue
                    
                    content = path_obj.read_text(encoding='utf-8', errors='ignore')
                    content_lower = content.lower()
                    
                    # Check if file contains rendering code
                    has_rendering = any(keyword in content_lower for keyword in rendering_keywords)
                    # Check if file contains culling code
                    has_culling = any(keyword in content_lower for keyword in culling_keywords)
                    
                    # Check if topic-related
                    topic_relevant = (
                        ('frustum' in topic_lower or 'frustrum' in topic_lower) and has_culling
                    ) or (
                        ('render' in topic_lower or 'graphics' in topic_lower) and has_rendering
                    ) or (
                        'cull' in topic_lower and has_culling
                    )
                    
                    if topic_relevant or (has_rendering and has_culling):
                        rel_path = str(path_obj.relative_to(Path(project_path)))
                        
                        # Extract relevant code snippets
                        lines = content.splitlines()
                        relevant_lines = []
                        
                        for i, line in enumerate(lines):
                            line_lower = line.lower()
                            if has_culling and any(kw in line_lower for kw in culling_keywords):
                                # Get context (3 lines before and after)
                                start = max(0, i - 3)
                                end = min(len(lines), i + 4)
                                snippet = '\n'.join(f"{j+1:4d}| {lines[j]}" for j in range(start, end))
                                relevant_lines.append({
                                    'line': i + 1,
                                    'snippet': snippet,
                                    'type': 'culling'
                                })
                            elif has_rendering and any(kw in line_lower for kw in rendering_keywords):
                                start = max(0, i - 3)
                                end = min(len(lines), i + 4)
                                snippet = '\n'.join(f"{j+1:4d}| {lines[j]}" for j in range(start, end))
                                relevant_lines.append({
                                    'line': i + 1,
                                    'snippet': snippet,
                                    'type': 'rendering'
                                })
                        
                        if relevant_lines:
                            if has_culling:
                                culling_code.append({
                                    'file': rel_path,
                                    'lines': [l for l in relevant_lines if l['type'] == 'culling']
                                })
                            if has_rendering:
                                rendering_code.append({
                                    'file': rel_path,
                                    'lines': [l for l in relevant_lines if l['type'] == 'rendering']
                                })
                            
                            relevant_files.append({
                                'file': rel_path,
                                'has_rendering': has_rendering,
                                'has_culling': has_culling,
                                'snippets': relevant_lines[:5]  # Limit to 5 snippets per file
                            })
                
                except Exception as e:
                    continue  # Skip files that can't be read
            
            return {
                "found_code": len(relevant_files) > 0,
                "relevant_files": relevant_files,
                "rendering_code": rendering_code,
                "culling_code": culling_code,
                "project_path": project_path
            }
        
        except Exception as e:
            return None
    
    def _generate_project_improvements(self, topic: str, analysis: Dict[str, Any], original_query: str) -> str:
        """
        Generate specific improvement suggestions based on found project code.
        """
        topic_lower = topic.lower()
        improvements = []
        
        # Frustum culling improvements
        if 'frustum' in topic_lower or 'frustrum' in topic_lower or 'cull' in topic_lower:
            culling_code = analysis.get('culling_code', [])
            rendering_code = analysis.get('rendering_code', [])
            
            if culling_code:
                improvements.append("**Found existing culling code in your project:**\n")
                for code_info in culling_code[:3]:  # Limit to 3 files
                    improvements.append(f"- `{code_info['file']}`")
                    if code_info['lines']:
                        line_nums = [str(l['line']) for l in code_info['lines'][:3]]
                        improvements.append(f"  - Found culling-related code at lines: {', '.join(line_nums)}")
                improvements.append("")
                
                # Check if they're asking about extraction specifically
                if 'extract' in topic_lower:
                    improvements.append("**Specific improvements for plane extraction:**\n")
                    improvements.append("1. **Use matrix-based extraction** (shown in guidance above)")
                    improvements.append("   - Replace manual plane calculations with matrix row operations")
                    improvements.append("   - More efficient and less error-prone\n")
                    
                    improvements.append("2. **Ensure proper normalization**")
                    improvements.append("   - Normalize only the normal vector `[a, b, c]`, not the distance `d`")
                    improvements.append("   - Use: `plane = plane / np.linalg.norm(plane[:3])`\n")
                    
                    improvements.append("3. **Store planes efficiently**")
                    improvements.append("   - Cache planes as class members")
                    improvements.append("   - Only recalculate when `view_matrix` or `projection_matrix` changes\n")
                else:
                    improvements.append("**Improvements you can make:**\n")
                    improvements.append("1. **Extract frustum planes from view-projection matrix**")
                    improvements.append("   - Your current code may be calculating planes manually or not at all")
                    improvements.append("   - Use the matrix extraction method for better performance\n")
                    
                    improvements.append("2. **Normalize plane equations**")
                    improvements.append("   - Ensure all plane normals are normalized for correct distance calculations")
                    improvements.append("   - This prevents incorrect culling decisions\n")
                    
                    improvements.append("3. **Cache frustum planes**")
                    improvements.append("   - Only recalculate when camera or projection changes")
                    improvements.append("   - Store planes as class members to avoid recalculation each frame\n")
                    
                    improvements.append("4. **Use bounding spheres first**")
                    improvements.append("   - Test spheres before AABBs for faster rejection")
                    improvements.append("   - Only test AABBs for objects that pass sphere tests\n")
            
            elif rendering_code:
                improvements.append("**Found rendering code, but no culling implementation:**\n")
                for code_info in rendering_code[:2]:
                    improvements.append(f"- `{code_info['file']}`")
                improvements.append("")
                improvements.append("**Recommendation:** Add frustum culling to improve performance.\n")
                improvements.append("- Your rendering code can benefit from skipping objects outside the view")
                improvements.append("- This is especially important if you're rendering many objects\n")
        
        # General rendering improvements
        elif 'render' in topic_lower or 'graphics' in topic_lower:
            rendering_code = analysis.get('rendering_code', [])
            if rendering_code:
                improvements.append("**Found rendering code in your project:**\n")
                for code_info in rendering_code[:3]:
                    improvements.append(f"- `{code_info['file']}`")
                improvements.append("")
                improvements.append("**Consider adding frustum culling if you haven't already:**\n")
                improvements.append("- Reduces draw calls for off-screen objects")
                improvements.append("- Improves frame rate in scenes with many objects\n")
        
        if not improvements:
            return "I found code files in your project, but couldn't identify specific rendering or culling code related to this topic."
        
        return "\n".join(improvements)
    
    def _get_allow_auto_followup(self, context: WorkflowContext) -> bool:
        """
        Check if auto followup is enabled in PyGenesis settings.
        Returns False if app is not available or setting is not found.
        """
        if not context.app:
            return False
        
        try:
            if hasattr(context.app, 'settings'):
                return bool(context.app.settings.get("AI_Allow_Auto_Followup", False))
        except Exception:
            pass
        
        return False
    
    def _clean_extract(self, text: str) -> str:
        """
        Clean up extracted text from Wikipedia or other sources.
        Removes reference markers, excessive whitespace, etc.
        """
        if not text:
            return ""
        
        # Remove Wikipedia reference markers like [1], [2], etc.
        text = re.sub(r'\[\d+\]', '', text)
        
        # Remove citation markers like (citation needed), etc.
        text = re.sub(r'\(citation needed\)', '', text, flags=re.IGNORECASE)
        
        # Clean up multiple spaces/newlines
        text = re.sub(r'\s+', ' ', text)
        
        # Remove leading/trailing whitespace
        text = text.strip()
        
        # Limit length to reasonable size (first ~1000 characters or first 2 sentences)
        if len(text) > 1000:
            # Try to cut at sentence boundary
            sentences = re.split(r'([.!?]\s+)', text[:1000])
            if len(sentences) > 2:
                # Take first 2 complete sentences
                text = ''.join(sentences[:3])  # 3 because split includes delimiters
            else:
                text = text[:1000] + "..."
        
        return text

