"""
Base Engine - Abstract base class for all engines.
Engines are simpler than executors - they process specific types of queries.
"""
from abc import ABC, abstractmethod

from core.workflow import WorkflowContext


class BaseEngine(ABC):
    """Base class for all engines."""
    
    @abstractmethod
    def process(self, context: WorkflowContext) -> str:
        """
        Process the query using this engine.
        Returns the response text to display in chat.
        """
        pass

