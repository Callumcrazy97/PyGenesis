"""
Dictionary Engine - Provides word definitions.
Uses downloadable knowledge bases (WordNet via NLTK) if available,
with fallback to pattern-based responses.
"""
import os
import re
from typing import Optional, Dict

from core.engines.base_engine import BaseEngine
from core.workflow import WorkflowContext

# Try to import NLTK WordNet, but fallback gracefully
try:
    import nltk
    from nltk.corpus import wordnet as wn
    WORDNET_AVAILABLE = True
    
    # Download WordNet data if not already present
    try:
        nltk.data.find('corpora/wordnet')
    except LookupError:
        try:
            nltk.download('wordnet', quiet=True)
        except Exception:
            WORDNET_AVAILABLE = False
except (ImportError, Exception):
    WORDNET_AVAILABLE = False
    wn = None


class DictionaryEngine(BaseEngine):
    """Provides word definitions using WordNet or fallback methods."""
    
    def __init__(self):
        # Simple fallback dictionary for common words
        self.fallback_dict = {
            "python": "A high-level programming language known for its simplicity and readability.",
            "code": "Instructions written in a programming language that a computer can execute.",
            "function": "A block of code that performs a specific task and can be called repeatedly.",
            "variable": "A named storage location that holds a value in a program.",
            "class": "A blueprint for creating objects in object-oriented programming.",
            "algorithm": "A step-by-step procedure for solving a problem or completing a task.",
            "debug": "The process of finding and fixing errors in code.",
            "api": "Application Programming Interface - a set of protocols for building software.",
            "json": "JavaScript Object Notation - a lightweight data interchange format.",
            "html": "HyperText Markup Language - the standard markup language for web pages.",
            "css": "Cascading Style Sheets - used for styling web pages.",
            "javascript": "A programming language commonly used for web development.",
            "database": "An organized collection of data stored and accessed electronically.",
            "server": "A computer or system that provides services to other computers over a network.",
            "client": "A computer or program that accesses services provided by a server.",
        }
    
    def process(self, context: WorkflowContext) -> str:
        """Process dictionary lookup request."""
        word = context.entity or self._extract_word(context.user_input)
        
        if not word:
            return "I need a word to define. Please ask something like 'Define python' or 'What does code mean?'"
        
        word_lower = word.lower().strip()
        
        # Try WordNet first if available
        if WORDNET_AVAILABLE:
            definition = self._lookup_wordnet(word_lower)
            if definition:
                return definition
        
        # Fallback to simple dictionary
        if word_lower in self.fallback_dict:
            return f"**{word.title()}**: {self.fallback_dict[word_lower]}"
        
        # Generic response
        return (
            f"I don't have a definition for '{word}' in my knowledge base. "
            f"You might want to check a dictionary or search online for more information."
        )
    
    def _extract_word(self, text: str) -> Optional[str]:
        """Extract word from user input."""
        # Patterns: "define X", "definition of X", "what does X mean"
        patterns = [
            r'\b(?:define|definition of|meaning of)\s+(\w+)',
            r'\bwhat does\s+(\w+)\s+mean',
            r'\bwhat is\s+(\w+)',
        ]
        
        for pattern in patterns:
            match = re.search(pattern, text.lower())
            if match:
                return match.group(1)
        
        # If no pattern matches, try to extract a single word
        words = re.findall(r'\b\w+\b', text.lower())
        if words:
            # Skip common question words
            skip_words = {'what', 'is', 'does', 'mean', 'the', 'a', 'an', 'define', 'definition', 'of', 'meaning'}
            for word in words:
                if word not in skip_words:
                    return word
        
        return None
    
    def _lookup_wordnet(self, word: str) -> Optional[str]:
        """Look up word definition using WordNet."""
        try:
            synsets = wn.synsets(word)
            
            if not synsets:
                return None
            
            # Get the first (most common) synset
            synset = synsets[0]
            
            # Get definition
            definition = synset.definition()
            
            # Get examples if available
            examples = synset.examples()
            
            # Build response
            response_parts = [f"**{word.title()}**: {definition}"]
            
            if examples:
                example_text = "; ".join(examples[:2])  # Max 2 examples
                response_parts.append(f"\nExample: {example_text}")
            
            # Get part of speech
            pos = synset.pos()
            pos_names = {
                'n': 'noun',
                'v': 'verb',
                'a': 'adjective',
                'r': 'adverb',
                's': 'adjective (satellite)'
            }
            if pos in pos_names:
                response_parts.append(f"\nPart of speech: {pos_names[pos]}")
            
            return "\n".join(response_parts)
            
        except Exception as e:
            print(f"WordNet lookup error: {e}")
            return None

