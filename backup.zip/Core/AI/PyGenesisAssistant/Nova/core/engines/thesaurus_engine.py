"""
Thesaurus Engine - Provides synonyms and related words.
Uses WordNet via NLTK if available, with fallback to simple responses.
"""
from typing import Optional, List

from core.engines.base_engine import BaseEngine
from core.workflow import WorkflowContext

# Try to import NLTK WordNet, but fallback gracefully
try:
    import nltk
    from nltk.corpus import wordnet as wn
    WORDNET_AVAILABLE = True
    
    # Download WordNet data if not already present
    try:
        nltk.data.find('corpora/wordnet')
    except LookupError:
        try:
            nltk.download('wordnet', quiet=True)
        except Exception:
            WORDNET_AVAILABLE = False
except (ImportError, Exception):
    WORDNET_AVAILABLE = False
    wn = None


class ThesaurusEngine(BaseEngine):
    """Provides synonyms and related words using WordNet or fallback methods."""
    
    def __init__(self):
        # Simple fallback thesaurus for common words
        self.fallback_thesaurus = {
            "good": ["excellent", "great", "fine", "nice", "wonderful", "superb"],
            "bad": ["poor", "terrible", "awful", "horrible", "dreadful"],
            "big": ["large", "huge", "enormous", "massive", "gigantic"],
            "small": ["tiny", "little", "mini", "miniature", "petite"],
            "fast": ["quick", "rapid", "swift", "speedy", "hasty"],
            "slow": ["sluggish", "leisurely", "gradual", "unhurried"],
            "happy": ["joyful", "cheerful", "glad", "pleased", "delighted"],
            "sad": ["unhappy", "melancholy", "gloomy", "depressed", "down"],
            "smart": ["intelligent", "clever", "bright", "brilliant", "wise"],
            "stupid": ["foolish", "dumb", "silly", "unintelligent", "dense"],
        }
    
    def process(self, context: WorkflowContext) -> str:
        """Process thesaurus lookup request."""
        word = context.entity or self._extract_word(context.user_input)
        
        if not word:
            return "I need a word to find synonyms for. Please ask something like 'Synonym for happy' or 'Another word for good'."
        
        word_lower = word.lower().strip()
        
        # Try WordNet first if available
        if WORDNET_AVAILABLE:
            synonyms = self._lookup_wordnet_synonyms(word_lower)
            if synonyms:
                return self._format_synonyms(word, synonyms)
        
        # Fallback to simple thesaurus
        if word_lower in self.fallback_thesaurus:
            synonyms = self.fallback_thesaurus[word_lower]
            return self._format_synonyms(word, synonyms)
        
        # Generic response
        return (
            f"I don't have synonyms for '{word}' in my knowledge base. "
            f"You might want to check a thesaurus or search online for alternatives."
        )
    
    def _extract_word(self, text: str) -> Optional[str]:
        """Extract word from user input."""
        import re
        
        # Patterns: "synonym for X", "another word for X", "better word for X"
        patterns = [
            r'\b(?:synonym|another word|better word|similar word)\s+(?:for|of)\s+(\w+)',
            r'\bsynonyms?\s+of\s+(\w+)',
            r'\balternative\s+to\s+(\w+)',
        ]
        
        for pattern in patterns:
            match = re.search(pattern, text.lower())
            if match:
                return match.group(1)
        
        # If no pattern matches, try to extract a single word
        words = re.findall(r'\b\w+\b', text.lower())
        if words:
            # Skip common question words
            skip_words = {'synonym', 'synonyms', 'another', 'word', 'for', 'of', 'better', 'similar', 'alternative', 'to', 'the', 'a', 'an'}
            for word in words:
                if word not in skip_words:
                    return word
        
        return None
    
    def _lookup_wordnet_synonyms(self, word: str) -> Optional[List[str]]:
        """Look up synonyms using WordNet."""
        try:
            synsets = wn.synsets(word)
            
            if not synsets:
                return None
            
            # Collect synonyms from all synsets
            synonyms = set()
            
            for synset in synsets:
                # Get lemma names (synonyms)
                for lemma in synset.lemmas():
                    synonym = lemma.name().replace('_', ' ')
                    if synonym.lower() != word.lower():
                        synonyms.add(synonym)
            
            # Also get antonyms if available
            antonyms = set()
            for synset in synsets:
                for lemma in synset.lemmas():
                    if lemma.antonyms():
                        for antonym in lemma.antonyms():
                            antonyms.add(antonym.name().replace('_', ' '))
            
            result = {
                'synonyms': sorted(list(synonyms))[:10],  # Limit to 10
                'antonyms': sorted(list(antonyms))[:5] if antonyms else None
            }
            
            return result
            
        except Exception as e:
            print(f"WordNet lookup error: {e}")
            return None
    
    def _format_synonyms(self, word: str, synonyms) -> str:
        """Format synonyms for display."""
        if isinstance(synonyms, dict):
            # WordNet format
            response_parts = [f"**{word.title()}**"]
            
            if synonyms.get('synonyms'):
                syn_list = ", ".join(synonyms['synonyms'])
                response_parts.append(f"\nSynonyms: {syn_list}")
            
            if synonyms.get('antonyms'):
                ant_list = ", ".join(synonyms['antonyms'])
                response_parts.append(f"\nAntonyms: {ant_list}")
            
            return "\n".join(response_parts)
        else:
            # Simple list format
            syn_list = ", ".join(synonyms)
            return f"**{word.title()}**\nSynonyms: {syn_list}"

