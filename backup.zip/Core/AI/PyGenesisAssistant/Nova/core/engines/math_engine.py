"""
Math Engine - Handles mathematical calculations.
Supports:
- Direct expressions: "2+3", "1*(98+476-27)"
- Natural language: "What is 2 * 3", "ninety minus one"
- Various formats with brackets, spaces, etc.
"""
import re
from typing import Optional

try:
    import sympy as sp
    from sympy import sympify, SympifyError
    SYMPY_AVAILABLE = True
except ImportError:
    SYMPY_AVAILABLE = False
    SympifyError = Exception

from core.engines.base_engine import BaseEngine
from core.workflow import WorkflowContext


class MathEngine(BaseEngine):
    """Handles mathematical calculations with natural language support."""
    
    # Word-to-number mapping
    WORD_TO_NUMBER = {
        "zero": 0, "one": 1, "two": 2, "three": 3, "four": 4, "five": 5,
        "six": 6, "seven": 7, "eight": 8, "nine": 9, "ten": 10,
        "eleven": 11, "twelve": 12, "thirteen": 13, "fourteen": 14, "fifteen": 15,
        "sixteen": 16, "seventeen": 17, "eighteen": 18, "nineteen": 19, "twenty": 20,
        "thirty": 30, "forty": 40, "fifty": 50, "sixty": 60, "seventy": 70,
        "eighty": 80, "ninety": 90, "hundred": 100, "thousand": 1000,
        "million": 1000000, "billion": 1000000000,
    }
    
    # Word-to-operator mapping
    WORD_TO_OPERATOR = {
        "plus": "+", "add": "+", "and": "+",
        "minus": "-", "subtract": "-", "less": "-",
        "times": "*", "multiply": "*", "multiplied": "*",
        "divide": "/", "divided": "/", "over": "/",
        "equals": "=", "is": "=",
    }
    
    def process(self, context: WorkflowContext) -> str:
        """Process math query."""
        if not SYMPY_AVAILABLE:
            return "Math engine requires sympy. Install with: pip install sympy"
        
        text = context.user_input.strip()
        entity = context.entity or text
        
        try:
            # Try to parse and solve
            result = self._solve_math(entity)
            return f"The answer is {result}"
        except Exception as e:
            return f"I couldn't solve that math problem. Error: {str(e)}\n\nTry formats like:\n• '2 + 3'\n• 'What is 2 * 3'\n• '1*(98+476-27)'\n• 'ninety minus one'"
    
    def _solve_math(self, expression: str) -> str:
        """
        Solve a math expression.
        Handles various formats including natural language.
        """
        # Step 1: Convert natural language to math expression
        math_expr = self._natural_language_to_math(expression)
        
        # Step 2: Clean up the expression
        math_expr = self._clean_expression(math_expr)
        
        # Step 3: Parse and evaluate using sympy
        try:
            # Use sympy for safe evaluation
            expr = sympify(math_expr)
            result = float(expr.evalf())
            
            # Format result nicely
            if result.is_integer():
                return str(int(result))
            else:
                # Round to reasonable precision
                return f"{result:.10f}".rstrip('0').rstrip('.')
        except SympifyError as e:
            raise ValueError(f"Invalid math expression: {math_expr}")
        except Exception as e:
            raise ValueError(f"Could not evaluate expression: {str(e)}")
    
    def _natural_language_to_math(self, text: str) -> str:
        """
        Convert natural language math to symbolic expression.
        E.g., "ninety minus one" -> "90 - 1"
        """
        text_lower = text.lower().strip()
        
        # Remove greetings and common prefixes (e.g., "Hi Nova, what is...")
        text_lower = re.sub(r'^(hi|hey|hello|nova|please|can you|could you)[,\s]*', '', text_lower, flags=re.IGNORECASE)
        text_lower = re.sub(r'^(hi|hey|hello|nova|please|can you|could you)[,\s]*', '', text_lower, flags=re.IGNORECASE)  # Run twice for "Hi Nova,"
        text_lower = re.sub(r'^(what is|what\'s|solve|calculate|compute|find|evaluate)\s+', '', text_lower)
        
        # Remove trailing question marks and punctuation first
        text_lower = re.sub(r'[?!.,;:]+$', '', text_lower)
        
        # Check if it's already a math expression (contains numbers and operators)
        if re.search(r'[0-9+\-*/()]', text_lower):
            # Already in math format, just clean it up
            return text_lower
        
        # Convert words to numbers and operators
        words = text_lower.split()
        result = []
        
        i = 0
        while i < len(words):
            word = words[i].strip('.,!?')
            
            # Check for number words
            if word in self.WORD_TO_NUMBER:
                num = self.WORD_TO_NUMBER[word]
                # Check for compound numbers (e.g., "ninety one" -> 91)
                if i + 1 < len(words):
                    next_word = words[i + 1].strip('.,!?')
                    if next_word in self.WORD_TO_NUMBER:
                        next_num = self.WORD_TO_NUMBER[next_word]
                        if next_num < 10:  # Single digit
                            num = num + next_num
                            i += 1
                result.append(str(num))
            
            # Check for operator words
            elif word in self.WORD_TO_OPERATOR:
                result.append(self.WORD_TO_OPERATOR[word])
            
            # Skip common words
            elif word in ["the", "of", "a", "an"]:
                pass
            
            # If we have a number already, this might be part of expression
            elif word.isdigit():
                result.append(word)
            
            i += 1
        
        # Join result
        expr = ' '.join(result)
        
        # If we got something, return it; otherwise return original
        if expr.strip():
            return expr
        return text_lower
    
    def _clean_expression(self, expression: str) -> str:
        """
        Clean up math expression for parsing.
        Removes spaces, handles operators, etc.
        """
        # Remove commas (they cause sympy to interpret as tuples!)
        expression = expression.replace(',', '')
        
        # Remove question marks, exclamation marks, periods, and other punctuation
        expression = re.sub(r'[?!.,;:]+', '', expression)
        
        # Remove any remaining text/words that aren't part of math
        expression = re.sub(r'[a-zA-Z]+', '', expression)
        
        # Remove spaces around operators
        expression = re.sub(r'\s*([+\-*/=])\s*', r'\1', expression)
        
        # Ensure spaces around parentheses for better parsing
        expression = re.sub(r'([0-9])\s*\(', r'\1*(', expression)  # 2(3) -> 2*(3)
        expression = re.sub(r'\)\s*([0-9])', r')*\1', expression)  # (2)3 -> (2)*3
        
        # Remove "=" if present (for "what is" queries)
        expression = expression.replace('=', '').strip()
        
        # Remove any remaining spaces
        expression = expression.replace(' ', '')
        
        # Clean up any double operators or empty parentheses
        expression = re.sub(r'[+\-*/]{2,}', lambda m: m.group(0)[-1], expression)  # Keep last operator
        expression = re.sub(r'\(\)', '', expression)  # Remove empty parens
        
        return expression

