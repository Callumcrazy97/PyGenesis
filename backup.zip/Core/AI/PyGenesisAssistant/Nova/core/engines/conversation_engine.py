"""
Conversation Engine - Handles natural language conversation.
Uses pattern matching, knowledge base, and context awareness for intelligent responses.

Enhanced with UserMode and ResponseStrategy support for more natural conversations.
"""
import json
import os
import re
import random
from datetime import datetime
from typing import Optional, Dict, List
from core.engines.base_engine import BaseEngine
from core.workflow import WorkflowContext
from core.models import UserMode, ResponseStrategy
from core.response_templates import (
    get_greeting_response, get_follow_up_question, 
    format_explanation_response, get_meta_prefix
)


class ConversationEngine(BaseEngine):
    """Handles natural language conversation with pattern matching and knowledge base."""
    
    def __init__(self):
        self.knowledge_base = {}
        self._load_knowledge_base()
        
        # Varied greeting responses (more natural)
        self.greeting_responses = [
            "Hello! I'm Nova, your AI assistant. How can I help you today?",
            "Hey there! What would you like to work on?",
            "Hi! Ready to help with whatever you need.",
            "Hello! I'm here to assist with coding, math, research, or just chatting.",
            "Hey! What's on your mind?",
        ]
        
        # Conversation patterns and responses
        self.patterns: Dict[str, List[str]] = {
            # Greetings - multiple responses for variety
            r'\b(hello|hi|hey|greetings)\b': self.greeting_responses,
            r'\b(good morning|good afternoon|good evening)\b': [
                "Good {time}! I'm Nova. What can I do for you?",
                "Good {time}! How can I help?",
                "{time} greetings! What would you like to work on?",
            ],
            
            # Questions about Nova
            r'\b(who are you|what are you|tell me about yourself)\b': [
                "I'm Nova, your AI coding assistant. I can help with code analysis, math, research, and more!",
                "I'm Nova! I'm built to help you with PyGenesis - from coding to calculations to conversation.",
            ],
            r'\b(what can you do|what do you do|your capabilities)\b': [
                "I can help with:\n• Code queries and analysis\n• Math calculations\n• Research and information\n• Dictionary and thesaurus lookups\n• Project management\n• And more!",
                "I'm your all-in-one assistant! I can:\n• Answer questions\n• Do math\n• Explain concepts\n• Help with code\n• Manage your project resources",
            ],
            
            # Help requests
            r'\b(help|how do i|how can i|what should i)\b': [
                "I'm here to help! You can ask me:\n• Math questions: 'What is 2 * 3?'\n• Research: 'What is Python?'\n• Definitions: 'Define happiness'\n• Code questions: 'How does my code work?'\n• And more!",
            ],
            
            # How are you / Status questions
            r'\b(how are you|how\'?s it going|how do you feel|are you ok)\b': [
                "I'm doing great, thanks for asking! How can I help you today?",
                "I'm good! Ready to assist whenever you need me. What's up?",
                "All systems operational! 😊 What can I do for you?",
            ],
            
            # Thanks
            r'\b(thanks|thank you|appreciate it)\b': [
                "You're welcome! Is there anything else I can help with?",
                "Happy to help! Let me know if you need anything else.",
                "No problem! What else would you like to do?",
            ],
            
            # Goodbye
            r'\b(bye|goodbye|see you|farewell)\b': [
                "Goodbye! Feel free to come back if you need anything.",
                "See you later! Good luck with your project!",
                "Bye! I'll be here whenever you need me.",
            ],
            
            # Positive feedback
            r'\b(great|awesome|excellent|perfect|good job|nice)\b': [
                "Thank you! I'm glad I could help.",
                "Awesome! Is there anything else you'd like to work on?",
                "Great! Happy to hear that worked out.",
            ],
            
            # Confusion
            r'\b(what|huh|i don\'t understand|confused)\b': [
                "I'm here to help! Could you rephrase that? I can help with math, research, code, and more.",
                "Let me try to help differently. What exactly are you trying to do?",
            ],
            
            # User seems frustrated or stuck
            r'\b(stuck|frustrated|not working|doesn\'t work|help me)\b': [
                "I understand that can be frustrating. Let me try to help - what specifically isn't working?",
                "Let's figure this out together. Can you tell me more about what's happening?",
            ],
        }
        
        # Context-aware responses
        self.context_responses = {
            "math_context": [
                "I can help with that calculation!",
                "Let me solve that for you.",
                "Working on that math problem...",
            ],
            "research_context": [
                "Let me look that up for you.",
                "I'll research that topic.",
                "Gathering information...",
            ],
        }
        
        # Meta-response prefixes for different modes
        self.mode_prefixes = {
            UserMode.LEARNING: ["Great question!", "Let me explain...", "Here's how that works..."],
            UserMode.EXPLORING: ["That's an interesting idea!", "We could explore that...", "Here are some possibilities..."],
            UserMode.PLANNING: ["Let me think about the best approach...", "There are a few ways we could do this..."],
            UserMode.VERIFYING: ["Let me confirm...", "Yes, that's right!", "To clarify..."],
            UserMode.CORRECTING: ["I understand, let me adjust...", "Got it, I'll change that...", "No problem, let's try differently..."],
        }
    
    def _load_knowledge_base(self):
        """Load knowledge base from JSON file."""
        try:
            current_dir = os.path.dirname(os.path.abspath(__file__))
            data_dir = os.path.join(os.path.dirname(os.path.dirname(current_dir)), "data")
            kb_path = os.path.join(data_dir, "knowledge_base.json")
            
            if os.path.exists(kb_path):
                with open(kb_path, "r", encoding="utf-8") as f:
                    self.knowledge_base = json.load(f)
        except Exception as e:
            print(f"Error loading knowledge base: {e}")
            self.knowledge_base = {}
    
    def _lookup_knowledge_base(self, query: str) -> Optional[str]:
        """Look up information in the knowledge base."""
        if not self.knowledge_base:
            return None
        
        query_lower = query.lower().strip()
        
        # Search in topics
        topics = self.knowledge_base.get("topics", {})
        for category, items in topics.items():
            for key, data in items.items():
                if key.lower() == query_lower or query_lower in key.lower():
                    # Found a match
                    response_parts = [f"**{key.title()}**: {data.get('definition', '')}"]
                    
                    facts = data.get("facts", [])
                    if facts:
                        response_parts.append("\n\nKey facts:")
                        for fact in facts[:3]:  # Limit to 3 facts
                            response_parts.append(f"• {fact}")
                    
                    examples = data.get("examples", [])
                    if examples:
                        response_parts.append("\n\nExamples:")
                        for example in examples[:2]:  # Limit to 2 examples
                            response_parts.append(f"  {example}")
                    
                    return "\n".join(response_parts)
        
        return None
    
    def process(self, context: WorkflowContext) -> str:
        """Process conversation request."""
        text = context.user_input.lower().strip()
        user_mode = getattr(context, 'user_mode', UserMode.CONVERSATION)
        
        # Check conversation context for references
        if context.conversation_context and context.conversation_context.get('has_reference'):
            return self._handle_context_reference(context, text)
        
        # First, try knowledge base lookup for factual queries
        kb_result = self._lookup_knowledge_base(text)
        if kb_result:
            return self._add_follow_up(kb_result, context)
        
        # Check for time/date questions first (before pattern matching)
        if re.search(r'\b(what day|what date|what time|when is|current date|today|now)\b', text, re.IGNORECASE):
            return self._get_time_date_response(text)
        
        # Check for pattern matches
        for pattern, responses in self.patterns.items():
            if re.search(pattern, text, re.IGNORECASE):
                # Get a random response from the list
                if isinstance(responses, list):
                    response = random.choice(responses)
                else:
                    response = responses
                
                # Handle time-based greetings
                if "{time}" in response:
                    if "morning" in text:
                        response = response.replace("{time}", "morning")
                    elif "afternoon" in text:
                        response = response.replace("{time}", "afternoon")
                    elif "evening" in text:
                        response = response.replace("{time}", "evening")
                    else:
                        response = response.replace("{time}", "day")
                
                return response
        
        # Default conversational response based on user mode
        return self._generate_contextual_response(context)
    
    def _handle_context_reference(self, context: WorkflowContext, text: str) -> str:
        """Handle references to previous conversation context."""
        ref_type = context.conversation_context.get('reference_type')
        prev_result = context.conversation_context.get('previous_result', '')
        
        if ref_type == 'general_reference':
            # User is referring to something Nova said
            if re.search(r'\b(explain|tell me more|elaborate|details)\b', text):
                return f"Sure! Here's more detail:\n\n{prev_result}\n\nWhat specific aspect would you like to know more about?"
            elif re.search(r'\b(correct|wrong|mistake|error|no)\b', text):
                return "I apologize if I made an error. Could you tell me what was incorrect so I can help you better?"
            elif re.search(r'\b(why|how come|reason)\b', text):
                return f"That's a great question! {prev_result[:200]}...\n\nWould you like me to explain the reasoning in more depth?"
            else:
                return f"Regarding what I mentioned: {prev_result[:150]}...\n\nIs there something specific you'd like to explore?"
        
        elif ref_type == 'topic_reference':
            return f"Building on that: {prev_result[:150]}...\n\nWhat else would you like to know?"
        
        elif ref_type == 'follow_up':
            # Handle follow-up questions naturally
            return self._generate_contextual_response(context)
        
        return self._generate_contextual_response(context)
    
    def _add_follow_up(self, response: str, context: WorkflowContext) -> str:
        """Optionally add a follow-up question to make conversation more natural."""
        # Don't always add follow-ups (50% chance)
        if random.random() > 0.5:
            return response
        
        follow_ups = [
            "\n\nIs there anything else you'd like to know about this?",
            "\n\nWould you like me to explain any part in more detail?",
            "\n\nDoes that help? Let me know if you have more questions!",
        ]
        return response + random.choice(follow_ups)
    
    def _get_time_date_response(self, text: str) -> str:
        """Get current time and date."""
        now = datetime.now()
        day_name = now.strftime("%A")
        date_str = now.strftime("%B %d, %Y")
        time_str = now.strftime("%I:%M %p")
        
        if re.search(r'\b(what day|what\'?s the day)\b', text, re.IGNORECASE):
            return f"Today is {day_name}, {date_str}."
        elif re.search(r'\b(what date|what\'?s the date)\b', text, re.IGNORECASE):
            return f"Today's date is {date_str}."
        elif re.search(r'\b(what time|what\'?s the time|current time)\b', text, re.IGNORECASE):
            return f"The current time is {time_str}."
        else:
            return f"Today is {day_name}, {date_str}. The current time is {time_str}."
    
    def _generate_contextual_response(self, context: WorkflowContext) -> str:
        """Generate a contextual response based on the conversation and user mode."""
        user_mode = getattr(context, 'user_mode', UserMode.CONVERSATION)
        
        # Add appropriate prefix based on user mode
        prefix = ""
        if user_mode in self.mode_prefixes:
            prefix = random.choice(self.mode_prefixes[user_mode]) + " "
        
        # Check if there's a previous intent hint
        if context.intent:
            intent_name = context.intent.name.lower()
            if "math" in intent_name:
                responses = [
                    "I can help with math! Try asking something like 'What is 2 * 3?' or 'Solve 1+1'.",
                    "Need some calculations done? Just ask me - I can handle basic and complex math.",
                ]
                return prefix + random.choice(responses)
            elif "research" in intent_name:
                responses = [
                    "I can help with research! What would you like to learn about?",
                    "I'd be happy to explain concepts or look up information. What's the topic?",
                ]
                return prefix + random.choice(responses)
            elif "code" in intent_name:
                responses = [
                    "I can help with code questions! What would you like to know about your project?",
                    "Need help understanding code? Just point me to what you're curious about.",
                ]
                return prefix + random.choice(responses)
        
        # User mode specific responses
        if user_mode == UserMode.EXPLORING:
            return (
                "That's interesting! Let's explore that together.\n\n"
                "What aspect are you most curious about? I can help with:\n"
                "• Technical concepts and explanations\n"
                "• Code implementation ideas\n"
                "• Problem-solving approaches"
            )
        
        if user_mode == UserMode.PLANNING:
            return (
                "Let me help you plan this out.\n\n"
                "Could you tell me more about what you're trying to achieve? "
                "I can help you break it down into steps."
            )
        
        if user_mode == UserMode.LEARNING:
            return (
                "I'd be happy to explain! What would you like to learn about?\n\n"
                "I can help with:\n"
                "• Programming concepts\n"
                "• Math and calculations\n"
                "• General knowledge questions"
            )
        
        # Generic helpful response
        generic_responses = [
            (
                "I'm here to help! You can ask me:\n"
                "• Math: 'What is 2 * 3?'\n"
                "• Research: 'What is Python?'\n"
                "• Definitions: 'Define happiness'\n"
                "• Code: 'How does this work?'\n"
                "• Or just chat!"
            ),
            (
                "What would you like to work on? I can help with:\n"
                "• Calculations and math\n"
                "• Answering questions\n"
                "• Explaining concepts\n"
                "• Working with your project"
            ),
            "I'm ready to help! What's on your mind?",
        ]
        return random.choice(generic_responses)

