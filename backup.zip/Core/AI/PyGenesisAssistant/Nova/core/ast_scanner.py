"""
AST Scanner - Scans Python files using Abstract Syntax Trees.
Extracts classes, functions, imports, and relationships.
"""
import ast
import os
from typing import Dict, List, Optional, Set, Any
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class FunctionInfo:
    """Information about a function."""
    name: str
    line_start: int
    line_end: int
    args: List[str] = field(default_factory=list)
    docstring: Optional[str] = None
    decorators: List[str] = field(default_factory=list)
    is_async: bool = False
    is_method: bool = False
    return_annotation: Optional[str] = None


@dataclass
class ClassInfo:
    """Information about a class."""
    name: str
    line_start: int
    line_end: int
    bases: List[str] = field(default_factory=list)
    docstring: Optional[str] = None
    methods: List[FunctionInfo] = field(default_factory=list)
    decorators: List[str] = field(default_factory=list)


@dataclass
class ImportInfo:
    """Information about imports."""
    module: str
    names: List[str] = field(default_factory=list)
    is_from_import: bool = False
    alias: Optional[str] = None


@dataclass
class FileAnalysis:
    """Complete analysis of a Python file."""
    file_path: str
    classes: List[ClassInfo] = field(default_factory=list)
    functions: List[FunctionInfo] = field(default_factory=list)
    imports: List[ImportInfo] = field(default_factory=list)
    variables: List[str] = field(default_factory=list)
    docstring: Optional[str] = None
    line_count: int = 0
    error: Optional[str] = None


class ASTScanner:
    """Scans Python files using AST parsing."""
    
    def __init__(self):
        self.analyzed_files: Dict[str, FileAnalysis] = {}
    
    def scan_file(self, file_path: str) -> FileAnalysis:
        """
        Scan a single Python file and extract structure.
        
        Args:
            file_path: Path to the Python file
            
        Returns:
            FileAnalysis object with extracted information
        """
        if file_path in self.analyzed_files:
            return self.analyzed_files[file_path]
        
        analysis = FileAnalysis(file_path=file_path)
        
        try:
            if not os.path.exists(file_path):
                analysis.error = f"File not found: {file_path}"
                return analysis
            
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
                analysis.line_count = len(content.splitlines())
            
            # Parse AST
            tree = ast.parse(content, filename=file_path)
            
            # Extract module-level docstring
            if tree.body and isinstance(tree.body[0], ast.Expr) and isinstance(tree.body[0].value, ast.Str):
                analysis.docstring = ast.get_docstring(tree)
            
            # Visit AST nodes
            visitor = ASTVisitor(analysis)
            visitor.visit(tree)
            
            self.analyzed_files[file_path] = analysis
            
        except SyntaxError as e:
            analysis.error = f"Syntax error: {e}"
        except Exception as e:
            analysis.error = f"Error scanning file: {e}"
        
        return analysis
    
    def scan_directory(self, directory: str, recursive: bool = True) -> Dict[str, FileAnalysis]:
        """
        Scan all Python files in a directory.
        
        Args:
            directory: Directory to scan
            recursive: If True, scan subdirectories
            
        Returns:
            Dictionary mapping file paths to FileAnalysis objects
        """
        results = {}
        
        if not os.path.exists(directory):
            return results
        
        pattern = "**/*.py" if recursive else "*.py"
        
        for file_path in Path(directory).glob(pattern):
            if file_path.is_file():
                file_str = str(file_path)
                analysis = self.scan_file(file_str)
                results[file_str] = analysis
        
        return results
    
    def get_project_structure(self, root_dir: str) -> Dict[str, Any]:
        """
        Get complete project structure.
        
        Returns:
            Dictionary with project structure information
        """
        files = self.scan_directory(root_dir)
        
        structure = {
            "root": root_dir,
            "files": {},
            "classes": [],
            "functions": [],
            "imports": {},
            "statistics": {
                "total_files": len(files),
                "total_classes": 0,
                "total_functions": 0,
                "total_lines": 0,
            }
        }
        
        all_classes = []
        all_functions = []
        all_imports = {}
        
        for file_path, analysis in files.items():
            if analysis.error:
                continue
            
            rel_path = os.path.relpath(file_path, root_dir)
            structure["files"][rel_path] = {
                "classes": len(analysis.classes),
                "functions": len(analysis.functions),
                "imports": len(analysis.imports),
                "lines": analysis.line_count,
            }
            
            # Collect all classes
            for cls in analysis.classes:
                cls_info = {
                    "name": cls.name,
                    "file": rel_path,
                    "line": cls.line_start,
                    "bases": cls.bases,
                    "methods": len(cls.methods),
                }
                all_classes.append(cls_info)
            
            # Collect all functions
            for func in analysis.functions:
                func_info = {
                    "name": func.name,
                    "file": rel_path,
                    "line": func.line_start,
                    "args": len(func.args),
                    "is_method": func.is_method,
                }
                all_functions.append(func_info)
            
            # Collect imports
            for imp in analysis.imports:
                if imp.module not in all_imports:
                    all_imports[imp.module] = []
                all_imports[imp.module].append(rel_path)
            
            structure["statistics"]["total_classes"] += len(analysis.classes)
            structure["statistics"]["total_functions"] += len(analysis.functions)
            structure["statistics"]["total_lines"] += analysis.line_count
        
        structure["classes"] = all_classes
        structure["functions"] = all_functions
        structure["imports"] = all_imports
        
        return structure


class ASTVisitor(ast.NodeVisitor):
    """AST visitor to extract code structure."""
    
    def __init__(self, analysis: FileAnalysis):
        self.analysis = analysis
        self.current_class: Optional[ClassInfo] = None
    
    def visit_ClassDef(self, node: ast.ClassDef):
        """Visit class definition."""
        cls_info = ClassInfo(
            name=node.name,
            line_start=node.lineno,
            line_end=node.end_lineno if hasattr(node, 'end_lineno') else node.lineno,
            docstring=ast.get_docstring(node),
        )
        
        # Extract base classes
        for base in node.bases:
            if isinstance(base, ast.Name):
                cls_info.bases.append(base.id)
            elif isinstance(base, ast.Attribute):
                cls_info.bases.append(self._get_attr_name(base))
        
        # Extract decorators
        for decorator in node.decorator_list:
            cls_info.decorators.append(self._get_decorator_name(decorator))
        
        self.current_class = cls_info
        self.analysis.classes.append(cls_info)
        
        # Visit class body
        self.generic_visit(node)
        
        self.current_class = None
    
    def visit_FunctionDef(self, node: ast.FunctionDef):
        """Visit function definition."""
        self._add_function(node, is_async=False)
        self.generic_visit(node)
    
    def visit_AsyncFunctionDef(self, node: ast.AsyncFunctionDef):
        """Visit async function definition."""
        self._add_function(node, is_async=True)
        self.generic_visit(node)
    
    def _add_function(self, node, is_async: bool):
        """Add function to analysis."""
        func_info = FunctionInfo(
            name=node.name,
            line_start=node.lineno,
            line_end=node.end_lineno if hasattr(node, 'end_lineno') else node.lineno,
            docstring=ast.get_docstring(node),
            is_async=is_async,
            is_method=self.current_class is not None,
        )
        
        # Extract arguments
        for arg in node.args.args:
            arg_name = arg.arg
            if arg.annotation:
                arg_name += f": {self._get_annotation_name(arg.annotation)}"
            func_info.args.append(arg_name)
        
        # Extract return annotation
        if node.returns:
            func_info.return_annotation = self._get_annotation_name(node.returns)
        
        # Extract decorators
        for decorator in node.decorator_list:
            func_info.decorators.append(self._get_decorator_name(decorator))
        
        if self.current_class:
            self.current_class.methods.append(func_info)
        else:
            self.analysis.functions.append(func_info)
    
    def visit_Import(self, node: ast.Import):
        """Visit import statement."""
        for alias in node.names:
            import_info = ImportInfo(
                module=alias.name,
                is_from_import=False,
                alias=alias.asname,
            )
            self.analysis.imports.append(import_info)
    
    def visit_ImportFrom(self, node: ast.ImportFrom):
        """Visit from import statement."""
        module = node.module or ""
        for alias in node.names:
            import_info = ImportInfo(
                module=module,
                names=[alias.name],
                is_from_import=True,
                alias=alias.asname,
            )
            self.analysis.imports.append(import_info)
    
    def visit_Assign(self, node: ast.Assign):
        """Visit assignment (for module-level variables)."""
        if self.current_class is None:  # Only module-level
            for target in node.targets:
                if isinstance(target, ast.Name):
                    self.analysis.variables.append(target.id)
        self.generic_visit(node)
    
    def _get_decorator_name(self, node: ast.AST) -> str:
        """Get decorator name."""
        if isinstance(node, ast.Name):
            return node.id
        elif isinstance(node, ast.Attribute):
            return self._get_attr_name(node)
        return str(node)
    
    def _get_attr_name(self, node: ast.Attribute) -> str:
        """Get attribute name."""
        if isinstance(node.value, ast.Name):
            return f"{node.value.id}.{node.attr}"
        elif isinstance(node.value, ast.Attribute):
            return f"{self._get_attr_name(node.value)}.{node.attr}"
        return node.attr
    
    def _get_annotation_name(self, node: ast.AST) -> str:
        """Get annotation name."""
        if isinstance(node, ast.Name):
            return node.id
        elif isinstance(node, ast.Attribute):
            return self._get_attr_name(node)
        elif isinstance(node, ast.Constant):
            return str(node.value)
        return str(node)

