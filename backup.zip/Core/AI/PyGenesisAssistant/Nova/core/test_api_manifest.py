"""
Simple test script to verify API Manifest works correctly.
Run this to test the manifest validation.
"""

from api_manifest import validate_operation, get_validator, API_SURFACE, RESOURCE_TYPES


def test_validation():
    """Test API manifest validation."""
    print("Testing API Surface Manifest...")
    print(f"Components: {list(API_SURFACE.keys())}")
    print(f"Resource Types: {RESOURCE_TYPES}")
    print()
    
    # Test 1: Valid operation
    print("Test 1: Valid create_resource operation")
    operation = {
        "component": "ResourceManager",
        "method": "create_resource",
        "params": {
            "resource_type": "sprites",
            "name": "TestSprite",
            "parent_folder": ""
        }
    }
    is_valid, error = validate_operation(operation, project_open=True)
    print(f"  Result: {'✓ Valid' if is_valid else f'✗ Invalid: {error}'}")
    print()
    
    # Test 2: Invalid component
    print("Test 2: Invalid component")
    operation = {
        "component": "InvalidComponent",
        "method": "create_resource",
        "params": {}
    }
    is_valid, error = validate_operation(operation, project_open=True)
    print(f"  Result: {'✓ Valid' if is_valid else f'✗ Invalid: {error}'}")
    print()
    
    # Test 3: Invalid method
    print("Test 3: Invalid method")
    operation = {
        "component": "ResourceManager",
        "method": "invalid_method",
        "params": {}
    }
    is_valid, error = validate_operation(operation, project_open=True)
    print(f"  Result: {'✓ Valid' if is_valid else f'✗ Invalid: {error}'}")
    print()
    
    # Test 4: Missing project
    print("Test 4: Operation requiring project (no project open)")
    operation = {
        "component": "ResourceManager",
        "method": "create_resource",
        "params": {
            "resource_type": "sprites",
            "name": "TestSprite",
            "parent_folder": ""
        }
    }
    is_valid, error = validate_operation(operation, project_open=False)
    print(f"  Result: {'✓ Valid' if is_valid else f'✗ Invalid: {error}'}")
    print()
    
    # Test 5: Invalid resource type
    print("Test 5: Invalid resource type")
    operation = {
        "component": "ResourceManager",
        "method": "create_resource",
        "params": {
            "resource_type": "invalid_type",
            "name": "TestSprite",
            "parent_folder": ""
        }
    }
    is_valid, error = validate_operation(operation, project_open=True)
    print(f"  Result: {'✓ Valid' if is_valid else f'✗ Invalid: {error}'}")
    print()
    
    # Test 6: List available methods
    print("Test 6: List available methods")
    validator = get_validator()
    methods = validator.list_available_methods("ResourceManager")
    print(f"  ResourceManager methods: {len(methods.get('ResourceManager', []))} methods")
    print(f"  Sample methods: {methods.get('ResourceManager', [])[:5]}")
    print()
    
    print("✓ All tests completed!")


if __name__ == "__main__":
    test_validation()

