"""
Context Analyzer - Analyzes conversation history to understand contextual references.
"""
import re
from typing import List, Dict, Optional, Tuple, Any
from datetime import datetime


class ContextAnalyzer:
    """Analyzes conversation context to understand references to previous messages."""
    
    def __init__(self):
        self.reference_patterns = [
            # Math references - flexible patterns for "divide that by 10", "multiply it by 5", etc.
            (r'\b(divide|multiply|add|subtract)\s+(?:that|this|it|again)?\s*(?:by|to|with)\s*(\d+)\b', 'math_operation'),
            (r'\b(plus|minus|times)\s+(\d+)\b', 'math_operation'),
            (r'\b(again|repeat|same|that)\s+(?:calculation|math|problem)\b', 'math_reference'),
            (r'\bwhat\s+(?:is|was)\s+(?:the\s+)?(?:answer|result|number)\s+(?:again|before)\b', 'math_result'),
            
            # General references
            (r'\b(that|this|it|what you said|your answer|the previous)\b', 'general_reference'),
            (r'\b(about|regarding|concerning)\s+(?:that|this|it|what you said)\b', 'topic_reference'),
            
            # Follow-up questions
            (r'\b(and|also|what about|how about)\s+(.+)', 'follow_up'),
            (r'\b(but|however|actually|wait)\s+(.+)', 'correction'),
        ]
    
    def analyze_context(
        self, 
        current_message: str, 
        conversation_history: List[Dict[str, Any]],
        max_history: int = 10
    ) -> Dict[str, Any]:
        """
        Analyze conversation context to extract references and context.
        
        Args:
            current_message: Current user message
            conversation_history: List of previous messages (most recent first)
            max_history: Maximum number of messages to analyze
            
        Returns:
            Dictionary with context information:
            - has_reference: bool
            - reference_type: str (e.g., 'math_operation', 'general_reference')
            - referenced_message: Optional[Dict] - The message being referenced
            - extracted_value: Optional[Any] - Extracted value (e.g., number for math)
            - enhanced_query: str - Query with context applied
        """
        context = {
            'has_reference': False,
            'reference_type': None,
            'referenced_message': None,
            'extracted_value': None,
            'enhanced_query': current_message,
            'previous_intent': None,
            'previous_result': None,
        }
        
        if not conversation_history:
            return context
        
        # Get recent messages (limit to max_history)
        recent_messages = conversation_history[:max_history]
        
        # Check for reference patterns
        current_lower = current_message.lower()
        
        # Check for math operation references
        math_ref = self._find_math_reference(current_lower, recent_messages)
        if math_ref:
            context.update(math_ref)
            return context
        
        # Check for general references
        general_ref = self._find_general_reference(current_lower, recent_messages)
        if general_ref:
            context.update(general_ref)
            return context
        
        # Check for follow-up questions
        follow_up = self._find_follow_up(current_lower, recent_messages)
        if follow_up:
            context.update(follow_up)
            return context
        
        # Extract previous intent and result for context
        if recent_messages:
            last_nova_message = None
            for msg in recent_messages:
                sender = str(msg.get('sender', '')).upper()
                is_nova = 'NOVA' in sender
                if is_nova:
                    last_nova_message = msg
                    break
            
            if last_nova_message:
                context['previous_result'] = last_nova_message.get('text', '')
                # Try to extract intent from message structure or metadata
                if 'intent' in last_nova_message:
                    context['previous_intent'] = last_nova_message.get('intent')
        
        return context
    
    def _find_math_reference(
        self, 
        current_message: str, 
        recent_messages: List[Dict[str, Any]]
    ) -> Optional[Dict[str, Any]]:
        """Find references to previous math operations."""
        # Look for math operation patterns - more flexible to catch "divide that by 10"
        operation_match = re.search(
            r'\b(divide|multiply|add|subtract)\s+(?:that|this|it|again)?\s*(?:by|to|with)\s*(\d+)\b',
            current_message,
            re.IGNORECASE
        )
        
        # Also try simpler pattern: "plus 10", "minus 5", "times 2"
        if not operation_match:
            operation_match = re.search(
                r'\b(plus|minus|times)\s+(\d+)\b',
                current_message,
                re.IGNORECASE
            )
        
        if operation_match:
            operation = operation_match.group(1).lower()
            number = operation_match.group(2)
            
            # Find last math result in conversation
            # Check various sender formats (Nova, NOVA, Sender.NOVA, etc.)
            for msg in recent_messages:
                sender = str(msg.get('sender', '')).upper()
                is_nova = 'NOVA' in sender or sender == 'NOVA'
                if is_nova:
                    text = msg.get('text', '')
                    # Look for "The answer is X" or just numbers - more flexible pattern
                    number_match = re.search(r'(?:answer is|result is|equals?|=)\s*(\d+(?:\.\d+)?)', text, re.IGNORECASE)
                    if not number_match:
                        # Try to find any number in a math-looking response
                        number_match = re.search(r'^(?:The\s+)?(\d+(?:\.\d+)?)\s*$', text.strip(), re.IGNORECASE)
                    if number_match:
                        previous_result = float(number_match.group(1))
                        
                        # Apply operation
                        if operation in ['divide', 'by']:
                            new_result = previous_result / float(number)
                        elif operation in ['multiply', 'times']:
                            new_result = previous_result * float(number)
                        elif operation in ['add', 'plus']:
                            new_result = previous_result + float(number)
                        elif operation in ['subtract', 'minus']:
                            new_result = previous_result - float(number)
                        else:
                            new_result = previous_result
                        
                        return {
                            'has_reference': True,
                            'reference_type': 'math_operation',
                            'referenced_message': msg,
                            'extracted_value': new_result,
                            'enhanced_query': f"{previous_result} {operation} {number}",
                            'previous_result': str(previous_result),
                        }
        
        # Look for "again" or "repeat" with math context
        if re.search(r'\b(again|repeat|same)\s+(?:calculation|math|problem)\b', current_message, re.IGNORECASE):
            for msg in recent_messages:
                sender = str(msg.get('sender', '')).upper()
                is_nova = 'NOVA' in sender
                if is_nova:
                    text = msg.get('text', '')
                    # Check if it's a math result
                    if re.search(r'(?:answer is|result is|equals?)\s+\d+', text, re.IGNORECASE):
                        # Find the original math query
                        for prev_msg in recent_messages:
                            prev_sender = str(prev_msg.get('sender', '')).upper()
                            is_user = 'USER' in prev_sender or 'ENGINEER' in prev_sender or 'NOVA' not in prev_sender
                            if is_user:
                                prev_text = prev_msg.get('text', '')
                                # Check if it contains math
                                if re.search(r'[0-9]+\s*[+\-*/]\s*[0-9]+', prev_text):
                                    return {
                                        'has_reference': True,
                                        'reference_type': 'math_reference',
                                        'referenced_message': prev_msg,
                                        'enhanced_query': prev_text,
                                        'previous_result': text,
                                    }
        
        return None
    
    def _find_general_reference(
        self, 
        current_message: str, 
        recent_messages: List[Dict[str, Any]]
    ) -> Optional[Dict[str, Any]]:
        """Find general references to previous messages."""
        # Check for reference words
        if not re.search(r'\b(that|this|it|what you said|your answer|the previous|about that)\b', current_message, re.IGNORECASE):
            return None
        
        # Find most recent Nova message
        for msg in recent_messages:
            sender = str(msg.get('sender', '')).upper()
            is_nova = 'NOVA' in sender
            if is_nova:
                return {
                    'has_reference': True,
                    'reference_type': 'general_reference',
                    'referenced_message': msg,
                    'enhanced_query': current_message,  # Keep original, but add context
                    'previous_result': msg.get('text', ''),
                }
        
        return None
    
    def _find_follow_up(
        self, 
        current_message: str, 
        recent_messages: List[Dict[str, Any]]
    ) -> Optional[Dict[str, Any]]:
        """Find follow-up questions."""
        follow_up_match = re.search(r'\b(and|also|what about|how about)\s+(.+)', current_message, re.IGNORECASE)
        if follow_up_match:
            follow_up_text = follow_up_match.group(2)
            return {
                'has_reference': True,
                'reference_type': 'follow_up',
                'enhanced_query': follow_up_text,
                'previous_result': recent_messages[0].get('text', '') if recent_messages else '',
            }
        
        return None
    
    def enhance_query_with_context(
        self, 
        query: str, 
        context: Dict[str, Any]
    ) -> str:
        """
        Enhance query by applying context from previous messages.
        
        Args:
            query: Original user query
            context: Context dictionary from analyze_context
            
        Returns:
            Enhanced query with context applied
        """
        if not context.get('has_reference'):
            return query
        
        ref_type = context.get('reference_type')
        
        if ref_type == 'math_operation' and context.get('extracted_value') is not None:
            # For math operations, return the calculated result directly
            # The enhanced_query already contains the full expression
            return context['enhanced_query']
        
        if ref_type == 'math_reference':
            # Return the original math query
            return context.get('enhanced_query', query)
        
        if ref_type == 'general_reference':
            # For general references, try to extract the topic from previous message
            prev_result = context.get('previous_result', '')
            # Combine with current query
            return f"{query} (referring to: {prev_result[:50]})"
        
        if ref_type == 'follow_up':
            # Return the follow-up part
            return context.get('enhanced_query', query)
        
        return query

