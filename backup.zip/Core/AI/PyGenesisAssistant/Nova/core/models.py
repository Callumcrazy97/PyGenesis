from dataclasses import dataclass, field
from enum import Enum, auto
from datetime import datetime
from typing import Optional, Any, Dict, List


class Sender(Enum):
    USER = auto()
    NOVA = auto()


class UserMode(Enum):
    """
    User's conversational phase - determines HOW Nova should respond.
    This is the key insight from GPT: Cloud AIs feel smart because they
    understand what the user is trying to do, not just what they're saying.
    """
    CONVERSATION = "conversation"   # Chatting / social ("Hi", "thanks", "how are you")
    LEARNING = "learning"           # Wants explanation ("What is X?", "Explain Y")
    EXPLORING = "exploring"         # Brainstorming ("What could we do?", "What if...")
    PLANNING = "planning"           # Designing approach ("How should we...", "Best way to...")
    ACTING = "acting"               # Ready to execute ("Do it", "Yes", "Create X now")
    VERIFYING = "verifying"         # Confirming understanding ("Is this correct?", "Right?")
    CORRECTING = "correcting"       # Fixing mistake ("No, I meant...", "Actually...")


class ResponseStrategy(Enum):
    """
    How Nova should respond - determines response format and behavior.
    This prevents premature execution and makes Nova feel collaborative.
    """
    DIRECT_ANSWER = "direct_answer"         # Simple answer: "The result is 42"
    EXPLANATION = "explanation"              # Teach: "X works by doing Y because Z"
    GUIDED_DIALOGUE = "guided_dialogue"      # Conversation: "Tell me more about..."
    OPTIONS_PRESENTATION = "options"         # "Here are a few approaches..."
    PLAN_PREVIEW = "plan_preview"            # Show plan before executing
    CONFIRMATION_REQUIRED = "confirmation"   # "Should I proceed with..."
    EXECUTE_AND_REPORT = "execute"          # Do it and report results
    CLARIFY_FIRST = "clarify"               # Ask for more info before proceeding


class ConfidenceBand(Enum):
    """Confidence bands for nuanced behavior."""
    HIGH = "high"       # > 0.8: Proceed normally
    MEDIUM = "medium"   # 0.5-0.8: Ask confirming question
    LOW = "low"         # < 0.5: Re-route or clarify


class Intent(Enum):
    """Intent types for Nova workflow routing."""
    CODE_QUERY = "code_query"
    CODE_SEARCH = "code_search"
    PROJECT_MODIFICATION = "project_modification"
    RESOURCE_OPERATION = "resource_operation"
    GRAPH_VISUALIZATION = "graph_visualization"
    GENERAL_CHAT = "general_chat"
    RESEARCH_QUERY = "research_query"
    MATH_QUERY = "math_query"
    DICTIONARY_LOOKUP = "dictionary_lookup"
    THESAURUS_LOOKUP = "thesaurus_lookup"


@dataclass
class IntentResult:
    """Result of intent classification with confidence and fallbacks."""
    primary_intent: Intent
    confidence: float  # 0.0 to 1.0
    fallback_intents: list[Intent] = None
    requires_clarification: bool = False
    clarification_question: Optional[str] = None
    entity: Optional[str] = None
    
    def __post_init__(self):
        if self.fallback_intents is None:
            self.fallback_intents = []


@dataclass
class ClarificationContext:
    """Context for handling clarification requests and responses."""
    original_query: str
    original_intent: Intent
    clarification_question: str
    clarification_options: list[str]  # Options presented to user
    task_id: str  # Task ID to resume after clarification


@dataclass
class ChatMessage:
    sender: Sender
    text: str
    timestamp: datetime
    thinking_content: Optional[str] = None  # Nova's thinking process
    operation_plan: Optional[Any] = None  # OperationPlan for preview
    clarification_context: Optional[ClarificationContext] = None  # If this is a clarification response
    intent: Optional[Intent] = None  # Intent classification for context awareness
    user_mode: Optional[UserMode] = None  # User's conversational phase


@dataclass
class ConversationState:
    """
    Persistent state within a conversation session.
    This is what makes "Do it" and "Explain that" work - 
    Nova remembers what was just discussed.
    """
    # Last exchange
    last_intent: Optional[Intent] = None
    last_entity: Optional[str] = None
    last_user_mode: Optional[UserMode] = None
    last_result: Optional[str] = None
    last_user_query: Optional[str] = None
    
    # Plan tracking (enables "Do it" to resume pending plans)
    pending_plan: Optional[Any] = None  # OperationPlan waiting for confirmation
    plan_context: Optional[str] = None  # What the plan is about
    plan_options: Optional[List[str]] = None  # Options presented to user
    selected_option: Optional[str] = None  # Which option user chose
    
    # Task continuity
    unresolved_task: Optional[str] = None
    awaiting_confirmation: bool = False
    awaiting_clarification: bool = False
    
    # Context memory (last 3 exchanges for pattern detection)
    recent_intents: List[Intent] = field(default_factory=list)
    recent_entities: List[str] = field(default_factory=list)
    recent_user_modes: List[UserMode] = field(default_factory=list)
    
    def update(
        self, 
        intent: Intent, 
        entity: Optional[str], 
        user_mode: UserMode, 
        result: str,
        user_query: str
    ):
        """Update state after each exchange."""
        self.last_intent = intent
        self.last_entity = entity
        self.last_user_mode = user_mode
        self.last_result = result
        self.last_user_query = user_query
        
        # Maintain rolling history (last 3)
        self.recent_intents = [intent] + self.recent_intents[:2]
        self.recent_user_modes = [user_mode] + self.recent_user_modes[:2]
        if entity:
            self.recent_entities = [entity] + self.recent_entities[:2]
    
    def set_pending_plan(self, plan: Any, context: str, options: List[str] = None):
        """Store a plan awaiting user confirmation."""
        self.pending_plan = plan
        self.plan_context = context
        self.plan_options = options
        self.awaiting_confirmation = True
    
    def clear_pending_plan(self):
        """Clear pending plan after execution or cancellation."""
        self.pending_plan = None
        self.plan_context = None
        self.plan_options = None
        self.selected_option = None
        self.awaiting_confirmation = False
    
    def has_pending_plan(self) -> bool:
        """Check if there's a plan waiting for confirmation."""
        return self.pending_plan is not None and self.awaiting_confirmation

