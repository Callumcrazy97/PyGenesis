"""
Code Query Executor - Handles code-related queries using AST analysis.
"""
import re
from typing import Optional

from core.executors.base_executor import BaseExecutor
from core.workflow import WorkflowContext
from core.models import Intent


class CodeQueryExecutor(BaseExecutor):
    """Handles code query requests using AST scanning."""
    
    def execute(self, context: WorkflowContext) -> str:
        """Process code query request."""
        if not context.ast_context:
            return "I couldn't scan your project. Please ensure you're in a Python project directory."
        
        scanner = context.ast_context.get("scanner")
        structure = context.ast_context.get("structure", {})
        
        if not scanner:
            return "Project scanner not available. Please try again."
        
        query_lower = context.user_input.lower()
        
        # Extract entity (class name, function name, etc.)
        entity = context.entity or self._extract_code_entity(context.user_input)
        
        # Handle different types of queries
        if self._is_class_query(query_lower, entity):
            return self._answer_class_query(scanner, entity or self._extract_class_name(query_lower))
        
        elif self._is_function_query(query_lower, entity):
            return self._answer_function_query(scanner, entity or self._extract_function_name(query_lower))
        
        elif self._is_structure_query(query_lower):
            return self._answer_structure_query(structure)
        
        elif self._is_dependency_query(query_lower):
            return self._answer_dependency_query(scanner)
        
        else:
            # Generic code query
            return self._answer_generic_query(structure, context.user_input)
    
    def _extract_code_entity(self, text: str) -> Optional[str]:
        """Extract code entity (class/function name) from query."""
        # Patterns: "how does ClassName work", "explain FunctionName", etc.
        patterns = [
            r'\b(?:class|function|method)\s+(\w+)',
            r'\b(\w+)\s+(?:class|function|method)',
            r'\bhow does\s+(\w+)\s+work',
            r'\bexplain\s+(\w+)',
        ]
        
        for pattern in patterns:
            match = re.search(pattern, text, re.IGNORECASE)
            if match:
                return match.group(1)
        
        return None
    
    def _extract_class_name(self, text: str) -> Optional[str]:
        """Extract class name from query."""
        match = re.search(r'\bclass\s+(\w+)', text, re.IGNORECASE)
        if match:
            return match.group(1)
        
        # Try to find capitalized words (likely class names)
        words = re.findall(r'\b[A-Z][a-z]+\w*\b', text)
        if words:
            return words[0]
        
        return None
    
    def _extract_function_name(self, text: str) -> Optional[str]:
        """Extract function name from query."""
        match = re.search(r'\b(?:function|def|method)\s+(\w+)', text, re.IGNORECASE)
        if match:
            return match.group(1)
        
        return None
    
    def _is_class_query(self, query: str, entity: Optional[str]) -> bool:
        """Check if query is about a class."""
        class_keywords = ['class', 'how does', 'explain']
        return any(kw in query for kw in class_keywords) or (entity and entity[0].isupper())
    
    def _is_function_query(self, query: str, entity: Optional[str]) -> bool:
        """Check if query is about a function."""
        func_keywords = ['function', 'method', 'def']
        return any(kw in query for kw in func_keywords)
    
    def _is_structure_query(self, query: str) -> bool:
        """Check if query is about project structure."""
        structure_keywords = ['structure', 'overview', 'summary', 'what files', 'list']
        return any(kw in query for kw in structure_keywords)
    
    def _is_dependency_query(self, query: str) -> bool:
        """Check if query is about dependencies."""
        dep_keywords = ['dependency', 'import', 'depend', 'uses']
        return any(kw in query for kw in dep_keywords)
    
    def _answer_class_query(self, scanner, class_name: Optional[str]) -> str:
        """Answer query about a class."""
        if not class_name:
            return "I need a class name to analyze. Please specify which class you're asking about."
        
        classes = scanner.find_class(class_name)
        
        if not classes:
            return f"I couldn't find a class named '{class_name}' in your project."
        
        response_parts = [f"Found {len(classes)} class(es) named '{class_name}':\n"]
        
        for cls_info in classes:
            response_parts.append(f"\n**{cls_info['name']}** (in {cls_info['file']}, line {cls_info['line']})")
            
            if cls_info.get('bases'):
                response_parts.append(f"  Inherits from: {', '.join(cls_info['bases'])}")
            
            # Get methods
            methods = scanner.get_class_methods(class_name, cls_info['file'])
            if methods:
                response_parts.append(f"  Methods ({len(methods)}):")
                for method in methods[:5]:  # Limit to 5 methods
                    args_str = ', '.join(method.get('args', []))
                    response_parts.append(f"    - {method['name']}({args_str})")
                if len(methods) > 5:
                    response_parts.append(f"    ... and {len(methods) - 5} more")
        
        return "\n".join(response_parts)
    
    def _answer_function_query(self, scanner, function_name: Optional[str]) -> str:
        """Answer query about a function."""
        if not function_name:
            return "I need a function name to analyze. Please specify which function you're asking about."
        
        functions = scanner.find_function(function_name)
        
        if not functions:
            return f"I couldn't find a function named '{function_name}' in your project."
        
        response_parts = [f"Found {len(functions)} function(s) named '{function_name}':\n"]
        
        for func_info in functions[:5]:  # Limit to 5 results
            location = f"{func_info['file']}:{func_info['line']}"
            func_type = "method" if func_info.get('is_method') else "function"
            response_parts.append(f"\n**{func_info['name']}** ({func_type} in {location})")
            
            args = func_info.get('args', [])
            if args:
                args_str = ', '.join(args)
                response_parts.append(f"  Parameters: {args_str}")
            else:
                response_parts.append(f"  Parameters: (none)")
        
        if len(functions) > 5:
            response_parts.append(f"\n... and {len(functions) - 5} more occurrences")
        
        return "\n".join(response_parts)
    
    def _answer_structure_query(self, structure: dict) -> str:
        """Answer query about project structure."""
        stats = structure.get("statistics", {})
        
        response_parts = [
            "**Project Structure Overview:**\n",
            f"• Total files: {stats.get('total_files', 0)}",
            f"• Total classes: {stats.get('total_classes', 0)}",
            f"• Total functions: {stats.get('total_functions', 0)}",
            f"• Total lines of code: {stats.get('total_lines', 0)}",
        ]
        
        files = structure.get("files", {})
        if files:
            response_parts.append("\n**Files:**")
            for file_path, info in list(files.items())[:10]:  # Limit to 10 files
                response_parts.append(
                    f"  {file_path}: {info.get('classes', 0)} classes, "
                    f"{info.get('functions', 0)} functions, {info.get('lines', 0)} lines"
                )
            if len(files) > 10:
                response_parts.append(f"  ... and {len(files) - 10} more files")
        
        return "\n".join(response_parts)
    
    def _answer_dependency_query(self, scanner) -> str:
        """Answer query about dependencies."""
        deps = scanner.get_dependencies()
        
        if not deps:
            return "No import dependencies found in your project."
        
        response_parts = ["**Project Dependencies:**\n"]
        
        # Group by external vs internal
        external = []
        internal = []
        
        for module, files in deps.items():
            if module.startswith('.') or '/' in module or module in ['os', 'sys', 'json', 'ast']:
                # Likely internal or standard library
                if module not in ['os', 'sys', 'json', 'ast']:
                    internal.append((module, files))
            else:
                external.append((module, files))
        
        if external:
            response_parts.append("**External packages:**")
            for module, files in sorted(external)[:15]:  # Limit to 15
                file_count = len(set(files))
                response_parts.append(f"  • {module} (used in {file_count} file(s))")
        
        if internal:
            response_parts.append("\n**Internal modules:**")
            for module, files in sorted(internal)[:10]:  # Limit to 10
                file_count = len(set(files))
                response_parts.append(f"  • {module} (used in {file_count} file(s))")
        
        return "\n".join(response_parts)
    
    def _answer_generic_query(self, structure: dict, query: str) -> str:
        """Answer generic code query."""
        stats = structure.get("statistics", {})
        
        return (
            f"I analyzed your project. Here's what I found:\n\n"
            f"• **{stats.get('total_files', 0)}** Python files\n"
            f"• **{stats.get('total_classes', 0)}** classes\n"
            f"• **{stats.get('total_functions', 0)}** functions\n"
            f"• **{stats.get('total_lines', 0)}** lines of code\n\n"
            f"You can ask me about specific classes, functions, or the project structure!"
        )

