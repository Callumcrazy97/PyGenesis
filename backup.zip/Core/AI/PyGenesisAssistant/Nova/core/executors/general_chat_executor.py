"""
General Chat Executor - Handles general conversation.
"""
from core.executors.base_executor import BaseExecutor
from core.workflow import WorkflowContext


class GeneralChatExecutor(BaseExecutor):
    """Handles general chat conversations."""
    
    def execute(self, context: WorkflowContext) -> str:
        """Process general chat request."""
        # Simple responses for now
        responses = {
            "hello": "Hello! I'm Nova, your AI assistant. How can I help you today?",
            "hi": "Hi there! What can I help you with?",
            "help": "I can help with code queries, research, math, and more. What do you need?",
        }
        
        text_lower = context.user_input.lower()
        for key, response in responses.items():
            if key in text_lower:
                return response
        
        return "I'm here to help! You can ask me about code, research topics, math problems, or just chat."

