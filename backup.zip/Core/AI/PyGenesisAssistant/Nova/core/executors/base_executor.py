"""
Base Executor - Abstract base class for all executors.
"""
from abc import ABC, abstractmethod

from core.workflow import WorkflowContext


class BaseExecutor(ABC):
    """Base class for all executors."""
    
    @abstractmethod
    def execute(self, context: WorkflowContext) -> str:
        """
        Execute the action for this intent type.
        Returns the response text to display in chat.
        """
        pass

