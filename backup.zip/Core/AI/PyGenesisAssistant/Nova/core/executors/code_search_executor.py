"""
Code Search Executor - Searches for keywords/definitions in code-containing resources.
"""

import re
import os
from typing import Dict, Any, Optional, List, Tuple
from pathlib import Path

from core.executors.base_executor import BaseExecutor
from core.workflow import WorkflowContext


class CodeSearchExecutor(BaseExecutor):
    """Handles code search/grep operations for finding definitions in code-containing resources."""
    
    # Code-containing resource types
    CODE_RESOURCE_TYPES = {
        'object': 'objects',
        'objects': 'objects',
        'script': 'scripts',
        'scripts': 'scripts',
        'shader': 'shaders',
        'shaders': 'shaders',
    }
    
    # Object event types mapping (event_id -> display name)
    EVENT_TYPES = {
        'create': 'Create',
        'room_start': 'Room Start',
        'game_start': 'Game Start',
        'start_step': 'Start Step',
        'step': 'Step',
        'end_step': 'End Step',
        'draw': 'Draw',
        'draw_begin': 'Draw Begin',
        'draw_end': 'Draw End',
        'destroy': 'Destroy',
        'room_end': 'Room End',
        'game_end': 'Game End',
        'alarm_0': 'Alarm 0',
        'alarm_1': 'Alarm 1',
        'alarm_2': 'Alarm 2',
        'alarm_3': 'Alarm 3',
        'alarm_4': 'Alarm 4',
        'alarm_5': 'Alarm 5',
        'alarm_6': 'Alarm 6',
        'alarm_7': 'Alarm 7',
        'alarm_8': 'Alarm 8',
        'alarm_9': 'Alarm 9',
        'user_event_0': 'User Event 0',
        'user_event_1': 'User Event 1',
        'user_event_2': 'User Event 2',
        'user_event_3': 'User Event 3',
        'user_event_4': 'User Event 4',
        'user_event_5': 'User Event 5',
        'user_event_6': 'User Event 6',
        'user_event_7': 'User Event 7',
        'user_event_8': 'User Event 8',
        'user_event_9': 'User Event 9',
        'collision': 'Collision',
        'keyboard': 'Keyboard',
        'mouse': 'Mouse',
        'other': 'Other',
    }
    
    def __init__(self, app=None):
        """Initialize executor with app reference for ResourceManager access."""
        super().__init__()
        self.app = app
    
    def execute(self, context: WorkflowContext) -> str:
        """Process code search request."""
        if not self.app:
            return "Error: Application context not available for code search."
        
        user_input = context.user_input.lower()
        
        # Extract search term and resource type
        search_info = self._extract_search_info(user_input)
        
        if not search_info['search_term']:
            return "I need to know what to search for. Try: 'where is move defined', 'find function X', etc."
        
        try:
            results = self._search_code(search_info)
            
            if not results:
                return f"Could not find '{search_info['search_term']}' in any code-containing resources."
            
            # Format results
            return self._format_results(results, search_info['search_term'])
        except Exception as e:
            return f"Error searching code: {str(e)}"
    
    def _extract_search_info(self, text: str) -> Dict[str, Any]:
        """Extract search term and optional resource type from text."""
        info = {
            'search_term': None,
            'resource_type': None,
            'resource_name': None,
        }
        
        # Extract resource type if specified
        for key, value in self.CODE_RESOURCE_TYPES.items():
            if re.search(rf'\b{key}\b', text, re.IGNORECASE):
                info['resource_type'] = value
                break
        
        # Extract resource name if specified (e.g., "in this object", "in object X")
        name_patterns = [
            r'(?:in|within)\s+(?:this|the)?\s*(?:object|script|shader)\s+["\']?([\w]+)["\']?',
            r'(?:object|script|shader)\s+["\']?([\w]+)["\']?',
        ]
        
        for pattern in name_patterns:
            match = re.search(pattern, text, re.IGNORECASE)
            if match:
                info['resource_name'] = match.group(1)
                break
        
        # Extract search term (what to find)
        # Patterns: "where is X", "find X", "search for X", "where is X defined"
        search_patterns = [
            r'(?:where\s+is|find|search\s+for|locate)\s+["\']?([\w]+)["\']?\s*(?:defined|located)?',
            r'["\']([^"\']+)["\']',  # Quoted search term
        ]
        
        for pattern in search_patterns:
            match = re.search(pattern, text, re.IGNORECASE)
            if match:
                info['search_term'] = match.group(1)
                break
        
        # If no explicit search term found, try to extract any word that looks like a function/variable
        if not info['search_term']:
            # Remove common words and extract potential search terms
            words = re.findall(r'\b[\w_]+\b', text)
            filtered = [w for w in words if w.lower() not in [
                'where', 'is', 'this', 'defined', 'find', 'search', 'for', 'in', 'the', 'a', 'an',
                'object', 'script', 'shader', 'objects', 'scripts', 'shaders'
            ]]
            if filtered:
                info['search_term'] = filtered[0]
        
        return info
    
    def _search_code(self, info: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Search for the term in code-containing resources."""
        results = []
        search_term = info['search_term']
        resource_type = info.get('resource_type')
        resource_name = info.get('resource_name')
        
        # Determine which resource types to search
        if resource_type:
            types_to_search = [resource_type]
        else:
            types_to_search = ['objects', 'scripts', 'shaders']
        
        # Search each resource type
        for rt in types_to_search:
            if rt == 'objects':
                results.extend(self._search_objects(search_term, resource_name))
            elif rt == 'scripts':
                results.extend(self._search_scripts(search_term, resource_name))
            elif rt == 'shaders':
                results.extend(self._search_shaders(search_term, resource_name))
        
        return results
    
    def _search_objects(self, search_term: str, object_name: Optional[str] = None) -> List[Dict[str, Any]]:
        """Search for term in object events."""
        results = []
        
        if not self.app.project_manager.get_project_path():
            return results
        
        project_path = Path(self.app.project_manager.get_project_path())
        objects_folder = project_path / "Resources" / "Objects"
        
        if not objects_folder.exists():
            return results
        
        # Get all objects
        objects = self.app.project_manager.get_resources('objects')
        
        for obj in objects:
            obj_name = obj.get('name', '')
            
            # Filter by object name if specified
            if object_name and obj_name.lower() != object_name.lower():
                continue
            
            parent_folder = obj.get('parent_folder', '')
            events = obj.get('events', {})
            
            # Search each event
            for event_id, event_ref in events.items():
                if not event_ref:
                    continue
                
                # Get event file path
                if parent_folder:
                    event_folder = objects_folder / parent_folder
                else:
                    event_folder = objects_folder
                
                # event_ref is a filename like "ObjectName_Create.pgsl"
                event_file = event_folder / event_ref
                
                if event_file.exists():
                    try:
                        with open(event_file, 'r', encoding='utf-8') as f:
                            lines = f.readlines()
                        
                        # Search for term in lines
                        for line_num, line in enumerate(lines, start=1):
                            if re.search(re.escape(search_term), line, re.IGNORECASE):
                                event_display = self.EVENT_TYPES.get(event_id, event_id.replace('_', ' ').title())
                                results.append({
                                    'resource_type': 'object',
                                    'resource_name': obj_name,
                                    'event_type': event_display,
                                    'event_id': event_id,
                                    'line': line_num,
                                    'content': line.strip(),
                                    'file_path': str(event_file),
                                })
                    except Exception as e:
                        # Skip files that can't be read
                        continue
        
        return results
    
    def _search_scripts(self, search_term: str, script_name: Optional[str] = None) -> List[Dict[str, Any]]:
        """Search for term in script files."""
        results = []
        
        if not self.app.project_manager.get_project_path():
            return results
        
        project_path = Path(self.app.project_manager.get_project_path())
        scripts_folder = project_path / "Resources" / "Scripts"
        
        if not scripts_folder.exists():
            return results
        
        # Get all scripts
        scripts = self.app.project_manager.get_resources('scripts')
        
        for script in scripts:
            script_name_val = script.get('name', '')
            
            # Filter by script name if specified
            if script_name and script_name_val.lower() != script_name.lower():
                continue
            
            parent_folder = script.get('parent_folder', '')
            
            # Get script file path
            if parent_folder:
                script_folder = scripts_folder / parent_folder
            else:
                script_folder = scripts_folder
            
            script_file = script_folder / f"{script_name_val}.script"
            
            if script_file.exists():
                try:
                    with open(script_file, 'r', encoding='utf-8') as f:
                        script_data = f.read()
                    
                    # Load JSON and get code
                    import json
                    script_json = json.loads(script_data)
                    code = script_json.get('code', '')
                    
                    # Search for term in code lines
                    lines = code.split('\n')
                    for line_num, line in enumerate(lines, start=1):
                        if re.search(re.escape(search_term), line, re.IGNORECASE):
                            results.append({
                                'resource_type': 'script',
                                'resource_name': script_name_val,
                                'event_type': None,
                                'event_id': None,
                                'line': line_num,
                                'content': line.strip(),
                                'file_path': str(script_file),
                            })
                except Exception as e:
                    # Skip files that can't be read
                    continue
        
        return results
    
    def _search_shaders(self, search_term: str, shader_name: Optional[str] = None) -> List[Dict[str, Any]]:
        """Search for term in shader files."""
        results = []
        
        if not self.app.project_manager.get_project_path():
            return results
        
        project_path = Path(self.app.project_manager.get_project_path())
        shaders_folder = project_path / "Resources" / "Shaders"
        
        if not shaders_folder.exists():
            return results
        
        # Get all shaders
        shaders = self.app.project_manager.get_resources('shaders')
        
        for shader in shaders:
            shader_name_val = shader.get('name', '')
            
            # Filter by shader name if specified
            if shader_name and shader_name_val.lower() != shader_name.lower():
                continue
            
            parent_folder = shader.get('parent_folder', '')
            
            # Get shader file path
            if parent_folder:
                shader_folder = shaders_folder / parent_folder
            else:
                shader_folder = shaders_folder
            
            shader_file = shader_folder / f"{shader_name_val}.shader"
            
            if shader_file.exists():
                try:
                    with open(shader_file, 'r', encoding='utf-8') as f:
                        shader_data = f.read()
                    
                    # Load JSON and get code sections
                    import json
                    shader_json = json.loads(shader_data)
                    
                    # Search in vertex_code, fragment_code, compute_code
                    code_sections = [
                        ('vertex', shader_json.get('vertex_code', '')),
                        ('fragment', shader_json.get('fragment_code', '')),
                        ('compute', shader_json.get('compute_code', '')),
                    ]
                    
                    for section_name, code in code_sections:
                        if not code:
                            continue
                        
                        lines = code.split('\n')
                        for line_num, line in enumerate(lines, start=1):
                            if re.search(re.escape(search_term), line, re.IGNORECASE):
                                results.append({
                                    'resource_type': 'shader',
                                    'resource_name': shader_name_val,
                                    'event_type': f'{section_name.capitalize()} Shader',
                                    'event_id': section_name,
                                    'line': line_num,
                                    'content': line.strip(),
                                    'file_path': str(shader_file),
                                })
                except Exception as e:
                    # Skip files that can't be read
                    continue
        
        return results
    
    def _format_results(self, results: List[Dict[str, Any]], search_term: str) -> str:
        """Format search results for display."""
        if not results:
            return f"No results found for '{search_term}'."
        
        formatted = [f"Found '{search_term}' in {len(results)} location(s):\n"]
        
        # Group by resource
        by_resource = {}
        for result in results:
            key = (result['resource_type'], result['resource_name'])
            if key not in by_resource:
                by_resource[key] = []
            by_resource[key].append(result)
        
        # Format each resource group
        for (resource_type, resource_name), matches in by_resource.items():
            resource_type_display = resource_type.capitalize()
            formatted.append(f"{resource_type_display}: {resource_name}")
            
            # Group by event/section if applicable
            by_event = {}
            for match in matches:
                event_key = match.get('event_type') or 'Code'
                if event_key not in by_event:
                    by_event[event_key] = []
                by_event[event_key].append(match)
            
            for event_type, event_matches in by_event.items():
                if event_type != 'Code':
                    formatted.append(f"  Event: {event_type}")
                
                for match in event_matches:
                    line_num = match['line']
                    content = match['content']
                    formatted.append(f"    Line {line_num}: {content}")
            
            formatted.append("")  # Blank line between resources
        
        return "\n".join(formatted)

