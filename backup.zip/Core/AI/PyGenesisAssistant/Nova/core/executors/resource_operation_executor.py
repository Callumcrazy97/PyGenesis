"""
Resource Operation Executor - Handles resource and folder operations via natural language.
"""

import re
import os
from typing import Dict, Any, Optional, Tuple
from pathlib import Path

from core.executors.base_executor import BaseExecutor
from core.workflow import WorkflowContext


class ResourceOperationExecutor(BaseExecutor):
    """Handles resource operations (create, edit, rename, delete, move, copy, paste)."""
    
    # Resource type mappings (singular/plural variations)
    RESOURCE_TYPES = {
        'sprite': 'sprites',
        'sprites': 'sprites',
        'object': 'objects',
        'objects': 'objects',
        'room': 'rooms',
        'rooms': 'rooms',
        'sound': 'sounds',
        'sounds': 'sounds',
        'background': 'backgrounds',
        'backgrounds': 'backgrounds',
        'model': 'models',
        'models': 'models',
        'texture': 'textures',
        'textures': 'textures',
        'shader': 'shaders',
        'shaders': 'shaders',
        'script': 'scripts',
        'scripts': 'scripts',
        'particle': 'particles',
        'particles': 'particles',
    }
    
    # Default resource properties
    DEFAULT_PROPERTIES = {
        'sprites': {'width': 32, 'height': 32},
        'objects': {},
        'rooms': {'width': 1024, 'height': 768},
        'sounds': {},
        'backgrounds': {'width': 1024, 'height': 768},
        'models': {},
        'textures': {'width': 256, 'height': 256},
        'shaders': {},
        'scripts': {},
        'particles': {},
    }
    
    def __init__(self, app=None):
        """Initialize executor with app reference for ResourceManager access."""
        super().__init__()
        self.app = app
    
    def execute(self, context: WorkflowContext) -> str:
        """Process resource operation request."""
        if not self.app:
            return "Error: Application context not available for resource operations."
        
        user_input = context.user_input.lower()
        
        # Check if this is a folder operation
        is_folder_op = self._is_folder_operation(user_input)
        
        if is_folder_op:
            # Handle folder operations
            folder_info = self._extract_folder_info(user_input)
            operation = folder_info.get('operation')
            
            try:
                if operation == 'create':
                    return self._create_folder(folder_info)
                elif operation == 'delete':
                    return self._delete_folder(folder_info)
                elif operation == 'rename':
                    return self._rename_folder(folder_info)
                else:
                    return f"Folder operation '{operation}' is not yet implemented."
            except Exception as e:
                return f"Error performing folder {operation} operation: {str(e)}"
        
        # Detect resource operation type
        operation = self._detect_operation(user_input)
        if not operation:
            return f"I'm not sure what resource operation you want. Try: 'create a sprite', 'rename object X to Y', 'delete sprite Z', etc."
        
        # Extract resource information
        resource_info = self._extract_resource_info(user_input, operation)
        
        try:
            if operation == 'create':
                return self._create_resource(resource_info)
            elif operation == 'rename':
                return self._rename_resource(resource_info)
            elif operation == 'delete':
                return self._delete_resource(resource_info)
            elif operation == 'move':
                return self._move_resource(resource_info)
            elif operation == 'copy':
                return self._copy_resource(resource_info)
            elif operation == 'edit':
                return self._edit_resource(resource_info)
            else:
                return f"Operation '{operation}' is not yet implemented."
        except Exception as e:
            return f"Error performing {operation} operation: {str(e)}"
    
    def _detect_operation(self, text: str) -> Optional[str]:
        """Detect what operation the user wants."""
        create_patterns = [r'\bcreate\b', r'\badd\b', r'\bmake\b', r'\bnew\b']
        rename_patterns = [r'\brename\b', r'\bname\b', r'\bcall\b', r'\blabel\b']
        delete_patterns = [r'\bdelete\b', r'\bremove\b', r'\bdel\b']
        move_patterns = [r'\bmove\b', r'\brelocate\b']
        copy_patterns = [r'\bcopy\b', r'\bduplicate\b']
        edit_patterns = [r'\bedit\b', r'\bmodify\b', r'\bchange\b', r'\bupdate\b', r'\bset\b']
        
        if any(re.search(p, text) for p in create_patterns):
            return 'create'
        elif any(re.search(p, text) for p in rename_patterns):
            return 'rename'
        elif any(re.search(p, text) for p in delete_patterns):
            return 'delete'
        elif any(re.search(p, text) for p in move_patterns):
            return 'move'
        elif any(re.search(p, text) for p in copy_patterns):
            return 'copy'
        elif any(re.search(p, text) for p in edit_patterns):
            return 'edit'
        
        return None
    
    def _extract_resource_info(self, text: str, operation: str) -> Dict[str, Any]:
        """Extract resource type, name, folder, and properties from text."""
        info = {
            'resource_type': None,
            'name': None,
            'folder': '',
            'properties': {},
            'old_name': None,
            'new_name': None,
            'target_folder': None,
        }
        
        # Extract resource type (more flexible matching)
        for key, value in self.RESOURCE_TYPES.items():
            # Match whole words only
            pattern = rf'\b{key}\b'
            if re.search(pattern, text, re.IGNORECASE):
                info['resource_type'] = value
                break
        
        # Extract name (quoted strings or after keywords)
        name_patterns = [
            r'["\']([^"\']+)["\']',  # Quoted names
            r'(?:named|called|labeled|name|call|label)\s+["\']?([\w]+)["\']?',  # After "named", "called", etc.
            r'(?:create|add|make|new)\s+(?:a\s+)?\w+\s+["\']?([\w]+)["\']?',  # After "create sprite X"
            r'(?:this|it)\s+(?:sprite|object|room|sound|background|model|texture|shader|script|particle)\s+["\']?([\w]+)["\']?',  # "this sprite X"
        ]
        
        for pattern in name_patterns:
            match = re.search(pattern, text, re.IGNORECASE)
            if match:
                info['name'] = match.group(1)
                break
        
        # Default name if not specified for create operations
        if operation == 'create' and not info['name']:
            resource_type_singular = info['resource_type'].rstrip('s') if info['resource_type'] else 'resource'
            info['name'] = f"New{resource_type_singular.capitalize()}"
        
        # Extract folder path (improved parsing)
        folder_patterns = [
            r'(?:in|within|inside|under)\s+["\']?([\w/\\\s]+)["\']?\s*(?:folder)?',
            r'folder\s+["\']?([\w/\\\s]+)["\']?',
            r'(?:the\s+)?["\']?([\w/\\\s]+)["\']?\s+folder',  # "Example001 folder"
        ]
        
        for pattern in folder_patterns:
            match = re.search(pattern, text, re.IGNORECASE)
            if match:
                folder_path = match.group(1).strip().replace('\\', '/')
                # Remove "Resources/Sprites/" prefix if present
                folder_path = re.sub(r'^resources?[/\\]', '', folder_path, flags=re.IGNORECASE)
                # Remove resource type prefixes
                for rt_key in self.RESOURCE_TYPES.keys():
                    folder_path = re.sub(rf'^{rt_key}s?[/\\]', '', folder_path, flags=re.IGNORECASE)
                info['folder'] = folder_path.strip('/').strip()
                break
        
        # Extract properties (size, dimensions, etc.)
        if info['resource_type'] in ['sprites', 'backgrounds', 'textures']:
            # Extract dimensions: "64x86", "64*86", "64 by 86", "46*97"
            size_match = re.search(r'(\d+)\s*[x*×]\s*(\d+)', text, re.IGNORECASE)
            if size_match:
                info['properties']['width'] = int(size_match.group(1))
                info['properties']['height'] = int(size_match.group(2))
            else:
                # Check for multipliers: "double", "2x", "twice", "2 times"
                multiplier_match = re.search(r'(?:double|2x|twice|2\s*times)\s*(?:the\s*)?(?:default|size)', text, re.IGNORECASE)
                if multiplier_match:
                    defaults = self.DEFAULT_PROPERTIES.get(info['resource_type'], {})
                    info['properties']['width'] = defaults.get('width', 32) * 2
                    info['properties']['height'] = defaults.get('height', 32) * 2
        
        # Extract rename info
        if operation == 'rename':
            # Pattern: "rename X to Y" or "rename X Y" or "name X Y"
            rename_patterns = [
                r'(?:rename|name)\s+["\']?([\w]+)["\']?\s+(?:to\s+)?["\']?([\w]+)["\']?',
                r'(?:rename|name)\s+(?:sprite|object|room|sound|background|model|texture|shader|script|particle)\s+["\']?([\w]+)["\']?\s+(?:to\s+)?["\']?([\w]+)["\']?',
            ]
            for pattern in rename_patterns:
                rename_match = re.search(pattern, text, re.IGNORECASE)
                if rename_match:
                    info['old_name'] = rename_match.group(1)
                    info['new_name'] = rename_match.group(2)
                    break
            
            # If we have a name but no old_name, try to find resource by name
            if info['name'] and not info['old_name']:
                info['new_name'] = info['name']
        
        # Extract move target folder
        if operation == 'move':
            move_patterns = [
                r'move\s+["\']?([\w]+)["\']?\s+(?:to|into)\s+["\']?([\w/\\\s]+)["\']?',
                r'move\s+(?:sprite|object|room|sound|background|model|texture|shader|script|particle)\s+["\']?([\w]+)["\']?\s+(?:to|into)\s+["\']?([\w/\\\s]+)["\']?',
            ]
            for pattern in move_patterns:
                move_match = re.search(pattern, text, re.IGNORECASE)
                if move_match:
                    info['name'] = move_match.group(1)
                    target_folder = move_match.group(2).strip().replace('\\', '/')
                    # Clean up folder path
                    target_folder = re.sub(r'^resources?[/\\]', '', target_folder, flags=re.IGNORECASE)
                    for rt_key in self.RESOURCE_TYPES.keys():
                        target_folder = re.sub(rf'^{rt_key}s?[/\\]', '', target_folder, flags=re.IGNORECASE)
                    info['target_folder'] = target_folder.strip('/').strip()
                    break
        
        # Extract copy info
        if operation == 'copy':
            copy_patterns = [
                r'copy\s+["\']?([\w]+)["\']?\s+(?:to|as|named|called)\s+["\']?([\w]+)["\']?',
                r'copy\s+(?:sprite|object|room|sound|background|model|texture|shader|script|particle)\s+["\']?([\w]+)["\']?\s+(?:to|as|named|called)\s+["\']?([\w]+)["\']?',
                r'copy\s+["\']?([\w]+)["\']?\s+(?:to|into)\s+["\']?([\w/\\\s]+)["\']?',
            ]
            for pattern in copy_patterns:
                copy_match = re.search(pattern, text, re.IGNORECASE)
                if copy_match:
                    info['name'] = copy_match.group(1)
                    # Check if second group is a name or folder
                    second_group = copy_match.group(2).strip()
                    if '/' in second_group or '\\' in second_group:
                        # It's a folder path
                        target_folder = second_group.replace('\\', '/')
                        target_folder = re.sub(r'^resources?[/\\]', '', target_folder, flags=re.IGNORECASE)
                        for rt_key in self.RESOURCE_TYPES.keys():
                            target_folder = re.sub(rf'^{rt_key}s?[/\\]', '', target_folder, flags=re.IGNORECASE)
                        info['target_folder'] = target_folder.strip('/').strip()
                    else:
                        # It's a new name
                        info['new_name'] = second_group
                    break
        
        return info
    
    def _find_resource_by_name(self, name: str, resource_type: Optional[str] = None, folder: str = '') -> Optional[Tuple[str, str]]:
        """Find a resource by name, returning (resource_type, resource_id) or None."""
        if resource_type:
            resources = self.app.project_manager.get_resources(resource_type)
            for resource in resources:
                if resource.get('name') == name:
                    if not folder or resource.get('parent_folder', '') == folder:
                        return (resource_type, resource.get('id'))
        else:
            # Search all resource types
            for rt in self.RESOURCE_TYPES.values():
                resources = self.app.project_manager.get_resources(rt)
                for resource in resources:
                    if resource.get('name') == name:
                        if not folder or resource.get('parent_folder', '') == folder:
                            return (rt, resource.get('id'))
        return None
    
    def _find_folder(self, folder_name: str, resource_type: str) -> Optional[str]:
        """Find a folder path by name within a resource type."""
        resources = self.app.project_manager.get_resources(resource_type)
        
        # Check for exact folder match
        for resource in resources:
            parent_folder = resource.get('parent_folder', '')
            if parent_folder == folder_name:
                return folder_name
            
            # Check nested folders
            if '/' in parent_folder or '\\' in parent_folder:
                parts = parent_folder.replace('\\', '/').split('/')
                if folder_name in parts:
                    # Return the path up to and including the folder
                    idx = parts.index(folder_name)
                    return '/'.join(parts[:idx+1])
        
        # Check if folder_name contains path separators (it's already a path)
        if '/' in folder_name or '\\' in folder_name:
            return folder_name.replace('\\', '/')
        
        return folder_name
    
    def _create_resource(self, info: Dict[str, Any]) -> str:
        """Create a new resource."""
        if not info['resource_type']:
            return "I need to know what type of resource to create. Try: 'create a sprite', 'create an object', etc."
        
        resource_type = info['resource_type']
        name = info['name'] or f"New{resource_type.rstrip('s').capitalize()}"
        folder = info['folder']
        
        # Get ResourceManager
        resource_manager = self.app.resource_manager
        
        # Check if project is open
        if not self.app.project_manager.get_project_path():
            return "No project is currently open. Please open a project first."
        
        # Find folder if specified (handles nested folders)
        if folder:
            found_folder = self._find_folder(folder, resource_type)
            if found_folder:
                folder = found_folder
        
        # Create resource with properties merged into default data
        resource_data = resource_manager.create_resource(resource_type, name, folder)
        
        if not resource_data:
            return f"Failed to create {resource_type} '{name}'. It may already exist or there was an error."
        
        # Update properties if specified (after creation to override defaults)
        if info['properties']:
            updates = {}
            for key, value in info['properties'].items():
                if key in resource_data:
                    updates[key] = value
            
            if updates:
                resource_manager.update_resource(resource_type, resource_data['id'], updates)
                # Reload resource data to get updated values
                resource_data = resource_manager.load_resource(resource_type, resource_data['id'])
        
        folder_str = f" in folder '{folder}'" if folder else ""
        props_str = ""
        if info['properties']:
            props_list = [f"{k}={v}" for k, v in info['properties'].items()]
            props_str = f" with properties: {', '.join(props_list)}"
        
        return f"Created {resource_type} '{name}'{folder_str}{props_str} successfully!"
    
    def _rename_resource(self, info: Dict[str, Any]) -> str:
        """Rename a resource."""
        # Determine old_name and new_name
        old_name = info.get('old_name') or info.get('name')
        new_name = info.get('new_name')
        
        if not old_name or not new_name:
            return "I need both the old name and new name to rename. Try: 'rename sprite X to Y' or 'rename X Y'"
        
        # Find resource by name
        result = self._find_resource_by_name(old_name, info.get('resource_type'), info.get('folder', ''))
        
        if not result:
            return f"Could not find {info.get('resource_type', 'resource')} named '{old_name}'."
        
        resource_type, resource_id = result
        
        success = self.app.resource_manager.rename_resource(resource_type, resource_id, new_name)
        
        if success:
            return f"Renamed {resource_type} '{old_name}' to '{new_name}' successfully!"
        else:
            return f"Failed to rename {resource_type} '{old_name}'. The new name may already exist."
    
    def _delete_resource(self, info: Dict[str, Any]) -> str:
        """Delete a resource."""
        if not info['name']:
            return "I need the name of the resource to delete. Try: 'delete sprite X'"
        
        # Find resource by name
        result = self._find_resource_by_name(info['name'], info.get('resource_type'), info.get('folder', ''))
        
        if not result:
            return f"Could not find {info.get('resource_type', 'resource')} named '{info['name']}'."
        
        resource_type, resource_id = result
        
        success = self.app.resource_manager.delete_resource(resource_type, resource_id)
        
        if success:
            return f"Deleted {resource_type} '{info['name']}' successfully!"
        else:
            return f"Failed to delete {resource_type} '{info['name']}'."
    
    def _move_resource(self, info: Dict[str, Any]) -> str:
        """Move a resource to a different folder."""
        if not info['name'] or not info['target_folder']:
            return "I need the resource name and target folder. Try: 'move sprite X to folder Y'"
        
        # Find resource
        result = self._find_resource_by_name(info['name'], info.get('resource_type'))
        
        if not result:
            return f"Could not find {info.get('resource_type', 'resource')} named '{info['name']}'."
        
        resource_type, resource_id = result
        
        # Find target folder if it's a name (not a path)
        target_folder = info['target_folder']
        if '/' not in target_folder and '\\' not in target_folder:
            found_folder = self._find_folder(target_folder, resource_type)
            if found_folder:
                target_folder = found_folder
        
        # Update parent_folder
        success = self.app.resource_manager.update_resource(
            resource_type, resource_id, {'parent_folder': target_folder}
        )
        
        if success:
            return f"Moved {resource_type} '{info['name']}' to folder '{target_folder}' successfully!"
        else:
            return f"Failed to move {resource_type} '{info['name']}'."
    
    def _copy_resource(self, info: Dict[str, Any]) -> str:
        """Copy a resource."""
        if not info['name']:
            return "I need the name of the resource to copy. Try: 'copy sprite X'"
        
        # Find resource
        result = self._find_resource_by_name(info['name'], info.get('resource_type'), info.get('folder', ''))
        
        if not result:
            return f"Could not find {info.get('resource_type', 'resource')} named '{info['name']}'."
        
        resource_type, resource_id = result
        
        # Load resource data
        resource_data = self.app.resource_manager.load_resource(resource_type, resource_id)
        if not resource_data:
            return f"Failed to load {resource_type} '{info['name']}'."
        
        # Generate new name
        new_name = info.get('new_name') or f"{info['name']}_copy"
        
        # Check if new name already exists
        existing_resources = self.app.project_manager.get_resources(resource_type)
        for resource in existing_resources:
            if resource.get('name') == new_name:
                # Try to find a unique name
                counter = 1
                while any(r.get('name') == f"{new_name}_{counter}" for r in existing_resources):
                    counter += 1
                new_name = f"{new_name}_{counter}"
                break
        
        # Create new resource with copied data
        target_folder = info.get('target_folder') or info.get('folder', '')
        if target_folder:
            found_folder = self._find_folder(target_folder, resource_type)
            if found_folder:
                target_folder = found_folder
        
        # Create new resource
        new_resource_data = self.app.resource_manager.create_resource(resource_type, new_name, target_folder)
        
        if not new_resource_data:
            return f"Failed to create copy of {resource_type} '{info['name']}'."
        
        # Copy properties (excluding id, name, created, modified)
        updates = {}
        for key, value in resource_data.items():
            if key not in ['id', 'name', 'created', 'modified', 'type']:
                updates[key] = value
        
        if updates:
            self.app.resource_manager.update_resource(resource_type, new_resource_data['id'], updates)
        
        folder_str = f" in folder '{target_folder}'" if target_folder else ""
        return f"Copied {resource_type} '{info['name']}' to '{new_name}'{folder_str} successfully!"
    
    def _edit_resource(self, info: Dict[str, Any]) -> str:
        """Edit resource properties."""
        if not info['name']:
            return "I need the name of the resource to edit. Try: 'edit sprite X'"
        
        # Find resource
        result = self._find_resource_by_name(info['name'], info.get('resource_type'), info.get('folder', ''))
        
        if not result:
            return f"Could not find {info.get('resource_type', 'resource')} named '{info['name']}'."
        
        resource_type, resource_id = result
        
        if not info['properties']:
            return f"Found {resource_type} '{info['name']}'. What property would you like to change? (e.g., 'set width to 64')"
        
        success = self.app.resource_manager.update_resource(resource_type, resource_id, info['properties'])
        
        if success:
            props_str = ', '.join(f"{k}={v}" for k, v in info['properties'].items())
            return f"Updated {resource_type} '{info['name']}' with properties: {props_str}"
        else:
            return f"Failed to update {resource_type} '{info['name']}'."
    
    def _is_folder_operation(self, text: str) -> bool:
        """Check if this is a folder operation."""
        folder_patterns = [
            r'\bfolder\b',
            r'\bcreate\s+folder\b',
            r'\bdelete\s+folder\b',
            r'\brename\s+folder\b',
        ]
        return any(re.search(p, text, re.IGNORECASE) for p in folder_patterns)
    
    def _extract_folder_info(self, text: str) -> Dict[str, Any]:
        """Extract folder operation information."""
        info = {
            'operation': None,
            'folder_name': None,
            'resource_type': None,
            'parent_folder': '',
            'old_name': None,
            'new_name': None,
        }
        
        # Detect operation
        if re.search(r'\bcreate\s+folder\b', text, re.IGNORECASE):
            info['operation'] = 'create'
        elif re.search(r'\bdelete\s+folder\b', text, re.IGNORECASE):
            info['operation'] = 'delete'
        elif re.search(r'\brename\s+folder\b', text, re.IGNORECASE):
            info['operation'] = 'rename'
        
        # Extract resource type
        for key, value in self.RESOURCE_TYPES.items():
            if re.search(rf'\b{key}\b', text, re.IGNORECASE):
                info['resource_type'] = value
                break
        
        # Extract folder name
        name_patterns = [
            r'["\']([^"\']+)["\']',
            r'(?:folder|named|called)\s+["\']?([\w]+)["\']?',
            r'(?:create|delete|rename)\s+folder\s+["\']?([\w]+)["\']?',
        ]
        
        for pattern in name_patterns:
            match = re.search(pattern, text, re.IGNORECASE)
            if match:
                info['folder_name'] = match.group(1)
                break
        
        # Extract parent folder
        parent_match = re.search(r'(?:in|within|inside|under)\s+["\']?([\w/\\\s]+)["\']?\s*(?:folder)?', text, re.IGNORECASE)
        if parent_match:
            parent_path = parent_match.group(1).strip().replace('\\', '/')
            parent_path = re.sub(r'^resources?[/\\]', '', parent_path, flags=re.IGNORECASE)
            for rt_key in self.RESOURCE_TYPES.keys():
                parent_path = re.sub(rf'^{rt_key}s?[/\\]', '', parent_path, flags=re.IGNORECASE)
            info['parent_folder'] = parent_path.strip('/').strip()
        
        # Extract rename info
        if info['operation'] == 'rename':
            rename_match = re.search(r'rename\s+folder\s+["\']?([\w]+)["\']?\s+(?:to\s+)?["\']?([\w]+)["\']?', text, re.IGNORECASE)
            if rename_match:
                info['old_name'] = rename_match.group(1)
                info['new_name'] = rename_match.group(2)
        
        return info
    
    def _create_folder(self, info: Dict[str, Any]) -> str:
        """Create a folder."""
        if not info['resource_type']:
            return "I need to know what resource type folder to create. Try: 'create folder in Sprites'"
        
        if not info['folder_name']:
            return "I need a name for the folder. Try: 'create folder Example001 in Sprites'"
        
        resource_type = info['resource_type']
        folder_name = info['folder_name']
        parent_folder = info.get('parent_folder', '')
        
        # Check if project is open
        if not self.app.project_manager.get_project_path():
            return "No project is currently open. Please open a project first."
        
        # Build folder path
        project_path = self.app.project_manager.get_project_path()
        resource_folder = self.app.resource_manager.resource_types[resource_type]["folder"]
        folder_path = os.path.join(project_path, "Resources", resource_folder)
        
        if parent_folder:
            folder_path = os.path.join(folder_path, parent_folder)
        
        folder_path = os.path.join(folder_path, folder_name)
        
        # Check if folder exists
        if os.path.exists(folder_path):
            return f"Folder '{folder_name}' already exists in {resource_type}."
        
        # Create folder
        try:
            os.makedirs(folder_path, exist_ok=True)
            parent_str = f" in '{parent_folder}'" if parent_folder else ""
            return f"Created folder '{folder_name}' in {resource_type}{parent_str} successfully!"
        except Exception as e:
            return f"Failed to create folder: {str(e)}"
    
    def _delete_folder(self, info: Dict[str, Any]) -> str:
        """Delete a folder."""
        if not info['resource_type']:
            return "I need to know what resource type folder to delete. Try: 'delete folder X in Sprites'"
        
        if not info['folder_name']:
            return "I need the name of the folder to delete. Try: 'delete folder Example001 in Sprites'"
        
        resource_type = info['resource_type']
        folder_name = info['folder_name']
        parent_folder = info.get('parent_folder', '')
        
        # Build folder path
        project_path = self.app.project_manager.get_project_path()
        resource_folder = self.app.resource_manager.resource_types[resource_type]["folder"]
        folder_path = os.path.join(project_path, "Resources", resource_folder)
        
        if parent_folder:
            folder_path = os.path.join(folder_path, parent_folder)
        
        folder_path = os.path.join(folder_path, folder_name)
        
        # Check if folder exists
        if not os.path.exists(folder_path):
            return f"Folder '{folder_name}' does not exist in {resource_type}."
        
        # Check if folder is empty
        try:
            if os.listdir(folder_path):
                return f"Folder '{folder_name}' is not empty. Please delete all resources in it first."
        except Exception:
            pass
        
        # Delete folder
        try:
            import shutil
            shutil.rmtree(folder_path)
            return f"Deleted folder '{folder_name}' from {resource_type} successfully!"
        except Exception as e:
            return f"Failed to delete folder: {str(e)}"
    
    def _rename_folder(self, info: Dict[str, Any]) -> str:
        """Rename a folder."""
        if not info['resource_type']:
            return "I need to know what resource type folder to rename. Try: 'rename folder X to Y in Sprites'"
        
        if not info['old_name'] or not info['new_name']:
            return "I need both the old name and new name. Try: 'rename folder X to Y in Sprites'"
        
        resource_type = info['resource_type']
        old_name = info['old_name']
        new_name = info['new_name']
        parent_folder = info.get('parent_folder', '')
        
        # Build folder paths
        project_path = self.app.project_manager.get_project_path()
        resource_folder = self.app.resource_manager.resource_types[resource_type]["folder"]
        old_folder_path = os.path.join(project_path, "Resources", resource_folder)
        new_folder_path = os.path.join(project_path, "Resources", resource_folder)
        
        if parent_folder:
            old_folder_path = os.path.join(old_folder_path, parent_folder)
            new_folder_path = os.path.join(new_folder_path, parent_folder)
        
        old_folder_path = os.path.join(old_folder_path, old_name)
        new_folder_path = os.path.join(new_folder_path, new_name)
        
        # Check if old folder exists
        if not os.path.exists(old_folder_path):
            return f"Folder '{old_name}' does not exist in {resource_type}."
        
        # Check if new folder exists
        if os.path.exists(new_folder_path):
            return f"Folder '{new_name}' already exists in {resource_type}."
        
        # Rename folder and update all resources in it
        try:
            import shutil
            shutil.move(old_folder_path, new_folder_path)
            
            # Update all resources in the folder to have new parent_folder
            resources = self.app.project_manager.get_resources(resource_type)
            updated_count = 0
            
            for resource in resources:
                resource_parent = resource.get('parent_folder', '')
                # Check if resource is in the renamed folder
                if parent_folder:
                    expected_path = f"{parent_folder}/{old_name}"
                else:
                    expected_path = old_name
                
                if resource_parent == expected_path or resource_parent.startswith(f"{expected_path}/"):
                    # Update parent_folder
                    new_parent = resource_parent.replace(expected_path, new_name, 1)
                    resource_id = resource.get('id')
                    self.app.resource_manager.update_resource(resource_type, resource_id, {'parent_folder': new_parent})
                    updated_count += 1
            
            return f"Renamed folder '{old_name}' to '{new_name}' in {resource_type} successfully! Updated {updated_count} resources."
        except Exception as e:
            return f"Failed to rename folder: {str(e)}"

