from dataclasses import dataclass, asdict
from typing import Literal
import json
import os
from pathlib import Path


@dataclass
class AppSettings:
    """Centralized settings with Nova-style naming."""

    DefaultTheme: str = "slate"
    Mode: Literal["Local", "Cloud"] = "Local"
    EnableEnterToSend: bool = True
    InputExpandedHeight: int = 140
    InputDefaultHeight: int = 72
    BubbleCornerRadius: int = 12
    MaxChatHistory: int = 500
    ShowThinking: bool = False  # Show intent and confidence in header (read from PyGenesis preferences)
    TrainOnChats: bool = True  # Use conversations for training (read from PyGenesis preferences)
    
    # Path to settings JSON file
    SETTINGS_JSON_PATH = Path(__file__).parent / "settings.json"
    
    def save(self):
        """Save settings to JSON file."""
        try:
            settings_dict = asdict(self)
            # Remove the path from the dict before saving
            settings_dict.pop('SETTINGS_JSON_PATH', None)
            with open(self.SETTINGS_JSON_PATH, 'w', encoding='utf-8') as f:
                json.dump(settings_dict, f, indent=2)
        except (IOError, OSError) as e:
            print(f"Error saving Nova settings: {e}")
    
    @classmethod
    def load(cls):
        """Load settings from JSON file or create with defaults."""
        instance = cls()
        
        # Try to load from PyGenesis preferences first
        try:
            # Try to get PyGenesis app settings if available
            import sys
            if 'app' in sys.modules or any('app' in str(m) for m in sys.modules.values()):
                # Try to find app instance
                for module_name, module in sys.modules.items():
                    if hasattr(module, 'app') and hasattr(module.app, 'settings'):
                        app_settings = module.app.settings
                        # Load from PyGenesis preferences
                        instance.ShowThinking = app_settings.get("AI_Show_Nova_Thinking", False)
                        instance.TrainOnChats = app_settings.get("AI_Train_Nova_On_Chats", True)
                        break
        except Exception:
            pass  # Fallback to local settings
        
        # Load local settings (for standalone mode)
        if cls.SETTINGS_JSON_PATH.exists():
            try:
                with open(cls.SETTINGS_JSON_PATH, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                # Merge with local settings (local overrides PyGenesis for standalone)
                for key, value in data.items():
                    if hasattr(instance, key):
                        setattr(instance, key, value)
            except (json.JSONDecodeError, IOError, TypeError) as e:
                print(f"Error loading Nova settings: {e}, using defaults")
        
        return instance


SETTINGS = AppSettings.load()

