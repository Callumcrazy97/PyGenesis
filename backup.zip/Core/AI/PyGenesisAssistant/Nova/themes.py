import json
import os
from pathlib import Path
from typing import Dict

from settings import SETTINGS

ThemePalette = Dict[str, str]

# Default themes (cannot be deleted)
DEFAULT_THEMES = {
    "slate", "cyberpunk", "dark", "light", "ocean", "forest", 
    "sunset", "monochrome", "high_contrast", "purple_dream"
}

# Path to themes JSON file
THEMES_JSON_PATH = Path(__file__).parent / "themes.json"


def _load_themes() -> Dict[str, ThemePalette]:
    """Load themes from JSON file."""
    if THEMES_JSON_PATH.exists():
        try:
            with open(THEMES_JSON_PATH, 'r', encoding='utf-8') as f:
                return json.load(f)
        except (json.JSONDecodeError, IOError) as e:
            print(f"Error loading themes.json: {e}")
            return _get_default_themes()
    else:
        # Create default themes.json if it doesn't exist
        themes = _get_default_themes()
        _save_themes(themes)
        return themes


def _get_default_themes() -> Dict[str, ThemePalette]:
    """Get default themes as fallback."""
    return {
        "slate": {
            "bg": "#0f172a",
            "panel": "#111827",
            "panelBorder": "#1e293b",
            "inputBg": "#1e293b",
            "accent": "#3b82f6",
            "accentAlt": "#2563eb",
            "text": "#e2e8f0",
            "muted": "#94a3b8",
            "bubbleUser": "#2563eb",
            "bubbleUserText": "#ffffff",
            "bubbleNova": "#1e293b",
            "bubbleNovaText": "#e2e8f0",
            "bubbleNovaAccentLocal": "#f59e0b",
            "bubbleNovaAccentCloud": "#3b82f6",
            "bubbleNovaBorder": "#334155",
            "metaUser": "#60a5fa",
            "metaNova": "#64748b",
            "shadow": "#0b1220",
        },
        "cyberpunk": {
            "bg": "#0b0f1a",
            "panel": "#0e1424",
            "panelBorder": "#1a2237",
            "inputBg": "#1a2237",
            "accent": "#d946ef",
            "accentAlt": "#a855f7",
            "text": "#e5e7eb",
            "muted": "#c084fc",
            "bubbleUser": "#a855f7",
            "bubbleUserText": "#ffffff",
            "bubbleNova": "#1a2237",
            "bubbleNovaText": "#e5e7eb",
            "bubbleNovaAccentLocal": "#f59e0b",
            "bubbleNovaAccentCloud": "#d946ef",
            "bubbleNovaBorder": "#2d3748",
            "metaUser": "#c084fc",
            "metaNova": "#9ca3af",
            "shadow": "#060912",
        },
    }


def _save_themes(themes: Dict[str, ThemePalette]):
    """Save themes to JSON file."""
    try:
        with open(THEMES_JSON_PATH, 'w', encoding='utf-8') as f:
            json.dump(themes, f, indent=2, ensure_ascii=False)
    except IOError as e:
        print(f"Error saving themes.json: {e}")


# Load themes from JSON
THEMES: Dict[str, ThemePalette] = _load_themes()


def current_palette() -> ThemePalette:
    return THEMES.get(SETTINGS.DefaultTheme, THEMES["slate"])


def add_custom_theme(name: str, palette: ThemePalette):
    """Add a custom theme."""
    THEMES[name] = palette.copy()
    _save_themes(THEMES)


def remove_custom_theme(name: str):
    """Remove a custom theme (cannot remove default themes)."""
    if name in DEFAULT_THEMES:
        raise ValueError(f"Cannot delete default theme: {name}")
    if name in THEMES:
        del THEMES[name]
        _save_themes(THEMES)
        # If deleted theme was selected, switch to default
        if SETTINGS.DefaultTheme == name:
            SETTINGS.DefaultTheme = "slate"


def rename_theme(old_name: str, new_name: str):
    """Rename a theme."""
    if old_name in DEFAULT_THEMES:
        raise ValueError(f"Cannot rename default theme: {old_name}")
    if old_name not in THEMES:
        raise ValueError(f"Theme '{old_name}' does not exist")
    if new_name in THEMES:
        raise ValueError(f"Theme '{new_name}' already exists")
    
    THEMES[new_name] = THEMES.pop(old_name)
    _save_themes(THEMES)
    # Update selected theme if it was renamed
    if SETTINGS.DefaultTheme == old_name:
        SETTINGS.DefaultTheme = new_name


def update_theme(name: str, palette: ThemePalette):
    """Update an existing theme (used when editing theme properties)."""
    if name in THEMES:
        THEMES[name] = palette.copy()
        _save_themes(THEMES)

