"""
Nova AI Assistant - Integrated into PyGenesis
This file is kept for reference but Nova should be opened through PyGenesis's AI button.
Use NovaWidget.py instead for integration.
"""

# This file is no longer used as a standalone entry point.
# Nova is now integrated into PyGenesis via NovaWidget.py
# To run Nova standalone for testing, use: python -m Core.AI.PyGenesisAssistant.Nova.ui.main_window

if __name__ == "__main__":
    import sys
    from PySide6.QtWidgets import QApplication
    from ui.main_window import MainWindow
    
    print("Note: Nova is now integrated into PyGenesis.")
    print("Use the AI button in PyGenesis to open Nova.")
    print("Running standalone for testing purposes only...")
    
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec())

