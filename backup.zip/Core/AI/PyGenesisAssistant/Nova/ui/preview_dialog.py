"""
Preview Dialog - Shows operation plan preview with file diffs.
"""

from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QScrollArea, QWidget, QTextEdit, QGroupBox, QDialogButtonBox
)
from PySide6.QtCore import Qt
from PySide6.QtGui import QTextCharFormat, QColor, QSyntaxHighlighter
from typing import Optional
import difflib

from core.operation_planner import OperationPlan
from ui.preview_widget import DiffHighlighter, FilePreviewWidget


class PreviewDialog(QDialog):
    """Dialog showing operation plan preview with file changes."""
    
    def __init__(self, operation_plan: OperationPlan, parent=None):
        super().__init__(parent)
        self.operation_plan = operation_plan
        self.setWindowTitle("Operation Preview")
        self.setModal(True)
        self.resize(900, 700)
        self.setup_ui()
    
    def setup_ui(self):
        """Setup the preview dialog UI."""
        layout = QVBoxLayout(self)
        layout.setContentsMargins(12, 12, 12, 12)
        layout.setSpacing(12)
        
        # Header
        header = QLabel("📋 Operation Plan Preview")
        header.setStyleSheet("font-weight: bold; font-size: 14pt; padding: 4px;")
        layout.addWidget(header)
        
        # Scroll area for content
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QScrollArea.NoFrame)
        
        content_widget = QWidget()
        content_layout = QVBoxLayout(content_widget)
        content_layout.setContentsMargins(8, 8, 8, 8)
        content_layout.setSpacing(12)
        
        # Summary
        summary_group = QGroupBox("Summary")
        summary_layout = QVBoxLayout(summary_group)
        
        summary_text = QLabel(
            f"<b>Rationale:</b> {self.operation_plan.rationale}<br/><br/>"
            f"<b>Risk Level:</b> <span style='color: {'#ff6b6b' if self.operation_plan.risk_level.value in ['High', 'Critical'] else '#4ecdc4' if self.operation_plan.risk_level.value == 'Low' else '#ffd93d'};'>{self.operation_plan.risk_level.value}</span><br/><br/>"
            f"<b>Expected Outcome:</b> {self.operation_plan.expected_outcome}<br/><br/>"
            f"<b>Affected Systems:</b> {', '.join(self.operation_plan.affected_systems) if self.operation_plan.affected_systems else 'None'}"
        )
        summary_text.setWordWrap(True)
        summary_layout.addWidget(summary_text)
        
        content_layout.addWidget(summary_group)
        
        # Operations list
        if self.operation_plan.operations:
            ops_group = QGroupBox(f"Operations ({len(self.operation_plan.operations)})")
            ops_layout = QVBoxLayout(ops_group)
            
            for i, op in enumerate(self.operation_plan.operations, 1):
                op_label = QLabel(
                    f"<b>{i}. {op.component}.{op.method}</b><br/>"
                    f"<span style='color: #aaa;'>{op.description}</span>"
                )
                op_label.setWordWrap(True)
                ops_layout.addWidget(op_label)
            
            content_layout.addWidget(ops_group)
        
        # File changes preview
        if self.operation_plan.affected_files:
            files_group = QGroupBox(f"File Changes ({len(self.operation_plan.affected_files)})")
            files_layout = QVBoxLayout(files_group)
            
            # For now, show file list
            # TODO: When file content is available in operation plan, show actual diffs
            for file_path in self.operation_plan.affected_files:
                file_label = QLabel(f"📄 {file_path}")
                file_label.setWordWrap(True)
                files_layout.addWidget(file_label)
            
            content_layout.addWidget(files_group)
        
        content_layout.addStretch()
        
        scroll.setWidget(content_widget)
        layout.addWidget(scroll)
        
        # Button box
        button_box = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        button_box.accepted.connect(self.accept)
        button_box.rejected.connect(self.reject)
        layout.addWidget(button_box)

