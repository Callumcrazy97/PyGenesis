from PySide6.QtCore import Qt, Signal, QTimer
from PySide6.QtGui import QKeyEvent, QFont
from PySide6.QtWidgets import (
    QWidget,
    QVBoxLayout,
    QHBoxLayout,
    QPushButton,
    QTextEdit,
    QSizePolicy,
    QLabel,
)

from settings import SETTINGS
from themes import current_palette


class InputTextEdit(QTextEdit):
    sendRequested = Signal()

    def keyPressEvent(self, event: QKeyEvent):
        if event.key() in (Qt.Key_Return, Qt.Key_Enter) and not event.modifiers() & Qt.ShiftModifier:
            if SETTINGS.EnableEnterToSend:
                self.sendRequested.emit()
                return
        super().keyPressEvent(event)


class ResizeButton(QPushButton):
    """Tiny icon button for resize controls."""
    def __init__(self, icon_text, parent=None):
        super().__init__(icon_text, parent)
        self.setFixedSize(20, 20)
        self.setStyleSheet(
            """
            QPushButton {
                background-color: transparent;
                border: none;
                color: rgba(255, 255, 255, 0.5);
                font-size: 10px;
                padding: 0px;
            }
            QPushButton:hover {
                color: rgba(255, 255, 255, 0.8);
                background-color: rgba(255, 255, 255, 0.1);
            }
            """
        )


class InputBar(QWidget):
    sendRequested = Signal(str)

    def __init__(self):
        super().__init__()
        self._apply_style()

        # Editor with resize buttons in top right
        editor_wrapper = QWidget()
        editor_wrapper_layout = QVBoxLayout(editor_wrapper)
        editor_wrapper_layout.setContentsMargins(0, 0, 0, 0)
        editor_wrapper_layout.setSpacing(0)
        
        # Top bar with resize buttons
        top_bar = QWidget()
        top_bar.setFixedHeight(24)
        top_bar_layout = QHBoxLayout(top_bar)
        top_bar_layout.setContentsMargins(0, 0, 4, 0)
        top_bar_layout.setSpacing(2)
        top_bar_layout.addStretch()
        
        self.expand_btn = ResizeButton("⛶")  # Expand icon
        self.expand_btn.setCheckable(True)
        self.expand_btn.setToolTip("Expand")
        self.expand_btn.clicked.connect(self._toggle_expand)
        
        self.reset_btn = ResizeButton("↻")  # Reset icon
        self.reset_btn.setToolTip("Reset Size")
        self.reset_btn.clicked.connect(self._reset_size)
        
        top_bar_layout.addWidget(self.expand_btn)
        top_bar_layout.addWidget(self.reset_btn)
        
        # Input textbox with integrated send button
        input_container = QWidget()
        input_container_layout = QHBoxLayout(input_container)
        input_container_layout.setContentsMargins(0, 0, 0, 0)
        input_container_layout.setSpacing(0)
        
        self.editor = InputTextEdit()
        self.editor.setPlaceholderText("Message Nova...")
        self.editor.setFixedHeight(SETTINGS.InputDefaultHeight)
        self.editor.setAcceptRichText(False)
        self.editor.sendRequested.connect(self._on_send_triggered)
        
        # Integrated send button inside textbox (right side)
        self.send_button = QPushButton("→")  # Arrow icon for send
        self.send_button.setFixedWidth(40)
        self.send_button.setFixedHeight(SETTINGS.InputDefaultHeight)
        self.send_button.clicked.connect(self._on_send_triggered)
        self.send_button.setDefault(True)
        self.send_button.setToolTip("Send (Enter)")
        
        input_container_layout.addWidget(self.editor)
        input_container_layout.addWidget(self.send_button)
        
        editor_wrapper_layout.addWidget(top_bar)
        editor_wrapper_layout.addWidget(input_container)

        # Status notification label (above input, hidden by default)
        self.status_label = QLabel("")
        self.status_label.setObjectName("statusNotification")
        status_font = QFont()
        status_font.setPointSize(10)
        status_font.setItalic(True)
        self.status_label.setFont(status_font)
        self.status_label.setVisible(False)
        self.status_label.setAlignment(Qt.AlignCenter)
        
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(6)
        layout.addStretch()  # Push input to bottom
        layout.addWidget(self.status_label)
        layout.addWidget(editor_wrapper)
        
        # Timer for animated dots
        self.status_timer = QTimer()
        self.status_timer.timeout.connect(self._animate_status_dots)
        self.status_dot_count = 0

    def _apply_style(self):
        palette = current_palette()
        # Use a slightly different color for input area background to make it visible
        input_area_bg = palette.get("inputAreaBg", palette["panel"])
        self.setStyleSheet(
            f"""
            QWidget {{
                background-color: {input_area_bg};
                border: 1px solid {palette["panelBorder"]};
                border-radius: 10px;
                padding: 8px;
            }}
            QTextEdit {{
                background-color: {palette.get("inputBg", palette["panel"])};
                color: {palette["text"]};
                border: 1px solid {palette["panelBorder"]};
                border-top-left-radius: 0px;
                border-top-right-radius: 0px;
                border-bottom-left-radius: 0px;
                border-bottom-right-radius: 0px;
                padding: 8px;
            }}
            QTextEdit:focus {{
                border: 2px solid {palette["accent"]};
            }}
            QPushButton {{
                background-color: {palette["accent"]};
                color: white;
                border: none;
                border-top-left-radius: 0px;
                border-top-right-radius: 0px;
                border-bottom-left-radius: 10px;
                border-bottom-right-radius: 10px;
                padding: 0px;
                font-weight: 700;
                font-size: 16px;
            }}
            QPushButton:hover {{
                background-color: {palette["accentAlt"]};
            }}
            QPushButton:pressed {{
                background-color: {palette.get("accentAlt", palette["accent"])};
            }}
            QLabel#statusNotification {{
                color: {palette.get("muted", palette["text"])};
                background-color: transparent;
                padding: 4px 8px;
                border-radius: 4px;
            }}
            """
        )

    def refresh_style(self):
        """Refresh styles when theme changes."""
        self._apply_style()

    def _on_send_triggered(self):
        text = self.editor.toPlainText().strip()
        if not text:
            return
        self.sendRequested.emit(text)
        self.editor.clear()

    def _toggle_expand(self):
        if self.expand_btn.isChecked():
            self.editor.setFixedHeight(SETTINGS.InputExpandedHeight)
            self.expand_btn.setToolTip("Collapse")
        else:
            self.editor.setFixedHeight(SETTINGS.InputDefaultHeight)
            self.expand_btn.setToolTip("Expand")

    def _reset_size(self):
        self.expand_btn.setChecked(False)
        self.editor.setFixedHeight(SETTINGS.InputDefaultHeight)
        self.expand_btn.setToolTip("Expand")
    
    def show_status(self, message: str, animated: bool = False):
        """
        Show status notification above input bar.
        
        Args:
            message: Status message text
            animated: If True, animate dots (e.g., "Thinking..." with animated dots)
        """
        self.status_label.setText(message)
        self.status_label.setVisible(True)
        
        if animated:
            self.status_dot_count = 0
            self.status_timer.start(500)  # Update every 500ms
        else:
            self.status_timer.stop()
    
    def hide_status(self):
        """Hide status notification."""
        self.status_label.setVisible(False)
        self.status_timer.stop()
    
    def _animate_status_dots(self):
        """Animate dots in status message (e.g., "Thinking..." -> "Thinking...." -> "Thinking.....")"""
        base_text = self.status_label.text().rstrip('.')
        self.status_dot_count = (self.status_dot_count + 1) % 4  # Cycle 0-3 dots
        dots = '.' * (self.status_dot_count + 1)
        self.status_label.setText(f"{base_text}{dots}")

