"""
Conversations Dialog - Shows list of conversations with management options.
"""
from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QListWidget, QListWidgetItem,
    QPushButton, QLabel, QLineEdit, QMessageBox, QDialogButtonBox, QInputDialog,
    QMenu, QWidget
)
from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QFont, QIcon

from core.conversations import ConversationManager, Conversation
from themes import current_palette


class ConversationListItem(QWidget):
    """Custom widget for conversation list item with star button."""
    
    def __init__(self, conversation: Conversation, parent=None):
        super().__init__(parent)
        self.conversation = conversation
        self.conversation_manager = None  # Will be set by dialog
        
        layout = QHBoxLayout(self)
        layout.setContentsMargins(8, 4, 8, 4)
        layout.setSpacing(8)
        
        # Star button (always visible, shows state)
        self.star_btn = QPushButton("⭐" if conversation.is_global else "☆")
        self.star_btn.setFixedSize(24, 24)
        self.star_btn.setToolTip(
            "Click to make global (available in all projects)" if not conversation.is_global
            else "Click to make project-specific"
        )
        self.star_btn.clicked.connect(self._on_star_clicked)
        palette = current_palette()
        self.star_btn.setStyleSheet(
            f"""
            QPushButton {{
                background-color: transparent;
                border: none;
                color: {palette.get('accent', '#0078d4')};
                font-size: 16px;
                padding: 0px;
            }}
            QPushButton:hover {{
                background-color: {palette.get('panelBorder', '#333')};
                border-radius: 4px;
            }}
            """
        )
        layout.addWidget(self.star_btn)
        
        # Title label
        self.title_label = QLabel(conversation.title)
        self.title_label.setStyleSheet(f"color: {palette['text']};")
        layout.addWidget(self.title_label, 1)
        
        # Set tooltip
        from datetime import datetime
        try:
            dt = datetime.fromisoformat(conversation.updated_at)
            tooltip = f"Updated: {dt.strftime('%Y-%m-%d %H:%M:%S')}"
        except:
            tooltip = f"Updated: {conversation.updated_at}"
        
        if conversation.is_global:
            tooltip += "\n⭐ Global conversation (available in all projects)"
        else:
            tooltip += "\nProject-specific conversation"
        
        self.setToolTip(tooltip)
    
    def _on_star_clicked(self):
        """Handle star button click - toggle global status."""
        if not self.conversation_manager:
            return
        
        new_is_global = self.conversation_manager.toggle_global(self.conversation.id)
        self.conversation.is_global = new_is_global
        
        # Update button text
        self.star_btn.setText("⭐" if new_is_global else "☆")
        self.star_btn.setToolTip(
            "Click to make project-specific" if new_is_global
            else "Click to make global (available in all projects)"
        )
        
        # Update tooltip
        from datetime import datetime
        try:
            dt = datetime.fromisoformat(self.conversation.updated_at)
            tooltip = f"Updated: {dt.strftime('%Y-%m-%d %H:%M:%S')}"
        except:
            tooltip = f"Updated: {self.conversation.updated_at}"
        
        if new_is_global:
            tooltip += "\n⭐ Global conversation (available in all projects)"
        else:
            tooltip += "\nProject-specific conversation"
        
        self.setToolTip(tooltip)


class ConversationsDialog(QDialog):
    """Dialog for managing conversations."""
    
    conversation_selected = Signal(str)  # Emits conversation_id when selected
    conversation_deleted = Signal(str)  # Emits conversation_id when deleted
    
    def __init__(self, conversation_manager: ConversationManager, parent=None):
        super().__init__(parent)
        self.conversation_manager = conversation_manager
        self.setWindowTitle("Conversations")
        self.resize(500, 400)
        self._setup_ui()
        self._load_conversations()
        self._apply_style()
    
    def _setup_ui(self):
        """Setup the UI."""
        layout = QVBoxLayout(self)
        layout.setSpacing(12)
        
        # Title
        title = QLabel("Conversations")
        title_font = QFont()
        title_font.setPointSize(16)
        title_font.setWeight(QFont.Bold)
        title.setFont(title_font)
        layout.addWidget(title)
        
        # Conversations list
        self.conversations_list = QListWidget()
        self.conversations_list.itemDoubleClicked.connect(self._on_conversation_double_clicked)
        self.conversations_list.itemSelectionChanged.connect(self._on_selection_changed)
        self.conversations_list.setContextMenuPolicy(Qt.CustomContextMenu)
        self.conversations_list.customContextMenuRequested.connect(self._on_context_menu)
        layout.addWidget(self.conversations_list, 1)
        
        # Buttons row
        buttons_layout = QHBoxLayout()
        
        self.new_chat_btn = QPushButton("New Chat")
        self.new_chat_btn.clicked.connect(self._on_new_chat)
        buttons_layout.addWidget(self.new_chat_btn)
        
        self.rename_btn = QPushButton("Rename")
        self.rename_btn.setEnabled(False)
        self.rename_btn.clicked.connect(self._on_rename)
        buttons_layout.addWidget(self.rename_btn)
        
        self.delete_btn = QPushButton("Delete")
        self.delete_btn.setEnabled(False)
        self.delete_btn.clicked.connect(self._on_delete)
        buttons_layout.addWidget(self.delete_btn)
        
        buttons_layout.addStretch()
        
        layout.addLayout(buttons_layout)
        
        # Close button
        close_btn = QPushButton("Close")
        close_btn.clicked.connect(self.accept)
        layout.addWidget(close_btn)
    
    def _load_conversations(self):
        """Load and display conversations."""
        self.conversations_list.clear()
        conversations = self.conversation_manager.list_conversations()
        
        for conversation in conversations:
            # Create custom widget for the item
            item_widget = ConversationListItem(conversation, self)
            item_widget.conversation_manager = self.conversation_manager
            
            # Create list item and set widget
            item = QListWidgetItem()
            item.setData(Qt.UserRole, conversation.id)
            item.setData(Qt.UserRole + 1, conversation.is_global)  # Store is_global flag
            item.setSizeHint(item_widget.sizeHint())
            
            self.conversations_list.addItem(item)
            self.conversations_list.setItemWidget(item, item_widget)
    
    def _on_selection_changed(self):
        """Handle selection change."""
        has_selection = len(self.conversations_list.selectedItems()) > 0
        self.rename_btn.setEnabled(has_selection)
        self.delete_btn.setEnabled(has_selection)
    
    def _on_conversation_double_clicked(self, item: QListWidgetItem):
        """Handle double-click on conversation."""
        conversation_id = item.data(Qt.UserRole)
        # Get the widget to access conversation
        item_widget = self.conversations_list.itemWidget(item)
        if item_widget and item_widget.conversation:
            # Update conversation reference in case it changed
            conversation = self.conversation_manager.get_conversation(conversation_id)
            if conversation:
                item_widget.conversation = conversation
        self.conversation_selected.emit(conversation_id)
        self.accept()
    
    def _on_new_chat(self):
        """Create a new conversation."""
        conversation = self.conversation_manager.create_conversation()
        self.conversation_selected.emit(conversation.id)
        self.accept()
    
    def _on_rename(self):
        """Rename selected conversation."""
        selected_items = self.conversations_list.selectedItems()
        if not selected_items:
            return
        
        item = selected_items[0]
        conversation_id = item.data(Qt.UserRole)
        conversation = self.conversation_manager.get_conversation(conversation_id)
        
        if not conversation:
            return
        
        # Show input dialog
        new_title, ok = QInputDialog.getText(
            self, "Rename Conversation", "New name:", text=conversation.title
        )
        
        if ok and new_title.strip():
            self.conversation_manager.rename_conversation(conversation_id, new_title.strip())
            # Update widget title
            item_widget = self.conversations_list.itemWidget(item)
            if item_widget:
                item_widget.title_label.setText(new_title.strip())
                conversation = self.conversation_manager.get_conversation(conversation_id)
                if conversation:
                    item_widget.conversation = conversation
    
    def _on_delete(self):
        """Delete selected conversation."""
        selected_items = self.conversations_list.selectedItems()
        if not selected_items:
            return
        
        item = selected_items[0]
        conversation_id = item.data(Qt.UserRole)
        conversation = self.conversation_manager.get_conversation(conversation_id)
        
        if not conversation:
            return
        
        # Confirm deletion
        reply = QMessageBox.question(
            self,
            "Delete Conversation",
            f"Are you sure you want to delete '{conversation.title}'?\n\nThis cannot be undone.",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No
        )
        
        if reply == QMessageBox.StandardButton.Yes:
            self.conversation_manager.delete_conversation(conversation_id)
            self.conversation_deleted.emit(conversation_id)
            # Remove from list
            row = self.conversations_list.row(item)
            self.conversations_list.takeItem(row)
    
    def _on_context_menu(self, position):
        """Show context menu for conversation item."""
        item = self.conversations_list.itemAt(position)
        if not item:
            return
        
        conversation_id = item.data(Qt.UserRole)
        is_global = item.data(Qt.UserRole + 1) or False
        conversation = self.conversation_manager.get_conversation(conversation_id)
        
        if not conversation:
            return
        
        menu = QMenu(self)
        
        # Toggle global action
        toggle_action = menu.addAction(
            "⭐ Mark as Global" if not is_global else "Remove Global Mark"
        )
        toggle_action.setToolTip(
            "Make this conversation available in all projects" if not is_global
            else "Make this conversation project-specific"
        )
        
        menu.addSeparator()
        
        rename_action = menu.addAction("Rename")
        delete_action = menu.addAction("Delete")
        
        action = menu.exec_(self.conversations_list.mapToGlobal(position))
        
        if action == toggle_action:
            # Toggle global status
            new_is_global = self.conversation_manager.toggle_global(conversation_id)
            # Update widget
            item_widget = self.conversations_list.itemWidget(item)
            if item_widget:
                item_widget.conversation.is_global = new_is_global
                item_widget.star_btn.setText("⭐" if new_is_global else "☆")
                item_widget.star_btn.setToolTip(
                    "Click to make project-specific" if new_is_global
                    else "Click to make global (available in all projects)"
                )
                # Update tooltip
                from datetime import datetime
                try:
                    dt = datetime.fromisoformat(item_widget.conversation.updated_at)
                    tooltip = f"Updated: {dt.strftime('%Y-%m-%d %H:%M:%S')}"
                except:
                    tooltip = f"Updated: {item_widget.conversation.updated_at}"
                if new_is_global:
                    tooltip += "\n⭐ Global conversation (available in all projects)"
                else:
                    tooltip += "\nProject-specific conversation"
                item_widget.setToolTip(tooltip)
            item.setData(Qt.UserRole + 1, new_is_global)
        elif action == rename_action:
            self._on_rename()
        elif action == delete_action:
            self._on_delete()
    
    def _apply_style(self):
        """Apply styling."""
        palette = current_palette()
        self.setStyleSheet(
            f"""
            QDialog {{
                background-color: {palette["panel"]};
            }}
            QLabel {{
                color: {palette["text"]};
            }}
            QListWidget {{
                background-color: {palette["bg"]};
                color: {palette["text"]};
                border: 1px solid {palette["panelBorder"]};
                border-radius: 8px;
            }}
            QPushButton {{
                background-color: {palette["accent"]};
                color: white;
                border: none;
                border-radius: 8px;
                padding: 8px 16px;
                font-weight: 700;
            }}
            QPushButton:hover {{
                background-color: {palette["accentAlt"]};
            }}
            QPushButton:disabled {{
                background-color: {palette["panelBorder"]};
                color: {palette["muted"]};
            }}
            """
        )

