from datetime import datetime
from typing import List

from PySide6.QtCore import Qt
from PySide6.QtGui import QFont
from PySide6.QtWidgets import (
    QLabel,
    QScrollArea,
    QVBoxLayout,
    QWidget,
    QFrame,
    QSizePolicy,
    QHBoxLayout,
)

from core.models import ChatMessage, Sender
from settings import SETTINGS
from themes import current_palette


class MessageMeta(QWidget):
    """Header with sender, timestamp, and mode indicator - distinct background from body."""
    def __init__(self, message: ChatMessage, app=None):
        super().__init__()
        self.app = app
        palette = current_palette()
        is_user = message.sender == Sender.USER
        
        layout = QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)  # No margins - card handles padding
        layout.setSpacing(12)  # More breathing room
        
        # Sender name - strong color (always left-aligned within card)
        # Get user name from PyGenesis settings, fallback to "Engineer" or "PRIMARY ENGINEER"
        if is_user:
            user_name = "Engineer"  # Default
            # Try to get from app settings if available
            if self.app and hasattr(self.app, 'settings'):
                try:
                    user_name = self.app.settings.get("User_Name", "Engineer")
                    if not user_name or user_name.strip() == "":
                        user_name = "Engineer"
                except Exception:
                    user_name = "Engineer"
            sender_name = user_name.upper()
        else:
            sender_name = "Nova"
        
        sender_label = QLabel(sender_name)
        sender_font = QFont()
        sender_font.setPointSize(8)
        sender_font.setWeight(QFont.Black)
        sender_font.setCapitalization(QFont.AllUppercase if is_user else QFont.MixedCase)
        sender_label.setFont(sender_font)
        sender_color = palette.get('accentSoft', palette['metaUser' if is_user else 'metaNova'])
        sender_label.setStyleSheet(f"color: {sender_color};")
        layout.addWidget(sender_label)
        
        # Date and time - muted
        date_time = message.timestamp.strftime("%Y-%m-%d %H:%M")
        time_label = QLabel(date_time)
        time_font = QFont()
        time_font.setPointSize(8)
        time_font.setWeight(QFont.Normal)
        time_font.setStyleHint(QFont.TypeWriter)
        time_label.setFont(time_font)
        time_label.setStyleSheet(f"color: {palette['muted']};")
        layout.addWidget(time_label)
        
        if not is_user:
            # Mode indicator - accent color (Nova only)
            mode_text = "● Local" if SETTINGS.Mode == "Local" else "● Cloud"
            mode_color = palette.get('bubbleNovaAccentLocal', palette.get('accentSoft', palette['accent'])) if SETTINGS.Mode == "Local" else palette.get('bubbleNovaAccentCloud', palette.get('accentSoft', palette['accent']))
            mode_label = QLabel(mode_text)
            mode_font = QFont()
            mode_font.setPointSize(8)
            mode_font.setWeight(QFont.Normal)
            mode_label.setFont(mode_font)
            mode_label.setStyleSheet(f"color: {mode_color};")
            layout.addWidget(mode_label)
        
        # Add stretch after content to push everything left
        layout.addStretch()
        
        # Header background - slightly different from card background for visual distinction
        card_bg = palette.get("surface", palette["bubbleUser"] if is_user else palette["bubbleNova"])
        # Make header slightly lighter/darker than card
        header_bg = palette.get("panel", card_bg)  # Use panel color for header background
        
        self.setStyleSheet(
            f"""
            QWidget {{
                background-color: {header_bg};
                padding: 6px 0px;
                border-bottom: 1px solid {palette.get('panelBorder', palette['muted'])}40;
            }}
            """
        )
        
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Maximum)


class MessageBody(QLabel):
    """Message body text - starts immediately after header, expands to show all content."""
    def __init__(self, message: ChatMessage):
        super().__init__(message.text)
        palette = current_palette()
        is_user = message.sender == Sender.USER
        
        fg = palette["bubbleUserText"] if is_user else palette["bubbleNovaText"]
        
        self.setWordWrap(True)
        self.setTextInteractionFlags(Qt.TextSelectableByMouse)
        text_font = QFont()
        text_font.setPointSize(10 if is_user else 9)
        self.setFont(text_font)
        # No padding - text starts immediately
        self.setStyleSheet(f"color: {fg}; padding: 0px;")
        # Use Preferred/Preferred to allow proper height calculation for word-wrapped text
        # (Gemini's fix: Preferred/Preferred handles word wrap better than Preferred/Expanding)
        self.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Preferred)
        self.setAlignment(Qt.AlignLeft | Qt.AlignTop)
        # Let the card's max width handle wrapping, not the label itself
        self.setMaximumWidth(16777215)  # Qt's default max (effectively unlimited)


class MessageCard(QFrame):
    """Flat message card - no speech bubble, IDE-like appearance."""
    def __init__(self, message: ChatMessage, app=None):
        super().__init__()
        self.app = app
        palette = current_palette()
        is_user = message.sender == Sender.USER

        # Use surface color if available, fallback to bubble colors
        bg = palette.get("surface", palette["bubbleUser"] if is_user else palette["bubbleNova"])
        fg = palette["bubbleUserText"] if is_user else palette["bubbleNovaText"]

        # Simple rounded card - no special corner treatment
        self.setStyleSheet(
            f"""
            QFrame {{
                background-color: {bg};
                color: {fg};
                border-radius: 10px;
                border: none;
                padding: 0px;
            }}
            """
        )
        # Size to content: width constrained to max, height expands to fit all text
        # Use Preferred/Preferred to allow card to grow as large as content requires
        # (Gemini's fix: Maximum was clamping height to incorrect size hint, Preferred allows growth)
        self.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Preferred)
        self.setMaximumWidth(600)  # Max width for wrapping
        self.setMinimumWidth(0)  # Allow shrinking to content
        # Ensure the card shrinks to fit content width
        self.setMinimumSize(0, 0)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(14, 10, 14, 10)  # Card padding - outer padding only
        layout.setSpacing(0)  # No spacing - header and body are adjacent

        # Add header
        meta = MessageMeta(message, app=self.app)
        layout.addWidget(meta)
        
        # Add body - ensure it can expand to show all text vertically
        body = MessageBody(message)
        layout.addWidget(body)  # No stretch factor - let it size naturally


class ChatView(QScrollArea):
    def __init__(self, app=None):
        super().__init__()
        self.app = app  # Store app reference for accessing settings
        self.setWidgetResizable(True)
        self.setFrameStyle(QFrame.NoFrame)
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self._apply_style()

        self.container = QWidget()
        self.container.setObjectName("chatContainer")
        self.setWidget(self.container)

        self.layout = QVBoxLayout(self.container)
        self.layout.setAlignment(Qt.AlignTop)  # Align items to top
        self.layout.addStretch()

        self.messages: List[ChatMessage] = []
        self.bubbles: List[MessageCard] = []

    def _apply_style(self):
        palette = current_palette()
        self.setStyleSheet(
            f"""
            QScrollArea {{
                border: none;
                background-color: {palette["bg"]};
            }}
            QWidget#chatContainer {{
                background-color: {palette["bg"]};
            }}
            """
        )

    def refresh_style(self):
        """Refresh styles when theme changes."""
        self._apply_style()
        self.container.setStyleSheet(
            f"QWidget#chatContainer {{ background-color: {current_palette()['bg']}; }}"
        )

    def refresh_bubbles(self):
        """Re-render all chat bubbles with the current theme."""
        # Store current messages
        messages = self.messages.copy()
        # Clear layout (except stretch)
        while self.layout.count() > 1:
            item = self.layout.takeAt(0)
            if item and item.widget():
                item.widget().deleteLater()
        self.bubbles.clear()
        # Re-add all messages with new theme
        for msg in messages:
            is_user = msg.sender == Sender.USER
            
            # Use MessageCard wrapped in a container for proper alignment
            # (Using alignment param on insertWidget breaks height calculation for word-wrapped QLabels)
            card = MessageCard(msg, app=self.app)
            wrapper = self._create_aligned_wrapper(card, is_user)
            
            self.bubbles.append(card)
            self.layout.insertWidget(self.layout.count() - 1, wrapper)
        self._scroll_to_bottom()

    def add_message(self, message: ChatMessage):
        if len(self.messages) >= SETTINGS.MaxChatHistory:
            # Drop the oldest visual message (skip the final stretch item)
            old_item = self.layout.takeAt(0)
            if old_item and old_item.widget():
                old_item.widget().deleteLater()
            self.messages.pop(0)
            self.bubbles.pop(0)

        # Determine if this is a user message
        is_user = message.sender == Sender.USER

        # Use MessageCard - flat card design, no container needed
        card = MessageCard(message, app=self.app)
        
        # Add thinking and preview widgets if available (for Nova messages)
        if not is_user:
            if message.thinking_content:
                from ui.preview_widget import ThinkingWidget
                thinking_widget = ThinkingWidget(message.thinking_content)
                card.layout().addWidget(thinking_widget)
            
            if message.operation_plan:
                from ui.preview_widget import PreviewButtonWidget
                preview_widget = PreviewButtonWidget(message.operation_plan)
                # Connect preview signal to open dialog
                preview_widget.preview_requested.connect(self._on_preview_requested)
                card.layout().addWidget(preview_widget)
        
        self.bubbles.append(card)
        # Wrap card in a container for proper alignment
        # (Using alignment param on insertWidget breaks height calculation for word-wrapped QLabels)
        wrapper = self._create_aligned_wrapper(card, is_user)
        self.layout.insertWidget(self.layout.count() - 1, wrapper)
        self.messages.append(message)
        self._scroll_to_bottom()
    
    def _on_preview_requested(self, operation_plan):
        """Handle preview button click - open preview dialog."""
        from ui.preview_dialog import PreviewDialog
        dialog = PreviewDialog(operation_plan, self)
        dialog.exec()

    def _alignment_for(self, sender: Sender):
        return Qt.AlignRight if sender == Sender.USER else Qt.AlignLeft

    def _create_aligned_wrapper(self, card: MessageCard, is_user: bool) -> QWidget:
        """
        Create a wrapper widget that handles horizontal alignment without using
        the alignment parameter on insertWidget (which breaks word-wrap height calculation).
        """
        wrapper = QWidget()
        wrapper.setStyleSheet("background: transparent;")
        wrapper_layout = QHBoxLayout(wrapper)
        wrapper_layout.setContentsMargins(0, 0, 0, 0)
        wrapper_layout.setSpacing(0)
        
        if is_user:
            # Right-align: add stretch before card
            wrapper_layout.addStretch()
            wrapper_layout.addWidget(card)
        else:
            # Left-align: add card then stretch
            wrapper_layout.addWidget(card)
            wrapper_layout.addStretch()
        
        return wrapper

    def _scroll_to_bottom(self):
        self.verticalScrollBar().setValue(self.verticalScrollBar().maximum())

