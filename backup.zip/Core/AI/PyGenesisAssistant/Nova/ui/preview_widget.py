"""
Preview Widget - Shows file changes with diff highlighting.
Green for additions, red for removals.
"""

from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QTextEdit, QScrollArea, QFrame, QGroupBox
)
from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QTextCharFormat, QTextCursor, QColor, QSyntaxHighlighter, QTextDocument
from typing import List, Dict, Optional
import difflib


class DiffHighlighter(QSyntaxHighlighter):
    """Syntax highlighter for diff display."""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.add_format = QTextCharFormat()
        self.add_format.setBackground(QColor(0, 255, 0, 50))  # Green with transparency
        self.add_format.setForeground(QColor(0, 200, 0))
        
        self.remove_format = QTextCharFormat()
        self.remove_format.setBackground(QColor(255, 0, 0, 50))  # Red with transparency
        self.remove_format.setForeground(QColor(200, 0, 0))
        
        self.context_format = QTextCharFormat()
        self.context_format.setForeground(QColor(150, 150, 150))
    
    def highlightBlock(self, text):
        """Highlight a line based on diff marker."""
        if text.startswith("+"):
            self.setFormat(0, len(text), self.add_format)
        elif text.startswith("-"):
            self.setFormat(0, len(text), self.remove_format)
        elif text.startswith(" "):
            self.setFormat(0, len(text), self.context_format)


class FilePreviewWidget(QWidget):
    """Widget showing a single file's changes."""
    
    def __init__(self, file_path: str, old_content: Optional[str], new_content: Optional[str], parent=None):
        super().__init__(parent)
        self.file_path = file_path
        self.old_content = old_content or ""
        self.new_content = new_content or ""
        
        self.setup_ui()
        self.generate_diff()
    
    def setup_ui(self):
        """Setup the preview UI."""
        layout = QVBoxLayout(self)
        layout.setContentsMargins(8, 8, 8, 8)
        layout.setSpacing(8)
        
        # File header
        header = QLabel(f"📄 {self.file_path}")
        header.setStyleSheet("font-weight: bold; font-size: 11pt; padding: 4px;")
        layout.addWidget(header)
        
        # Diff display
        self.diff_text = QTextEdit()
        self.diff_text.setReadOnly(True)
        self.diff_text.setFontFamily("Consolas, 'Courier New', monospace")
        self.diff_text.setFontPointSize(9)
        self.diff_text.setLineWrapMode(QTextEdit.NoWrap)
        
        # Apply highlighter
        self.highlighter = DiffHighlighter(self.diff_text.document())
        
        # Wrap in scroll area
        scroll = QScrollArea()
        scroll.setWidget(self.diff_text)
        scroll.setWidgetResizable(True)
        scroll.setMinimumHeight(200)
        scroll.setMaximumHeight(400)
        
        layout.addWidget(scroll)
    
    def generate_diff(self):
        """Generate unified diff and display it."""
        old_lines = self.old_content.splitlines(keepends=True) if self.old_content else []
        new_lines = self.new_content.splitlines(keepends=True) if self.new_content else []
        
        # Generate unified diff
        diff = list(difflib.unified_diff(
            old_lines,
            new_lines,
            fromfile=f"Original: {self.file_path}",
            tofile=f"Modified: {self.file_path}",
            lineterm=""
        ))
        
        if not diff:
            # No changes
            self.diff_text.setPlainText("(No changes)")
            return
        
        # Format diff for display
        diff_text = "\n".join(diff)
        self.diff_text.setPlainText(diff_text)


class OperationPreviewWidget(QWidget):
    """Widget showing operation plan preview with file changes."""
    
    def __init__(self, operation_plan, parent=None):
        super().__init__(parent)
        self.operation_plan = operation_plan
        self.setup_ui()
    
    def setup_ui(self):
        """Setup the preview UI."""
        layout = QVBoxLayout(self)
        layout.setContentsMargins(12, 12, 12, 12)
        layout.setSpacing(12)
        
        # Header
        header = QLabel("📋 Operation Preview")
        header.setStyleSheet("font-weight: bold; font-size: 12pt; padding: 4px;")
        layout.addWidget(header)
        
        # Summary
        summary_group = QGroupBox("Summary")
        summary_layout = QVBoxLayout(summary_group)
        
        summary_text = QLabel(
            f"<b>Rationale:</b> {self.operation_plan.rationale}<br/>"
            f"<b>Risk Level:</b> {self.operation_plan.risk_level.value}<br/>"
            f"<b>Expected Outcome:</b> {self.operation_plan.expected_outcome}<br/>"
            f"<b>Affected Systems:</b> {', '.join(self.operation_plan.affected_systems) if self.operation_plan.affected_systems else 'None'}"
        )
        summary_text.setWordWrap(True)
        summary_layout.addWidget(summary_text)
        
        layout.addWidget(summary_group)
        
        # Operations list
        if self.operation_plan.operations:
            ops_group = QGroupBox(f"Operations ({len(self.operation_plan.operations)})")
            ops_layout = QVBoxLayout(ops_group)
            
            for i, op in enumerate(self.operation_plan.operations, 1):
                op_label = QLabel(f"{i}. <b>{op.component}.{op.method}</b><br/>{op.description}")
                op_label.setWordWrap(True)
                ops_layout.addWidget(op_label)
            
            layout.addWidget(ops_group)
        
        # File changes (if available)
        if self.operation_plan.affected_files:
            files_group = QGroupBox(f"File Changes ({len(self.operation_plan.affected_files)})")
            files_layout = QVBoxLayout(files_group)
            
            # For now, show file list
            # TODO: When file content is available, show actual diffs
            for file_path in self.operation_plan.affected_files:
                file_label = QLabel(f"📄 {file_path}")
                file_label.setWordWrap(True)
                files_layout.addWidget(file_label)
            
            layout.addWidget(files_group)
        
        layout.addStretch()


class ThinkingWidget(QWidget):
    """Collapsible widget showing Nova's thinking process."""
    
    def __init__(self, thinking_content: str, parent=None):
        super().__init__(parent)
        self.thinking_content = thinking_content
        self.is_expanded = False
        self.setup_ui()
    
    def setup_ui(self):
        """Setup the thinking widget UI."""
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)
        
        # Collapsible button
        self.toggle_btn = QPushButton("🔍 Show Thinking")
        self.toggle_btn.setCheckable(True)
        self.toggle_btn.setChecked(False)
        self.toggle_btn.clicked.connect(self.toggle_expanded)
        self.toggle_btn.setStyleSheet("""
            QPushButton {
                text-align: left;
                padding: 6px 8px;
                border: 1px solid #444;
                border-radius: 4px;
                background-color: #2a2a2a;
            }
            QPushButton:hover {
                background-color: #333;
            }
            QPushButton:checked {
                background-color: #3a3a3a;
            }
        """)
        layout.addWidget(self.toggle_btn)
        
        # Content area (hidden by default)
        self.content_area = QFrame()
        self.content_area.setVisible(False)
        content_layout = QVBoxLayout(self.content_area)
        content_layout.setContentsMargins(12, 8, 12, 8)
        
        thinking_text = QLabel(self.thinking_content)
        thinking_text.setWordWrap(True)
        thinking_text.setStyleSheet("color: #aaa; font-size: 9pt; font-style: italic;")
        content_layout.addWidget(thinking_text)
        
        layout.addWidget(self.content_area)
    
    def toggle_expanded(self, checked):
        """Toggle expanded state."""
        self.is_expanded = checked
        self.content_area.setVisible(checked)
        self.toggle_btn.setText("🔍 Hide Thinking" if checked else "🔍 Show Thinking")


class PreviewButtonWidget(QWidget):
    """Widget with preview button that opens preview dialog."""
    
    preview_requested = Signal(object)  # Emits operation_plan
    
    def __init__(self, operation_plan, parent=None):
        super().__init__(parent)
        self.operation_plan = operation_plan
        self.setup_ui()
    
    def setup_ui(self):
        """Setup the preview button UI."""
        layout = QHBoxLayout(self)
        layout.setContentsMargins(0, 4, 0, 4)
        layout.setSpacing(8)
        
        preview_btn = QPushButton("👁️ Show Preview")
        preview_btn.clicked.connect(lambda: self.preview_requested.emit(self.operation_plan))
        preview_btn.setStyleSheet("""
            QPushButton {
                padding: 6px 12px;
                border: 1px solid #444;
                border-radius: 4px;
                background-color: #2a2a2a;
            }
            QPushButton:hover {
                background-color: #333;
            }
        """)
        layout.addWidget(preview_btn)
        layout.addStretch()

