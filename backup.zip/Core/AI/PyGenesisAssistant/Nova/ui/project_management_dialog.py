from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QTabWidget, QWidget, QLabel, QPushButton,
    QTextEdit, QTreeWidget, QTreeWidgetItem, QHBoxLayout, QProgressBar,
    QMessageBox, QFileSystemModel, QSplitter
)
from PySide6.QtCore import Qt, QThread, Signal, QModelIndex, QTimer
import sys
from pathlib import Path

from themes import current_palette

# Import integrated codebase analyzer
try:
    from core.codebase_analyzer import CodebaseAnalyzer
    ANALYSIS_AVAILABLE = True
except ImportError:
    ANALYSIS_AVAILABLE = False


class AnalysisWorker(QThread):
    """Worker thread for running code analysis"""
    finished = Signal(dict)
    progress = Signal(str)
    
    def __init__(self, root_path, analysis_type):
        super().__init__()
        self.root_path = root_path
        self.analysis_type = analysis_type
        self.analyzer = CodebaseAnalyzer()
    
    def run(self):
        try:
            if self.analysis_type == "codebase":
                self.progress.emit("Analyzing codebase...")
                result = self.analyzer.analyze_codebase(self.root_path)
                self.finished.emit(result)
            elif self.analysis_type == "dependency":
                self.progress.emit("Analyzing dependencies...")
                result = self.analyzer.analyze_dependencies(self.root_path)
                self.finished.emit(result)
        except Exception as e:
            self.finished.emit({"error": str(e)})


class CodebaseSummaryTab(QWidget):
    """Codebase Summary using code analysis scripts."""
    def __init__(self, parent=None, project_root=None):
        super().__init__(parent)
        self.project_root = project_root
        self.worker = None
        layout = QVBoxLayout(self)
        layout.setSpacing(12)
        
        # Header
        label = QLabel("Codebase Summary")
        label_font = label.font()
        label_font.setPointSize(12)
        label_font.setBold(True)
        label.setFont(label_font)
        layout.addWidget(label)
        
        # Progress bar
        self.progress_bar = QProgressBar()
        self.progress_bar.setVisible(False)
        layout.addWidget(self.progress_bar)
        
        # Content area
        self.content = QTextEdit()
        self.content.setReadOnly(True)
        self.content.setPlaceholderText("Analyzing codebase...")
        layout.addWidget(self.content)
        
        self._apply_style()
        
        # Auto-analyze if project root is available
        if self.project_root:
            QTimer.singleShot(100, self.run_analysis)
    
    def run_analysis(self):
        """Run code analysis automatically"""
        if not ANALYSIS_AVAILABLE:
            self.content.setText("Code analysis not available.")
            return
        
        if not self.project_root:
            self.content.setText("No project root specified.")
            return
        
        self.progress_bar.setVisible(True)
        self.progress_bar.setRange(0, 0)  # Indeterminate
        
        self.worker = AnalysisWorker(self.project_root, "codebase")
        self.worker.progress.connect(self.on_progress)
        self.worker.finished.connect(self.on_analysis_complete)
        self.worker.start()
    
    def on_progress(self, message):
        """Update progress message"""
        self.content.setPlainText(f"{message}\n\nPlease wait...")
    
    def on_analysis_complete(self, result):
        """Handle analysis completion"""
        self.analyze_btn.setEnabled(True)
        self.progress_bar.setVisible(False)
        
        if "error" in result:
            self.content.setText(f"Error: {result['error']}")
            return
        
        # Check if no code files found
        if result.get("no_code") or not result.get("code_files"):
            self.content.setPlainText("No Code Yet\n\nThis project doesn't contain any code files yet.\n\nCode files include:\n- Objects (.object files with PGSL code)\n- Scripts (.script or .py files)\n- Shaders (.shader files)")
            return
        
        # Format results
        summary = f"Codebase Summary\n{'='*50}\n\n"
        summary += f"Root Path: {result.get('root_path', 'Unknown')}\n"
        summary += f"Total Code Files: {result.get('total_files', 0)}\n"
        summary += f"Total Size: {result.get('total_size', '0 KB')}\n\n"
        
        # File extensions
        if result.get('file_extensions'):
            summary += "File Types:\n"
            for ext, count in sorted(result['file_extensions'].items()):
                summary += f"  {ext}: {count}\n"
            summary += "\n"
        
        # Python files summary
        python_files = result.get('python_files', [])
        if python_files:
            summary += f"Python Files ({len(python_files)} shown):\n"
            for pf in python_files[:10]:
                summary += f"  - {pf['path']} ({pf['lines']} lines)\n"
            summary += "\n"
        
        # PGSL files summary
        pgsl_files = result.get('pgsl_files', [])
        if pgsl_files:
            summary += f"PGSL Files ({len(pgsl_files)} shown):\n"
            for pf in pgsl_files[:10]:
                summary += f"  - {pf['path']} ({pf['lines']} lines)\n"
            summary += "\n"
        
        # Functions and classes
        functions = result.get('functions', [])
        classes = result.get('classes', [])
        if functions:
            summary += f"Functions Found: {len(functions)}\n"
        if classes:
            summary += f"Classes Found: {len(classes)}\n"
        
        # Errors and warnings
        errors = result.get('errors', [])
        warnings = result.get('warnings', [])
        if errors:
            summary += f"\nErrors: {len(errors)}\n"
        if warnings:
            summary += f"Warnings: {len(warnings)}\n"
        
        self.content.setPlainText(summary)
    
    def set_project_root(self, project_root):
        """Set the project root for analysis"""
        self.project_root = project_root
        # Auto-run analysis when project root is set
        if project_root:
            QTimer.singleShot(100, self.run_analysis)
    
    def _apply_style(self):
        palette = current_palette()
        self.setStyleSheet(
            f"""
            QLabel {{
                color: {palette["text"]};
            }}
            QTextEdit {{
                background: {palette["bg"]};
                color: {palette["text"]};
                border: 1px solid {palette["panelBorder"]};
                border-radius: 8px;
                padding: 8px;
            }}
            """
        )


class DependencyAnalysisTab(QWidget):
    """Dependency Analysis using DependencyAnalyser."""
    def __init__(self, parent=None, project_root=None):
        super().__init__(parent)
        self.project_root = project_root
        self.worker = None
        layout = QVBoxLayout(self)
        layout.setSpacing(12)
        
        # Header
        label = QLabel("Dependency Analysis")
        label_font = label.font()
        label_font.setPointSize(12)
        label_font.setBold(True)
        label.setFont(label_font)
        layout.addWidget(label)
        
        # Progress bar
        self.progress_bar = QProgressBar()
        self.progress_bar.setVisible(False)
        layout.addWidget(self.progress_bar)
        
        # Content area
        self.content = QTextEdit()
        self.content.setReadOnly(True)
        self.content.setPlaceholderText("Analyzing dependencies...")
        layout.addWidget(self.content)
        
        self._apply_style()
        
        # Auto-analyze if project root is available
        if self.project_root:
            QTimer.singleShot(100, self.run_analysis)
    
    def run_analysis(self):
        """Run dependency analysis automatically"""
        if not ANALYSIS_AVAILABLE:
            self.content.setText("Dependency analysis not available.")
            return
        
        if not self.project_root:
            self.content.setText("No project root specified.")
            return
        
        self.progress_bar.setVisible(True)
        self.progress_bar.setRange(0, 0)
        
        self.worker = AnalysisWorker(self.project_root, "dependency")
        self.worker.progress.connect(self.on_progress)
        self.worker.finished.connect(self.on_analysis_complete)
        self.worker.start()
    
    def on_progress(self, message):
        """Update progress message"""
        self.content.setPlainText(f"{message}\n\nPlease wait...")
    
    def on_analysis_complete(self, result):
        """Handle analysis completion"""
        self.progress_bar.setVisible(False)
        
        if "error" in result:
            self.content.setText(f"Error: {result['error']}")
            return
        
        # Check if no code files found
        if result.get("no_code") or not result.get("code_files"):
            self.content.setPlainText("No Code Yet\n\nThis project doesn't contain any code files yet.\n\nCode files include:\n- Objects (.object files with PGSL code)\n- Scripts (.script or .py files)\n- Shaders (.shader files)")
            return
        
        # Format dependency results
        summary = f"Dependency Analysis\n{'='*50}\n\n"
        summary += f"Code Files Analyzed: {len(result.get('code_files', []))}\n\n"
        
        dependencies = result.get('dependencies', {})
        file_imports = result.get('file_imports', {})
        
        if dependencies:
            summary += "Module Dependencies:\n"
            for module, files in list(dependencies.items())[:20]:
                summary += f"  {module}:\n"
                for file in files[:5]:
                    summary += f"    - {file}\n"
                if len(files) > 5:
                    summary += f"    ... and {len(files) - 5} more\n"
            summary += "\n"
        
        if file_imports:
            summary += "File Imports:\n"
            for file_path, imports in list(file_imports.items())[:15]:
                if imports:
                    summary += f"  {file_path}:\n"
                    for imp in imports[:5]:
                        summary += f"    - {imp}\n"
                    if len(imports) > 5:
                        summary += f"    ... and {len(imports) - 5} more\n"
        
        self.content.setPlainText(summary)
    
    def set_project_root(self, project_root):
        """Set the project root for analysis"""
        self.project_root = project_root
        # Auto-run analysis when project root is set
        if project_root:
            QTimer.singleShot(100, self.run_analysis)
    
    def _apply_style(self):
        palette = current_palette()
        self.setStyleSheet(
            f"""
            QLabel {{
                color: {palette["text"]};
            }}
            QTextEdit {{
                background: {palette["bg"]};
                color: {palette["text"]};
                border: 1px solid {palette["panelBorder"]};
                border-radius: 8px;
                padding: 8px;
            }}
            """
        )


class ProjectStructureTab(QWidget):
    """Interactive Project Structure with file tree."""
    def __init__(self, parent=None, project_root=None):
        super().__init__(parent)
        self.project_root = project_root
        layout = QVBoxLayout(self)
        layout.setSpacing(12)
        
        label = QLabel("Project Structure")
        label_font = label.font()
        label_font.setPointSize(12)
        label_font.setBold(True)
        label.setFont(label_font)
        layout.addWidget(label)
        
        # File system model for interactive tree
        self.model = QFileSystemModel()
        self.model.setRootPath("")
        
        # Tree widget
        self.tree = QTreeWidget()
        self.tree.setHeaderLabel("Project Files")
        self.tree.itemDoubleClicked.connect(self.on_item_double_clicked)
        layout.addWidget(self.tree)
        
        self._apply_style()
        self._populate_tree()
    
    def _populate_tree(self):
        """Populate tree with project structure, focusing on Resources folder"""
        self.tree.clear()
        
        if not self.project_root or not Path(self.project_root).exists():
            root_item = QTreeWidgetItem(self.tree, ["No project loaded"])
            self.tree.addTopLevelItem(root_item)
            return
        
        # Build tree structure - show Resources folder prominently
        root_path = Path(self.project_root)
        resources_path = root_path / "Resources"
        
        if resources_path.exists():
            # Show Resources folder as root
            root_item = QTreeWidgetItem(self.tree, ["Resources"])
            root_item.setData(0, Qt.UserRole, str(resources_path))
            self._add_directory(root_item, resources_path)
            self.tree.addTopLevelItem(root_item)
            self.tree.expandItem(root_item)
        else:
            # Fallback to project root if Resources doesn't exist
            root_item = QTreeWidgetItem(self.tree, [root_path.name])
            root_item.setData(0, Qt.UserRole, str(root_path))
            self._add_directory(root_item, root_path)
            self.tree.addTopLevelItem(root_item)
            self.tree.expandItem(root_item)
    
    def _add_directory(self, parent_item, directory_path):
        """Recursively add directory contents to tree, showing resource files"""
        try:
            # Resource file extensions
            resource_extensions = {
                '.sprite', '.model', '.object', '.shader', '.script', 
                '.sound', '.room', '.background', '.texture', '.particle',
                '.pgsl'  # PGSL script files
            }
            
            for item in sorted(directory_path.iterdir()):
                if item.is_dir() and not item.name.startswith('.') and item.name != '__pycache__':
                    dir_item = QTreeWidgetItem(parent_item, [item.name])
                    dir_item.setData(0, Qt.UserRole, str(item))
                    self._add_directory(dir_item, item)
                elif item.is_file():
                    # Show resource files and common code/text files
                    if item.suffix.lower() in resource_extensions or item.suffix.lower() in ['.py', '.json', '.txt', '.md']:
                        file_item = QTreeWidgetItem(parent_item, [item.name])
                        file_item.setData(0, Qt.UserRole, str(item))
        except PermissionError:
            pass
    
    def on_item_double_clicked(self, item, column):
        """Handle double-click on tree item"""
        file_path = item.data(0, Qt.UserRole)
        if file_path and Path(file_path).is_file():
            # Could open file in editor here
            QMessageBox.information(self, "File Selected", f"Selected: {file_path}")
    
    def set_project_root(self, project_root):
        """Set the project root and refresh tree"""
        self.project_root = project_root
        self._populate_tree()
    
    def _apply_style(self):
        palette = current_palette()
        self.setStyleSheet(
            f"""
            QLabel {{
                color: {palette["text"]};
            }}
            QTreeWidget {{
                background: {palette["bg"]};
                color: {palette["text"]};
                border: 1px solid {palette["panelBorder"]};
                border-radius: 8px;
                padding: 8px;
            }}
            QTreeWidget::item {{
                padding: 4px;
            }}
            QTreeWidget::item:hover {{
                background-color: {palette["panelBorder"]};
            }}
            """
        )


class SandboxTab(QWidget):
    """Stub for Sandbox functionality."""
    def __init__(self, parent=None):
        super().__init__(parent)
        layout = QVBoxLayout(self)
        layout.setSpacing(12)
        
        label = QLabel("Sandbox")
        label_font = label.font()
        label_font.setPointSize(12)
        label_font.setBold(True)
        label.setFont(label_font)
        layout.addWidget(label)
        
        info = QLabel("This feature will provide a safe environment for testing code snippets and experimenting with changes.")
        info.setWordWrap(True)
        layout.addWidget(info)
        
        # Stub content area
        content = QTextEdit()
        content.setPlaceholderText("Sandbox environment will be available here...")
        layout.addWidget(content)
        
        # Stub buttons
        btn_layout = QHBoxLayout()
        btn_layout.addStretch()
        run_btn = QPushButton("Run Code")
        run_btn.setEnabled(False)
        clear_btn = QPushButton("Clear")
        clear_btn.setEnabled(False)
        btn_layout.addWidget(clear_btn)
        btn_layout.addWidget(run_btn)
        layout.addLayout(btn_layout)
        
        self._apply_style()
    
    def _apply_style(self):
        palette = current_palette()
        self.setStyleSheet(
            f"""
            QLabel {{
                color: {palette["text"]};
            }}
            QTextEdit {{
                background: {palette["bg"]};
                color: {palette["text"]};
                border: 1px solid {palette["panelBorder"]};
                border-radius: 8px;
                padding: 8px;
            }}
            QPushButton {{
                background-color: {palette["accent"]};
                color: white;
                border: none;
                border-radius: 8px;
                padding: 8px 16px;
                font-weight: 700;
            }}
            QPushButton:hover {{
                background-color: {palette["accentAlt"]};
            }}
            QPushButton:disabled {{
                background-color: {palette["panelBorder"]};
                color: {palette["muted"]};
            }}
            """
        )


class ProjectManagementDialog(QDialog):
    def __init__(self, parent=None, project_root=None):
        super().__init__(parent)
        self.project_root = project_root
        self.setWindowTitle("Project Management")
        self.setModal(False)  # Non-modal so user can keep it open
        self.resize(800, 600)
        palette = current_palette()

        self.setStyleSheet(
            f"""
            QDialog {{
                background-color: {palette["panel"]};
            }}
            QTabWidget::pane {{
                border: 1px solid {palette["panelBorder"]};
                background-color: {palette["panel"]};
            }}
            QTabBar::tab {{
                background-color: {palette["bg"]};
                color: {palette["text"]};
                padding: 10px 20px;
                border-top-left-radius: 4px;
                border-top-right-radius: 4px;
            }}
            QTabBar::tab:selected {{
                background-color: {palette["panel"]};
                border-bottom: 2px solid {palette["accent"]};
            }}
            QPushButton {{
                background-color: {palette["accent"]};
                color: white;
                border: none;
                border-radius: 8px;
                padding: 8px 16px;
                font-weight: 700;
            }}
            QPushButton:hover {{
                background-color: {palette["accentAlt"]};
            }}
            QProgressBar {{
                border: 1px solid {palette["panelBorder"]};
                border-radius: 4px;
                text-align: center;
            }}
            """
        )

        layout = QVBoxLayout(self)
        layout.setSpacing(0)

        # Create tab widget
        tabs = QTabWidget()
        
        # Add tabs with project root
        self.codebase_tab = CodebaseSummaryTab(self, project_root)
        self.dependency_tab = DependencyAnalysisTab(self, project_root)
        self.structure_tab = ProjectStructureTab(self, project_root)
        
        tabs.addTab(self.codebase_tab, "Codebase Summary")
        tabs.addTab(self.dependency_tab, "Dependency Analysis")
        tabs.addTab(self.structure_tab, "Project Structure")
        tabs.addTab(SandboxTab(), "Sandbox")
        
        layout.addWidget(tabs)

        # Close button
        btn_layout = QHBoxLayout()
        btn_layout.addStretch()
        close_btn = QPushButton("Close")
        close_btn.clicked.connect(self.accept)
        btn_layout.addWidget(close_btn)
        layout.addLayout(btn_layout)
    
    def set_project_root(self, project_root):
        """Update project root for all tabs"""
        self.project_root = project_root
        if hasattr(self, 'codebase_tab'):
            self.codebase_tab.set_project_root(project_root)
        if hasattr(self, 'dependency_tab'):
            self.dependency_tab.set_project_root(project_root)
        if hasattr(self, 'structure_tab'):
            self.structure_tab.set_project_root(project_root)

