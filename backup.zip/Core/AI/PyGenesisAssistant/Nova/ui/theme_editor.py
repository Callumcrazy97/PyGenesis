from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QLineEdit,
    QScrollArea, QGridLayout, QColorDialog, QFrame, QDialog
)
from PySide6.QtGui import QColor

from themes import THEMES, current_palette, DEFAULT_THEMES, update_theme


class ColorPicker(QWidget):
    """Widget for selecting a color."""
    colorChanged = None  # Signal placeholder
    
    def __init__(self, color_value: str, label: str, parent=None):
        super().__init__(parent)
        self.color_value = color_value
        self.label_text = label
        
        layout = QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(8)
        
        name_label = QLabel(label)
        name_label.setMinimumWidth(150)
        layout.addWidget(name_label)
        
        self.color_input = QLineEdit()
        self.color_input.setText(color_value)
        self.color_input.setMaximumWidth(100)
        layout.addWidget(self.color_input)
        
        self.color_preview = QFrame()
        self.color_preview.setFixedSize(40, 24)
        self.color_preview.setStyleSheet(f"background-color: {color_value}; border: 1px solid #666; border-radius: 4px;")
        layout.addWidget(self.color_preview)
        
        pick_btn = QPushButton("Pick")
        pick_btn.setMaximumWidth(60)
        pick_btn.clicked.connect(self._pick_color)
        layout.addWidget(pick_btn)
        
        layout.addStretch()
        
        # Connect input change
        self.color_input.textChanged.connect(self._on_text_changed)
    
    def _pick_color(self):
        """Open color picker dialog."""
        current_color = QColor(self.color_value)
        color = QColorDialog.getColor(current_color, self, f"Pick {self.label_text}")
        if color.isValid():
            hex_color = color.name()
            self.color_input.setText(hex_color)
            self._update_preview(hex_color)
    
    def _on_text_changed(self, text: str):
        """Update preview when text changes."""
        if text.startswith('#') and len(text) == 7:
            try:
                QColor(text)  # Validate color
                self._update_preview(text)
                self.color_value = text
            except:
                pass
    
    def _update_preview(self, color: str):
        """Update color preview."""
        self.color_preview.setStyleSheet(f"background-color: {color}; border: 1px solid #666; border-radius: 4px;")
    
    def get_color(self) -> str:
        """Get current color value."""
        return self.color_input.text()


class ThemeEditor(QWidget):
    """Editor for viewing and editing theme properties."""
    def __init__(self, theme_name: str, parent=None):
        super().__init__(parent)
        self.theme_name = theme_name
        self.color_pickers = {}
        
        layout = QVBoxLayout(self)
        layout.setSpacing(12)
        
        # Header
        header = QLabel(f"Editing: {theme_name}")
        header_font = header.font()
        header_font.setPointSize(12)
        header_font.setBold(True)
        header.setFont(header_font)
        layout.addWidget(header)
        
        # Scrollable area for color properties
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setMaximumHeight(400)
        
        content = QWidget()
        content_layout = QGridLayout(content)
        content_layout.setSpacing(8)
        
        if theme_name in THEMES:
            theme = THEMES[theme_name]
            row = 0
            
            # Group properties by category
            categories = {
                "Background": ["bg", "panel", "panelBorder", "inputBg", "shadow"],
                "Text": ["text", "muted"],
                "Accents": ["accent", "accentAlt"],
                "User Messages": ["bubbleUser", "bubbleUserText", "metaUser"],
                "Nova Messages": ["bubbleNova", "bubbleNovaText", "bubbleNovaBorder", "metaNova"],
                "Mode Indicators": ["bubbleNovaAccentLocal", "bubbleNovaAccentCloud"],
            }
            
            for category, keys in categories.items():
                # Category header
                cat_label = QLabel(category)
                cat_font = cat_label.font()
                cat_font.setBold(True)
                cat_label.setFont(cat_font)
                content_layout.addWidget(cat_label, row, 0, 1, 4)
                row += 1
                
                # Color pickers for this category
                for key in keys:
                    if key in theme:
                        picker = ColorPicker(theme[key], key, self)
                        self.color_pickers[key] = picker
                        content_layout.addWidget(picker, row, 0, 1, 4)
                        row += 1
                
                # Spacer after category
                content_layout.addWidget(QWidget(), row, 0, 1, 4)
                row += 1
        
        scroll.setWidget(content)
        layout.addWidget(scroll)
        
        # Buttons
        btn_layout = QHBoxLayout()
        btn_layout.addStretch()
        save_btn = QPushButton("Save Changes")
        cancel_btn = QPushButton("Cancel")
        save_btn.clicked.connect(self._save_changes)
        cancel_btn.clicked.connect(lambda: self.parent().close() if self.parent() else None)
        btn_layout.addWidget(cancel_btn)
        btn_layout.addWidget(save_btn)
        layout.addLayout(btn_layout)
        
        self._apply_style()
    
    def _apply_style(self):
        palette = current_palette()
        self.setStyleSheet(
            f"""
            QLabel {{
                color: {palette["text"]};
            }}
            QLineEdit {{
                background: {palette["bg"]};
                color: {palette["text"]};
                border: 1px solid {palette["panelBorder"]};
                border-radius: 4px;
                padding: 4px;
            }}
            QPushButton {{
                background-color: {palette["accent"]};
                color: white;
                border: none;
                border-radius: 8px;
                padding: 8px 12px;
                font-weight: 700;
            }}
            QPushButton:hover {{
                background-color: {palette["accentAlt"]};
            }}
            QScrollArea {{
                border: 1px solid {palette["panelBorder"]};
                border-radius: 8px;
            }}
            """
        )
    
    def _save_changes(self):
        """Save all color changes to the theme."""
        if self.theme_name not in THEMES:
            return
        
        theme = THEMES[self.theme_name].copy()
        for key, picker in self.color_pickers.items():
            color = picker.get_color()
            if color.startswith('#') and len(color) == 7:
                try:
                    QColor(color)  # Validate
                    theme[key] = color
                except:
                    pass
        
        # Update theme in system (this saves to themes.json)
        update_theme(self.theme_name, theme)
        
        # Close editor dialog
        parent_dialog = self.parent()
        while parent_dialog and not isinstance(parent_dialog, QDialog):
            parent_dialog = parent_dialog.parent()
        if parent_dialog:
            parent_dialog.accept()

