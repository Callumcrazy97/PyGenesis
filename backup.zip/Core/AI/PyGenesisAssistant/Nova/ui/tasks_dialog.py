"""
Tasks Dialog - UI for managing tasks.
Shows tasks with filters (All, Pending, Active, Completed) and allows
reordering, deleting, and starting tasks.
"""
from datetime import datetime
from typing import Optional

from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QFont
from PySide6.QtWidgets import (
    QDialog,
    QVBoxLayout,
    QHBoxLayout,
    QWidget,
    QPushButton,
    QLabel,
    QListWidget,
    QListWidgetItem,
    QFrame,
    QScrollArea,
)

from core.tasks import Task, TaskStatus, TaskManager
from settings import SETTINGS
from themes import current_palette


class TaskItemWidget(QWidget):
    """Widget representing a single task in the list."""
    
    start_requested = Signal(str)  # task_id
    delete_requested = Signal(str)  # task_id
    move_up_requested = Signal(str)  # task_id
    move_down_requested = Signal(str)  # task_id
    
    def __init__(self, task: Task, parent=None):
        super().__init__(parent)
        self.task = task
        self._build_ui()
        self._apply_style()
    
    def _build_ui(self):
        """Build the task item UI."""
        layout = QHBoxLayout(self)
        layout.setContentsMargins(12, 8, 12, 8)
        layout.setSpacing(8)
        
        # Task content
        content_layout = QVBoxLayout()
        content_layout.setSpacing(4)
        
        # Task name
        name_label = QLabel(self.task.name)
        name_font = QFont()
        name_font.setPointSize(10)
        name_font.setWeight(QFont.Bold)
        name_label.setFont(name_font)
        name_label.setStyleSheet("color: #e2e8f0;")
        
        # Strike through if completed
        if self.task.status == TaskStatus.COMPLETED:
            name_label.setStyleSheet("color: #94a3b8; text-decoration: line-through;")
        
        content_layout.addWidget(name_label)
        
        # Task description (if any)
        if self.task.description:
            desc_label = QLabel(self.task.description)
            desc_label.setWordWrap(True)
            desc_font = QFont()
            desc_font.setPointSize(9)
            desc_label.setFont(desc_font)
            desc_label.setStyleSheet("color: #94a3b8;")
            content_layout.addWidget(desc_label)
        
        # Task metadata (status, priority, time)
        meta_label = QLabel(self._format_metadata())
        meta_font = QFont()
        meta_font.setPointSize(8)
        meta_label.setFont(meta_font)
        meta_label.setStyleSheet("color: #64748b;")
        content_layout.addWidget(meta_label)
        
        layout.addLayout(content_layout, 1)
        
        # Action buttons
        button_layout = QHBoxLayout()
        button_layout.setSpacing(4)
        
        # Up/Down buttons - only for pending tasks
        if self.task.status == TaskStatus.PENDING:
            up_btn = QPushButton("↑")
            up_btn.setFixedSize(28, 28)
            up_btn.setToolTip("Move up")
            up_btn.clicked.connect(lambda: self.move_up_requested.emit(self.task.id))
            button_layout.addWidget(up_btn)
            
            down_btn = QPushButton("↓")
            down_btn.setFixedSize(28, 28)
            down_btn.setToolTip("Move down")
            down_btn.clicked.connect(lambda: self.move_down_requested.emit(self.task.id))
            button_layout.addWidget(down_btn)
        
        # Start Now button - only for pending tasks
        if self.task.status == TaskStatus.PENDING:
            start_btn = QPushButton("Start Now")
            start_btn.setFixedSize(70, 28)
            start_btn.clicked.connect(lambda: self.start_requested.emit(self.task.id))
            button_layout.addWidget(start_btn)
        
        # Delete button - only for completed tasks
        if self.task.status == TaskStatus.COMPLETED:
            delete_btn = QPushButton("Delete")
            delete_btn.setFixedSize(60, 28)
            delete_btn.setToolTip("Delete task")
            delete_btn.clicked.connect(lambda: self.delete_requested.emit(self.task.id))
            button_layout.addWidget(delete_btn)
        
        layout.addLayout(button_layout)
    
    def _format_metadata(self) -> str:
        """Format task metadata for display."""
        parts = []
        parts.append(self.task.status.value.upper())
        parts.append(self.task.priority.value.upper())
        if self.task.created_at:
            time_str = self.task.created_at.strftime("%H:%M:%S")
            parts.append(time_str)
        return " • ".join(parts)
    
    def _apply_style(self):
        """Apply styling to task item."""
        palette = current_palette()
        status_colors = {
            TaskStatus.PENDING: palette.get("muted", "#94a3b8"),
            TaskStatus.ACTIVE: palette.get("accent", "#3b82f6"),
            TaskStatus.COMPLETED: palette.get("muted", "#64748b"),
        }
        
        self.setStyleSheet(
            f"""
            QWidget {{
                background-color: {palette.get("panel", "#111827")};
                border-radius: 8px;
            }}
            QPushButton {{
                background-color: {palette.get("accent", "#3b82f6")};
                color: white;
                border: none;
                border-radius: 4px;
                font-size: 10px;
                font-weight: bold;
            }}
            QPushButton:hover {{
                background-color: {palette.get("accentAlt", "#2563eb")};
            }}
            QPushButton:pressed {{
                background-color: {palette.get("accentAlt", "#2563eb")};
            }}
            """
        )


class TasksDialog(QDialog):
    """Dialog for managing tasks."""
    
    def __init__(self, task_manager: TaskManager, parent=None):
        super().__init__(parent)
        self.task_manager = task_manager
        self.current_filter: Optional[TaskStatus] = None
        
        self.setWindowTitle("Tasks")
        self.resize(800, 600)
        self._build_ui()
        self._apply_style()
        self._refresh_tasks()
    
    def _build_ui(self):
        """Build the dialog UI."""
        layout = QVBoxLayout(self)
        layout.setContentsMargins(16, 16, 16, 16)
        layout.setSpacing(12)
        
        # Header with filters
        header_layout = QHBoxLayout()
        header_layout.setSpacing(8)
        
        filter_label = QLabel("Filter:")
        filter_label.setStyleSheet("color: #e2e8f0; font-weight: bold;")
        header_layout.addWidget(filter_label)
        
        # Filter buttons
        self.filter_all_btn = QPushButton("All")
        self.filter_all_btn.setCheckable(True)
        self.filter_all_btn.setChecked(True)
        self.filter_all_btn.clicked.connect(lambda: self._set_filter(None))
        
        self.filter_pending_btn = QPushButton("Pending")
        self.filter_pending_btn.setCheckable(True)
        self.filter_pending_btn.clicked.connect(lambda: self._set_filter(TaskStatus.PENDING))
        
        self.filter_active_btn = QPushButton("Active")
        self.filter_active_btn.setCheckable(True)
        self.filter_active_btn.clicked.connect(lambda: self._set_filter(TaskStatus.ACTIVE))
        
        self.filter_completed_btn = QPushButton("Completed")
        self.filter_completed_btn.setCheckable(True)
        self.filter_completed_btn.clicked.connect(lambda: self._set_filter(TaskStatus.COMPLETED))
        
        for btn in [self.filter_all_btn, self.filter_pending_btn, self.filter_active_btn, self.filter_completed_btn]:
            btn.setFixedSize(100, 32)
            header_layout.addWidget(btn)
        
        header_layout.addStretch()
        layout.addLayout(header_layout)
        
        # Task list
        self.task_list = QListWidget()
        self.task_list.setSpacing(4)
        layout.addWidget(self.task_list, 1)
        
        # Footer with close button
        footer_layout = QHBoxLayout()
        footer_layout.addStretch()
        
        close_btn = QPushButton("Close")
        close_btn.setFixedSize(100, 32)
        close_btn.clicked.connect(self.accept)
        footer_layout.addWidget(close_btn)
        
        layout.addLayout(footer_layout)
    
    def _set_filter(self, status: Optional[TaskStatus]):
        """Set the current filter."""
        self.current_filter = status
        
        # Update button states
        self.filter_all_btn.setChecked(status is None)
        self.filter_pending_btn.setChecked(status == TaskStatus.PENDING)
        self.filter_active_btn.setChecked(status == TaskStatus.ACTIVE)
        self.filter_completed_btn.setChecked(status == TaskStatus.COMPLETED)
        
        self._refresh_tasks()
    
    def _refresh_tasks(self):
        """Refresh the task list."""
        self.task_list.clear()
        
        # Get filtered tasks
        if self.current_filter:
            tasks = self.task_manager.get_tasks(status=self.current_filter)
        else:
            tasks = self.task_manager.tasks
        
        # Add tasks to list
        for task in tasks:
            item = QListWidgetItem()
            item.setSizeHint(TaskItemWidget(task).sizeHint())
            
            task_widget = TaskItemWidget(task)
            task_widget.start_requested.connect(self._on_start_task)
            task_widget.delete_requested.connect(self._on_delete_task)
            task_widget.move_up_requested.connect(self._on_move_up)
            task_widget.move_down_requested.connect(self._on_move_down)
            
            self.task_list.addItem(item)
            self.task_list.setItemWidget(item, task_widget)
    
    def _on_start_task(self, task_id: str):
        """Handle start task request."""
        self.task_manager.start_task(task_id)
        self._refresh_tasks()
    
    def _on_delete_task(self, task_id: str):
        """Handle delete task request."""
        self.task_manager.delete_task(task_id)
        self._refresh_tasks()
    
    def _on_move_up(self, task_id: str):
        """Handle move up request."""
        # Always work with full task list for reordering
        all_tasks = self.task_manager.tasks
        
        # Find current index in the full task list
        current_index = None
        for i, task in enumerate(all_tasks):
            if task.id == task_id:
                current_index = i
                break
        
        if current_index is not None and current_index > 0:
            task = self.task_manager.get_task(task_id)
            if task and task.status == TaskStatus.PENDING:
                # Get previous task
                prev_task = all_tasks[current_index - 1]
                # Only swap if previous task is also pending
                if prev_task.status == TaskStatus.PENDING:
                    # Swap positions in task manager
                    self.task_manager.reorder_task(task_id, current_index - 1)
                    self.task_manager.reorder_task(prev_task.id, current_index)
                    self._refresh_tasks()
    
    def _on_move_down(self, task_id: str):
        """Handle move down request."""
        # Always work with full task list for reordering
        all_tasks = self.task_manager.tasks
        
        # Find current index in the full task list
        current_index = None
        for i, task in enumerate(all_tasks):
            if task.id == task_id:
                current_index = i
                break
        
        if current_index is not None and current_index < len(all_tasks) - 1:
            task = self.task_manager.get_task(task_id)
            if task and task.status == TaskStatus.PENDING:
                # Get next task
                next_task = all_tasks[current_index + 1]
                # Only swap if next task is also pending
                if next_task.status == TaskStatus.PENDING:
                    # Swap positions in task manager
                    self.task_manager.reorder_task(task_id, current_index + 1)
                    self.task_manager.reorder_task(next_task.id, current_index)
                    self._refresh_tasks()
    
    
    def _apply_style(self):
        """Apply styling to dialog."""
        palette = current_palette()
        self.setStyleSheet(
            f"""
            QDialog {{
                background-color: {palette.get("bg", "#0f172a")};
            }}
            QListWidget {{
                background-color: {palette.get("panel", "#111827")};
                border: 1px solid {palette.get("panelBorder", "#1e293b")};
                border-radius: 8px;
            }}
            QListWidget::item {{
                border: none;
                padding: 4px;
            }}
            QPushButton {{
                background-color: {palette.get("panel", "#111827")};
                color: {palette.get("text", "#e2e8f0")};
                border: 1px solid {palette.get("panelBorder", "#1e293b")};
                border-radius: 4px;
                padding: 6px 12px;
            }}
            QPushButton:hover {{
                background-color: {palette.get("accent", "#3b82f6")};
                color: white;
            }}
            QPushButton:checked {{
                background-color: {palette.get("accent", "#3b82f6")};
                color: white;
            }}
            QLabel {{
                color: {palette.get("text", "#e2e8f0")};
            }}
            """
        )

