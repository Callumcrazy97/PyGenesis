from datetime import datetime

from PySide6.QtCore import Qt, QTimer
from PySide6.QtWidgets import (
    QMainWindow,
    QWidget,
    QVBoxLayout,
    QFrame,
    QDialog,
)

from core.models import ChatMessage, Sender, ClarificationContext
from core.workflow import WorkflowPipeline
from core.tasks import TaskManager
from core.conversations import ConversationManager
from settings import SETTINGS
from themes import current_palette
from ui.chat_view import ChatView
from ui.header import Header
from ui.input_bar import InputBar
from ui.settings_dialog import SettingsDialog
from ui.project_management_dialog import ProjectManagementDialog
from ui.tasks_dialog import TasksDialog
from ui.conversations_dialog import ConversationsDialog


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Nova Shell (Python)")
        self.resize(1120, 760)

        self._apply_root_style()

        root = QWidget()
        root_layout = QVBoxLayout(root)
        root_layout.setContentsMargins(0, 0, 0, 0)
        root_layout.setSpacing(0)

        # Initialize task manager
        self.task_manager = TaskManager()
        
        # Initialize conversation manager
        self.conversation_manager = ConversationManager()
        # Create or load current conversation
        current_conv = self.conversation_manager.create_conversation()
        self.conversation_manager.set_current_conversation(current_conv.id)
        
        self.header = Header(
            self._open_settings,
            self._handle_mode_toggle,
            self._open_project_management,
            self._open_tasks,
            self._open_conversations,
            app=self.app,
            conversation_manager=self.conversation_manager
        )
        root_layout.addWidget(self.header)
        
        # Initialize thinking status to idle
        self.header.update_thinking_status()
        # Initialize global star button
        self.header.update_global_star()

        # Chat area - directly on background, no frame
        chat_container = QWidget()
        chat_layout = QVBoxLayout(chat_container)
        chat_layout.setContentsMargins(32, 16, 32, 16)  # More padding like Nova Web
        chat_layout.setSpacing(16)

        self.chat_view = ChatView(app=None)  # Standalone mode - no app instance
        chat_layout.addWidget(self.chat_view, 1)

        self.input_bar = InputBar()
        self.input_bar.sendRequested.connect(self._handle_send)
        chat_layout.addWidget(self.input_bar)

        root_layout.addWidget(chat_container, 1)
        self.setCentralWidget(root)

        # Initialize workflow pipeline with task manager and project root
        import os
        project_root = os.getcwd()  # Use current working directory as project root
        self.workflow = WorkflowPipeline(
            task_manager=self.task_manager,
            project_root=project_root,
            app=None  # Standalone mode - no app instance
        )
        self._register_executors()
        
        # Track pending clarification context
        self.pending_clarification: Optional[ClarificationContext] = None
        
        self._seed_greeting()
    
    def _register_executors(self):
        """Register all executors and engines with the workflow pipeline."""
        from core.executors.code_query_executor import CodeQueryExecutor
        from core.executors.project_modification_executor import ProjectModificationExecutor
        from core.executors.resource_operation_executor import ResourceOperationExecutor
        from core.executors.graph_visualization_executor import GraphVisualizationExecutor
        from core.engines.conversation_engine import ConversationEngine
        from core.engines.math_engine import MathEngine
        from core.engines.research_engine import ResearchEngine
        from core.engines.dictionary_engine import DictionaryEngine
        from core.engines.thesaurus_engine import ThesaurusEngine
        from core.models import Intent
        
        # Register engines (preferred for specialized processing)
        self.workflow.register_engine(Intent.GENERAL_CHAT, ConversationEngine())
        self.workflow.register_engine(Intent.MATH_QUERY, MathEngine())
        self.workflow.register_engine(Intent.RESEARCH_QUERY, ResearchEngine())
        self.workflow.register_engine(Intent.DICTIONARY_LOOKUP, DictionaryEngine())
        self.workflow.register_engine(Intent.THESAURUS_LOOKUP, ThesaurusEngine())
        
        # Register executors (for code/project operations)
        self.workflow.register_executor(Intent.CODE_QUERY, CodeQueryExecutor())
        self.workflow.register_executor(Intent.PROJECT_MODIFICATION, ProjectModificationExecutor())
        # Note: ResourceOperationExecutor needs app context, so it's registered in NovaWidget
        self.workflow.register_executor(Intent.GRAPH_VISUALIZATION, GraphVisualizationExecutor())

    def _apply_root_style(self):
        palette = current_palette()
        self.setStyleSheet(
            f"""
            QMainWindow {{
                background-color: {palette["bg"]};
            }}
            """
        )

    def _apply_theme(self):
        """Refresh all UI components when theme changes."""
        self._apply_root_style()
        self.header.refresh_style()
        self.chat_view.refresh_style()
        self.input_bar.refresh_style()
        # Re-render existing chat bubbles with new theme
        self.chat_view.refresh_bubbles()

    def _seed_greeting(self):
        self.chat_view.add_message(
            ChatMessage(
                sender=Sender.NOVA,
                text="Hello! I'm Nova. This is the Python UI shell — no cloud logic yet.",
                timestamp=datetime.now(),
            )
        )

    def _handle_send(self, text: str):
        """Handle user message through workflow pipeline."""
        now = datetime.now()
        user_message = ChatMessage(sender=Sender.USER, text=text, timestamp=now)
        self.chat_view.add_message(user_message)
        
        # Store in current conversation
        current_conv = self.conversation_manager.get_current_conversation()
        if current_conv:
            self.conversation_manager.add_message(current_conv.id, user_message)
                    # Update conversation summary after first user message
                    if len(current_conv.messages) == 1:
                        # Pass intent_router for smart naming
                        self.conversation_manager.update_conversation_summary(
                            current_conv.id, 
                            intent_router=self.workflow.intent_router
                        )
                    # Update global star button (in case conversation was just created)
                    if self.header:
                        self.header.update_global_star()
        
        # Disable input while processing
        self.input_bar.editor.setEnabled(False)
        self.input_bar.send_button.setEnabled(False)
        
        # Show "Nova is thinking..." status and process Qt events to update UI
        self.input_bar.show_status("Nova is thinking...", animated=True)
        QTimer.singleShot(0, lambda: None)  # Force event processing
        
        # Process through workflow pipeline (async simulation for UX)
        def process_workflow():
            try:
                # Process Qt events to ensure UI updates
                from PySide6.QtWidgets import QApplication
                QApplication.processEvents()
                
                # Get intent classification first (for thinking status display)
                # This is called before workflow.process to show thinking status immediately
                intent_result = self.workflow.intent_router.classify(text, self.pending_clarification)
                
                # Update thinking status with actual intent and confidence
                if intent_result and intent_result.primary_intent:
                    self.header.update_thinking_status(
                        intent_result.primary_intent.value,
                        intent_result.confidence
                    )
                    QApplication.processEvents()  # Update UI
                
                # Show "Nova is typing..." when starting to generate response
                self.input_bar.show_status("Nova is typing...", animated=True)
                QApplication.processEvents()  # Update UI
                
                # Get conversation history for context awareness
                conversation_history = []
                current_conv = self.conversation_manager.get_current_conversation()
                if current_conv:
                    # Get recent messages (excluding the one we just added)
                    conversation_history = current_conv.messages[:-1] if len(current_conv.messages) > 1 else []
                    # Reverse to get chronological order (oldest first)
                    conversation_history = list(reversed(conversation_history))
                
                # Process through workflow (pass clarification context and conversation history)
                # Note: workflow.process will call classify again internally, but that's okay
                # We call it here first to show thinking status immediately
                context = self.workflow.process(text, self.pending_clarification, conversation_history)
                
                # Clear pending clarification after processing
                if self.pending_clarification:
                    self.pending_clarification = None
                
                # Display result
                response_text = context.result or "I'm processing your request..."
                
                # Check if this is a clarification request
                clarification_context = None
                if hasattr(context, 'clarification_context') and context.clarification_context:
                    clarification_context = context.clarification_context
                    # Store for next message
                    self.pending_clarification = clarification_context
                
                # Hide status notification before showing message
                self.input_bar.hide_status()
                
                nova_message = ChatMessage(
                    sender=Sender.NOVA,
                    text=response_text,
                    timestamp=datetime.now(),
                    clarification_context=clarification_context,
                    intent=context.intent  # Store intent for context awareness
                )
                self.chat_view.add_message(nova_message)
                
                # Store in current conversation
                current_conv = self.conversation_manager.get_current_conversation()
                if current_conv:
                    self.conversation_manager.add_message(current_conv.id, nova_message)
                
                # Reset thinking status to idle after response
                self.header.update_thinking_status()
                
                # TODO: Update Project Management dialog if file changes occurred
                # if context.file_changes:
                #     self._update_project_management(context.file_changes)
                
            except Exception as e:
                # Error handling with full traceback for debugging
                import traceback
                error_msg = str(e) if str(e) else type(e).__name__
                traceback_str = traceback.format_exc()
                
                # Hide status notification
                self.input_bar.hide_status()
                
                # Show user-friendly error message
                error_text = f"Error processing request: {error_msg}"
                if "sympy" in error_msg.lower() or "numpy" in error_msg.lower():
                    error_text += "\n\nPlease install required dependencies:\npip install sympy numpy"
                
                self.chat_view.add_message(
                    ChatMessage(
                        sender=Sender.NOVA,
                        text=error_text,
                        timestamp=datetime.now(),
                    )
                )
                
                # Reset thinking status
                self.header.update_thinking_status()
                
                # Print full traceback to console for debugging
                print(f"Workflow Error:\n{traceback_str}")
            finally:
                # Re-enable input
                self.input_bar.editor.setEnabled(True)
                self.input_bar.send_button.setEnabled(True)
                self.input_bar.editor.setFocus()
        
        # Use QTimer to process workflow asynchronously (non-blocking)
        # This allows UI to update and show status notifications
        QTimer.singleShot(100, process_workflow)

    def _handle_mode_toggle(self, mode: str):
        """Handle mode toggle between Local and Cloud."""
        # This will be used when AI logic is implemented
        pass

    def _open_project_management(self):
        """Open Project Management dialog."""
        dialog = ProjectManagementDialog(self)
        dialog.exec()
    
    def _open_tasks(self):
        """Open Tasks dialog."""
        dialog = TasksDialog(self.task_manager, self)
        dialog.exec()
    
    def _open_conversations(self):
        """Open Conversations dialog."""
        dialog = ConversationsDialog(self.conversation_manager, self)
        dialog.conversation_selected.connect(self._on_conversation_selected)
        dialog.conversation_deleted.connect(self._on_conversation_deleted)
        dialog.exec()
    
    def _on_conversation_deleted(self, conversation_id: str):
        """Handle conversation deletion."""
        # If the deleted conversation was the current one, ensure a new one exists
        if self.conversation_manager.current_conversation_id == conversation_id or self.conversation_manager.current_conversation_id is None:
            # Clear the current chat view
            self.chat_view.messages.clear()
            self.chat_view.bubbles.clear()
            while self.chat_view.layout.count() > 1:
                item = self.chat_view.layout.takeAt(0)
                if item.widget():
                    item.widget().deleteLater()
            
            # Ensure a conversation exists (this will create one if all are deleted)
            current = self.conversation_manager.ensure_conversation_exists()
            if current:
                self.conversation_manager.set_current_conversation(current.id)
                # Update global star button
                if self.header:
                    self.header.update_global_star()
    
    def _on_conversation_selected(self, conversation_id: str):
        """Handle conversation selection."""
        # Load conversation and display messages
        conversation = self.conversation_manager.get_conversation(conversation_id)
        if conversation:
            self.conversation_manager.set_current_conversation(conversation_id)
            # Update global star button
            if self.header:
                self.header.update_global_star()
            # Clear chat view and load conversation messages
            self.chat_view.messages.clear()
            self.chat_view.bubbles.clear()
            # Clear layout (keep stretch at end)
            while self.chat_view.layout.count() > 1:  # Keep the final stretch
                item = self.chat_view.layout.takeAt(0)
                if item.widget():
                    item.widget().deleteLater()
            
            # Load messages
            for msg_data in conversation.messages:
                from datetime import datetime
                timestamp = datetime.fromisoformat(msg_data["timestamp"])
                sender = Sender[msg_data["sender"]]
                message = ChatMessage(
                    sender=sender,
                    text=msg_data["text"],
                    timestamp=timestamp,
                    thinking_content=msg_data.get("thinking_content")
                )
                self.chat_view.add_message(message)

    def _open_settings(self):
        dialog = SettingsDialog(self)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            SETTINGS.DefaultTheme = dialog.selected_theme()
            self._apply_theme()
            # Refresh header to update theme styling
            self.header.refresh_style()
            # Update thinking status visibility if setting changed
            self.header.update_thinking_status()

