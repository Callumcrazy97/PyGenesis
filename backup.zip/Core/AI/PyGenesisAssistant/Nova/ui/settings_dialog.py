from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QComboBox,
    QTabWidget, QWidget, QListWidget, QListWidgetItem, QLineEdit, QMessageBox, QDialogButtonBox, QCheckBox
)

from settings import SETTINGS
from themes import THEMES, current_palette, add_custom_theme, remove_custom_theme, rename_theme


class AppearanceTab(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        palette = current_palette()
        
        layout = QVBoxLayout(self)
        layout.setSpacing(12)
        
        # Theme selection
        theme_row = QHBoxLayout()
        theme_row.addWidget(QLabel("Current Theme:"))
        self.theme_combo = QComboBox()
        self.theme_combo.addItems(sorted(THEMES.keys()))
        self.theme_combo.setCurrentText(SETTINGS.DefaultTheme)
        self.theme_combo.currentTextChanged.connect(self._on_theme_selected)
        theme_row.addWidget(self.theme_combo)
        theme_row.addStretch()
        layout.addLayout(theme_row)
        
        # Theme list with add/delete/edit
        list_label = QLabel("Available Themes:")
        layout.addWidget(list_label)
        
        self.theme_list = QListWidget()
        self.theme_list.setMaximumHeight(150)
        self._populate_theme_list()
        # Single click selects theme (updates combo box)
        self.theme_list.itemClicked.connect(self._on_theme_list_clicked)
        # Double click opens theme editor
        self.theme_list.itemDoubleClicked.connect(self._edit_theme_properties)
        layout.addWidget(self.theme_list)
        
        # Buttons for theme management
        btn_row = QHBoxLayout()
        add_btn = QPushButton("+ Add Theme")
        add_btn.clicked.connect(self._add_theme)
        edit_props_btn = QPushButton("Edit Properties")
        edit_props_btn.clicked.connect(self._edit_theme_properties)
        rename_btn = QPushButton("Rename")
        rename_btn.clicked.connect(self._rename_theme)
        delete_btn = QPushButton("Delete")
        delete_btn.clicked.connect(self._delete_theme)
        
        btn_row.addWidget(add_btn)
        btn_row.addWidget(edit_props_btn)
        btn_row.addWidget(rename_btn)
        btn_row.addWidget(delete_btn)
        btn_row.addStretch()
        layout.addLayout(btn_row)
        
        layout.addStretch()
        
        self._apply_style(palette)
    
    def _apply_style(self, palette):
        self.setStyleSheet(
            f"""
            QLabel {{
                color: {palette["text"]};
            }}
            QComboBox {{
                background: {palette["bg"]};
                color: {palette["text"]};
                border: 1px solid {palette["panelBorder"]};
                border-radius: 8px;
                padding: 6px;
            }}
            QListWidget {{
                background: {palette["bg"]};
                color: {palette["text"]};
                border: 1px solid {palette["panelBorder"]};
                border-radius: 8px;
            }}
            QPushButton {{
                background-color: {palette["accent"]};
                color: white;
                border: none;
                border-radius: 8px;
                padding: 8px 12px;
                font-weight: 700;
            }}
            QPushButton:hover {{
                background-color: {palette["accentAlt"]};
            }}
            """
        )
    
    def _populate_theme_list(self):
        """Populate the theme list widget."""
        self.theme_list.clear()
        for theme_name in sorted(THEMES.keys()):
            item = QListWidgetItem(theme_name)
            # Mark default themes as non-editable (visual distinction)
            from themes import DEFAULT_THEMES
            if theme_name in DEFAULT_THEMES:
                item.setToolTip("Default theme (cannot be deleted)")
            self.theme_list.addItem(item)
    
    def _on_theme_selected(self, theme_name: str):
        """Handle theme selection change from combo box."""
        SETTINGS.DefaultTheme = theme_name
        SETTINGS.save()  # Persist theme selection
        # Update list selection to match
        for i in range(self.theme_list.count()):
            item = self.theme_list.item(i)
            if item.text() == theme_name:
                self.theme_list.setCurrentItem(item)
                break
    
    def _on_theme_list_clicked(self, item: QListWidgetItem):
        """Handle single click on theme list - select the theme."""
        theme_name = item.text()
        # Update combo box
        self.theme_combo.setCurrentText(theme_name)
        # Update settings
        SETTINGS.DefaultTheme = theme_name
        SETTINGS.save()  # Persist theme selection
        # Refresh UI to show new theme
        from themes import current_palette
        palette = current_palette()
        self._apply_style(palette)
    
    def _add_theme(self):
        """Add a new custom theme."""
        dialog = QDialog(self)
        dialog.setWindowTitle("Add New Theme")
        dialog.setModal(True)
        
        layout = QVBoxLayout(dialog)
        
        name_label = QLabel("Theme Name:")
        name_input = QLineEdit()
        name_input.setPlaceholderText("Enter theme name...")
        
        layout.addWidget(name_label)
        layout.addWidget(name_input)
        
        btn_layout = QHBoxLayout()
        cancel_btn = QPushButton("Cancel")
        create_btn = QPushButton("Create")
        cancel_btn.clicked.connect(dialog.reject)
        create_btn.clicked.connect(dialog.accept)
        create_btn.setDefault(True)
        
        btn_layout.addStretch()
        btn_layout.addWidget(cancel_btn)
        btn_layout.addWidget(create_btn)
        layout.addLayout(btn_layout)
        
        if dialog.exec() == QDialog.DialogCode.Accepted:
            theme_name = name_input.text().strip()
            if not theme_name:
                QMessageBox.warning(self, "Invalid Name", "Theme name cannot be empty.")
                return
            
            if theme_name in THEMES:
                QMessageBox.warning(self, "Duplicate", f"Theme '{theme_name}' already exists.")
                return
            
            # Create a new theme based on current theme
            current_theme = THEMES[SETTINGS.DefaultTheme].copy()
            add_custom_theme(theme_name, current_theme)  # This saves to themes.json
            self._populate_theme_list()
            self.theme_combo.addItem(theme_name)
            self.theme_combo.setCurrentText(theme_name)
            # Update settings to use new theme
            SETTINGS.DefaultTheme = theme_name
            SETTINGS.save()
    
    def _delete_theme(self):
        """Delete the selected theme."""
        current_item = self.theme_list.currentItem()
        if not current_item:
            QMessageBox.warning(self, "No Selection", "Please select a theme to delete.")
            return
        
        theme_name = current_item.text()
        
        # Prevent deleting default themes
        from themes import DEFAULT_THEMES
        if theme_name in DEFAULT_THEMES:
            QMessageBox.warning(self, "Cannot Delete", "Default themes cannot be deleted.")
            return
        
        reply = QMessageBox.question(
            self, "Confirm Delete",
            f"Are you sure you want to delete the theme '{theme_name}'?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        )
        
        if reply == QMessageBox.StandardButton.Yes:
            remove_custom_theme(theme_name)
            self._populate_theme_list()
            self.theme_combo.removeItem(self.theme_combo.findText(theme_name))
            
            # If deleted theme was selected, switch to default
            if SETTINGS.DefaultTheme == theme_name:
                SETTINGS.DefaultTheme = "slate"
                self.theme_combo.setCurrentText("slate")
    
    def _rename_theme(self):
        """Rename the selected theme."""
        current_item = self.theme_list.currentItem()
        if not current_item:
            QMessageBox.warning(self, "No Selection", "Please select a theme to rename.")
            return
        
        theme_name = current_item.text()
        self._edit_theme_name(current_item)
    
    def _edit_theme_properties(self, item=None):
        """Open theme editor for selected theme."""
        if isinstance(item, QListWidgetItem):
            theme_name = item.text()
        else:
            current_item = self.theme_list.currentItem()
            if not current_item:
                QMessageBox.warning(self, "No Selection", "Please select a theme to edit.")
                return
            theme_name = current_item.text()
        
        # Open theme editor dialog
        from ui.theme_editor import ThemeEditor
        editor_dialog = QDialog(self)
        editor_dialog.setWindowTitle(f"Edit Theme: {theme_name}")
        editor_dialog.setModal(True)
        editor_dialog.resize(600, 500)
        
        editor_layout = QVBoxLayout(editor_dialog)
        editor = ThemeEditor(theme_name, editor_dialog)
        editor_layout.addWidget(editor)
        
        if editor_dialog.exec() == QDialog.DialogCode.Accepted:
            # Theme was saved, refresh if needed
            self._populate_theme_list()
            # Notify parent to refresh UI
            if hasattr(self.parent(), 'parent') and hasattr(self.parent().parent(), '_apply_theme'):
                self.parent().parent()._apply_theme()
    
    def _edit_theme_name(self, item: QListWidgetItem):
        """Edit theme name inline."""
        old_name = item.text()
        
        # Prevent renaming default themes
        from themes import DEFAULT_THEMES
        if old_name in DEFAULT_THEMES:
            QMessageBox.warning(self, "Cannot Rename", "Default themes cannot be renamed.")
            return
        
        dialog = QDialog(self)
        dialog.setWindowTitle("Rename Theme")
        dialog.setModal(True)
        
        layout = QVBoxLayout(dialog)
        
        name_label = QLabel("New Theme Name:")
        name_input = QLineEdit()
        name_input.setText(old_name)
        name_input.selectAll()
        
        layout.addWidget(name_label)
        layout.addWidget(name_input)
        
        btn_layout = QHBoxLayout()
        cancel_btn = QPushButton("Cancel")
        rename_btn = QPushButton("Rename")
        cancel_btn.clicked.connect(dialog.reject)
        rename_btn.clicked.connect(dialog.accept)
        rename_btn.setDefault(True)
        
        btn_layout.addStretch()
        btn_layout.addWidget(cancel_btn)
        btn_layout.addWidget(rename_btn)
        layout.addLayout(btn_layout)
        
        if dialog.exec() == QDialog.DialogCode.Accepted:
            new_name = name_input.text().strip()
            if not new_name:
                QMessageBox.warning(self, "Invalid Name", "Theme name cannot be empty.")
                return
            
            if new_name in THEMES and new_name != old_name:
                QMessageBox.warning(self, "Duplicate", f"Theme '{new_name}' already exists.")
                return
            
            rename_theme(old_name, new_name)
            self._populate_theme_list()
            
            # Update combo box
            combo_index = self.theme_combo.findText(old_name)
            if combo_index >= 0:
                self.theme_combo.setItemText(combo_index, new_name)
            
            # Update selected theme if it was renamed
            if SETTINGS.DefaultTheme == old_name:
                SETTINGS.DefaultTheme = new_name
                self.theme_combo.setCurrentText(new_name)


class GeneralTab(QWidget):
    """General settings tab."""
    def __init__(self, parent=None):
        super().__init__(parent)
        palette = current_palette()
        
        layout = QVBoxLayout(self)
        layout.setSpacing(16)
        
        # Show Thinking option
        thinking_row = QHBoxLayout()
        self.show_thinking_checkbox = QCheckBox("Show Thinking Status")
        self.show_thinking_checkbox.setChecked(SETTINGS.ShowThinking)
        self.show_thinking_checkbox.setToolTip("Display intent and confidence in header when enabled")
        thinking_row.addWidget(self.show_thinking_checkbox)
        thinking_row.addStretch()
        layout.addLayout(thinking_row)
        
        # Enter to Send option
        enter_row = QHBoxLayout()
        self.enter_to_send_checkbox = QCheckBox("Enable Enter to Send")
        self.enter_to_send_checkbox.setChecked(SETTINGS.EnableEnterToSend)
        self.enter_to_send_checkbox.setToolTip("Press Enter to send message (Shift+Enter for new line)")
        enter_row.addWidget(self.enter_to_send_checkbox)
        enter_row.addStretch()
        layout.addLayout(enter_row)
        
        layout.addStretch()
        
        self._apply_style(palette)
    
    def _apply_style(self, palette):
        self.setStyleSheet(
            f"""
            QLabel {{
                color: {palette["text"]};
            }}
            QCheckBox {{
                color: {palette["text"]};
                font-size: 12px;
            }}
            QCheckBox::indicator {{
                width: 18px;
                height: 18px;
                border: 2px solid {palette["panelBorder"]};
                border-radius: 4px;
                background-color: {palette["bg"]};
            }}
            QCheckBox::indicator:checked {{
                background-color: {palette["accent"]};
                border-color: {palette["accent"]};
            }}
            """
        )


class SettingsDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Settings")
        self.setModal(True)
        self.resize(500, 400)
        palette = current_palette()

        self.setStyleSheet(
            f"""
            QDialog {{
                background-color: {palette["panel"]};
            }}
            QTabWidget::pane {{
                border: 1px solid {palette["panelBorder"]};
                background-color: {palette["panel"]};
            }}
            QTabBar::tab {{
                background-color: {palette["bg"]};
                color: {palette["text"]};
                padding: 8px 16px;
                border-top-left-radius: 4px;
                border-top-right-radius: 4px;
            }}
            QTabBar::tab:selected {{
                background-color: {palette["panel"]};
                border-bottom: 2px solid {palette["accent"]};
            }}
            QPushButton {{
                background-color: {palette["accent"]};
                color: white;
                border: none;
                border-radius: 10px;
                padding: 10px 14px;
                font-weight: 700;
            }}
            QPushButton#cancel {{
                background-color: {palette["panelBorder"]};
                color: {palette["text"]};
            }}
            """
        )

        layout = QVBoxLayout(self)
        layout.setSpacing(12)

        # Create tab widget
        tabs = QTabWidget()
        
        # General tab
        self.general_tab = GeneralTab()
        tabs.addTab(self.general_tab, "General")
        
        # Appearance tab
        self.appearance_tab = AppearanceTab()
        tabs.addTab(self.appearance_tab, "Appearance")
        
        layout.addWidget(tabs)

        # Buttons
        buttons = QHBoxLayout()
        buttons.addStretch()
        save = QPushButton("Save")
        cancel = QPushButton("Cancel")
        cancel.setObjectName("cancel")
        save.clicked.connect(self._save_settings)
        cancel.clicked.connect(self.reject)
        buttons.addWidget(cancel)
        buttons.addWidget(save)

        layout.addLayout(buttons)
    
    def _save_settings(self):
        """Save settings before accepting dialog."""
        # Save General tab settings
        SETTINGS.ShowThinking = self.general_tab.show_thinking_checkbox.isChecked()
        SETTINGS.EnableEnterToSend = self.general_tab.enter_to_send_checkbox.isChecked()
        
        # Save all settings
        SETTINGS.save()
        
        # Accept dialog
        self.accept()
    
    def showEvent(self, event):
        """Refresh theme list when dialog is shown."""
        from themes import THEMES
        super().showEvent(event)
        if hasattr(self, 'appearance_tab'):
            self.appearance_tab._populate_theme_list()
            # Update combo box
            self.appearance_tab.theme_combo.clear()
            self.appearance_tab.theme_combo.addItems(sorted(THEMES.keys()))
            self.appearance_tab.theme_combo.setCurrentText(SETTINGS.DefaultTheme)

    def selected_theme(self) -> str:
        return SETTINGS.DefaultTheme
