from PySide6.QtWidgets import QWidget, QHBoxLayout, QLabel, QPushButton, QVBoxLayout
from PySide6.QtGui import QFont

from settings import SETTINGS
from themes import current_palette

class Header(QWidget):
    def __init__(self, on_settings, on_mode_toggle, on_project_management, on_tasks, on_conversations=None, app=None, conversation_manager=None):
        super().__init__()
        self.app = app
        self.conversation_manager = conversation_manager
        self.on_settings = on_settings
        self.on_mode_toggle = on_mode_toggle
        self.on_project_management = on_project_management
        self.on_tasks = on_tasks
        self.on_conversations = on_conversations
        
        layout = QHBoxLayout(self)
        layout.setContentsMargins(16, 10, 16, 10)

        title = QLabel("Nova Shell")
        title.setObjectName("title")
        title_font = QFont()
        title_font.setPointSize(14)
        title_font.setWeight(QFont.Black)
        title.setFont(title_font)

        # Get user name from PyGenesis settings
        user_name = self._get_user_name()
        self.subtitle = QLabel(f"Active: {user_name}")
        self.subtitle.setObjectName("subtitle")
        sub_font = QFont()
        sub_font.setPointSize(9)
        self.subtitle.setFont(sub_font)
        
        # Thinking status label (hidden by default)
        self.thinking_label = QLabel("")
        self.thinking_label.setObjectName("thinking")
        thinking_font = QFont()
        thinking_font.setPointSize(8)
        thinking_font.setItalic(True)
        self.thinking_label.setFont(thinking_font)
        self.thinking_label.setVisible(False)

        text_column = QWidget()
        text_layout = QVBoxLayoutNoMargins(text_column)
        text_layout.addWidget(title)
        text_layout.addWidget(self.subtitle)
        text_layout.addWidget(self.thinking_label)

        # Conversations button (three lines icon) - top left
        conversations_btn = QPushButton("☰")  # Three lines icon
        conversations_btn.setObjectName("conversations")
        conversations_btn.setToolTip("Conversations")
        conversations_btn.setFixedSize(36, 36)
        if self.on_conversations:
            conversations_btn.clicked.connect(self.on_conversations)
        
        # Global conversation star button (top right of header, before mode button)
        self.global_star_btn = QPushButton("☆")
        self.global_star_btn.setObjectName("globalStar")
        self.global_star_btn.setToolTip("Click to make this conversation global (available in all projects)")
        self.global_star_btn.setFixedSize(36, 36)
        self.global_star_btn.clicked.connect(self._on_global_star_clicked)
        self.global_star_btn.setVisible(False)  # Hidden by default, shown when conversation is loaded

        self.mode_btn = QPushButton(SETTINGS.Mode)
        self.mode_btn.setObjectName("mode")
        self.mode_btn.clicked.connect(self._handle_mode_toggle)

        tasks_btn = QPushButton("Tasks")
        tasks_btn.setObjectName("tasks")
        tasks_btn.clicked.connect(on_tasks)

        project_btn = QPushButton("Project Management")
        project_btn.setObjectName("project")
        project_btn.clicked.connect(on_project_management)

        settings_btn = QPushButton("⚙")  # Cog icon
        settings_btn.setObjectName("settings")
        settings_btn.setToolTip("Settings")
        settings_btn.setFixedSize(36, 36)  # Square icon button
        settings_btn.clicked.connect(on_settings)

        layout.addWidget(conversations_btn)
        layout.addWidget(text_column)
        layout.addStretch()
        layout.addWidget(self.global_star_btn)
        layout.addWidget(self.mode_btn)
        layout.addWidget(tasks_btn)
        layout.addWidget(project_btn)
        layout.addWidget(settings_btn)
        
        self._apply_style()

    def _handle_mode_toggle(self):
        """Toggle between Local and Cloud mode."""
        SETTINGS.Mode = "Cloud" if SETTINGS.Mode == "Local" else "Local"
        self.mode_btn.setText(SETTINGS.Mode)
        if self.on_mode_toggle:
            self.on_mode_toggle(SETTINGS.Mode)

    def update_mode_display(self):
        """Update the mode button text."""
        self.mode_btn.setText(SETTINGS.Mode)

    def _apply_style(self):
        palette = current_palette()
        self.setStyleSheet(
            f"""
            QWidget {{
                background-color: {palette["panel"]};
                border-bottom: 1px solid {palette["panelBorder"]};
            }}
            QLabel#title {{
                color: {palette["text"]};
            }}
            QLabel#subtitle {{
                color: {palette["muted"]};
            }}
            QLabel#thinking {{
                color: {palette.get("accentSoft", palette["accent"])};
                font-style: italic;
            }}
            QPushButton#settings {{
                color: {palette["text"]};
                border: 1px solid {palette["panelBorder"]};
                border-radius: 8px;
                padding: 0px;
                font-size: 18px;
                background-color: transparent;
            }}
            QPushButton#settings:hover {{
                border-color: {palette["accent"]};
                background-color: {palette["panelBorder"]};
            }}
            QPushButton#project {{
                color: {palette["text"]};
                border: 1px solid {palette["panelBorder"]};
                border-radius: 10px;
                padding: 8px 12px;
            }}
            QPushButton#project:hover {{
                border-color: {palette["accent"]};
            }}
            QPushButton#mode {{
                color: {palette["text"]};
                border: 1px solid {palette["panelBorder"]};
                border-radius: 10px;
                padding: 8px 12px;
            }}
            QPushButton#mode:hover {{
                border-color: {palette["accent"]};
            }}
            QPushButton#tasks {{
                color: {palette["text"]};
                border: 1px solid {palette["panelBorder"]};
                border-radius: 10px;
                padding: 8px 12px;
            }}
            QPushButton#tasks:hover {{
                border-color: {palette["accent"]};
            }}
            QPushButton#conversations {{
                color: {palette["text"]};
                border: 1px solid {palette["panelBorder"]};
                border-radius: 8px;
                padding: 0px;
                font-size: 18px;
                background-color: transparent;
            }}
            QPushButton#conversations:hover {{
                border-color: {palette["accent"]};
                background-color: {palette["panelBorder"]};
            }}
            QPushButton#globalStar {{
                color: {palette.get("accent", "#0078d4")};
                border: 1px solid {palette["panelBorder"]};
                border-radius: 8px;
                padding: 0px;
                font-size: 18px;
                background-color: transparent;
            }}
            QPushButton#globalStar:hover {{
                border-color: {palette["accent"]};
                background-color: {palette["panelBorder"]};
            }}
            """
        )

    def refresh_style(self):
        """Refresh styles when theme changes."""
        self._apply_style()
    
    def _get_user_name(self) -> str:
        """Get user name from PyGenesis settings."""
        if self.app and hasattr(self.app, 'settings'):
            try:
                name = self.app.settings.get("User_Name", "Engineer")
                if name and name.strip():
                    return name.strip()
            except Exception:
                pass
        return "Engineer"
    
    def refresh_user_name(self):
        """Refresh the user name display."""
        user_name = self._get_user_name()
        self.subtitle.setText(f"Active: {user_name}")
    
    def update_thinking_status(self, intent: str = None, confidence: float = None):
        """
        Update thinking status display in header.
        
        Args:
            intent: Intent name (e.g., "math_query", "research_query")
            confidence: Confidence score (0.0 to 1.0)
        """
        from settings import SETTINGS
        
        if not SETTINGS.ShowThinking:
            self.thinking_label.setVisible(False)
            return
        
        if intent is None:
            # Idle state
            self.thinking_label.setText("Idle")
            self.thinking_label.setVisible(True)
        else:
            # Format intent name (remove underscores, capitalize)
            intent_display = intent.replace("_", " ").title()
            confidence_pct = int(confidence * 100) if confidence else 0
            self.thinking_label.setText(f"Thinking About {intent_display} ({confidence_pct}% Confidence)")
            self.thinking_label.setVisible(True)
    
    def update_global_star(self):
        """Update the global star button based on current conversation."""
        if not self.conversation_manager:
            self.global_star_btn.setVisible(False)
            return
        
        current = self.conversation_manager.get_current_conversation()
        if current:
            self.global_star_btn.setVisible(True)
            is_global = current.is_global
            self.global_star_btn.setText("⭐" if is_global else "☆")
            self.global_star_btn.setToolTip(
                "Click to make project-specific" if is_global
                else "Click to make global (available in all projects)"
            )
        else:
            self.global_star_btn.setVisible(False)
    
    def _on_global_star_clicked(self):
        """Handle global star button click."""
        if not self.conversation_manager:
            return
        
        current = self.conversation_manager.get_current_conversation()
        if not current:
            return
        
        # Toggle global status
        new_is_global = self.conversation_manager.toggle_global(current.id)
        
        # Update button
        self.global_star_btn.setText("⭐" if new_is_global else "☆")
        self.global_star_btn.setToolTip(
            "Click to make project-specific" if new_is_global
            else "Click to make global (available in all projects)"
        )


class QVBoxLayoutNoMargins(QVBoxLayout):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setContentsMargins(0, 0, 0, 0)
        self.setSpacing(2)

