# PyGenesis Knowledge Base

## Table of Contents
1. [Introduction](#introduction)
2. [Getting Started](#getting-started)
3. [Resource Types](#resource-types)
4. [Editors](#editors)
5. [PGSL Scripting Language](#pgsl-scripting-language)
6. [Project Management](#project-management)
7. [Code System](#code-system)
8. [Best Practices](#best-practices)

---

## Introduction

PyGenesis is a GameMaker-style IDE for creating Python games. It provides a visual editor interface with resource management, code editing, and game development tools.

### Key Concepts
- **Resources**: Game assets (sprites, sounds, objects, rooms, etc.)
- **Projects**: Collections of resources organized in a project file
- **PGSL**: PyGenesis Scripting Language - a GameMaker-like language that compiles to Python
- **Editors**: Specialized tools for editing different resource types

---

## Getting Started

### Creating a New Project
1. File → New Project
2. Choose a location and project name
3. Project structure is created automatically:
   ```
   ProjectName/
   ├── ProjectName.pgproject
   └── Resources/
       ├── Sprites/
       ├── Objects/
       ├── Rooms/
       ├── Sounds/
       ├── Backgrounds/
       ├── Models/
       ├── Textures/
       ├── Scripts/
       └── Shaders/
   ```

### Opening a Project
- File → Open Project
- Select the `.pgproject` file
- All resources load automatically

### Saving Projects
- File → Save (Ctrl+S)
- Projects auto-save on resource changes
- Backup system available: File → Backup → Project Backup

---

## Resource Types

### Sprites (.sprite)
**Purpose**: 2D images and animations for game objects

**Creating Sprites**:
1. Right-click Sprites folder → Create Sprite
2. Name your sprite
3. Click "Edit" to open Image Editor
4. Draw frames or import images
5. Set animation tags and properties

**Sprite Properties**:
- Width/Height: Frame dimensions
- Collision Mask: Precise, rectangle, or custom
- Animation Tags: Named sequences of frames
- Origin: Sprite origin point (default: center)

**File Structure**:
- `.sprite` file: Metadata (JSON)
- `img_0.png`, `img_1.png`, etc.: Frame images

### Objects (.object)
**Purpose**: Game entities with behavior (code)

**Creating Objects**:
1. Right-click Objects folder → Create Object
2. Name your object
3. Assign a sprite (optional)
4. Add events and PGSL code
5. Set properties (solid, persistent, depth, etc.)

**Object Events**:
- Create: Runs when object is created
- Step: Runs every frame
- Draw: Runs every draw frame
- Collision: Runs on collision with another object
- Keyboard/Mouse: Input events
- And more...

**Object Properties**:
- Sprite: Visual representation
- Solid: Collision detection enabled
- Persistent: Survives room changes
- Depth: Draw order (lower = drawn first)
- Parent: Inheritance from another object

### Rooms (.room)
**Purpose**: Game levels/scenes

**Creating Rooms**:
1. Right-click Rooms folder → Create Room
2. Name your room
3. Set background
4. Place object instances
5. Configure room settings

**Room Properties**:
- Width/Height: Room dimensions
- Background: Background resource
- Views: Camera/viewport settings
- Instance Order: Draw order for instances

### Sounds (.sound)
**Purpose**: Audio files for music and sound effects

**Creating Sounds**:
1. Right-click Sounds folder → Create Sound
2. Name your sound
3. Import audio file (WAV, MP3, OGG)
4. Configure properties

**Sound Properties**:
- Volume: 0.0 to 1.0
- Loop: Whether to loop playback
- Preload: Load into memory at startup
- Frequency: Sample rate

### Models (.model)
**Purpose**: 3D models for 3D games

**Creating Models**:
1. Right-click Models folder → Create Model
2. Name your model
3. Import 3D file (OBJ, GLTF, GLB, DAE)
4. Configure materials and textures

**Model Properties**:
- Model File: 3D mesh file
- Scale: Model scale factor
- Position/Rotation: Transform
- Materials: Material assignments

### Backgrounds (.background)
**Purpose**: Background images for rooms

**Creating Backgrounds**:
1. Right-click Backgrounds folder → Create Background
2. Name your background
3. Import or draw image
4. Set tiling properties

### Textures (.texture)
**Purpose**: Texture resources for 3D models

**Creating Textures**:
1. Right-click Textures folder → Create Texture
2. Name your texture
3. Import or draw image
4. Configure texture properties

### Scripts (.script)
**Purpose**: Reusable PGSL code functions

**Creating Scripts**:
1. Right-click Scripts folder → Create Script
2. Name your script
3. Write PGSL code
4. Define arguments and return values

### Shaders (.shader)
**Purpose**: GPU shader programs

**Creating Shaders**:
1. Right-click Shaders folder → Create Shader
2. Name your shader
3. Write shader code (GLSL)
4. Configure uniforms and attributes

---

## Editors

### Sprite Editor
**Access**: Double-click a sprite resource

**Features**:
- Image Editor integration
- Frame management
- Animation tag editor
- Collision mask editor
- Preview panel

**Image Editor Tools**:
- Pencil, Brush, Eraser
- Shapes (Rectangle, Ellipse, Polygon, Star)
- Selection tools
- Effects (blur, sharpen, etc.)
- Timeline for animation

### Object Editor
**Access**: Double-click an object resource

**Features**:
- Event code editor (PGSL)
- Property panel
- Sprite assignment
- Parent object selection
- Event list with categories

**Code Editor**:
- Syntax highlighting
- Auto-completion
- PGSL command support
- Error checking

### Room Editor
**Access**: Double-click a room resource

**Features**:
- Visual instance placement
- Background assignment
- View configuration
- Instance order management
- Settings panel

### Sound Editor
**Access**: Double-click a sound resource

**Features**:
- Waveform visualization
- Playback controls
- Volume/pan controls
- Track mixing
- Export options

### Model Editor
**Access**: Double-click a model resource

**Features**:
- 3D preview
- Material editor
- Texture assignment
- Transform controls
- Export options

---

## PGSL Scripting Language

### Overview
PGSL (PyGenesis Scripting Language) is a GameMaker-like language that compiles to Python. It provides simplified syntax for common game development tasks.

### Language Features

#### Variables
```pgsl
// Local variables
var x = 10;
var name = "Player";

// Instance variables (in objects)
self.x = 100;
self.y = 200;
self.speed = 5;
```

#### Functions
```pgsl
// Function definition
function move_player(x, y) {
    self.x = x;
    self.y = y;
}

// Function call
move_player(100, 200);
```

#### Control Flow
```pgsl
// If statements
if (x > 10) {
    // do something
} else {
    // do something else
}

// Loops
while (x < 100) {
    x += 1;
}

for (var i = 0; i < 10; i++) {
    // loop body
}
```

#### Object Commands
```pgsl
// Create instance
var inst = create_instance("obj_player", x, y);

// Destroy instance
instance_destroy(self);

// Check collision
if (place_meeting(x, y, "obj_wall")) {
    // collision detected
}
```

#### Sprite Commands
```pgsl
// Set sprite
sprite_set("spr_player");

// Set animation
sprite_set_animation("walk");

// Set frame
sprite_set_frame(0);
```

#### Movement Commands
```pgsl
// 2D movement
move_towards(x, y, speed);
move_in_direction(direction, speed);

// 3D movement
Move3D_direction(x, y, z, speed);
Move3D_stop();
```

#### Math Functions
```pgsl
var dist = point_distance(x1, y1, x2, y2);
var dir = point_direction(x1, y1, x2, y2);
var val = clamp(value, min, max);
var rand = random_range(min, max);
```

### PGSL Code System

PyGenesis uses `Core/CodeSystem` for PGSL parsing:

- **Lexer**: Tokenizes PGSL code
- **Parser**: Builds Abstract Syntax Tree (AST)
- **AST**: Represents code structure
- **Syntax Highlighter**: Provides syntax highlighting
- **Syntax Validator**: Validates code correctness

The AST system allows Nova to understand PGSL code structure for better code analysis and assistance.

---

## Project Management

### Project Structure
```
ProjectName/
├── ProjectName.pgproject  # Project metadata
└── Resources/
    ├── Sprites/
    ├── Objects/
    ├── Rooms/
    ├── Sounds/
    ├── Backgrounds/
    ├── Models/
    ├── Textures/
    ├── Scripts/
    └── Shaders/
```

### Project File Format
The `.pgproject` file is JSON containing:
- Project metadata (name, version, author)
- Resource lists by type
- Project settings

### Resource File Extensions
- `.sprite` - Sprite resources
- `.object` - Object resources
- `.room` - Room resources
- `.sound` - Sound resources
- `.background` - Background resources
- `.model` - Model resources
- `.texture` - Texture resources
- `.script` - Script resources
- `.shader` - Shader resources
- `.pgsl` - PGSL code files (in objects/scripts)

### Backup System
- **Editor Backup**: Backs up editor state
- **Project Backup**: Backs up entire project
- **Restore**: Restore from backups
- Location: `Backups/` folder in project directory

---

## Code System

### PGSL AST Structure
The CodeSystem (`Core/CodeSystem`) provides:

**AST Nodes**:
- `ProgramNode`: Root node containing statements
- `BlockNode`: Code blocks
- `FunctionDefNode`: Function definitions
- `VariableDeclNode`: Variable declarations
- `IfStatementNode`: Conditional statements
- `WhileLoopNode`: While loops
- `ForLoopNode`: For loops
- `FunctionCallNode`: Function calls
- `BinaryOpNode`: Binary operations
- `UnaryOpNode`: Unary operations

**Token Types**:
- Keywords: `if`, `while`, `for`, `function`, `var`, etc.
- Operators: `+`, `-`, `*`, `/`, `==`, `!=`, etc.
- Literals: Numbers, strings, booleans
- Identifiers: Variable and function names

### Code Analysis
Nova uses Python AST to analyze:
- Python files (`.py` in Scripts folder)
- PGSL code in objects, scripts, and shaders
- Function definitions and calls
- Dependencies between files
- Code structure and organization

---

## Best Practices

### Resource Organization
1. Use folders to organize resources
2. Name resources descriptively
3. Group related resources together
4. Keep resource names consistent

### Code Organization
1. Use scripts for reusable code
2. Keep object code focused on object behavior
3. Use comments to document complex logic
4. Follow PGSL syntax conventions

### Performance
1. Optimize sprite sizes
2. Use sprite atlases when possible
3. Minimize object instance counts
4. Use object pooling for frequently created/destroyed objects

### Project Management
1. Save frequently (Ctrl+S)
2. Use backups before major changes
3. Test in small increments
4. Document complex game logic

---

## Editor Shortcuts

### General
- `Ctrl+S`: Save project
- `Ctrl+O`: Open project
- `Ctrl+N`: New project
- `Ctrl+R`: Reload project
- `F5`: Run game
- `F9`: Debug game
- `F6`: Build game

### Image Editor
- `P`: Pencil tool
- `B`: Brush tool
- `E`: Eraser tool
- `S`: Selection tool
- `Ctrl+Z`: Undo
- `Ctrl+Y`: Redo
- `Ctrl+C`: Copy
- `Ctrl+V`: Paste

### Code Editor
- `Ctrl+/`: Toggle comment
- `Tab`: Indent
- `Shift+Tab`: Unindent
- `Ctrl+F`: Find
- `Ctrl+H`: Replace

---

## Troubleshooting

### Common Issues

**Resources not loading**:
- Check file paths in project file
- Verify resource files exist
- Check file permissions

**Code errors**:
- Check PGSL syntax
- Verify function names
- Check variable scope

**Performance issues**:
- Reduce sprite sizes
- Optimize object counts
- Check for memory leaks

---

## Advanced Topics

### Custom Editors
PyGenesis supports custom resource types and editors through the EditorFactory system.

### Extension System
Extensions can add new features, resource types, and tools to PyGenesis.

### Runtime Integration
PGSL code compiles to Python and runs through the PyGenesis runtime system.

---

*This knowledge base is maintained and updated as PyGenesis evolves.*

