# Nova Data Directory

This directory contains data files used by Nova for knowledge and research capabilities.

## Files

### `safe_sites.json`
Contains a list of trusted websites that Nova can use for research queries. Each site includes:
- **name**: Display name of the site
- **url**: URL template with `{query}` placeholder
- **type**: Category (encyclopedia, documentation, tutorial, qna, code, wiki)
- **enabled**: Whether the site is currently active
- **description**: Brief description of the site's purpose

**Usage**: When users ask research questions, Nova will suggest these safe sites as sources.

**Editing**: You can add, remove, or modify sites in this file. The URL should use `{query}` as a placeholder that will be replaced with the search term.

### `knowledge_base.json`
Local knowledge base for conversational AI capabilities. Contains:
- **topics**: Structured information about various subjects
  - **programming**: Programming language facts and definitions
  - **general**: General knowledge topics
- **conversational_patterns**: Pre-defined responses for common interactions

**Usage**: Nova uses this for answering factual questions without needing external APIs or AI models.

**Expanding**: You can add new topics and facts to make Nova more knowledgeable. The structure is:
```json
{
  "topics": {
    "category": {
      "topic_name": {
        "definition": "Brief definition",
        "facts": ["Fact 1", "Fact 2"],
        "examples": ["Example 1", "Example 2"]
      }
    }
  }
}
```

## Knowledge Base Sources

Nova uses several knowledge sources:

1. **WordNet (via NLTK)**: For dictionary definitions and thesaurus lookups
   - Automatically downloads on first use
   - Provides synonyms, antonyms, definitions, and examples
   - Requires: `nltk` package

2. **Local Knowledge Base**: Custom JSON file with curated facts
   - Expandable and customizable
   - No external dependencies
   - Fast and always available

3. **Safe Sites**: Trusted web sources for research
   - User-configurable list
   - Provides search URLs for topics
   - No web scraping - just provides links

## Adding New Knowledge

### To add a new topic to the knowledge base:
1. Open `knowledge_base.json`
2. Find or create the appropriate category
3. Add a new entry with definition, facts, and examples
4. Save the file - Nova will load it automatically

### To add a new safe site:
1. Open `safe_sites.json`
2. Add a new entry to the `sites` array
3. Use `{query}` in the URL for the search term placeholder
4. Set `enabled: true` to activate it
5. Save the file - Nova will load it automatically

## Notes

- All JSON files are loaded at runtime
- Changes take effect when Nova restarts
- WordNet data is cached after first download
- Safe sites are used for research queries only
- Knowledge base is used for conversational responses

