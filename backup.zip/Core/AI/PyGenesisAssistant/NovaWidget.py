"""
Nova Widget Wrapper for PyGenesis
Allows Nova to be opened as a tab widget with fullscreen option
"""

from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QToolBar
)
from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QAction

# Import Nova's MainWindow but we'll adapt it to work as a widget
import sys
import os
from pathlib import Path

# Add Nova directory to path for imports
nova_dir = Path(__file__).parent / "Nova"
if str(nova_dir) not in sys.path:
    sys.path.insert(0, str(nova_dir))

# Note: We don't import NovaMainWindow directly - we build the UI components ourselves


class NovaWidget(QWidget):
    """Wrapper widget that contains Nova and provides fullscreen capability"""
    
    def __init__(self, app, main_window, standalone_window=False):
        super().__init__()
        self.app = app
        self.main_window = main_window
        self.is_nova_widget = True  # Marker for identification
        self.is_fullscreen = False
        self.fullscreen_window = None
        self.standalone_window = standalone_window  # Whether this is in a standalone window
        
        # Connect to project changes
        self.app.project_manager.project_loaded.connect(self.on_project_changed)
        
        # Get project root from PyGenesis
        project_path = app.project_manager.get_project_path()
        if project_path:
            # Use project's resources folder
            project_root = Path(project_path) / "Resources"
            if not project_root.exists():
                project_root = Path(project_path)
        else:
            # Fallback to app directory
            project_root = Path(app.app_dir)
        
        self.setup_ui(project_root)
    
    def setup_ui(self, project_root):
        """Setup the Nova widget UI"""
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)
        
        # Create toolbar (only show if not in standalone window, or show with Settings only)
        toolbar = QToolBar()
        toolbar.setMovable(False)
        
        # Only add "New Window" button if not already in standalone window
        if not self.standalone_window:
            # Open in new window button
            new_window_action = QAction("⛶ New Window", self)
            new_window_action.setToolTip("Open AI Assistant in New Window")
            new_window_action.triggered.connect(self.open_in_new_window)
            toolbar.addAction(new_window_action)
            toolbar.addSeparator()
        
        # Settings button (opens PyGenesis preferences)
        settings_action = QAction("⚙ Settings", self)
        settings_action.setToolTip("Open AI Settings")
        settings_action.triggered.connect(self.open_settings)
        toolbar.addAction(settings_action)
        
        layout.addWidget(toolbar)
        
        # Create Nova main window content
        # We need to extract the central widget from Nova's MainWindow
        # Since Nova's MainWindow is a QMainWindow, we'll create a custom widget
        # that contains Nova's UI components directly
        
        # Create container widget - store reference for fullscreen
        self.nova_container = QWidget()
        nova_layout = QVBoxLayout(self.nova_container)
        nova_layout.setContentsMargins(0, 0, 0, 0)
        nova_layout.setSpacing(0)
        
        # Initialize Nova components
        from datetime import datetime
        from core.models import ChatMessage, Sender
        from core.workflow import WorkflowPipeline
        from core.tasks import TaskManager
        from core.conversations import ConversationManager
        from settings import SETTINGS
        from themes import current_palette
        from ui.chat_view import ChatView
        from ui.header import Header
        from ui.input_bar import InputBar
        
        # Initialize task manager
        self.task_manager = TaskManager()
        
        # Initialize conversation manager with project-specific storage
        # Global conversations are loaded automatically from global_storage_dir
        project_storage_dir = None
        if project_root:
            # Use project-specific storage: ProjectRoot/.nova/conversations/
            from pathlib import Path
            project_storage_dir = Path(project_root) / ".nova" / "conversations"
        
        self.conversation_manager = ConversationManager(storage_dir=project_storage_dir)
        # Create or load current conversation
        current_conv = self.conversation_manager.ensure_conversation_exists()
        self.conversation_manager.set_current_conversation(current_conv.id)
        
        # Create header (but hide Nova's project management button since we'll use PyGenesis's)
        self.nova_header = Header(
            self._open_nova_settings,
            self._handle_mode_toggle,
            self._open_project_management,
            self._open_tasks,
            self._open_conversations,
            app=self.app,
            conversation_manager=self.conversation_manager
        )
        nova_layout.addWidget(self.nova_header)
        
        # Initialize global star button after header is created
        self.nova_header.update_global_star()
        
        # Chat area
        chat_container = QWidget()
        chat_layout = QVBoxLayout(chat_container)
        chat_layout.setContentsMargins(32, 16, 32, 16)
        chat_layout.setSpacing(16)
        
        self.chat_view = ChatView(app=self.app)
        chat_layout.addWidget(self.chat_view, 1)
        
        self.input_bar = InputBar()
        self.input_bar.sendRequested.connect(self._handle_send)
        chat_layout.addWidget(self.input_bar)
        
        nova_layout.addWidget(chat_container, 1)
        
        # Initialize workflow pipeline with project root and app instance
        self.workflow = WorkflowPipeline(
            task_manager=self.task_manager,
            project_root=str(project_root),
            app=self.app
        )
        self._register_executors()
        
        # Seed greeting
        self._seed_greeting()
        
        # Apply Nova theme
        self._apply_nova_theme()
        
        layout.addWidget(self.nova_container)
    
    def _register_executors(self):
        """Register all executors and engines with the workflow pipeline."""
        from core.executors.code_query_executor import CodeQueryExecutor
        from core.executors.code_search_executor import CodeSearchExecutor
        from core.executors.project_modification_executor import ProjectModificationExecutor
        from core.executors.resource_operation_executor import ResourceOperationExecutor
        from core.executors.graph_visualization_executor import GraphVisualizationExecutor
        from core.engines.conversation_engine import ConversationEngine
        from core.engines.math_engine import MathEngine
        from core.engines.research_engine import ResearchEngine
        from core.engines.dictionary_engine import DictionaryEngine
        from core.engines.thesaurus_engine import ThesaurusEngine
        from core.models import Intent
        
        # Register engines
        self.workflow.register_engine(Intent.GENERAL_CHAT, ConversationEngine())
        self.workflow.register_engine(Intent.MATH_QUERY, MathEngine())
        self.workflow.register_engine(Intent.RESEARCH_QUERY, ResearchEngine())
        self.workflow.register_engine(Intent.DICTIONARY_LOOKUP, DictionaryEngine())
        self.workflow.register_engine(Intent.THESAURUS_LOOKUP, ThesaurusEngine())
        
        # Register executors
        self.workflow.register_executor(Intent.CODE_QUERY, CodeQueryExecutor())
        self.workflow.register_executor(Intent.CODE_SEARCH, CodeSearchExecutor(app=self.app))
        self.workflow.register_executor(Intent.PROJECT_MODIFICATION, ProjectModificationExecutor())
        self.workflow.register_executor(Intent.RESOURCE_OPERATION, ResourceOperationExecutor(app=self.app))
        self.workflow.register_executor(Intent.GRAPH_VISUALIZATION, GraphVisualizationExecutor())
    
    def _apply_nova_theme(self):
        """Apply Nova theme styling"""
        from themes import current_palette
        palette = current_palette()
        self.setStyleSheet(
            f"""
            QWidget {{
                background-color: {palette["bg"]};
            }}
            """
        )
        if hasattr(self, 'nova_header'):
            self.nova_header.refresh_style()
        if hasattr(self, 'chat_view'):
            self.chat_view.refresh_style()
        if hasattr(self, 'input_bar'):
            self.input_bar.refresh_style()
    
    def _seed_greeting(self):
        """Show initial greeting message"""
        from datetime import datetime
        from core.models import ChatMessage, Sender
        self.chat_view.add_message(
            ChatMessage(
                sender=Sender.NOVA,
                text="Hello! I'm Nova, your AI assistant integrated into PyGenesis. How can I help you today?",
                timestamp=datetime.now(),
            )
        )
    
    def _handle_send(self, text: str):
        """Handle user message through workflow pipeline."""
        from datetime import datetime
        from core.models import ChatMessage, Sender
        from PySide6.QtCore import QTimer
        
        now = datetime.now()
        user_message = ChatMessage(sender=Sender.USER, text=text, timestamp=now)
        self.chat_view.add_message(user_message)
        
        # Store in current conversation
        current_conv = self.conversation_manager.get_current_conversation()
        if current_conv:
            self.conversation_manager.add_message(current_conv.id, user_message)
            # Update conversation summary after first user message
            if len(current_conv.messages) == 1:
                # Pass intent_router for smart naming
                self.conversation_manager.update_conversation_summary(
                    current_conv.id,
                    intent_router=self.workflow.intent_router
                )
        
        # Disable input while processing
        self.input_bar.editor.setEnabled(False)
        self.input_bar.send_button.setEnabled(False)
        
        # Show "Nova is thinking..." status and process Qt events to update UI
        self.input_bar.show_status("Nova is thinking...", animated=True)
        from PySide6.QtWidgets import QApplication
        QApplication.processEvents()
        
        # Process through workflow pipeline
        def process_workflow():
            try:
                # Process Qt events to ensure UI updates
                QApplication.processEvents()
                
                # Get intent classification first (for thinking status display)
                intent_result = self.workflow.intent_router.classify(text)
                
                # Update thinking status with actual intent and confidence
                if intent_result and intent_result.primary_intent:
                    self.nova_header.update_thinking_status(
                        intent_result.primary_intent.value,
                        intent_result.confidence
                    )
                    QApplication.processEvents()  # Update UI
                
                # Show "Nova is typing..." when starting to generate response
                self.input_bar.show_status("Nova is typing...", animated=True)
                QApplication.processEvents()  # Update UI
                
                # Get conversation history for context awareness
                conversation_history = []
                current_conv = self.conversation_manager.get_current_conversation()
                if current_conv:
                    # Get recent messages (excluding the one we just added)
                    conversation_history = current_conv.messages[:-1] if len(current_conv.messages) > 1 else []
                    # Reverse to get chronological order (oldest first)
                    conversation_history = list(reversed(conversation_history))
                
                # Process through workflow with conversation history
                context = self.workflow.process(text, None, conversation_history)
                response_text = context.result or "I'm processing your request..."
                
                # Generate thinking content
                thinking_content = None
                if context.thinking_content:
                    # Use thinking content from context (e.g., from research engine)
                    thinking_content = context.thinking_content
                elif context.operation_plan:
                    # Generate thinking from operation plan
                    thinking_parts = []
                    if context.capabilities:
                        thinking_parts.append(f"Discovered capabilities: {', '.join(context.capabilities.get('available_methods', {}).keys())}")
                    if context.ast_context:
                        thinking_parts.append("Scanned project structure")
                    if context.kb_context:
                        thinking_parts.append("Consulted knowledge base")
                    thinking_parts.append(f"Created operation plan with {len(context.operation_plan.operations)} operation(s)")
                    thinking_content = "\n".join(f"• {part}" for part in thinking_parts)
                
                # For research queries with example code, create a simple "preview" structure
                operation_plan = context.operation_plan
                if context.example_code and not operation_plan:
                    # Create a simple preview structure for example code
                    # The UI can display this in "Show Preview"
                    class SimplePreview:
                        def __init__(self, code):
                            self.code = code
                            self.operations = []  # Empty operations list
                            self.requires_confirmation = False
                    operation_plan = SimplePreview(context.example_code)
                
                nova_message = ChatMessage(
                    sender=Sender.NOVA,
                    text=response_text,
                    timestamp=datetime.now(),
                    thinking_content=thinking_content,
                    operation_plan=operation_plan,
                    intent=context.intent  # Store intent for context awareness
                )
                self.chat_view.add_message(nova_message)
                
                # Store in current conversation
                current_conv = self.conversation_manager.get_current_conversation()
                if current_conv:
                    self.conversation_manager.add_message(current_conv.id, nova_message)
                
                # Hide status notifications
                self.input_bar.hide_status()
                
                # Re-enable input
                self.input_bar.editor.setEnabled(True)
                self.input_bar.send_button.setEnabled(True)
            except Exception as e:
                import traceback
                error_msg = str(e) if str(e) else type(e).__name__
                traceback_str = traceback.format_exc()
                
                error_text = f"Error processing request: {error_msg}"
                if "sympy" in error_msg.lower() or "numpy" in error_msg.lower():
                    error_text += "\n\nPlease install required dependencies:\npip install sympy numpy"
                
                self.chat_view.add_message(
                    ChatMessage(
                        sender=Sender.NOVA,
                        text=error_text,
                        timestamp=datetime.now(),
                    )
                )
                print(f"Workflow Error:\n{traceback_str}")
                
                # Hide status on error
                self.input_bar.hide_status()
                
                # Re-enable input on error
                self.input_bar.editor.setEnabled(True)
                self.input_bar.send_button.setEnabled(True)
        
        QTimer.singleShot(100, process_workflow)  # Reduced delay for faster UI response
    
    def _handle_mode_toggle(self, mode: str):
        """Handle mode toggle between Local and Cloud."""
        pass
    
    def _open_project_management(self):
        """Open Project Management dialog (integrated with PyGenesis)"""
        from ui.project_management_dialog import ProjectManagementDialog
        
        # Get project root from PyGenesis
        project_path = self.app.project_manager.get_project_path()
        if project_path:
            # Use project's resources folder
            project_root = Path(project_path) / "resources"
            if not project_root.exists():
                project_root = Path(project_path)
        else:
            project_root = None
        
        dialog = ProjectManagementDialog(self, project_root=str(project_root) if project_root else None)
        dialog.exec()
    
    def _open_tasks(self):
        """Open Tasks dialog"""
        from ui.tasks_dialog import TasksDialog
        dialog = TasksDialog(self.task_manager, self)
        dialog.exec()
    
    def _open_conversations(self):
        """Open Conversations dialog"""
        from ui.conversations_dialog import ConversationsDialog
        dialog = ConversationsDialog(self.conversation_manager, self)
        dialog.conversation_selected.connect(self._on_conversation_selected)
        dialog.conversation_deleted.connect(self._on_conversation_deleted)
        dialog.exec()
    
    def _on_conversation_deleted(self, conversation_id: str):
        """Handle conversation deletion."""
        # If the deleted conversation was the current one, ensure a new one exists
        if self.conversation_manager.current_conversation_id == conversation_id or self.conversation_manager.current_conversation_id is None:
            # Clear the current chat view
            self.chat_view.messages.clear()
            self.chat_view.bubbles.clear()
            while self.chat_view.layout.count() > 1:
                item = self.chat_view.layout.takeAt(0)
                if item.widget():
                    item.widget().deleteLater()
            
            # Ensure a conversation exists (this will create one if all are deleted)
            current = self.conversation_manager.ensure_conversation_exists()
            if current:
                self.conversation_manager.set_current_conversation(current.id)
                # Update global star button
                if hasattr(self, 'nova_header'):
                    self.nova_header.update_global_star()
    
    def _on_conversation_selected(self, conversation_id: str):
        """Handle conversation selection."""
        # Load conversation and display messages
        conversation = self.conversation_manager.get_conversation(conversation_id)
        if conversation:
            self.conversation_manager.set_current_conversation(conversation_id)
            # Update global star button
            if hasattr(self, 'nova_header'):
                self.nova_header.update_global_star()
            # Clear chat view and load conversation messages
            self.chat_view.messages.clear()
            self.chat_view.bubbles.clear()
            # Clear layout (keep stretch at end)
            while self.chat_view.layout.count() > 1:  # Keep the final stretch
                item = self.chat_view.layout.takeAt(0)
                if item.widget():
                    item.widget().deleteLater()
            
            # Load messages
            from datetime import datetime
            for msg_data in conversation.messages:
                timestamp = datetime.fromisoformat(msg_data["timestamp"])
                sender = Sender[msg_data["sender"]]
                message = ChatMessage(
                    sender=sender,
                    text=msg_data["text"],
                    timestamp=timestamp,
                    thinking_content=msg_data.get("thinking_content")
                )
                self.chat_view.add_message(message)
    
    def _open_nova_settings(self):
        """Open Nova settings (redirects to PyGenesis preferences)"""
        self.open_settings()
    
    def open_settings(self):
        """Open PyGenesis preferences dialog at AI tab"""
        from UI.CommonDialogs.PreferencesDialog import PreferencesDialog
        dialog = PreferencesDialog(self.app, self.main_window)
        # Switch to AI tab
        for i in range(dialog.tab_widget.count()):
            if dialog.tab_widget.tabText(i) == "AI":
                dialog.tab_widget.setCurrentIndex(i)
                break
        dialog.preferences_changed.connect(self._on_preferences_changed)
        dialog.exec()
    
    def _on_preferences_changed(self):
        """Handle preferences changes"""
        self._apply_nova_theme()
        if hasattr(self, 'chat_view'):
            self.chat_view.refresh_bubbles()
    
    def open_in_new_window(self):
        """Open Nova in a new separate window"""
        from PySide6.QtWidgets import QMainWindow, QVBoxLayout, QWidget, QToolBar
        from PySide6.QtGui import QAction
        
        # Check if window already exists
        if hasattr(self, 'separate_window') and self.separate_window and self.separate_window.isVisible():
            # Window already open, just bring it to front
            self.separate_window.raise_()
            self.separate_window.activateWindow()
            return
        
        # Get project root for the new window
        project_path = self.app.project_manager.get_project_path()
        if project_path:
            project_root = Path(project_path) / "resources"
            if not project_root.exists():
                project_root = Path(project_path)
        else:
            project_root = Path(self.app.app_dir)
        
        # Create new window
        self.separate_window = QMainWindow()
        self.separate_window.setWindowTitle("AI Assistant")
        self.separate_window.resize(1120, 760)
        
        # Create central widget
        central_widget = QWidget()
        layout = QVBoxLayout(central_widget)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)
        
        # Create a new Nova container for the separate window
        # We'll create a complete Nova instance in this window
        from datetime import datetime
        from core.models import ChatMessage, Sender
        from core.workflow import WorkflowPipeline
        from core.tasks import TaskManager
        from settings import SETTINGS
        from themes import current_palette
        from ui.chat_view import ChatView
        from ui.header import Header
        from ui.input_bar import InputBar
        
        # Initialize task manager for separate window
        separate_task_manager = TaskManager()
        
        # Create header
        separate_header = Header(
            lambda: self._open_nova_settings(),
            self._handle_mode_toggle,
            lambda: self._open_project_management(),
            lambda: self._open_tasks()
        )
        layout.addWidget(separate_header)
        
        # Chat area
        chat_container = QWidget()
        chat_layout = QVBoxLayout(chat_container)
        chat_layout.setContentsMargins(32, 16, 32, 16)
        chat_layout.setSpacing(16)
        
        separate_chat_view = ChatView()
        chat_layout.addWidget(separate_chat_view, 1)
        
        separate_input_bar = InputBar()
        
        # Create workflow for separate window
        separate_workflow = WorkflowPipeline(
            task_manager=separate_task_manager,
            project_root=str(project_root)
        )
        
        # Register executors for separate window
        self._register_executors_for_workflow(separate_workflow)
        
        # Connect input bar
        def handle_send(text: str):
            from PySide6.QtCore import QTimer
            now = datetime.now()
            separate_chat_view.add_message(ChatMessage(sender=Sender.USER, text=text, timestamp=now))
            
            def process_workflow():
                try:
                    context = separate_workflow.process(text)
                    response_text = context.result or "I'm processing your request..."
                    separate_chat_view.add_message(
                        ChatMessage(
                            sender=Sender.NOVA,
                            text=response_text,
                            timestamp=datetime.now(),
                        )
                    )
                except Exception as e:
                    import traceback
                    error_msg = str(e) if str(e) else type(e).__name__
                    error_text = f"Error processing request: {error_msg}"
                    if "sympy" in error_msg.lower() or "numpy" in error_msg.lower():
                        error_text += "\n\nPlease install required dependencies:\npip install sympy numpy"
                    separate_chat_view.add_message(
                        ChatMessage(
                            sender=Sender.NOVA,
                            text=error_text,
                            timestamp=datetime.now(),
                        )
                    )
                    print(f"Workflow Error:\n{traceback.format_exc()}")
            
            QTimer.singleShot(400, process_workflow)
        
        separate_input_bar.sendRequested.connect(handle_send)
        chat_layout.addWidget(separate_input_bar)
        
        layout.addWidget(chat_container, 1)
        
        # Seed greeting
        separate_chat_view.add_message(
            ChatMessage(
                sender=Sender.NOVA,
                text="Hello! I'm Nova, your AI assistant. This is a separate window - you can keep it open while working in PyGenesis.",
                timestamp=datetime.now(),
            )
        )
        
        # Apply Nova theme
        palette = current_palette()
        self.separate_window.setStyleSheet(
            f"""
            QMainWindow {{
                background-color: {palette["bg"]};
            }}
            """
        )
        separate_header.refresh_style()
        separate_chat_view.refresh_style()
        separate_input_bar.refresh_style()
        
        self.separate_window.setCentralWidget(central_widget)
        
        # Handle window close - just close the window, don't affect the tab
        def on_window_close(event):
            self.separate_window = None
            event.accept()
        
        self.separate_window.closeEvent = on_window_close
        
        self.separate_window.show()
    
    def _register_executors_for_workflow(self, workflow):
        """Register executors for a workflow instance"""
        from core.executors.code_query_executor import CodeQueryExecutor
        from core.executors.code_search_executor import CodeSearchExecutor
        from core.executors.project_modification_executor import ProjectModificationExecutor
        from core.executors.resource_operation_executor import ResourceOperationExecutor
        from core.executors.graph_visualization_executor import GraphVisualizationExecutor
        from core.engines.conversation_engine import ConversationEngine
        from core.engines.math_engine import MathEngine
        from core.engines.research_engine import ResearchEngine
        from core.engines.dictionary_engine import DictionaryEngine
        from core.engines.thesaurus_engine import ThesaurusEngine
        from core.models import Intent
        
        # Register engines
        workflow.register_engine(Intent.GENERAL_CHAT, ConversationEngine())
        workflow.register_engine(Intent.MATH_QUERY, MathEngine())
        workflow.register_engine(Intent.RESEARCH_QUERY, ResearchEngine())
        workflow.register_engine(Intent.DICTIONARY_LOOKUP, DictionaryEngine())
        workflow.register_engine(Intent.THESAURUS_LOOKUP, ThesaurusEngine())
        
        # Register executors
        workflow.register_executor(Intent.CODE_QUERY, CodeQueryExecutor())
        workflow.register_executor(Intent.CODE_SEARCH, CodeSearchExecutor(app=self.app))
        workflow.register_executor(Intent.PROJECT_MODIFICATION, ProjectModificationExecutor())
        workflow.register_executor(Intent.RESOURCE_OPERATION, ResourceOperationExecutor(app=self.app))
        workflow.register_executor(Intent.GRAPH_VISUALIZATION, GraphVisualizationExecutor())
    
    def on_project_changed(self, project_path):
        """Handle project change - update Nova's project root"""
        if project_path:
            # Update project root
            project_root = Path(project_path) / "Resources"
            if not project_root.exists():
                project_root = Path(project_path)
            
            # Update conversation manager with new project-specific storage
            # Global conversations are still accessible via global_storage_dir
            if hasattr(self, 'conversation_manager'):
                project_storage_dir = project_root / ".nova" / "conversations"
                self.conversation_manager.storage_dir = project_storage_dir
                project_storage_dir.mkdir(parents=True, exist_ok=True)
                
                # Ensure a conversation exists for the new project
                current = self.conversation_manager.ensure_conversation_exists()
                if current:
                    self.conversation_manager.set_current_conversation(current.id)
            
            # Update workflow pipeline with new project root
            if hasattr(self, 'workflow'):
                self.workflow.project_scanner.root_directory = str(project_root)
            
            # Update separate window workflow if it exists
            if hasattr(self, 'separate_window') and self.separate_window:
                # The separate window has its own workflow, but we can't easily update it
                # User will need to close and reopen the window for new project
                pass
            
            # Show notification in chat
            if hasattr(self, 'chat_view'):
                from datetime import datetime
                from core.models import ChatMessage, Sender
                self.chat_view.add_message(
                    ChatMessage(
                        sender=Sender.NOVA,
                        text=f"Project changed to: {Path(project_path).name}\nI'm now aware of the new project structure.",
                        timestamp=datetime.now(),
                    )
                )

