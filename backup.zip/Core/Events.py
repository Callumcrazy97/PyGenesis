"""
Event System for PyGenesis IDE
Implements Observer Pattern for loose coupling between modules.

This allows modules to communicate without direct dependencies.
"""

from typing import Dict, List, Callable, Any, Optional
from enum import Enum
from Core.Debug import debug

class EventType(Enum):
    """Event types for the application."""
    # Resource events
    RESOURCE_CREATED = "resource_created"
    RESOURCE_UPDATED = "resource_updated"
    RESOURCE_DELETED = "resource_deleted"
    RESOURCE_LOADED = "resource_loaded"
    
    # Project events
    PROJECT_OPENED = "project_opened"
    PROJECT_SAVED = "project_saved"
    PROJECT_CLOSED = "project_closed"
    PROJECT_CREATED = "project_created"
    
    # Editor events
    EDITOR_OPENED = "editor_opened"
    EDITOR_CLOSED = "editor_closed"
    EDITOR_SAVED = "editor_saved"
    EDITOR_DIRTY_CHANGED = "editor_dirty_changed"
    
    # UI events
    THEME_CHANGED = "theme_changed"
    SETTINGS_CHANGED = "settings_changed"
    
    # Custom events (for extensibility)
    CUSTOM = "custom"

class Event:
    """Represents an event in the system."""
    
    def __init__(self, event_type: EventType, data: Dict[str, Any] = None, source: Optional[str] = None):
        """
        Create a new event.
        
        Args:
            event_type: Type of event
            data: Event data dictionary
            source: Source module name (optional)
        """
        self.event_type = event_type
        self.data = data or {}
        self.source = source
        self.timestamp = None  # Can be set by event bus if needed

class EventBus:
    """
    Central event bus for the application.
    Implements Observer Pattern for loose coupling.
    """
    
    _instance = None
    
    def __new__(cls):
        """Singleton pattern - only one event bus instance."""
        if cls._instance is None:
            cls._instance = super(EventBus, cls).__new__(cls)
            cls._instance._initialized = False
        return cls._instance
    
    def __init__(self):
        """Initialize the event bus."""
        if self._initialized:
            return
        
        self._subscribers: Dict[EventType, List[Callable[[Event], None]]] = {}
        self._initialized = True
        debug("EventBus initialized")
    
    def subscribe(self, event_type: EventType, callback: Callable[[Event], None]) -> None:
        """
        Subscribe to an event type.
        
        Args:
            event_type: Type of event to subscribe to
            callback: Function to call when event is published
                     Callback signature: callback(event: Event) -> None
        """
        if event_type not in self._subscribers:
            self._subscribers[event_type] = []
        
        if callback not in self._subscribers[event_type]:
            self._subscribers[event_type].append(callback)
            debug(f"Subscribed to {event_type.value}: {callback.__name__}")
    
    def unsubscribe(self, event_type: EventType, callback: Callable[[Event], None]) -> None:
        """
        Unsubscribe from an event type.
        
        Args:
            event_type: Type of event to unsubscribe from
            callback: Callback function to remove
        """
        if event_type in self._subscribers:
            if callback in self._subscribers[event_type]:
                self._subscribers[event_type].remove(callback)
                debug(f"Unsubscribed from {event_type.value}: {callback.__name__}")
    
    def publish(self, event_type: EventType, data: Dict[str, Any] = None, source: Optional[str] = None) -> None:
        """
        Publish an event to all subscribers.
        
        Args:
            event_type: Type of event to publish
            data: Event data dictionary
            source: Source module name (optional)
        """
        event = Event(event_type, data, source)
        
        # Notify all subscribers
        if event_type in self._subscribers:
            for callback in self._subscribers[event_type]:
                try:
                    callback(event)
                except Exception as e:
                    debug(f"Error in event callback {callback.__name__} for {event_type.value}: {e}")
        
        # Also notify subscribers to CUSTOM events if this is a custom event
        if event_type == EventType.CUSTOM and EventType.CUSTOM in self._subscribers:
            for callback in self._subscribers[EventType.CUSTOM]:
                try:
                    callback(event)
                except Exception as e:
                    debug(f"Error in custom event callback {callback.__name__}: {e}")
    
    def clear_subscribers(self, event_type: Optional[EventType] = None) -> None:
        """
        Clear all subscribers for an event type, or all events if None.
        
        Args:
            event_type: Event type to clear, or None for all events
        """
        if event_type is None:
            self._subscribers.clear()
            debug("Cleared all event subscribers")
        elif event_type in self._subscribers:
            self._subscribers[event_type].clear()
            debug(f"Cleared subscribers for {event_type.value}")

# Global event bus instance
event_bus = EventBus()

