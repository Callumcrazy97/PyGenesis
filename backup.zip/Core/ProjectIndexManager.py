"""
Project Index Manager
Generates and loads a single project index file (project.pgindex) containing all resource metadata.
This dramatically speeds up project loading by reading one file instead of hundreds.
"""

import os
import json
import hashlib
from pathlib import Path
from typing import Dict, List, Optional, Any
from Core.Debug import debug


class ProjectIndexManager:
    """Manages the project index file for fast project loading"""
    
    INDEX_FILENAME = "project.pgindex"
    INDEX_VERSION = 1  # Increment when index format changes
    
    def __init__(self, project_path: str):
        self.project_path = Path(project_path)
        self.index_path = self.project_path / self.INDEX_FILENAME
    
    def generate_index(self, runtime_resources: Dict[str, Dict[str, Any]]) -> bool:
        """
        Generate project index file from runtime resources.
        Only stores metadata, not full resource data.
        """
        try:
            debug("Generating project index...")
            
            index_data = {
                "version": self.INDEX_VERSION,
                "resources": {}
            }
            
            # Process each resource type
            for resource_type, resources in runtime_resources.items():
                index_data["resources"][resource_type] = {}
                
                for resource_id, resource_data in resources.items():
                    # Extract only metadata (not full content)
                    metadata = self._extract_metadata(resource_type, resource_data)
                    
                    # Add file modification time for cache invalidation
                    file_path = self._get_resource_file_path(resource_type, resource_data)
                    if file_path and file_path.exists():
                        metadata["_file_mtime"] = file_path.stat().st_mtime
                        metadata["_file_size"] = file_path.stat().st_size
                    
                    index_data["resources"][resource_type][resource_id] = metadata
            
            # Write index file
            with open(self.index_path, 'w', encoding='utf-8') as f:
                json.dump(index_data, f, indent=2, ensure_ascii=False)
            
            debug(f"Project index generated: {len(index_data['resources'])} resource types, "
                  f"{sum(len(r) for r in index_data['resources'].values())} total resources")
            return True
            
        except Exception as e:
            debug(f"Error generating project index: {e}")
            import traceback
            debug(traceback.format_exc())
            return False
    
    def load_index(self) -> Optional[Dict[str, Dict[str, Any]]]:
        """
        Load project index file and return metadata for all resources.
        Returns None if index doesn't exist or is invalid.
        """
        if not self.index_path.exists():
            debug("Project index not found, will need to scan files")
            return None
        
        try:
            with open(self.index_path, 'r', encoding='utf-8') as f:
                index_data = json.load(f)
            
            # Check version compatibility
            if index_data.get("version") != self.INDEX_VERSION:
                debug(f"Project index version mismatch (expected {self.INDEX_VERSION}, got {index_data.get('version')})")
                return None
            
            # Validate index is not empty
            if "resources" not in index_data:
                debug("Project index missing resources data")
                return None
            
            debug(f"Project index loaded: {len(index_data['resources'])} resource types, "
                  f"{sum(len(r) for r in index_data['resources'].values())} total resources")
            
            return index_data["resources"]
            
        except Exception as e:
            debug(f"Error loading project index: {e}")
            import traceback
            debug(traceback.format_exc())
            return None
    
    def is_index_valid(self) -> bool:
        """
        Check if the index file exists and is up-to-date.
        Returns False if index is missing or any resource files have changed.
        """
        if not self.index_path.exists():
            return False
        
        try:
            with open(self.index_path, 'r', encoding='utf-8') as f:
                index_data = json.load(f)
            
            if index_data.get("version") != self.INDEX_VERSION:
                return False
            
            # Check if any resource files have been modified
            resources = index_data.get("resources", {})
            for resource_type, type_resources in resources.items():
                for resource_id, metadata in type_resources.items():
                    file_path = self._get_resource_file_path_from_metadata(resource_type, metadata)
                    if file_path and file_path.exists():
                        current_mtime = file_path.stat().st_mtime
                        current_size = file_path.stat().st_size
                        
                        if (metadata.get("_file_mtime") != current_mtime or 
                            metadata.get("_file_size") != current_size):
                            debug(f"Index invalid: {resource_type}/{resource_id} file changed")
                            return False
            
            return True
            
        except Exception as e:
            debug(f"Error validating index: {e}")
            return False
    
    def _extract_metadata(self, resource_type: str, resource_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Extract only metadata from resource data, excluding heavy content.
        """
        metadata = {
            "id": resource_data.get("id", ""),
            "name": resource_data.get("name", ""),
            "parent_folder": resource_data.get("parent_folder", ""),
        }
        
        # Type-specific metadata
        if resource_type == "objects":
            metadata["sprite"] = resource_data.get("sprite", "")
            metadata["parent"] = resource_data.get("parent", "")
            metadata["solid"] = resource_data.get("solid", False)
            metadata["persistent"] = resource_data.get("persistent", False)
            metadata["depth"] = resource_data.get("depth", 0)
            # Don't include events or full properties - load on demand
            metadata["_has_events"] = bool(resource_data.get("events", {}))
            metadata["_event_count"] = len(resource_data.get("events", {}))
        
        elif resource_type == "sprites":
            metadata["width"] = resource_data.get("width", 0)
            metadata["height"] = resource_data.get("height", 0)
            metadata["_frame_count"] = len(resource_data.get("frames", []))
            # Include first frame filename for thumbnail
            frames = resource_data.get("frames", [])
            if frames:
                first_frame = frames[0] if isinstance(frames[0], dict) else frames[0]
                if isinstance(first_frame, dict):
                    metadata["_first_frame"] = first_frame.get("file", "")
                else:
                    metadata["_first_frame"] = first_frame
        
        elif resource_type == "rooms":
            metadata["width"] = resource_data.get("width", 0)
            metadata["height"] = resource_data.get("height", 0)
            metadata["_instance_count"] = len(resource_data.get("instances", []))
            # Don't include full instance data - load on demand
        
        elif resource_type == "backgrounds":
            metadata["image_file"] = resource_data.get("image_file") or resource_data.get("image_path") or resource_data.get("file", "")
        
        elif resource_type == "sounds":
            metadata["audio_file"] = resource_data.get("audio_file", "")
            metadata["duration"] = resource_data.get("duration", 0)
        
        elif resource_type == "models":
            metadata["model_file"] = resource_data.get("model_file", "")
            metadata["format"] = resource_data.get("format", "")
        
        # Always include modified timestamp if available
        if "modified" in resource_data:
            metadata["modified"] = resource_data["modified"]
        
        return metadata
    
    def _get_resource_file_path(self, resource_type: str, resource_data: Dict[str, Any]) -> Optional[Path]:
        """Get the file path for a resource"""
        resource_folder_map = {
            "sprites": "Sprites",
            "backgrounds": "Backgrounds",
            "textures": "Textures",
            "objects": "Objects",
            "sounds": "Sounds",
            "models": "Models",
            "rooms": "Rooms"
        }
        
        resource_folder = resource_folder_map.get(resource_type, "Sprites")
        parent_folder = resource_data.get("parent_folder", "")
        resource_name = resource_data.get("name", "Unknown")
        
        base_path = self.project_path / "Resources" / resource_folder
        if parent_folder:
            base_path = base_path / parent_folder
        
        # Try different extensions
        extensions = {
            "sprites": ".sprite",
            "backgrounds": ".background",
            "textures": ".texture",
            "objects": ".object",
            "sounds": ".sound",
            "models": ".model",
            "rooms": ".room"
        }
        
        ext = extensions.get(resource_type, ".sprite")
        file_path = base_path / f"{resource_name}{ext}"
        
        if file_path.exists():
            return file_path
        
        return None
    
    def _get_resource_file_path_from_metadata(self, resource_type: str, metadata: Dict[str, Any]) -> Optional[Path]:
        """Get file path from metadata"""
        resource_folder_map = {
            "sprites": "Sprites",
            "backgrounds": "Backgrounds",
            "textures": "Textures",
            "objects": "Objects",
            "sounds": "Sounds",
            "models": "Models",
            "rooms": "Rooms"
        }
        
        resource_folder = resource_folder_map.get(resource_type, "Sprites")
        parent_folder = metadata.get("parent_folder", "")
        resource_name = metadata.get("name", "Unknown")
        
        base_path = self.project_path / "Resources" / resource_folder
        if parent_folder:
            base_path = base_path / parent_folder
        
        extensions = {
            "sprites": ".sprite",
            "backgrounds": ".background",
            "textures": ".texture",
            "objects": ".object",
            "sounds": ".sound",
            "models": ".model",
            "rooms": ".room"
        }
        
        ext = extensions.get(resource_type, ".sprite")
        return base_path / f"{resource_name}{ext}"

