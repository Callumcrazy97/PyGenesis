"""
Editor Interface for PyGenesis IDE
Abstract base class that all editors must implement for consistent lifecycle management
"""

from typing import Dict, Optional
from PySide6.QtWidgets import QWidget


class EditorInterface:
    """
    Abstract base class for all resource editors in PyGenesis IDE.
    
    This interface ensures consistent behavior across all editors:
    - Resource loading and saving
    - Editor lifecycle management
    - Dirty state tracking
    - Widget access for embedding in tabs
    """
    
    def open_resource(self, resource_data: Dict) -> bool:
        """
        Load a resource into the editor.
        
        Args:
            resource_data: Dictionary containing resource data (id, name, type, etc.)
            
        Returns:
            True if resource loaded successfully, False otherwise
        """
        raise NotImplementedError("Subclasses must implement open_resource")
    
    def save_resource(self) -> bool:
        """
        Save the current editor state to the resource.
        
        Returns:
            True if save successful, False otherwise
        """
        raise NotImplementedError("Subclasses must implement save_resource")
    
    def close_editor(self) -> bool:
        """
        Cleanup and close the editor.
        Should handle unsaved changes prompts if needed.
        
        Returns:
            True if editor can be closed, False if user cancelled
        """
        raise NotImplementedError("Subclasses must implement close_editor")
    
    def get_editor_widget(self) -> QWidget:
        """
        Get the main widget for this editor.
        This widget will be embedded in the editor tabs.
        
        Returns:
            QWidget instance that represents the editor UI
        """
        raise NotImplementedError("Subclasses must implement get_editor_widget")
    
    def is_dirty(self) -> bool:
        """
        Check if the editor has unsaved changes.
        
        Returns:
            True if there are unsaved changes, False otherwise
        """
        raise NotImplementedError("Subclasses must implement is_dirty")
    
    def get_resource_type(self) -> str:
        """
        Get the resource type this editor handles.
        
        Returns:
            String identifier for the resource type (e.g., "sprites", "rooms", "sounds")
        """
        raise NotImplementedError("Subclasses must implement get_resource_type")
    
    def get_resource_id(self) -> Optional[str]:
        """
        Get the ID of the currently loaded resource.
        
        Returns:
            Resource ID string, or None if no resource loaded
        """
        raise NotImplementedError("Subclasses must implement get_resource_id")
    
    def get_resource_name(self) -> Optional[str]:
        """
        Get the name of the currently loaded resource.
        Default implementation returns None - editors can override.
        
        Returns:
            Resource name string, or None if no resource loaded
        """
        return None
    
    def can_close(self) -> bool:
        """
        Check if the editor can be closed (no unsaved changes or user confirmed).
        Default implementation checks is_dirty() - editors can override for custom logic.
        
        Returns:
            True if editor can be closed, False otherwise
        """
        if self.is_dirty():
            # In the future, this could show a save dialog
            # For now, just return True (let MainWindow handle prompts)
            return True
        return True


