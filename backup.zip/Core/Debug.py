"""
Debug utility for conditional debug output
"""
import sys

class DebugManager:
    """Manages debug output based on settings"""
    _instance = None
    _debug_enabled = None
    _settings = None
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(DebugManager, cls).__new__(cls)
        return cls._instance
    
    def set_settings(self, settings):
        """Set the settings object to check for debug toggle"""
        self._settings = settings
        self._debug_enabled = None  # Reset to force re-check
    
    def is_debug_enabled(self):
        """Check if debug is enabled in settings"""
        if self._debug_enabled is not None:
            return self._debug_enabled
        
        if self._settings is None:
            # Default to False if no settings
            self._debug_enabled = False
            return False
        
        try:
            # Check for Debug setting in preferences
            debug_value = self._settings.get("Debug", False)
            # Handle both bool and string ("True"/"False") values
            if isinstance(debug_value, str):
                self._debug_enabled = debug_value.lower() == "true"
            else:
                self._debug_enabled = bool(debug_value)
        except:
            self._debug_enabled = False
        
        return self._debug_enabled
    
    def force_debug(self, enabled=True):
        """Force debug on/off (for critical startup messages)"""
        self._debug_enabled = enabled
    
    def reset(self):
        """Reset debug state (force re-check on next call)"""
        self._debug_enabled = None

# Global instance
_debug_manager = DebugManager()

def debug(*args, **kwargs):
    """
    Conditional debug print - only prints if debug is enabled in settings
    Usage: debug("message") or debug("DEBUG:", message)
    """
    if _debug_manager.is_debug_enabled():
        print(*args, **kwargs)
        sys.stdout.flush()  # Ensure output is immediate

def debug_critical(*args, **kwargs):
    """
    Always print - for critical startup messages even when debug is off
    Usage: debug_critical("PyGenesis Starting...")
    """
    print(*args, **kwargs)
    sys.stdout.flush()

def init_debug(settings):
    """Initialize debug manager with settings"""
    _debug_manager.set_settings(settings)

