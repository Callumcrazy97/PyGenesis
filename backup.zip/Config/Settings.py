"""
Settings and Configuration for Python Game IDE
"""

from PySide6.QtCore import QSettings
import json
import os
from pathlib import Path

class Settings:
    def __init__(self):
        self.settings = QSettings("PythonGameIDE", "Settings")
        self.load_default_settings()
    
    def load_default_settings(self):
        """Load default settings if they don't exist"""
        if not self.settings.contains("Window_Geometry"):
            self.set_default_settings()
    
    def set_default_settings(self):
        """Set default application settings"""
        # Window settings
        self.settings.setValue("Window_Geometry", "")
        self.settings.setValue("Window_State", "")
        
        # Editor settings
        self.settings.setValue("Show_Grid", True)
        self.settings.setValue("Grid_Size", 32)
        self.settings.setValue("Snap_To_Grid", True)
        
        # Resource settings
        self.settings.setValue("Default_Sprite_Size", 32)
        self.settings.setValue("Default_Room_Size", (1024, 768))
        
        # Recent projects
        self.settings.setValue("Recent_Projects", [])
        
        # Theme settings
        self.settings.setValue("Theme", "Dark")
        self.settings.setValue("Accent_Color", "#0078d4")
        
        # Backup settings
        import os
        user_home = Path.home()
        default_editor_backup = os.path.join(str(user_home), "PyGenesis", "Backups", "Editor")
        default_project_backup = os.path.join(str(user_home), "PyGenesis", "Backups", "Projects")
        self.settings.setValue("Editor_Backup_Location", default_editor_backup)
        self.settings.setValue("Project_Backup_Location", default_project_backup)
    
    def get(self, key, default=None):
        """Get a setting value"""
        return self.settings.value(key, default)
    
    def set(self, key, value):
        """Set a setting value"""
        self.settings.setValue(key, value)
    
    def get_recent_projects(self):
        """Get list of recent projects"""
        recent = self.settings.value("Recent_Projects", [])
        # Ensure we return a list
        if not isinstance(recent, list):
            return list(recent) if recent else []
        return recent
    
    def add_recent_project(self, project_path):
        """Add a project to recent projects list"""
        recent = self.get_recent_projects()
        # Ensure recent is a list
        if not isinstance(recent, list):
            recent = list(recent) if recent else []
        if project_path in recent:
            recent.remove(project_path)
        recent.insert(0, project_path)
        # Keep only last 10 projects
        recent = recent[:10]
        self.settings.setValue("Recent_Projects", recent)
    
    def sync(self):
        """Sync settings to disk"""
        self.settings.sync()
