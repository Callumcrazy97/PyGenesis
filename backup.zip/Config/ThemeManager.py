"""
Theme Manager for Python Game IDE
Centralized theme management for all editors and UI components
"""

from PySide6.QtCore import QObject, Signal, QCoreApplication
from PySide6.QtGui import QColor
import json
import os
from Core.Debug import debug

class ThemeManager(QObject):
    """Centralized theme management"""
    
    theme_changed = Signal(str)  # Emitted when theme changes
    
    def __init__(self, settings):
        super().__init__()
        self.settings = settings
        self.current_theme = self.settings.get("Theme", "Dark")
        self.accent_color = self.settings.get("Accent_Color", "#0078d4")
        self.themes = {
            "Dark": self._get_dark_theme(),
            "Light": self._get_light_theme(),
            "High Contrast": self._get_high_contrast_theme()
        }
        # Load custom themes
        self._load_custom_themes()
        
        # Load custom theme colors into settings if current theme is custom
        self._load_custom_theme_colors()
    
    def _get_dark_theme(self):
        """Dark theme colors with improved contrast"""
        return {
            # Main colors - darker background for better contrast
            "background": "#1e1e1e",
            "surface": "#2d2d2d", 
            "surface_variant": "#3c3c3c",
            "surface_hover": "#4a4a4a",
            
            # Text colors - improved contrast
            "foreground": "#ffffff",
            "text_primary": "#ffffff",
            "text_secondary": "#e0e0e0",
            "text_disabled": "#808080",
            
            # Border colors - better visibility
            "border": "#555555",
            "border_light": "#404040",
            "border_dark": "#707070",
            
            # Accent colors
            "accent": "#0078d4",
            "accent_hover": "#106ebe",
            "accent_pressed": "#005a9e",
            
            # Status colors
            "success": "#4caf50",
            "warning": "#ff9800", 
            "error": "#f44336",
            "info": "#2196f3",
            
            # Input colors - better contrast
            "input_bg": "#2d2d2d",
            "input_background": "#2d2d2d",
            "input_border": "#555555",
            "input_focus": "#0078d4",
            
            # Button colors - better contrast
            "button_bg": "#404040",
            "button_background": "#404040",
            "button_hover": "#505050",
            "button_pressed": "#303030",
            "button_text": "#ffffff",
            
            # Menu colors - better visibility
            "menu_bar": "#2d2d2d",
            "panel_background": "#2d2d2d",
            "panel_border": "#555555",
            
            # Editor specific
            "editor_background": "#1e1e1e",
            "editor_text": "#ffffff",
            "editor_selection": "#264f78",
            "editor_line_number": "#858585",
            
            # Sprite editor specific
            "sprite_canvas": "#000000",
            "sprite_grid": "#404040",
            "sprite_origin": "#ff0000",
            "sprite_handle": "#ffffff"
        }
    
    def _get_light_theme(self):
        """Light theme colors with improved contrast"""
        return {
            # Main colors - better contrast
            "background": "#ffffff",
            "surface": "#f8f8f8",
            "surface_variant": "#eeeeee", 
            "surface_hover": "#e0e0e0",
            
            # Text colors - improved contrast
            "foreground": "#000000",
            "text_primary": "#000000",
            "text_secondary": "#333333",
            "text_disabled": "#666666",
            
            # Border colors - better visibility
            "border": "#b0b0b0",
            "border_light": "#d0d0d0",
            "border_dark": "#808080",
            
            # Accent colors
            "accent": "#0078d4",
            "accent_hover": "#106ebe",
            "accent_pressed": "#005a9e",
            
            # Status colors
            "success": "#4caf50",
            "warning": "#ff9800",
            "error": "#f44336", 
            "info": "#2196f3",
            
            # Input colors - better contrast
            "input_bg": "#ffffff",
            "input_background": "#ffffff",
            "input_border": "#b0b0b0",
            "input_focus": "#0078d4",
            
            # Button colors - better contrast
            "button_bg": "#f0f0f0",
            "button_background": "#f0f0f0",
            "button_hover": "#e0e0e0",
            "button_pressed": "#d0d0d0",
            "button_text": "#000000",
            
            # Menu colors - better visibility
            "menu_bar": "#f8f8f8",
            "panel_background": "#f8f8f8",
            "panel_border": "#b0b0b0",
            
            # Editor specific
            "editor_background": "#ffffff",
            "editor_text": "#000000",
            "editor_selection": "#add6ff",
            "editor_line_number": "#858585",
            
            # Sprite editor specific
            "sprite_canvas": "#ffffff",
            "sprite_grid": "#e0e0e0",
            "sprite_origin": "#ff0000",
            "sprite_handle": "#000000"
        }
    
    def _get_high_contrast_theme(self):
        """High contrast theme colors"""
        return {
            # Main colors
            "background": "#000000",
            "surface": "#1a1a1a",
            "surface_variant": "#333333",
            "surface_hover": "#4d4d4d",
            
            # Text colors
            "text_primary": "#ffffff",
            "text_secondary": "#ffff00",
            "text_disabled": "#808080",
            
            # Border colors
            "border": "#ffffff",
            "border_light": "#ffff00",
            "border_dark": "#808080",
            
            # Accent colors
            "accent": "#00ffff",
            "accent_hover": "#00cccc",
            "accent_pressed": "#009999",
            
            # Status colors
            "success": "#00ff00",
            "warning": "#ffff00",
            "error": "#ff0000",
            "info": "#00ffff",
            
            # Input colors
            "input_background": "#000000",
            "input_border": "#ffffff",
            "input_focus": "#00ffff",
            
            # Button colors
            "button_background": "#333333",
            "button_hover": "#4d4d4d",
            "button_pressed": "#1a1a1a",
            "button_text": "#ffffff",
            
            # Panel colors
            "panel_background": "#1a1a1a",
            "panel_border": "#ffffff",
            
            # Editor specific
            "editor_background": "#000000",
            "editor_text": "#ffffff",
            "editor_selection": "#0000ff",
            "editor_line_number": "#ffff00",
            
            # Sprite editor specific
            "sprite_canvas": "#000000",
            "sprite_grid": "#ffffff",
            "sprite_origin": "#ff0000",
            "sprite_handle": "#ffffff"
        }
    
    def get_current_theme(self):
        """Get current theme name"""
        return self.current_theme
    
    def get_colors(self):
        """Get current theme colors"""
        # Check if it's a custom theme
        if self.current_theme in self.themes:
            return self.themes[self.current_theme]
        # Fallback to Dark theme
        return self.themes.get("Dark")
    
    def set_theme(self, theme_name):
        """Set the current theme"""
        if theme_name in self.themes:
            self.current_theme = theme_name
            self.settings.set("Theme", theme_name)
            self.theme_changed.emit(theme_name)
            return True
        return False
    
    def get_available_themes(self):
        """Get list of available themes"""
        return list(self.themes.keys())
    
    def apply_custom_colors(self, custom_colors):
        """Apply custom colors globally"""
        colors = self.get_colors()
        # Merge custom colors with theme colors
        final_colors = {**colors, **custom_colors}
        
        # Generate custom stylesheet
        stylesheet = self.generate_custom_stylesheet(final_colors)
        QCoreApplication.instance().setStyleSheet(stylesheet)
    
    def generate_custom_stylesheet(self, colors):
        """Generate stylesheet with custom colors"""
        return f"""
        QMainWindow, QWidget, QDockWidget {{
            background-color: {colors.get('background', '#2b2b2b')}; 
            color: {colors.get('foreground', '#cccccc')};
        }}
        QMenuBar {{
            background-color: {colors.get('menu_bar', '#3c3c3c')}; 
            color: {colors.get('foreground', '#cccccc')};
        }}
        QMenu {{
            background-color: {colors.get('menu_bar', '#3c3c3c')}; 
            color: {colors.get('foreground', '#cccccc')};
        }}
        QMenu::item:selected {{
            background-color: {colors.get('accent', '#0078d4')};
        }}
        QTabWidget::pane {{
            border: 1px solid {colors.get('border', '#4a4a4a')};
        }}
        QTabBar::tab {{
            background: {colors.get('menu_bar', '#3c3c3c')}; 
            color: {colors.get('foreground', '#cccccc')}; 
            border: 1px solid {colors.get('border', '#4a4a4a')}; 
            border-bottom-color: {colors.get('menu_bar', '#3c3c3c')}; 
            padding: 5px;
        }}
        QTabBar::tab:selected {{
            background: {colors.get('background', '#2b2b2b')}; 
            border-bottom-color: {colors.get('background', '#2b2b2b')};
        }}
        QTreeWidget {{
            background-color: {colors.get('background', '#2b2b2b')}; 
            color: {colors.get('foreground', '#cccccc')}; 
            alternate-background-color: {colors.get('menu_bar', '#3c3c3c')};
        }}
        QTreeWidget::item:selected {{
            background-color: {colors.get('accent', '#0078d4')}; 
            color: white;
        }}
        QLineEdit, QSpinBox, QComboBox, QTextEdit {{
            background-color: {colors.get('input_bg', '#3c3c3c')}; 
            color: {colors.get('foreground', '#cccccc')}; 
            border: 1px solid {colors.get('border', '#4a4a4a')};
        }}
        QSpinBox::up-button {{
            subcontrol-origin: border;
            subcontrol-position: top right;
            width: 16px;
            border-left: 1px solid {colors.get('border', '#4a4a4a')};
            border-bottom: 1px solid {colors.get('border', '#4a4a4a')};
            background-color: {colors.get('button_bg', '#4a4a4a')};
        }}
        QSpinBox::up-button:hover {{
            background-color: {colors.get('button_hover', '#5a5a5a')};
        }}
        QSpinBox::up-button:pressed {{
            background-color: {colors.get('button_pressed', '#3a3a3a')};
        }}
        QSpinBox::up-arrow {{
            image: none;
            border-left: 4px solid transparent;
            border-right: 4px solid transparent;
            border-bottom: 6px solid {colors.get('foreground', '#cccccc')};
            width: 0px;
            height: 0px;
        }}
        QSpinBox::down-button {{
            subcontrol-origin: border;
            subcontrol-position: bottom right;
            width: 16px;
            border-left: 1px solid {colors.get('border', '#4a4a4a')};
            background-color: {colors.get('button_bg', '#4a4a4a')};
        }}
        QSpinBox::down-button:hover {{
            background-color: {colors.get('button_hover', '#5a5a5a')};
        }}
        QSpinBox::down-button:pressed {{
            background-color: {colors.get('button_pressed', '#3a3a3a')};
        }}
        QSpinBox::down-arrow {{
            image: none;
            border-left: 4px solid transparent;
            border-right: 4px solid transparent;
            border-top: 6px solid {colors.get('foreground', '#cccccc')};
            width: 0px;
            height: 0px;
        }}
        QPushButton {{
            background-color: {colors.get('button_bg', '#4a4a4a')}; 
            color: {colors.get('foreground', '#cccccc')}; 
            border: 1px solid {colors.get('border', '#5a5a5a')}; 
            padding: 5px;
        }}
        QPushButton:hover {{
            background-color: {colors.get('button_hover', '#5a5a5a')};
        }}
        QPushButton:pressed {{
            background-color: {colors.get('button_pressed', '#3a3a3a')};
        }}
        QLabel {{
            color: {colors.get('foreground', '#cccccc')};
        }}
        QStatusBar {{
            background-color: {colors.get('menu_bar', '#3c3c3c')};
            color: {colors.get('foreground', '#cccccc')};
        }}
        QDockWidget::title {{
            background-color: {colors.get('menu_bar', '#3c3c3c')};
            color: {colors.get('foreground', '#cccccc')};
        }}
        QMenuBar::item {{
            color: {colors.get('foreground', '#cccccc')};
        }}
        QMenu::item {{
            color: {colors.get('foreground', '#cccccc')};
        }}
        QGroupBox {{
            color: {colors.get('foreground', '#cccccc')}; 
            border: 1px solid {colors.get('border', '#4a4a4a')}; 
            margin-top: 10px;
        }}
        QGroupBox::title {{
            subcontrol-origin: margin; 
            subcontrol-position: top left; 
            padding: 0 3px;
        }}
        """
    
    def get_stylesheet(self, component="main"):
        """Get stylesheet for a specific component"""
        colors = self.get_colors()
        
        if component == "main":
            return f"""
                QMainWindow {{
                    background-color: {colors['background']};
                    color: {colors['text_primary']};
                }}
                QWidget {{
                    background-color: {colors['background']};
                    color: {colors['text_primary']};
                }}
                QMenuBar {{
                    background-color: {colors['surface']};
                    color: {colors['text_primary']};
                    border-bottom: 1px solid {colors['border']};
                }}
                QMenuBar::item {{
                    background-color: transparent;
                    padding: 4px 8px;
                }}
                QMenuBar::item:selected {{
                    background-color: {colors['surface_hover']};
                }}
                QMenu {{
                    background-color: {colors['surface']};
                    color: {colors['text_primary']};
                    border: 1px solid {colors['border']};
                }}
                QMenu::item {{
                    padding: 6px 20px;
                }}
                QMenu::item:selected {{
                    background-color: {colors['surface_hover']};
                }}
                QToolBar {{
                    background-color: {colors['surface']};
                    border: none;
                    spacing: 2px;
                }}
                QStatusBar {{
                    background-color: {colors['surface']};
                    color: {colors['text_primary']};
                    border-top: 1px solid {colors['border']};
                }}
                QDockWidget {{
                    background-color: {colors['surface']};
                    color: {colors['text_primary']};
                    border: 1px solid {colors['border']};
                }}
                QDockWidget::title {{
                    background-color: {colors['surface_variant']};
                    padding: 4px;
                }}
            """
        
        elif component == "sprite_editor":
            return f"""
                QWidget {{
                    background-color: {colors['panel_background']};
                    color: {colors['text_primary']};
                }}
                QGroupBox {{
                    background-color: {colors['panel_background']};
                    color: {colors['text_primary']};
                    border: 1px solid {colors['border']};
                    border-radius: 4px;
                    margin-top: 10px;
                    padding-top: 10px;
                }}
                QGroupBox::title {{
                    subcontrol-origin: margin;
                    left: 10px;
                    padding: 0 5px 0 5px;
                }}
                QLineEdit {{
                    background-color: {colors['input_background']};
                    color: {colors['text_primary']};
                    border: 1px solid {colors['input_border']};
                    padding: 4px;
                    border-radius: 2px;
                }}
                QLineEdit:focus {{
                    border: 2px solid {colors['input_focus']};
                }}
                QSpinBox {{
                    background-color: {colors['input_background']};
                    color: {colors['text_primary']};
                    border: 1px solid {colors['input_border']};
                    padding: 2px;
                    border-radius: 2px;
                }}
                QSpinBox:focus {{
                    border: 2px solid {colors['input_focus']};
                }}
                QPushButton {{
                    background-color: {colors['button_background']};
                    color: {colors['button_text']};
                    border: 1px solid {colors['border']};
                    padding: 6px 12px;
                    border-radius: 3px;
                }}
                QPushButton:hover {{
                    background-color: {colors['button_hover']};
                }}
                QPushButton:pressed {{
                    background-color: {colors['button_pressed']};
                }}
                QCheckBox {{
                    color: {colors['text_primary']};
                }}
                QCheckBox::indicator {{
                    width: 16px;
                    height: 16px;
                    border: 1px solid {colors['border']};
                    background-color: {colors['input_background']};
                }}
                QCheckBox::indicator:checked {{
                    background-color: {colors['accent']};
                    border: 2px solid {colors['text_primary']};
                    /* Note: Qt stylesheets don't support checkmark icons directly */
                    /* For a visible checkmark, we need a custom widget or image resource */
                    /* This ensures the checked state is visible with contrasting border */
                }}
                QComboBox {{
                    background-color: {colors['input_background']};
                    color: {colors['text_primary']};
                    border: 1px solid {colors['input_border']};
                    padding: 4px;
                    border-radius: 2px;
                }}
                QComboBox:focus {{
                    border: 2px solid {colors['input_focus']};
                }}
                QComboBox::drop-down {{
                    border: none;
                }}
                QComboBox::down-arrow {{
                    image: none;
                    border-left: 4px solid transparent;
                    border-right: 4px solid transparent;
                    border-top: 4px solid {colors['text_primary']};
                    margin-right: 4px;
                }}
                QTabWidget::pane {{
                    border: 1px solid {colors['border']};
                    background-color: {colors['panel_background']};
                }}
                QTabBar::tab {{
                    background-color: {colors['surface']};
                    color: {colors['text_primary']};
                    padding: 8px 16px;
                    margin-right: 2px;
                }}
                QTabBar::tab:selected {{
                    background-color: {colors['panel_background']};
                    border-bottom: 2px solid {colors['accent']};
                }}
                QTabBar::tab:hover {{
                    background-color: {colors['surface_hover']};
                }}
            """
        
        elif component == "editor":
            return f"""
                QTextEdit {{
                    background-color: {colors['editor_background']};
                    color: {colors['editor_text']};
                    border: 1px solid {colors['border']};
                    selection-background-color: {colors['editor_selection']};
                }}
            """
        
        return ""
    
    def _load_custom_themes(self):
        """Load custom themes from settings"""
        custom_themes_data = self.settings.get("Custom_Themes", {})
        if isinstance(custom_themes_data, str):
            try:
                custom_themes_data = json.loads(custom_themes_data)
            except json.JSONDecodeError:
                custom_themes_data = {}
        
        for theme_name, theme_data in custom_themes_data.items():
            # Start with Dark theme as base
            base_theme = self._get_dark_theme()
            # Apply custom colors
            custom_theme = {**base_theme, **theme_data}
            self.themes[theme_name] = custom_theme
    
    def save_custom_theme(self, theme_name, theme_data):
        """Save a custom theme"""
        # Get existing custom themes
        custom_themes_data = self.settings.get("Custom_Themes", {})
        if isinstance(custom_themes_data, str):
            try:
                custom_themes_data = json.loads(custom_themes_data)
            except json.JSONDecodeError:
                custom_themes_data = {}
        
        # Add new theme
        custom_themes_data[theme_name] = theme_data
        
        # Save to settings
        self.settings.set("Custom_Themes", json.dumps(custom_themes_data))
        self.settings.sync()
        
        # Add to themes dictionary
        base_theme = self._get_dark_theme()
        custom_theme = {**base_theme, **theme_data}
        self.themes[theme_name] = custom_theme
    
    def delete_custom_theme(self, theme_name):
        """Delete a custom theme"""
        # Get existing custom themes
        custom_themes_data = self.settings.get("Custom_Themes", {})
        if isinstance(custom_themes_data, str):
            try:
                custom_themes_data = json.loads(custom_themes_data)
            except json.JSONDecodeError:
                custom_themes_data = {}
        
        # Remove theme
        if theme_name in custom_themes_data:
            del custom_themes_data[theme_name]
            
            # Save to settings
            self.settings.set("Custom_Themes", json.dumps(custom_themes_data))
            self.settings.sync()
            
            # Remove from themes dictionary
            if theme_name in self.themes:
                del self.themes[theme_name]
    
    def get_custom_themes(self):
        """Get list of custom theme names"""
        custom_themes = []
        for theme_name in self.themes.keys():
            if theme_name not in ["Dark", "Light", "High Contrast"]:
                custom_themes.append(theme_name)
        return custom_themes
    
    def _load_custom_theme_colors(self):
        """Load custom theme colors into settings on startup"""
        custom_themes = self.get_custom_themes()
        if self.current_theme in custom_themes:
            theme_colors = self.get_colors()
            color_mapping = {
                "font_color": "foreground",
                "button_color": "button_bg", 
                "menu_color": "menu_bar",
                "background_color": "background",
                "border_color": "border",
                "input_color": "input_bg"
            }
            
            # Load custom theme colors into settings
            for color_type, theme_key in color_mapping.items():
                color = theme_colors.get(theme_key)
                if color:
                    self.settings.set(f"Custom_{color_type.title()}", color)
                    debug(f" Loaded {color_type} = {color} for theme {self.current_theme}")
