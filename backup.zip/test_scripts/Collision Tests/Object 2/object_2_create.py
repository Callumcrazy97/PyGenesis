# Python Create Event - Object 2
# Initialize Object 2 properties

import random

# Set initial position (different from Object 1)
x = 300
y = 300

# Set initial health (Object 2 has 500 health)
health = 500
max_health = 500

# Set random damage factor (1-70, different per object)
MyDamageFactor = random.randint(1, 70)

# Set initial speed and direction for movement
speed = 2
direction = 225

# Make object solid for collision detection
solid = True

# Print initialization
print(f"Object 2 created - Health: {health} Damage Factor: {MyDamageFactor}")


