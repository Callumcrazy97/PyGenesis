# Python Collision Event - Object 2
# Handle collision with other object

# Deal damage to the other object
if other:
    other.health -= MyDamageFactor
    
    # Print the other object's health after damage
    print(f"Object 2 collision - Other health: {other.health}")


