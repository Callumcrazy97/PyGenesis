# Python Collision Event - Object 1
# Handle collision with other object

# Deal damage to the other object
if other:
    other.health -= MyDamageFactor
    
    # Print the other object's health after damage
    print(f"Object 1 collision - Other health: {other.health}")


