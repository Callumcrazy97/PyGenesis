# Python Step Event - Object 1
# Movement and basic logic

# Move the object
# Movement is handled by speed and direction automatically

# Bounce off screen edges
if x < 0 or x > room_width:
    direction = 180 - direction
    x = max(0, min(x, room_width))

if y < 0 or y > room_height:
    direction = -direction
    y = max(0, min(y, room_height))

# Check if health is depleted
if health <= 0:
    print("Object 1 destroyed - Health depleted")
    instance_destroy(self)


