# Python Draw Event - Object 1
# Draw the object and health bar

# Draw a circle to represent the object
draw_circle(x, y, 20, (255, 100, 100), True)

# Draw health bar above object
health_percent = health / max_health
bar_width = 40
bar_height = 4
bar_x = x - bar_width / 2
bar_y = y - 30

# Background (red)
draw_rectangle(bar_x, bar_y, bar_x + bar_width, bar_y + bar_height, (100, 0, 0), True)

# Health (green)
health_width = bar_width * health_percent
draw_rectangle(bar_x, bar_y, bar_x + health_width, bar_y + bar_height, (0, 255, 0), True)

# Draw damage factor text
draw_text(x - 20, y + 25, f"DMG: {MyDamageFactor}", (255, 255, 255))


