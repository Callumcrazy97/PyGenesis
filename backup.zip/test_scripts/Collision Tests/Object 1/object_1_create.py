# Python Create Event - Object 1
# Initialize Object 1 properties

import random

# Set initial position
x = 100
y = 100

# Set initial health (Object 1 has 150 health)
health = 150
max_health = 150

# Set random damage factor (1-70, different per object)
MyDamageFactor = random.randint(1, 70)

# Set initial speed and direction for movement
speed = 3
direction = 45

# Make object solid for collision detection
solid = True

# Print initialization
print(f"Object 1 created - Health: {health} Damage Factor: {MyDamageFactor}")


