# Object Editor (PGOE) — Planned Documentation

## Overview

The Object Editor will be PyGenesis's tool for creating game entity definitions. Objects are reusable game elements (players, enemies, collectibles, etc.) that reference sprites, define properties, and contain event-driven behaviors.

---

## Planned Features

### Core Functionality

**Object Definition:**
- Assign sprite resource to object
- Set default properties (variables with types and defaults)
- Define collision shape (inherit from sprite or custom)
- Set object physics flags (solid, persistent, visible default)

**Event System:**
- **Create Event**: Runs when instance is created
- **Step Event**: Runs every frame
- **Draw Event**: Custom drawing (overrides default sprite drawing)
- **Collision Events**: Triggered when collision detected with other objects
- **Keyboard/Mouse Events**: Input handling
- **Room Events**: Room Start, Room End

**Code Editor Integration:**
- Inline code editor for each event
- Syntax highlighting for PGSL (or Python)
- Auto-completion for game API
- Code templates and snippets

---

## Planned UI Layout

### Left Panel: Properties

**Basic Properties:**
- **Name**: Object resource name
- **Sprite**: Dropdown to select sprite resource
- **Parent Object**: Inheritance system (optional)

**Collision:**
- **Collision Shape**: Inherit from sprite / Custom rectangle / Custom mask
- **Solid**: Object blocks movement
- **Visible**: Default visibility state
- **Persistent**: Object persists across room changes

**Custom Properties:**
- List of user-defined variables
- Add/Remove property buttons
- Property editor (name, type, default value)

### Right Panel: Events & Code

**Event List:**
- Tree view of all events
- Create, Step, Draw (always available)
- Collision events (one per object type)
- Keyboard events (one per key)
- Custom events (user-defined)

**Code Editor:**
- Syntax-highlighted code area
- Tab per event or split view
- Line numbers
- Error indicators
- Code templates dropdown

**Event Management:**
- Add Event button
- Remove Event button
- Duplicate Event (copy code to new event)

---

## Object Resource Structure (Planned)

```json
{
  "id": "uuid-here",
  "name": "Player",
  "type": "objects",
  "sprite_id": "sprite-uuid",
  "sprite_name": "PlayerSprite",
  "parent_object_id": null,
  "visible": true,
  "solid": false,
  "persistent": false,
  "properties": [
    {
      "name": "health",
      "type": "number",
      "default": 100
    },
    {
      "name": "score",
      "type": "number",
      "default": 0
    }
  ],
  "events": {
    "create": {
      "code": "health = 100\nscore = 0\nx = room_width / 2\ny = room_height / 2"
    },
    "step": {
      "code": "if keyboard_check(KEY_LEFT):\n    x -= 4\nif keyboard_check(KEY_RIGHT):\n    x += 4"
    },
    "collision_player_enemy": {
      "code": "health -= 10\nif health <= 0:\n    instance_destroy(self)"
    }
  }
}
```

---

## Game API (Planned)

### Object Control
- `x`, `y`: Position
- `xprevious`, `yprevious`: Previous frame position
- `hspeed`, `vspeed`: Horizontal/vertical speed
- `direction`: Direction in degrees
- `speed`: Speed in direction
- `image_angle`: Sprite rotation
- `image_xscale`, `image_yscale`: Sprite scaling

### Object Management
- `instance_create(x, y, object)`: Create instance
- `instance_destroy(instance)`: Destroy instance
- `instance_exists(instance)`: Check if exists
- `instance_place(x, y, object)`: Check collision at position

### Collision
- `place_meeting(x, y, object)`: Check collision
- `collision_rectangle(x1, y1, x2, y2, object)`: Rectangle collision
- `collision_circle(x, y, radius, object)`: Circle collision

### Drawing
- `draw_sprite(sprite, frame, x, y)`: Draw sprite
- `draw_self()`: Draw object's sprite
- `draw_text(x, y, text)`: Draw text
- `draw_rectangle(x1, y1, x2, y2)`: Draw rectangle

### Input
- `keyboard_check(key)`: Check if key pressed
- `keyboard_check_pressed(key)`: Check if key just pressed
- `mouse_x`, `mouse_y`: Mouse position
- `mouse_check(button)`: Check mouse button

### Room
- `room_goto(room)`: Change room
- `room_restart()`: Restart room
- `room_width`, `room_height`: Room dimensions

---

## Workflow (Planned)

### Creating an Object

1. Right-click "Objects" in Resource Tree → "Create Object"
2. Object Editor opens
3. Assign sprite from dropdown
4. Set collision shape and flags
5. Add custom properties (health, score, etc.)
6. Write Create event code (initialization)
7. Write Step event code (gameplay logic)
8. Add collision events as needed
9. Save object

### Using Objects in Rooms

1. Open Room Editor
2. Drag object from Resource Tree onto room
3. Or: Click "Add Instance" → Select object
4. Instance created with object's default properties
5. Instance runs Create event on room load

---

## Inheritance System (Planned)

**Parent Objects:**
- Objects can inherit from parent objects
- Child objects get all parent properties and events
- Child can override parent events
- Useful for object variants (Enemy → FlyingEnemy → BossEnemy)

---

## Dependencies

**Object Editor requires:**
- ✅ Sprite Editor (to create sprites for objects)
- ❌ Scripting Language (PGSL or Python API)
- ❌ Code Editor (for writing event code)

**Object Editor enables:**
- Game entity definition
- Behavior scripting
- Reusable game components

---

## Development Status

**Status**: Not Started (Phase 2)

**Estimated Completion**: 2-3 weeks (after scripting language)

**Priority**: High (blocks Room Editor gameplay, runtime logic)

---

## Future Enhancements

- [ ] Visual property editor (drag-and-drop UI for complex properties)
- [ ] Event inheritance visualization
- [ ] Code debugging (step-through event execution)
- [ ] Event templates library
- [ ] Behavior tree editor (alternative to code)
- [ ] Object variants system
- [ ] Component system (modular behaviors)

---

## Notes

**Scripting Language Decision:**
- If using Python: Object Editor integrates Python code editor
- If using PGSL: Object Editor becomes PGSL editor
- Recommendation: Start with Python for faster development

**Code Storage:**
- Code stored in `.object` file as strings
- Could alternatively store code in separate `.py` or `.pgsl` files
- Version control friendly format needed

---

**See Also:**
- `Plan.md` — Development roadmap
- `Room Editor.md` — Where objects are placed
- `Code Editor.md` — Advanced code editing features

