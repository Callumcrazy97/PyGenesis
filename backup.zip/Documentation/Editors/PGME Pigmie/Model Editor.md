# Model Editor (PGME — Pigme) — Documentation

## Overview

The Model Editor (PGME, nicknamed "Pigme") is PyGenesis's tool for managing 3D models. It provides an interim viewer for importing and previewing 3D models, with a full editor planned for future development.

**Current Status**: Phase 1 — Interim Editor Complete ✅
- Basic 3D model import and preview working
- Resource management integrated
- Full editor planned for Phase 6

---

## Current Features

### 3D Model Import

**Supported Formats:**
- **OBJ** (Wavefront) — Full support
- **GLB** (GL Transmission Format Binary) — Full support
- **GLTF** (GL Transmission Format) — Planned

**Import Workflow:**
1. Create a Model resource in the Resource Tree (right-click "Models" → "Create Model")
2. Double-click the model to open the Model Preview editor
3. Click "Load Model" button
4. Select an `.obj` or `.glb` file
5. File is automatically copied to `Resources/Models/` folder
6. `.model` resource file is updated with file references

### 3D Preview Window

**3D Viewport:**
- **Perspective view** with OpenGL rendering
- **Camera controls**:
  - Left-click drag: Rotate camera around model
  - Right-click drag: Pan camera
  - Mouse wheel: Zoom in/out
- **Grid visualization**: Optional grid display
- **Axis indicators**: X (red), Y (green), Z (blue) axes

**Model Display:**
- **Solid mode**: Rendered with lighting and materials
- **Wireframe mode**: Shows model structure
- **Color support**: Models with vertex colors are displayed
- **Smooth rendering**: Automatic normal calculation

**Performance:**
- Uses OpenGL for hardware-accelerated rendering
- Optimized for models up to 100K vertices
- Automatic camera positioning for model size

---

## Resource Structure

### .model File Format

```json
{
  "id": "uuid-here",
  "name": "MyModel",
  "type": "models",
  "parent_folder": "",
  "created": "2024-01-01T00:00:00",
  "modified": "2024-01-01T00:00:00",
  "model_file": "MyModel.obj",
  "original_model_file": "MyModel.obj",
  "format": "obj",
  "scale": 1.0,
  "position": {"x": 0.0, "y": 0.0, "z": 0.0},
  "rotation": {"x": 0.0, "y": 0.0, "z": 0.0}
}
```

**Fields:**
- `model_file`: Filename of the model file in the project's Models folder
- `original_model_file`: Original filename when imported (for reference)
- `format`: Detected format ("obj", "glb", "gltf")
- `scale`: Scale factor (default: 1.0)
- `position`: 3D position offset (default: 0, 0, 0)
- `rotation`: 3D rotation in degrees (default: 0, 0, 0)

---

## Resource Management

### Creating Models

1. **Right-click "Models"** in Resource Tree → "Create Model"
2. Enter model name
3. Model resource created in `Resources/Models/` folder
4. `.model` file created with default metadata

### Importing Model Files

1. **Open Model Editor** (double-click model resource)
2. Click **"Load Model"** button
3. Select `.obj` or `.glb` file from file dialog
4. File is **automatically copied** to project's `Resources/Models/` folder
5. Resource file is updated with file references
6. Model loads and displays in 3D viewport

### File Organization

```
ProjectName/
└── Resources/
    └── Models/
        ├── MyModel/
        │   ├── MyModel.model          # JSON metadata
        │   └── MyModel.obj            # Model file
        └── SubFolder/
            └── AnotherModel.model
```

- Models support **parent folders** for organization
- Model files are stored alongside `.model` resource files
- Original files are preserved; copies are made in project

### Copying Models

- Right-click model → Copy, then paste
- Model file is **automatically copied** to new location
- Resource file references are updated
- No manual file management needed

### Renaming Models

- Right-click model → Rename
- Model file is **automatically renamed** on disk
- Resource file is updated
- Handles naming conflicts automatically

### Deleting Models

- Right-click model → Delete
- Model file and resource file are **both deleted**
- Purge system ensures no orphaned files remain

---

## Integration with IDE

### Resource Tree

- Models appear under **"Models"** folder with 🎭 icon
- Supports parent folders for organization
- Double-click to open editor
- Right-click menu: Create, Copy, Rename, Delete, Open

### Main Window

- **Edit Menu**: Models option available (planned for full editor)
- Models included in project save/load
- Models included in purge system

### Purge System

The purge system automatically:
- Reads `.model` files to find referenced model files (`.obj`, `.glb`, `.gltf`)
- Keeps all files referenced in resource metadata
- Deletes unreferenced files when project is saved/switched

---

## Technical Implementation

### Dependencies

**Required:**
- `PySide6` — Qt widgets and OpenGL integration
- `PyOpenGL` — OpenGL bindings for Python
- `PyOpenGL_accelerate` — Optimized OpenGL operations
- `numpy` — Vertex/index data handling
- `trimesh` (optional) — Advanced GLTF/GLB loading

**Model Loading:**
- **OBJ files**: Parsed directly (vertex positions, normals, faces)
- **GLB/GLTF files**: Uses `trimesh` library for complex format support

### Editor Architecture

**Interim Editor (`ModelPreviewWindow`):**
- `QWidget` subclass for embedding in IDE
- `ModelPreviewGLWidget` for OpenGL rendering
- Camera controls via mouse interaction
- File loading via "Load Model" button

**Standalone Editor (`StandaloneModelPreviewWindow`):**
- `QMainWindow` subclass for standalone testing
- Instantiates `ModelPreviewWindow` widget
- Useful for development and debugging

---

## Use Cases

### Current Use Cases

1. **Model Preview**: Import and view 3D models
2. **Resource Management**: Organize 3D assets in projects
3. **Model Organization**: Use parent folders to group related models

### Planned Use Cases (Future)

1. **3D Sprites**: Rotate 3D model to generate sprite frames
2. **3D Backgrounds**: Static 3D elements in 2D games
3. **Particle Effects**: 3D meshes for particle systems
4. **Model Editing**: Full vertex editing, materials, textures

---

## Development Roadmap

### Phase 1: Interim Editor ✅ (Complete)

- [x] Basic 3D model import (OBJ, GLB)
- [x] 3D preview with camera controls
- [x] Resource management integration
- [x] File copy/rename/delete operations
- [x] Purge system integration

### Phase 2: Enhanced Preview (Planned)

- [ ] Texture/material support
- [ ] Multiple view modes (front, side, top, perspective)
- [ ] Lighting controls
- [ ] Export rendered images

### Phase 3: Full Model Editor (Phase 6 — Low Priority)

- [ ] Model creation (primitive shapes, mesh editing)
- [ ] Vertex manipulation tools
- [ ] Material editor
- [ ] UV mapping tools
- [ ] Animation support (skeletal animation)
- [ ] Model optimization (reduce polygons)
- [ ] LOD (Level of Detail) generation

---

## UI Layout

### Model Preview Window (Interim Editor)

**Top Section:**
- **"Load Model"** button — Opens file dialog to import model
- **File label** — Shows current model file name

**Main Area:**
- **3D Viewport** — OpenGL rendering area
  - Left-click drag: Rotate
  - Right-click drag: Pan
  - Mouse wheel: Zoom

**Bottom (Planned):**
- Model information (vertices, faces, format)
- Camera controls (reset, perspective/orthographic)
- Display options (wireframe, solid, textures)

---

## Keyboard Shortcuts

- **None currently** — Planned for full editor

---

## Known Limitations

1. **No Texture Support**: Textures from OBJ/GLB files not loaded yet
2. **No Material Editor**: Materials not editable
3. **No Model Creation**: Can only import, not create from scratch
4. **Limited GLTF Support**: GLTF loading needs additional testing
5. **Performance**: Large models (>500K vertices) may be slow

---

## Tips & Best Practices

1. **Organize with Folders**: Use parent folders in Resource Tree to group related models
2. **Keep Files Together**: Model files are stored with `.model` resource files
3. **Use GLB for Complex Models**: GLB format includes all textures/materials in one file
4. **Optimize Before Import**: Reduce polygon count in external tools for better performance
5. **Model Naming**: Use descriptive names; files are copied automatically

---

## Future Enhancements

- [ ] Full model editor with vertex manipulation
- [ ] Texture/material support
- [ ] Animation import and playback
- [ ] Model optimization tools
- [ ] Sprite frame generation from 3D models
- [ ] Physics mesh generation
- [ ] LOD (Level of Detail) automatic generation
- [ ] UV mapping visualization and editing
- [ ] Lighting preview with adjustable lights
- [ ] Multiple viewport support (4-pane view)

---

**See Also:**
- `Tutorials.md` — How to add new resource types
- `Plan.md` — Overall development roadmap
- `Summary Of PyGenesis.md` — IDE overview

**Status**: Interim editor complete, full editor planned for Phase 6

