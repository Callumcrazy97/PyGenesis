# Room Editor (PGRE) — Complete Documentation

## Overview

The Room Editor is PyGenesis's level design tool. It allows you to place object instances and backgrounds in 2D game rooms (levels). Currently in **early development** — basic structure exists but needs visual implementation.

---

## Current Status

### ✅ Implemented

- **UI Structure**: Toolbar with room size controls, grid settings
- **Instance Management**: List of instances, add/remove functionality
- **Background Management**: List of backgrounds, add/remove functionality
- **Grid System**: Toggle visibility, snap-to-grid, adjustable size
- **Basic Canvas**: Room boundary visualization, placeholder instance/background rendering

### ❌ Not Yet Implemented

- **Visual Instance Placement**: Cannot drag-and-drop objects onto room
- **Sprite Rendering**: Instances show as placeholders, not actual sprites
- **Zoom/Pan**: Canvas does not support zooming or panning
- **Instance Handles**: No move/resize/rotate controls
- **Background Rendering**: Backgrounds show as placeholders
- **Tile System**: Tile placement not implemented
- **Instance Properties**: Cannot edit instance properties (x, y, visible, persistent)

---

## UI Layout (Current)

### Top Toolbar

**Room Properties:**
- **Width/Height**: Spinboxes (64-4096 pixels)
- Automatically updates room size

**Grid Settings:**
- **Grid Size**: Spinbox (8-128 pixels)
- **Snap to Grid**: Checkbox
- **Show Grid**: Checkbox

### Main Area

**Left Side: Room Canvas**
- Shows room boundary (scaled to fit)
- Grid overlay (when enabled)
- Placeholder rectangles for instances (green, 32x32)
- Placeholder rectangles for backgrounds (blue, 100x100)
- Selected instance highlighted (red border)

**Right Side: Properties Panel**

**Instances:**
- List of all object instances in room
- "Add Instance" button → Opens object selection dialog
- "Remove" button → Deletes selected instance
- Clicking list item selects instance on canvas

**Backgrounds:**
- List of all background layers
- "Add Background" button → Opens background selection dialog
- "Remove" button → Deletes selected background
- Each background has properties (x, y, visible, tiled, speed)

---

## Planned Features (Phase 1.3)

### Visual Instance Placement

**Goal**: Drag-and-drop objects onto room canvas

**Implementation:**
- Drag object from Resource Tree onto canvas
- Or: Select object from dropdown → Click canvas to place
- Snap to grid when enabled
- Visual feedback (ghost preview while dragging)

### Sprite Rendering

**Goal**: Show actual sprite images for instances

**Implementation:**
- Load sprite from object resource
- Render sprite at instance position
- Show current animation frame (or frame 0 for static)
- Respect sprite origin point
- Scale sprites for zoom levels

### Zoom and Pan

**Goal**: Navigate large rooms easily

**Implementation:**
- Mouse wheel = zoom in/out
- Right-click drag = pan
- Zoom controls in toolbar (100%, 50%, 200%, Fit)
- Zoom indicator in status bar

### Instance Manipulation

**Goal**: Move, resize, rotate instances visually

**Implementation:**
- Selection handles (8-point resize box)
- Drag instance to move
- Drag handles to resize (if object supports it)
- Rotation handle (if needed)
- Keyboard arrow keys for precise movement

### Background Layers

**Goal**: Render and manage background layers

**Implementation:**
- Load background images from resources
- Render backgrounds in correct layer order
- Support tiling (horizontal/vertical)
- Background scrolling speed (for parallax)
- Foreground/background toggle

### Tile System

**Goal**: Place tile regions efficiently

**Implementation:**
- Tile palette from background resources
- Brush tool for tile painting
- Fill tool for large areas
- Tile collision options
- Auto-tiling (smart tile placement)

---

## Resource Structure

### .room File Format

```json
{
  "id": "uuid-here",
  "name": "Room1",
  "type": "rooms",
  "width": 1024,
  "height": 768,
  "grid_size": 32,
  "snap_to_grid": true,
  "show_grid": true,
  "instances": [
    {
      "id": "instance_0",
      "object_id": "sprite-object-uuid",
      "object_name": "Player",
      "x": 100,
      "y": 200,
      "visible": true,
      "persistent": false
    }
  ],
  "backgrounds": [
    {
      "id": "bg_0",
      "background_id": "bg-uuid",
      "background_name": "Sky",
      "x": 0,
      "y": 0,
      "visible": true,
      "foreground": false,
      "htiled": false,
      "vtiled": false,
      "hspeed": 0,
      "vspeed": 0
    }
  ],
  "tiles": []  // Future feature
}
```

---

## Workflow (Planned)

### Creating a Room

1. Right-click "Rooms" in Resource Tree → "Create Room"
2. Room Editor opens automatically
3. Set room size (Width/Height)
4. Configure grid (size, snap, visibility)

### Placing Objects

**Method 1: Drag-and-Drop**
1. Open Resource Tree sidebar
2. Drag object resource onto room canvas
3. Instance created at drop position

**Method 2: Add Instance Button**
1. Click "Add Instance"
2. Select object from dialog
3. Click on canvas where you want instance
4. Instance placed at click position

### Editing Instances

1. Click instance on canvas to select
2. Use arrow keys for precise movement
3. Or drag instance to move
4. Right-click → Properties to edit (x, y, visible, persistent)
5. Delete key or "Remove" button to delete

### Adding Backgrounds

1. Click "Add Background"
2. Select background resource from dialog
3. Background layer added at (0, 0)
4. Edit position, tiling, speed in properties panel

---

## Dependencies

**Room Editor requires:**
- ✅ Sprite Editor (for creating sprite resources)
- ✅ Object Editor (for creating object resources that reference sprites)
- ✅ Background resources (for room backgrounds)

**Room Editor enables:**
- Game level design
- Object instance management
- Room-based game flow

---

## Integration Points

### Object Editor
- Rooms reference objects by ID
- Objects define sprites, properties, events
- Room Editor visualizes object instances

### Runtime (Future)
- Rooms are loaded by game runtime
- Instances are created in runtime
- Room transitions handled by runtime

---

## Known Issues (Current)

1. **No Visual Placement**: Must use "Add Instance" dialog — cannot click canvas
2. **Placeholder Rendering**: Instances show as green boxes, not sprites
3. **No Zoom/Pan**: Cannot navigate large rooms
4. **No Property Editing**: Instance properties not editable in UI
5. **No Background Images**: Backgrounds show as blue boxes

---

## Future Enhancements

- [ ] Visual drag-and-drop placement
- [ ] Sprite rendering with animations
- [ ] Zoom and pan controls
- [ ] Instance property editor (dialog or inline)
- [ ] Tile system
- [ ] Room layers (foreground/background)
- [ ] Camera system (set room viewport)
- [ ] Room transitions (next room, previous room)
- [ ] Persistent objects (carry between rooms)
- [ ] Room preview/test mode

---

## Development Priority

**Status**: Phase 1.3 — High Priority

**Estimated Completion**: 2-3 weeks

**Blocks**: Object Editor workflow, game level design, runtime testing

**See Also:**
- `Plan.md` — Overall development roadmap
- `Summary Of PyGenesis.md` — IDE overview

