# Sprite Editor — Complete Documentation

## Overview

The Sprite Editor is PyGenesis's primary tool for creating and managing sprite resources. It provides a GameMaker-style interface with property panels and preview controls, seamlessly integrated with the full Image Editor for detailed frame editing.

---

## UI Layout

### Left Panel: Properties

**Basic Properties:**
- **Name Field**: Edit sprite resource name (auto-saves on change)
- **Load Sprite**: Import image files (PNG, GIF) as frames
- **Edit Sprite**: Opens embedded Image Editor for frame-by-frame editing
- **Close Editor**: Closes the Image Editor tab

**Dimensions:**
- **Width**: Sprite width in pixels (display only)
- **Height**: Sprite height in pixels (display only)
- **Number of subimages**: Total frame count

**Frame Selection:**
- **Show**: Spinbox to jump to specific frame (0-indexed)

**Origin Settings:**
- **X/Y Coordinates**: Set sprite origin point (affects rotation/positioning in game)
- **Center Button**: Quickly center origin (width/2, height/2)

**Collision Checking:**
- **Precise collision checking**: Use per-frame collision masks
- **Separate collision masks**: Each frame has its own mask
- **Modify Mask**: Button (placeholder — visual mask editor coming soon)

**Texture Settings:**
- **Tile: Horizontal**: Sprite tiles horizontally
- **Tile: Vertical**: Sprite tiles vertically
- **Used in 3D**: Flag for 3D usage (future feature)
- **Texture Group**: Dropdown for texture grouping

**Playback Speed:**
- **Speed**: FPS setting for animation playback (1-60 fps)
- Defaults to preference setting (30 fps typical)

### Right Panel: Preview

**Playback Controls:**
- **◀ Previous Frame**: Step backward
- **▶ Play/Pause**: Toggle animation playback
- **⏹ Stop**: Stop and reset to frame 0
- **▶ Next Frame**: Step forward

**Frame Counter:**
- Displays `current / total` (e.g., "5 / 50")
- When animation tag selected: Shows `anim_frame/total (Frame global_frame/total)` (e.g., "3/10 (Frame 13/50)")

**Animation Selector:**
- Dropdown: **None** (plays all frames) or animation tags from Image Editor
- Selecting a tag filters playback to only frames with that tag
- Automatically updates frame counter and playback scope

**Speed Control:**
- Spinbox with FPS setting
- Affects playback timer interval

**Preview Canvas:**
- Shows current frame with origin point visualized
- Red crosshair indicates origin position
- Scaled to fit preview panel

---

## Workflow

### Creating a New Sprite

1. Right-click "Sprites" in Resource Tree → "Create Sprite"
2. Enter name, click OK
3. Click "Load Sprite" → Select image file(s)
4. Frames are automatically extracted and saved
5. Preview updates immediately

### Editing Frames

1. Click "Edit Sprite" to open Image Editor
2. Full pixel art editing available (brushes, effects, timeline)
3. Use Timeline to tag animation sequences:
   - Right-click frame(s) → "Tag Selected Range..."
   - Enter tag name (e.g., "Walking")
4. Save sprite from Image Editor (or close editor)
5. Return to Sprite Editor preview
6. Use Animation dropdown to preview tagged sequences

### Animation Tags → Preview Integration

**The Animation Tag System:**

1. **In Image Editor Timeline:**
   - Select frame range (Ctrl+click or Shift+click for multi-select)
   - Right-click → "Tag Selected Range..."
   - Enter tag name (e.g., "Walking", "Idle", "Jump")

2. **Tags Save to Sprite File:**
   - Tags are stored in frame metadata
   - Persist across project reloads (when fully implemented)

3. **In Sprite Editor Preview:**
   - Animation dropdown auto-populates with all tags
   - Select "None" = play all frames
   - Select tag name = only frames with that tag play
   - Frame navigation (prev/next) respects tag filter
   - Playback loops within tag scope

---

## Resource Management

### Sprite File Structure

```
Resources/Sprites/
└── MySprite/
    ├── MySprite.sprite          # JSON metadata
    ├── MySprite_0.png           # Frame 0
    ├── MySprite_1.png           # Frame 1
    └── MySprite_2.png           # Frame 2
```

### .sprite File Format

```json
{
  "id": "uuid-here",
  "name": "MySprite",
  "type": "sprites",
  "width": 64,
  "height": 64,
  "frames": [
    {
      "id": "frame_0",
      "file": "MySprite_0.png",
      "tags": ["Walking"]  // Animation tags
    }
  ],
  "origin_x": 32,
  "origin_y": 32,
  "collision_mask": "precise",
  "speed": 30
}
```

### Copying Sprites

- Copy duplicates `.sprite` file
- **Automatically copies all frame PNGs**
- Renames frames to match new sprite name
- Updates frame references in metadata
- Prevents purge conflicts

### Renaming Sprites

- Renames `.sprite` file
- **Automatically renames all frame PNGs**
- Updates frame references in `.sprite` metadata
- Handles filename conflicts (_1, _2 suffixes)

---

## Integration with Image Editor

### Embedded Editor

- Full Image Editor runs in a tab within Sprite Editor
- All menus and tools available
- Timeline accessible via View → Toggle Timeline (Ctrl+Shift+T)
- Changes save automatically to sprite resource

### Menu Synchronization

- **Effects Menu**: Dynamically syncs from Image Editor
- **Edit Menu (Utils)**: Syncs Undo/Redo/Cut/Copy/Paste
- Actions delegate to embedded Image Editor instance

---

## Tips & Best Practices

1. **Tag animations while editing**: Use Timeline to tag frames as you create them
2. **Origin placement**: Set origin based on game needs (center for rotation, bottom for platformers)
3. **Frame consistency**: Keep frame dimensions consistent for smooth animation
4. **Collision masks**: Use precise masks for pixel-perfect collision (when editor is implemented)
5. **Texture groups**: Organize sprites by texture group for batch operations
6. **Animation preview**: Use the Animation dropdown to test specific sequences without exporting

---

## Keyboard Shortcuts

- **Ctrl+S**: Save project (saves sprite automatically)
- Frame navigation: Use prev/next buttons or Edit Sprite → Timeline

---

## Known Limitations

- **Collision Mask Editor**: "Modify Mask" button is placeholder — visual editor coming soon
- **Animation Tags Persistence**: Currently in runtime, full disk persistence coming in Phase 1.1
- **3D Support**: "Used in 3D" flag exists but 3D rendering not yet implemented

---

## Future Enhancements (Planned)

- [ ] Visual collision mask editor
- [ ] Sprite preview with multiple animation playback
- [ ] Frame interpolation/onion skinning in preview
- [ ] Sprite sheet export
- [ ] Auto-generated sprite variants (mirroring, rotation)
- [ ] Collision mask optimization (auto-generate masks)

---

**See Also:**
- `Summary Of Image Editor.md` — Full Image Editor capabilities
- `Tutorials.md` — How to add effects and advanced workflows

