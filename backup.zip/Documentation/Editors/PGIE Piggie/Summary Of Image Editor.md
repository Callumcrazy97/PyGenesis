## Image Editor (PGIE) — Summary

### What it is
- A modular pixel‑art editor embedded in the IDE, also runnable standalone.
- Focused on sprite workflows: layers, frames, timeline, effects, selections.

### Key features
- **Layers and Frames**: Multi-layer RGBA; per-layer frames; frame thumbnails; playback with speed and loop.
- **Timeline**: Large thumbnails, right‑click tagging, color‑by‑tag, multi‑select; horizontal scrolling; click to navigate; toggle via View or Ctrl+Shift+T.
- **Selections**: Rect, magic wand (OpenCV flood fill), brush, lasso; smooth outlines; expand/contract/invert; clipboard cut/copy/paste.
- **Undo/Redo**: Per‑frame history; standard shortcuts.
- **Effects**: Upscale, HD Crisp, Shader Bloom, texture creation, visual styles; unified dialog system with live preview.
- **Atlas/Textures**: Advanced atlas editor; 2D texture generator; map tools with adaptive performance for large images.
- **Performance**: OpenCV‑based filters; preview downscaling; adaptive params for large images.

### Tools overview
- **Brushes**: Radius control, primary/secondary color painting, line/shape tools.
- **Shapes**: Rectangle, ellipse; fill/outline toggle; grid snapping optional.
- **Fill/Bucket**: Fast flood fill (OpenCV path); tolerance via wand when needed.
- **Eraser**: Alpha‑aware erasing on current layer.
- **Color Picker**: Sample from canvas.
- **Grid**: Show/hide, size, color, rotation, snap.

### Selections (single-mask system)
- Rectangular, magic wand (OpenCV), brush selection, lasso (polygon path).
- Smooth “marching ants” contours; expand/contract/invert; select‑all/clear.
- Copy/Cut/Paste into new or existing layer regions; keyboard shortcuts wired.

### Layers
- Add/remove/reorder (via layer manager); visibility/lock; per‑layer frames.
- Origin/collision helpers are exposed when used via Sprite Editor integration.

### Frames & Timeline
- Thumbnails for every frame; click = navigate; double‑click also navigates.
- Multi‑select (Ctrl/Shift); context menu for copy/delete/tag; color by tag.
- Horizontal scroll (wheel or scrollbar); speed slider and loop toggle.
- Onion skinning: master toggle in the right panel, with canvas integration for previous/next frame ghosting when enabled.

### Effects library
- **Reshades (Visual Style menu)**:
  - GameCube styles: WindWaker, Ocarina of Time, Luigi’s Mansion, Eternal Darkness, Pokémon Colosseum.
  - Modern Nintendo: Mario Kart 8.
- **Image enhancement**: Upscale (edge‑aware sharpening), HD Crisp (adaptive unsharp, Laplacian edge boost, gamma pop).
- **Lighting/Atmosphere**: Shader Bloom, atmospheric helpers.
- **Creation tools**: 2D Texture Creation, Advanced Atlas Editor, Character Creator, 2D Map Generator (with adaptive detail on large canvases).
- All effects run through the unified effect dialog (live preview + apply), documented in Tutorials.

### Sprite Editor integration
- The full Image Editor is embedded inside `SpriteEditor` as a tab with synced menus.
- **Animation Tags → Preview**: Frame tags created in PGIE populate the Sprite Editor’s “Animation” dropdown.
  - Select “None” to play all frames, or choose a tag (e.g., Walking) to scope playback and next/prev to that subset.
  - Frame counter shows both global and animation‑scoped positions.
- **Timeline control**: View → Toggle Timeline (or Ctrl+Shift+T) from within the embedded editor.
- **Workflow**:
  1) Open Image Editor from Sprite Editor (“Edit Sprite”).
  2) In the timeline, multi‑select frames and choose “Tag Selected Range…”.
  3) Save the sprite; return to Sprite Editor preview.
  4) Use “Animation” dropdown to preview the tagged sequence.

### Performance & large projects
- OpenCV replaces heavy SciPy ops; large‑image previews are downscaled.
- Map Generator caps octaves/detail for >2MP images; effects adapt kernel sizes to scale.

### Shortcuts (highlights)
- Timeline toggle: Ctrl+Shift+T
- Undo/Redo: Ctrl+Z / Ctrl+Y (Ctrl+Shift+Z)
- Cut/Copy/Paste/Delete: Ctrl+X / Ctrl+C / Ctrl+V / Del
- Select All / Invert: Ctrl+A / Shift+I (or menu)

### Sprite integration
- **Embedded in Sprite Editor** with full menus and timeline.
- **Animation tags**: Frame tags populate the Sprite Editor’s Animation dropdown; choose a tag to preview only those frames.
- **Origin/Collision helpers**: Origin centering and collision toggles available in Sprite Editor.

### Tips
- Use the timeline context menu to tag ranges quickly (Tag Selected Range…).
- Toggle timeline from View or press Ctrl+Shift+T.
- Effects are registry‑driven; see Tutorials for adding new effects.


