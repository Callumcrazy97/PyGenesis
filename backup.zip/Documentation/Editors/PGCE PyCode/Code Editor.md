# Code Editor (PGCE) — Planned Documentation

## Overview

The Code Editor will be PyGenesis's script editing interface. It integrates with the Object Editor for event scripting and provides advanced code editing features for game development.

---

## Planned Features

### Core Editing

**Syntax Highlighting:**
- Python syntax (if using Python directly)
- PGSL syntax (if custom language implemented)
- Game API keywords highlighted
- Comments, strings, numbers colorized

**Auto-Completion:**
- Game API function suggestions
- Object property suggestions
- Variable name completion
- Import statement completion

**Error Detection:**
- Real-time syntax checking
- Invalid function call warnings
- Undefined variable warnings
- Type checking (if implemented)

**Code Navigation:**
- Go to definition
- Find all references
- Symbol browser
- Function outline

### Integration Points

**Object Editor:**
- Inline code editor for each event
- Tab-based or split view
- Event switching preserves code
- Auto-save on event change

**Standalone Mode:**
- Can open/edit script files directly
- Project-wide script management
- Global script support (game initialization)

---

## UI Layout (Planned)

### Main Editor Area

**Code View:**
- Line numbers
- Syntax highlighting
- Code folding (collapsible blocks)
- Bracket matching
- Indentation guides

**Sidebar:**
- File browser (project scripts)
- Symbol list (functions, classes, variables)
- Search results
- Problems/errors panel

**Bottom Panel:**
- Output/console (runtime errors)
- Terminal (if needed)
- Debug info

**Toolbar:**
- Save, Save All
- Undo/Redo
- Find/Replace
- Go to Line
- Code formatting

---

## Game API Integration

### Auto-Completion Database

**Built-in Functions:**
- Object manipulation (`instance_create`, `instance_destroy`)
- Collision (`place_meeting`, `collision_rectangle`)
- Drawing (`draw_sprite`, `draw_text`)
- Input (`keyboard_check`, `mouse_x`)
- Math (`abs`, `sin`, `cos`, `distance`)
- String operations

**Context-Aware Suggestions:**
- In object event: Suggest object variables
- In collision event: Suggest collision data
- After dot (`.`): Suggest properties/methods

### Code Templates

**Event Templates:**
```python
# Create Event
def create():
    # Initialize object
    pass

# Step Event
def step():
    # Game logic every frame
    pass

# Draw Event
def draw():
    # Custom drawing
    draw_self()  # Default sprite drawing
```

**Common Patterns:**
- Movement (8-directional, platformer)
- Collision handling
- Animation control
- State machines

---

## Script File Structure (Planned)

### Project Scripts

```
ProjectName/
└── Scripts/
    ├── game_init.py       # Global game initialization
    ├── global_functions.py # Shared functions
    └── utils/
        └── helpers.py      # Utility functions
```

### Object Event Code

Stored in `.object` files:
```json
{
  "events": {
    "create": "code string here",
    "step": "code string here"
  }
}
```

Or separate files:
```
ProjectName/
└── Scripts/
    └── Objects/
        ├── Player_create.py
        ├── Player_step.py
        └── Player_collision_enemy.py
```

---

## Python vs PGSL Decision

### Option 1: Use Python Directly (Recommended)

**Pros:**
- Developers already know Python
- Huge ecosystem of libraries
- No parser/runtime to maintain
- Faster development

**Cons:**
- Less game-specific syntax
- Need to wrap game functions

**Implementation:**
- Code Editor becomes Python editor
- Game API provided as Python module
- Objects import game API automatically

### Option 2: Build PGSL (Custom Language)

**Pros:**
- Game-specific syntax
- Can optimize for game development
- More intuitive for game devs

**Cons:**
- Significant development time
- Must maintain parser/runtime
- Learning curve

**Implementation:**
- Code Editor becomes PGSL editor
- Custom syntax highlighting
- Parser converts to runtime bytecode

---

## Development Priority

**Status**: Not Started (Phase 3)

**Estimated Completion**: 1-2 weeks (Python) or 4-6 weeks (PGSL)

**Dependencies**: 
- Scripting language decision
- Game API definition
- Object Editor integration

**Blocks**: Object Editor events, game logic

---

## Future Enhancements

- [ ] Debugging integration (breakpoints, step-through)
- [ ] Live code reload (hot-swap during game)
- [ ] Visual scripting (node-based alternative)
- [ ] Code snippets library
- [ ] Version control integration
- [ ] Multi-file search/replace
- [ ] Code refactoring tools
- [ ] Documentation generation

---

## Code Editor API (Planned)

### Game Runtime Functions

**Object Instance:**
```python
self.x          # X position
self.y          # Y position
self.visible    # Visibility
self.solid      # Collision flag
```

**Movement:**
```python
x += hspeed
y += vspeed
move_towards(x, y, speed)
```

**Collision:**
```python
if place_meeting(x, y, "Enemy"):
    # Handle collision
    pass

collision = instance_place(x, y, "Collectible")
if collision:
    instance_destroy(collision)
```

**Drawing:**
```python
draw_self()  # Draw assigned sprite
draw_sprite("SpriteName", frame, x, y)
draw_text(x, y, f"Score: {score}")
```

**Input:**
```python
if keyboard_check(KEY_SPACE):
    jump()

if mouse_check(BUTTON_LEFT):
    shoot_at(mouse_x, mouse_y)
```

---

**See Also:**
- `Object Editor.md` — Where code editor is used
- `Plan.md` — Development roadmap
- `Pythonic Shortcut Language.md` — PSL overview

