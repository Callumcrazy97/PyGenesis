## Pythonic Shortcut Language (PSL)

PSL is a thin, optional shorthand for invoking common IDE actions and effects without hunting through menus. It maps simple phrases to real methods. You can enter PSL snippets in future quick‑command UIs or bind them to hotkeys.

### Syntax
- Commands are lower‑case words separated by spaces.
- Arguments are written as `name=value` (numbers, booleans, or strings in quotes).
- Multiple arguments are separated by spaces.

### Categories and Examples

- **Effects (Image Editor)**
  - `effect upscale factor=1.5 enhance_edges=true`
  - `effect hd_crisp sharpening=1.8 edge_enhancement=1.2`
  - `effect shader_bloom radius=8 intensity=0.7`

- **Timeline**
  - `timeline toggle`
  - `timeline play`
  - `timeline stop`
  - `timeline speed=fps:24`  (sets playback speed to 24 fps)

- **Selection**
  - `select rect x=10 y=10 w=64 h=64`
  - `select invert`
  - `select clear`

- **Sprite Preview**
  - `preview animation name="Walking"`
  - `preview animation none`

- **Recording**
  - `record start`
  - `record stop`
  - `record compress`

### Resolution Flow
1. Determine context (Sprite Editor, Image Editor, Sound Editor, or IDE main window).
2. Parse command and arguments.
3. Map to a known method (e.g., `effect_upscale`, `toggle_timeline`, `set_speed`).
4. Execute and report status.

### Notes
- PSL is intentionally minimal and human‑readable.
- Unsupported commands should return a friendly hint listing valid commands for the active context.


