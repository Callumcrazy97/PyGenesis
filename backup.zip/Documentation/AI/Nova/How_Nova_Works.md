# How Nova Works - Complete Guide with Examples

## Overview

Nova uses an **Intent-Based Workflow Pipeline** that routes your queries to specialized engines or executors based on what you're asking. Here's how it works:

## Workflow Pipeline Steps

1. **User Input** → You type a message
2. **Intent Routing** → Nova classifies your query (using SLM or keyword patterns)
3. **Project Knowledge Scan** → If code-related, scans your project structure
4. **Capability Discovery** → Validates operation against API Surface Manifest
5. **Knowledge Base Lookup** → Checks PyGenesis knowledge base
6. **Operation Planning** → Creates operation plan with risk assessment (for modifications)
7. **Preview & Confirmation** → Shows preview if high-risk (unless allowed in preferences)
8. **Cloud AI Fallback** → For complex queries (if enabled)
9. **Atomic Execution** → Executes operations transactionally (all or nothing)
10. **Response** → Returns formatted answer with thinking/preview options

---

## Example Queries by Type

### 1. **Asking for File Edits**

**Intent:** `PROJECT_MODIFICATION`

**Example Queries:**
- "Modify the player movement script"
- "Change the sprite size in object X"
- "Update the shader code"
- "Refactor the collision detection"

**How It Works:**
```
User: "Modify the player movement script"
  ↓
Intent Router → PROJECT_MODIFICATION
  ↓
Project Scanner → Scans project for code files
  ↓
Capability Discovery → Validates against API Surface Manifest
  ↓
Operation Planner → Creates operation plan with risk assessment
  ↓
Preview Dialog → Shows file changes (green=additions, red=removals)
  ↓
User Confirmation → (unless "Allow High Risk" enabled in preferences)
  ↓
Transaction Manager → Executes atomically (all or nothing)
  ↓
Response: "Operation Complete" with thinking/preview options
```

**Current Status:** ✅ **FULLY IMPLEMENTED**
- ✅ Operation planning with risk assessment
- ✅ Preview dialog with file diff highlighting
- ✅ Transaction-based atomic execution
- ✅ Automatic rollback on failure
- ✅ User confirmation for high-risk operations

---

### 2. **Asking for File Creation**

**Intent:** `PROJECT_MODIFICATION` or `RESOURCE_OPERATION`

**Example Queries:**
- "Create a new script file"
- "Add a new shader"
- "Create a sprite named PlayerSprite"
- "Make a new object called Enemy"

**How It Works:**

**For Resources (Sprites, Objects, etc.):**
```
User: "Create a sprite named PlayerSprite"
  ↓
Intent Router → RESOURCE_OPERATION
  ↓
ResourceOperationExecutor → Extracts: resource_type="sprites", name="PlayerSprite"
  ↓
ResourceManager.create_resource() → Creates sprite file
  ↓
Response: "Created sprites 'PlayerSprite' successfully!"
```

**For Code Files:**
```
User: "Create a new script file"
  ↓
Intent Router → PROJECT_MODIFICATION
  ↓
Capability Discovery → Validates operation
  ↓
Operation Planner → Creates plan
  ↓
Transaction Manager → Executes atomically
  ↓
Response: "Operation Complete" with preview
```

**Current Status:** 
- ✅ Resource creation works perfectly (sprites, objects, rooms, etc.)
- ✅ Operation planning and transaction management implemented
- ✅ Preview and confirmation system in place

---

### 3. **Asking for Math**

**Intent:** `MATH_QUERY`

**Example Queries:**
- "What is 2 * 3?"
- "Solve 1*(98+476-27)"
- "ninety minus one"
- "Calculate 15 + 23"
- "What is 2 + 2?"

**How It Works:**
```
User: "What is 2 * 3?"
  ↓
Intent Router → MATH_QUERY
  ↓
Entity Extraction → "2 * 3"
  ↓
MathEngine → Converts to math expression, evaluates with SymPy
  ↓
Response: "The answer is 6"
```

**Natural Language Support:**
```
User: "ninety minus one"
  ↓
MathEngine → Converts words to numbers: "90 - 1"
  ↓
SymPy evaluation → 89
  ↓
Response: "The answer is 89"
```

**Supported Formats:**
- Direct expressions: `2+3`, `1*(98+476-27)`
- Natural language: `ninety minus one`, `two times three`
- Questions: `What is 2 * 3?`, `Solve 15 + 23`

**Current Status:** ✅ Fully functional

---

### 4. **Asking Something Nova Is Not Sure On**

**Intent:** `GENERAL_CHAT`

**Example Queries:**
- "Hello"
- "What can you do?"
- "I'm confused"
- "Help me"
- Random questions that don't match specific intents

**How It Works:**
```
User: "Hello"
  ↓
Intent Router → GENERAL_CHAT (no specific pattern matched)
  ↓
ConversationEngine → Pattern matching for greetings
  ↓
Response: "Hello! I'm Nova, your AI assistant. How can I help you today?"
```

**For Unclear Queries:**
```
User: "What is this thing?"
  ↓
Intent Router → GENERAL_CHAT
  ↓
ConversationEngine → No pattern match, generates contextual response
  ↓
Response: "I'm here to help! You can ask me:
          • Math: 'What is 2 * 3?' or 'ninety minus one'
          • Research: 'What is Python?'
          • Definitions: 'Define happiness'
          • Code: 'How does my code work?'
          • Or just chat with me!"
```

**Current Status:** ✅ Fully functional with pattern matching and fallback responses

---

### 5. **Asking "What is Python Language"**

**Intent:** `RESEARCH_QUERY`

**Example Queries:**
- "What is Python?"
- "What is Python Language?"
- "Tell me about Python"
- "Research Python"
- "Explain Python"

**How It Works:**
```
User: "What is Python Language"
  ↓
Intent Router → RESEARCH_QUERY
  ↓
Entity Extraction → "Python Language"
  ↓
ResearchEngine → Cleans query → "Python Language"
  ↓
Safe Sites Lookup → Finds Wikipedia and other safe sites
  ↓
Response: "I found 1 safe source(s) for 'Python Language':
          
          • Wikipedia (encyclopedia): https://en.wikipedia.org/wiki/Python_Language
            General knowledge and encyclopedia articles
          
          You can visit these links to learn more about 'Python Language'. 
          I can help summarize information if you provide specific questions."
```

**Current Status:** ✅ Functional - provides safe site links (currently Wikipedia)

**Note:** This provides links to safe sites rather than direct answers. For direct answers, you'd need Cloud AI mode enabled.

---

### 6. **Asking "How Can We Implement Occlusion Culling Into My Project"**

**Intent:** `PROJECT_MODIFICATION` or `CODE_QUERY` (requires Cloud AI)

**Example Queries:**
- "How can we implement occlusion culling into my project?"
- "Add a feature for X"
- "Implement Y system"
- Complex implementation questions

**How It Works:**

**Without Cloud AI (Current):**
```
User: "How can we implement occlusion culling into my project?"
  ↓
Intent Router → PROJECT_MODIFICATION (detects "implement")
  ↓
Project Scanner → Scans project structure
  ↓
Knowledge Base Lookup → Checks PyGenesis_KnowledgeBase.md
  ↓
ProjectModificationExecutor → Stub implementation
  ↓
Response: "I understand you want to modify the project: 'How can we implement occlusion culling...'. 
          File modification is not yet implemented."
```

**With Cloud AI Enabled (Future):**
```
User: "How can we implement occlusion culling into my project?"
  ↓
Intent Router → PROJECT_MODIFICATION
  ↓
Project Scanner → Scans project structure
  ↓
Capability Discovery → Validates against API manifest
  ↓
Knowledge Base Lookup → Checks PyGenesis_KnowledgeBase.md
  ↓
Operation Planner → Creates implementation plan
  ↓
_should_use_cloud() → Returns True (complex intent)
  ↓
Cloud AI (Gemini/OpenAI) → Analyzes project, provides implementation plan
  ↓
Preview Dialog → Shows proposed changes
  ↓
Transaction Manager → Executes atomically
  ↓
Response: [Detailed implementation guide with code examples]
```

**Current Status:** 
- ⚠️ Cloud AI integration is stubbed (not yet implemented)
- ✅ Project scanning works
- ✅ Knowledge base lookup works
- ✅ Operation planning works
- ✅ Transaction management works
- ✅ Preview/confirmation system works
- ⚠️ Needs Cloud AI API integration for complex queries

**What's Needed:**
1. Cloud AI API integration (Gemini/OpenAI)
2. Enhanced ProjectModificationExecutor with code generation
3. Context-aware implementation suggestions

---

## Intent Types Summary

| Intent | Engine/Executor | Status | Example |
|--------|----------------|--------|---------|
| `MATH_QUERY` | MathEngine | ✅ Working | "What is 2 * 3?" |
| `RESEARCH_QUERY` | ResearchEngine | ✅ Working | "What is Python?" |
| `DICTIONARY_LOOKUP` | DictionaryEngine | ✅ Working | "Define happiness" |
| `THESAURUS_LOOKUP` | ThesaurusEngine | ✅ Working | "Synonym for happy" |
| `CODE_QUERY` | CodeQueryExecutor | ✅ Working | "How does my code work?" |
| `CODE_SEARCH` | CodeSearchExecutor | ✅ Working | "Where is move defined?" |
| `RESOURCE_OPERATION` | ResourceOperationExecutor | ✅ Working | "Create a sprite" |
| `PROJECT_MODIFICATION` | ProjectModificationExecutor | ⚠️ Stub | "Modify file X" |
| `GRAPH_VISUALIZATION` | GraphVisualizationExecutor | ✅ Working | "Show dependencies" |
| `GENERAL_CHAT` | ConversationEngine | ✅ Working | "Hello" |

---

## SLM (Small Language Model) Integration

Nova uses a **CustomNeuralModel** (neural network) for intent classification when available, with fallback to TinyIntentModel:

**How It Works:**
1. Tries CustomNeuralModel first (trained on 32,000+ examples)
2. Falls back to TinyIntentModel if CustomNeuralModel unavailable
3. Falls back to keyword patterns if SLM unavailable or low confidence
4. Uses pattern matching as final fallback

**Benefits:**
- Better intent detection for complex queries (neural network vs logistic regression)
- Handles variations in phrasing
- More natural language understanding
- Consistent training data (template-based, 32k+ examples)
- Explainability and confidence calibration

**Training:**
- Training script: `Core/AI/PyGenesisAssistant/Nova/core/slm/train_model.py`
- Training data: `Core/AI/PyGenesisAssistant/Nova/core/slm/training_data.json` (32,000+ examples)
- Templates: `Core/AI/PyGenesisAssistant/Nova/core/slm/intent_templates.json`
- Model file: `Core/AI/PyGenesisAssistant/Nova/core/slm/models/neural_model.json`

**To Train/Retrain:**
```bash
python Core/AI/PyGenesisAssistant/Nova/core/slm/train_model.py
```

**Example:**
```
"Can you help me add occlusion culling?"
  ↓
CustomNeuralModel → PROJECT_MODIFICATION (confidence: 0.85)
  ↓
Routes to ProjectModificationExecutor
```

---

## Cloud AI Mode

**When Enabled:**
- Complex queries requiring reasoning
- Code generation requests
- Implementation suggestions
- Questions requiring deep knowledge

**Current Status:** Stubbed - needs API integration

**Future Implementation:**
- Gemini API integration
- OpenAI API integration
- Anthropic API integration
- Context-aware code generation

---

## Tips for Best Results

1. **Be Specific:** "Create a sprite named Player" vs "create something"
2. **Use Natural Language:** Nova understands conversational queries
3. **For Math:** Use natural language or direct expressions
4. **For Research:** Ask "What is X?" format
5. **For Code:** Reference your project context
6. **For Resources:** Use resource type names (sprite, object, etc.)

---

## New Features

### Show Thinking / Show Preview

Nova now provides transparency into its decision-making:

- **🔍 Show Thinking**: Collapsible button showing Nova's reasoning process
  - What capabilities were discovered
  - What knowledge was consulted
  - How the operation plan was created

- **👁️ Show Preview**: Button opening preview dialog
  - Operation summary with risk assessment
  - List of all operations to be performed
  - Affected files and systems
  - File diffs with green (additions) / red (removals) highlighting

### Transaction Management

All operations are now **atomic**:
- ✅ Either all changes apply, or none apply
- ✅ Automatic rollback on failure
- ✅ File backups before modification
- ✅ Resource backups before changes
- ✅ Multi-file transaction support

### Operation Planning

Nova now plans operations before execution:
- ✅ Risk assessment (Low/Medium/High/Critical)
- ✅ Rationale generation
- ✅ Expected outcome prediction
- ✅ Affected systems identification
- ✅ Hierarchical task creation (1, 1.1, 1.2, etc.)

### API Surface Manifest

Nova validates all operations against PyGenesis's API:
- ✅ Formal API definition for all public methods
- ✅ Parameter validation
- ✅ Return type checking
- ✅ Signal emission tracking
- ✅ Side effect documentation

### Preferences Integration

- ✅ "Allow High Risk Operations" setting in Edit → Preferences → AI → Edits
- ✅ When enabled, skips confirmation for high-risk operations
- ✅ When disabled, requires user confirmation

---

## Current Limitations

1. ⚠️ Cloud AI not integrated (stubbed)
2. ⚠️ Complex implementation queries need Cloud AI
3. ✅ All other features working

---

## Future Enhancements

1. Cloud AI integration for complex queries
2. Code generation capabilities
3. Enhanced project analysis
4. Better context awareness
5. Advanced error recovery

