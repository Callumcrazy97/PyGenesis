# Mode Auto-Detection - How It Works

## Overview

UnifiedCodeEditor now **automatically detects** which language (PGSL or Python) is being used. There is **no mode toggle** in the editor - mode is controlled entirely by the **Advanced Mode** setting in Preferences.

## How It Works

### Advanced Mode OFF (Simple Mode)
- ✅ **Only PGSL** is supported
- ✅ All code is validated as PGSL
- ✅ Syntax highlighting is PGSL
- ❌ Python code will not work

### Advanced Mode ON (Advanced Mode)
- ✅ **Both PGSL and Python** are supported
- ✅ Editor **auto-detects** which language is being used
- ✅ Syntax highlighting switches automatically
- ✅ Validation tries both languages if needed
- ✅ Test execution uses detected language

## Auto-Detection Logic

The editor analyzes code content to determine language:

### PGSL Indicators
If code contains any of these, it's detected as PGSL:
- `variable_set`, `variable_get`
- `create_instance`, `instance_destroy`
- `draw_sprite_2d`, `draw_text_2d`
- `camera2d_set_position`, `camera3d_set_position`
- `sound_play`, `key_check`
- `game_end`, `game_save`, `game_load`

### Python Indicators
If code contains any of these, it's detected as Python:
- `def function_name` (function definitions)
- `class ClassName` (class definitions)
- `import module` (import statements)
- `from module import` (from imports)
- `print(` (print function calls)

### Default Behavior
- **Advanced Mode ON**: Defaults to Python if no indicators found
- **Advanced Mode OFF**: Always PGSL

## Validation Behavior

### Advanced Mode ON
1. Detects language from code
2. Validates with detected language
3. If validation fails and detected was Python, tries PGSL as fallback
4. Uses whichever gives better results

### Advanced Mode OFF
- Always validates as PGSL only

## Example Usage

### Example 1: PGSL Code (Advanced Mode ON)
```pgsl
if true:
    variable_set("count", 10)
    print("Count: " + variable_get("count"))
```
**Detected**: PGSL (has `variable_set`, `variable_get`)
**Validation**: PGSL validator
**Execution**: PGSL (when compiler complete)

### Example 2: Python Code (Advanced Mode ON)
```python
def add(a, b):
    return a + b

result = add(5, 3)
print(result)
```
**Detected**: Python (has `def`, `print(`)
**Validation**: Python validator
**Execution**: Python sandbox

### Example 3: Mixed Code (Advanced Mode ON)
```python
# Python function
def calculate(x, y):
    return x + y

# PGSL call
variable_set("result", calculate(10, 20))
```
**Detected**: Python (has `def`)
**Validation**: Tries Python first, then PGSL if needed
**Note**: Mixed code may have validation issues - prefer one language per file

## Benefits

1. **No Manual Mode Switching** - Editor detects automatically
2. **Seamless Experience** - Just write code, editor figures it out
3. **Smart Fallback** - Tries both languages if validation fails
4. **Consistent with Preferences** - Advanced Mode setting controls everything

## For Nova

Nova should use `CodeAcceptanceContract.suggest_mode()` to determine which language to generate:
- If Advanced Mode OFF: Always generate PGSL
- If Advanced Mode ON: Use `suggest_mode()` to detect, or generate Python by default

## Testing

### Test PGSL (Simple Mode)
1. Turn Advanced Mode OFF
2. Write PGSL code
3. Should validate as PGSL
4. Should syntax highlight as PGSL

### Test Python (Advanced Mode)
1. Turn Advanced Mode ON
2. Write Python code
3. Should auto-detect Python
4. Should validate as Python
5. Should execute as Python

### Test Auto-Detection (Advanced Mode)
1. Turn Advanced Mode ON
2. Write PGSL code (with `variable_set`, etc.)
3. Should auto-detect PGSL
4. Write Python code (with `def`, etc.)
5. Should auto-detect Python

