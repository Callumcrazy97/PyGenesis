# Script Editor Testing Guide

## Quick Start

### Step 1: Create a Test Script Resource

1. Open PyGenesis
2. Right-click on "Scripts" folder in Resource Tree
3. Create a new script resource
4. Name it "test_script" (or any name)

### Step 2: Test PGSL Mode (Simple Mode)

**When to Use**: Advanced Mode is **OFF** in Preferences → General

**Example PGSL Code**:
```pgsl
// Simple PGSL test script
if true:
    print("Hello from PGSL!")
    variable_set("count", 10)
    print("Count is: " + variable_get("count"))
```

**What to Test**:
1. ✅ Code editing works
2. ✅ Syntax highlighting works
3. ✅ Click "Check Full" - should validate PGSL syntax
4. ✅ Click "Test Code" - may show "PGSL execution not yet implemented" (expected)
5. ✅ Save works
6. ✅ Reload works

---

### Step 3: Test Python Mode (Advanced Mode)

**When to Use**: Advanced Mode is **ON** in Preferences → General

**Example Python Code**:
```python
# Python test script
def greet(name):
    return f"Hello, {name}!"

def calculate(x, y):
    result = x + y
    print(f"{x} + {y} = {result}")
    return result

# Test the functions
greet("World")
calculate(5, 3)
```

**What to Test**:
1. ✅ Code editing works
2. ✅ Syntax highlighting works (Python colors)
3. ✅ Mode toggle appears in toolbar
4. ✅ Click "Check Full" - should validate Python syntax
5. ✅ Click "Test Code" - should execute and show output
6. ✅ Select some code, click "Check Selected" - validates selection
7. ✅ Select some code, click "Test Selected" - executes selection
8. ✅ Save works
9. ✅ Reload works

---

## Testing Workflow

### Basic Functionality Test

1. **Open Script Editor**
   - Double-click a script resource
   - Editor should open with UnifiedCodeEditor

2. **Code Editing**
   - Type some code
   - Verify syntax highlighting updates
   - Verify "dirty" state (unsaved indicator)

3. **Validation**
   - Click "Check Full" button
   - Check diagnostics panel for errors/warnings
   - Fix any errors
   - Click "Check Full" again - should show "✅ Code check passed"

4. **Test Execution** (Python only)
   - Click "Test Code" button
   - Should show execution results in dialog
   - Check output, variables, return value

5. **Selection Testing**
   - Select a portion of code
   - Click "Check Selected" - validates only selection
   - Click "Test Selected" - executes only selection

6. **Save/Load**
   - Make changes
   - Save (Ctrl+S or File → Save)
   - Close editor
   - Reopen - changes should persist

---

## Test Scripts

### Test Script 1: Simple PGSL (Simple Mode)

```pgsl
// PGSL Test Script
// This tests basic PGSL functionality

if true:
    print("PGSL script is working!")
    variable_set("test_value", 42)
    print("Test value: " + variable_get("test_value"))
```

**Expected Results**:
- ✅ Syntax highlighting works
- ✅ "Check Full" validates (may show warnings if PGSL validator incomplete)
- ✅ "Test Code" shows "PGSL execution not yet implemented" (expected)

---

### Test Script 2: Simple Python (Advanced Mode)

```python
# Python Test Script
# This tests basic Python functionality

def add_numbers(a, b):
    """Add two numbers"""
    result = a + b
    print(f"{a} + {b} = {result}")
    return result

# Test the function
result = add_numbers(10, 20)
print(f"Final result: {result}")
```

**Expected Results**:
- ✅ Syntax highlighting works (Python colors)
- ✅ "Check Full" validates successfully
- ✅ "Test Code" executes and shows:
  - Output: "10 + 20 = 30\nFinal result: 30"
  - Variables: `result = 30`
  - Success message

---

### Test Script 3: Python with Errors (Advanced Mode)

```python
# Python Test Script with Errors
# This tests error detection

def broken_function(
    # Missing closing parenthesis
    x = 10
    return x  # Syntax error
```

**Expected Results**:
- ✅ "Check Full" shows syntax error
- ✅ Diagnostics panel shows error details
- ✅ "Test Code" shows error message
- ✅ Cannot execute until fixed

---

### Test Script 4: Selection Testing (Advanced Mode)

```python
# Selection Test Script
# Test "Check Selected" and "Test Selected"

def function_a():
    return "A"

def function_b():
    return "B"

def function_c():
    return "C"

# Test selection
result = function_b()
print(result)
```

**Testing Steps**:
1. Select only `function_b()` and the `result = function_b()` line
2. Click "Check Selected" - should validate just that selection
3. Click "Test Selected" - should execute just that selection
4. Should show output: "B"

---

## Mode Switching Test

### Test Simple ↔ Advanced Mode

1. **Start in Simple Mode** (Advanced Mode OFF)
   - Editor should default to PGSL mode
   - Mode toggle should NOT be visible (or disabled)
   - Only PGSL syntax highlighting

2. **Enable Advanced Mode**
   - Go to Preferences → General → Check "Advanced Mode"
   - Save preferences
   - Reload Script Editor

3. **Verify Advanced Mode**
   - Mode toggle should be visible
   - Can switch between "Simple (PGSL)" and "Advanced (Python + PGSL)"
   - Syntax highlighting switches accordingly

4. **Test Both Modes**
   - Switch to PGSL, write PGSL code, validate
   - Switch to Python, write Python code, validate and test

---

## What to Check

### ✅ Must Work

- [ ] Script Editor opens when double-clicking script resource
- [ ] Code editing works (typing, selection, copy/paste)
- [ ] Syntax highlighting works
- [ ] "Check Full" validates code
- [ ] "Check Selected" validates selection
- [ ] "Test Code" executes Python code (Advanced Mode)
- [ ] "Test Selected" executes selection (Advanced Mode)
- [ ] Diagnostics panel shows errors/warnings
- [ ] Save works (Ctrl+S)
- [ ] Load works (reopen script)
- [ ] Unsaved changes prompt works
- [ ] Mode switching works (Advanced Mode)

### ⚠️ Expected Limitations

- **PGSL Execution**: May show "PGSL execution not yet implemented" (expected - compiler incomplete)
- **PGSL Validation**: May have limited validation (PGSL compiler is ~10% complete)
- **Python Execution**: Should work fully

---

## Troubleshooting

### Script Editor Doesn't Open

**Check**:
- Is `Editors/CodeEditor/ScriptEditor.py` in the correct location?
- Are there any import errors in console?
- Does EditorFactory find ScriptEditor?

**Fix**:
- Check console for errors
- Verify file exists: `Editors/CodeEditor/ScriptEditor.py`

### Code Editor Doesn't Appear

**Check**:
- Is UnifiedCodeEditor imported correctly?
- Are there any errors in console?

**Fix**:
- Check console for import errors
- Verify `Core/Code/Unified/__init__.py` exports UnifiedCodeEditor

### Validation Doesn't Work

**Check**:
- Is validation pipeline initialized?
- Are there errors in diagnostics panel?

**Fix**:
- Check console for validation errors
- Verify CodeSystem is available for PGSL validation

### Test Execution Doesn't Work

**Check**:
- Is Advanced Mode enabled?
- Are you testing Python code (not PGSL)?
- Are there syntax errors?

**Fix**:
- Enable Advanced Mode in Preferences
- Use Python code for testing
- Fix any syntax errors first

---

## Success Criteria

✅ **Script Editor is working if**:
- Opens when double-clicking script resource
- Code editing works smoothly
- Validation works (PGSL and Python)
- Test execution works (Python)
- Save/load works
- Mode switching works (Advanced Mode)

🎉 **Ready for Object Editor integration if all above work!**

