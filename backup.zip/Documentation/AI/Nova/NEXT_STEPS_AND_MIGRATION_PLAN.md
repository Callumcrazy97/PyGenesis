# Next Steps and Migration Plan

## Executive Summary

✅ **UnifiedCodeEditor is complete and architecturally sound**

**Status**: Ready for testing and migration

**Risk Level**: Low (clean implementation, no legacy debt)

---

## Immediate Next Steps

### Step 1: Standalone Test Harness ✅

**File**: `Core/Code/Unified/test_harness.py`

**Purpose**: Verify UnifiedCodeEditor works correctly before any migration

**What to Test**:
- [ ] Mode switching (Simple ↔ Advanced)
- [ ] Validation (PGSL and Python)
- [ ] Test execution (Python)
- [ ] Diagnostics display
- [ ] Advanced Mode setting integration
- [ ] No hidden dependencies
- [ ] No lifecycle bugs
- [ ] No UI regressions

**How to Run**:
```python
from Core.Code.Unified.test_harness import create_test_window

# In main.py or test script
test_window = create_test_window(app)
test_window.show()
```

**DO NOT**: Integrate this into production - it's for testing only

---

### Step 2: CodeAcceptanceContract Integration ✅

**File**: `Core/Code/Unified/acceptance_contract.py`

**Purpose**: Allows Nova to check if code will be accepted before generating

**Key Methods**:
```python
contract = CodeAcceptanceContract(project_path)

# Nova uses this before generating code
result = contract.validate_for_nova(
    code, mode, context, advanced_mode_enabled
)

if result.can_accept:
    # Generate code
else:
    # Fix issues first
```

**Benefits**:
- Prevents Nova from generating illegal code
- Simplifies Nova prompts
- Makes Simple/Advanced mode airtight
- Reduces hallucinations

---

## Migration Order (Do Not Deviate)

### Phase A: Script Editor (First and Only)

**Why Script Editor First**:
- ✅ No event context complexity
- ✅ No object lifecycle hooks
- ✅ Pure code editing
- ✅ Simplest integration

**Goal**: Prove UnifiedCodeEditor can fully replace a real editor

**What to Replace**:
- Current Script Editor implementation
- Use UnifiedCodeEditor as the core

**Success Criteria**:
- ✅ Script Editor works identically
- ✅ Nova integration works
- ✅ PGSL gaps become visible
- ✅ Execution model validated

**When Complete**:
- Nova integration becomes trivial
- Foundation proven
- Ready for next phase

---

### Phase B: Object Editor (Code Panel Only)

**Important Rule**: 
- ❌ Do NOT touch left panel (properties)
- ❌ Do NOT touch middle panel (events)
- ✅ Replace ONLY the code editor widget

**Why This Order**:
- If something breaks, issue is in UnifiedCodeEditor
- Not Object Editor logic
- Keeps debugging surgical

**What to Replace**:
- `Editors/ObjectEditor/UI/code_editor_widget.py`
- Or `Editors/ObjectEditor/code_editor_dock.py`
- With UnifiedCodeEditor

**Success Criteria**:
- ✅ Event code editing works
- ✅ Event switching works
- ✅ Code persists correctly
- ✅ Validation works per event

---

### Phase C: Shader / Particle Editors

**Why These Are Easier**:
- ✅ No lifecycle hooks
- ✅ Fewer events
- ✅ Simpler validation
- ✅ Object Editor already proven the pattern

**What to Replace**:
- Shader Editor code sections
- Particle Editor code sections

---

## What NOT to Do Yet

### ❌ Do NOT Expand PGSL Syntax
- Locking the contract was correct
- Let Nova + Script Editor pressure-test PGSL first
- Wait for real-world usage patterns

### ❌ Do NOT Refactor Old Editors Yet
- They still work
- Don't destabilize
- Migrate incrementally

### ❌ Do NOT "Optimize" Execution Engine
- It is correct by design, not by speed
- Safety > Performance at this stage
- Optimize after usage patterns emerge

### ❌ Do NOT Add Nova-Specific Hacks
- Use CodeAcceptanceContract instead
- Keep Nova as a client, not integrated
- Maintain clean separation

---

## Testing Checklist

### Standalone Test Harness
- [ ] Window opens correctly
- [ ] Editor displays
- [ ] Mode switching works
- [ ] Python sample loads
- [ ] PGSL sample loads
- [ ] Invalid sample shows errors
- [ ] Validation works
- [ ] Test execution works
- [ ] Diagnostics display correctly

### Script Editor Migration
- [ ] Script Editor opens
- [ ] Code editing works
- [ ] Validation works
- [ ] Test execution works
- [ ] Mode switching works
- [ ] Advanced Mode setting respected
- [ ] Nova can generate code
- [ ] Code is accepted correctly

### Object Editor Migration
- [ ] Object Editor opens
- [ ] Event code editing works
- [ ] Event switching preserves code
- [ ] Validation works per event
- [ ] Test execution works
- [ ] Properties panel still works
- [ ] Events panel still works

---

## Nova Integration Strategy

### Using CodeAcceptanceContract

**Before Generating Code**:
```python
from Core.Code.Unified import CodeAcceptanceContract, CodeMode, EditorContext

contract = CodeAcceptanceContract(project_path)

# Check if code will be accepted
result = contract.validate_for_nova(
    generated_code,
    CodeMode.PGSL,  # or PYTHON if Advanced Mode
    EditorContext.SCRIPT,
    advanced_mode_enabled
)

if not result.can_accept:
    # Fix issues before generating
    # Or use different approach
```

**Benefits**:
- Nova knows what will be accepted
- Prevents generation of invalid code
- Reduces retry loops
- Makes Simple/Advanced mode airtight

---

## Risk Assessment

### Low Risk Areas ✅
- Standalone test harness (isolated)
- Script Editor migration (simple, no dependencies)
- CodeAcceptanceContract (read-only, no side effects)

### Medium Risk Areas ⚠️
- Object Editor migration (more complex, event system)
- Shader/Particle editors (less tested)

### High Risk Areas ❌
- None identified - architecture is sound

---

## Success Metrics

### Phase A (Script Editor) Success
- ✅ Script Editor works identically to before
- ✅ Nova can generate and validate code
- ✅ No regressions
- ✅ Performance acceptable

### Phase B (Object Editor) Success
- ✅ Code editing works in events
- ✅ Event switching works
- ✅ No property/event panel issues
- ✅ Validation works per event

### Phase C (Other Editors) Success
- ✅ All editors use UnifiedCodeEditor
- ✅ Consistent behavior
- ✅ No editor-specific hacks

---

## Timeline Estimate

### Week 1: Testing
- Standalone test harness
- Verify all features
- Fix any issues

### Week 2: Script Editor Migration
- Replace Script Editor
- Test thoroughly
- Verify Nova integration

### Week 3: Object Editor Migration
- Replace code widget
- Test event system
- Verify no regressions

### Week 4: Other Editors
- Shader Editor
- Particle Editor
- Final testing

### Week 5: Cleanup
- Remove old implementations
- Update documentation
- Consolidate code

---

## Key Principles

1. **Test First**: Always test in isolation before integration
2. **One at a Time**: Migrate editors one by one
3. **No Regressions**: Old functionality must still work
4. **Clean Separation**: Keep Nova as client, not integrated
5. **Safety First**: No file modifications in tests

---

## Status

✅ **Ready for Testing**
- All phases complete
- Test harness created
- CodeAcceptanceContract ready
- Migration plan defined

🎯 **Next Action**: Run standalone test harness and verify all features

