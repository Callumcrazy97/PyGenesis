# Next Phase Status - Code Editor Integration

## ✅ Completed

### Phase A: Script Editor Integration - **COMPLETE**
- ✅ `ScriptEditor.py` created and integrated
- ✅ Uses `UnifiedCodeEditor` with `EditorContext.SCRIPT`
- ✅ All features working: validation, test execution, diagnostics
- ✅ PGSL and Python modes working
- ✅ Test scripts validate correctly
- ✅ File save/load working correctly
- ✅ Purge system integration complete

**Status**: Ready for production use

---

## 🎯 Next Steps

### Phase B: Object Editor Integration ✅ COMPLETE

**Status**: Integration complete, ready for testing

### Phase C: Shader Editor Integration (NEXT PRIORITY)

**Goal**: Replace Object Editor's code widget with `UnifiedCodeEditor`

**File to Modify**: `Editors/ObjectEditor/UI/code_editor_widget.py`

**What Needs to Be Done**:

1. **Replace Code Editor Widget**
   - Replace current code editor (likely `CodeEditorDock` or extends `BaseCodeEditor`)
   - Use `UnifiedCodeEditor` with `EditorContext.OBJECT_EVENT`
   - Maintain event switching functionality

2. **Key Requirements**:
   - ✅ Code editing works for object events
   - ✅ Event switching preserves code correctly
   - ✅ Each event has its own code context
   - ✅ Validation works per event
   - ✅ Test execution works per event
   - ✅ Maximize/dock features still work (if applicable)
   - ❌ Don't touch property panel
   - ❌ Don't touch events panel (left/middle panels)

3. **Testing Checklist**:
   - [ ] Object Editor opens
   - [ ] Can create/edit objects
   - [ ] Event code editing works
   - [ ] Switching between events preserves code
   - [ ] Validation works for each event
   - [ ] Test execution works
   - [ ] No regressions in property/event panels

**Why This Order**: 
- Object Editor is simpler than Script Editor (just code panel replacement)
- Script Editor already proved the pattern works
- Keeps migration surgical (only code widget, not entire editor)

---

### Phase C: Shader Editor Integration (AFTER OBJECT EDITOR)

**Goal**: Replace Shader Editor's code sections with `UnifiedCodeEditor`

**Files to Find**: Shader Editor implementation (location TBD)

**What Needs to Be Done**:
- Find Shader Editor code widget
- Replace with `UnifiedCodeEditor`
- Set context to `EditorContext.SHADER`
- Support Video and Compute shaders

**Status**: Waiting for Phase B completion

---

## 📋 Integration Pattern

All editors follow this same pattern:

```python
from Core.Code.Unified import UnifiedCodeEditor, EditorContext

# Replace existing code editor with:
self.code_editor = UnifiedCodeEditor(
    app,
    context=EditorContext.OBJECT_EVENT,  # or SHADER for shaders
    parent=self
)

# Connect signals
self.code_editor.code_changed.connect(self._on_code_changed)
self.code_editor.validation_complete.connect(self._on_validation_complete)

# Use API methods
self.code_editor.set_code(code, suppress_signals=True)
code = self.code_editor.get_code()
is_dirty = self.code_editor.is_dirty()
```

---

## ⚠️ Critical Rules

1. **Migrate one editor at a time** - Test thoroughly before next
2. **Don't delete old code yet** - Keep until migration proven
3. **Test thoroughly** - Each editor must work identically to before
4. **No regressions** - Old functionality must still work
5. **Only replace code widget** - Don't touch other panels/functionality

---

## 🎯 Immediate Next Action

**Start Phase B: Object Editor Integration**

1. Read `Editors/ObjectEditor/UI/code_editor_widget.py` to understand current implementation
2. Understand how event switching works
3. Replace code widget with `UnifiedCodeEditor`
4. Test thoroughly
5. Verify no regressions

**Estimated Time**: 1-2 hours for careful integration and testing

