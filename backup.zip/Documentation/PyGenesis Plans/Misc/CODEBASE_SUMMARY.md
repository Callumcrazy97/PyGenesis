# Codebase Summary: `Temp`

## Overview

- Root path: `C:\Design\Python\IDE Development\Newest PyGenesis\Original\Old Version\Temp`
- Total files: **227**
- Approx total size: **21.5 MB**

### Top-level directories

- `Code/`
- `Config/`
- `Core/`
- `Documentation/`
- `Editors/`
- `Examples/`
- `Files/`
- `Screen_Recording_App/`
- `UI/`
- `core_libs/`
- `optional_libs/`
- `store_cache/`

### File types

- `.py`: 181
- `.json`: 29
- `.md`: 15
- `.txt`: 1
- `.png`: 1

## Project tree (truncated)

- **Temp/**
  - **Code/**
    - **Base/**
      - __init__.py
      - base_code_editor.py
      - base_syntax_highlighter.py
    - **PGSL/**
      - __init__.py
      - Parser.py
      - PGSL_Commands.py
      - pgsl_parser.py
      - pgsl_runtime.py
    - **Shared/**
      - __init__.py
      - code_completer.py
      - pgsl_help_manual.py
      - script_validator.py
  - **Config/**
    - __init__.py
    - CoreRequirements.json
    - InstalledPackagesCache.json
    - OptionalRequirements.json
    - PyPICache.json
    - Requirements.json
    - Settings.py
    - ThemeManager.py
  - **Core/**
    - **Code/**
      - **Base/**
      - **PGSL/**
      - **Shared/**
    - **Rendering/**
      - __init__.py
      - BufferManager.py
      - Canvas_2D.py
      - OpenGLRuntime.py
      - ShaderManager.py
      - SuperShader_2D.py
      - TextureManager.py
    - **Services/**
      - __init__.py
      - file_service.py
      - project_service.py
      - resource_service.py
      - script_checker.py
      - validation_service.py
    - __init__.py
    - BackupManager.py
    - Debug.py
    - DeletePyCache.py
    - EditorFactory.py
    - EditorInterface.py
    - Events.py
    - ExtensionsManager.py
    - GameGenerator.py
    - ModulePreloader.py
    - PackageInstaller.py
    - PackageLoadThread.py
    - PackageSearchThread.py
    - ProjectManager.py
    - PyPILoadThread.py
    - ResourceManager.py
    - UtilityOperations.py
    - VenvManager.py
  - **core_libs/**
    - **numpy/**
      - manifest.json
    - **pillow/**
      - manifest.json
    - **pyopengl/**
      - manifest.json
    - **pyopengl_accelerate/**
      - manifest.json
    - **pyside6/**
      - manifest.json
    - **pyside6_addons/**
      - manifest.json
    - **setuptools/**
      - manifest.json
  - **Documentation/**
    - **Editors/**
      - **PGCE PyCode/**
      - **PGIE Piggie/**
      - **PGME Pigmie/**
      - **PGOE Pygo/**
      - **PGRE Pygress/**
    - **Misc/**
    - **PyGenesis Plans/**
      - **Misc/**
      - **Roadmap/**
      - **Tutorials/**
      - Summary Of PyGenesis.md
  - **Editors/**
    - **Image/**
      - **2/**
      - **ui/**
      - __init__.py
    - **Model/**
      - **Examples/**
      - __init__.py
    - **Object/**
      - code_editor_dock.py
      - event_tree_widget.py
      - object_editor.py
      - object_editor_menu.py
      - object_editor_ui.py
      - object_events_panel.py
      - object_properties_panel.py
      - sprite_browser_widget.py
    - **Script/**
      - script_editor.py
    - **Sound/**
      - WaveForge.py
    - __init__.py
    - CodeEditor.py
    - ModelEditor.py
    - RoomEditor.py
    - ScriptEditor.py
    - SoundEditor.py
    - SpriteEditor.py
    - test_ai_scenario_output.png
    - TextureEditor.py
  - **Examples/**
    - **object_editor/**
      - __init__.py
      - code_editor.py
      - event_editor.py
      - inheritance_panel.py
      - object_editor.py
      - properties_panel.py
    - **room_editor/**
      - __init__.py
      - background_editor.py
      - Basic Map Editor.py
      - instance_manager.py
      - layer_manager.py
      - Map_Editor.py
      - room_editor.py
      - tile_editor.py
      - viewport.py
    - **script_editor/**
      - __init__.py
      - ai_assistant.py
      - ai_sidebar.py
      - code_analyzer.py
      - code_completion.py
      - code_editor.py
      - code_editor_launcher.py
      - debugger.py
      - file_manager.py
      - problems_panel.py
      - script_editor.py
      - search_replace.py
      - settings_dialog.py
      - start_editor.py
      - syntax_highlighter.py
  - **Files/**
    - **Room/**
      - Map_Editor.py
    - **Script/**
      - CodeAnalyser.py
      - DependencyAnalyser.py
      - ScriptEditor.py
  - **optional_libs/**
    - **json5/**
      - manifest.json
    - **librosa/**
      - manifest.json
    - **mido/**
      - manifest.json
    - **mss/**
      - manifest.json
    - **music21/**
      - manifest.json
    - **numba/**
      - manifest.json
    - **opencv_python/**
      - manifest.json
    - **pycollada/**
      - manifest.json
    - **pydub/**
      - manifest.json
    - **pygame/**
      - manifest.json
    - **pytest/**
      - manifest.json
    - **pytest_qt/**
      - manifest.json
    - **soundfile/**
      - manifest.json
    - **trimesh/**
      - manifest.json
  - **Screen_Recording_App/**
    - integrated_screen_recorder.py
  - **store_cache/**
    - pypi_cache.json
  - **UI/**
    - __init__.py
    - ExtensionsDialog.py
    - LoadingWidget.py
    - MainWindow.py
    - PreferencesDialog.py
    - ResourceTree.py
    - TerminalWidget.py
    - ThumbnailLoader.py
  - GenerateSummary.py
  - main.py
  - pyrightconfig.json
  - requirements.txt

## Key Python modules (largest by size)

### `Editors\ModelEditor.py`
- Size: 568.4 KB (11919 lines approx)
- First meaningful line:
```
from PySide6.QtWidgets import (
```

### `Editors\Image\2\ui\main_window.py`
- Size: 281.2 KB (6486 lines approx)
- First meaningful line:
```
from PySide6.QtWidgets import QMainWindow, QWidget, QHBoxLayout, QVBoxLayout, QMenuBar, QFileDialog, QLabel, QPushButton, QSizePolicy, QSpacerItem, QDialog, QMessageBox
```

### `Editors\Image\2\ui\dialogs\effect_dialog.py`
- Size: 263.8 KB (5774 lines approx)
- Docstring:
```
Unified Effect Dialog for Image Editor
Extracted from dialogs.py
```

### `Editors\SpriteEditor.py`
- Size: 169.5 KB (3826 lines approx)
- Docstring:
```
Sprite Editor for Python Game IDE
GameMaker 8-style sprite editor with properties panel and preview box
```

### `Editors\Image\2\ui\preview.py`
- Size: 140.3 KB (3154 lines approx)
- First meaningful line:
```
from PySide6.QtWidgets import QWidget, QSizePolicy
```

### `Editors\TextureEditor.py`
- Size: 139.2 KB (3239 lines approx)
- First meaningful line:
```
"""
```

### `Editors\Model\Examples\PoorPerformanceCreationAndLoading.py`
- Size: 131.9 KB (3406 lines approx)
- Docstring:
```
3D Model Viewer and Editor - SketchUp-like Application
A single-file 3D modeling application with real-time editing capabilities.
```

### `Editors\SoundEditor.py`
- Size: 121.1 KB (2955 lines approx)
- Docstring:
```
Sound Editor for Python Game IDE
GameMaker 8-style sound editor with properties panel and preview box
PGSE "Pigsey" - PyGenesis Sound Editor
```

### `Editors\Image\2\ui\character_creator_dialog.py`
- Size: 102.8 KB (2208 lines approx)
- First meaningful line:
```
import sys
```

### `UI\PreferencesDialog.py`
- Size: 99.4 KB (2101 lines approx)
- Docstring:
```
Preferences Dialog for Python Game IDE
Centralized preferences for all editors and settings
```

### `Examples\room_editor\Map_Editor.py`
- Size: 82.8 KB (1681 lines approx)
- Docstring:
```
Map_Editor.py
2D Map Editor for Among Us 2D Clone
Creates and edits barrier layouts, saves to JSON
Enhanced with dynamic sizing, rotation controls, and multiple object types
Supports custom object types with images, file dialogs for save/load/background.
Includes instance management (visibility t...
```

### `Files\Room\Map_Editor.py`
- Size: 82.8 KB (1681 lines approx)
- Docstring:
```
Map_Editor.py
2D Map Editor for Among Us 2D Clone
Creates and edits barrier layouts, saves to JSON
Enhanced with dynamic sizing, rotation controls, and multiple object types
Supports custom object types with images, file dialogs for save/load/background.
Includes instance management (visibility t...
```

### `Core\ResourceManager.py`
- Size: 79.5 KB (1809 lines approx)
- Docstring:
```
Resource Manager for Python Game IDE
Handles resource creation, editing, and management
```

### `UI\ResourceTree.py`
- Size: 79.0 KB (1835 lines approx)
- Docstring:
```
Resource Tree Widget for Python Game IDE
Displays project resources in a tree structure with drag and drop support
```

### `Examples\object_editor\object_editor.py`
- Size: 69.9 KB (1439 lines approx)
- Docstring:
```
PyGenesis IDE - Object Editor
GameMaker-style object editor with comprehensive properties and event system
```

### `UI\MainWindow.py`
- Size: 65.0 KB (1607 lines approx)
- Docstring:
```
Main Window for Python Game IDE
GameMaker-style interface with resource tree and editors
```

### `Core\ProjectManager.py`
- Size: 61.9 KB (1234 lines approx)
- Docstring:
```
Project Manager for Python Game IDE
Handles project creation, loading, and management
```

### `Editors\Image\2\ui\timeline.py`
- Size: 61.5 KB (1446 lines approx)
- First meaningful line:
```
from PySide6.QtWidgets import (QWidget, QHBoxLayout, QVBoxLayout, QPushButton,
```

### `Examples\script_editor\code_editor.py`
- Size: 61.0 KB (1532 lines approx)
- Docstring:
```
PyGenesis Code Editor - Professional Edition
A standalone code editor that can also be integrated into the PyGenesis IDE.
Features syntax highlighting, file management, and professional dark theme.
```

### `Files\Script\CodeAnalyser.py`
- Size: 57.1 KB (1281 lines approx)
- Docstring:
```
GUI Python Code Analyzer - Enhanced
Enhanced version with collapsible sections, summaries, color coding, and better reporting
```

### `Files\Script\ScriptEditor.py`
- Size: 54.9 KB (1355 lines approx)
- Docstring:
```
PyGenesis Object Script Editor
A specialized code editor for game objects in the PyGenesis Game Development IDE.
```

### `Examples\script_editor\ai_assistant.py`
- Size: 50.7 KB (1256 lines approx)
- Docstring:
```
PyGenesis Code Editor - AI Assistant Engine
Local AI processing for code analysis, error detection, and assistance.
```

### `Editors\Sound\WaveForge.py`
- Size: 43.0 KB (1225 lines approx)
- Docstring:
```
WaveForge - Audacity-style Waveform Editor
Advanced multi-track audio editing with waveform visualization
```

### `Editors\Image\2\services\effect_processor.py`
- Size: 42.6 KB (978 lines approx)
- Docstring:
```
Effect Processor Service
Handles all image effect processing operations.
Extracted from main_window.py for better separation of concerns.

This service processes image effects without UI dependencies.
Methods that need state/UI access should remain in main_window and call this service.
```

### `UI\ExtensionsDialog.py`
- Size: 41.9 KB (1020 lines approx)
- Docstring:
```
Extensions Manager Dialog for PyGenesis IDE
Installed (Core/Optional/Other) + Store tabs.

This version:
- Uses your existing architecture and threads.
- Integrates with the updated ExtensionsManager (with get_outdated_packages).
- Adds a "Check Updates" button to highlight outdated packages in t...
```

### `Files\Script\DependencyAnalyser.py`
- Size: 41.6 KB (937 lines approx)
- Docstring:
```
Python Code Flow Visualizer
Analyzes Python files to show:
- What functions/classes are created in each script
- What functions/classes are imported/called by each script  
- Visual workflow showing dependencies and usage patterns
```

### `Editors\Image\2\ui\panels\right_panel.py`
- Size: 41.4 KB (891 lines approx)
- First meaningful line:
```
from PySide6.QtWidgets import QFrame, QVBoxLayout, QLabel, QPushButton, QWidget, QHBoxLayout, QInputDialog, QSizePolicy, QLineEdit, QSlider, QScrollArea, QTabWidget, QColorDialog, QCheckBox, QHBoxL...
```

### `Editors\Image\2\core\selection_manager.py`
- Size: 39.8 KB (1005 lines approx)
- First meaningful line:
```
from PySide6.QtCore import Qt, QRectF
```

### `Editors\Image\2\ui\panels\left_panel.py`
- Size: 39.7 KB (950 lines approx)
- First meaningful line:
```
from PySide6.QtWidgets import QFrame, QVBoxLayout, QLabel, QWidget, QPushButton, QHBoxLayout, QColorDialog, QCheckBox, QToolButton, QSizePolicy, QGridLayout, QLineEdit, QSlider, QScrollArea
```

### `Editors\Image\2\ui\ai_dialogs.py`
- Size: 39.0 KB (996 lines approx)
- Docstring:
```
AI Generation Dialogs for Gemini Integration
Includes base image generation, animation creation, and JSON editing
```

### `Examples\script_editor\search_replace.py`
- Size: 37.8 KB (919 lines approx)
- Docstring:
```
Search and Replace Dialog for PyGenesis Code Editor
Professional search and replace functionality with advanced options.
```

### `Editors\Image\2\core\texture_utils.py`
- Size: 36.6 KB (898 lines approx)
- First meaningful line:
```
import numpy as np
```

### `Editors\Image\2\ui\texture_atlas_dialog.py`
- Size: 36.3 KB (918 lines approx)
- First meaningful line:
```
from PySide6.QtWidgets import (
```

### `Editors\Object\object_editor.py`
- Size: 36.2 KB (874 lines approx)
- First meaningful line:
```
======================================================================
```

### `Editors\Image\2\ui\nine_slice_importer.py`
- Size: 35.8 KB (847 lines approx)
- Docstring:
```
Sprite Sheet Importer Dialog

Industry-standard sprite sheet importer with:
- Background removal with tolerance and live preview
- Automatic sprite detection and cropping
- Bounding box visualization
- Multiple output modes (sprite sheet or individual frames)
```

### `Editors\Image\2\ui\dialogs\preferences_dialog.py`
- Size: 34.2 KB (708 lines approx)
- Docstring:
```
Preferences Dialog for Image Editor
Extracted from dialogs.py
```

### `Screen_Recording_App\integrated_screen_recorder.py`
- Size: 33.4 KB (785 lines approx)
- Docstring:
```
Integrated Screen Recorder for PyGenesis IDE
Modified version that saves to project Recordings folder by default
```

### `Editors\Image\2\ui\sprite_sheet_importer.py`
- Size: 33.2 KB (811 lines approx)
- Docstring:
```
Sprite Sheet Importer Dialog

Provides UI for importing sprite sheets with auto-slicing, background removal,
and frame centering.
```

### `Examples\script_editor\syntax_highlighter.py`
- Size: 32.0 KB (696 lines approx)
- Docstring:
```
Syntax Highlighter for PyGenesis Code Editor
Provides syntax highlighting for multiple programming languages with the professional dark theme.
```

### `Editors\Image\2\core\ai_test_app.py`
- Size: 31.9 KB (786 lines approx)
- Docstring:
```
GUI Test App for AI-driven image generation using editor tools.
Dialog-based interface with preview and animation support.
```

## Other important text files

- `store_cache\pypi_cache.json` (16766.3 KB): {
- `Config\PyPICache.json` (414.6 KB): {
- `Documentation\PyGenesis Plans\Tutorials\Tutorials.md` (25.8 KB): How To Add Effects
- `Documentation\PyGenesis Plans\Roadmap\TODO_ROADMAP.md` (22.7 KB): PyGenesis IDE — Comprehensive Development Roadmap
- `Documentation\PyGenesis Plans\Roadmap\OutstandingActions.md` (21.1 KB): Outstanding Actions from PyGenesis Roadmap
- `Editors\Image\2\core\ai_tool_knowledge.json` (18.4 KB): {
- `Documentation\PyGenesis Plans\Roadmap\Plan.md` (11.9 KB): PyGenesis IDE — Development Plan
- `Documentation\PyGenesis Plans\Roadmap\IMAGE_EDITOR_PERFORMANCE_ANALYSIS.md` (10.6 KB): Image Editor Performance Analysis - Critical Bottlenecks
- `Documentation\Editors\PGME Pigmie\Model Editor.md` (9.0 KB): Model Editor (PGME — Pigme) — Documentation
- `Documentation\Editors\PGRE Pygress\Room Editor.md` (7.3 KB): Room Editor (PGRE) — Complete Documentation
- `Documentation\Editors\PGIE Piggie\Sprite Editor.md` (6.9 KB): Sprite Editor — Complete Documentation
- `Documentation\PyGenesis Plans\Summary Of PyGenesis.md` (6.8 KB): PyGenesis IDE — Project Structure Summary
- `Documentation\Editors\PGOE Pygo\Object Editor.md` (6.5 KB): Object Editor (PGOE) — Planned Documentation
- `Documentation\Editors\PGCE PyCode\Code Editor.md` (5.6 KB): Code Editor (PGCE) — Planned Documentation
- `Config\OptionalRequirements.json` (5.4 KB): {
- `Documentation\PyGenesis Plans\Roadmap\PERFORMANCE_PROGRESS.md` (5.1 KB): Image Editor Performance Optimization - Progress Report
- `Documentation\Editors\PGIE Piggie\Summary Of Image Editor.md` (4.6 KB): Image Editor (PGIE) — Summary
- `Documentation\PyGenesis Plans\Roadmap\PERFORMANCE_OPTIMIZATIONS.md` (3.4 KB): Performance Optimizations - Image Editor
- `Config\CoreRequirements.json` (3.1 KB): {
- `Config\Requirements.json` (2.2 KB): {
- `Documentation\Editors\PGCE PyCode\Pythonic Shortcut Language.md` (1.5 KB): Pythonic Shortcut Language (PSL)
- `requirements.txt` (1.1 KB): PyGenesis IDE - Complete Requirements
- `Config\InstalledPackagesCache.json` (0.8 KB): {
- `core_libs\numpy\manifest.json` (0.5 KB): {
- `core_libs\pillow\manifest.json` (0.5 KB): {
- `core_libs\pyside6_addons\manifest.json` (0.5 KB): {
- `core_libs\pyside6\manifest.json` (0.5 KB): {
- `core_libs\pyopengl\manifest.json` (0.5 KB): {
- `optional_libs\opencv_python\manifest.json` (0.5 KB): {
- `optional_libs\trimesh\manifest.json` (0.5 KB): {
- `core_libs\setuptools\manifest.json` (0.4 KB): {
- `core_libs\pyopengl_accelerate\manifest.json` (0.4 KB): {
- `pyrightconfig.json` (0.4 KB): {
- `optional_libs\pycollada\manifest.json` (0.4 KB): {
- `optional_libs\numba\manifest.json` (0.4 KB): {
- `optional_libs\librosa\manifest.json` (0.4 KB): {
- `optional_libs\pygame\manifest.json` (0.4 KB): {
- `optional_libs\music21\manifest.json` (0.4 KB): {
- `optional_libs\pytest\manifest.json` (0.4 KB): {
- `optional_libs\mss\manifest.json` (0.4 KB): {

## Binary assets (images, binaries, etc.)

- `Editors\test_ai_scenario_output.png` (3.0 KB)
