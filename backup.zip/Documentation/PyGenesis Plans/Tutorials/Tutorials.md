# How To Add Effects

Complete step-by-step guide for adding new effects to the IDE. Based on the TempEffect001 example.

## Overview

When adding a new effect, you need to modify **THREE files**:

1. **`Editors/Image/2/ui/main_window.py`** - Menu, handlers, processing, and menu mapping
2. **`Editors/Image/2/ui/dialogs.py`** - Registry, preview routing, and preview implementation
3. **`Editors/SpriteEditor.py`** - Forwarder method (for Sprite Editor integration)

---

## Step-by-Step: Adding "TempEffect001"

### FILE 1: Editors/Image/2/ui/main_window.py

#### Step 1: Add Menu Entry (Line 448-449)

In the `_setup_menu()` method, after the Dither action:

```python
temp_effect_action = filter_menu.addAction("TempEffect001")
temp_effect_action.triggered.connect(self.effect_temp_effect_001)
```

**Location:** After line 447 in `_setup_menu()` method

---

#### Step 2: Add Effect Handler (Line 1093-1096)

Add the handler that calls `_apply_unified_effect()`:

```python
def effect_temp_effect_001(self):
    print("DEBUG: effect_temp_effect_001 called")
    print(f"DEBUG: 'temp_effect_001' in EFFECT_REGISTRY: {'temp_effect_001' in EFFECT_REGISTRY}")
    self._apply_unified_effect('temp_effect_001')
```

**Location:** After line 1092 with other effect handlers

---

#### Step 3: Add Routing in _process_effect (Line 1374-1375)

In the `_process_effect()` method:

```python
elif effect_type == 'temp_effect_001':
    return self._apply_temp_effect_001(pil_img, parameters)
```

**Location:** After line 1371 with other effect routing

---

#### Step 4: Add Implementation (Line 1447-1463)

Add the actual effect processing code:

```python
def _apply_temp_effect_001(self, pil_img, parameters):
    """Apply temp effect 001 - placeholder using brightness as template."""
    factor = parameters.get('factor', 1.0)
    from PIL import ImageEnhance
    
    # Apply brightness while preserving alpha
    if pil_img.mode != 'RGBA':
        pil_img = pil_img.convert('RGBA')
    
    # Convert to RGB for brightness adjustment, then restore alpha
    rgb_img = pil_img.convert('RGB')
    enhancer = ImageEnhance.Brightness(rgb_img)
    brightened_rgb = enhancer.enhance(factor)
    
    # Restore alpha channel
    brightened_rgb.putalpha(pil_img.getchannel('A'))
    return np.array(brightened_rgb)
```

**Location:** After line 1443 with other effect implementations

**Note:** This is the version that runs when the user clicks "Apply Effect"

---

#### Step 5: Add to Menu Mapping (Line 4850)

In `_map_action_to_method()` function, add your effect to the mapping:

```python
"TempEffect001": "effect_temp_effect_001",
```

**Location:** In the dictionary starting at line 4838

**Why:** Sprite Editor uses this mapping to sync its effects menu with the Image Editor

---

### FILE 2: Editors/Image/2/ui/dialogs.py

#### Step 6: Add to EFFECT_REGISTRY (Line 5008-5016)

Add your effect to the registry dictionary:

```python
'temp_effect_001': {
    'name': 'Temp Effect 001',
    'parameters': [
        {'type': 'double_slider', 'name': 'factor', 'label': 'Brightness', 'range': (0.1, 3.0), 'default': 1.0}
    ],
    'preview_enabled': True,
    'frame_options': True,
    'selection_options': True
},
```

**Location:** After line 5007 with other registry entries

**What this does:**
- Defines the dialog parameters (slider, dropdown, color picker, etc.)
- Enables preview, frame options, and selection options
- The dialog is auto-generated from this registry entry

---

#### Step 7: Add Preview Routing (Line 1939-1940)

In `_apply_effect()` method of `UnifiedEffectDialog` class:

```python
elif self.effect_type == 'temp_effect_001':
    return self._apply_temp_effect_001(pil_img, parameters, frame_idx)
```

**Location:** After line 1936 with other preview routing

---

#### Step 8: Add Preview Implementation (Line 2041-2062)

Add the preview version of your effect (supports frame animation):

```python
def _apply_temp_effect_001(self, pil_img, parameters, frame_idx=0):
    """Apply temp effect 001 - placeholder using brightness as template."""
    base_factor = parameters.get('factor', 1.0)
    from PIL import ImageEnhance
    
    # If creating multiple frames, interpolate brightness based on frame_idx
    if self.frame_option == "create_frames" and self.total_preview_frames > 1:
        # Progressive brightness: frame 0 = 1.0 (normal), last frame = factor
        factor = 1.0 + (base_factor - 1.0) * (frame_idx / (self.total_preview_frames - 1)) if self.total_preview_frames > 1 else base_factor
    else:
        factor = base_factor
    
    # Apply brightness while preserving alpha
    if pil_img.mode != 'RGBA':
        pil_img = pil_img.convert('RGBA')
    
    # Convert to RGB for brightness adjustment, then restore alpha
    rgb_img = pil_img.convert('RGB')
    enhancer = ImageEnhance.Brightness(rgb_img)
    brightened_rgb = enhancer.enhance(factor)
    
    # Restore alpha channel
    brightened_rgb.putalpha(pil_img.getchannel('A'))
    return np.array(brightened_rgb)
```

**Location:** After line 2038 with other preview implementations

**Note:** This is the version that runs for the live preview in the dialog. The `frame_idx` parameter allows progressive animation effects.

---

### FILE 3: Editors/SpriteEditor.py

#### Step 9: Add Forwarder Method (Line 883-894)

Add a forwarder that calls the Image Editor's method:

```python
def effect_temp_effect_001(self):
    print("=" * 60)
    print("DEBUG: SpriteEditor.effect_temp_effect_001 called")
    print(f"DEBUG: hasattr(self, 'main_editor'): {hasattr(self, 'main_editor')}")
    if hasattr(self, 'main_editor'):
        print(f"DEBUG: self.main_editor exists: {self.main_editor is not None}")
        print(f"DEBUG: Calling self.main_editor.effect_temp_effect_001()")
        self.main_editor.effect_temp_effect_001()
        print("DEBUG: Returned from main_editor call")
    else:
        print("DEBUG: ERROR - No main_editor found!")
    print("=" * 60)
```

**Location:** After line 882 with other effect forwarders

**Why:** Sprite Editor embeds the Image Editor and forwards menu calls to it

---

## Quick Reference: What Each Piece Does

| Location | What It Does |
|----------|--------------|
| **main_window.py line 448** | Menu entry - creates the menu item |
| **main_window.py line 1093** | Handler - called when menu item clicked |
| **main_window.py line 1374** | Processing routing - routes to implementation |
| **main_window.py line 1447** | Processing implementation - the actual effect code |
| **main_window.py line 4850** | Menu mapping - syncs with Sprite Editor |
| **dialogs.py line 5008** | Registry entry - defines dialog parameters |
| **dialogs.py line 1939** | Preview routing - routes to preview implementation |
| **dialogs.py line 2041** | Preview implementation - live preview code |
| **SpriteEditor.py line 883** | Forwarder - forwards call to Image Editor |

---

## Parameter Types Available

When defining parameters in the registry (Step 6), you can use:

- **`'slider'`** - Integer slider: `{'type': 'slider', 'name': 'intensity', 'label': 'Intensity', 'range': (1, 100), 'default': 50}`
- **`'double_slider'`** - Float slider: `{'type': 'double_slider', 'name': 'factor', 'label': 'Factor', 'range': (0.1, 3.0), 'default': 1.0}`
- **`'dropdown'`** - Dropdown menu: `{'type': 'dropdown', 'name': 'mode', 'label': 'Mode', 'options': ['Option1', 'Option2'], 'default': 'Option1'}`
- **`'color_picker'`** - Color picker: `{'type': 'color_picker', 'name': 'color', 'label': 'Color', 'default': '#000000'}`
- **`'checkbox'`** - Checkbox: `{'type': 'checkbox', 'name': 'enable_feature', 'label': 'Enable Feature', 'default': False}`

---

## Testing

After adding an effect:

1. **Restart the app** - Required for menu changes
2. **Open an image in Sprite Editor**
3. **Go to Effects → Filters**
4. **Click your effect**
5. **Check terminal for debug output**

Expected debug output:
```
============================================================
DEBUG: SpriteEditor.effect_temp_effect_001 called
DEBUG: hasattr(self, 'main_editor'): True
DEBUG: self.main_editor exists: True
DEBUG: Calling self.main_editor.effect_temp_effect_001()
DEBUG: effect_temp_effect_001 called
DEBUG: 'temp_effect_001' in EFFECT_REGISTRY: True
DEBUG: _apply_unified_effect called with effect_type: temp_effect_001
DEBUG: Creating UnifiedEffectDialog for temp_effect_001
DEBUG: Dialog created successfully
DEBUG: Preview updated, about to show dialog
```

---

## Why Two Implementations?

You implement the effect **twice**:

1. **Processing version** (main_window.py line 1447) - Runs when user clicks "Apply"
2. **Preview version** (dialogs.py line 2041) - Runs for live preview in dialog

Both should do the same thing, but the preview version includes:
- `frame_idx` parameter for progressive animation
- Access to `self.frame_option` and `self.total_preview_frames`
- Called multiple times as user adjusts parameters

---

## Copy-Paste Template

For a new effect called "MyEffect":

1. **Search and replace** `temp_effect_001` → `my_effect`
2. **Search and replace** `TempEffect001` → `My Effect`
3. **Search and replace** `effect_temp_effect_001` → `effect_my_effect`
4. **Modify the effect code** to do what you want
5. **Update parameters** in the registry entry
6. **Test and debug**

---

## Common Mistakes

❌ **Forgetting the menu mapping** (Step 5) - Sprite Editor won't show the effect
❌ **Missing registry entry** - Dialog won't open
❌ **Not implementing both versions** - Preview or processing won't work
❌ **Wrong parameter names** - Effect won't receive parameters
❌ **Not restarting app** - Menu changes won't appear

✅ **Always add debug output** to trace the flow
✅ **Always restart after menu changes**
✅ **Test in both Sprite Editor and standalone Image Editor**

---

## Complete Example: TempEffect001

**Files Modified:**
- ✅ `Editors/Image/2/ui/main_window.py` (5 places)
- ✅ `Editors/Image/2/ui/dialogs.py` (3 places)  
- ✅ `Editors/SpriteEditor.py` (1 place)

**Total Lines Added:** ~100 lines across 3 files

**Files NOT Modified:**
- ❌ `UI/MainWindow.py` - No need
- ❌ Any other files

This is the complete, tested workflow for adding effects to your IDE.

---

# How To Add A New Resource Type

Complete step-by-step guide for adding a new resource type (e.g., Models, Particles, Shaders) to PyGenesis. This tutorial uses **Models** as the example, but the same pattern applies to any new resource type.

## Overview

When adding a new resource type, you need to modify **FIVE core files**:

1. **`Core/ResourceManager.py`** - Define resource type, file operations (copy/rename/delete)
2. **`Core/ProjectManager.py`** - Create folder on project creation, purge system integration, runtime resources
3. **`UI/ResourceTree.py`** - Add icon, include in refresh loop
4. **`UI/MainWindow.py`** - Open editor when resource is double-clicked
5. **`Editors/[YourEditor].py`** - Create the editor widget/class (if needed)

---

## Step-by-Step: Adding "Models" Resource Type

### FILE 1: Core/ResourceManager.py

#### Step 1: Add Resource Type Definition (Line ~21-89)

In the `__init__` method, add your resource type to `self.resource_types`:

```python
"models": {
    "extension": ".model",
    "folder": "Models",
    "default_data": {
        "model_file": None,
        "original_model_file": None,
        "format": None,  # "obj", "glb", "gltf"
        "scale": 1.0,
        "position": {"x": 0.0, "y": 0.0, "z": 0.0},
        "rotation": {"x": 0.0, "y": 0.0, "z": 0.0}
    }
},
```

**Location:** Add after other resource types (sprites, backgrounds, objects, sounds, rooms)

**What this does:**
- Defines the file extension (`.model`)
- Defines the folder name (`Models`)
- Sets default data structure for new resources

---

#### Step 2: Add File Copy Method (Line ~705)

If your resource type has associated files that need to be copied when loading/importing:

```python
def _copy_model_file(self, model_resource, source_model_path):
    """Copy model file from source to project Models folder"""
    if not source_model_path or not os.path.exists(source_model_path):
        return False
    
    project_path = self.project_manager.get_project_path()
    models_folder = os.path.join(project_path, "Resources", "Models")
    
    # Handle parent folders
    parent_folder = model_resource.get("parent_folder", "")
    if parent_folder:
        models_folder = os.path.join(models_folder, parent_folder)
        os.makedirs(models_folder, exist_ok=True)
    
    # Get filename and handle conflicts
    filename = os.path.basename(source_model_path)
    dest_path = os.path.join(models_folder, filename)
    
    # Handle naming conflicts
    base_name = os.path.splitext(filename)[0]
    ext = os.path.splitext(filename)[1]
    counter = 1
    while os.path.exists(dest_path):
        new_filename = f"{base_name}_{counter}{ext}"
        dest_path = os.path.join(models_folder, new_filename)
        counter += 1
    
    # Copy file
    shutil.copy2(source_model_path, dest_path)
    
    # Update resource data
    model_resource["model_file"] = os.path.basename(dest_path)
    model_resource["original_model_file"] = os.path.basename(source_model_path)
    
    # Detect format
    ext_lower = ext.lower()
    if ext_lower == ".obj":
        model_resource["format"] = "obj"
    elif ext_lower == ".glb":
        model_resource["format"] = "glb"
    elif ext_lower == ".gltf":
        model_resource["format"] = "gltf"
    
    return True
```

**Location:** Add after other `_copy_*_file` methods

**Pattern:** Follow the same structure as `_copy_sound_audio_file()` or `_copy_sprite_frame_files()`

---

#### Step 3: Add File Delete Method (Line ~852)

When a resource is deleted, remove associated files:

```python
def _delete_model_files(self, model_resource):
    """Delete model files associated with a model resource"""
    project_path = self.project_manager.get_project_path()
    models_folder = os.path.join(project_path, "Resources", "Models")
    
    parent_folder = model_resource.get("parent_folder", "")
    if parent_folder:
        models_folder = os.path.join(models_folder, parent_folder)
    
    # Delete model_file if it exists
    model_file = model_resource.get("model_file")
    if model_file:
        model_path = os.path.join(models_folder, model_file)
        if os.path.exists(model_path):
            os.remove(model_path)
            print(f"DEBUG: Deleted model file: {model_path}")
    
    # Optionally delete original_model_file if different
    original_file = model_resource.get("original_model_file")
    if original_file and original_file != model_file:
        original_path = os.path.join(models_folder, original_file)
        if os.path.exists(original_path):
            os.remove(original_path)
```

**Location:** Add after other `_delete_*_files` methods

---

#### Step 4: Add File Rename Method (Line ~888)

When a resource is renamed, rename associated files:

```python
def _rename_model_file(self, model_resource, old_name, new_name):
    """Rename model file when resource is renamed"""
    project_path = self.project_manager.get_project_path()
    models_folder = os.path.join(project_path, "Resources", "Models")
    
    parent_folder = model_resource.get("parent_folder", "")
    if parent_folder:
        models_folder = os.path.join(models_folder, parent_folder)
    
    # Rename model_file
    model_file = model_resource.get("model_file")
    if model_file:
        old_path = os.path.join(models_folder, model_file)
        
        # Generate new filename based on resource name
        ext = os.path.splitext(model_file)[1]
        new_filename = f"{new_name}{ext}"
        new_path = os.path.join(models_folder, new_filename)
        
        # Handle conflicts
        if os.path.exists(new_path) and new_path != old_path:
            base_name = new_name
            counter = 1
            while os.path.exists(new_path):
                new_filename = f"{base_name}_{counter}{ext}"
                new_path = os.path.join(models_folder, new_filename)
                counter += 1
        
        if os.path.exists(old_path) and old_path != new_path:
            os.rename(old_path, new_path)
            model_resource["model_file"] = new_filename
```

**Location:** Add after other `_rename_*_file` methods

---

#### Step 5: Integrate Methods into Delete/Rename/Copy Operations

**In `delete_resource` method (Line ~281):**
```python
elif resource_type == "models":
    self._delete_model_files(resource)
```

**In `rename_resource` method (Line ~355):**
```python
elif resource_type == "models":
    self._rename_model_file(resource, old_name, new_name)
```

**In `copy_resource` method:** (if your resource type supports copying with file duplication)
- Add similar logic to copy associated files, following the pattern used for sprites/sounds

---

### FILE 2: Core/ProjectManager.py

#### Step 6: Create Folder on Project Creation (Line ~37)

In `create_project` method, ensure the folder is created:

```python
os.makedirs(os.path.join(project_path, "Resources", "Models"), exist_ok=True)
```

**Location:** Add with other folder creation calls

---

#### Step 7: Add to Project Data Structure (Line ~59)

In `create_project`, add to resources dictionary:

```python
"resources": {
    "sprites": [],
    "backgrounds": [],
    "objects": [],
    "sounds": [],
    "models": [],  # Add your resource type
    "rooms": []
}
```

---

#### Step 8: Add to Purge System (Line ~338)

In `purge_files_not_in_project`, add logic to read your resource files and include referenced files:

```python
# Check all model resources by reading their .model files
models = current_project_data.get("resources", {}).get("models", [])
print(f"DEBUG: Found {len(models)} models in project:")

for model_ref in models:
    print(f"DEBUG: - {model_ref.get('name', 'NO_NAME')}")
    
    # Get the parent folder path
    parent_folder = model_ref.get("parent_folder", "")
    if parent_folder:
        model_folder = os.path.join(self.project_path, "Resources", "Models", parent_folder)
    else:
        model_folder = os.path.join(self.project_path, "Resources", "Models")
    
    # Construct path to .model file
    model_file = os.path.join(model_folder, f"{model_ref['name']}.model")
    
    if os.path.exists(model_file):
        # Add the .model file itself
        valid_files.add(model_file)
        
        # Read the .model file to get referenced model files
        try:
            with open(model_file, 'r', encoding='utf-8') as f:
                model_data = json.load(f)
            
            # Add referenced model files (.obj, .glb, .gltf)
            model_file_ref = model_data.get("model_file")
            original_model_file = model_data.get("original_model_file")
            
            if model_file_ref:
                model_path = os.path.join(model_folder, model_file_ref)
                if os.path.exists(model_path):
                    valid_files.add(model_path)
            
            if original_model_file and original_model_file != model_file_ref:
                original_path = os.path.join(model_folder, original_model_file)
                if os.path.exists(original_path):
                    valid_files.add(original_path)
        except Exception as e:
            print(f"DEBUG: Error reading model file {model_file}: {e}")
```

**Location:** Add in the purge loop, following the pattern for sprites/sounds

---

#### Step 9: Add File Extensions to Purge Check (Line ~394)

In the file scanning loop, add your resource extensions:

```python
if file.endswith(('.png', '.jpg', '.jpeg', '.bmp', '.sprite', '.object', '.sound', 
                  '.model', '.room', '.wav', '.mp3', '.ogg', '.flac', '.m4a', 
                  '.midi', '.mid', '.obj', '.glb', '.gltf')):  # Add your extensions
    all_files.add(os.path.join(root, file))
```

---

#### Step 10: Ensure Folder Created on Project Load (Line ~478)

In `_load_runtime_resources`, ensure folder exists for old projects:

```python
os.makedirs(os.path.join(resources_base, "Models"), exist_ok=True)
```

---

#### Step 11: Initialize Runtime Resources (Line ~480)

In `_load_runtime_resources`, add to `self.runtime_resources`:

```python
self.runtime_resources = {
    "sprites": {},
    "backgrounds": {},
    "objects": {},
    "sounds": {},
    "models": {},  # Add your resource type
    "rooms": {}
}
```

---

### FILE 3: UI/ResourceTree.py

#### Step 12: Add Resource Icon (Line ~27)

Add an icon for your resource type:

```python
self.resource_icons = {
    "sprites": "🖼️",
    "backgrounds": "🎨",
    "objects": "📦",
    "sounds": "🔊",
    "models": "🎭",  # Add your icon
    "rooms": "🏠"
}
```

---

#### Step 13: Include in Refresh Loop (Line ~120)

In `refresh` method, include your resource type:

```python
for resource_type in ["sprites", "backgrounds", "objects", "sounds", "models", "rooms"]:
    # ... existing code
```

**Location:** In the loop that creates resource type items

---

### FILE 4: UI/MainWindow.py

#### Step 14: Open Editor on Double-Click (Line ~570)

In `open_resource_in_editor`, add handling for your resource type:

```python
elif resource_type == "models":
    from Editors.ModelEditor import ModelPreviewWindow
    editor = ModelPreviewWindow(app=self.app, resource_data=resource, parent=self)
```

**Location:** Add in the `if/elif` chain for resource types

---

### FILE 5: Create Your Editor (Editors/[YourEditor].py)

#### Step 15: Create Editor Widget/Window

Create your editor following the pattern of existing editors:

- **For interim/preview editors**: Create a `QWidget` that can be embedded (like `ModelPreviewWindow`)
- **For full editors**: Create a complete editor with menus, toolbars, etc. (like `ImageEditor` or `SpriteEditor`)

**Example structure for interim editor:**
```python
from PySide6.QtWidgets import QWidget, QVBoxLayout, QPushButton, QLabel

class ModelPreviewWindow(QWidget):
    def __init__(self, app=None, resource_data=None, parent=None):
        super().__init__(parent)
        self.app = app
        self.resource_data = resource_data
        self.setup_ui()
        self.load_resource_data()
    
    def setup_ui(self):
        layout = QVBoxLayout(self)
        # Add your UI components
    
    def load_resource_data(self):
        # Load and display resource data
        pass
```

---

## Quick Reference: Files to Modify

| File | Changes | Purpose |
|------|---------|---------|
| **ResourceManager.py** | 5 changes | Define type, copy/delete/rename operations |
| **ProjectManager.py** | 6 changes | Folder creation, purge system, runtime resources |
| **ResourceTree.py** | 2 changes | Icon and refresh loop |
| **MainWindow.py** | 1 change | Open editor on double-click |
| **Editors/[YourEditor].py** | Create file | Your editor implementation |

---

## Testing Checklist

After adding a new resource type:

- [ ] **Create resource**: Right-click → Create [Resource Type] works
- [ ] **Folder created**: Project folder structure includes your folder
- [ ] **Resource appears**: Resource shows in Resource Tree with correct icon
- [ ] **Double-click opens editor**: Editor opens when resource is double-clicked
- [ ] **File operations**: Copy/rename/delete work correctly
- [ ] **Purge system**: Unreferenced files are deleted correctly
- [ ] **Project save/load**: Resource persists across project save/load
- [ ] **Runtime**: Resource appears in runtime resources dictionary

---

## Common Patterns

### Pattern 1: Resource with Single Associated File
**Example:** Models (`.obj`, `.glb`, `.gltf` files)
- Use `_copy_model_file()` pattern
- Store `model_file` and `original_model_file` in resource data
- Purge system reads resource file to find referenced files

### Pattern 2: Resource with Multiple Associated Files
**Example:** Sprites (multiple `.png` frame files)
- Use `_copy_sprite_frame_files()` pattern
- Store array of file references in resource data
- Iterate through files in copy/delete/rename operations

### Pattern 3: Resource with Optional Associated File
**Example:** Sounds (optional audio file)
- Check if file exists before operations
- Handle `None` values gracefully
- Use `original_audio_file` as authoritative reference for purge

---

## Important Notes

1. **File Extensions in Purge**: Always add your resource's file extensions to the purge file check (Step 9)

2. **Parent Folder Support**: Ensure copy/delete/rename methods handle `parent_folder` correctly

3. **Naming Conflicts**: Always handle filename conflicts in copy operations (use `_1`, `_2` suffixes)

4. **Runtime Resources**: Always initialize in `_load_runtime_resources` to prevent errors with old projects

5. **Purge Safety**: Purge system should read actual resource files (not just project metadata) to find referenced files

6. **Editor Integration**: Editor must accept `app` and `resource_data` parameters for full integration

---

## Complete Example: Models Resource Type

**Files Modified:**
- ✅ `Core/ResourceManager.py` (5 places: type definition, copy, delete, rename, integration)
- ✅ `Core/ProjectManager.py` (6 places: folder creation, project data, purge, extensions, runtime)
- ✅ `UI/ResourceTree.py` (2 places: icon, refresh loop)
- ✅ `UI/MainWindow.py` (1 place: editor opening)
- ✅ `Editors/ModelEditor.py` (created new file)

**Total Changes:** ~300 lines across 5 files

This is the complete workflow for adding a new resource type to PyGenesis.

