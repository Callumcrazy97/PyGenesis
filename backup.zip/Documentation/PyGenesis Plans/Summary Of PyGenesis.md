# PyGenesis IDE — Project Structure Summary

*Generated on 2025-11-26 23:12:47*

---



```
Temp/
├── Config/
│       (7 files)
│   ├── CoreRequirements.json
│   ├── InstalledPackagesCache.json
│   ├── OptionalRequirements.json
│   ├── PyPICache.json
│   ├── Requirements.json
│   ├── Settings.py
│   └── ThemeManager.py
├── Core/
│       (16 files)
│   ├── Rendering/
│   │       (6 files)
│   │   ├── BufferManager.py
│   │   ├── Canvas_2D.py
│   │   ├── OpenGLRuntime.py
│   │   ├── ShaderManager.py
│   │   ├── SuperShader_2D.py
│   │   └── TextureManager.py
│   ├── Services/
│   │       (4 files)
│   │   ├── file_service.py
│   │   ├── project_service.py
│   │   ├── resource_service.py
│   │   └── validation_service.py
│   ├── BackupManager.py
│   ├── Debug.py
│   ├── DeletePyCache.py
│   ├── EditorFactory.py
│   ├── EditorInterface.py
│   ├── Events.py
│   ├── ExtensionsManager.py
│   ├── ModulePreloader.py
│   ├── PackageInstaller.py
│   ├── PackageLoadThread.py
│   ├── PackageSearchThread.py
│   ├── ProjectManager.py
│   ├── PyPILoadThread.py
│   ├── ResourceManager.py
│   ├── UtilityOperations.py
│   └── VenvManager.py
├── Documentation/
│   ├── Editors/
│   │   ├── PGCE PyCode/
│   │   │   ├── Code Editor.md
│   │   │   └── Pythonic Shortcut Language.md
│   │   ├── PGIE Piggie/
│   │   │   ├── Sprite Editor.md
│   │   │   └── Summary Of Image Editor.md
│   │   ├── PGME Pigmie/
│   │   │   └── Model Editor.md
│   │   ├── PGOE Pygo/
│   │   │   └── Object Editor.md
│   │   └── PGRE Pygress/
│   │       └── Room Editor.md
│   ├── Misc/
│   └── PyGenesis/
│           (1 file)
│       ├── Misc/
│       ├── Roadmap/
│       │   ├── IMAGE_EDITOR_PERFORMANCE_ANALYSIS.md
│       │   ├── OutstandingActions.md
│       │   ├── PERFORMANCE_OPTIMIZATIONS.md
│       │   ├── PERFORMANCE_PROGRESS.md
│       │   ├── Plan.md
│       │   └── TODO_ROADMAP.md
│       ├── Tutorials/
│       │   └── Tutorials.md
│       └── Summary Of PyGenesis.md
├── Editors/
│       (6 files)
│   ├── Image/
│   │   ├── 2/
│   │   │   ├── core/
│   │   │   ├── layers/
│   │   │   ├── services/
│   │   │   ├── ui/
│   │   │   ├── app.py
│   │   │   ├── generate_textures.py
│   │   │   └── selection_helpers.py
│   │   ├── old2/
│   │   │   ├── core/
│   │   │   ├── layers/
│   │   │   ├── ui/
│   │   │   ├── app.py
│   │   │   ├── generate_textures.py
│   │   │   └── selection_helpers.py
│   │   └── ui/
│   ├── Model/
│   │   └── Examples/
│   │       ├── GoodPerformanceButOnlyShowsModels.py
│   │       └── PoorPerformanceCreationAndLoading.py
│   ├── Sound/
│   │       (1 file)
│   │   └── WaveForge.py
│   ├── ModelEditor.py
│   ├── RoomEditor.py
│   ├── SoundEditor.py
│   ├── SpriteEditor.py
│   ├── TextureEditor.py
│   └── test_ai_scenario_output.png
├── Screen_Recording_App/
│       (1 file)
│   └── integrated_screen_recorder.py
├── UI/
│       (7 files)
│   ├── ExtensionsDialog.py
│   ├── LoadingWidget.py
│   ├── MainWindow.py
│   ├── PreferencesDialog.py
│   ├── ResourceTree.py
│   ├── TerminalWidget.py
│   └── ThumbnailLoader.py
├── core_libs/
│   ├── numpy/
│   │       (1 file)
│   │   └── manifest.json
│   ├── pillow/
│   │       (1 file)
│   │   └── manifest.json
│   ├── pyopengl/
│   │       (1 file)
│   │   └── manifest.json
│   ├── pyopengl_accelerate/
│   │       (1 file)
│   │   └── manifest.json
│   ├── pyside6/
│   │       (1 file)
│   │   └── manifest.json
│   ├── pyside6_addons/
│   │       (1 file)
│   │   └── manifest.json
│   └── setuptools/
│           (1 file)
│       └── manifest.json
├── optional_libs/
│   ├── json5/
│   │       (1 file)
│   │   └── manifest.json
│   ├── librosa/
│   │       (1 file)
│   │   └── manifest.json
│   ├── mido/
│   │       (1 file)
│   │   └── manifest.json
│   ├── mss/
│   │       (1 file)
│   │   └── manifest.json
│   ├── music21/
│   │       (1 file)
│   │   └── manifest.json
│   ├── numba/
│   │       (1 file)
│   │   └── manifest.json
│   ├── opencv_python/
│   │       (1 file)
│   │   └── manifest.json
│   ├── pycollada/
│   │       (1 file)
│   │   └── manifest.json
│   ├── pydub/
│   │       (1 file)
│   │   └── manifest.json
│   ├── pygame/
│   │       (1 file)
│   │   └── manifest.json
│   ├── pytest/
│   │       (1 file)
│   │   └── manifest.json
│   ├── pytest_qt/
│   │       (1 file)
│   │   └── manifest.json
│   ├── soundfile/
│   │       (1 file)
│   │   └── manifest.json
│   └── trimesh/
│           (1 file)
│       └── manifest.json
├── store_cache/
│       (1 file)
│   └── pypi_cache.json
├── GenerateStructures.py
├── main.py
├── pyrightconfig.json
└── requirements.txt
```

## Statistics

- **Python Files**: 138
- **Markdown Files**: 15
- **JSON Files**: 30
- **Other Files**: 2
- **Total Files**: 185

## Key Directories

- **Core/**: Core application logic, managers, and interfaces (16 Python files)
- **Editors/**: Resource editors (Sprite, Room, Sound, etc.) (6 Python files)
- **UI/**: Main window and UI components (7 Python files)
- **Config/**: Settings, themes, and configuration (7 Python files)
- **Documentation/**: Project documentation and guides (0 Python files)

---

*This summary is automatically generated. Run `Documentation/Misc/GenerateStructures.py` to regenerate.*
