# PyGenesis IDE — Development Plan

## Roadmap to Making Playable Games

This document outlines the development plan to transform PyGenesis from a resource editor into a complete game development environment capable of creating and running games.

---

## Current Status Summary

### ✅ Completed Systems

1. **Project Management** — Full project creation, loading, saving, purging
2. **Resource Management** — Complete CRUD for all resource types with file propagation
3. **Image Editor (PGIE — Piggie)** — Feature-complete pixel art editor with effects, timeline, selections
4. **Sprite Editor** — Full integration with Image Editor, animation tag preview system
5. **Sound Editor (PGSE — Pygsie)** — Basic playback, waveforms, track mixing (WAV/MP3 support)
6. **Room Editor (PGRE — Pygre)** — Basic structure exists (placeholders only)
7. **Preferences/Theme System** — Complete with customization
8. **Screen Recording** — Integrated with auto-management

### 🚧 Partially Complete

1. **Room Editor** — UI exists but needs visual placement, sprite rendering, zoom/pan
2. **Sound Editor** — Basic features done, advanced editors (WaveForge, MelodyMaker) not started

### ❌ Not Started

1. **Object Editor (PGOE — PyGo)** — Does not exist
2. **Model Editor (PGME — Pigme)** — Does not exist
3. **Scripting Language (PGSL — Pigsil)** — Does not exist
4. **Code Editor (PGCE — PyCo)** — Does not exist
5. **Backend Runtime (PGBE — Piggieback)** — Does not exist
6. **Compile/Test System** — Does not exist
7. **Debug Mode** — Does not exist

---

## Development Phases

### Phase 1: Core Editor Completion (Current Priority)

**Goal**: Get all resource editors to a fully functional state

#### 1.1 Finish Image/Sprite Editor Polish
- [ ] Collision mask visual editor (currently just a button)
- [ ] Animation frame tag save/load system (tags persist to `.sprite` files)
- [ ] Sprite atlas improvements (auto-packing, export metadata)

**Status**: ~95% complete, minor polish needed

#### 1.2 Complete Sound Editor
- [ ] Sound groups/categories system
- [ ] Basic audio effects (reverb, echo)
- [ ] Export/compression options
- [ ] WaveForge (Audacity-style editor) — Full waveform editing, effects chain
- [ ] MelodyMaker (GarageBand-style) — MIDI sequencer, instrument library, export to WAV

**Status**: Basic playback done, advanced editors needed

#### 1.3 Complete Room Editor (PGRE — Pygre)
- [ ] Visual instance placement (drag-and-drop objects onto room)
- [ ] Sprite rendering for instances (show actual sprite images)
- [ ] Zoom and pan controls
- [ ] Instance selection handles (move, rotate, scale)
- [ ] Background layering and rendering
- [ ] Tile system (place tile regions)

**Status**: UI structure exists, needs visual implementation

**Estimated Time**: 2-3 weeks

---

### Phase 2: Object System (PGOE — PyGo)

**Goal**: Create game entities with behaviors

#### 2.1 Object Editor (PGOE — PyGo)
- [ ] Object resource creation (assign sprite, set properties)
- [ ] Event system (Create, Step, Draw, Collision events)
- [ ] Property definitions (variables, types, defaults)
- [ ] Sprite reference and animation control
- [ ] Collision mask inheritance from sprite

**Dependencies**: Sprite Editor complete, basic scripting language

**Estimated Time**: 2-3 weeks

---

### Phase 3: Scripting & Code (PGSL — Pigsil + PGCE — PyCo)

**Goal**: Enable game logic and behaviors

#### 3.1 Pythonic Shortcut Language (PSL)
- [ ] PSL parser and command router
- [ ] Context-aware command resolution
- [ ] Syntax validation and error messages
- [ ] Command registry system

#### 3.2 PyGenesis Scripting Language (PGSL — Pigsil) — Full Language
- [ ] Grammar definition (Python-like syntax)
- [ ] Lexer and parser
- [ ] AST generation
- [ ] Runtime execution engine
- [ ] Built-in functions (object manipulation, collision, drawing)
- [ ] Script editor integration

**Alternative Approach**: Use Python directly with game API

#### 3.3 Code Editor (PGCE — PyCo)
- [ ] Syntax highlighting for PGSL (or Python)
- [ ] Auto-completion for game API
- [ ] Error detection and inline warnings
- [ ] Code templates for events
- [ ] Integration with Object Editor

**Dependencies**: Scripting language definition

**Estimated Time**: 4-6 weeks (or less if using Python directly)

---

### Phase 4: Runtime & Execution (PGBE)

**Goal**: Run games built in PyGenesis

#### 4.1 Backend Runtime (PGBE — Piggieback)
- [ ] Resource loader (load `.sprite`, `.sound`, `.object`, `.room` files)
- [ ] Object instance manager (create, update, destroy instances)
- [ ] Sprite rendering engine (2D sprite batching)
- [ ] Collision detection system (AABB, precise masks)
- [ ] Event system (handle Create, Step, Draw, Collision events)
- [ ] Input system (keyboard, mouse)
- [ ] Audio playback system (sound mixing, looping)
- [ ] Room/level management (room transitions, persistence)
- [ ] Main game loop (fixed timestep or variable)

#### 4.2 Resource Pipeline
- [ ] Project compilation (convert `.pgproject` to runtime format)
- [ ] Resource bundling (organize all assets)
- [ ] Dependency resolution (validate all references)

**Dependencies**: Object Editor, Scripting Language

**Estimated Time**: 6-8 weeks

---

### Phase 5: Testing & Debugging

**Goal**: Make game development smooth and debuggable

#### 5.1 Test Button
- [ ] Launch game in test window
- [ ] Hot-reload on resource changes
- [ ] FPS counter and performance metrics
- [ ] Exit handling

#### 5.2 Debug Mode
- [ ] Subprocess inspector window (detached debugger UI)
- [ ] Variable inspector (inspect all objects, specific objects, globals)
- [ ] Resource usage viewer (memory, textures, sounds)
- [ ] Breakpoint system (pause execution)
- [ ] Step-by-step execution
- [ ] Call stack viewer

#### 5.3 Compile/Export
- [ ] Standalone executable generation
- [ ] Asset bundling and optimization
- [ ] Platform-specific builds (Windows, Mac, Linux)
- [ ] Installer creation

**Dependencies**: Backend Runtime complete

**Estimated Time**: 3-4 weeks

---

### Phase 6: Advanced Features

**Goal**: Polish and extend capabilities

#### 6.1 Model Editor (PGME — Pigme)
- [ ] 3D model import (OBJ, FBX)
- [ ] Basic 3D preview
- [ ] Texture mapping
- [ ] Animation support (if needed)

#### 6.2 Additional Systems
- [ ] Particle system editor
- [ ] Shader editor
- [ ] Physics integration
- [ ] Networking support
- [ ] Save/load system

**Estimated Time**: Ongoing, as needed

---

## Recommended Development Order

### Option A: "Get a Game Running Fast" (Recommended)

**Priority**: Create a minimal playable game ASAP

1. ✅ **Phase 1.1** — Polish Image/Sprite Editor (1 week)
2. ✅ **Phase 1.3** — Complete Room Editor (2-3 weeks)
3. ✅ **Phase 2** — Object Editor with minimal scripting (2-3 weeks)
4. ✅ **Phase 3** — Use Python directly (skip PGSL, add game API) (1-2 weeks)
5. ✅ **Phase 4** — Minimal runtime (4-5 weeks)
6. ✅ **Phase 5.1** — Test button (1 week)

**Total: ~11-15 weeks** to first playable game

**Then:**
7. Sound Editor completion (WaveForge/MelodyMaker)
8. Debug mode
9. Compile/export

### Option B: "Polish Before Runtime"

**Priority**: Complete all editors first

1. Phase 1.1 — Image/Sprite Editor polish
2. Phase 1.2 — Sound Editor + WaveForge + MelodyMaker
3. Phase 1.3 — Complete Room Editor
4. Phase 2 — Object Editor
5. Phase 3 — Scripting Language
6. Phase 4 — Runtime
7. Phase 5 — Testing & Debugging

**Total: ~20-25 weeks** to first playable game

---

## Decision Point: Scripting Language

### Option 1: Build Custom PGSL
- **Pros**: Tight integration, game-specific syntax, can optimize for game development
- **Cons**: Significant development time, must maintain parser/runtime, learning curve
- **Time**: 4-6 weeks

### Option 2: Use Python Directly
- **Pros**: Developers already know Python, huge ecosystem, no parser needed
- **Cons**: Less specialized, need to build game API wrapper
- **Time**: 1-2 weeks

**Recommendation**: **Option 2** (Python) for faster path to playable games. Can always add PGSL later as a convenience layer.

---

## Technical Dependencies

```
Project Manager (✅)
    └── Resource Manager (✅)
            ├── Sprite Editor (✅)
            ├── Image Editor (✅)
            ├── Sound Editor (🔄)
            ├── Room Editor (🔄)
            └── Object Editor (❌)
                    └── Scripting Language (❌)
                            └── Backend Runtime (❌)
                                    ├── Test Button (❌)
                                    ├── Debug Mode (❌)
                                    └── Compile/Export (❌)
```

---

## Milestones

### Milestone 1: "Resource Editor Complete"
- [ ] All resource editors functional
- [ ] All resources can be created, edited, saved
- [ ] No critical bugs in resource management

**Target**: End of Phase 1

### Milestone 2: "Level Design Ready"
- [ ] Room Editor fully functional
- [ ] Objects can be placed in rooms
- [ ] Rooms save and load correctly

**Target**: End of Phase 1.3 + Phase 2

### Milestone 3: "First Playable Game"
- [ ] Backend runtime runs
- [ ] Objects with simple behaviors
- [ ] Rooms load and display
- [ ] Test button launches game

**Target**: End of Phase 4 + 5.1

### Milestone 4: "Production Ready"
- [ ] Full debugging capabilities
- [ ] Compile/export working
- [ ] Performance optimized
- [ ] Documentation complete

**Target**: End of Phase 5

---

## Risk Assessment

### High Priority Risks

1. **Scripting Language Complexity** — Mitigate by using Python directly
2. **Runtime Performance** — Plan for optimization early (sprite batching, collision optimization)
3. **Resource Loading Speed** — Implement async loading and caching
4. **Feature Creep** — Stick to roadmap, defer nice-to-haves

### Technical Debt to Address

- [ ] Sprite animation tag persistence (currently in runtime only)
- [ ] Room Editor visual implementation
- [ ] Sound Editor advanced features
- [ ] Collision mask editor

---

## Next Steps (Immediate)

Based on current state and dependencies, the recommended next focus is:

### **Phase 1.3: Complete Room Editor**

**Why:**
- Room Editor has basic structure but no visual functionality
- Critical for game design workflow
- Relatively straightforward (UI exists, needs visual rendering)
- Unblocks object placement and level design

**Tasks:**
1. Implement drag-and-drop object placement
2. Render sprites for instances (load from sprite resources)
3. Add zoom/pan controls
4. Implement move/resize handles for instances
5. Render background layers
6. Add tile placement system

**Estimated Time**: 2-3 weeks

**After Room Editor**: Move to Object Editor (Phase 2), which requires sprites and basic scripting.

---

## Success Criteria

PyGenesis will be considered "game-ready" when:

1. ✅ User can create a project
2. ✅ User can create sprites, sounds, objects, rooms
3. ✅ User can place objects in rooms visually
4. ✅ User can write game logic (Python or PGSL)
5. ✅ User can test the game (Test button)
6. ✅ User can debug the game (inspect variables, objects)
7. ✅ User can compile/export to executable

**Current Status**: 40% complete (4/10 major systems done)

---

## Notes

- All estimates assume focused development time
- Parallel work possible on independent systems (e.g., Sound Editor advanced features while working on Room Editor)
- Scripting language decision should be made early (before Object Editor)
- Runtime architecture should be designed before implementation (consider using existing game engines vs. building from scratch)

---

**Last Updated**: Based on current codebase state
**Next Review**: After Phase 1.3 completion

