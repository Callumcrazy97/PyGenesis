# Outstanding Actions from PyGenesis Roadmap

**Last Updated**: Based on current codebase analysis  
**Status**: Tracking what remains to be completed from TODO_ROADMAP.md and Plan.md

---

## 🏗️ FOUNDATION: Shared PyOpenGL Runtime Architecture

**Overall Status**: 🟡 **PARTIALLY COMPLETE** (50% done)

### ✅ Completed Components
- ✅ `Core/Rendering/OpenGLRuntime.py` - Singleton OpenGL context manager exists
- ✅ `Core/Rendering/BufferManager.py` - VBO/VAO/IBO management exists
- ✅ `Core/Rendering/TextureManager.py` - Texture cache and management exists
- ✅ `Core/Rendering/ShaderManager.py` - Shader compilation system exists
- ✅ `Core/Rendering/SuperShader_2D.py` - 2D unified shader exists
- ✅ `Core/Rendering/Canvas_2D.py` - GPU-accelerated 2D canvas widget exists

### ❌ Missing Critical Components
- ❌ `Core/Rendering/SuperShader_3D.py` - **DELETED** (needs recreation)
- ❌ `Core/Rendering/Viewport_3D.py` - **DELETED** (needs recreation)
- ❌ `Core/Rendering/ModelLoader.py` - **DELETED** (needs recreation)

### 📋 Outstanding Foundation Tasks
1. **Recreate SuperShader_3D** (CRITICAL)
   - Unified 3D shader for model/room preview
   - PBR (Physically Based Rendering) support
   - Shadow mapping (hard, soft, CSM)
   - Multiple light types (directional, point, spot)
   - Material properties (albedo, metallic, roughness, normal maps)
   - Wireframe mode support

2. **Recreate Viewport_3D** (CRITICAL)
   - GPU-accelerated 3D viewport widget
   - Camera controllers (orbit, FPS, orthographic)
   - Frustum culling
   - Level-of-detail (LOD) support
   - Render queues and batching
   - Note: ModelEditor currently has a basic BoundedViewport_3D, but needs full Viewport_3D

3. **Recreate ModelLoader** (CRITICAL)
   - Unified model loading API
   - Support for OBJ, DAE, GLTF/GLB, G3D, JSON formats
   - UnifiedMaterial and MaterialResolver
   - Note: ModelEditor has inline model loading code that should be moved to ModelLoader

4. **Foundation Integration Tasks**
   - [ ] Remove all ModernGL references from example files
   - [ ] Remove ModernGL from requirements/cache
   - [ ] Verify no remaining ModernGL references
   - [ ] Complete Image Editor migration to Canvas_2D (if not fully done)
   - [ ] Migrate Sprite Editor to use shared Canvas_2D
   - [ ] Migrate Texture Editor to use shared Canvas_2D
   - [ ] Ensure Model Editor uses Viewport_3D properly

---

## ⭐ TIER 1 — Easiest Changes With Huge UX/Performance Value

### 1. Replace QPainter Canvas With GPU Canvas (Image Editor)
**Status**: ✅ **COMPLETE** (GPU Canvas implemented and working, optional via Preferences)
- [x] ✅ **Image Editor uses Canvas_2D when "Use Hardware Rendering" is enabled** (Prefs → Editor Specific → Image → "Use Hardware Rendering")
- [x] ✅ Canvas_2D exists and is functional
- [x] ✅ Preference setting saves/loads correctly
- [x] ✅ Falls back to CheckerboardCanvas if GPU initialization fails
- [x] ✅ **CHECKERBOARD BACKGROUND IN SHADER**: Confirmed in `SuperShader_2D.py` (lines 139-159) - `checkerboard_pattern()` function in fragment shader, called via `set_checkerboard()` in `Canvas_2D.py` (line 131)
- [x] ✅ **TEXTURE UPLOAD FOR NUMPY ARRAYS (RGBA)**: Confirmed in `Canvas_2D.set_image()` (lines 312-350) - accepts `np.ndarray`, uses `TextureManager.create_texture_from_array()` which handles RGBA/RGB/grayscale (lines 29-100 in TextureManager.py)
- [x] ✅ **ZOOM/PAN LOGIC USES GPU TRANSFORMS**: Confirmed - `_update_model_matrix()` (lines 252-310) creates 3x3 GPU transformation matrix, applied in `paintGL()` (line 144). Zoom/pan calculations feed into GPU matrix via `set_model_matrix()` shader uniform
- [x] ✅ **PIXEL-PERFECT FILTERING METHOD EXISTS**: Confirmed - `set_pixel_perfect()` method (lines 416-436) toggles between GL_NEAREST (pixel-perfect) and GL_LINEAR (smooth) filtering. Filtering is applied to texture (lines 342-343)
- [ ] ⚠️ **UI TOGGLE FOR PIXEL-PERFECT**: No UI toggle found - method exists but needs UI control added (checkbox/menu item)
- [x] ✅ **PREVIEWBOX USES QPAINTER**: Confirmed - `PreviewBox` (lines 2601-2663 in `preview.py`) uses `QPainter` for rendering, not Canvas_2D. This is intentional (separate preview panel, not main canvas)
- [ ] 📋 **MANUAL TESTING NEEDED**: Test with various image sizes (32x32 to 4096x4096) - code supports it but needs manual verification
- [ ] **Note**: Currently requires Image Editor restart to take effect (checked at initialization)

### 2. Dirty Rectangles (Only Update Changed Pixels)
**Status**: ✅ **COMPLETE**
- [x] Implement dirty rectangle tracking in `EditorState`
- [x] Track modified regions on brush/shape operations
- [x] Partial texture updates in GPU canvas
- [x] Combine multiple dirty rectangles for efficiency
- [x] Reset dirty rectangles after render

**Implementation Details:**
- **EditorState (`core/state.py`)**: Added `dirty_rectangles` list, `mark_dirty_region()`, `mark_dirty_point()`, `merge_dirty_rectangles()`, `clear_dirty_rectangles()`, and `has_dirty_regions()` methods. Automatically merges overlapping/adjacent rectangles and limits to 100 regions before forcing full redraw.

- **Canvas_2D (`Core/Rendering/Canvas_2D.py`)**: Added `update_partial_texture()` method using `glTexSubImage2D` for efficient GPU texture updates. Added `update_dirty_regions()` method that reads from EditorState and performs partial updates. Falls back to full update if >20 dirty regions or full_redraw_needed flag is set.

- **CheckerboardCanvas (`ui/preview.py`)**: Added `update_dirty_regions()` method that converts image coordinates to widget coordinates and uses `QWidget.update(QRect)` for partial repaints. Qt automatically clips repaints to requested regions.

- **Drawing Operations**: All drawing operations (`_draw_at`, `_draw_line`, `_draw_shape`) now mark dirty regions in EditorState using bounding boxes with padding. Single pixel operations mark 3x3 regions, brush operations mark radius + 2 pixel padding.

- **Integration**: Both canvas types now check for dirty regions and use partial updates when available. MainWindow's GPU canvas compatibility layer calls `update_dirty_regions()` when updating images.

**Testing Notes:**
- Manual testing needed to verify performance improvements with large images
- Verify partial updates work correctly at various zoom levels
- Test with rapid brush strokes to ensure dirty rectangles merge correctly
- Confirm full redraw fallback works when dirty region count exceeds threshold

### 3. Delta-Based Undo/Redo
**Status**: 🔴 **NOT STARTED**
- [ ] Implement diff calculation (before vs after pixel regions)
- [ ] Store pixel deltas instead of full frame copies
- [ ] Compression for delta regions (RLE or similar)
- [ ] Apply/restore deltas efficiently
- [ ] Limit undo stack size by memory usage, not count
- [ ] Test with large images (4K+)

### 4. Remove ModernGL Fully → Consolidate on PyOpenGL
**Status**: 🟡 **PARTIALLY COMPLETE**
- [x] Remove ModernGL imports from `Core/Rendering/Renderer.py` (file deleted)
- [x] Remove ModernGL imports from `Core/Rendering/Shadows.py` (file deleted)
- [x] Remove ModernGL imports from `Core/Rendering/ModelLoader.py` (file deleted)
- [x] Remove ModernGL imports from `Core/Rendering/Shaders.py` (file deleted)
- [ ] Remove ModernGL from example files (if any exist)
- [ ] Remove ModernGL from requirements/cache
- [ ] Verify no remaining ModernGL references

### 5. Background Task Queue
**Status**: 🟡 **PARTIALLY IMPLEMENTED** (exists in Image Editor)
- [x] Basic BackgroundProcessor exists in `Editors/Image/2/core/background_processor.py`
- [ ] Expand existing `BackgroundProcessor` to handle more task types
- [ ] Create shared `Core/BackgroundProcessor.py` (or move existing one)
- [ ] Thumbnail generation queue
- [ ] Validation task queue
- [ ] Progress reporting system
- [ ] UI indicators for background tasks
- [ ] Task cancellation support

### 6. Lazy Loading of Frames & Layers
**Status**: 🔴 **NOT STARTED**
- [ ] Implement frame data on-demand loading
- [ ] Unload frames not currently visible
- [ ] Memory threshold management
- [ ] Loading indicators for delayed frames
- [ ] Cache recently viewed frames

### 7. Session Cache (Thumbnails + Last Opened Editors)
**Status**: 🔴 **NOT STARTED**
- [ ] Create `Core/SessionCache.py`
- [ ] Generate and cache thumbnails for all resources
- [ ] Store last opened editor state
- [ ] Restore editor tabs on startup
- [ ] Cache invalidation on file changes

---

## ⭐ TIER 2 — Medium Difficulty, Very High UX / Engine Value

### 8. "Run Game" Button (F5)
**Status**: 🔴 **NOT STARTED**
- [ ] Create `Core/GameRunner.py`
- [ ] Implement game runner system
- [ ] Generate temporary build structure
- [ ] Launch game in venv Python
- [ ] Handle stdout/stderr capture
- [ ] Add "Stop Game" functionality
- [ ] Error reporting for runtime errors
- [ ] Add F5 shortcut to MainWindow
- **Dependencies**: Runtime Engine Architecture (Task 16)

### 9. "Build Game" to EXE
**Status**: 🔴 **NOT STARTED**
- [ ] Create `Core/GameBuilder.py`
- [ ] Integrate PyInstaller or similar
- [ ] Bundle runtime, resources, scripts
- [ ] Generate platform-specific executables
- [ ] Icon and metadata configuration
- [ ] Build progress reporting
- [ ] Output directory selection
- **Dependencies**: Runtime Engine Architecture (Task 16)

### 10. Resource Inspector Panel
**Status**: 🔴 **NOT STARTED**
- [ ] Create `UI/ResourceInspector.py`
- [ ] Create inspector panel widget
- [ ] Display resource metadata dynamically
- [ ] Quick action buttons (open, duplicate, export)
- [ ] Property editing for selected resources
- [ ] Integrate into MainWindow layout

### 11. Unified BaseEditor Class
**Status**: 🔴 **NOT STARTED**
- [ ] Create `Core/BaseEditor.py`
- [ ] Create abstract BaseEditor class
- [ ] Implement common save/load/close logic
- [ ] Standardized signal system
- [ ] Refactor SpriteEditor to inherit BaseEditor
- [ ] Refactor Image Editor to inherit BaseEditor
- [ ] Refactor other editors to inherit BaseEditor

### 12. Tile-Based Multi-threaded Effects (Image Editor)
**Status**: 🔴 **NOT STARTED**
- [ ] Create `Editors/Image/2/core/effect_processor.py`
- [ ] Implement tile-based image splitting
- [ ] Multi-threaded effect processing
- [ ] Progress reporting per tile
- [ ] Seamless tile recombination
- [ ] Memory-efficient tile processing
- **Dependencies**: Background Task Queue (Task 5)

### 13. Inspector + Object/Room Metadata
**Status**: 🔴 **NOT STARTED**
- [ ] Extend Resource Inspector (Task 10)
- [ ] Display frame counts for sprites
- [ ] Display event lists for objects
- [ ] Display sound duration and metadata
- [ ] Display triangle count for models
- [ ] Display room instance counts
- **Dependencies**: Resource Inspector Panel (Task 10)

---

## ⭐ TIER 3 — Moderate Difficulty, Very Large Strategic Value

### 14. Object Editor (GameMaker-style Events)
**Status**: 🔴 **NOT STARTED**
- [ ] Create `Editors/ObjectEditor.py`
- [ ] Create `Core/Runtime/Events.py`
- [ ] Create Object Editor UI
- [ ] Implement event system (Create, Step, Draw, Collision, etc.)
- [ ] Integrated script editor for events
- [ ] Inspector for object properties
- [ ] Visual event flow representation
- [ ] Event templates/library
- **Dependencies**: Runtime Engine Architecture (Task 16)

### 15. Room Editor 2.0 (Drag & Drop + Live Preview)
**Status**: 🟡 **PARTIALLY STARTED** (basic structure exists)
- [x] Basic UI structure exists in `Editors/RoomEditor.py`
- [ ] Implement real-time PyOpenGL viewport (use Viewport_3D or 2D equivalent)
- [ ] Drag-and-drop sprite/object placement
- [ ] Snap and grid system
- [ ] Layer management for room
- [ ] Visual instance properties editing
- [ ] Room camera controls
- **Dependencies**: Foundation (Viewport_3D), Runtime Engine Architecture (Task 16)

### 16. Runtime Engine Architecture (Rooms/Objects/Renderer)
**Status**: 🔴 **NOT STARTED**
- [ ] Create `Core/Runtime/` directory
- [ ] Create pygame-based main loop
- [ ] Implement resource pack loading system
- [ ] Object lifecycle management
- [ ] Room transition system
- [ ] Event system integration
- [ ] Input handling system
- [ ] Collision detection system
- **Dependencies**: Foundation (Shared PyOpenGL Runtime)

### 17. Script Language (PGSL → Python)
**Status**: 🔴 **NOT STARTED**
- [ ] Create `Core/PGSL/` directory
- [ ] Design PGSL syntax (beginner-friendly)
- [ ] Implement PGSL parser
- [ ] Implement PGSL → Python transpiler
- [ ] Syntax highlighting for PGSL
- [ ] PGSL code editor integration
- [ ] Error reporting for PGSL
- **Note**: Alternative is to use Python directly with game API (recommended in Plan.md)

### 18. Mipmaps & Better Zoom Quality (Image Editor)
**Status**: 🔴 **NOT STARTED**
- [ ] Implement automatic mipmap generation in TextureManager
- [ ] Pixel-perfect mode (nearest neighbor filtering)
- [ ] Smooth mode (linear filtering with mipmaps)
- [ ] Zoom level detection and mipmap selection
- [ ] UI toggle for pixel-perfect vs smooth
- **Dependencies**: GPU Canvas (Task 1)

### 19. Optimised Selection Tools
**Status**: 🔴 **NOT STARTED**
- [ ] Optimize magic wand algorithm (vectorized)
- [ ] Implement Numba JIT for selection operations
- [ ] Cache selection masks efficiently
- [ ] Multi-threaded selection processing
- [ ] Progress reporting for large selections

---

## ⭐ TIER 4 — Harder, Long-Term, Polishing Features

### 20. Unified UI Theme (Dark/Light + SVG Icons)
**Status**: 🟡 **PARTIALLY IMPLEMENTED** (basic theming exists)
- [x] Basic theme system exists
- [ ] Create comprehensive light theme
- [ ] Improve dark theme consistency
- [ ] Replace PNG icons with SVG icons
- [ ] Icon color theming system
- [ ] Theme preview in preferences
- [ ] Custom theme creation support

### 21. Docking UI System
**Status**: 🔴 **NOT STARTED**
- [ ] Create `UI/DockManager.py`
- [ ] Implement movable panels system
- [ ] Save/restore workspace layouts
- [ ] Panel grouping and tabbing
- [ ] Floating panel support
- [ ] Default workspace layouts
- **Dependencies**: PySide6 QDockWidget or custom docking library

### 22. AI Everywhere (Multi-editor Integration)
**Status**: 🟡 **PARTIALLY IMPLEMENTED** (Image Editor AI dialog exists)
- [x] Image Editor AI dialog exists
- [ ] AI animation assist (sprite editor)
- [ ] AI room layout suggestions (room editor)
- [ ] AI shader/material help (model editor)
- [ ] AI sound cleanup (sound editor)
- [ ] Unified AI dialog system
- [ ] AI service abstraction layer
- [ ] Create `Core/AI/` directory
- **Dependencies**: Free AI service integration (currently blocked)

### 23. Delta Compression for Large Edits
**Status**: 🔴 **NOT STARTED**
- [ ] Implement patch storage system
- [ ] Compress patches efficiently
- [ ] Apply patches incrementally
- [ ] Memory usage optimization
- **Dependencies**: Delta-Based Undo/Redo (Task 3)

### 24. Dedicated Runtime Preview Panel
**Status**: 🔴 **NOT STARTED**
- [ ] Create `UI/RuntimePreviewPanel.py`
- [ ] Create in-IDE preview panel
- [ ] Embed game viewport
- [ ] Debug overlay (FPS, object counts, etc.)
- [ ] Input forwarding to preview
- [ ] Preview controls (play, pause, step)
- **Dependencies**: Runtime Engine Architecture (Task 16)

---

## ⭐ TIER 5 — Advanced Professional Features

### 25. ECS Architecture (Optional)
**Status**: 🔴 **NOT STARTED**
- [ ] Create `Core/Runtime/ECS/` directory
- [ ] Design ECS component system
- [ ] Implement entity manager
- [ ] Implement component storage
- [ ] Implement system processing
- [ ] Migration from object-based to ECS
- **Dependencies**: Runtime Engine Architecture (Task 16)

### 26. GPU-Accelerated Effects (GLSL Filters)
**Status**: 🔴 **NOT STARTED**
- [ ] Create `Core/Rendering/Effects/` directory
- [ ] Implement GLSL blur shader
- [ ] Implement GLSL glow shader
- [ ] Implement color grading shader
- [ ] Implement outline shader
- [ ] Effect chain system
- [ ] Real-time preview of GPU effects
- **Dependencies**: Foundation (Shared PyOpenGL Runtime)

### 27. In-game Debug Console & REPL
**Status**: 🔴 **NOT STARTED**
- [ ] Create `Core/Runtime/DebugConsole.py`
- [ ] Implement debug console overlay
- [ ] REPL for live Python execution
- [ ] Object inspection commands
- [ ] Variable modification commands
- [ ] Command history
- [ ] Auto-completion
- **Dependencies**: Runtime Engine Architecture (Task 16)

### 28. Auto Test Runner & Crash Reporting
**Status**: 🔴 **NOT STARTED**
- [ ] Create `Core/Testing/` directory
- [ ] Implement test discovery system
- [ ] Automated test execution
- [ ] Crash report generation
- [ ] Error telemetry (optional, user consent)
- [ ] Test result reporting

---

## 📋 Plan.md Specific Outstanding Items

### Phase 1: Core Editor Completion

#### 1.1 Finish Image/Sprite Editor Polish
- [ ] Collision mask visual editor (currently just a button)
- [ ] Animation frame tag save/load system (tags persist to `.sprite` files)
- [ ] Sprite atlas improvements (auto-packing, export metadata)

#### 1.2 Complete Sound Editor
- [ ] Sound groups/categories system
- [ ] Basic audio effects (reverb, echo)
- [ ] Export/compression options
- [ ] WaveForge (Audacity-style editor) — Full waveform editing, effects chain
- [ ] MelodyMaker (GarageBand-style) — MIDI sequencer, instrument library, export to WAV

#### 1.3 Complete Room Editor (PGRE — Pygre)
- [ ] Visual instance placement (drag-and-drop objects onto room)
- [ ] Sprite rendering for instances (show actual sprite images)
- [ ] Zoom and pan controls
- [ ] Instance selection handles (move, rotate, scale)
- [ ] Background layering and rendering
- [ ] Tile system (place tile regions)

### Phase 2: Object System (PGOE — PyGo)
- [ ] All tasks from Task 14 above

### Phase 3: Scripting & Code (PGSL — Pigsil + PGCE — PyCo)
- [ ] All tasks from Task 17 above
- [ ] Code Editor (PGCE — PyCo)
  - [ ] Syntax highlighting for PGSL (or Python)
  - [ ] Auto-completion for game API
  - [ ] Error detection and inline warnings
  - [ ] Code templates for events
  - [ ] Integration with Object Editor

### Phase 4: Runtime & Execution (PGBE)
- [ ] All tasks from Task 16 above
- [ ] Resource Pipeline
  - [ ] Project compilation (convert `.pgproject` to runtime format)
  - [ ] Resource bundling (organize all assets)
  - [ ] Dependency resolution (validate all references)

### Phase 5: Testing & Debugging
- [ ] Test Button (covered in Task 8)
- [ ] Debug Mode
  - [ ] Subprocess inspector window (detached debugger UI)
  - [ ] Variable inspector (inspect all objects, specific objects, globals)
  - [ ] Resource usage viewer (memory, textures, sounds)
  - [ ] Breakpoint system (pause execution)
  - [ ] Step-by-step execution
  - [ ] Call stack viewer
- [ ] Compile/Export (covered in Task 9)

### Phase 6: Advanced Features
- [ ] Model Editor (PGME — Pigme) — **STATUS**: 🟡 **PARTIALLY COMPLETE**
  - [x] Basic structure exists
  - [x] Model loading (inline implementation)
  - [ ] Move model loading to shared ModelLoader
  - [ ] Complete 3D preview improvements
  - [ ] Animation support (if needed)
- [ ] Additional Systems
  - [ ] Particle system editor
  - [ ] Shader editor
  - [ ] Physics integration
  - [ ] Networking support
  - [ ] Save/load system

---

## 🎯 Priority Summary

### 🔴 CRITICAL (Blocking Foundation)
1. **Recreate SuperShader_3D** - Required for 3D rendering
2. **Recreate Viewport_3D** - Required for 3D viewport
3. **Recreate ModelLoader** - Required for model loading

### 🟠 HIGH PRIORITY (Foundation Completion)
4. Complete Foundation integration tasks
5. Remove all ModernGL references
6. Verify GPU Canvas migration in Image Editor

### 🟡 MEDIUM PRIORITY (Tier 1 Tasks)
7. Dirty Rectangles implementation
8. Delta-Based Undo/Redo
9. Lazy Loading of Frames & Layers
10. Session Cache
11. Expand Background Task Queue

### 🟢 LOWER PRIORITY (Tier 2+ Tasks)
12. All Tier 2 tasks (Run Game, Build EXE, Resource Inspector, etc.)
13. All Tier 3 tasks (Object Editor, Room Editor 2.0, Runtime Engine, etc.)
14. All Tier 4 tasks (Theme improvements, Docking, AI, etc.)
15. All Tier 5 tasks (ECS, GPU Effects, Debug Console, etc.)

---

## 📊 Implementation Status Summary

- **Foundation**: 50% complete (missing 3 critical components)
- **Tier 1**: ~30% complete (2/7 tasks started)
- **Tier 2**: 0% complete (0/6 tasks)
- **Tier 3**: ~5% complete (1/6 tasks started)
- **Tier 4**: ~15% complete (2/5 tasks started)
- **Tier 5**: 0% complete (0/4 tasks)

**Overall Roadmap Completion**: ~25%

---

## 📝 Notes

- ModelEditor was recently recreated and uses a basic BoundedViewport_3D, but needs full Viewport_3D integration
- Several critical files (SuperShader_3D, Viewport_3D, ModelLoader) were deleted and need to be recreated
- Background processing exists but is limited to Image Editor - needs to be shared
- Many tasks are blocked by the Foundation architecture completion
- Runtime Engine Architecture (Task 16) is a dependency for many high-value features

---

**This document should be updated after each major implementation milestone.**

