# Image Editor Performance Analysis - Critical Bottlenecks

**IMPORTANT**: This analysis covers BOTH rendering paths:
- **Canvas_2D (PyOpenGL GPU)** - Hardware-accelerated rendering via PyOpenGL
- **CheckerboardCanvas (QPainter Software)** - Software rendering via QPainter

Both paths need optimization, though the issues differ slightly.

## 🔴 CRITICAL ISSUES (Blocking Performance)

### 1. paintEvent Does Expensive Operations on EVERY Frame
**Location**: `Editors/Image/2/ui/preview.py:2363` (CheckerboardCanvas.paintEvent)

**Problems**:
- `composite_layers()` called on EVERY paintEvent when `show_composite=True`
  - Composites ALL visible layers with alpha blending
  - Creates new NumPy arrays
  - Loops through all layers
  - **Impact**: O(layers × width × height) on every paint (~60 times per second)
  
- QImage creation from NumPy array on EVERY paintEvent (line ~2255)
  - `QImage(img_copy.data, ...)` creates new QImage
  - Array copying with `np.ascontiguousarray()`
  - **Impact**: Memory allocation + conversion overhead
  
- Checkerboard pattern drawn with nested loops (lines 2235-2240)
  - Double loop `for y in range(...): for x in range(...)`
  - Executes on every paintEvent
  - **Impact**: O(width × height) operations per frame
  
- Grid rendering recalculates everything (lines 2347-2376)
  - Rotated grid lines calculated on every paint
  - Multiple trigonometric calculations
  - **Impact**: Heavy CPU usage

- Onion skin overlays drawn on every paintEvent (lines 2265-2323)
  - Multiple frame lookups and color conversions
  - QImage creation for each overlay

**Recommended Fixes**:
1. **Cache composite image** - Only recomposite when layers change
2. **Cache QImage** - Only recreate QImage when image data changes
3. **Pre-generate checkerboard pattern** - Create static texture/pixmap once
4. **Cache grid lines** - Only recalculate on grid change/zoom
5. **Cache onion skin overlays** - Only regenerate on frame change

---

### 2. Excessive Image Copying
**Location**: Multiple locations

**Problems**:
- `update_current_image_from_selected_layer()` does `img.copy()` (line 2349)
  - Called on every frame/layer change
  - Creates full image copy (O(width × height))
  
- `force_canvas_and_preview_refresh()` triggers full copy
  - Called from 20+ locations in codebase
  - Each call = full image copy
  
- GPU canvas compatibility layer copies image (main_window.py:1404)
  - `image = current_frame.image.copy()` on every update
  - Even with dirty rectangles, still does copy

**Recommended Fixes**:
1. **Use references where possible** - Only copy when absolutely necessary
2. **Track image changes** - Use dirty flags to avoid unnecessary copies
3. **Lazy copying** - Copy only when multiple consumers need independent data

---

### 3. Composite Layers Called Too Frequently
**Location**: `Editors/Image/2/layers/manager.py:22` (composite_layers)

**Problems**:
- Called from paintEvent on every frame render
- Loops through all layers, doing alpha blending for each
- PIL Image.resize() called if size mismatch (line 50)
- **No caching** - Recomputes entire composite every time

**Performance Impact**:
- For 5 layers at 512x512: ~50MB memory ops per frame
- At 60 FPS: ~3GB/second memory bandwidth
- Multiple float conversions and array operations

**Recommended Fixes**:
1. **Cache composite result** - Store last composite, invalidate on layer change
2. **Dirty tracking** - Track which layers changed, recomposite only changed regions
3. **Lazy compositing** - Only composite when visible/composite mode active

---

### 4. Timeline Thumbnail Generation
**Location**: `Editors/Image/2/ui/timeline.py:74` (_generate_thumbnail)

**Problems**:
- Thumbnails generated on FrameBox creation (every frame)
- Multiple cv2.resize operations
- RGB↔BGR color space conversions (lines 94-109)
- Called for ALL frames when timeline updates (line 610)

**Performance Impact**:
- For 10 frames: 10 thumbnail generations
- Each thumbnail = cv2.resize + color conversions
- Timeline update blocks UI thread

**Recommended Fixes**:
1. **Cache thumbnails** - Store generated thumbnails, regenerate only on frame change
2. **Lazy generation** - Generate thumbnails on-demand when frame becomes visible
3. **Background generation** - Use thread pool for thumbnail generation
4. **Simplify conversion** - Avoid unnecessary RGB↔BGR conversions

---

### 5. Excessive update() Calls
**Location**: Found 29+ `.update()` calls in preview.py alone

**Problems**:
- Every mouse move triggers `self.update()` (lines 229, 237, 246, etc.)
- Multiple updates in single operation (brush stroke triggers multiple)
- No batching or throttling
- Each `update()` schedules a paintEvent

**Performance Impact**:
- At 60 FPS: 60 paintEvents/second
- With expensive paintEvent: Constant CPU usage
- Can cause UI lag

**Recommended Fixes**:
1. **Batch updates** - Collect updates, flush once per frame
2. **Throttle updates** - Limit to 60 FPS maximum
3. **Use dirty rectangles** - Already implemented, ensure it's working correctly
4. **Debounce rapid updates** - Group rapid updates together

---

## 🟡 HIGH PRIORITY ISSUES

### 6. Preview Box Updates
**Location**: `_update_preview_box()` called from many places

**Problems**:
- Preview box updated on every canvas change
- May trigger full repaint of preview widget
- Called from brush strokes, layer changes, etc.

**Recommended Fixes**:
1. **Throttle preview updates** - Update max once per frame
2. **Dirty tracking for preview** - Only update when preview area changed

---

### 7. Selection Rendering (Marching Ants)
**Location**: Selection manager draws marching ants

**Problems**:
- Contour detection on every paintEvent
- Animated marching ants requires frequent updates
- Resize handles calculated every frame

**Recommended Fixes**:
1. **Cache contours** - Only recalculate on selection change
2. **Optimize animation** - Use shader or optimized drawing
3. **Simplify handles** - Use simpler rendering method

---

### 8. Grid Rendering Performance
**Location**: `preview.py:2347-2376`

**Problems**:
- Rotated grid lines calculated on every paintEvent
- Trigonometric calculations for every line
- Multiple drawLine() calls

**Recommended Fixes**:
1. **Cache grid lines** - Pre-calculate lines, only update on grid/zoom change
2. **Use QPixmap** - Render grid to pixmap, cache it
3. **Simplify rotation** - Use transform matrix instead of manual calculation

---

## 📊 Performance Metrics (Estimated)

### Current Performance (Without Optimizations)
- **paintEvent**: ~16-50ms per frame (should be <16ms for 60 FPS)
- **Brush stroke**: ~50-200ms (should be <16ms)
- **Layer composite**: ~10-30ms per composite (called 60x/sec)
- **Thumbnail gen**: ~5-10ms per thumbnail (blocks UI)

### Target Performance (After Optimizations)
- **paintEvent**: <8ms per frame (120+ FPS capability)
- **Brush stroke**: <8ms (real-time responsiveness)
- **Layer composite**: <2ms (cached, only on change)
- **Thumbnail gen**: <1ms (cached) or async

---

## 🎯 Prioritized Action Plan

### Phase 1: Critical Fixes (Biggest Impact)
1. ✅ **Cache composite image** - Store last composite, invalidate on change
2. ✅ **Cache QImage for rendering** - Only recreate when image data changes
3. ✅ **Pre-generate checkerboard** - Create static texture/pixmap
4. ✅ **Reduce image copying** - Use references, track changes

### Phase 2: High Impact
5. ✅ **Cache grid rendering** - Pre-calculate, only update on change
6. ✅ **Throttle/batch updates** - Limit paintEvents to 60 FPS
7. ✅ **Cache thumbnails** - Store in FrameBox, regenerate on change

### Phase 3: Polish
8. ✅ **Optimize onion skin** - Cache overlay images
9. ✅ **Simplify selection rendering** - Cache contours
10. ✅ **Background thumbnail generation** - Move to thread pool

---

## 🔧 Implementation Strategy

### For Composite Caching:
```python
class LayerManager:
    def __init__(self):
        self._composite_cache = None
        self._composite_cache_frame = None
        self._composite_cache_layers = None
    
    def composite_layers(self, frame_index):
        # Check cache validity
        if (self._composite_cache is not None and
            self._composite_cache_frame == frame_index and
            self._composite_cache_layers == self._get_visible_layers_hash()):
            return self._composite_cache.copy()
        
        # Generate composite
        composite = self._generate_composite(frame_index)
        
        # Update cache
        self._composite_cache = composite
        self._composite_cache_frame = frame_index
        self._composite_cache_layers = self._get_visible_layers_hash()
        
        return composite.copy()
```

### For QImage Caching:
```python
class CheckerboardCanvas:
    def __init__(self):
        self._cached_qimage = None
        self._cached_image_hash = None
    
    def paintEvent(self, event):
        current_image = self.current_image
        image_hash = hash(current_image.tobytes()) if current_image is not None else None
        
        if self._cached_qimage is None or self._cached_image_hash != image_hash:
            # Recreate QImage
            self._cached_qimage = self._create_qimage(current_image)
            self._cached_image_hash = image_hash
        
        # Use cached QImage for rendering
        painter.drawImage(offset_x, offset_y, self._cached_qimage)
```

### For Checkerboard Pattern:
```python
def _create_checkerboard_pixmap(self, size):
    """Create checkerboard pattern as cached pixmap"""
    pixmap = QPixmap(size, size)
    painter = QPainter(pixmap)
    # Draw checkerboard once
    # Cache the pixmap
    return pixmap

def paintEvent(self, event):
    # Use cached checkerboard pixmap
    painter.drawPixmap(tile_rect, self.checkerboard_pixmap)
```

---

## 📈 Expected Performance Gains

- **paintEvent**: 5-10x faster (from ~30ms to ~3-6ms)
- **Brush strokes**: 2-3x faster (less paintEvent overhead)
- **Layer compositing**: 50-100x faster when cached (only on change)
- **Timeline updates**: 10-20x faster (cached thumbnails)
- **Overall UI responsiveness**: Much smoother, no lag

---

## ⚠️ Important Notes

1. **Dirty rectangle system** already exists but may not be used optimally
2. **GPU canvas (Canvas_2D)** should already have better performance but needs optimization too
3. **Memory vs Performance tradeoff** - Caching uses more memory but significantly faster
4. **Invalidation strategy** - Need robust cache invalidation on edits

