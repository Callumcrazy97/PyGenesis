# PyGenesis IDE — Comprehensive Development Roadmap

## Current Status Summary

### ✅ Completed Systems
- Project Management — Full project creation, loading, saving, purging
- Resource Management — Complete CRUD for all resource types with file propagation
- Image Editor (PGIE — Piggie) — Feature-complete pixel art editor with effects, timeline, selections
- Sprite Editor — Full integration with Image Editor, animation tag preview system
- Sound Editor (PGSE — Pygsie) — Basic playback, waveforms, track mixing (WAV/MP3 support)
- Preferences/Theme System — Complete with customization
- Screen Recording — Integrated with auto-management
- Backup System — Editor and project backup with versioned folders
- AI Integration — Basic AI assistant dialog structure (work in progress)

### 🚧 Partially Complete
- Room Editor — UI exists but needs visual placement, sprite rendering, zoom/pan
- Sound Editor — Advanced editors (WaveForge, MelodyMaker) not started
- AI Integration — Test app exists, full integration pending

### ❌ Not Started
- Object Editor (PGOE — PyGo) — Does not exist
- Model Editor (PGME — Pigme) — Basic structure exists, needs full implementation
- Scripting Language (PGSL — Pigsil) — Does not exist
- Code Editor (PGCE — PyCo) — Does not exist
- Backend Runtime (PGBE — Piggieback) — Does not exist
- Compile/Test System — Does not exist
- Debug Mode — Does not exist

---

## 🏗️ Foundation: Shared PyOpenGL Runtime Architecture

**Status**: ⚠️ CRITICAL — Must be completed before Tier 1 improvements

### Overview
Create a unified OpenGL rendering system shared across all editors, eliminating ModernGL dependencies and providing consistent, high-performance rendering.

### Architecture Plan

#### Core Components

**1. `Core/Rendering/OpenGLRuntime.py`**
- Singleton OpenGL context manager
- Context creation and lifecycle management
- Shared resource pool (textures, buffers)
- Cross-editor state synchronization
- PyOpenGL wrapper (not ModernGL)

**2. `Core/Rendering/ShaderManager.py`**
- Unified shader compilation and management
- Hot-reload capability for shader development
- Shader variant system (for 2D vs 3D modes)

**3. `Core/Rendering/SuperShader_2D.py`**
- GameMaker-style unified 2D shader
- Supports: sprite rendering, texture atlas, color modulation, rotation, scale, flip
- Blending modes: normal, multiply, screen, additive, subtract
- Supports both pixel-perfect and smooth filtering modes
- Built-in checkerboard background rendering
- Selection mask rendering support

**4. `Core/Rendering/SuperShader_3D.py`**
- Unified 3D shader for model/room preview
- PBR (Physically Based Rendering) support
- Shadow mapping (hard, soft, CSM)
- Multiple light types (directional, point, spot)
- Material properties (albedo, metallic, roughness, normal maps)
- Wireframe mode support

**5. `Core/Rendering/Canvas_2D.py`**
- GPU-accelerated 2D canvas widget (QOpenGLWidget-based)
- Replaces QPainter-based CheckerboardCanvas
- Texture-based image rendering with zoom/pan
- Dirty rectangle tracking and partial updates
- Mipmap generation for smooth zoom
- Pixel-perfect mode toggle

**6. `Core/Rendering/Viewport_3D.py`**
- GPU-accelerated 3D viewport widget
- Camera controllers (orbit, FPS, orthographic)
- Frustum culling
- Level-of-detail (LOD) support
- Render queues and batching

**7. `Core/Rendering/BufferManager.py`**
- Shared VBO/VAO/IBO management
- Buffer pooling to reduce allocations
- Automatic cleanup and resource tracking

**8. `Core/Rendering/TextureManager.py`**
- Shared texture cache across editors
- Automatic texture atlas generation
- Mipmap generation and management
- Format conversion (RGBA, RGB, grayscale)
- Texture compression support (optional)

### Integration Points

**Image Editor Integration:**
- Replace `CheckerboardCanvas` (QPainter-based) with `Canvas_2D` (OpenGL-based)
- Use `SuperShader_2D` for all canvas rendering
- GPU texture upload for layer/frame images
- Hardware-accelerated zoom/pan

**Sprite Editor Integration:**
- Use shared `Canvas_2D` for preview panel
- Leverage texture atlas system for sprite sheets

**Texture Editor Integration:**
- Use `Canvas_2D` for texture preview
- Leverage mipmap generation for zoom previews

**Model Editor Integration:**
- Use `Viewport_3D` for model preview
- Use `SuperShader_3D` for rendering
- Integrate with existing camera system

**Room Editor Integration:**
- Use `Viewport_3D` for room editing viewport
- Use `SuperShader_2D` for sprite rendering in 3D space
- Orthographic and perspective projection support

### Migration Strategy

1. **Phase 1**: Create core runtime classes (OpenGLRuntime, ShaderManager, BufferManager, TextureManager)
2. **Phase 2**: Implement SuperShader_2D and Canvas_2D
3. **Phase 3**: Migrate Image Editor to use Canvas_2D (parallel implementation, switch via flag)
4. **Phase 4**: Implement SuperShader_3D and Viewport_3D
5. **Phase 5**: Migrate Model Editor to Viewport_3D
6. **Phase 6**: Remove all ModernGL references and legacy rendering code
7. **Phase 7**: Optimize and profile performance

### Dependencies
- PyOpenGL (already in requirements)
- PyOpenGL-accelerate (already in requirements)
- NumPy (for buffer operations)
- QOpenGLWidget (from PySide6)

---

## ⭐ TIER 1 — Easiest Changes With Huge UX/Performance Value

**Priority Order**: Implement these immediately after Foundation architecture

### 1. Replace QPainter Canvas With GPU Canvas (Image Editor)
- **File**: `Editors/Image/2/ui/preview.py`
- **Status**: 🔴 Not Started
- **Impact**: ⭐⭐⭐⭐⭐ (Major)
- **Ease**: ⭐⭐⭐⭐ (High)
- **Dependencies**: Foundation (Shared PyOpenGL Runtime)
- **Tasks**:
  - [ ] Implement `Canvas_2D` widget using QOpenGLWidget
  - [ ] Port checkerboard background to shader
  - [ ] Implement texture upload for NumPy arrays (RGBA)
  - [ ] Port zoom/pan logic to GPU transforms
  - [ ] Add pixel-perfect vs smooth filtering toggle
  - [ ] Replace `CheckerboardCanvas` in `PreviewBox`
  - [ ] Test with various image sizes (32x32 to 4096x4096)

### 2. Dirty Rectangles (Only Update Changed Pixels)
- **File**: `Editors/Image/2/ui/preview.py`, `Editors/Image/2/core/state.py`
- **Status**: 🔴 Not Started
- **Impact**: ⭐⭐⭐⭐⭐
- **Ease**: ⭐⭐⭐⭐
- **Dependencies**: GPU Canvas (Task 1)
- **Tasks**:
  - [ ] Implement dirty rectangle tracking in `EditorState`
  - [ ] Track modified regions on brush/shape operations
  - [ ] Partial texture updates in GPU canvas
  - [ ] Combine multiple dirty rectangles for efficiency
  - [ ] Reset dirty rectangles after render

### 3. Delta-Based Undo/Redo
- **File**: `Editors/Image/2/core/history.py`
- **Status**: 🔴 Not Started
- **Impact**: ⭐⭐⭐⭐⭐
- **Ease**: ⭐⭐⭐⭐
- **Dependencies**: None
- **Tasks**:
  - [ ] Implement diff calculation (before vs after pixel regions)
  - [ ] Store pixel deltas instead of full frame copies
  - [ ] Compression for delta regions (RLE or similar)
  - [ ] Apply/restore deltas efficiently
  - [ ] Limit undo stack size by memory usage, not count
  - [ ] Test with large images (4K+)

### 4. Remove ModernGL Fully → Consolidate on PyOpenGL
- **Files**: `Core/Rendering/*.py`, `Editors/Model/Examples/*.py`
- **Status**: 🟡 In Progress (partially done)
- **Impact**: ⭐⭐⭐⭐⭐
- **Ease**: ⭐⭐⭐⭐⭐ (Very high)
- **Dependencies**: Foundation (Shared PyOpenGL Runtime)
- **Tasks**:
  - [x] Remove ModernGL imports from `Core/Rendering/Renderer.py`
  - [x] Remove ModernGL imports from `Core/Rendering/Shadows.py`
  - [x] Remove ModernGL imports from `Core/Rendering/ModelLoader.py`
  - [x] Remove ModernGL imports from `Core/Rendering/Shaders.py`
  - [ ] Remove ModernGL from example files
  - [ ] Remove ModernGL from requirements/cache
  - [ ] Verify no remaining ModernGL references

### 5. Background Task Queue
- **File**: `Core/BackgroundProcessor.py` (new), `Editors/Image/2/core/background_processor.py`
- **Status**: 🟡 Partially Implemented
- **Impact**: ⭐⭐⭐⭐⭐
- **Ease**: ⭐⭐⭐⭐
- **Dependencies**: None
- **Tasks**:
  - [ ] Expand existing `BackgroundProcessor` to handle more task types
  - [ ] Thumbnail generation queue
  - [ ] Validation task queue
  - [ ] Progress reporting system
  - [ ] UI indicators for background tasks
  - [ ] Task cancellation support

### 6. Lazy Loading of Frames & Layers
- **File**: `Editors/Image/2/layers/layer.py`, `Editors/Image/2/layers/manager.py`
- **Status**: 🔴 Not Started
- **Impact**: ⭐⭐⭐⭐
- **Ease**: ⭐⭐⭐⭐
- **Dependencies**: None
- **Tasks**:
  - [ ] Implement frame data on-demand loading
  - [ ] Unload frames not currently visible
  - [ ] Memory threshold management
  - [ ] Loading indicators for delayed frames
  - [ ] Cache recently viewed frames

### 7. Session Cache (Thumbnails + Last Opened Editors)
- **File**: `Core/SessionCache.py` (new)
- **Status**: 🔴 Not Started
- **Impact**: ⭐⭐⭐⭐
- **Ease**: ⭐⭐⭐⭐
- **Dependencies**: None
- **Tasks**:
  - [ ] Create session cache system
  - [ ] Generate and cache thumbnails for all resources
  - [ ] Store last opened editor state
  - [ ] Restore editor tabs on startup
  - [ ] Cache invalidation on file changes

---

## ⭐ TIER 2 — Medium Difficulty, Very High UX / Engine Value

**Priority Order**: Implement after Tier 1 completion

### 8. "Run Game" Button (F5)
- **File**: `Core/GameRunner.py` (new), `UI/MainWindow.py`
- **Status**: 🔴 Not Started
- **Impact**: ⭐⭐⭐⭐⭐
- **Ease**: ⭐⭐⭐
- **Dependencies**: Runtime Engine Architecture (Task 16)
- **Tasks**:
  - [ ] Implement game runner system
  - [ ] Generate temporary build structure
  - [ ] Launch game in venv Python
  - [ ] Handle stdout/stderr capture
  - [ ] Add "Stop Game" functionality
  - [ ] Error reporting for runtime errors

### 9. "Build Game" to EXE
- **File**: `Core/GameBuilder.py` (new)
- **Status**: 🔴 Not Started
- **Impact**: ⭐⭐⭐⭐⭐
- **Ease**: ⭐⭐⭐
- **Dependencies**: Runtime Engine Architecture (Task 16)
- **Tasks**:
  - [ ] Integrate PyInstaller or similar
  - [ ] Bundle runtime, resources, scripts
  - [ ] Generate platform-specific executables
  - [ ] Icon and metadata configuration
  - [ ] Build progress reporting
  - [ ] Output directory selection

### 10. Resource Inspector Panel
- **File**: `UI/ResourceInspector.py` (new)
- **Status**: 🔴 Not Started
- **Impact**: ⭐⭐⭐⭐⭐
- **Ease**: ⭐⭐⭐
- **Dependencies**: None
- **Tasks**:
  - [ ] Create inspector panel widget
  - [ ] Display resource metadata dynamically
  - [ ] Quick action buttons (open, duplicate, export)
  - [ ] Property editing for selected resources
  - [ ] Integrate into MainWindow layout

### 11. Unified BaseEditor Class
- **File**: `Core/BaseEditor.py` (new)
- **Status**: 🔴 Not Started
- **Impact**: ⭐⭐⭐⭐
- **Ease**: ⭐⭐⭐
- **Dependencies**: None
- **Tasks**:
  - [ ] Create abstract BaseEditor class
  - [ ] Implement common save/load/close logic
  - [ ] Standardized signal system
  - [ ] Refactor SpriteEditor to inherit BaseEditor
  - [ ] Refactor Image Editor to inherit BaseEditor
  - [ ] Refactor other editors to inherit BaseEditor

### 12. Tile-Based Multi-threaded Effects (Image Editor)
- **File**: `Editors/Image/2/core/effect_processor.py` (new)
- **Status**: 🔴 Not Started
- **Impact**: ⭐⭐⭐⭐
- **Ease**: ⭐⭐⭐
- **Dependencies**: Background Task Queue (Task 5)
- **Tasks**:
  - [ ] Implement tile-based image splitting
  - [ ] Multi-threaded effect processing
  - [ ] Progress reporting per tile
  - [ ] Seamless tile recombination
  - [ ] Memory-efficient tile processing

### 13. Inspector + Object/Room Metadata
- **File**: `UI/ResourceInspector.py` (extends Task 10)
- **Status**: 🔴 Not Started
- **Impact**: ⭐⭐⭐⭐
- **Ease**: ⭐⭐⭐
- **Dependencies**: Resource Inspector Panel (Task 10)
- **Tasks**:
  - [ ] Display frame counts for sprites
  - [ ] Display event lists for objects
  - [ ] Display sound duration and metadata
  - [ ] Display triangle count for models
  - [ ] Display room instance counts

---

## ⭐ TIER 3 — Moderate Difficulty, Very Large Strategic Value

**Priority Order**: Implement after Tier 2 completion

### 14. Object Editor (GameMaker-style Events)
- **File**: `Editors/ObjectEditor.py` (new), `Core/Runtime/Events.py` (new)
- **Status**: 🔴 Not Started
- **Impact**: ⭐⭐⭐⭐⭐ (Huge ROI)
- **Ease**: ⭐⭐
- **Dependencies**: Runtime Engine Architecture (Task 16)
- **Tasks**:
  - [ ] Create Object Editor UI
  - [ ] Implement event system (Create, Step, Draw, Collision, etc.)
  - [ ] Integrated script editor for events
  - [ ] Inspector for object properties
  - [ ] Visual event flow representation
  - [ ] Event templates/library

### 15. Room Editor 2.0 (Drag & Drop + Live Preview)
- **File**: `Editors/RoomEditor.py`, `Core/Rendering/Viewport_3D.py`
- **Status**: 🟡 Partially Started (basic structure exists)
- **Impact**: ⭐⭐⭐⭐⭐ (Enormous)
- **Ease**: ⭐⭐
- **Dependencies**: Foundation (Viewport_3D), Runtime Engine Architecture (Task 16)
- **Tasks**:
  - [ ] Implement real-time PyOpenGL viewport
  - [ ] Drag-and-drop sprite/object placement
  - [ ] Snap and grid system
  - [ ] Layer management for room
  - [ ] Visual instance properties editing
  - [ ] Room camera controls

### 16. Runtime Engine Architecture (Rooms/Objects/Renderer)
- **File**: `Core/Runtime/` (new directory)
- **Status**: 🔴 Not Started
- **Impact**: ⭐⭐⭐⭐⭐
- **Ease**: ⭐⭐
- **Dependencies**: Foundation (Shared PyOpenGL Runtime)
- **Tasks**:
  - [ ] Create pygame-based main loop
  - [ ] Implement resource pack loading system
  - [ ] Object lifecycle management
  - [ ] Room transition system
  - [ ] Event system integration
  - [ ] Input handling system
  - [ ] Collision detection system

### 17. Script Language (PGSL → Python)
- **File**: `Core/PGSL/` (new directory)
- **Status**: 🔴 Not Started
- **Impact**: ⭐⭐⭐⭐⭐
- **Ease**: ⭐⭐
- **Dependencies**: None
- **Tasks**:
  - [ ] Design PGSL syntax (beginner-friendly)
  - [ ] Implement PGSL parser
  - [ ] Implement PGSL → Python transpiler
  - [ ] Syntax highlighting for PGSL
  - [ ] PGSL code editor integration
  - [ ] Error reporting for PGSL

### 18. Mipmaps & Better Zoom Quality (Image Editor)
- **File**: `Core/Rendering/TextureManager.py`, `Editors/Image/2/ui/preview.py`
- **Status**: 🔴 Not Started
- **Impact**: ⭐⭐⭐⭐
- **Ease**: ⭐⭐
- **Dependencies**: GPU Canvas (Task 1)
- **Tasks**:
  - [ ] Implement automatic mipmap generation
  - [ ] Pixel-perfect mode (nearest neighbor filtering)
  - [ ] Smooth mode (linear filtering with mipmaps)
  - [ ] Zoom level detection and mipmap selection
  - [ ] UI toggle for pixel-perfect vs smooth

### 19. Optimised Selection Tools
- **File**: `Editors/Image/2/core/selection_manager.py`, `Editors/Image/2/selection_helpers.py`
- **Status**: 🔴 Not Started
- **Impact**: ⭐⭐⭐⭐⭐
- **Ease**: ⭐⭐
- **Dependencies**: None
- **Tasks**:
  - [ ] Optimize magic wand algorithm (vectorized)
  - [ ] Implement Numba JIT for selection operations
  - [ ] Cache selection masks efficiently
  - [ ] Multi-threaded selection processing
  - [ ] Progress reporting for large selections

---

## ⭐ TIER 4 — Harder, Long-Term, Polishing Features

**Priority Order**: Implement after Tier 3 completion

### 20. Unified UI Theme (Dark/Light + SVG Icons)
- **File**: `Config/ThemeManager.py`, `UI/*.py`
- **Status**: 🟡 Partially Implemented (basic theming exists)
- **Impact**: ⭐⭐⭐⭐
- **Ease**: ⭐
- **Dependencies**: None
- **Tasks**:
  - [ ] Create comprehensive light theme
  - [ ] Improve dark theme consistency
  - [ ] Replace PNG icons with SVG icons
  - [ ] Icon color theming system
  - [ ] Theme preview in preferences
  - [ ] Custom theme creation support

### 21. Docking UI System
- **File**: `UI/DockManager.py` (new), `UI/MainWindow.py`
- **Status**: 🔴 Not Started
- **Impact**: ⭐⭐⭐⭐
- **Ease**: ⭐
- **Dependencies**: PySide6 QDockWidget or custom docking library
- **Tasks**:
  - [ ] Implement movable panels system
  - [ ] Save/restore workspace layouts
  - [ ] Panel grouping and tabbing
  - [ ] Floating panel support
  - [ ] Default workspace layouts

### 22. AI Everywhere (Multi-editor Integration)
- **File**: `Core/AI/` (new directory), existing `Editors/Image/2/core/ai_*.py`
- **Status**: 🟡 Partially Implemented (Image Editor AI dialog exists)
- **Impact**: ⭐⭐⭐⭐⭐
- **Ease**: ⭐⭐
- **Dependencies**: Free AI service integration (currently blocked)
- **Tasks**:
  - [ ] AI animation assist (sprite editor)
  - [ ] AI room layout suggestions (room editor)
  - [ ] AI shader/material help (model editor)
  - [ ] AI sound cleanup (sound editor)
  - [ ] Unified AI dialog system
  - [ ] AI service abstraction layer

### 23. Delta Compression for Large Edits
- **File**: `Editors/Image/2/core/history.py` (extends Task 3)
- **Status**: 🔴 Not Started
- **Impact**: ⭐⭐⭐⭐
- **Ease**: ⭐⭐
- **Dependencies**: Delta-Based Undo/Redo (Task 3)
- **Tasks**:
  - [ ] Implement patch storage system
  - [ ] Compress patches efficiently
  - [ ] Apply patches incrementally
  - [ ] Memory usage optimization

### 24. Dedicated Runtime Preview Panel
- **File**: `UI/RuntimePreviewPanel.py` (new)
- **Status**: 🔴 Not Started
- **Impact**: ⭐⭐⭐
- **Ease**: ⭐⭐
- **Dependencies**: Runtime Engine Architecture (Task 16)
- **Tasks**:
  - [ ] Create in-IDE preview panel
  - [ ] Embed game viewport
  - [ ] Debug overlay (FPS, object counts, etc.)
  - [ ] Input forwarding to preview
  - [ ] Preview controls (play, pause, step)

---

## ⭐ TIER 5 — Advanced Professional Features

**Priority Order**: Implement as needed for professional features

### 25. ECS Architecture (Optional)
- **File**: `Core/Runtime/ECS/` (new directory)
- **Status**: 🔴 Not Started
- **Impact**: ⭐⭐⭐⭐
- **Ease**: ⭐
- **Dependencies**: Runtime Engine Architecture (Task 16)
- **Tasks**:
  - [ ] Design ECS component system
  - [ ] Implement entity manager
  - [ ] Implement component storage
  - [ ] Implement system processing
  - [ ] Migration from object-based to ECS

### 26. GPU-Accelerated Effects (GLSL Filters)
- **File**: `Core/Rendering/Effects/` (new directory)
- **Status**: 🔴 Not Started
- **Impact**: ⭐⭐⭐⭐
- **Ease**: ⭐
- **Dependencies**: Foundation (Shared PyOpenGL Runtime)
- **Tasks**:
  - [ ] Implement GLSL blur shader
  - [ ] Implement GLSL glow shader
  - [ ] Implement color grading shader
  - [ ] Implement outline shader
  - [ ] Effect chain system
  - [ ] Real-time preview of GPU effects

### 27. In-game Debug Console & REPL
- **File**: `Core/Runtime/DebugConsole.py` (new)
- **Status**: 🔴 Not Started
- **Impact**: ⭐⭐⭐⭐⭐
- **Ease**: ⭐⭐ (but specialized)
- **Dependencies**: Runtime Engine Architecture (Task 16)
- **Tasks**:
  - [ ] Implement debug console overlay
  - [ ] REPL for live Python execution
  - [ ] Object inspection commands
  - [ ] Variable modification commands
  - [ ] Command history
  - [ ] Auto-completion

### 28. Auto Test Runner & Crash Reporting
- **File**: `Core/Testing/` (new directory)
- **Status**: 🔴 Not Started
- **Impact**: ⭐⭐⭐
- **Ease**: ⭐⭐
- **Dependencies**: None
- **Tasks**:
  - [ ] Implement test discovery system
  - [ ] Automated test execution
  - [ ] Crash report generation
  - [ ] Error telemetry (optional, user consent)
  - [ ] Test result reporting

---

## 🎯 Implementation Priority Summary

### 🏆 MUST-DO FIRST (Highest Value + Easiest)
1. **Foundation**: Shared PyOpenGL Runtime Architecture ⚠️ CRITICAL
2. **Tier 1, Task 1**: GPU Canvas (depends on Foundation)
3. **Tier 1, Task 2**: Dirty Rectangle Updates (depends on GPU Canvas)
4. **Tier 1, Task 3**: Delta Undo (independent)
5. **Tier 1, Task 4**: Remove ModernGL (depends on Foundation)
6. **Tier 1, Task 5**: Background Task Queue (independent)
7. **Tier 1, Task 6**: Lazy Loading (independent)
8. **Tier 1, Task 7**: Session Cache (independent)

### 🏆 NEXT (Transforms PyGenesis into a Real Engine)
1. **Tier 2, Task 16**: Runtime Engine Architecture (required for Run/Build)
2. **Tier 2, Task 8**: Run Game (F5) (depends on Runtime Engine)
3. **Tier 2, Task 9**: Build EXE (depends on Runtime Engine)
4. **Tier 3, Task 14**: Object Editor (depends on Runtime Engine)
5. **Tier 3, Task 15**: Room Editor 2.0 (depends on Runtime Engine + Viewport_3D)
6. **Tier 2, Task 10**: Resource Inspector (independent)
7. **Tier 2, Task 11**: Unified BaseEditor (independent)

### 🏆 THEN (Polish & Excellence)
1. **Tier 3, Task 17**: Script Language (PGSL)
2. **Tier 3, Task 18**: Mipmapped Zoom
3. **Tier 3, Task 19**: Fast Selection Tools
4. **Tier 2, Task 12**: Tile-Based Effects
5. **Tier 4, Task 20**: Unified UI Theme
6. **Tier 4, Task 21**: Docking System
7. **Tier 4, Task 22**: Full AI Integration
8. **Tier 4, Task 23**: Delta Compression
9. **Tier 4, Task 24**: Runtime Preview Panel

### 🏆 LATER (Advanced Features)
- Tier 5 tasks can be implemented as needed for professional features

---

## 📊 Expected Quality Improvements

### Current State: **6.9/10**
- Functional IDE with good editor capabilities
- Some performance issues with large images
- Missing runtime/game building capabilities
- Inconsistent rendering backends

### After Tier 1: **8.7/10**
- High-performance GPU-accelerated rendering
- Responsive UI with background processing
- Efficient memory usage
- Consistent, stable rendering system

### After Tier 2: **9.2/10**
- Complete game development workflow
- Run and build capabilities
- Professional resource management
- Consistent editor architecture

### After Tier 3: **9.5/10**
- Full-featured game engine
- Beginner-friendly scripting
- Professional room/object editing
- Optimized performance across the board

### Target: **9.5+ / 10**
- Comparable to Aseprite for 2D editing
- Comparable to GameMaker Studio for object event logic
- Comparable to Unity/Godot for room/scene editing
- Comparable to Krita/Photoshop for sprite responsiveness

---

## 📝 Notes

- All tasks should be implemented one at a time with testing between steps
- Maintain restore point list for undoing changes if needed
- Follow existing code patterns and architecture decisions
- Use Formatting_Like_This for new settings (capitalized, not all caps)
- Prefer refactoring existing code over creating new workarounds
- Keep code uniform and avoid ad-hoc methods

---

**Last Updated**: 2025-11-25
**Version**: 1.0

