# Codebase Summary: `Temp`

## Overview

- Root path: `C:\Design\Python\IDE Development\Newest PyGenesis\Original\Old Version\Temp`
- Total files: **376**
- Approx total size: **29.0 MB**

### Top-level directories

- `.nova/`
- `Analysis/`
- `Config/`
- `Core/`
- `Documentation/`
- `Editors/`
- `Tools/`
- `UI/`
- `test_scripts/`

### File types

- `.py`: 260
- `.json`: 43
- `.md`: 36
- `.pgsl`: 27
- `.object`: 7
- `.txt`: 2
- `.npz`: 1

## Project tree (truncated)

- **Temp/**
  - **.nova/**
    - **conversations/**
      - 8bda352e-6bb7-45b6-a54a-6c96b18058c5.json
  - **Analysis/**
    - Definitions.md
    - Dependencies.md
    - Overview.md
    - UnusedCode.md
    - Workflow.md
  - **Config/**
    - __init__.py
    - CoreRequirements.json
    - InstalledPackagesCache.json
    - OptionalRequirements.json
    - PyPICache.json
    - Requirements.json
    - Settings.py
    - ThemeManager.py
  - **Core/**
    - **AI/**
      - **PyGenesisAssistant/**
    - **Code/**
      - **Base/**
      - **PGSL/**
      - **Shared/**
      - **Unified/**
    - **CodeSystem/**
      - __init__.py
      - ast.py
      - lexer.py
      - parser.py
      - syntax.py
    - **Rendering/**
      - __init__.py
      - BufferManager.py
      - Canvas_2D.py
      - OpenGLRuntime.py
      - ShaderManager.py
      - SuperShader_2D.py
      - TextureManager.py
    - **Services/**
      - __init__.py
      - async_editor_loader.py
      - async_project_loader.py
      - async_project_saver.py
      - file_service.py
      - incremental_resource_reloader.py
      - project_service.py
      - resource_service.py
      - script_checker.py
      - validation_service.py
    - __init__.py
    - Debug.py
    - DeletePyCache.py
    - EditorFactory.py
    - EditorInterface.py
    - EditorOptimizer.py
    - Events.py
    - ExtensionsManager.py
    - GameGenerator.py
    - ModulePreloader.py
    - PackageInstaller.py
    - PackageLoadThread.py
    - PackageSearchThread.py
    - ProjectIndexManager.py
    - ProjectManager.py
    - PyPILoadThread.py
    - ResourceManager.py
    - ThumbnailCache.py
    - UtilityOperations.py
    - VenvManager.py
      - ... (1 more)
  - **Documentation/**
    - **AI/**
      - **Nova/**
    - **Editors/**
      - **PGCE PyCode/**
      - **PGIE Piggie/**
      - **PGME Pigmie/**
      - **PGOE Pygo/**
      - **PGRE Pygress/**
    - **PyGenesis Plans/**
      - **Misc/**
      - **Roadmap/**
      - **Tutorials/**
      - Summary Of PyGenesis.md
  - **Editors/**
    - **BackgroundEditor/**
      - __init__.py
      - BackgroundEditor.py
    - **CodeEditor/**
      - __init__.py
      - pgsl_parser.py
      - pgsl_runtime.py
      - PGSLCodeEditor.py
      - ScriptEditor.py
    - **ImageEditor/**
      - **core/**
      - **ui/**
      - __init__.py
      - ImageEditor.py
    - **ModelEditor/**
      - **examples/**
      - __init__.py
      - ModelEditor.py
    - **ObjectEditor/**
      - **Core/**
      - **Services/**
      - **UI/**
      - __init__.py
      - object_editor.py
      - object_editor_menu.py
      - object_editor_ui.py
      - object_events_panel.py
      - object_properties_panel.py
      - sprite_browser_widget.py
    - **RoomEditor/**
      - **ui/**
      - __init__.py
      - RoomEditor.py
    - **Shared/**
      - __init__.py
      - BaseImageResourceEditor.py
      - IntegratedImageEditor.py
    - **SoundEditor/**
      - **core/**
      - __init__.py
      - SoundEditor.py
    - **SpriteEditor/**
      - **core/**
      - **services/**
      - **ui/**
      - **widgets/**
      - __init__.py
      - SpriteEditor.py
    - **TextureEditor/**
      - __init__.py
      - TextureEditor.py
    - __init__.py
  - **test_scripts/**
    - **Collision/**
      - test_object_collision.object
      - test_object_collision_collision.pgsl
      - test_object_collision_create.pgsl
    - **Collision Tests/**
      - **Object 1/**
      - **Object 2/**
    - **Instance Finding/**
      - test_object_instance_finding.object
      - test_object_instance_finding_create.pgsl
      - test_object_instance_finding_step.pgsl
    - **PGSL/**
      - test_object_pgsl_create.pgsl
      - test_object_pgsl_draw.pgsl
      - test_object_pgsl_step.pgsl
    - **Python/**
      - test_object_python_create.pgsl
      - test_object_python_draw.pgsl
      - test_object_python_step.pgsl
    - **Stress Tests/**
      - **Edge Cases/**
      - **Errors/**
      - **Nested/**
  - **Tools/**
    - **BackupManager/**
      - __init__.py
      - BackupManager.py
    - **ProjectMaintenance/**
      - __init__.py
    - **ScreenRecording/**
      - __init__.py
      - screen_recorder.py
    - **VenvManagement/**
      - **core_libs/**
      - **optional_libs/**
      - **store_cache/**
      - __init__.py
  - **UI/**
    - **CommonDialogs/**
      - BackupFolderDialog.py
      - ExtensionsDialog.py
      - PreferencesDialog.py
      - ResourceFolderDialog.py
      - RestoreDialog.py
    - **MainWindow/**
      - MainWindow.py
    - **Panels/**
      - __init__.py
    - **Widgets/**
      - LoadingWidget.py
      - ParallelThumbnailLoader.py
      - ResourceTree.py
      - TerminalWidget.py
      - ThumbnailLoader.py
    - __init__.py
  - check_dependencies.py
  - GenerateSummary.py
  - main.py
  - Plan.md
  - pyrightconfig.json
  - requirements.txt

## Key Python modules (largest by size)

### `Editors\ModelEditor\ModelEditor.py`
- Size: 590.2 KB (12074 lines approx)
- First meaningful line:
```
from PySide6.QtWidgets import (
```

### `Editors\ImageEditor\core\ui\main_window.py`
- Size: 282.0 KB (6495 lines approx)
- First meaningful line:
```
from PySide6.QtWidgets import QMainWindow, QWidget, QHBoxLayout, QVBoxLayout, QMenuBar, QFileDialog, QLabel, QPushButton, QSizePolicy, QSpacerItem, QDialog, QMessageBox
```

### `Editors\ImageEditor\core\ui\dialogs\effect_dialog.py`
- Size: 266.7 KB (5814 lines approx)
- Docstring:
```
Unified Effect Dialog for Image Editor
Extracted from dialogs.py
```

### `Editors\ImageEditor\core\ui\preview.py`
- Size: 140.7 KB (3160 lines approx)
- First meaningful line:
```
from PySide6.QtWidgets import QWidget, QSizePolicy
```

### `UI\CommonDialogs\PreferencesDialog.py`
- Size: 132.0 KB (2803 lines approx)
- Docstring:
```
Preferences Dialog for Python Game IDE
Centralized preferences for all editors and settings
```

### `Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py`
- Size: 131.9 KB (3406 lines approx)
- Docstring:
```
3D Model Viewer and Editor - SketchUp-like Application
A single-file 3D modeling application with real-time editing capabilities.
```

### `Editors\SoundEditor\SoundEditor.py`
- Size: 121.1 KB (2955 lines approx)
- Docstring:
```
Sound Editor for Python Game IDE
GameMaker 8-style sound editor with properties panel and preview box
PGSE "Pigsey" - PyGenesis Sound Editor
```

### `Editors\ImageEditor\core\ui\character_creator_dialog.py`
- Size: 102.8 KB (2208 lines approx)
- First meaningful line:
```
import sys
```

### `UI\Widgets\ResourceTree.py`
- Size: 96.8 KB (2217 lines approx)
- Docstring:
```
Resource Tree Widget for Python Game IDE
Displays project resources in a tree structure with drag and drop support
```

### `Core\ResourceManager.py`
- Size: 85.7 KB (1944 lines approx)
- Docstring:
```
Resource Manager for Python Game IDE
Handles resource creation, editing, and management
```

### `Editors\Shared\IntegratedImageEditor.py`
- Size: 82.6 KB (1755 lines approx)
- Docstring:
```
Integrated Image Editor for Python Game IDE
GameMaker 8-style sprite editor with properties panel and preview box
```

### `UI\MainWindow\MainWindow.py`
- Size: 81.6 KB (2002 lines approx)
- Docstring:
```
Main Window for Python Game IDE
GameMaker-style interface with resource tree and editors
```

### `Core\ProjectManager.py`
- Size: 79.5 KB (1533 lines approx)
- Docstring:
```
Project Manager for Python Game IDE
Handles project creation, loading, and management
```

### `Core\AI\PyGenesisAssistant\Nova\core\engines\research_engine.py`
- Size: 64.5 KB (1431 lines approx)
- Docstring:
```
Research Engine - Handles research queries using safe sites.
Fetches actual information from safe sites and returns it with citations.
```

### `Editors\SpriteEditor\SpriteEditor.py`
- Size: 63.9 KB (1439 lines approx)
- Docstring:
```
Sprite Editor for Python Game IDE
GameMaker 8-style sprite editor with properties panel and preview box
```

### `Editors\ImageEditor\core\ui\timeline.py`
- Size: 61.5 KB (1446 lines approx)
- First meaningful line:
```
from PySide6.QtWidgets import (QWidget, QHBoxLayout, QVBoxLayout, QPushButton,
```

### `Editors\RoomEditor\RoomEditor.py`
- Size: 60.7 KB (1614 lines approx)
- Docstring:
```
Room Editor for Python Game IDE (PyGenesis)
2D-only for now, designed to integrate with shared 2D OpenGL runtime later.

Features:
- GameMaker-style room editor with:
  - Left tabbed panel: Objects / Background / Settings / Views / Instance Order
  - Central 2D canvas with pan + zoom, grid + snap...
```

### `Core\AI\PyGenesisAssistant\CodeAnalyser.py`
- Size: 57.1 KB (1281 lines approx)
- Docstring:
```
GUI Python Code Analyzer - Enhanced
Enhanced version with collapsible sections, summaries, color coding, and better reporting
```

### `Editors\ObjectEditor\object_editor.py`
- Size: 55.5 KB (1307 lines approx)
- First meaningful line:
```
======================================================================
```

### `Editors\TextureEditor\TextureEditor.py`
- Size: 52.5 KB (1199 lines approx)
- Docstring:
```
Texture Editor for Python Game IDE
GameMaker 8-style texture editor with properties panel and preview box
```

### `Core\AI\PyGenesisAssistant\Nova\core\intent_router.py`
- Size: 50.3 KB (1108 lines approx)
- Docstring:
```
Intent Router - Classifies user input into intent types.
Uses SLM (Small Language Model) with keyword-based fallback.
Implements 4-layer Intent Resolution Stack for deterministic disambiguation.
```

### `Core\AI\PyGenesisAssistant\UnifiedCodeAnalyzer.py`
- Size: 50.2 KB (1231 lines approx)
- Docstring:
```
Unified Code Analyzer - High Performance
Combines dependency analysis and code analysis with:
- Parallel processing for thousands of files
- Interactive file tree
- Cached AST parsing
- Incremental analysis
- Click-to-analyze individual files
```

### `Editors\RoomEditor\ui\main_window.py`
- Size: 45.7 KB (1208 lines approx)
- Docstring:
```
Room Editor Main Window
GameMaker-style room editor with tabbed interface for Objects, Background, Settings, Views, and Instance Order.
```

### `Editors\SoundEditor\core\WaveForge.py`
- Size: 43.0 KB (1225 lines approx)
- Docstring:
```
WaveForge - Audacity-style Waveform Editor
Advanced multi-track audio editing with waveform visualization
```

### `Editors\ImageEditor\core\services\effect_processor.py`
- Size: 42.6 KB (978 lines approx)
- Docstring:
```
Effect Processor Service
Handles all image effect processing operations.
Extracted from main_window.py for better separation of concerns.

This service processes image effects without UI dependencies.
Methods that need state/UI access should remain in main_window and call this service.
```

### `UI\CommonDialogs\ExtensionsDialog.py`
- Size: 41.9 KB (1020 lines approx)
- Docstring:
```
Extensions Manager Dialog for PyGenesis IDE
Installed (Core/Optional/Other) + Store tabs.

This version:
- Uses your existing architecture and threads.
- Integrates with the updated ExtensionsManager (with get_outdated_packages).
- Adds a "Check Updates" button to highlight outdated packages in t...
```

### `Core\AI\PyGenesisAssistant\DependencyAnalyser.py`
- Size: 41.6 KB (937 lines approx)
- Docstring:
```
Python Code Flow Visualizer
Analyzes Python files to show:
- What functions/classes are created in each script
- What functions/classes are imported/called by each script  
- Visual workflow showing dependencies and usage patterns
```

### `Editors\ImageEditor\core\ui\panels\right_panel.py`
- Size: 41.6 KB (894 lines approx)
- First meaningful line:
```
from PySide6.QtWidgets import QFrame, QVBoxLayout, QLabel, QPushButton, QWidget, QHBoxLayout, QInputDialog, QSizePolicy, QLineEdit, QSlider, QScrollArea, QTabWidget, QColorDialog, QCheckBox, QHBoxL...
```

### `Editors\Shared\BaseImageResourceEditor.py`
- Size: 41.5 KB (962 lines approx)
- Docstring:
```
Base Image Resource Editor
Shared base class for SpriteEditor, TextureEditor, and BackgroundEditor
Eliminates code duplication by providing common functionality
```

### `Editors\ImageEditor\core\core\selection_manager.py`
- Size: 39.8 KB (1005 lines approx)
- First meaningful line:
```
from PySide6.QtCore import Qt, QRectF
```

### `Editors\ImageEditor\core\ui\panels\left_panel.py`
- Size: 39.7 KB (950 lines approx)
- First meaningful line:
```
from PySide6.QtWidgets import QFrame, QVBoxLayout, QLabel, QWidget, QPushButton, QHBoxLayout, QColorDialog, QCheckBox, QToolButton, QSizePolicy, QGridLayout, QLineEdit, QSlider, QScrollArea
```

### `Core\Code\Unified\unified_code_editor.py`
- Size: 39.2 KB (989 lines approx)
- Docstring:
```
Unified Code Editor
Shared code editor for all PyGenesis editors (Script, Object, Shader, Particle, etc.)

Phase 1: Editor Shell + Mode Management (No Execution)
- UnifiedCodeEditor widget
- Mode toggle (Simple / Advanced)
- Syntax highlighter switching
- Diagnostics panel (static/stub)
- Basic A...
```

### `Editors\ImageEditor\core\ui\ai_dialogs.py`
- Size: 39.0 KB (996 lines approx)
- Docstring:
```
AI Generation Dialogs for Gemini Integration
Includes base image generation, animation creation, and JSON editing
```

### `Editors\ImageEditor\core\core\texture_utils.py`
- Size: 37.2 KB (910 lines approx)
- First meaningful line:
```
import numpy as np
```

### `Editors\ImageEditor\core\ui\texture_atlas_dialog.py`
- Size: 36.3 KB (918 lines approx)
- First meaningful line:
```
from PySide6.QtWidgets import (
```

### `Editors\ImageEditor\core\ui\nine_slice_importer.py`
- Size: 35.8 KB (847 lines approx)
- Docstring:
```
Sprite Sheet Importer Dialog

Industry-standard sprite sheet importer with:
- Background removal with tolerance and live preview
- Automatic sprite detection and cropping
- Bounding box visualization
- Multiple output modes (sprite sheet or individual frames)
```

### `Editors\ImageEditor\core\ui\dialogs\preferences_dialog.py`
- Size: 34.2 KB (708 lines approx)
- Docstring:
```
Preferences Dialog for Image Editor
Extracted from dialogs.py
```

### `Core\AI\PyGenesisAssistant\Nova\core\workflow.py`
- Size: 33.6 KB (758 lines approx)
- Docstring:
```
Core Workflow Pipeline - The main processing pipeline for Nova.
Handles the complete order of operations for user interactions.

Enhanced with UserMode, ResponseStrategy, and ConversationState
for smarter, more natural conversations.
```

### `Editors\ImageEditor\core\ui\sprite_sheet_importer.py`
- Size: 33.2 KB (811 lines approx)
- Docstring:
```
Sprite Sheet Importer Dialog

Provides UI for importing sprite sheets with auto-slicing, background removal,
and frame centering.
```

### `Core\AI\PyGenesisAssistant\Nova\core\executors\resource_operation_executor.py`
- Size: 32.6 KB (724 lines approx)
- Docstring:
```
Resource Operation Executor - Handles resource and folder operations via natural language.
```

## Other important text files

- `Tools\VenvManagement\store_cache\pypi_cache.json` (16766.3 KB): {
- `Core\AI\PyGenesisAssistant\Nova\core\slm\training_data.json` (3026.4 KB): [
- `Core\AI\PyGenesisAssistant\Nova\core\slm\models\neural_model.json` (2994.9 KB): {"W1": [[0.08955202642526919, 0.019695223096056678, 0.08183427015825791, -0.007872033020562141, -0.06847838490563428, -0.04544703897049957, -0.04592659199082097, 0.03405520059318697, -0.00397556317...
- `Analysis\Workflow.md` (617.4 KB): 🔄 COMPLETE WORKFLOW
- `Config\PyPICache.json` (414.6 KB): {
- `Analysis\Dependencies.md` (182.1 KB): 🔗 DEPENDENCIES
- `Analysis\Definitions.md` (180.5 KB): 🏗️ ALL DEFINITIONS
- `Analysis\UnusedCode.md` (83.4 KB): 🗑️ UNUSED CODE
- `Plan.md` (28.0 KB): PyGenesis & Nova Development Plan
- `Documentation\PyGenesis Plans\Tutorials\Tutorials.md` (25.8 KB): How To Add Effects
- `Documentation\PyGenesis Plans\Roadmap\TODO_ROADMAP.md` (22.7 KB): PyGenesis IDE — Comprehensive Development Roadmap
- `Documentation\PyGenesis Plans\Roadmap\OutstandingActions.md` (21.1 KB): Outstanding Actions from PyGenesis Roadmap
- `Editors\ImageEditor\core\core\ai_tool_knowledge.json` (18.4 KB): {
- `Documentation\PyGenesis Plans\Misc\CODEBASE_SUMMARY.md` (17.7 KB): Codebase Summary: `Temp`
- `Documentation\AI\Nova\UNIFIED_EDITOR_IMPLEMENTATION_SUMMARY.md` (17.0 KB): UnifiedCodeEditor Implementation Summary
- `Documentation\AI\Nova\Architectural_Alignment_Analysis.md` (15.2 KB): Nova Architectural Alignment Analysis
- `Documentation\AI\Nova\How_Nova_Works.md` (13.2 KB): How Nova Works - Complete Guide with Examples
- `Core\AI\PyGenesisAssistant\Nova\data\PyGenesis_KnowledgeBase.md` (12.1 KB): PyGenesis Knowledge Base
- `Documentation\PyGenesis Plans\Roadmap\Plan.md` (11.9 KB): PyGenesis IDE — Development Plan
- `Documentation\PyGenesis Plans\Roadmap\IMAGE_EDITOR_PERFORMANCE_ANALYSIS.md` (10.6 KB): Image Editor Performance Analysis - Critical Bottlenecks
- `Documentation\Editors\PGME Pigmie\Model Editor.md` (9.0 KB): Model Editor (PGME — Pigme) — Documentation
- `Documentation\AI\Nova\SCRIPT_EDITOR_TESTING_GUIDE.md` (7.5 KB): Script Editor Testing Guide
- `Documentation\Editors\PGRE Pygress\Room Editor.md` (7.3 KB): Room Editor (PGRE) — Complete Documentation
- `Core\AI\PyGenesisAssistant\Nova\core\slm\intent_templates.json` (7.3 KB): {
- `Documentation\AI\Nova\NEXT_STEPS_AND_MIGRATION_PLAN.md` (7.2 KB): Next Steps and Migration Plan
- `Documentation\Editors\PGIE Piggie\Sprite Editor.md` (6.9 KB): Sprite Editor — Complete Documentation
- `Documentation\PyGenesis Plans\Summary Of PyGenesis.md` (6.8 KB): PyGenesis IDE — Project Structure Summary
- `Core\AI\PyGenesisAssistant\Nova\themes.json` (6.7 KB): {
- `Documentation\Editors\PGOE Pygo\Object Editor.md` (6.5 KB): Object Editor (PGOE) — Planned Documentation
- `Core\AI\PyGenesisAssistant\data\conversations\91c46c3e-bbb2-443c-ab3a-22740e8a392b.json` (6.4 KB): {
- `Core\AI\PyGenesisAssistant\Nova\core\slm\Test\intent_templates.json` (5.8 KB): {
- `Documentation\Editors\PGCE PyCode\Code Editor.md` (5.6 KB): Code Editor (PGCE) — Planned Documentation
- `Config\OptionalRequirements.json` (5.4 KB): {
- `Documentation\AI\Nova\OBJECT_EDITOR_INTEGRATION.md` (5.1 KB): Object Editor Integration - Complete ✅
- `Documentation\PyGenesis Plans\Roadmap\PERFORMANCE_PROGRESS.md` (5.1 KB): Image Editor Performance Optimization - Progress Report
- `Core\AI\PyGenesisAssistant\Nova\core\slm\IMPROVEMENTS_SUMMARY.md` (5.1 KB): Nova Neural Network Improvements Summary
- `Documentation\Editors\PGIE Piggie\Summary Of Image Editor.md` (4.6 KB): Image Editor (PGIE) — Summary
- `Core\AI\PyGenesisAssistant\data\conversations\67f65abb-591e-422a-b468-e6236fe88d24.json` (4.2 KB): {
- `Documentation\AI\Nova\OUTSTANDING_WORK.md` (4.2 KB): Outstanding Work - Code Editor Integration
- `Documentation\AI\Nova\NEXT_PHASE_STATUS.md` (3.8 KB): Next Phase Status - Code Editor Integration

## Binary assets (images, binaries, etc.)

- `Core\AI\PyGenesisAssistant\Nova\core\slm\models\intent_model.npz` (8.3 KB)
