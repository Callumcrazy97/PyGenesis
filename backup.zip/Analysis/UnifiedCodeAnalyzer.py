#!/usr/bin/env python3
"""
Unified Code Analyzer - High Performance
Combines dependency analysis and code analysis with:
- Parallel processing for thousands of files
- Interactive file tree
- Cached AST parsing
- Incremental analysis
- Click-to-analyze individual files
"""

import os
import ast
import sys
import tkinter as tk
from tkinter import ttk, filedialog, messagebox, scrolledtext
from pathlib import Path
from typing import Dict, List, Set, Tuple, Optional, Any
from collections import defaultdict
import threading
import multiprocessing
from concurrent.futures import ProcessPoolExecutor, ThreadPoolExecutor, as_completed
import json
import pickle
import hashlib
import time
from functools import lru_cache

# Performance constants
MAX_WORKERS = max(1, multiprocessing.cpu_count() - 1)
CACHE_DIR = Path.home() / ".pygenesis_analyzer_cache"
CACHE_EXPIRY = 3600  # 1 hour


class ASTCache:
    """Cache for AST parsing results"""
    
    def __init__(self, cache_dir: Path = CACHE_DIR):
        self.cache_dir = cache_dir
        self.cache_dir.mkdir(exist_ok=True)
        self.memory_cache = {}
        self.cache_hits = 0
        self.cache_misses = 0
    
    def _get_cache_key(self, file_path: Path) -> str:
        """Generate cache key from file path and modification time"""
        try:
            mtime = file_path.stat().st_mtime
            return hashlib.md5(f"{file_path}_{mtime}".encode()).hexdigest()
        except:
            return hashlib.md5(str(file_path).encode()).hexdigest()
    
    def get(self, file_path: Path) -> Optional[ast.AST]:
        """Get cached AST"""
        cache_key = self._get_cache_key(file_path)
        
        # Check memory cache first
        if cache_key in self.memory_cache:
            self.cache_hits += 1
            return self.memory_cache[cache_key]
        
        # Check disk cache
        cache_file = self.cache_dir / f"{cache_key}.pkl"
        if cache_file.exists():
            try:
                with open(cache_file, 'rb') as f:
                    cached_data = pickle.load(f)
                    # Check if cache is still valid
                    if time.time() - cached_data['timestamp'] < CACHE_EXPIRY:
                        self.memory_cache[cache_key] = cached_data['tree']
                        self.cache_hits += 1
                        return cached_data['tree']
            except:
                pass
        
        self.cache_misses += 1
        return None
    
    def set(self, file_path: Path, tree: ast.AST):
        """Cache AST"""
        cache_key = self._get_cache_key(file_path)
        
        # Store in memory
        self.memory_cache[cache_key] = tree
        
        # Store on disk
        cache_file = self.cache_dir / f"{cache_key}.pkl"
        try:
            with open(cache_file, 'wb') as f:
                pickle.dump({
                    'tree': tree,
                    'timestamp': time.time(),
                    'file': str(file_path)
                }, f)
        except:
            pass
    
    def clear(self):
        """Clear all caches"""
        self.memory_cache.clear()
        try:
            for cache_file in self.cache_dir.glob("*.pkl"):
                cache_file.unlink()
        except:
            pass
    
    def get_stats(self) -> Dict:
        """Get cache statistics"""
        total = self.cache_hits + self.cache_misses
        hit_rate = (self.cache_hits / total * 100) if total > 0 else 0
        return {
            'hits': self.cache_hits,
            'misses': self.cache_misses,
            'hit_rate': f"{hit_rate:.1f}%",
            'memory_size': len(self.memory_cache)
        }


def parse_file_ast(file_path: Path) -> Tuple[Path, Optional[ast.AST], Optional[str]]:
    """Parse a single file's AST (for parallel processing)"""
    try:
        with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read()
        
        tree = ast.parse(content, filename=str(file_path))
        return (file_path, tree, None)
    except SyntaxError as e:
        return (file_path, None, f"Syntax error: {e.msg} (line {e.lineno})")
    except Exception as e:
        return (file_path, None, f"Error: {str(e)}")


def extract_definitions_fast(tree: ast.AST, file_path: Path) -> Dict:
    """Fast definition extraction using optimized AST traversal"""
    definitions = {
        'functions': {},
        'classes': {},
        'variables': {},
        'imports': {}
    }
    
    # Use visit pattern for better performance
    class DefinitionVisitor(ast.NodeVisitor):
        def __init__(self, defs):
            self.defs = defs
        
        def visit_FunctionDef(self, node):
            self.defs['functions'][node.name] = {
                'line': node.lineno,
                'args': [arg.arg for arg in node.args.args],
                'is_async': isinstance(node, ast.AsyncFunctionDef)
            }
            self.generic_visit(node)
        
        def visit_ClassDef(self, node):
            methods = []
            for item in node.body:
                if isinstance(item, ast.FunctionDef):
                    methods.append(item.name)
            
            self.defs['classes'][node.name] = {
                'line': node.lineno,
                'methods': methods,
                'bases': [self._get_name(base) for base in node.bases]
            }
            self.generic_visit(node)
        
        def visit_Import(self, node):
            for alias in node.names:
                self.defs['imports'][alias.name] = {
                    'type': 'import',
                    'alias': alias.asname or alias.name,
                    'line': node.lineno
                }
        
        def visit_ImportFrom(self, node):
            module = node.module or ''
            for alias in node.names:
                key = f"{module}.{alias.name}" if module else alias.name
                self.defs['imports'][key] = {
                    'type': 'from',
                    'module': module,
                    'name': alias.name,
                    'alias': alias.asname or alias.name,
                    'line': node.lineno,
                    'level': node.level
                }
        
        def _get_name(self, node):
            if isinstance(node, ast.Name):
                return node.id
            elif isinstance(node, ast.Attribute):
                return f"{self._get_name(node.value)}.{node.attr}"
            return str(node)
    
    visitor = DefinitionVisitor(definitions)
    visitor.visit(tree)
    
    return definitions


def extract_calls_fast(tree: ast.AST, file_path: Path) -> List[Dict]:
    """Fast function call extraction"""
    calls = []
    
    class CallVisitor(ast.NodeVisitor):
        def visit_Call(self, node):
            func_name = self._get_function_name(node.func)
            if func_name:
                calls.append({
                    'function': func_name,
                    'line': node.lineno
                })
            self.generic_visit(node)
        
        def _get_function_name(self, func_node):
            if isinstance(func_node, ast.Name):
                return func_node.id
            elif isinstance(func_node, ast.Attribute):
                if isinstance(func_node.value, ast.Name):
                    return f"{func_node.value.id}.{func_node.attr}"
                return func_node.attr
            return None
    
    visitor = CallVisitor()
    visitor.visit(tree)
    
    return calls


class UnifiedCodeAnalyzer:
    """High-performance unified code analyzer"""
    
    def __init__(self, root_path: Path, progress_callback=None):
        self.root_path = root_path
        self.progress_callback = progress_callback
        self.ast_cache = ASTCache()
        
        # Analysis results
        self.file_trees = {}  # file_path -> AST
        self.file_definitions = {}  # file_path -> definitions dict
        self.file_calls = {}  # file_path -> calls list
        self.file_errors = {}  # file_path -> error message
        
        # Aggregated data
        self.all_functions = {}  # func_name -> {file, line, args}
        self.all_classes = {}  # class_name -> {file, line, methods}
        self.all_imports = {}  # import_name -> {file, type, ...}
        self.all_calls = []  # List of all function calls
    
    def analyze_files(self, file_paths: List[Path], use_cache: bool = True):
        """Analyze multiple files in parallel"""
        total = len(file_paths)
        
        # Filter out files that are already cached
        files_to_parse = []
        if use_cache:
            for file_path in file_paths:
                cached_tree = self.ast_cache.get(file_path)
                if cached_tree:
                    self.file_trees[file_path] = cached_tree
                else:
                    files_to_parse.append(file_path)
        else:
            files_to_parse = file_paths
        
        # Parse files in parallel
        if files_to_parse:
            self._update_progress(f"Parsing {len(files_to_parse)} files...")
            
            with ProcessPoolExecutor(max_workers=MAX_WORKERS) as executor:
                future_to_file = {
                    executor.submit(parse_file_ast, file_path): file_path 
                    for file_path in files_to_parse
                }
                
                completed = 0
                for future in as_completed(future_to_file):
                    file_path, tree, error = future.result()
                    completed += 1
                    
                    if error:
                        self.file_errors[file_path] = error
                    elif tree:
                        self.file_trees[file_path] = tree
                        self.ast_cache.set(file_path, tree)
                    
                    if completed % 10 == 0:
                        self._update_progress(
                            f"Parsed {completed}/{len(files_to_parse)} files "
                            f"({completed/len(files_to_parse)*100:.1f}%)"
                        )
        
        # Extract definitions and calls in parallel
        self._update_progress("Extracting definitions and calls...")
        
        with ThreadPoolExecutor(max_workers=MAX_WORKERS * 2) as executor:
            # Submit tasks with file_path tracking
            future_to_file = {}
            for file_path, tree in self.file_trees.items():
                future_to_file[executor.submit(extract_definitions_fast, tree, file_path)] = (file_path, 'defs')
                future_to_file[executor.submit(extract_calls_fast, tree, file_path)] = (file_path, 'calls')
            
            completed = 0
            total = len(future_to_file)
            for future in as_completed(future_to_file):
                file_path, result_type = future_to_file[future]
                try:
                    result = future.result()
                    completed += 1
                    
                    if result_type == 'defs' and isinstance(result, dict):
                        self.file_definitions[file_path] = result
                    elif result_type == 'calls' and isinstance(result, list):
                        self.file_calls[file_path] = result
                except Exception as e:
                    print(f"Error processing {file_path}: {e}")
                    completed += 1
                
                if completed % 20 == 0:
                    self._update_progress(f"Processed {completed}/{total} items ({completed/total*100:.1f}%)")
        
        # Aggregate results
        self._update_progress("Aggregating results...")
        self._aggregate_results()
        
        self._update_progress("Analysis complete")
    
    def _aggregate_results(self):
        """Aggregate results from all files with error handling"""
        try:
            for file_path, definitions in self.file_definitions.items():
                if not definitions or not isinstance(definitions, dict):
                    continue
                
                # Functions
                functions = definitions.get('functions', {})
                if isinstance(functions, dict):
                    for func_name, func_data in functions.items():
                        if not isinstance(func_data, dict):
                            continue
                        # Handle duplicate function names by appending file info
                        if func_name in self.all_functions:
                            # Keep the first one, or create a list
                            if not isinstance(self.all_functions[func_name], list):
                                self.all_functions[func_name] = [self.all_functions[func_name]]
                            self.all_functions[func_name].append({
                                'file': file_path,
                                'line': func_data.get('line', 0),
                                'args': func_data.get('args', [])
                            })
                        else:
                            self.all_functions[func_name] = {
                                'file': file_path,
                                'line': func_data.get('line', 0),
                                'args': func_data.get('args', [])
                            }
                
                # Classes
                classes = definitions.get('classes', {})
                if isinstance(classes, dict):
                    for class_name, class_data in classes.items():
                        if not isinstance(class_data, dict):
                            continue
                        # Handle duplicate class names
                        if class_name in self.all_classes:
                            if not isinstance(self.all_classes[class_name], list):
                                self.all_classes[class_name] = [self.all_classes[class_name]]
                            self.all_classes[class_name].append({
                                'file': file_path,
                                'line': class_data.get('line', 0),
                                'methods': class_data.get('methods', [])
                            })
                        else:
                            self.all_classes[class_name] = {
                                'file': file_path,
                                'line': class_data.get('line', 0),
                                'methods': class_data.get('methods', [])
                            }
                
                # Imports
                imports = definitions.get('imports', {})
                if isinstance(imports, dict):
                    for import_name, import_data in imports.items():
                        if not isinstance(import_data, dict):
                            continue
                        if import_name not in self.all_imports:
                            self.all_imports[import_name] = []
                        # Safely copy import data
                        import_entry = {'file': file_path}
                        for key, value in import_data.items():
                            import_entry[key] = value
                        self.all_imports[import_name].append(import_entry)
            
            # Calls
            for file_path, calls in self.file_calls.items():
                if not isinstance(calls, list):
                    continue
                for call in calls:
                    if not isinstance(call, dict):
                        continue
                    call_entry = {'file': file_path}
                    for key, value in call.items():
                        call_entry[key] = value
                    self.all_calls.append(call_entry)
        
        except Exception as e:
            # Log error but don't crash
            print(f"Error aggregating results: {e}")
            import traceback
            traceback.print_exc()
    
    def _update_progress(self, message: str):
        """Update progress"""
        if self.progress_callback:
            self.progress_callback(message)
    
    def get_file_workflow(self, file_path: Path) -> Dict:
        """Get workflow for a specific file"""
        definitions = self.file_definitions.get(file_path, {})
        calls = self.file_calls.get(file_path, [])
        
        return {
            'file': file_path,
            'functions': definitions.get('functions', {}),
            'classes': definitions.get('classes', {}),
            'calls': calls,
            'imports': definitions.get('imports', {})
        }
    
    def get_function_workflow(self, func_name: str) -> Optional[Dict]:
        """Get workflow for a specific function"""
        if func_name not in self.all_functions:
            return None
        
        func_data = self.all_functions[func_name]
        
        # Find callers
        callers = []
        for call in self.all_calls:
            if call['function'] == func_name:
                callers.append({
                    'file': call['file'],
                    'line': call['line']
                })
        
        return {
            'definition': func_data,
            'called_by': callers
        }
    
    def get_unused_functions(self) -> List[str]:
        """Find unused functions"""
        called_functions = set()
        for call in self.all_calls:
            func_name = call.get('function', '')
            if func_name:
                # Extract base function name (handle method calls)
                base_name = func_name.split('.')[-1]
                called_functions.add(base_name)
                called_functions.add(func_name)
        
        defined_functions = set(self.all_functions.keys())
        return sorted(defined_functions - called_functions)


class UnifiedAnalyzerGUI:
    """Unified GUI for code and dependency analysis"""
    
    def __init__(self, root):
        self.root = root
        self.root.title("Unified Code Analyzer - High Performance")
        self.root.geometry("1600x1000")
        
        # Analysis data
        self.analyzer = None
        self.selected_files = []
        self.analysis_running = False
        self.all_python_files = []
        self.checkbox_states = {}  # Initialize checkbox states early
        
        # Create GUI
        self.create_widgets()
        
        # Initialize
        self.refresh_files()
    
    def create_widgets(self):
        """Create the GUI widgets"""
        # Main container
        main_frame = ttk.Frame(self.root, padding="10")
        main_frame.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        
        # Configure grid
        self.root.columnconfigure(0, weight=1)
        self.root.rowconfigure(0, weight=1)
        main_frame.columnconfigure(1, weight=1)
        main_frame.rowconfigure(1, weight=1)
        
        # Title
        title_label = ttk.Label(
            main_frame, 
            text="🔍 Unified Code Analyzer - High Performance", 
            font=('Arial', 16, 'bold')
        )
        title_label.grid(row=0, column=0, columnspan=3, pady=(0, 10))
        
        # Left panel: File tree
        left_panel = ttk.Frame(main_frame, width=300)
        left_panel.grid(row=1, column=0, sticky=(tk.W, tk.E, tk.N, tk.S), padx=(0, 10))
        left_panel.columnconfigure(0, weight=1)
        left_panel.rowconfigure(1, weight=1)
        
        ttk.Label(left_panel, text="📁 File Browser", font=('Arial', 12, 'bold')).grid(
            row=0, column=0, sticky=tk.W, pady=(0, 5)
        )
        
        # Folder selection
        folder_frame = ttk.Frame(left_panel)
        folder_frame.grid(row=1, column=0, sticky=(tk.W, tk.E), pady=(0, 5))
        folder_frame.columnconfigure(0, weight=1)
        
        self.folder_var = tk.StringVar(value=str(Path.cwd()))
        folder_entry = ttk.Entry(folder_frame, textvariable=self.folder_var, width=30)
        folder_entry.grid(row=0, column=0, sticky=(tk.W, tk.E), padx=(0, 5))
        ttk.Button(folder_frame, text="Browse", command=self.browse_folder).grid(row=0, column=1)
        
        # File tree with scrollbar
        tree_frame = ttk.Frame(left_panel)
        tree_frame.grid(row=2, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        tree_frame.columnconfigure(0, weight=1)
        tree_frame.rowconfigure(0, weight=1)
        
        # Treeview for file browser with checkbox column
        self.file_tree = ttk.Treeview(
            tree_frame, 
            columns=('checked',), 
            show='tree headings',
            height=30
        )
        self.file_tree.heading('#0', text='Files')
        self.file_tree.heading('checked', text='✓')
        self.file_tree.column('#0', width=250)
        self.file_tree.column('checked', width=30, anchor='center')
        
        tree_scrollbar = ttk.Scrollbar(tree_frame, orient=tk.VERTICAL, command=self.file_tree.yview)
        self.file_tree.configure(yscrollcommand=tree_scrollbar.set)
        
        self.file_tree.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        tree_scrollbar.grid(row=0, column=1, sticky=(tk.N, tk.S))
        
        # Bind events
        self.file_tree.bind('<Double-1>', self.on_file_double_click)
        self.file_tree.bind('<Button-1>', self.on_tree_click)  # Handle checkbox clicks
        self.file_tree.bind('<Button-3>', self.on_file_right_click)  # Right-click context menu
        
        # File tree controls
        tree_controls = ttk.Frame(left_panel)
        tree_controls.grid(row=3, column=0, sticky=(tk.W, tk.E), pady=(5, 0))
        
        ttk.Button(tree_controls, text="Refresh", command=self.refresh_files).grid(row=0, column=0, padx=(0, 5))
        ttk.Button(tree_controls, text="Check All", command=self.check_all).grid(row=0, column=1, padx=(0, 5))
        ttk.Button(tree_controls, text="Uncheck All", command=self.uncheck_all).grid(row=0, column=2, padx=(0, 5))
        
        ttk.Button(tree_controls, text="Analyze Selected", command=self.analyze_selected).grid(row=1, column=0, padx=(0, 5), pady=(5, 0))
        ttk.Button(tree_controls, text="Analyze All", command=self.analyze_all).grid(row=1, column=1, pady=(5, 0))
        
        # Right panel: Results
        right_panel = ttk.Frame(main_frame)
        right_panel.grid(row=1, column=1, sticky=(tk.W, tk.E, tk.N, tk.S))
        right_panel.columnconfigure(0, weight=1)
        right_panel.rowconfigure(1, weight=1)
        
        # Analysis controls
        controls_frame = ttk.Frame(right_panel)
        controls_frame.grid(row=0, column=0, sticky=(tk.W, tk.E), pady=(0, 10))
        controls_frame.columnconfigure(1, weight=1)
        
        self.analyze_button = ttk.Button(
            controls_frame, 
            text="🔄 Analyze", 
            command=self.analyze_all,
            style='Accent.TButton'
        )
        self.analyze_button.grid(row=0, column=0, padx=(0, 10))
        
        self.progress_var = tk.StringVar(value="Ready")
        self.progress_label = ttk.Label(controls_frame, textvariable=self.progress_var)
        self.progress_label.grid(row=0, column=1, sticky=tk.W)
        
        self.progress_bar = ttk.Progressbar(controls_frame, mode='indeterminate')
        self.progress_bar.grid(row=0, column=2, sticky=(tk.W, tk.E), padx=(10, 0))
        controls_frame.columnconfigure(2, weight=1)
        
        # Results notebook
        self.results_notebook = ttk.Notebook(right_panel)
        self.results_notebook.grid(row=1, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        
        # Create tabs
        self.create_overview_tab()
        self.create_definitions_tab()
        self.create_dependencies_tab()
        self.create_workflow_tab()
        self.create_unused_tab()
        self.create_file_analysis_tab()
    
    def create_overview_tab(self):
        """Create overview tab"""
        frame = ttk.Frame(self.results_notebook)
        self.results_notebook.add(frame, text="📊 Overview")
        
        self.overview_text = scrolledtext.ScrolledText(frame, wrap=tk.WORD, height=20)
        self.overview_text.pack(fill="both", expand=True, padx=10, pady=10)
        
        # Configure tags
        self.overview_text.tag_configure("header", font=('Arial', 12, 'bold'), foreground="darkblue")
        self.overview_text.tag_configure("stat", font=('Arial', 10, 'bold'), foreground="darkgreen")
    
    def create_definitions_tab(self):
        """Create definitions tab"""
        frame = ttk.Frame(self.results_notebook)
        self.results_notebook.add(frame, text="🏗️ Definitions")
        
        self.definitions_text = scrolledtext.ScrolledText(frame, wrap=tk.WORD, height=20)
        self.definitions_text.pack(fill="both", expand=True, padx=10, pady=10)
    
    def create_dependencies_tab(self):
        """Create dependencies tab"""
        frame = ttk.Frame(self.results_notebook)
        self.results_notebook.add(frame, text="🔗 Dependencies")
        
        self.dependencies_text = scrolledtext.ScrolledText(frame, wrap=tk.WORD, height=20)
        self.dependencies_text.pack(fill="both", expand=True, padx=10, pady=10)
    
    def create_workflow_tab(self):
        """Create workflow tab"""
        frame = ttk.Frame(self.results_notebook)
        self.results_notebook.add(frame, text="🔄 Workflow")
        
        # Filter controls
        controls = ttk.Frame(frame)
        controls.pack(fill="x", padx=10, pady=(10, 5))
        
        ttk.Label(controls, text="Filter:").pack(side="left", padx=(0, 5))
        self.workflow_filter_var = tk.StringVar()
        self.workflow_filter = ttk.Combobox(controls, textvariable=self.workflow_filter_var, width=30, state="readonly")
        self.workflow_filter.pack(side="left", padx=(0, 10))
        self.workflow_filter.bind('<<ComboboxSelected>>', self.update_workflow)
        
        ttk.Button(controls, text="Show All", command=self.show_all_workflow).pack(side="left")
        
        self.workflow_text = scrolledtext.ScrolledText(frame, wrap=tk.WORD, height=20)
        self.workflow_text.pack(fill="both", expand=True, padx=10, pady=(5, 10))
    
    def create_unused_tab(self):
        """Create unused code tab"""
        frame = ttk.Frame(self.results_notebook)
        self.results_notebook.add(frame, text="🗑️ Unused")
        
        self.unused_text = scrolledtext.ScrolledText(frame, wrap=tk.WORD, height=20)
        self.unused_text.pack(fill="both", expand=True, padx=10, pady=10)
    
    def create_file_analysis_tab(self):
        """Create file-specific analysis tab"""
        frame = ttk.Frame(self.results_notebook)
        self.results_notebook.add(frame, text="📄 File Analysis")
        
        self.file_analysis_text = scrolledtext.ScrolledText(frame, wrap=tk.WORD, height=20)
        self.file_analysis_text.pack(fill="both", expand=True, padx=10, pady=10)
    
    def browse_folder(self):
        """Browse for folder"""
        folder = filedialog.askdirectory(initialdir=self.folder_var.get())
        if folder:
            self.folder_var.set(folder)
            self.refresh_files()
    
    def refresh_files(self):
        """Refresh file tree"""
        self.file_tree.delete(*self.file_tree.get_children())
        self.all_python_files = []
        
        root_path = Path(self.folder_var.get())
        if not root_path.exists():
            return
        
        try:
            # Find all Python files
            for file_path in root_path.rglob('*.py'):
                if '__pycache__' not in str(file_path):
                    self.all_python_files.append(file_path)
            
            # Build tree structure efficiently
            tree_structure = {}  # path -> node_id
            
            for file_path in sorted(self.all_python_files):
                rel_path = file_path.relative_to(root_path)
                parts = rel_path.parts
                
                # Build directory nodes
                parent = ""
                current_path = root_path
                for i, part in enumerate(parts[:-1]):  # All but last (file)
                    current_path = current_path / part
                    path_key = str(current_path)
                    
                    if path_key not in tree_structure:
                        node_id = self.file_tree.insert(
                            parent, tk.END,
                            text=part,
                            values=('✓',),
                            tags=('dir',)
                        )
                        tree_structure[path_key] = node_id
                        self.checkbox_states[node_id] = True
                    else:
                        node_id = tree_structure[path_key]
                    
                    parent = node_id
                
                # Add file node with checkbox (checked by default)
                node_id = self.file_tree.insert(
                    parent, tk.END,
                    text=parts[-1],
                    values=('✓', str(file_path)),
                    tags=('file',)
                )
                self.checkbox_states[node_id] = True
            
            # Configure tags
            self.file_tree.tag_configure('file', foreground='blue')
            self.file_tree.tag_configure('dir', foreground='black')
            
            # Expand root level
            for child in self.file_tree.get_children():
                self.file_tree.item(child, open=False)
            
            self.progress_var.set(f"Found {len(self.all_python_files)} Python files")
            
        except Exception as e:
            messagebox.showerror("Error", f"Error refreshing files: {e}")
    
    def on_tree_click(self, event):
        """Handle clicks on tree (for checkboxes)"""
        region = self.file_tree.identify_region(event.x, event.y)
        if region == 'cell':
            column = self.file_tree.identify_column(event.x)
            item = self.file_tree.identify_row(event.y)
            
            if item and column == '#1':  # Checkbox column
                # Toggle checkbox
                current_state = self.checkbox_states.get(item, False)
                new_state = not current_state
                self.checkbox_states[item] = new_state
                
                # Update display
                values = list(self.file_tree.item(item, 'values'))
                if len(values) > 0:
                    values[0] = '✓' if new_state else ''
                    # Preserve file path if it exists
                    if len(values) > 1:
                        self.file_tree.item(item, values=(values[0], values[1]))
                    else:
                        self.file_tree.item(item, values=(values[0],))
                
                # If directory, toggle all children
                if self.file_tree.item(item, 'tags')[0] == 'dir':
                    self._toggle_children(item, new_state)
    
    def _toggle_children(self, parent_item, state: bool):
        """Toggle all children of a directory"""
        for child in self.file_tree.get_children(parent_item):
            self.checkbox_states[child] = state
            values = list(self.file_tree.item(child, 'values'))
            if len(values) > 0:
                values[0] = '✓' if state else ''
                if len(values) > 1:
                    self.file_tree.item(child, values=(values[0], values[1]))
                else:
                    self.file_tree.item(child, values=(values[0],))
            
            # Recursively toggle grandchildren
            if self.file_tree.get_children(child):
                self._toggle_children(child, state)
    
    def check_all(self):
        """Check all files"""
        for item in self.file_tree.get_children():
            self._set_checked(item, True)
    
    def uncheck_all(self):
        """Uncheck all files"""
        for item in self.file_tree.get_children():
            self._set_checked(item, False)
    
    def _set_checked(self, item, checked: bool):
        """Set checked state for item and all children"""
        self.checkbox_states[item] = checked
        values = list(self.file_tree.item(item, 'values'))
        if len(values) > 0:
            values[0] = '✓' if checked else ''
            if len(values) > 1:
                self.file_tree.item(item, values=(values[0], values[1]))
            else:
                self.file_tree.item(item, values=(values[0],))
        
        # Recursively set children
        for child in self.file_tree.get_children(item):
            self._set_checked(child, checked)
    
    def on_file_double_click(self, event):
        """Handle double-click on file"""
        selection = self.file_tree.selection()
        if selection:
            item = selection[0]
            values = self.file_tree.item(item, 'values')
            if values and len(values) > 1:
                file_path = Path(values[1])
                self.analyze_single_file(file_path)
    
    def on_file_right_click(self, event):
        """Handle right-click for context menu"""
        item = self.file_tree.identify_row(event.y)
        if item:
            self.file_tree.selection_set(item)
            values = self.file_tree.item(item, 'values')
            if values and len(values) > 1:
                file_path = Path(values[1])
                # Could show context menu here
                self.analyze_single_file(file_path)
    
    def analyze_single_file(self, file_path: Path):
        """Analyze a single file"""
        self.progress_var.set(f"Analyzing {file_path.name}...")
        self.progress_bar.start()
        
        def analyze():
            try:
                analyzer = UnifiedCodeAnalyzer(file_path.parent, self.update_progress)
                analyzer.analyze_files([file_path], use_cache=True)
                
                self.root.after(0, lambda: self.display_file_analysis(file_path, analyzer))
            except Exception as e:
                self.root.after(0, lambda: messagebox.showerror("Error", f"Analysis failed: {e}"))
            finally:
                self.root.after(0, lambda: self.progress_bar.stop())
        
        threading.Thread(target=analyze, daemon=True).start()
    
    def analyze_selected(self):
        """Analyze checked files in tree"""
        checked_files = []
        
        def collect_checked_files(item):
            """Recursively collect all checked file items"""
            values = self.file_tree.item(item, 'values')
            if self.checkbox_states.get(item, False):
                # Check if it's a file (has file path in values)
                if values and len(values) > 1:
                    try:
                        file_path = Path(values[1])
                        if file_path.exists() and file_path.suffix == '.py':
                            checked_files.append(file_path)
                    except:
                        pass
            
            # Check children
            for child in self.file_tree.get_children(item):
                collect_checked_files(child)
        
        # Start from root items
        for item in self.file_tree.get_children():
            collect_checked_files(item)
        
        if not checked_files:
            messagebox.showwarning("Warning", "Please check files to analyze")
            return
        
        self.start_analysis(checked_files)
    
    def analyze_all(self):
        """Analyze all checked files (or all if none checked)"""
        checked_files = []
        
        def collect_checked_files(item):
            """Recursively collect all checked file items"""
            values = self.file_tree.item(item, 'values')
            if self.checkbox_states.get(item, False):
                if values and len(values) > 1:
                    try:
                        file_path = Path(values[1])
                        if file_path.exists() and file_path.suffix == '.py':
                            checked_files.append(file_path)
                    except:
                        pass
            
            for child in self.file_tree.get_children(item):
                collect_checked_files(child)
        
        for item in self.file_tree.get_children():
            collect_checked_files(item)
        
        # If no files checked, use all files
        files_to_analyze = checked_files if checked_files else self.all_python_files
        
        if not files_to_analyze:
            messagebox.showwarning("Warning", "No files to analyze")
            return
        
        self.start_analysis(files_to_analyze)
    
    def start_analysis(self, file_paths: List[Path]):
        """Start analysis of files"""
        if self.analysis_running:
            return
        
        self.analysis_running = True
        self.analyze_button.config(state='disabled')
        self.progress_bar.start()
        self.clear_results()
        
        def analyze():
            try:
                root_path = file_paths[0].parent if file_paths else Path(self.folder_var.get())
                self.analyzer = UnifiedCodeAnalyzer(root_path, self.update_progress)
                self.analyzer.analyze_files(file_paths, use_cache=True)
                
                self.root.after(0, self.analysis_complete)
            except Exception as e:
                self.root.after(0, lambda: self.analysis_error(str(e)))
        
        threading.Thread(target=analyze, daemon=True).start()
    
    def update_progress(self, message: str):
        """Update progress message"""
        self.root.after(0, lambda: self.progress_var.set(message))
    
    def analysis_complete(self):
        """Handle analysis completion"""
        self.analysis_running = False
        self.analyze_button.config(state='normal')
        self.progress_bar.stop()
        self.progress_var.set("Analysis complete")
        
        # Display results
        self.display_results()
        
        # Show cache stats
        cache_stats = self.analyzer.ast_cache.get_stats()
        messagebox.showinfo(
            "Analysis Complete",
            f"Analyzed {len(self.analyzer.file_trees)} files\n"
            f"Cache: {cache_stats['hit_rate']} hit rate\n"
            f"Functions: {len(self.analyzer.all_functions)}\n"
            f"Classes: {len(self.analyzer.all_classes)}"
        )
    
    def analysis_error(self, error_msg: str):
        """Handle analysis error"""
        self.analysis_running = False
        self.analyze_button.config(state='normal')
        self.progress_bar.stop()
        self.progress_var.set("Analysis failed")
        messagebox.showerror("Analysis Error", f"Analysis failed: {error_msg}")
    
    def display_results(self):
        """Display all results"""
        if not self.analyzer:
            return
        
        self.display_overview()
        self.display_definitions()
        self.display_dependencies()
        self.display_workflow()
        self.display_unused()
        
        # Update workflow filter
        functions = list(self.analyzer.all_functions.keys())
        classes = list(self.analyzer.all_classes.keys())
        self.workflow_filter['values'] = [""] + functions + classes
    
    def display_overview(self):
        """Display overview"""
        self.overview_text.delete(1.0, tk.END)
        
        header = "📊 ANALYSIS OVERVIEW\n"
        header += "=" * 50 + "\n\n"
        self.overview_text.insert(tk.END, header, "header")
        
        stats = (
            f"Files analyzed: {len(self.analyzer.file_trees)}\n"
            f"Functions defined: {len(self.analyzer.all_functions)}\n"
            f"Classes defined: {len(self.analyzer.all_classes)}\n"
            f"Imports found: {len(self.analyzer.all_imports)}\n"
            f"Function calls: {len(self.analyzer.all_calls)}\n"
            f"Errors: {len(self.analyzer.file_errors)}\n\n"
        )
        self.overview_text.insert(tk.END, stats, "stat")
        
        # Cache stats
        cache_stats = self.analyzer.ast_cache.get_stats()
        cache_info = (
            f"Cache Statistics:\n"
            f"  Hits: {cache_stats['hits']}\n"
            f"  Misses: {cache_stats['misses']}\n"
            f"  Hit Rate: {cache_stats['hit_rate']}\n"
            f"  Memory Cache Size: {cache_stats['memory_size']}\n"
        )
        self.overview_text.insert(tk.END, cache_info)
    
    def display_definitions(self):
        """Display definitions"""
        self.definitions_text.delete(1.0, tk.END)
        
        self.definitions_text.insert(tk.END, "🏗️ ALL DEFINITIONS\n")
        self.definitions_text.insert(tk.END, "=" * 40 + "\n\n")
        
        for file_path, definitions in self.analyzer.file_definitions.items():
            rel_path = file_path.relative_to(self.analyzer.root_path)
            self.definitions_text.insert(tk.END, f"📄 {rel_path}\n")
            
            if definitions['functions']:
                self.definitions_text.insert(tk.END, "  Functions:\n")
                for name, data in sorted(definitions['functions'].items()):
                    self.definitions_text.insert(tk.END, f"    • {name} (line {data['line']})\n")
            
            if definitions['classes']:
                self.definitions_text.insert(tk.END, "  Classes:\n")
                for name, data in sorted(definitions['classes'].items()):
                    self.definitions_text.insert(tk.END, f"    • {name} (line {data['line']})\n")
            
            self.definitions_text.insert(tk.END, "\n")
    
    def display_dependencies(self):
        """Display dependencies"""
        self.dependencies_text.delete(1.0, tk.END)
        
        self.dependencies_text.insert(tk.END, "🔗 DEPENDENCIES\n")
        self.dependencies_text.insert(tk.END, "=" * 40 + "\n\n")
        
        for file_path in self.analyzer.file_trees.keys():
            rel_path = file_path.relative_to(self.analyzer.root_path)
            self.dependencies_text.insert(tk.END, f"📄 {rel_path}\n")
            
            definitions = self.analyzer.file_definitions.get(file_path, {})
            imports = definitions.get('imports', {})
            if imports:
                self.dependencies_text.insert(tk.END, "  Imports:\n")
                for name, data in sorted(imports.items()):
                    self.dependencies_text.insert(tk.END, f"    📦 {name}\n")
            
            calls = self.analyzer.file_calls.get(file_path, [])
            if calls:
                self.dependencies_text.insert(tk.END, "  Calls:\n")
                for call in calls[:10]:  # Limit display
                    self.dependencies_text.insert(tk.END, f"    📞 {call['function']} (line {call['line']})\n")
            
            self.dependencies_text.insert(tk.END, "\n")
    
    def display_workflow(self):
        """Display workflow"""
        self.show_all_workflow()
    
    def show_all_workflow(self):
        """Show all workflows"""
        self.workflow_text.delete(1.0, tk.END)
        
        self.workflow_text.insert(tk.END, "🔄 COMPLETE WORKFLOW\n")
        self.workflow_text.insert(tk.END, "=" * 40 + "\n\n")
        
        for func_name, func_data in self.analyzer.all_functions.items():
            workflow = self.analyzer.get_function_workflow(func_name)
            if workflow:
                def_data = workflow.get('definition')
                if not def_data:
                    continue
                
                # Handle both single dict and list (duplicates)
                if isinstance(def_data, list):
                    def_data = def_data[0]
                
                if not isinstance(def_data, dict):
                    continue
                
                file_path = def_data.get('file')
                if not file_path:
                    continue
                
                rel_path = file_path.relative_to(self.analyzer.root_path)
                
                self.workflow_text.insert(tk.END, f"🏗️ {func_name}\n")
                self.workflow_text.insert(tk.END, f"   📄 {rel_path} (line {def_data.get('line', 0)})\n")
                
                called_by = workflow.get('called_by', [])
                if called_by:
                    self.workflow_text.insert(tk.END, f"   📞 Called by:\n")
                    for caller in called_by:
                        if isinstance(caller, dict) and caller.get('file'):
                            caller_rel = caller['file'].relative_to(self.analyzer.root_path)
                            self.workflow_text.insert(tk.END, f"      • {caller_rel} (line {caller.get('line', 0)})\n")
                else:
                    self.workflow_text.insert(tk.END, f"   ⚠️  Never called\n")
                
                self.workflow_text.insert(tk.END, "\n")
    
    def update_workflow(self, event=None):
        """Update workflow display"""
        selected = self.workflow_filter_var.get()
        if not selected:
            self.show_all_workflow()
            return
        
        self.workflow_text.delete(1.0, tk.END)
        workflow = self.analyzer.get_function_workflow(selected)
        
        if workflow:
            def_data = workflow.get('definition')
            if not def_data:
                return
            
            # Handle both single dict and list (duplicates)
            if isinstance(def_data, list):
                def_data = def_data[0]
            
            if not isinstance(def_data, dict):
                return
            
            file_path = def_data.get('file')
            if not file_path:
                return
            
            rel_path = file_path.relative_to(self.analyzer.root_path)
            
            self.workflow_text.insert(tk.END, f"🔄 WORKFLOW: {selected}\n")
            self.workflow_text.insert(tk.END, f"📄 Defined in: {rel_path} (line {def_data.get('line', 0)})\n\n")
            
            called_by = workflow.get('called_by', [])
            if called_by:
                self.workflow_text.insert(tk.END, "Called by:\n")
                for caller in called_by:
                    if isinstance(caller, dict) and caller.get('file'):
                        caller_rel = caller['file'].relative_to(self.analyzer.root_path)
                        self.workflow_text.insert(tk.END, f"  • {caller_rel} (line {caller.get('line', 0)})\n")
            else:
                self.workflow_text.insert(tk.END, "⚠️  Never called (potentially unused)\n")
    
    def display_unused(self):
        """Display unused code"""
        self.unused_text.delete(1.0, tk.END)
        
        self.unused_text.insert(tk.END, "🗑️ UNUSED CODE\n")
        self.unused_text.insert(tk.END, "=" * 40 + "\n\n")
        
        unused = self.analyzer.get_unused_functions()
        if unused:
            self.unused_text.insert(tk.END, "Unused Functions:\n")
            for func_name in unused:
                func_data = self.analyzer.all_functions[func_name]
                # Handle both single dict and list
                if isinstance(func_data, list):
                    func_data = func_data[0]
                
                file_path = func_data.get('file')
                if file_path:
                    rel_path = file_path.relative_to(self.analyzer.root_path)
                    self.unused_text.insert(tk.END, f"  • {func_name} in {rel_path} (line {func_data.get('line', 0)})\n")
        else:
            self.unused_text.insert(tk.END, "✅ All functions are being used!\n")
    
    def display_file_analysis(self, file_path: Path, analyzer: UnifiedCodeAnalyzer):
        """Display analysis for a single file"""
        self.file_analysis_text.delete(1.0, tk.END)
        self.results_notebook.select(5)  # Switch to file analysis tab
        
        workflow = analyzer.get_file_workflow(file_path)
        rel_path = file_path.relative_to(analyzer.root_path)
        
        self.file_analysis_text.insert(tk.END, f"📄 FILE ANALYSIS: {rel_path}\n")
        self.file_analysis_text.insert(tk.END, "=" * 50 + "\n\n")
        
        # Functions
        if workflow['functions']:
            self.file_analysis_text.insert(tk.END, "Functions:\n")
            for name, data in sorted(workflow['functions'].items()):
                self.file_analysis_text.insert(tk.END, f"  • {name} (line {data['line']})\n")
            self.file_analysis_text.insert(tk.END, "\n")
        
        # Classes
        if workflow['classes']:
            self.file_analysis_text.insert(tk.END, "Classes:\n")
            for name, data in sorted(workflow['classes'].items()):
                self.file_analysis_text.insert(tk.END, f"  • {name} (line {data['line']})\n")
            self.file_analysis_text.insert(tk.END, "\n")
        
        # Imports
        if workflow['imports']:
            self.file_analysis_text.insert(tk.END, "Imports:\n")
            for name, data in sorted(workflow['imports'].items()):
                self.file_analysis_text.insert(tk.END, f"  📦 {name}\n")
            self.file_analysis_text.insert(tk.END, "\n")
        
        # Calls
        if workflow['calls']:
            self.file_analysis_text.insert(tk.END, "Function Calls:\n")
            for call in workflow['calls']:
                self.file_analysis_text.insert(tk.END, f"  📞 {call['function']} (line {call['line']})\n")
    
    def clear_results(self):
        """Clear all results"""
        for text_widget in [
            self.overview_text, self.definitions_text, self.dependencies_text,
            self.workflow_text, self.unused_text, self.file_analysis_text
        ]:
            text_widget.delete(1.0, tk.END)


def main():
    """Main function"""
    root = tk.Tk()
    
    # Configure style
    style = ttk.Style()
    style.theme_use('clam')
    
    app = UnifiedAnalyzerGUI(root)
    root.mainloop()


if __name__ == "__main__":
    main()

