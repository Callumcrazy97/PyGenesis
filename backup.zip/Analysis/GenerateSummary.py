import os
import sys
import argparse
from pathlib import Path
from collections import Counter
import ast

IGNORED_DIRS = {
    ".git",
    ".idea",
    ".vscode",
    "__pycache__",
    "venv",
    ".venv",
    "env",
    ".env",
    "node_modules",
    "dist",
    "build",
    ".mypy_cache",
    ".pytest_cache",
    ".tox",
}

TEXT_EXTENSIONS = {
    ".py", ".txt", ".md", ".json", ".yml", ".yaml", ".ini",
    ".cfg", ".toml", ".html", ".htm", ".js", ".ts", ".css",
    ".qml", ".qss",
}

BINARY_EXTENSIONS = {
    ".png", ".jpg", ".jpeg", ".gif", ".bmp", ".ico",
    ".exe", ".dll", ".pyd", ".so", ".dylib",
    ".ttf", ".otf",
    ".zip", ".rar", ".7z",
    ".mp3", ".wav", ".ogg",
}


def is_text_file(path: Path) -> bool:
    if path.suffix in TEXT_EXTENSIONS:
        return True
    if path.suffix in BINARY_EXTENSIONS:
        return False
    # Fallback: treat small, no-null-byte files as text
    try:
        with path.open("rb") as f:
            chunk = f.read(2048)
        if b"\x00" in chunk:
            return False
        return True
    except OSError:
        return False


def get_python_docstring(path: Path, max_len: int = 300) -> str:
    try:
        src = path.read_text(encoding="utf-8", errors="ignore")
        module = ast.parse(src)
        doc = ast.get_docstring(module) or ""
        doc = doc.strip()
        if len(doc) > max_len:
            doc = doc[: max_len - 3] + "..."
        return doc
    except Exception:
        return ""


def get_first_comment_or_line(path: Path, max_len: int = 200) -> str:
    try:
        with path.open("r", encoding="utf-8", errors="ignore") as f:
            for line in f:
                stripped = line.strip()
                if not stripped:
                    continue
                if stripped.startswith("#") or stripped.startswith("//") or stripped.startswith("/*"):
                    text = stripped.lstrip("#/ ").strip()
                else:
                    text = stripped
                if len(text) > max_len:
                    text = text[: max_len - 3] + "..."
                return text
    except OSError:
        pass
    return ""


def build_tree(root: Path, max_depth: int = 3, max_entries_per_dir: int = 25):
    """
    Return a markdown-ish tree of the directory.
    """
    lines = []

    def walk(dir_path: Path, depth: int):
        if depth > max_depth:
            return
        indent = "  " * depth
        try:
            entries = sorted(dir_path.iterdir(), key=lambda p: (p.is_file(), p.name.lower()))
        except PermissionError:
            return
        count = 0
        total_entries = len(entries)
        for entry in entries:
            if entry.is_dir():
                if entry.name in IGNORED_DIRS:
                    continue
                lines.append(f"{indent}- **{entry.name}/**")
                count += 1
                if count >= max_entries_per_dir:
                    remaining = total_entries - count
                    if remaining > 0:
                        lines.append(f"{indent}  - ... ({remaining} more)")
                    break
                walk(entry, depth + 1)
            else:
                lines.append(f"{indent}- {entry.name}")
                count += 1
                if count >= max_entries_per_dir:
                    remaining = total_entries - count
                    if remaining > 0:
                        lines.append(f"{indent}  - ... ({remaining} more)")
                    break

    lines.append(f"- **{root.name}/**")
    walk(root, 1)
    return "\n".join(lines)


def summarize_project(root: Path, max_files_per_section: int = 40, max_tree_depth: int = 3) -> str:
    file_ext_counts = Counter()
    file_count = 0
    total_bytes = 0
    python_files = []
    other_text_files = []
    binary_files = []
    top_level_dirs = Counter()

    for dirpath, dirnames, filenames in os.walk(root):
        # Prune ignored dirs
        dirnames[:] = [d for d in dirnames if d not in IGNORED_DIRS]
        rel = Path(dirpath).relative_to(root)
        # Track top-level dirs
        if rel.parts:
            top_level_dirs[rel.parts[0]] += 0  # ensure key exists

        for fn in filenames:
            path = Path(dirpath) / fn
            rel_path = path.relative_to(root)
            ext = path.suffix.lower()
            file_ext_counts[ext or "<no-ext>"] += 1
            file_count += 1
            try:
                size = path.stat().st_size
            except OSError:
                size = 0
            total_bytes += size

            if ext == ".py":
                python_files.append((rel_path, size))
            elif is_text_file(path):
                other_text_files.append((rel_path, size))
            else:
                binary_files.append((rel_path, size))

    python_files.sort(key=lambda t: t[1], reverse=True)
    other_text_files.sort(key=lambda t: t[1], reverse=True)
    binary_files.sort(key=lambda t: t[1], reverse=True)

    # Build markdown summary
    out_lines = []
    out_lines.append(f"# Codebase Summary: `{root.name}`\n")
    out_lines.append("## Overview\n")
    out_lines.append(f"- Root path: `{root}`")
    out_lines.append(f"- Total files: **{file_count}**")
    kb = total_bytes / 1024 if total_bytes else 0
    mb = kb / 1024 if kb else 0
    if mb >= 1:
        size_str = f"{mb:.1f} MB"
    else:
        size_str = f"{kb:.1f} KB"
    out_lines.append(f"- Approx total size: **{size_str}**\n")

    if top_level_dirs:
        out_lines.append("### Top-level directories\n")
        for name in sorted(top_level_dirs.keys()):
            out_lines.append(f"- `{name}/`")
        out_lines.append("")

    out_lines.append("### File types\n")
    for ext, count in file_ext_counts.most_common():
        out_lines.append(f"- `{ext}`: {count}")
    out_lines.append("")

    # Directory tree
    out_lines.append("## Project tree (truncated)\n")
    out_lines.append(build_tree(root, max_depth=max_tree_depth))
    out_lines.append("")

    # Key Python modules
    if python_files:
        out_lines.append("## Key Python modules (largest by size)\n")
        for rel_path, size in python_files[:max_files_per_section]:
            path = root / rel_path
            loc = 0
            try:
                with path.open("r", encoding="utf-8", errors="ignore") as f:
                    for i, _ in enumerate(f, 1):
                        pass
                loc = i
            except Exception:
                loc = 0
            doc = get_python_docstring(path)
            size_kb = size / 1024 if size else 0
            out_lines.append(f"### `{rel_path}`")
            out_lines.append(f"- Size: {size_kb:.1f} KB ({loc} lines approx)")
            if doc:
                out_lines.append("- Docstring:")
                out_lines.append("```")
                out_lines.append(doc)
                out_lines.append("```")
            else:
                first_line = get_first_comment_or_line(path)
                if first_line:
                    out_lines.append("- First meaningful line:")
                    out_lines.append("```")
                    out_lines.append(first_line)
                    out_lines.append("```")
            out_lines.append("")
    
    # Other key text files
    if other_text_files:
        out_lines.append("## Other important text files\n")
        for rel_path, size in other_text_files[:max_files_per_section]:
            path = root / rel_path
            size_kb = size / 1024 if size else 0
            first_line = get_first_comment_or_line(path)
            summary = first_line or "(no obvious description)"
            out_lines.append(f"- `{rel_path}` ({size_kb:.1f} KB): {summary}")
        out_lines.append("")

    # Binary assets
    if binary_files:
        out_lines.append("## Binary assets (images, binaries, etc.)\n")
        for rel_path, size in binary_files[:max_files_per_section]:
            size_kb = size / 1024 if size else 0
            out_lines.append(f"- `{rel_path}` ({size_kb:.1f} KB)")
        if len(binary_files) > max_files_per_section:
            out_lines.append(f"- ... and {len(binary_files) - max_files_per_section} more")
        out_lines.append("")

    return "\n".join(out_lines)


def main():
    parser = argparse.ArgumentParser(
        description="Generate a markdown summary of a codebase for use as AI context."
    )
    parser.add_argument(
        "root",
        nargs="?",
        default=".",
        help="Root directory to summarize (default: current directory).",
    )
    parser.add_argument(
        "-o", "--output",
        default="CODEBASE_SUMMARY.md",
        help="Output markdown file (default: CODEBASE_SUMMARY.md)",
    )
    parser.add_argument(
        "--max-depth",
        type=int,
        default=3,
        help="Max directory tree depth in the summary (default: 3).",
    )
    parser.add_argument(
        "--max-files",
        type=int,
        default=40,
        help="Max files per section (largest Python, text, binary).",
    )
    args = parser.parse_args()

    root = Path(args.root).resolve()
    if not root.exists():
        print(f"Error: root path does not exist: {root}", file=sys.stderr)
        sys.exit(1)

    summary = summarize_project(
        root,
        max_files_per_section=args.max_files,
        max_tree_depth=args.max_depth,
    )
    out_path = Path(args.output).resolve()
    out_path.write_text(summary, encoding="utf-8")
    print(f"Summary written to: {out_path}")


if __name__ == "__main__":
    main()
