📊 ANALYSIS OVERVIEW
==================================================

Files analyzed: 251
Functions defined: 3006
Classes defined: 345
Imports found: 595
Function calls: 45156
Errors: 1

Cache Statistics:
  Hits: 0
  Misses: 252
  Hit Rate: 0.0%
  Memory Cache Size: 251

