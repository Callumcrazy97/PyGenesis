🔗 DEPENDENCIES
========================================

📄 check_dependencies.py
  Imports:
    📦 subprocess
    📦 sys
  Calls:
    📞 __import__ (line 29)
    📞 print (line 30)
    📞 print (line 34)
    📞 subprocess.check_call (line 36)
    📞 print (line 37)
    📞 print (line 40)
    📞 print (line 41)
    📞 print (line 44)
    📞 print (line 45)
    📞 print (line 50)

📄 Config\__init__.py

📄 Config\Settings.py
  Imports:
    📦 PySide6.QtCore.QSettings
    📦 json
    📦 os
    📦 pathlib.Path
  Calls:
    📞 QSettings (line 12)
    📞 self.load_default_settings (line 13)
    📞 contains (line 17)
    📞 self.set_default_settings (line 18)
    📞 setValue (line 23)
    📞 setValue (line 24)
    📞 setValue (line 27)
    📞 setValue (line 28)
    📞 setValue (line 29)
    📞 setValue (line 32)

📄 Core\__init__.py

📄 Core\AI\PyGenesisAssistant\code_analysis.py
  Imports:
    📦 ast
    📦 collections.defaultdict
    📦 pathlib.Path
    📦 typing.Any
    📦 typing.Dict
    📦 typing.List
    📦 typing.Optional
    📦 typing.Set
  Calls:
    📞 __init__ (line 32)
    📞 super (line 32)
    📞 set (line 33)
    📞 clear (line 37)
    📞 clear (line 38)
    📞 clear (line 39)
    📞 ast.parse (line 42)
    📞 str (line 42)
    📞 self._collect_definitions (line 44)
    📞 self._check_undefined_names (line 46)

📄 Config\ThemeManager.py
  Imports:
    📦 Core.Debug.debug
    📦 PySide6.QtCore.QCoreApplication
    📦 PySide6.QtCore.QObject
    📦 PySide6.QtCore.Signal
    📦 PySide6.QtGui.QColor
    📦 json
    📦 os
  Calls:
    📞 Signal (line 15)
    📞 __init__ (line 18)
    📞 super (line 18)
    📞 get (line 20)
    📞 get (line 21)
    📞 self._get_dark_theme (line 23)
    📞 self._get_light_theme (line 24)
    📞 self._get_high_contrast_theme (line 25)
    📞 self._load_custom_themes (line 28)
    📞 self._load_custom_theme_colors (line 31)

📄 Core\AI\PyGenesisAssistant\Nova\core\__init__.py

📄 Core\AI\PyGenesisAssistant\Nova\core\api_manifest.py
  Imports:
    📦 dataclasses.dataclass
    📦 typing.Any
    📦 typing.Dict
    📦 typing.List
    📦 typing.Optional
    📦 typing.Tuple
  Calls:
    📞 APIMethod (line 31)
    📞 APIMethod (line 40)
    📞 APIMethod (line 48)
    📞 APIMethod (line 56)
    📞 APIMethod (line 64)
    📞 APIMethod (line 74)
    📞 APIMethod (line 83)
    📞 APIMethod (line 91)
    📞 APIMethod (line 101)
    📞 APIMethod (line 111)

📄 Core\AI\PyGenesisAssistant\Nova\core\ast_scanner.py
  Imports:
    📦 ast
    📦 dataclasses.dataclass
    📦 dataclasses.field
    📦 os
    📦 pathlib.Path
    📦 typing.Any
    📦 typing.Dict
    📦 typing.List
    📦 typing.Optional
    📦 typing.Set
  Calls:
    📞 field (line 18)
    📞 field (line 20)
    📞 field (line 32)
    📞 field (line 34)
    📞 field (line 35)
    📞 field (line 42)
    📞 field (line 51)
    📞 field (line 52)
    📞 field (line 53)
    📞 field (line 54)

📄 Core\AI\PyGenesisAssistant\Nova\core\async_scanner.py
  Imports:
    📦 PySide6.QtCore.QThread
    📦 PySide6.QtCore.Signal
    📦 core.project_scanner.ProjectScanner
    📦 typing.Any
    📦 typing.Dict
    📦 typing.Optional
  Calls:
    📞 Signal (line 13)
    📞 Signal (line 14)
    📞 Signal (line 15)
    📞 __init__ (line 18)
    📞 super (line 18)
    📞 ProjectScanner (line 20)
    📞 emit (line 29)
    📞 scan_project (line 32)
    📞 structure.get (line 37)
    📞 emit (line 38)

📄 Core\AI\PyGenesisAssistant\Nova\core\codebase_analyzer.py
  Imports:
    📦 ast
    📦 collections.Counter
    📦 collections.defaultdict
    📦 os
    📦 pathlib.Path
    📦 typing.Any
    📦 typing.Dict
    📦 typing.List
    📦 typing.Optional
    📦 typing.Set
  Calls:
    📞 Path (line 26)
    📞 resources_path.exists (line 31)
    📞 resources_path.rglob (line 33)
    📞 file_path.is_file (line 34)
    📞 any (line 36)
    📞 code_files.append (line 38)
    📞 str (line 38)
    📞 sorted (line 40)
    📞 Path (line 44)
    📞 self.find_code_files (line 45)

📄 Core\AI\PyGenesisAssistant\Nova\core\context_analyzer.py
  Imports:
    📦 datetime.datetime
    📦 re
    📦 typing.Any
    📦 typing.Dict
    📦 typing.List
    📦 typing.Optional
    📦 typing.Tuple
  Calls:
    📞 current_message.lower (line 68)
    📞 self._find_math_reference (line 71)
    📞 context.update (line 73)
    📞 self._find_general_reference (line 77)
    📞 context.update (line 79)
    📞 self._find_follow_up (line 83)
    📞 context.update (line 85)
    📞 upper (line 92)
    📞 str (line 92)
    📞 msg.get (line 92)

📄 Core\AI\PyGenesisAssistant\Nova\core\engines\__init__.py

📄 Core\AI\PyGenesisAssistant\DependencyAnalyser.py
  Imports:
    📦 ast
    📦 collections.defaultdict
    📦 json
    📦 os
    📦 pathlib.Path
    📦 sys
    📦 threading
    📦 tkinter
    📦 tkinter.filedialog
    📦 tkinter.messagebox
    📦 tkinter.scrolledtext
    📦 tkinter.ttk
    📦 typing.Dict
    📦 typing.List
    📦 typing.Optional
    📦 typing.Set
    📦 typing.Tuple
  Calls:
    📞 title (line 24)
    📞 geometry (line 25)
    📞 self.create_widgets (line 33)
    📞 ttk.Frame (line 38)
    📞 main_frame.grid (line 39)
    📞 columnconfigure (line 42)
    📞 rowconfigure (line 43)
    📞 main_frame.columnconfigure (line 44)
    📞 main_frame.rowconfigure (line 45)
    📞 ttk.Label (line 48)

📄 Core\AI\PyGenesisAssistant\Nova\core\engines\base_engine.py
  Imports:
    📦 abc.ABC
    📦 abc.abstractmethod
    📦 core.workflow.WorkflowContext

📄 Core\AI\PyGenesisAssistant\CodeAnalyser.py
  Imports:
    📦 ast
    📦 collections.defaultdict
    📦 importlib.util
    📦 json
    📦 os
    📦 pathlib.Path
    📦 re
    📦 sys
    📦 threading
    📦 tkinter
    📦 tkinter.filedialog
    📦 tkinter.messagebox
    📦 tkinter.scrolledtext
    📦 tkinter.ttk
    📦 typing.Dict
    📦 typing.List
    📦 typing.Optional
    📦 typing.Set
    📦 typing.Tuple
  Calls:
    📞 __init__ (line 23)
    📞 tk.BooleanVar (line 25)
    📞 trace (line 26)
    📞 ttk.Frame (line 29)
    📞 pack (line 30)
    📞 ttk.Checkbutton (line 33)
    📞 pack (line 37)
    📞 ttk.Label (line 39)
    📞 pack (line 40)
    📞 ttk.Frame (line 43)

📄 Core\AI\PyGenesisAssistant\Nova\core\engines\conversation_engine.py
  Imports:
    📦 core.engines.base_engine.BaseEngine
    📦 core.models.ResponseStrategy
    📦 core.models.UserMode
    📦 core.response_templates.format_explanation_response
    📦 core.response_templates.get_follow_up_question
    📦 core.response_templates.get_greeting_response
    📦 core.response_templates.get_meta_prefix
    📦 core.workflow.WorkflowContext
    📦 datetime.datetime
    📦 json
    📦 os
    📦 random
    📦 re
    📦 typing.Dict
    📦 typing.List
    📦 typing.Optional
  Calls:
    📞 self._load_knowledge_base (line 27)
    📞 dirname (line 130)
    📞 abspath (line 130)
    📞 join (line 131)
    📞 dirname (line 131)
    📞 dirname (line 131)
    📞 join (line 132)
    📞 exists (line 134)
    📞 open (line 135)
    📞 json.load (line 136)

📄 Core\AI\PyGenesisAssistant\Nova\core\engines\dictionary_engine.py
  Imports:
    📦 core.engines.base_engine.BaseEngine
    📦 core.workflow.WorkflowContext
    📦 nltk
    📦 nltk.corpus.wordnet
    📦 os
    📦 re
    📦 typing.Dict
    📦 typing.Optional
  Calls:
    📞 find (line 21)
    📞 nltk.download (line 24)
    📞 self._extract_word (line 57)
    📞 strip (line 62)
    📞 word.lower (line 62)
    📞 self._lookup_wordnet (line 66)
    📞 word.title (line 72)
    📞 re.search (line 90)
    📞 text.lower (line 90)
    📞 match.group (line 92)

📄 Core\AI\PyGenesisAssistant\Nova\core\engines\math_engine.py
  Imports:
    📦 core.engines.base_engine.BaseEngine
    📦 core.workflow.WorkflowContext
    📦 re
    📦 sympy
    📦 sympy.SympifyError
    📦 sympy.sympify
    📦 typing.Optional
  Calls:
    📞 strip (line 51)
    📞 self._solve_math (line 56)
    📞 str (line 59)
    📞 self._natural_language_to_math (line 67)
    📞 self._clean_expression (line 70)
    📞 sympify (line 75)
    📞 float (line 76)
    📞 expr.evalf (line 76)
    📞 result.is_integer (line 79)
    📞 str (line 80)

📄 Core\AI\PyGenesisAssistant\Nova\core\conversations.py
  Imports:
    📦 core.models.ChatMessage
    📦 core.models.Sender
    📦 dataclasses.asdict
    📦 dataclasses.dataclass
    📦 datetime.datetime
    📦 json
    📦 pathlib.Path
    📦 re
    📦 settings.SETTINGS
    📦 typing.Any
    📦 typing.Dict
    📦 typing.List
    📦 typing.Optional
    📦 uuid
  Calls:
    📞 asdict (line 28)
    📞 cls (line 36)
    📞 Path (line 52)
    📞 Path (line 57)
    📞 Path (line 60)
    📞 mkdir (line 61)
    📞 Path (line 63)
    📞 mkdir (line 64)
    📞 str (line 80)
    📞 uuid.uuid4 (line 80)

📄 Core\AI\PyGenesisAssistant\Nova\core\engines\thesaurus_engine.py
  Imports:
    📦 core.engines.base_engine.BaseEngine
    📦 core.workflow.WorkflowContext
    📦 nltk
    📦 nltk.corpus.wordnet
    📦 re
    📦 typing.List
    📦 typing.Optional
  Calls:
    📞 find (line 18)
    📞 nltk.download (line 21)
    📞 self._extract_word (line 49)
    📞 strip (line 54)
    📞 word.lower (line 54)
    📞 self._lookup_wordnet_synonyms (line 58)
    📞 self._format_synonyms (line 60)
    📞 self._format_synonyms (line 65)
    📞 re.search (line 85)
    📞 text.lower (line 85)

📄 Core\AI\PyGenesisAssistant\Nova\core\executors\__init__.py

📄 Core\AI\PyGenesisAssistant\Nova\core\executors\base_executor.py
  Imports:
    📦 abc.ABC
    📦 abc.abstractmethod
    📦 core.workflow.WorkflowContext

📄 Core\AI\PyGenesisAssistant\Nova\core\engines\research_engine.py
  Imports:
    📦 core.codebase_analyzer.CodebaseAnalyzer
    📦 core.engines.base_engine.BaseEngine
    📦 core.workflow.WorkflowContext
    📦 json
    📦 os
    📦 pathlib.Path
    📦 re
    📦 requests
    📦 typing.Any
    📦 typing.Dict
    📦 typing.List
    📦 typing.Optional
    📦 urllib.parse.quote_plus
  Calls:
    📞 config.get (line 25)
    📞 config.get (line 26)
    📞 config.get (line 27)
    📞 config.get (line 28)
    📞 config.get (line 29)
    📞 query.replace (line 37)
    📞 replace (line 38)
    📞 replace (line 41)
    📞 quote_plus (line 41)
    📞 self._load_safe_sites (line 50)

📄 Core\AI\PyGenesisAssistant\Nova\core\executors\code_query_executor.py
  Imports:
    📦 core.executors.base_executor.BaseExecutor
    📦 core.models.Intent
    📦 core.workflow.WorkflowContext
    📦 re
    📦 typing.Optional
  Calls:
    📞 get (line 20)
    📞 get (line 21)
    📞 lower (line 26)
    📞 self._extract_code_entity (line 29)
    📞 self._is_class_query (line 32)
    📞 self._answer_class_query (line 33)
    📞 self._extract_class_name (line 33)
    📞 self._is_function_query (line 35)
    📞 self._answer_function_query (line 36)
    📞 self._extract_function_name (line 36)

📄 Core\AI\PyGenesisAssistant\Nova\core\executors\general_chat_executor.py
  Imports:
    📦 core.executors.base_executor.BaseExecutor
    📦 core.workflow.WorkflowContext
  Calls:
    📞 lower (line 20)
    📞 responses.items (line 21)

📄 Core\AI\PyGenesisAssistant\Nova\core\executors\graph_visualization_executor.py
  Imports:
    📦 core.executors.base_executor.BaseExecutor
    📦 core.workflow.WorkflowContext

📄 Core\AI\PyGenesisAssistant\Nova\core\executors\code_search_executor.py
  Imports:
    📦 core.executors.base_executor.BaseExecutor
    📦 core.workflow.WorkflowContext
    📦 json
    📦 os
    📦 pathlib.Path
    📦 re
    📦 typing.Any
    📦 typing.Dict
    📦 typing.List
    📦 typing.Optional
    📦 typing.Tuple
  Calls:
    📞 __init__ (line 69)
    📞 super (line 69)
    📞 lower (line 77)
    📞 self._extract_search_info (line 80)
    📞 self._search_code (line 86)
    📞 self._format_results (line 92)
    📞 str (line 94)
    📞 items (line 105)
    📞 re.search (line 106)
    📞 re.search (line 117)

📄 Core\AI\PyGenesisAssistant\Nova\core\executors\project_modification_executor.py
  Imports:
    📦 core.executors.base_executor.BaseExecutor
    📦 core.workflow.WorkflowContext

📄 Core\AI\PyGenesisAssistant\Nova\core\feedback_handler.py
  Imports:
    📦 core.models.Intent
    📦 core.transaction_manager.TransactionManager
    📦 datetime.datetime
    📦 json
    📦 pathlib.Path
    📦 re
    📦 typing.Any
    📦 typing.Dict
    📦 typing.Optional
    📦 typing.Tuple
  Calls:
    📞 Path (line 15)
    📞 strip (line 57)
    📞 text.lower (line 57)
    📞 re.search (line 60)
    📞 self.is_feedback_request (line 84)
    📞 get_transaction_state (line 94)
    📞 transaction_state.get (line 95)
    📞 rollback (line 97)
    📞 isinstance (line 113)
    📞 str (line 113)

📄 Core\AI\PyGenesisAssistant\Nova\core\project_scanner.py
  Imports:
    📦 core.ast_scanner.ASTScanner
    📦 core.ast_scanner.FileAnalysis
    📦 os
    📦 pathlib.Path
    📦 typing.Dict
    📦 typing.List
    📦 typing.Optional
    📦 typing.Set
  Calls:
    📞 os.getcwd (line 22)
    📞 ASTScanner (line 23)
    📞 exists (line 39)
    📞 get_project_structure (line 47)
    📞 self.scan_project (line 61)
    📞 get (line 64)
    📞 lower (line 65)
    📞 class_name.lower (line 65)
    📞 results.append (line 66)
    📞 self.scan_project (line 81)

📄 Core\AI\PyGenesisAssistant\Nova\core\models.py
  Imports:
    📦 dataclasses.dataclass
    📦 dataclasses.field
    📦 datetime.datetime
    📦 enum.Enum
    📦 enum.auto
    📦 typing.Any
    📦 typing.Dict
    📦 typing.List
    📦 typing.Optional
  Calls:
    📞 auto (line 8)
    📞 auto (line 9)
    📞 field (line 126)
    📞 field (line 127)
    📞 field (line 128)

📄 Core\AI\PyGenesisAssistant\Nova\core\language_utils.py
  Imports:
    📦 enum.Enum
    📦 re
    📦 spellchecker.SpellChecker
    📦 typing.List
    📦 typing.Optional
    📦 typing.Tuple
  Calls:
    📞 SPELLING_DIFFERENCES.items (line 84)
    📞 SpellChecker (line 106)
    📞 SpellChecker (line 108)
    📞 SpellChecker (line 110)
    📞 re.finditer (line 135)
    📞 match.start (line 137)
    📞 parts.append (line 138)
    📞 match.start (line 138)
    📞 parts.append (line 140)
    📞 match.group (line 140)

📄 Core\AI\PyGenesisAssistant\Nova\core\operation_planner.py
  Imports:
    📦 core.api_manifest.API_SURFACE
    📦 core.api_manifest.get_validator
    📦 core.api_manifest.validate_operation
    📦 core.models.Intent
    📦 core.tasks.Task
    📦 core.tasks.TaskManager
    📦 core.tasks.TaskPriority
    📦 core.workflow.WorkflowContext
    📦 dataclasses.dataclass
    📦 dataclasses.field
    📦 enum.Enum
    📦 typing.Any
    📦 typing.Dict
    📦 typing.List
    📦 typing.Optional
    📦 typing.Tuple
  Calls:
    📞 field (line 41)
    📞 field (line 42)
    📞 field (line 43)
    📞 field (line 49)
    📞 get_validator (line 68)
    📞 create_task (line 82)
    📞 self._generate_plan_name (line 83)
    📞 self._determine_priority (line 87)
    📞 OperationPlan (line 92)
    📞 self._generate_rationale (line 94)

📄 Core\AI\PyGenesisAssistant\Nova\core\executors\resource_operation_executor.py
  Imports:
    📦 core.executors.base_executor.BaseExecutor
    📦 core.workflow.WorkflowContext
    📦 os
    📦 pathlib.Path
    📦 re
    📦 shutil
    📦 typing.Any
    📦 typing.Dict
    📦 typing.Optional
    📦 typing.Tuple
  Calls:
    📞 __init__ (line 57)
    📞 super (line 57)
    📞 lower (line 65)
    📞 self._is_folder_operation (line 68)
    📞 self._extract_folder_info (line 72)
    📞 folder_info.get (line 73)
    📞 self._create_folder (line 77)
    📞 self._delete_folder (line 79)
    📞 self._rename_folder (line 81)
    📞 str (line 85)

📄 Core\AI\PyGenesisAssistant\Nova\core\intent_router.py
  Imports:
    📦 core.models.ClarificationContext
    📦 core.models.ConfidenceBand
    📦 core.models.Intent
    📦 core.models.IntentResult
    📦 core.models.UserMode
    📦 core.slm.custom_neural_model.CustomNeuralModel
    📦 core.slm.tiny_intent_model.TinyIntentModel
    📦 os
    📦 re
    📦 typing.Any
    📦 typing.Dict
    📦 typing.List
    📦 typing.Optional
  Calls:
    📞 CustomNeuralModel (line 49)
    📞 print (line 52)
    📞 TinyIntentModel (line 58)
    📞 print (line 60)
    📞 print (line 66)
    📞 text.lower (line 151)
    📞 self._quick_pattern_check (line 155)
    📞 self._handle_clarification_response (line 162)
    📞 self._extract_potential_entity (line 165)
    📞 self._is_project_loaded (line 168)

📄 Core\AI\PyGenesisAssistant\Nova\core\slm\__init__.py

📄 Core\AI\PyGenesisAssistant\Nova\core\response_templates.py
  Imports:
    📦 core.models.Intent
    📦 core.models.ResponseStrategy
    📦 core.models.UserMode
    📦 random
  Calls:
    📞 RESPONSE_TEMPLATES.get (line 148)
    📞 len (line 155)
    📞 len (line 156)
    📞 len (line 157)
    📞 template.format (line 159)
    📞 strip (line 184)
    📞 template.format (line 184)
    📞 template.format (line 195)
    📞 template.format (line 204)
    📞 format (line 210)

📄 Core\AI\PyGenesisAssistant\Nova\core\slm\Test\expand_intent_templates.py
  Imports:
    📦 itertools
    📦 json
    📦 random
  Calls:
    📞 intent_spec.get (line 8)
    📞 intent_spec.get (line 9)
    📞 intent_spec.get (line 10)
    📞 list (line 12)
    📞 axes.keys (line 12)
    📞 list (line 13)
    📞 axes.values (line 13)
    📞 list (line 15)
    📞 itertools.product (line 15)
    📞 dict (line 19)

📄 Core\AI\PyGenesisAssistant\Nova\core\slm\expand_intent_templates.py
  Imports:
    📦 itertools
    📦 json
    📦 random
  Calls:
    📞 intent_spec.get (line 8)
    📞 intent_spec.get (line 9)
    📞 intent_spec.get (line 10)
    📞 list (line 12)
    📞 axes.keys (line 12)
    📞 list (line 13)
    📞 axes.values (line 13)
    📞 list (line 15)
    📞 itertools.product (line 15)
    📞 dict (line 19)

📄 Core\AI\PyGenesisAssistant\Nova\core\slm\generate_training_data.py
  Imports:
    📦 json
    📦 pathlib.Path
    📦 random
    📦 typing.Any
    📦 typing.Dict
    📦 typing.List
  Calls:
    📞 random.seed (line 29)
    📞 templates.items (line 32)
    📞 spec.get (line 34)
    📞 range (line 37)
    📞 vars_dict.items (line 41)
    📞 isinstance (line 42)
    📞 len (line 44)
    📞 all (line 44)
    📞 isinstance (line 44)
    📞 random.randint (line 46)

📄 Core\AI\PyGenesisAssistant\Nova\core\slm\custom_neural_model.py
  Imports:
    📦 collections.defaultdict
    📦 core.models.Intent
    📦 datetime.datetime
    📦 enum.Enum
    📦 json
    📦 math
    📦 models.Intent
    📦 numpy
    📦 pathlib.Path
    📦 re
    📦 subprocess
    📦 sys
    📦 typing.Dict
    📦 typing.List
    📦 typing.Optional
    📦 typing.Tuple
    📦 typing.Union
  Calls:
    📞 print (line 23)
    📞 subprocess.check_call (line 24)
    📞 print (line 28)
    📞 Path (line 37)
    📞 str (line 38)
    📞 insert (line 39)
    📞 str (line 39)
    📞 Path (line 62)
    📞 MODEL_DIR.mkdir (line 63)
    📞 ImportError (line 111)

📄 Core\AI\PyGenesisAssistant\Nova\core\slm\tiny_intent_model.py
  Imports:
    📦 core.models.Intent
    📦 numpy
    📦 os
    📦 pathlib.Path
    📦 typing.List
    📦 typing.Tuple
  Calls:
    📞 Path (line 20)
    📞 MODEL_DIR.mkdir (line 21)
    📞 ImportError (line 46)
    📞 list (line 48)
    📞 keys (line 48)
    📞 MODEL_FILE.exists (line 49)
    📞 self._load (line 50)
    📞 self._bootstrap (line 52)
    📞 randn (line 80)
    📞 len (line 80)

📄 Core\AI\PyGenesisAssistant\Nova\core\slm\train_model.py
  Imports:
    📦 json
    📦 numpy
    📦 pathlib.Path
    📦 slm.custom_neural_model.CustomNeuralModel
    📦 slm.custom_neural_model.MISCLASSIFICATION_LOG
    📦 subprocess
    📦 sys
    📦 typing.Dict
    📦 typing.List
    📦 typing.Optional
    📦 typing.Tuple
  Calls:
    📞 print (line 15)
    📞 subprocess.check_call (line 17)
    📞 print (line 19)
    📞 print (line 21)
    📞 print (line 22)
    📞 sys.exit (line 23)
    📞 insert (line 26)
    📞 str (line 26)
    📞 Path (line 26)
    📞 data_file.exists (line 41)

📄 Core\AI\PyGenesisAssistant\Nova\core\task_name_generator.py
  Imports:
    📦 core.models.Intent
    📦 re
    📦 typing.Optional
  Calls:
    📞 strip (line 25)
    📞 user_input.lower (line 25)
    📞 re.search (line 32)
    📞 strip (line 34)
    📞 match.group (line 34)
    📞 entity.title (line 40)
    📞 strip (line 42)
    📞 replace (line 42)
    📞 replace (line 42)
    📞 user_input_lower.replace (line 42)

📄 Core\AI\PyGenesisAssistant\Nova\core\tasks.py
  Imports:
    📦 dataclasses.dataclass
    📦 dataclasses.field
    📦 datetime.datetime
    📦 enum.Enum
    📦 typing.List
    📦 typing.Optional
    📦 uuid.uuid4
  Calls:
    📞 field (line 30)
    📞 str (line 30)
    📞 uuid4 (line 30)
    📞 field (line 35)
    📞 field (line 44)
    📞 datetime.now (line 51)
    📞 datetime.now (line 56)
    📞 isoformat (line 68)
    📞 isoformat (line 69)
    📞 isoformat (line 70)

📄 Core\AI\PyGenesisAssistant\Nova\core\test_api_manifest.py
  Imports:
    📦 api_manifest.API_SURFACE
    📦 api_manifest.RESOURCE_TYPES
    📦 api_manifest.get_validator
    📦 api_manifest.validate_operation
  Calls:
    📞 print (line 11)
    📞 print (line 12)
    📞 list (line 12)
    📞 API_SURFACE.keys (line 12)
    📞 print (line 13)
    📞 print (line 14)
    📞 print (line 17)
    📞 validate_operation (line 27)
    📞 print (line 28)
    📞 print (line 29)

📄 Core\AI\PyGenesisAssistant\Nova\core\transaction_manager.py
  Imports:
    📦 copy
    📦 dataclasses.dataclass
    📦 dataclasses.field
    📦 datetime.datetime
    📦 datetime.timedelta
    📦 enum.Enum
    📦 json
    📦 os
    📦 shutil
    📦 typing.Any
    📦 typing.Callable
    📦 typing.Dict
    📦 typing.List
    📦 typing.Optional
    📦 uuid.uuid4
  Calls:
    📞 field (line 39)
    📞 field (line 47)
    📞 field (line 48)
    📞 self._setup_backup_dir (line 71)
    📞 hasattr (line 75)
    📞 get_project_path (line 76)
    📞 join (line 78)
    📞 os.makedirs (line 79)
    📞 str (line 91)
    📞 uuid4 (line 91)

📄 Core\AI\PyGenesisAssistant\Nova\main.py
  Imports:
    📦 PySide6.QtWidgets.QApplication
    📦 sys
    📦 ui.main_window.MainWindow
  Calls:
    📞 print (line 16)
    📞 print (line 17)
    📞 print (line 18)
    📞 QApplication (line 20)
    📞 MainWindow (line 21)
    📞 window.show (line 22)
    📞 sys.exit (line 23)
    📞 app.exec (line 23)

📄 Core\AI\PyGenesisAssistant\Nova\core\workflow.py
  Imports:
    📦 core.api_manifest.get_validator
    📦 core.context_analyzer.ContextAnalyzer
    📦 core.feedback_handler.FeedbackHandler
    📦 core.intent_router.IntentRouter
    📦 core.language_utils.Language
    📦 core.language_utils.LanguageUtils
    📦 core.models.ClarificationContext
    📦 core.models.ConfidenceBand
    📦 core.models.ConversationState
    📦 core.models.Intent
    📦 core.models.ResponseStrategy
    📦 core.models.UserMode
    📦 core.operation_planner.OperationPlanner
    📦 core.project_scanner.ProjectScanner
    📦 core.response_templates.format_clarification_request
    📦 core.response_templates.format_confirmation_request
    📦 core.response_templates.format_execution_report
    📦 core.response_templates.format_explanation_response
    📦 core.response_templates.format_options_response
    📦 core.response_templates.format_plan_preview
    📦 core.response_templates.get_follow_up_question
    📦 core.response_templates.get_greeting_response
    📦 core.response_templates.get_meta_prefix
    📦 core.task_name_generator.TaskNameGenerator
    📦 core.tasks.TaskManager
    📦 core.tasks.TaskStatus
    📦 core.transaction_manager.TransactionManager
    📦 dataclasses.dataclass
    📦 os
    📦 pathlib.Path
    📦 settings.SETTINGS
    📦 typing.Any
    📦 typing.Dict
    📦 typing.List
    📦 typing.Optional
  Calls:
    📞 ProjectScanner (line 71)
    📞 IntentRouter (line 73)
    📞 TaskManager (line 74)
    📞 TaskNameGenerator (line 75)
    📞 OperationPlanner (line 80)
    📞 TransactionManager (line 83)
    📞 ContextAnalyzer (line 87)
    📞 ConversationState (line 90)
    📞 self._init_language_utils (line 99)
    📞 hasattr (line 116)

📄 Core\AI\PyGenesisAssistant\Nova\settings.py
  Imports:
    📦 dataclasses.asdict
    📦 dataclasses.dataclass
    📦 json
    📦 os
    📦 pathlib.Path
    📦 sys
    📦 typing.Literal
  Calls:
    📞 Path (line 23)
    📞 asdict (line 28)
    📞 settings_dict.pop (line 30)
    📞 open (line 31)
    📞 json.dump (line 32)
    📞 print (line 34)
    📞 cls (line 39)
    📞 any (line 45)
    📞 str (line 45)
    📞 values (line 45)

📄 Core\AI\PyGenesisAssistant\Nova\themes.py
  Imports:
    📦 json
    📦 os
    📦 pathlib.Path
    📦 settings.SETTINGS
    📦 typing.Dict
  Calls:
    📞 Path (line 17)
    📞 THEMES_JSON_PATH.exists (line 22)
    📞 open (line 24)
    📞 json.load (line 25)
    📞 print (line 27)
    📞 _get_default_themes (line 28)
    📞 _get_default_themes (line 31)
    📞 _save_themes (line 32)
    📞 open (line 85)
    📞 json.dump (line 86)

📄 Core\AI\PyGenesisAssistant\Nova\ui\__init__.py

📄 Core\AI\PyGenesisAssistant\Nova\ui\chat_view.py
  Imports:
    📦 PySide6.QtCore.Qt
    📦 PySide6.QtGui.QFont
    📦 PySide6.QtWidgets.QFrame
    📦 PySide6.QtWidgets.QHBoxLayout
    📦 PySide6.QtWidgets.QLabel
    📦 PySide6.QtWidgets.QScrollArea
    📦 PySide6.QtWidgets.QSizePolicy
    📦 PySide6.QtWidgets.QVBoxLayout
    📦 PySide6.QtWidgets.QWidget
    📦 core.models.ChatMessage
    📦 core.models.Sender
    📦 datetime.datetime
    📦 settings.SETTINGS
    📦 themes.current_palette
    📦 typing.List
    📦 ui.preview_dialog.PreviewDialog
    📦 ui.preview_widget.PreviewButtonWidget
    📦 ui.preview_widget.ThinkingWidget
  Calls:
    📞 __init__ (line 24)
    📞 super (line 24)
    📞 current_palette (line 26)
    📞 QHBoxLayout (line 29)
    📞 layout.setContentsMargins (line 30)
    📞 layout.setSpacing (line 31)
    📞 hasattr (line 38)
    📞 get (line 40)
    📞 user_name.strip (line 41)
    📞 user_name.upper (line 45)

📄 Core\AI\PyGenesisAssistant\Nova\ui\conversations_dialog.py
  Imports:
    📦 PySide6.QtCore.Qt
    📦 PySide6.QtCore.Signal
    📦 PySide6.QtGui.QFont
    📦 PySide6.QtGui.QIcon
    📦 PySide6.QtWidgets.QDialog
    📦 PySide6.QtWidgets.QDialogButtonBox
    📦 PySide6.QtWidgets.QHBoxLayout
    📦 PySide6.QtWidgets.QInputDialog
    📦 PySide6.QtWidgets.QLabel
    📦 PySide6.QtWidgets.QLineEdit
    📦 PySide6.QtWidgets.QListWidget
    📦 PySide6.QtWidgets.QListWidgetItem
    📦 PySide6.QtWidgets.QMenu
    📦 PySide6.QtWidgets.QMessageBox
    📦 PySide6.QtWidgets.QPushButton
    📦 PySide6.QtWidgets.QVBoxLayout
    📦 PySide6.QtWidgets.QWidget
    📦 core.conversations.Conversation
    📦 core.conversations.ConversationManager
    📦 datetime.datetime
    📦 themes.current_palette
  Calls:
    📞 __init__ (line 20)
    📞 super (line 20)
    📞 QHBoxLayout (line 24)
    📞 layout.setContentsMargins (line 25)
    📞 layout.setSpacing (line 26)
    📞 QPushButton (line 29)
    📞 setFixedSize (line 30)
    📞 setToolTip (line 31)
    📞 connect (line 35)
    📞 current_palette (line 36)

📄 Core\AI\PyGenesisAssistant\Nova\ui\header.py
  Imports:
    📦 PySide6.QtGui.QFont
    📦 PySide6.QtWidgets.QHBoxLayout
    📦 PySide6.QtWidgets.QLabel
    📦 PySide6.QtWidgets.QPushButton
    📦 PySide6.QtWidgets.QVBoxLayout
    📦 PySide6.QtWidgets.QWidget
    📦 settings.SETTINGS
    📦 themes.current_palette
  Calls:
    📞 __init__ (line 9)
    📞 super (line 9)
    📞 QHBoxLayout (line 18)
    📞 layout.setContentsMargins (line 19)
    📞 QLabel (line 21)
    📞 title.setObjectName (line 22)
    📞 QFont (line 23)
    📞 title_font.setPointSize (line 24)
    📞 title_font.setWeight (line 25)
    📞 title.setFont (line 26)

📄 Core\AI\PyGenesisAssistant\Nova\ui\input_bar.py
  Imports:
    📦 PySide6.QtCore.QTimer
    📦 PySide6.QtCore.Qt
    📦 PySide6.QtCore.Signal
    📦 PySide6.QtGui.QFont
    📦 PySide6.QtGui.QKeyEvent
    📦 PySide6.QtWidgets.QHBoxLayout
    📦 PySide6.QtWidgets.QLabel
    📦 PySide6.QtWidgets.QPushButton
    📦 PySide6.QtWidgets.QSizePolicy
    📦 PySide6.QtWidgets.QTextEdit
    📦 PySide6.QtWidgets.QVBoxLayout
    📦 PySide6.QtWidgets.QWidget
    📦 settings.SETTINGS
    📦 themes.current_palette
  Calls:
    📞 Signal (line 18)
    📞 event.key (line 21)
    📞 event.modifiers (line 21)
    📞 emit (line 23)
    📞 keyPressEvent (line 25)
    📞 super (line 25)
    📞 __init__ (line 31)
    📞 super (line 31)
    📞 self.setFixedSize (line 32)
    📞 self.setStyleSheet (line 33)

📄 Core\AI\PyGenesisAssistant\Nova\ui\preview_dialog.py
  Imports:
    📦 PySide6.QtCore.Qt
    📦 PySide6.QtGui.QColor
    📦 PySide6.QtGui.QSyntaxHighlighter
    📦 PySide6.QtGui.QTextCharFormat
    📦 PySide6.QtWidgets.QDialog
    📦 PySide6.QtWidgets.QDialogButtonBox
    📦 PySide6.QtWidgets.QGroupBox
    📦 PySide6.QtWidgets.QHBoxLayout
    📦 PySide6.QtWidgets.QLabel
    📦 PySide6.QtWidgets.QPushButton
    📦 PySide6.QtWidgets.QScrollArea
    📦 PySide6.QtWidgets.QTextEdit
    📦 PySide6.QtWidgets.QVBoxLayout
    📦 PySide6.QtWidgets.QWidget
    📦 core.operation_planner.OperationPlan
    📦 difflib
    📦 typing.Optional
    📦 ui.preview_widget.DiffHighlighter
    📦 ui.preview_widget.FilePreviewWidget
  Calls:
    📞 __init__ (line 22)
    📞 super (line 22)
    📞 self.setWindowTitle (line 24)
    📞 self.setModal (line 25)
    📞 self.resize (line 26)
    📞 self.setup_ui (line 27)
    📞 QVBoxLayout (line 31)
    📞 layout.setContentsMargins (line 32)
    📞 layout.setSpacing (line 33)
    📞 QLabel (line 36)

📄 Core\AI\PyGenesisAssistant\Nova\ui\preview_widget.py
  Imports:
    📦 PySide6.QtCore.Qt
    📦 PySide6.QtCore.Signal
    📦 PySide6.QtGui.QColor
    📦 PySide6.QtGui.QSyntaxHighlighter
    📦 PySide6.QtGui.QTextCharFormat
    📦 PySide6.QtGui.QTextCursor
    📦 PySide6.QtGui.QTextDocument
    📦 PySide6.QtWidgets.QFrame
    📦 PySide6.QtWidgets.QGroupBox
    📦 PySide6.QtWidgets.QHBoxLayout
    📦 PySide6.QtWidgets.QLabel
    📦 PySide6.QtWidgets.QPushButton
    📦 PySide6.QtWidgets.QScrollArea
    📦 PySide6.QtWidgets.QTextEdit
    📦 PySide6.QtWidgets.QVBoxLayout
    📦 PySide6.QtWidgets.QWidget
    📦 difflib
    📦 typing.Dict
    📦 typing.List
    📦 typing.Optional
  Calls:
    📞 __init__ (line 20)
    📞 super (line 20)
    📞 QTextCharFormat (line 21)
    📞 setBackground (line 22)
    📞 QColor (line 22)
    📞 setForeground (line 23)
    📞 QColor (line 23)
    📞 QTextCharFormat (line 25)
    📞 setBackground (line 26)
    📞 QColor (line 26)

📄 Core\AI\PyGenesisAssistant\Nova\ui\theme_editor.py
  Imports:
    📦 PySide6.QtGui.QColor
    📦 PySide6.QtWidgets.QColorDialog
    📦 PySide6.QtWidgets.QDialog
    📦 PySide6.QtWidgets.QFrame
    📦 PySide6.QtWidgets.QGridLayout
    📦 PySide6.QtWidgets.QHBoxLayout
    📦 PySide6.QtWidgets.QLabel
    📦 PySide6.QtWidgets.QLineEdit
    📦 PySide6.QtWidgets.QPushButton
    📦 PySide6.QtWidgets.QScrollArea
    📦 PySide6.QtWidgets.QVBoxLayout
    📦 PySide6.QtWidgets.QWidget
    📦 themes.DEFAULT_THEMES
    📦 themes.THEMES
    📦 themes.current_palette
    📦 themes.update_theme
  Calls:
    📞 __init__ (line 15)
    📞 super (line 15)
    📞 QHBoxLayout (line 19)
    📞 layout.setContentsMargins (line 20)
    📞 layout.setSpacing (line 21)
    📞 QLabel (line 23)
    📞 name_label.setMinimumWidth (line 24)
    📞 layout.addWidget (line 25)
    📞 QLineEdit (line 27)
    📞 setText (line 28)

📄 Core\AI\PyGenesisAssistant\Nova\ui\project_management_dialog.py
  Imports:
    📦 PySide6.QtCore.QModelIndex
    📦 PySide6.QtCore.QThread
    📦 PySide6.QtCore.QTimer
    📦 PySide6.QtCore.Qt
    📦 PySide6.QtCore.Signal
    📦 PySide6.QtWidgets.QDialog
    📦 PySide6.QtWidgets.QFileSystemModel
    📦 PySide6.QtWidgets.QHBoxLayout
    📦 PySide6.QtWidgets.QLabel
    📦 PySide6.QtWidgets.QMessageBox
    📦 PySide6.QtWidgets.QProgressBar
    📦 PySide6.QtWidgets.QPushButton
    📦 PySide6.QtWidgets.QSplitter
    📦 PySide6.QtWidgets.QTabWidget
    📦 PySide6.QtWidgets.QTextEdit
    📦 PySide6.QtWidgets.QTreeWidget
    📦 PySide6.QtWidgets.QTreeWidgetItem
    📦 PySide6.QtWidgets.QVBoxLayout
    📦 PySide6.QtWidgets.QWidget
    📦 core.codebase_analyzer.CodebaseAnalyzer
    📦 pathlib.Path
    📦 sys
    📦 themes.current_palette
  Calls:
    📞 Signal (line 22)
    📞 Signal (line 23)
    📞 __init__ (line 26)
    📞 super (line 26)
    📞 CodebaseAnalyzer (line 29)
    📞 emit (line 34)
    📞 analyze_codebase (line 35)
    📞 emit (line 36)
    📞 emit (line 38)
    📞 analyze_dependencies (line 39)

📄 Core\AI\PyGenesisAssistant\Nova\ui\tasks_dialog.py
  Imports:
    📦 PySide6.QtCore.Qt
    📦 PySide6.QtCore.Signal
    📦 PySide6.QtGui.QFont
    📦 PySide6.QtWidgets.QDialog
    📦 PySide6.QtWidgets.QFrame
    📦 PySide6.QtWidgets.QHBoxLayout
    📦 PySide6.QtWidgets.QLabel
    📦 PySide6.QtWidgets.QListWidget
    📦 PySide6.QtWidgets.QListWidgetItem
    📦 PySide6.QtWidgets.QPushButton
    📦 PySide6.QtWidgets.QScrollArea
    📦 PySide6.QtWidgets.QVBoxLayout
    📦 PySide6.QtWidgets.QWidget
    📦 core.tasks.Task
    📦 core.tasks.TaskManager
    📦 core.tasks.TaskStatus
    📦 datetime.datetime
    📦 settings.SETTINGS
    📦 themes.current_palette
    📦 typing.Optional
  Calls:
    📞 Signal (line 32)
    📞 Signal (line 33)
    📞 Signal (line 34)
    📞 Signal (line 35)
    📞 __init__ (line 38)
    📞 super (line 38)
    📞 self._build_ui (line 40)
    📞 self._apply_style (line 41)
    📞 QHBoxLayout (line 45)
    📞 layout.setContentsMargins (line 46)

📄 Core\AI\PyGenesisAssistant\Nova\ui\settings_dialog.py
  Imports:
    📦 PySide6.QtWidgets.QCheckBox
    📦 PySide6.QtWidgets.QComboBox
    📦 PySide6.QtWidgets.QDialog
    📦 PySide6.QtWidgets.QDialogButtonBox
    📦 PySide6.QtWidgets.QHBoxLayout
    📦 PySide6.QtWidgets.QLabel
    📦 PySide6.QtWidgets.QLineEdit
    📦 PySide6.QtWidgets.QListWidget
    📦 PySide6.QtWidgets.QListWidgetItem
    📦 PySide6.QtWidgets.QMessageBox
    📦 PySide6.QtWidgets.QPushButton
    📦 PySide6.QtWidgets.QTabWidget
    📦 PySide6.QtWidgets.QVBoxLayout
    📦 PySide6.QtWidgets.QWidget
    📦 settings.SETTINGS
    📦 themes.DEFAULT_THEMES
    📦 themes.THEMES
    📦 themes.add_custom_theme
    📦 themes.current_palette
    📦 themes.remove_custom_theme
    📦 themes.rename_theme
    📦 ui.theme_editor.ThemeEditor
  Calls:
    📞 __init__ (line 12)
    📞 super (line 12)
    📞 current_palette (line 13)
    📞 QVBoxLayout (line 15)
    📞 layout.setSpacing (line 16)
    📞 QHBoxLayout (line 19)
    📞 theme_row.addWidget (line 20)
    📞 QLabel (line 20)
    📞 QComboBox (line 21)
    📞 addItems (line 22)

📄 Core\AI\PyGenesisAssistant\NovaWidget.py
  Imports:
    📦 PySide6.QtCore.QTimer
    📦 PySide6.QtCore.Qt
    📦 PySide6.QtCore.Signal
    📦 PySide6.QtGui.QAction
    📦 PySide6.QtWidgets.QApplication
    📦 PySide6.QtWidgets.QHBoxLayout
    📦 PySide6.QtWidgets.QMainWindow
    📦 PySide6.QtWidgets.QPushButton
    📦 PySide6.QtWidgets.QToolBar
    📦 PySide6.QtWidgets.QVBoxLayout
    📦 PySide6.QtWidgets.QWidget
    📦 UI.CommonDialogs.PreferencesDialog.PreferencesDialog
    📦 core.conversations.ConversationManager
    📦 core.engines.conversation_engine.ConversationEngine
    📦 core.engines.dictionary_engine.DictionaryEngine
    📦 core.engines.math_engine.MathEngine
    📦 core.engines.research_engine.ResearchEngine
    📦 core.engines.thesaurus_engine.ThesaurusEngine
    📦 core.executors.code_query_executor.CodeQueryExecutor
    📦 core.executors.code_search_executor.CodeSearchExecutor
    📦 core.executors.graph_visualization_executor.GraphVisualizationExecutor
    📦 core.executors.project_modification_executor.ProjectModificationExecutor
    📦 core.executors.resource_operation_executor.ResourceOperationExecutor
    📦 core.models.ChatMessage
    📦 core.models.Intent
    📦 core.models.Sender
    📦 core.tasks.TaskManager
    📦 core.workflow.WorkflowPipeline
    📦 datetime.datetime
    📦 os
    📦 pathlib.Path
    📦 settings.SETTINGS
    📦 sys
    📦 themes.current_palette
    📦 traceback
    📦 ui.chat_view.ChatView
    📦 ui.conversations_dialog.ConversationsDialog
    📦 ui.header.Header
    📦 ui.input_bar.InputBar
    📦 ui.project_management_dialog.ProjectManagementDialog
    📦 ui.tasks_dialog.TasksDialog
  Calls:
    📞 Path (line 18)
    📞 str (line 19)
    📞 insert (line 20)
    📞 str (line 20)
    📞 __init__ (line 29)
    📞 super (line 29)
    📞 connect (line 38)
    📞 get_project_path (line 41)
    📞 Path (line 44)
    📞 project_root.exists (line 45)

📄 Core\Code\Base\__init__.py
  Imports:
    📦 base_syntax_highlighter.BaseSyntaxHighlighter
    📦 base_syntax_highlighter.PythonSyntaxHighlighter

📄 Core\Code\Base\base_syntax_highlighter.py
  Imports:
    📦 PySide6.QtCore.QRegularExpression
    📦 PySide6.QtGui.QColor
    📦 PySide6.QtGui.QSyntaxHighlighter
    📦 PySide6.QtGui.QTextCharFormat
    📦 re
  Calls:
    📞 __init__ (line 15)
    📞 super (line 15)
    📞 self._setup_highlighting (line 17)
    📞 pattern.finditer (line 26)
    📞 match.span (line 27)
    📞 self.setFormat (line 28)
    📞 QTextCharFormat (line 36)
    📞 keyword_format.setForeground (line 37)
    📞 QColor (line 37)
    📞 keyword_format.setFontWeight (line 38)

📄 Core\Code\PGSL\__init__.py
  Imports:
    📦 pgsl_parser.PGSLParser
    📦 pgsl_runtime.PGSLRuntime

📄 Core\Code\PGSL\Parser.py
  Imports:
    📦 PGSL_Commands.PGSLCommandSpec
    📦 PGSL_Commands.PGSL_COMMANDS
    📦 __future__.annotations
    📦 contextlib.redirect_stdout
    📦 io
    📦 math
    📦 numpy
    📦 sys
    📦 typing.Dict
    📦 typing.Tuple
  Calls:
    📞 line.strip (line 31)
    📞 stripped.endswith (line 32)
    📞 PGSLParserError (line 33)
    📞 stripped.find (line 35)
    📞 PGSLParserError (line 37)
    📞 strip (line 39)
    📞 strip (line 40)
    📞 parts.append (line 57)
    📞 strip (line 57)
    📞 join (line 57)

📄 Core\Code\PGSL\PGSL_Commands.py
  Imports:
    📦 __future__.annotations
    📦 dataclasses.dataclass
    📦 numpy
    📦 typing.Dict
    📦 typing.List
  Calls:
    📞 PGSLCommandSpec (line 34)
    📞 PGSLCommandSpec (line 40)
    📞 PGSLCommandSpec (line 46)
    📞 PGSLCommandSpec (line 52)
    📞 PGSLCommandSpec (line 58)
    📞 PGSLCommandSpec (line 64)
    📞 PGSLCommandSpec (line 70)
    📞 PGSLCommandSpec (line 76)
    📞 PGSLCommandSpec (line 82)
    📞 PGSLCommandSpec (line 88)

📄 Core\Code\Shared\__init__.py
  Imports:
    📦 script_validator.ScriptValidator

📄 Core\Code\PGSL\pgsl_runtime.py
  Imports:
    📦 math
    📦 pygame
    📦 random
    📦 typing.Any
    📦 typing.Dict
    📦 typing.List
    📦 typing.Optional
    📦 typing.Tuple
  Calls:
    📞 set_mode (line 63)
    📞 set_caption (line 69)
    📞 cls.instance_find (line 109)
    📞 cls.instance_find (line 118)
    📞 get (line 129)
    📞 len (line 135)
    📞 cls.instance_find (line 135)
    📞 cls.instance_get_count (line 140)
    📞 isinstance (line 151)
    📞 cls.instance_find_id (line 151)

📄 Core\Code\Shared\code_completer.py
  Imports:
    📦 PySide6.QtCore.QPoint
    📦 PySide6.QtCore.QTimer
    📦 PySide6.QtCore.Qt
    📦 PySide6.QtCore.Signal
    📦 PySide6.QtGui.QFont
    📦 PySide6.QtGui.QTextCursor
    📦 PySide6.QtWidgets.QFrame
    📦 PySide6.QtWidgets.QLabel
    📦 PySide6.QtWidgets.QListWidget
    📦 PySide6.QtWidgets.QListWidgetItem
    📦 PySide6.QtWidgets.QVBoxLayout
    📦 PySide6.QtWidgets.QWidget
    📦 keyword
    📦 re
    📦 typing.Dict
    📦 typing.List
    📦 typing.Optional
    📦 typing.Tuple
  Calls:
    📞 Signal (line 21)
    📞 __init__ (line 24)
    📞 super (line 24)
    📞 self.setup_ui (line 25)
    📞 self.hide (line 30)
    📞 QTimer (line 33)
    📞 setSingleShot (line 34)
    📞 connect (line 35)
    📞 QVBoxLayout (line 39)
    📞 layout.setContentsMargins (line 40)

📄 Core\Code\Unified\__init__.py
  Imports:
    📦 acceptance_contract.AcceptanceResult
    📦 acceptance_contract.CodeAcceptanceContract
    📦 execution_engine.ExecutionResult
    📦 execution_engine.SandboxedExecutionEngine
    📦 types.CodeMode
    📦 types.EditorContext
    📦 unified_code_editor.DiagnosticsPanel
    📦 unified_code_editor.UnifiedCodeEditor
    📦 validation_pipeline.Diagnostic
    📦 validation_pipeline.DiagnosticType
    📦 validation_pipeline.UnifiedValidationPipeline

📄 Core\AI\PyGenesisAssistant\UnifiedCodeAnalyzer.py
  Imports:
    📦 ast
    📦 collections.defaultdict
    📦 concurrent.futures.ProcessPoolExecutor
    📦 concurrent.futures.ThreadPoolExecutor
    📦 concurrent.futures.as_completed
    📦 functools.lru_cache
    📦 hashlib
    📦 json
    📦 multiprocessing
    📦 os
    📦 pathlib.Path
    📦 pickle
    📦 sys
    📦 threading
    📦 time
    📦 tkinter
    📦 tkinter.filedialog
    📦 tkinter.messagebox
    📦 tkinter.scrolledtext
    📦 tkinter.ttk
    📦 traceback
    📦 typing.Any
    📦 typing.Dict
    📦 typing.List
    📦 typing.Optional
    📦 typing.Set
    📦 typing.Tuple
  Calls:
    📞 max (line 30)
    📞 multiprocessing.cpu_count (line 30)
    📞 Path.home (line 31)
    📞 mkdir (line 40)
    📞 file_path.stat (line 48)
    📞 hexdigest (line 49)
    📞 hashlib.md5 (line 49)
    📞 encode (line 49)
    📞 hexdigest (line 51)
    📞 hashlib.md5 (line 51)

📄 Core\Code\Shared\script_validator.py
  Imports:
    📦 ast
    📦 collections.defaultdict
    📦 importlib.util
    📦 inspect
    📦 io.StringIO
    📦 os
    📦 pathlib.Path
    📦 sys
    📦 traceback
    📦 typing.Any
    📦 typing.Callable
    📦 typing.Dict
    📦 typing.List
    📦 typing.Optional
    📦 typing.Set
    📦 typing.Tuple
    📦 unicodedata
  Calls:
    📞 Path (line 111)
    📞 self.output_callback (line 117)
    📞 code.strip (line 144)
    📞 self._clean_code_string (line 149)
    📞 compile (line 155)
    📞 ast.parse (line 156)
    📞 append (line 159)
    📞 self._output (line 160)
    📞 self._output (line 162)
    📞 strip (line 162)

📄 Core\Code\PGSL\pgsl_parser.py
  Imports:
    📦 ast
    📦 re
    📦 typing.List
    📦 typing.Optional
    📦 typing.Tuple
  Calls:
    📞 self._build_command_patterns (line 20)
    📞 patterns.append (line 27)
    📞 re.compile (line 27)
    📞 patterns.append (line 28)
    📞 re.compile (line 28)
    📞 patterns.append (line 29)
    📞 re.compile (line 29)
    📞 m.group (line 30)
    📞 patterns.append (line 31)
    📞 re.compile (line 31)

📄 Core\Code\Unified\acceptance_contract.py
  Imports:
    📦 Core.Code.Unified.types.CodeMode
    📦 Core.Code.Unified.types.EditorContext
    📦 Core.Code.Unified.validation_pipeline.Diagnostic
    📦 Core.Code.Unified.validation_pipeline.UnifiedValidationPipeline
    📦 enum.Enum
    📦 typing.List
    📦 typing.Optional
    📦 typing.Tuple
  Calls:
    📞 len (line 42)
    📞 len (line 43)
    📞 UnifiedValidationPipeline (line 61)
    📞 code.strip (line 82)
    📞 AcceptanceResult (line 83)
    📞 validate (line 89)
    📞 AcceptanceResult (line 97)
    📞 len (line 99)
    📞 AcceptanceResult (line 105)
    📞 len (line 107)

📄 Core\Code\Unified\execution_engine.py
  Imports:
    📦 Core.Code.Unified.types.CodeMode
    📦 ast
    📦 builtins
    📦 contextlib.redirect_stderr
    📦 contextlib.redirect_stdout
    📦 enum.Enum
    📦 io
    📦 pathlib.Path
    📦 sys
    📦 traceback
    📦 typing.Any
    📦 typing.Dict
    📦 typing.List
    📦 typing.Optional
    📦 typing.Tuple
  Calls:
    📞 str (line 48)
    📞 str (line 49)
    📞 items (line 49)
    📞 code.strip (line 95)
    📞 ExecutionResult (line 96)
    📞 self._execute_pgsl (line 103)
    📞 self._execute_python (line 106)
    📞 ExecutionResult (line 108)
    📞 ExecutionResult (line 124)
    📞 io.StringIO (line 146)

📄 Core\Code\Unified\types.py
  Imports:
    📦 enum.Enum

📄 Core\Code\Unified\test_harness.py
  Imports:
    📦 Core.Code.Unified.CodeMode
    📦 Core.Code.Unified.EditorContext
    📦 Core.Code.Unified.UnifiedCodeEditor
    📦 PySide6.QtCore.Qt
    📦 PySide6.QtWidgets.QLabel
    📦 PySide6.QtWidgets.QMainWindow
    📦 PySide6.QtWidgets.QPushButton
    📦 PySide6.QtWidgets.QTextEdit
    📦 PySide6.QtWidgets.QVBoxLayout
    📦 PySide6.QtWidgets.QWidget
  Calls:
    📞 __init__ (line 20)
    📞 super (line 20)
    📞 self.setWindowTitle (line 22)
    📞 self.resize (line 23)
    📞 QWidget (line 26)
    📞 QVBoxLayout (line 27)
    📞 layout.setContentsMargins (line 28)
    📞 QLabel (line 31)
    📞 title.setStyleSheet (line 32)
    📞 layout.addWidget (line 33)

📄 Core\Code\Unified\validation_pipeline.py
  Imports:
    📦 Core.Code.Shared.script_validator.ScriptValidator
    📦 Core.Code.Unified.types.CodeMode
    📦 Core.Code.Unified.types.EditorContext
    📦 Core.CodeSystem.parser.PGSLParser
    📦 Core.CodeSystem.parser.ParseError
    📦 Core.CodeSystem.syntax.SyntaxValidator
    📦 ast
    📦 enum.Enum
    📦 traceback
    📦 typing.Dict
    📦 typing.List
    📦 typing.Optional
    📦 typing.Tuple
  Calls:
    📞 PGSLSyntaxValidator (line 80)
    📞 ScriptValidator (line 86)
    📞 self._validate_pgsl (line 113)
    📞 self._validate_python (line 115)
    📞 Diagnostic (line 118)
    📞 code.strip (line 142)
    📞 validate (line 148)
    📞 Diagnostic (line 152)
    📞 err.get (line 153)
    📞 str (line 153)

📄 Core\CodeSystem\__init__.py
  Imports:
    📦 ast.ASTNode
    📦 ast.ASTVisitor
    📦 lexer.Lexer
    📦 lexer.Token
    📦 lexer.TokenType
    📦 parser.PGSLParser
    📦 syntax.SyntaxHighlighter
    📦 syntax.SyntaxValidator

📄 Core\CodeSystem\ast.py
  Imports:
    📦 abc.ABC
    📦 abc.abstractmethod
    📦 enum.Enum
    📦 typing.Any
    📦 typing.Dict
    📦 typing.List
    📦 typing.Optional
  Calls:
    📞 append (line 44)
    📞 __init__ (line 59)
    📞 super (line 59)
    📞 self.add_child (line 62)
    📞 visitor.visit_program (line 65)
    📞 __init__ (line 72)
    📞 super (line 72)
    📞 self.add_child (line 75)
    📞 visitor.visit_block (line 78)
    📞 __init__ (line 85)

📄 Core\CodeSystem\lexer.py
  Imports:
    📦 enum.Enum
    📦 re
    📦 typing.List
    📦 typing.Optional
    📦 typing.Tuple
  Calls:
    📞 isinstance (line 86)
    📞 len (line 127)
    📞 len (line 134)
    📞 len (line 140)
    📞 self.current_char (line 156)
    📞 self.current_char (line 156)
    📞 self.advance (line 157)
    📞 self.current_char (line 164)
    📞 isdigit (line 164)
    📞 self.current_char (line 164)

📄 Core\Code\Unified\unified_code_editor.py
  Imports:
    📦 Core.Code.Base.base_syntax_highlighter.PythonSyntaxHighlighter
    📦 Core.Code.PGSL.PGSL_Commands.get_all_command_names
    📦 Core.CodeSystem.syntax.SyntaxHighlighter
    📦 PySide6.QtCore.QRegularExpression
    📦 PySide6.QtCore.QTimer
    📦 PySide6.QtCore.Qt
    📦 PySide6.QtCore.Signal
    📦 PySide6.QtGui.QColor
    📦 PySide6.QtGui.QFont
    📦 PySide6.QtGui.QSyntaxHighlighter
    📦 PySide6.QtGui.QTextCharFormat
    📦 PySide6.QtGui.QTextCursor
    📦 PySide6.QtWidgets.QComboBox
    📦 PySide6.QtWidgets.QFrame
    📦 PySide6.QtWidgets.QHBoxLayout
    📦 PySide6.QtWidgets.QLabel
    📦 PySide6.QtWidgets.QMessageBox
    📦 PySide6.QtWidgets.QPushButton
    📦 PySide6.QtWidgets.QScrollArea
    📦 PySide6.QtWidgets.QTextEdit
    📦 PySide6.QtWidgets.QVBoxLayout
    📦 PySide6.QtWidgets.QWidget
    📦 enum.Enum
    📦 execution_engine.ExecutionResult
    📦 execution_engine.SandboxedExecutionEngine
    📦 pathlib.Path
    📦 re
    📦 types.CodeMode
    📦 types.EditorContext
    📦 typing.Any
    📦 typing.Dict
    📦 typing.List
    📦 typing.Optional
    📦 validation_pipeline.Diagnostic
    📦 validation_pipeline.UnifiedValidationPipeline
  Calls:
    📞 __init__ (line 36)
    📞 super (line 36)
    📞 self.setup_ui (line 37)
    📞 QVBoxLayout (line 42)
    📞 layout.setContentsMargins (line 43)
    📞 layout.setSpacing (line 44)
    📞 QPushButton (line 47)
    📞 setStyleSheet (line 48)
    📞 connect (line 63)
    📞 layout.addWidget (line 64)

📄 Core\Debug.py
  Imports:
    📦 sys
  Calls:
    📞 __new__ (line 14)
    📞 super (line 14)
    📞 get (line 34)
    📞 isinstance (line 36)
    📞 debug_value.lower (line 37)
    📞 bool (line 39)
    📞 DebugManager (line 54)
    📞 _debug_manager.is_debug_enabled (line 61)
    📞 print (line 62)
    📞 flush (line 63)

📄 Core\CodeSystem\syntax.py
  Imports:
    📦 PySide6.QtCore.QRegularExpression
    📦 PySide6.QtGui.QColor
    📦 PySide6.QtGui.QSyntaxHighlighter
    📦 PySide6.QtGui.QTextCharFormat
    📦 lexer.Lexer
    📦 lexer.Token
    📦 lexer.TokenType
    📦 parser.PGSLParser
    📦 parser.ParseError
    📦 typing.Dict
    📦 typing.List
    📦 typing.Optional
    📦 typing.Tuple
  Calls:
    📞 __init__ (line 16)
    📞 super (line 16)
    📞 self.setup_highlighting (line 18)
    📞 QTextCharFormat (line 23)
    📞 keyword_format.setForeground (line 24)
    📞 QColor (line 24)
    📞 keyword_format.setFontWeight (line 25)
    📞 QRegularExpression (line 31)
    📞 append (line 32)
    📞 QTextCharFormat (line 35)

📄 Core\CodeSystem\parser.py
  Imports:
    📦 ast.ASTNode
    📦 ast.AssignmentNode
    📦 ast.BinaryOpNode
    📦 ast.BlockNode
    📦 ast.ForLoopNode
    📦 ast.FunctionCallNode
    📦 ast.FunctionDefNode
    📦 ast.IdentifierNode
    📦 ast.IfStatementNode
    📦 ast.LiteralNode
    📦 ast.ProgramNode
    📦 ast.ReturnStatementNode
    📦 ast.UnaryOpNode
    📦 ast.VariableDeclNode
    📦 ast.WhileLoopNode
    📦 lexer.Lexer
    📦 lexer.Token
    📦 lexer.TokenType
    📦 typing.List
    📦 typing.Optional
  Calls:
    📞 __init__ (line 23)
    📞 super (line 23)
    📞 __init__ (line 25)
    📞 super (line 25)
    📞 Lexer (line 32)
    📞 tokenize (line 38)
    📞 self.is_at_end (line 42)
    📞 self.match (line 43)
    📞 self.match (line 46)
    📞 self.statement (line 48)

📄 Core\DeletePyCache.py
  Imports:
    📦 os
    📦 shutil
  Calls:
    📞 os.walk (line 9)
    📞 join (line 12)
    📞 print (line 13)
    📞 shutil.rmtree (line 14)
    📞 abspath (line 17)
    📞 print (line 18)
    📞 delete_pycache (line 19)
    📞 print (line 20)

📄 Core\EditorFactory.py
  Imports:
    📦 Core.Debug.debug
    📦 Core.EditorInterface.EditorInterface
    📦 Editors.BackgroundEditor.BackgroundEditor.BackgroundEditor
    📦 Editors.CodeEditor.ScriptEditor.ScriptEditor
    📦 Editors.ModelEditor.ModelEditor.ModelPreviewWindow
    📦 Editors.ObjectEditor.object_editor.ObjectEditor
    📦 Editors.RoomEditor.RoomEditor.RoomEditor
    📦 Editors.SoundEditor.SoundEditor.SoundEditor
    📦 Editors.SpriteEditor.SpriteEditor.SpriteEditor
    📦 Editors.TextureEditor.TextureEditor.TextureEditor
    📦 PySide6.QtWidgets.QTextEdit
    📦 PySide6.QtWidgets.QWidget
    📦 json
    📦 traceback
    📦 typing.Dict
    📦 typing.Optional
  Calls:
    📞 EditorFactory._create_sprite_editor (line 37)
    📞 EditorFactory._create_background_editor (line 39)
    📞 EditorFactory._create_room_editor (line 41)
    📞 EditorFactory._create_sound_editor (line 43)
    📞 EditorFactory._create_model_editor (line 45)
    📞 EditorFactory._create_texture_editor (line 47)
    📞 EditorFactory._create_object_editor (line 49)
    📞 EditorFactory._create_code_editor (line 51)
    📞 debug (line 53)
    📞 EditorFactory._create_generic_editor (line 54)

📄 Core\EditorInterface.py
  Imports:
    📦 PySide6.QtWidgets.QWidget
    📦 typing.Dict
    📦 typing.Optional
  Calls:
    📞 NotImplementedError (line 31)
    📞 NotImplementedError (line 40)
    📞 NotImplementedError (line 50)
    📞 NotImplementedError (line 60)
    📞 NotImplementedError (line 69)
    📞 NotImplementedError (line 78)
    📞 NotImplementedError (line 87)
    📞 self.is_dirty (line 107)

📄 Core\EditorOptimizer.py
  Imports:
    📦 Core.Debug.debug
    📦 PySide6.QtCore.QSettings
    📦 PySide6.QtCore.QTimer
    📦 PySide6.QtCore.Qt
    📦 PySide6.QtWidgets.QApplication
    📦 PySide6.QtWidgets.QWidget
    📦 traceback
  Calls:
    📞 widget.setUpdatesEnabled (line 21)
    📞 callback (line 23)
    📞 widget.setUpdatesEnabled (line 25)
    📞 QTimer.singleShot (line 33)
    📞 load_preview_callback (line 43)
    📞 debug (line 45)
    📞 debug (line 47)
    📞 traceback.format_exc (line 47)
    📞 QTimer.singleShot (line 49)
    📞 init_opengl_callback (line 59)

📄 Core\Events.py
  Imports:
    📦 Core.Debug.debug
    📦 enum.Enum
    📦 typing.Any
    📦 typing.Callable
    📦 typing.Dict
    📦 typing.List
    📦 typing.Optional
  Calls:
    📞 __new__ (line 67)
    📞 super (line 67)
    📞 debug (line 78)
    📞 append (line 93)
    📞 debug (line 94)
    📞 remove (line 106)
    📞 debug (line 107)
    📞 Event (line 118)
    📞 callback (line 124)
    📞 debug (line 126)

📄 Core\GameGenerator.py
  Imports:
    📦 Core.Code.PGSL.pgsl_parser.PGSLParser
    📦 json
    📦 os
    📦 pathlib.Path
    📦 typing.Dict
    📦 typing.List
    📦 typing.Optional
  Calls:
    📞 Path (line 24)
    📞 project_manager.get_project_path (line 24)
    📞 mkdir (line 26)
    📞 PGSLParser (line 27)
    📞 self._get_rooms (line 38)
    📞 self._generate_main_script (line 43)
    📞 main_file.write_text (line 45)
    📞 self._generate_runtime (line 48)
    📞 runtime_file.write_text (line 50)
    📞 self._generate_objects (line 53)

📄 Core\ExtensionsManager.py
  Imports:
    📦 Core.Debug.debug
    📦 Core.PackageInstaller.UnifiedPackageInstaller
    📦 PySide6.QtCore.QObject
    📦 PySide6.QtCore.Signal
    📦 datetime.datetime
    📦 importlib
    📦 json
    📦 pathlib.Path
    📦 re
    📦 requests
    📦 subprocess
    📦 sys
    📦 traceback
    📦 typing.Dict
    📦 typing.List
    📦 typing.Optional
    📦 typing.Tuple
    📦 urllib.request
  Calls:
    📞 query.lower (line 34)
    📞 name.lower (line 35)
    📞 n.startswith (line 37)
    📞 len (line 38)
    📞 len (line 41)
    📞 len (line 47)
    📞 decode (line 63)
    📞 read (line 63)
    📞 urlopen (line 63)
    📞 re.findall (line 64)

📄 Core\PackageInstaller.py
  Imports:
    📦 PySide6.QtCore.QThread
    📦 PySide6.QtCore.Signal
    📦 importlib
    📦 os
    📦 pathlib.Path
    📦 subprocess
    📦 sys
    📦 typing.Optional
    📦 typing.Tuple
  Calls:
    📞 Signal (line 22)
    📞 Signal (line 23)
    📞 __init__ (line 37)
    📞 super (line 37)
    📞 get_python_executable (line 47)
    📞 str (line 50)
    📞 resolve (line 50)
    📞 Path (line 50)
    📞 self._install_package (line 53)
    📞 self._update_package (line 55)

📄 Core\ModulePreloader.py
  Imports:
    📦 Core.Debug.debug
    📦 Editors.CodeEditor.ScriptEditor.ScriptEditor
    📦 Editors.ModelEditor.ModelEditor.ModelPreviewWindow
    📦 Editors.ObjectEditor.object_editor.ObjectEditor
    📦 Editors.RoomEditor.RoomEditor.RoomEditor
    📦 Editors.SoundEditor.SoundEditor.SoundEditor
    📦 Editors.SoundEditor.core.WaveForge.WaveForge
    📦 Editors.SpriteEditor.SpriteEditor.SpriteEditor
    📦 PySide6.QtCore.QObject
    📦 PySide6.QtCore.QThread
    📦 PySide6.QtCore.QTimer
    📦 PySide6.QtCore.Signal
    📦 core.state.EditorState
    📦 core.state.state
    📦 os
    📦 pathlib.Path
    📦 sys
    📦 traceback
    📦 ui.dialogs.NewImageDialog
    📦 ui.dialogs.UnifiedEffectDialog
    📦 ui.main_window.MainWindow
  Calls:
    📞 Signal (line 15)
    📞 Signal (line 16)
    📞 __init__ (line 19)
    📞 super (line 19)
    📞 Path (line 21)
    📞 self._preload_image_editor (line 27)
    📞 self._preload_sprite_editor (line 29)
    📞 self._preload_sound_editor (line 31)
    📞 self._preload_model_editor (line 33)
    📞 self._preload_room_editor (line 35)

📄 Core\PackageLoadThread.py
  Imports:
    📦 Core.Debug.debug
    📦 Core.ExtensionsManager.ExtensionsManager
    📦 PySide6.QtCore.QThread
    📦 PySide6.QtCore.Signal
    📦 traceback
  Calls:
    📞 Signal (line 14)
    📞 Signal (line 15)
    📞 Signal (line 16)
    📞 Signal (line 17)
    📞 __init__ (line 20)
    📞 super (line 20)
    📞 debug (line 27)
    📞 get_all_installed_libraries (line 28)
    📞 emit (line 29)
    📞 debug (line 32)

📄 Core\PackageSearchThread.py
  Imports:
    📦 Core.Debug.debug
    📦 Core.ExtensionsManager.ExtensionsManager
    📦 PySide6.QtCore.QThread
    📦 PySide6.QtCore.Signal
    📦 traceback
  Calls:
    📞 Signal (line 14)
    📞 Signal (line 15)
    📞 __init__ (line 18)
    📞 super (line 18)
    📞 debug (line 27)
    📞 search_pypi (line 28)
    📞 emit (line 29)
    📞 debug (line 31)
    📞 debug (line 33)
    📞 traceback.format_exc (line 33)

📄 Core\ProjectIndexManager.py
  Imports:
    📦 Core.Debug.debug
    📦 hashlib
    📦 json
    📦 os
    📦 pathlib.Path
    📦 traceback
    📦 typing.Any
    📦 typing.Dict
    📦 typing.List
    📦 typing.Optional
  Calls:
    📞 Path (line 22)
    📞 debug (line 31)
    📞 runtime_resources.items (line 39)
    📞 resources.items (line 42)
    📞 self._extract_metadata (line 44)
    📞 self._get_resource_file_path (line 47)
    📞 file_path.exists (line 48)
    📞 file_path.stat (line 49)
    📞 file_path.stat (line 50)
    📞 open (line 55)

📄 Core\PyPILoadThread.py
  Imports:
    📦 Core.Debug.debug
    📦 Core.ExtensionsManager.ExtensionsManager
    📦 PySide6.QtCore.QThread
    📦 PySide6.QtCore.Signal
    📦 traceback
  Calls:
    📞 Signal (line 14)
    📞 Signal (line 15)
    📞 __init__ (line 18)
    📞 super (line 18)
    📞 debug (line 24)
    📞 load_pypi_names (line 25)
    📞 emit (line 26)
    📞 debug (line 27)
    📞 debug (line 29)
    📞 debug (line 31)

📄 Core\Rendering\__init__.py
  Imports:
    📦 BufferManager.BufferManager
    📦 BufferManager.get_buffer_manager
    📦 Canvas_2D.Canvas_2D
    📦 OpenGLRuntime.OpenGLRuntime
    📦 OpenGLRuntime.get_runtime
    📦 ShaderManager.ShaderManager
    📦 ShaderManager.get_shader_manager
    📦 SuperShader_2D.SuperShader_2D
    📦 SuperShader_2D.get_super_shader_2d
    📦 TextureManager.TextureManager
    📦 TextureManager.get_texture_manager

📄 Core\Rendering\BufferManager.py
  Imports:
    📦 Core.Debug.debug
    📦 Core.Rendering.OpenGLRuntime.get_runtime
    📦 OpenGL.GL
    📦 OpenGL.arrays.vbo
    📦 numpy
    📦 typing.Dict
    📦 typing.List
    📦 typing.Optional
    📦 typing.Tuple
  Calls:
    📞 get_runtime (line 31)
    📞 is_current (line 45)
    📞 make_current (line 46)
    📞 get (line 52)
    📞 GL.glBindBuffer (line 56)
    📞 GL.glBufferSubData (line 57)
    📞 GL.glBindBuffer (line 58)
    📞 get (line 59)
    📞 debug (line 60)
    📞 GL.glGenBuffers (line 64)

📄 Core\Rendering\OpenGLRuntime.py
  Imports:
    📦 Core.Debug.debug
    📦 OpenGL.GL
    📦 PySide6.QtGui.QSurfaceFormat
    📦 PySide6.QtOpenGLWidgets.QOpenGLWidget
    📦 numpy
    📦 typing.Any
    📦 typing.Dict
    📦 typing.Optional
  Calls:
    📞 __new__ (line 25)
    📞 super (line 25)
    📞 debug (line 51)
    📞 debug (line 62)
    📞 widget.makeCurrent (line 66)
    📞 widget.context (line 69)
    📞 context.format (line 71)
    📞 self._query_gl_info (line 74)
    📞 self._setup_default_state (line 77)
    📞 debug (line 80)

📄 Core\Rendering\ShaderManager.py
  Imports:
    📦 Core.Debug.debug
    📦 Core.Rendering.OpenGLRuntime.get_runtime
    📦 OpenGL.GL
    📦 OpenGL.GL.shaders
    📦 pathlib.Path
    📦 typing.Dict
    📦 typing.Optional
    📦 typing.Tuple
  Calls:
    📞 get_runtime (line 26)
    📞 is_current (line 45)
    📞 make_current (line 46)
    📞 get (line 50)
    📞 shaders.compileShader (line 55)
    📞 shaders.compileShader (line 58)
    📞 shaders.compileShader (line 63)
    📞 shader_list.append (line 64)
    📞 shaders.compileProgram (line 67)
    📞 debug (line 74)

📄 Core\Rendering\Canvas_2D.py
  Imports:
    📦 Core.Debug.debug
    📦 Core.Rendering.BufferManager.get_buffer_manager
    📦 Core.Rendering.OpenGLRuntime.get_runtime
    📦 Core.Rendering.SuperShader_2D.get_super_shader_2d
    📦 Core.Rendering.TextureManager.get_texture_manager
    📦 OpenGL.GL
    📦 PySide6.QtCore.QPoint
    📦 PySide6.QtCore.QRect
    📦 PySide6.QtCore.QTimer
    📦 PySide6.QtCore.Qt
    📦 PySide6.QtCore.Signal
    📦 PySide6.QtGui.QSurfaceFormat
    📦 PySide6.QtOpenGLWidgets.QOpenGLWidget
    📦 PySide6.QtWidgets.QWidget
    📦 core.state.state
    📦 numpy
    📦 typing.List
    📦 typing.Optional
    📦 typing.Tuple
  Calls:
    📞 Signal (line 28)
    📞 QSurfaceFormat (line 33)
    📞 format_obj.setVersion (line 34)
    📞 format_obj.setProfile (line 35)
    📞 format_obj.setSamples (line 36)
    📞 QSurfaceFormat.setDefaultFormat (line 37)
    📞 __init__ (line 39)
    📞 super (line 39)
    📞 get_runtime (line 42)
    📞 get_texture_manager (line 43)

📄 Core\ProjectManager.py
  Imports:
    📦 Core.Debug.debug
    📦 Core.ProjectIndexManager.ProjectIndexManager
    📦 Core.Services.async_project_loader.AsyncProjectLoader
    📦 Core.Services.async_project_saver.AsyncProjectSaver
    📦 Core.Services.project_service.ProjectService
    📦 Core.VenvManager.VenvManager
    📦 PySide6.QtCore.QObject
    📦 PySide6.QtCore.QTimer
    📦 PySide6.QtCore.Signal
    📦 PySide6.QtWidgets.QMessageBox
    📦 datetime.datetime
    📦 glob
    📦 json
    📦 os
    📦 re
    📦 shutil
    📦 traceback
  Calls:
    📞 Signal (line 16)
    📞 Signal (line 17)
    📞 Signal (line 18)
    📞 Signal (line 19)
    📞 __init__ (line 22)
    📞 super (line 22)
    📞 ProjectService (line 32)
    📞 os.makedirs (line 40)
    📞 os.makedirs (line 41)
    📞 join (line 41)

📄 Core\Rendering\SuperShader_2D.py
  Imports:
    📦 Core.Debug.debug
    📦 Core.Rendering.ShaderManager.get_shader_manager
    📦 OpenGL.GL
    📦 OpenGL.arrays.ArrayDatatype
    📦 numpy
    📦 typing.Dict
    📦 typing.Optional
  Calls:
    📞 get_shader_manager (line 34)
    📞 self._get_vertex_shader_source (line 56)
    📞 self._get_fragment_shader_source (line 57)
    📞 compile_shader (line 60)
    📞 self._cache_uniform_locations (line 67)
    📞 debug (line 69)
    📞 debug (line 72)
    📞 debug (line 76)
    📞 get_uniform_location (line 197)
    📞 self.compile (line 209)

📄 Core\Rendering\TextureManager.py
  Imports:
    📦 Core.Debug.debug
    📦 Core.Rendering.OpenGLRuntime.get_runtime
    📦 OpenGL.GL
    📦 PIL.Image
    📦 numpy
    📦 pathlib.Path
    📦 typing.Dict
    📦 typing.List
    📦 typing.Optional
    📦 typing.Tuple
  Calls:
    📞 get_runtime (line 27)
    📞 is_current (line 52)
    📞 make_current (line 53)
    📞 len (line 58)
    📞 ValueError (line 69)
    📞 len (line 70)
    📞 ValueError (line 75)
    📞 np.ascontiguousarray (line 79)
    📞 data.astype (line 82)
    📞 GL.glBindTexture (line 88)

📄 Core\Services\__init__.py
  Imports:
    📦 file_service.FileService
    📦 project_service.ProjectService
    📦 resource_service.ResourceService
    📦 validation_service.ValidationService

📄 Core\Services\async_editor_loader.py
  Imports:
    📦 Core.Debug.debug
    📦 Core.EditorFactory.EditorFactory
    📦 PySide6.QtCore.QThread
    📦 PySide6.QtCore.Signal
    📦 traceback
  Calls:
    📞 Signal (line 15)
    📞 Signal (line 16)
    📞 __init__ (line 19)
    📞 super (line 19)
    📞 debug (line 27)
    📞 EditorFactory.create_editor (line 30)
    📞 get (line 37)
    📞 debug (line 38)
    📞 emit (line 39)
    📞 emit (line 41)

📄 Core\Services\async_project_loader.py
  Imports:
    📦 Core.Debug.debug
    📦 Core.ProjectIndexManager.ProjectIndexManager
    📦 PySide6.QtCore.QMutex
    📦 PySide6.QtCore.QThread
    📦 PySide6.QtCore.Signal
    📦 json
    📦 os
    📦 pathlib.Path
    📦 traceback
  Calls:
    📞 Signal (line 23)
    📞 Signal (line 24)
    📞 Signal (line 25)
    📞 Signal (line 26)
    📞 Signal (line 27)
    📞 __init__ (line 30)
    📞 super (line 30)
    📞 QMutex (line 33)
    📞 QMutex (line 38)
    📞 get (line 46)

📄 Core\Services\async_project_saver.py
  Imports:
    📦 Core.Debug.debug
    📦 Core.ProjectIndexManager.ProjectIndexManager
    📦 PySide6.QtCore.QMutex
    📦 PySide6.QtCore.QThread
    📦 PySide6.QtCore.Signal
    📦 json
    📦 os
    📦 pathlib.Path
    📦 traceback
  Calls:
    📞 Signal (line 17)
    📞 Signal (line 18)
    📞 __init__ (line 21)
    📞 super (line 21)
    📞 QMutex (line 26)
    📞 QMutex (line 31)
    📞 emit (line 37)
    📞 emit (line 41)
    📞 self._save_runtime_to_project_data (line 42)
    📞 emit (line 45)

📄 Core\Services\file_service.py
  Imports:
    📦 Core.Debug.debug
    📦 json
    📦 os
    📦 typing.Any
    📦 typing.Dict
    📦 typing.Optional
  Calls:
    📞 exists (line 29)
    📞 debug (line 30)
    📞 open (line 33)
    📞 json.load (line 34)
    📞 debug (line 36)
    📞 os.makedirs (line 52)
    📞 dirname (line 52)
    📞 open (line 54)
    📞 json.dump (line 55)
    📞 debug (line 58)

📄 Core\Services\project_service.py
  Imports:
    📦 Core.Debug.debug
    📦 Core.Events.EventBus
    📦 Core.Events.EventType
    📦 typing.Any
    📦 typing.Dict
    📦 typing.Optional
  Calls:
    📞 EventBus (line 22)
    📞 debug (line 37)
    📞 create_project (line 41)
    📞 publish (line 45)
    📞 debug (line 68)
    📞 load_project (line 72)
    📞 publish (line 76)
    📞 save_project (line 95)
    📞 publish (line 99)
    📞 close_project (line 120)

📄 Core\Services\incremental_resource_reloader.py
  Imports:
    📦 Core.Debug.debug
    📦 PySide6.QtCore.QMutex
    📦 PySide6.QtCore.QThread
    📦 PySide6.QtCore.Signal
    📦 json
    📦 os
    📦 pathlib.Path
    📦 traceback
  Calls:
    📞 Signal (line 17)
    📞 Signal (line 18)
    📞 Signal (line 19)
    📞 Signal (line 20)
    📞 __init__ (line 23)
    📞 super (line 23)
    📞 QMutex (line 26)
    📞 QMutex (line 31)
    📞 Path (line 38)
    📞 Path (line 38)

📄 Core\Services\resource_service.py
  Imports:
    📦 Core.Debug.debug
    📦 Core.Events.EventBus
    📦 Core.Events.EventType
    📦 typing.Any
    📦 typing.Dict
    📦 typing.Optional
  Calls:
    📞 EventBus (line 24)
    📞 debug (line 40)
    📞 name.strip (line 44)
    📞 debug (line 45)
    📞 create_resource (line 49)
    📞 publish (line 53)
    📞 resource_data.get (line 57)
    📞 debug (line 79)
    📞 update_resource (line 83)
    📞 publish (line 87)

📄 Core\Services\validation_service.py
  Imports:
    📦 Core.Debug.debug
    📦 typing.Any
    📦 typing.Dict
    📦 typing.List
    📦 typing.Optional
  Calls:
    📞 name.strip (line 26)
    📞 len (line 29)
    📞 resource_data.get (line 58)
    📞 resource_data.get (line 59)
    📞 self.validate_resource_name (line 62)
    📞 resource_data.get (line 62)
    📞 project_path.strip (line 78)
    📞 len (line 82)

📄 Core\Services\script_checker.py
  Imports:
    📦 ast
    📦 collections.defaultdict
    📦 importlib.util
    📦 pathlib.Path
    📦 typing.Callable
    📦 typing.Dict
    📦 typing.List
    📦 typing.Optional
  Calls:
    📞 Path (line 28)
    📞 self.output_callback (line 38)
    📞 Path (line 55)
    📞 script_path.exists (line 57)
    📞 append (line 59)
    📞 self._output (line 60)
    📞 append (line 69)
    📞 self._output (line 70)
    📞 open (line 78)
    📞 f.read (line 79)

📄 Core\ThumbnailCache.py
  Imports:
    📦 Core.Debug.debug
    📦 PySide6.QtCore.QSize
    📦 PySide6.QtCore.Qt
    📦 PySide6.QtGui.QIcon
    📦 PySide6.QtGui.QImage
    📦 PySide6.QtGui.QPixmap
    📦 hashlib
    📦 json
    📦 os
    📦 pathlib.Path
    📦 typing.Optional
    📦 typing.Tuple
  Calls:
    📞 Path (line 26)
    📞 mkdir (line 32)
    📞 self._load_cache_index (line 35)
    📞 exists (line 42)
    📞 self._get_cache_key (line 46)
    📞 cached_thumbnail_path.exists (line 51)
    📞 getmtime (line 62)
    📞 getsize (line 63)
    📞 cache_entry.get (line 65)
    📞 cache_entry.get (line 66)

📄 Core\ResourceManager.py
  Imports:
    📦 Core.Debug.debug
    📦 Core.Services.resource_service.ResourceService
    📦 PIL.Image
    📦 PySide6.QtCore.QObject
    📦 PySide6.QtCore.Signal
    📦 PySide6.QtWidgets.QMessageBox
    📦 copy
    📦 datetime
    📦 json
    📦 numpy
    📦 os
    📦 shutil
    📦 traceback
    📦 uuid
  Calls:
    📞 Signal (line 15)
    📞 Signal (line 16)
    📞 Signal (line 17)
    📞 __init__ (line 20)
    📞 super (line 20)
    📞 ResourceService (line 27)
    📞 QMessageBox.critical (line 162)
    📞 get_resources (line 166)
    📞 resource.get (line 168)
    📞 resource.get (line 169)

📄 Core\UtilityOperations.py
  Imports:
    📦 Core.Debug.debug
    📦 PySide6.QtCore.QObject
    📦 PySide6.QtCore.Signal
    📦 PySide6.QtWidgets.QMessageBox
    📦 copy
    📦 datetime.datetime
    📦 json
    📦 os
    📦 shutil
  Calls:
    📞 __init__ (line 17)
    📞 super (line 17)
    📞 self._paste_resource (line 41)
    📞 self._paste_folder (line 43)
    📞 QMessageBox.critical (line 45)
    📞 str (line 45)
    📞 target_data.get (line 57)
    📞 get (line 61)
    📞 self._get_unique_name (line 62)
    📞 copy.deepcopy (line 66)

📄 Editors\__init__.py

📄 Editors\BackgroundEditor\__init__.py

📄 Core\VenvManager.py
  Imports:
    📦 json
    📦 os
    📦 pathlib.Path
    📦 platform
    📦 site
    📦 subprocess
    📦 sys
    📦 traceback
    📦 venv
  Calls:
    📞 subprocess.run (line 19)
    📞 Path (line 35)
    📞 Path (line 35)
    📞 Path (line 39)
    📞 custom_path.exists (line 42)
    📞 exists (line 42)
    📞 platform.system (line 47)
    📞 Path.home (line 48)
    📞 Path.home (line 50)
    📞 platform.system (line 54)

📄 Editors\CodeEditor\__init__.py

📄 Editors\CodeEditor\pgsl_parser.py
  Imports:
    📦 re
  Calls:
    📞 pgsl_code.split (line 170)
    📞 line.strip (line 172)
    📞 python_lines.append (line 175)
    📞 stripped.startswith (line 179)
    📞 python_lines.append (line 180)
    📞 strip (line 180)
    📞 stripped.startswith (line 184)
    📞 max (line 185)
    📞 self._convert_line (line 189)
    📞 python_lines.append (line 192)

📄 Editors\BackgroundEditor\BackgroundEditor.py
  Imports:
    📦 Core.Debug.debug
    📦 Editors.ImageEditor.core.core.state.EditorState
    📦 Editors.ImageEditor.core.ui.dialogs.new_image_dialog.NewImageDialog
    📦 Editors.ImageEditor.core.ui.main_window.MainWindow
    📦 Editors.Shared.BaseImageResourceEditor.BaseImageResourceEditor
    📦 Editors.SpriteEditor.SpriteEditor.IntegratedImageEditor
    📦 PIL.Image
    📦 PySide6.QtWidgets.QDialog
    📦 PySide6.QtWidgets.QFileDialog
    📦 PySide6.QtWidgets.QMessageBox
    📦 PySide6.QtWidgets.QVBoxLayout
    📦 PySide6.QtWidgets.QWidget
    📦 base64
    📦 core.state.state
    📦 numpy
    📦 os
    📦 sys
    📦 traceback
  Calls:
    📞 __init__ (line 15)
    📞 super (line 15)
    📞 QFileDialog.getOpenFileNames (line 21)
    📞 self.load_background_from_files (line 26)
    📞 hasattr (line 37)
    📞 text (line 37)
    📞 text (line 37)
    📞 get (line 37)
    📞 debug (line 39)
    📞 join (line 42)

📄 Editors\CodeEditor\PGSLCodeEditor.py
  Imports:
    📦 PySide6.QtCore.QRect
    📦 PySide6.QtCore.QTimer
    📦 PySide6.QtCore.Qt
    📦 PySide6.QtGui.QColor
    📦 PySide6.QtGui.QFont
    📦 PySide6.QtGui.QSyntaxHighlighter
    📦 PySide6.QtGui.QTextCharFormat
    📦 PySide6.QtGui.QTextCursor
    📦 PySide6.QtWidgets.QApplication
    📦 PySide6.QtWidgets.QListWidget
    📦 PySide6.QtWidgets.QListWidgetItem
    📦 PySide6.QtWidgets.QPlainTextEdit
    📦 re
  Calls:
    📞 __init__ (line 97)
    📞 super (line 97)
    📞 QTextCharFormat (line 99)
    📞 setForeground (line 100)
    📞 QColor (line 100)
    📞 setFontWeight (line 101)
    📞 QTextCharFormat (line 103)
    📞 setForeground (line 104)
    📞 QColor (line 104)
    📞 QTextCharFormat (line 106)

📄 Editors\CodeEditor\pgsl_runtime.py
  Imports:
    📦 math
    📦 random
    📦 time
  Calls:
    📞 get (line 30)
    📞 PGSLContext (line 37)
    📞 print (line 49)
    📞 print (line 53)
    📞 print (line 57)
    📞 print (line 61)
    📞 print (line 65)
    📞 print (line 69)
    📞 print (line 73)
    📞 print (line 77)

📄 Editors\CodeEditor\ScriptEditor.py
  Imports:
    📦 Core.Code.Unified.EditorContext
    📦 Core.Code.Unified.UnifiedCodeEditor
    📦 Core.EditorInterface.EditorInterface
    📦 PySide6.QtCore.Qt
    📦 PySide6.QtCore.Signal
    📦 PySide6.QtWidgets.QLabel
    📦 PySide6.QtWidgets.QMessageBox
    📦 PySide6.QtWidgets.QVBoxLayout
    📦 PySide6.QtWidgets.QWidget
    📦 typing.Dict
    📦 typing.Optional
  Calls:
    📞 __init__ (line 23)
    📞 super (line 23)
    📞 resource_data.get (line 29)
    📞 resource_data.get (line 30)
    📞 self._build_ui (line 34)
    📞 self.open_resource (line 37)
    📞 QVBoxLayout (line 41)
    📞 layout.setContentsMargins (line 42)
    📞 QLabel (line 45)
    📞 header.setStyleSheet (line 46)

📄 Editors\ImageEditor\__init__.py

📄 Editors\ImageEditor\core\app.py
  Imports:
    📦 PySide6.QtWidgets.QApplication
    📦 core.background_processor.get_background_processor
    📦 core.background_processor.shutdown_background_processor
    📦 core.state.state
    📦 sys
    📦 ui.dialogs.NewImageDialog
    📦 ui.main_window.MainWindow
  Calls:
    📞 QApplication (line 9)
    📞 get_background_processor (line 12)
    📞 MainWindow (line 14)
    📞 window.showFullScreen (line 15)
    📞 NewImageDialog (line 16)
    📞 dlg.exec (line 17)
    📞 window.close (line 18)
    📞 shutdown_background_processor (line 19)
    📞 sys.exit (line 20)
    📞 dlg.get_size (line 21)

📄 Editors\ImageEditor\core\core\admin_elevator.py
  Imports:
    📦 ctypes
    📦 importlib
    📦 os
    📦 pathlib.Path
    📦 subprocess
    📦 sys
    📦 tempfile
    📦 time
  Calls:
    📞 IsUserAnAdmin (line 17)
    📞 subprocess.run (line 36)
    📞 is_admin (line 44)
    📞 subprocess.run (line 45)
    📞 str (line 53)
    📞 resolve (line 53)
    📞 Path (line 53)
    📞 str (line 54)
    📞 Path (line 54)
    📞 replace (line 57)

📄 Editors\ImageEditor\core\core\ai_helpers.py
  Imports:
    📦 PIL.Image
    📦 concurrent.futures
    📦 cv2
    📦 hashlib
    📦 json
    📦 numpy
    📦 os
    📦 pathlib.Path
    📦 re
    📦 threading.Lock
    📦 typing.Any
    📦 typing.Dict
    📦 typing.List
    📦 typing.Optional
    📦 typing.Tuple
  Calls:
    📞 Path.home (line 19)
    📞 CACHE_DIR.mkdir (line 20)
    📞 Lock (line 23)
    📞 json.loads (line 33)
    📞 extract_json_from_text (line 36)
    📞 json.loads (line 38)
    📞 extract_json_fallback (line 41)
    📞 json.loads (line 42)
    📞 re.findall (line 54)
    📞 max (line 57)

📄 Editors\ImageEditor\core\core\ai_image_operations.py
  Imports:
    📦 PIL.Image
    📦 base64
    📦 google.generativeai
    📦 io
    📦 json
    📦 numpy
    📦 re
    📦 requests
    📦 typing.Any
    📦 typing.Dict
    📦 typing.Optional
    📦 typing.Tuple
  Calls:
    📞 __init__ (line 18)
    📞 super (line 18)
    📞 str (line 25)
    📞 error_str.lower (line 30)
    📞 error_str.lower (line 31)
    📞 error_str.lower (line 32)
    📞 error_str.lower (line 32)
    📞 error_str.lower (line 32)
    📞 re.search (line 39)
    📞 float (line 41)

📄 Editors\ImageEditor\core\core\ai_requirements.py
  Imports:
    📦 importlib
    📦 json
    📦 subprocess
    📦 sys
    📦 typing.List
    📦 typing.Optional
    📦 typing.Tuple
  Calls:
    📞 get (line 54)
    📞 RequirementChecker.check_package (line 59)
    📞 package_info.get (line 65)
    📞 RequirementChecker.check_package (line 67)
    📞 missing_deps.append (line 69)
    📞 join (line 72)
    📞 get (line 89)
    📞 importlib.import_module (line 97)
    📞 subprocess.run (line 114)
    📞 json.loads (line 122)

📄 Editors\ImageEditor\core\core\ai_worker_threads.py
  Imports:
    📦 PySide6.QtCore.QThread
    📦 PySide6.QtCore.Signal
    📦 core.ai_helpers.apply_cumulative_changes
    📦 core.ai_helpers.compute_frame_diff
    📦 core.ai_helpers.generate_frames_parallel
    📦 core.gemini_client.GeminiClient
    📦 numpy
    📦 typing.Any
    📦 typing.Dict
    📦 typing.List
    📦 typing.Optional
    📦 typing.Tuple
  Calls:
    📞 Signal (line 19)
    📞 Signal (line 20)
    📞 Signal (line 21)
    📞 __init__ (line 25)
    📞 super (line 25)
    📞 emit (line 37)
    📞 generate_base_image (line 39)
    📞 emit (line 44)
    📞 emit (line 47)
    📞 emit (line 49)

📄 Editors\ImageEditor\core\core\background_processor.py
  Imports:
    📦 PySide6.QtCore.QObject
    📦 PySide6.QtCore.QThread
    📦 PySide6.QtCore.QTimer
    📦 PySide6.QtCore.Signal
    📦 queue
    📦 threading
    📦 time
    📦 typing.Any
    📦 typing.Callable
    📦 typing.Optional
  Calls:
    📞 Signal (line 26)
    📞 Signal (line 27)
    📞 Signal (line 28)
    📞 Signal (line 29)
    📞 Signal (line 30)
    📞 __init__ (line 33)
    📞 super (line 33)
    📞 get (line 43)
    📞 time.time (line 49)
    📞 emit (line 51)

📄 Editors\ImageEditor\core\core\atlas_manager.py
  Imports:
    📦 PIL.Image
    📦 PySide6.QtGui.QColor
    📦 PySide6.QtGui.QImage
    📦 copy
    📦 core.texture_utils.generate_block_texture_qimage
    📦 numpy
    📦 os
    📦 tempfile
  Calls:
    📞 self._create_default_grid (line 45)
    📞 enumerate (line 57)
    📞 AtlasCell (line 59)
    📞 append (line 60)
    📞 self._recalculate_grid_layout (line 66)
    📞 enumerate (line 78)
    📞 self._recalculate_grid_layout (line 89)
    📞 len (line 97)
    📞 len (line 100)
    📞 AtlasCell (line 106)

📄 Editors\ImageEditor\core\core\ai_test_app.py
  Imports:
    📦 PIL.Image
    📦 PySide6.QtCore.QTimer
    📦 PySide6.QtCore.Qt
    📦 PySide6.QtCore.Signal
    📦 PySide6.QtGui.QColor
    📦 PySide6.QtGui.QImage
    📦 PySide6.QtGui.QPainter
    📦 PySide6.QtGui.QPixmap
    📦 PySide6.QtWidgets.QApplication
    📦 PySide6.QtWidgets.QCheckBox
    📦 PySide6.QtWidgets.QDialog
    📦 PySide6.QtWidgets.QFileDialog
    📦 PySide6.QtWidgets.QFrame
    📦 PySide6.QtWidgets.QGroupBox
    📦 PySide6.QtWidgets.QHBoxLayout
    📦 PySide6.QtWidgets.QLabel
    📦 PySide6.QtWidgets.QLineEdit
    📦 PySide6.QtWidgets.QMessageBox
    📦 PySide6.QtWidgets.QPushButton
    📦 PySide6.QtWidgets.QSplitter
    📦 PySide6.QtWidgets.QTextEdit
    📦 PySide6.QtWidgets.QVBoxLayout
    📦 ai_test_scenario.create_system_prompt
    📦 ai_test_scenario.execute_instructions
    📦 ai_test_scenario.generate_instructions_with_ai
    📦 ai_test_scenario.load_tool_knowledge
    📦 anthropic
    📦 importlib
    📦 json
    📦 numpy
    📦 os
    📦 random
    📦 re
    📦 subprocess
    📦 sys
    📦 traceback
  Calls:
    📞 __import__ (line 25)
    📞 missing_packages.append (line 28)
    📞 print (line 31)
    📞 list (line 32)
    📞 set (line 32)
    📞 print (line 33)
    📞 join (line 33)
    📞 print (line 36)
    📞 subprocess.run (line 38)
    📞 print (line 45)

📄 Editors\ImageEditor\core\core\gemini_client.py
  Imports:
    📦 PIL.Image
    📦 base64
    📦 core.ai_helpers.cache_response
    📦 core.ai_helpers.clamp_region
    📦 core.ai_helpers.get_cache_key
    📦 core.ai_helpers.get_cached_response
    📦 core.ai_helpers.parse_json_response
    📦 core.ai_helpers.validate_region
    📦 google.generativeai
    📦 io
    📦 json
    📦 numpy
    📦 os
    📦 re
    📦 typing.Any
    📦 typing.Dict
    📦 typing.List
    📦 typing.Optional
    📦 typing.Tuple
  Calls:
    📞 print (line 19)
    📞 ImportError (line 38)
    📞 os.getenv (line 40)
    📞 ValueError (line 42)
    📞 genai.configure (line 44)
    📞 genai.GenerativeModel (line 45)
    📞 get_cache_key (line 62)
    📞 get_cached_response (line 66)
    📞 self._decode_image_from_cache (line 69)
    📞 generate_content (line 82)

📄 Editors\ImageEditor\core\core\history.py
  Imports:
    📦 copy
    📦 numpy
  Calls:
    📞 get_current_layer (line 13)
    📞 layer.get_frame (line 15)
    📞 has_selection (line 19)
    📞 copy (line 21)
    📞 append (line 26)
    📞 copy.deepcopy (line 27)
    📞 len (line 30)
    📞 pop (line 31)
    📞 clear (line 32)
    📞 get_current_layer (line 37)

📄 Editors\ImageEditor\core\core\pgsprite_io.py
  Imports:
    📦 PIL.Image
    📦 PySide6.QtCore.QBuffer
    📦 PySide6.QtCore.QIODevice
    📦 PySide6.QtGui.QColor
    📦 PySide6.QtGui.QImage
    📦 base64
    📦 io
    📦 json
    📦 numpy
    📦 os
    📦 typing.Any
    📦 typing.Dict
    📦 typing.List
    📦 typing.Optional
  Calls:
    📞 self._export_layers (line 29)
    📞 self._export_atlas (line 30)
    📞 self._export_settings (line 31)
    📞 open (line 35)
    📞 json.dump (line 36)
    📞 print (line 41)
    📞 open (line 47)
    📞 json.load (line 48)
    📞 get (line 51)
    📞 data.get (line 51)

📄 Editors\ImageEditor\core\core\settings.py
  Imports:
    📦 json
    📦 logging
    📦 os
  Calls:
    📞 expanduser (line 5)
    📞 self.load (line 17)
    📞 exists (line 20)
    📞 open (line 22)
    📞 json.load (line 23)
    📞 update (line 24)
    📞 logging.warning (line 26)
    📞 os.makedirs (line 32)
    📞 dirname (line 32)
    📞 open (line 33)

📄 Editors\ImageEditor\core\core\smart_layer_separation.py
  Imports:
    📦 PySide6.QtCore.Qt
    📦 PySide6.QtGui.QColor
    📦 cv2
    📦 numpy
  Calls:
    📞 self._get_bounds_from_mask (line 31)
    📞 copy (line 38)
    📞 copy (line 41)
    📞 len (line 44)
    📞 template_mask.astype (line 46)
    📞 np.zeros (line 49)
    📞 template_mask.astype (line 51)
    📞 self._track_with_template_matching (line 65)
    📞 self._track_with_optical_flow (line 67)
    📞 len (line 73)

📄 Editors\ImageEditor\core\core\state.py
  Imports:
    📦 PySide6.QtCore.QRect
    📦 core.atlas_manager.AtlasManager
    📦 core.history.HistoryManager
    📦 core.selection_manager.SelectionManager
    📦 layers.manager.LayerManager
  Calls:
    📞 LayerManager (line 11)
    📞 ensure_minimums (line 12)
    📞 AtlasManager (line 13)
    📞 SelectionManager (line 14)
    📞 HistoryManager (line 26)
    📞 self.push_undo (line 38)
    📞 LayerManager (line 41)
    📞 ensure_minimums (line 42)
    📞 set_canvas_size (line 43)
    📞 has_selection (line 63)

📄 Editors\ImageEditor\core\core\themes.py
  Calls:
    📞 THEMES.get (line 38)

📄 Editors\ImageEditor\core\core\venv_fix_tool.py
  Imports:
    📦 os
    📦 pathlib.Path
    📦 psutil
    📦 stat
    📦 subprocess
    📦 sys
    📦 typing.List
    📦 typing.Tuple
  Calls:
    📞 venv_path.exists (line 24)
    📞 issues.append (line 25)
    📞 test_file.write_text (line 31)
    📞 test_file.unlink (line 32)
    📞 issues.append (line 34)
    📞 issues.append (line 37)
    📞 site_packages.exists (line 47)
    📞 test_file.write_text (line 50)
    📞 test_file.unlink (line 51)
    📞 issues.append (line 53)

📄 Editors\ImageEditor\core\core\selection_manager.py
  Imports:
    📦 PySide6.QtCore.QPointF
    📦 PySide6.QtCore.QRectF
    📦 PySide6.QtCore.Qt
    📦 PySide6.QtGui.QBrush
    📦 PySide6.QtGui.QColor
    📦 PySide6.QtGui.QPainter
    📦 PySide6.QtGui.QPainterPath
    📦 PySide6.QtGui.QPen
    📦 cv2
    📦 matplotlib.path.Path
    📦 numpy
    📦 scipy.ndimage
    📦 scipy.ndimage.binary_dilation
    📦 scipy.ndimage.binary_erosion
    📦 segment_anything.SamPredictor
    📦 segment_anything.sam_model_registry
    📦 skimage.measure
  Calls:
    📞 np.any (line 36)
    📞 np.any (line 48)
    📞 np.where (line 52)
    📞 len (line 53)
    📞 min (line 54)
    📞 max (line 54)
    📞 min (line 55)
    📞 max (line 55)
    📞 self.get_selection_bounds (line 63)
    📞 max (line 70)

📄 Editors\ImageEditor\core\layers\layer.py
  Imports:
    📦 copy
    📦 core.history.HistoryManager
    📦 numpy
  Calls:
    📞 np.zeros (line 6)
    📞 Frame (line 12)
    📞 copy (line 13)
    📞 copy (line 14)
    📞 Frame (line 22)
    📞 HistoryManager (line 27)
    📞 Frame (line 50)
    📞 np.zeros (line 52)
    📞 append (line 53)
    📞 len (line 55)

📄 Editors\ImageEditor\core\core\texture_utils.py
  Imports:
    📦 PySide6.QtGui.QColor
    📦 PySide6.QtGui.QImage
    📦 math
    📦 numpy
    📦 random
    📦 warnings
  Calls:
    📞 hex_color.startswith (line 9)
    📞 int (line 11)
    📞 int (line 12)
    📞 int (line 13)
    📞 QColor (line 14)
    📞 int (line 18)
    📞 c1.red (line 18)
    📞 c2.red (line 18)
    📞 int (line 19)
    📞 c1.green (line 19)

📄 Editors\ImageEditor\core\layers\manager.py
  Imports:
    📦 PIL.Image
    📦 core.history.HistoryManager
    📦 layer.Frame
    📦 layer.Layer
    📦 numpy
  Calls:
    📞 Layer (line 7)
    📞 get_frame (line 23)
    📞 self.get_current_layer (line 23)
    📞 self.get_current_frame (line 26)
    📞 l.get_frame (line 37)
    📞 l.get_frame (line 37)
    📞 id (line 37)
    📞 l.get_frame (line 37)
    📞 sorted (line 38)
    📞 hash (line 39)

📄 Editors\ImageEditor\core\selection_helpers.py
  Imports:
    📦 PySide6.QtCore.QPointF
    📦 PySide6.QtGui.QPainterPath
    📦 cv2
    📦 numpy
    📦 skimage.measure
  Calls:
    📞 measure.find_contours (line 17)
    📞 mask.astype (line 17)
    📞 len (line 20)
    📞 QPainterPath (line 23)
    📞 path.moveTo (line 28)
    📞 QPointF (line 28)
    📞 path.lineTo (line 34)
    📞 QPointF (line 34)
    📞 path.closeSubpath (line 36)
    📞 paths.append (line 37)

📄 Editors\ImageEditor\core\generate_textures.py
  Imports:
    📦 PIL.Image
    📦 PIL.ImageDraw
    📦 math
    📦 os
    📦 pygame
    📦 sys
  Calls:
    📞 os.makedirs (line 8)
    📞 os.makedirs (line 9)
    📞 print (line 13)
    📞 Image.new (line 14)
    📞 ImageDraw.Draw (line 15)
    📞 draw.line (line 19)
    📞 draw.line (line 20)
    📞 draw.line (line 23)
    📞 draw.line (line 24)
    📞 img.save (line 26)

📄 Editors\ImageEditor\core\services\__init__.py
  Imports:
    📦 effect_processor.EffectProcessor
    📦 file_io.FileIOService
    📦 image_operations.ImageOperations

📄 Editors\ImageEditor\core\services\file_io.py
  Imports:
    📦 PIL.Image
    📦 numpy
    📦 os
    📦 typing.Any
    📦 typing.Dict
    📦 typing.Optional
  Calls:
    📞 Image.fromarray (line 32)
    📞 pil_img.save (line 33)
    📞 print (line 36)
    📞 Image.open (line 50)
    📞 pil_img.convert (line 52)
    📞 np.array (line 53)
    📞 print (line 55)
    📞 len (line 71)
    📞 self.save_image (line 73)
    📞 splitext (line 76)

📄 Editors\ImageEditor\core\services\image_operations.py
  Imports:
    📦 PIL.Image
    📦 numpy
    📦 typing.Any
    📦 typing.Dict
    📦 typing.Optional
    📦 typing.Tuple
  Calls:
    📞 Image.fromarray (line 20)
    📞 pil_img.resize (line 22)
    📞 pil_img.resize (line 24)
    📞 np.array (line 25)
    📞 Image.fromarray (line 29)
    📞 pil_img.crop (line 30)
    📞 np.array (line 31)
    📞 Image.fromarray (line 35)
    📞 pil_img.rotate (line 36)
    📞 np.array (line 37)

📄 Editors\ImageEditor\core\ui\api_key_dialog.py
  Imports:
    📦 PySide6.QtCore.QUrl
    📦 PySide6.QtCore.Qt
    📦 PySide6.QtGui.QDesktopServices
    📦 PySide6.QtGui.QFont
    📦 PySide6.QtWidgets.QDialog
    📦 PySide6.QtWidgets.QDialogButtonBox
    📦 PySide6.QtWidgets.QHBoxLayout
    📦 PySide6.QtWidgets.QLabel
    📦 PySide6.QtWidgets.QLineEdit
    📦 PySide6.QtWidgets.QMessageBox
    📦 PySide6.QtWidgets.QPushButton
    📦 PySide6.QtWidgets.QTextEdit
    📦 PySide6.QtWidgets.QVBoxLayout
  Calls:
    📞 __init__ (line 17)
    📞 super (line 17)
    📞 self.setWindowTitle (line 18)
    📞 self.setMinimumWidth (line 19)
    📞 self.setModal (line 20)
    📞 QVBoxLayout (line 22)
    📞 QLabel (line 25)
    📞 instructions.setWordWrap (line 34)
    📞 instructions.setStyleSheet (line 35)
    📞 layout.addWidget (line 36)

📄 Editors\ImageEditor\core\ui\background_removal_dialog.py
  Imports:
    📦 PySide6.QtCore.Qt
    📦 PySide6.QtGui.QImage
    📦 PySide6.QtGui.QPixmap
    📦 PySide6.QtWidgets.QDialog
    📦 PySide6.QtWidgets.QDialogButtonBox
    📦 PySide6.QtWidgets.QGroupBox
    📦 PySide6.QtWidgets.QHBoxLayout
    📦 PySide6.QtWidgets.QLabel
    📦 PySide6.QtWidgets.QMessageBox
    📦 PySide6.QtWidgets.QProgressDialog
    📦 PySide6.QtWidgets.QPushButton
    📦 PySide6.QtWidgets.QScrollArea
    📦 PySide6.QtWidgets.QVBoxLayout
    📦 PySide6.QtWidgets.QWidget
    📦 cv2
    📦 numpy
    📦 pathlib.Path
    📦 subprocess
    📦 sys
    📦 torch
    📦 torchvision
    📦 torchvision.models.segmentation.DeepLabV3_ResNet50_Weights
    📦 torchvision.models.segmentation.deeplabv3_resnet50
    📦 torchvision.transforms
    📦 traceback
  Calls:
    📞 __init__ (line 22)
    📞 super (line 22)
    📞 self.setWindowTitle (line 23)
    📞 self.setModal (line 24)
    📞 self.setMinimumSize (line 25)
    📞 astype (line 29)
    📞 np.clip (line 29)
    📞 len (line 31)
    📞 cv2.cvtColor (line 32)
    📞 len (line 33)

📄 Editors\ImageEditor\core\ui\ai_dialogs.py
  Imports:
    📦 PIL.Image
    📦 PySide6.QtCore.QThread
    📦 PySide6.QtCore.QTimer
    📦 PySide6.QtCore.Qt
    📦 PySide6.QtCore.Signal
    📦 PySide6.QtGui.QBrush
    📦 PySide6.QtGui.QColor
    📦 PySide6.QtGui.QImage
    📦 PySide6.QtGui.QPainter
    📦 PySide6.QtGui.QPen
    📦 PySide6.QtGui.QPixmap
    📦 PySide6.QtWidgets.QButtonGroup
    📦 PySide6.QtWidgets.QCheckBox
    📦 PySide6.QtWidgets.QComboBox
    📦 PySide6.QtWidgets.QDialog
    📦 PySide6.QtWidgets.QDialogButtonBox
    📦 PySide6.QtWidgets.QFormLayout
    📦 PySide6.QtWidgets.QFrame
    📦 PySide6.QtWidgets.QGroupBox
    📦 PySide6.QtWidgets.QHBoxLayout
    📦 PySide6.QtWidgets.QLabel
    📦 PySide6.QtWidgets.QLineEdit
    📦 PySide6.QtWidgets.QMessageBox
    📦 PySide6.QtWidgets.QProgressBar
    📦 PySide6.QtWidgets.QPushButton
    📦 PySide6.QtWidgets.QRadioButton
    📦 PySide6.QtWidgets.QScrollArea
    📦 PySide6.QtWidgets.QSlider
    📦 PySide6.QtWidgets.QSpinBox
    📦 PySide6.QtWidgets.QSplitter
    📦 PySide6.QtWidgets.QTabWidget
    📦 PySide6.QtWidgets.QTextEdit
    📦 PySide6.QtWidgets.QTreeWidget
    📦 PySide6.QtWidgets.QTreeWidgetItem
    📦 PySide6.QtWidgets.QVBoxLayout
    📦 PySide6.QtWidgets.QWidget
    📦 base64
    📦 io
    📦 json
    📦 numpy
    📦 typing.Any
    📦 typing.Dict
    📦 typing.List
    📦 typing.Optional
  Calls:
    📞 Signal (line 26)
    📞 Signal (line 27)
    📞 Signal (line 28)
    📞 __init__ (line 31)
    📞 super (line 31)
    📞 self.setWindowTitle (line 32)
    📞 self.setModal (line 33)
    📞 self.setMinimumWidth (line 34)
    📞 QVBoxLayout (line 36)
    📞 QLabel (line 38)

📄 Editors\ImageEditor\core\services\effect_processor.py
  Imports:
    📦 PIL.Image
    📦 PIL.ImageEnhance
    📦 PIL.ImageFilter
    📦 colorsys.hsv_to_rgb
    📦 colorsys.rgb_to_hsv
    📦 cv2
    📦 math
    📦 numpy
    📦 random
    📦 scipy.ndimage
    📦 typing.Any
    📦 typing.Dict
    📦 typing.Optional
    📦 typing.Union
  Calls:
    📞 isinstance (line 38)
    📞 pil_img.convert (line 41)
    📞 Image.fromarray (line 44)
    📞 isinstance (line 48)
    📞 np.array (line 49)
    📞 self._apply_dither_effect (line 53)
    📞 self._apply_pixelate_effect (line 55)
    📞 self._apply_invert_effect (line 59)
    📞 self._apply_brightness_effect (line 61)
    📞 self._apply_contrast_effect (line 63)

📄 Editors\ImageEditor\core\ui\atmospheric_lighting_helpers.py
  Imports:
    📦 cv2
    📦 math
    📦 numpy
    📦 typing.Any
    📦 typing.Dict
    📦 typing.List
    📦 typing.Optional
    📦 typing.Tuple
  Calls:
    📞 append (line 37)
    📞 len (line 44)
    📞 cv2.cvtColor (line 46)
    📞 cv2.cvtColor (line 48)
    📞 img_array.copy (line 50)
    📞 self._detect_brightness_lights_simple (line 53)
    📞 detected_lights.extend (line 54)
    📞 self._merge_nearby_lights (line 57)
    📞 detection_params.get (line 57)
    📞 img_array.copy (line 76)

📄 Editors\ImageEditor\core\ui\block_texture_dialog.py
  Imports:
    📦 PySide6.QtCore.QTimer
    📦 PySide6.QtCore.Qt
    📦 PySide6.QtCore.Signal
    📦 PySide6.QtGui.QColor
    📦 PySide6.QtGui.QImage
    📦 PySide6.QtGui.QPainter
    📦 PySide6.QtGui.QPixmap
    📦 PySide6.QtWidgets.QButtonGroup
    📦 PySide6.QtWidgets.QCheckBox
    📦 PySide6.QtWidgets.QColorDialog
    📦 PySide6.QtWidgets.QComboBox
    📦 PySide6.QtWidgets.QDialog
    📦 PySide6.QtWidgets.QDialogButtonBox
    📦 PySide6.QtWidgets.QFormLayout
    📦 PySide6.QtWidgets.QFrame
    📦 PySide6.QtWidgets.QGroupBox
    📦 PySide6.QtWidgets.QHBoxLayout
    📦 PySide6.QtWidgets.QLabel
    📦 PySide6.QtWidgets.QLineEdit
    📦 PySide6.QtWidgets.QPushButton
    📦 PySide6.QtWidgets.QRadioButton
    📦 PySide6.QtWidgets.QSlider
    📦 PySide6.QtWidgets.QSpinBox
    📦 PySide6.QtWidgets.QTabWidget
    📦 PySide6.QtWidgets.QVBoxLayout
    📦 PySide6.QtWidgets.QWidget
    📦 core.texture_utils.generate_block_texture_qimage
    📦 core.texture_utils.hex_to_qcolor
    📦 core.texture_utils.make_gradient_palette_qt
    📦 math
    📦 random
  Calls:
    📞 __init__ (line 14)
    📞 super (line 14)
    📞 self.setWindowTitle (line 16)
    📞 self.resize (line 17)
    📞 self.setModal (line 18)
    📞 QTimer (line 22)
    📞 setSingleShot (line 23)
    📞 connect (line 24)
    📞 self._setup_ui (line 26)
    📞 self._connect_signals (line 27)

📄 Editors\ImageEditor\core\ui\components\__init__.py

📄 Editors\ImageEditor\core\ui\components\menu_bar.py
  Imports:
    📦 PySide6.QtGui.QKeySequence
    📦 PySide6.QtGui.QShortcut
    📦 PySide6.QtWidgets.QMenuBar
    📦 core.settings.settings
  Calls:
    📞 QMenuBar (line 27)
    📞 self._create_file_menu (line 29)
    📞 self._create_edit_menu (line 30)
    📞 self._create_view_menu (line 31)
    📞 self._create_frame_menu (line 32)
    📞 self._create_effects_menu (line 33)
    📞 self._create_ai_menu (line 34)
    📞 addMenu (line 40)
    📞 file_menu.addAction (line 43)
    📞 new_action.setShortcut (line 44)

📄 Editors\ImageEditor\core\ui\components\status_bar.py
  Imports:
    📦 PySide6.QtCore.Signal
    📦 PySide6.QtWidgets.QLabel
    📦 PySide6.QtWidgets.QStatusBar
  Calls:
    📞 statusBar (line 29)
    📞 setStyleSheet (line 30)
    📞 QLabel (line 33)
    📞 QLabel (line 34)
    📞 QLabel (line 35)
    📞 QLabel (line 36)
    📞 addWidget (line 39)
    📞 addPermanentWidget (line 40)
    📞 addPermanentWidget (line 41)
    📞 addPermanentWidget (line 42)

📄 Editors\ImageEditor\core\ui\dialogs\__init__.py
  Imports:
    📦 ui.dialogs.effect_dialog.EFFECT_REGISTRY
    📦 ui.dialogs.effect_dialog.UnifiedEffectDialog
    📦 ui.dialogs.merge_replace_dialog.MergeReplaceDialog
    📦 ui.dialogs.new_image_dialog.NewImageDialog
    📦 ui.dialogs.origin_dialog.OriginSelectionDialog
    📦 ui.dialogs.parameter_widgets.CheckboxWidget
    📦 ui.dialogs.parameter_widgets.ColorListWidget
    📦 ui.dialogs.parameter_widgets.ColorPickerWidget
    📦 ui.dialogs.parameter_widgets.DoubleSliderWidget
    📦 ui.dialogs.parameter_widgets.DropdownWidget
    📦 ui.dialogs.parameter_widgets.ParameterWidget
    📦 ui.dialogs.parameter_widgets.SliderWidget
    📦 ui.dialogs.parameter_widgets.TextBoxWidget
    📦 ui.dialogs.preferences_dialog.PreferencesDialog
    📦 ui.dialogs.preview_widgets.CheckerboardPreviewWidget
    📦 ui.dialogs.preview_widgets.LeftPanelPreviewWidget
    📦 ui.dialogs.preview_widgets.RightPanelPreviewWidget

📄 Editors\ImageEditor\core\ui\dialogs\merge_replace_dialog.py
  Imports:
    📦 PySide6.QtWidgets.QButtonGroup
    📦 PySide6.QtWidgets.QDialog
    📦 PySide6.QtWidgets.QDialogButtonBox
    📦 PySide6.QtWidgets.QLabel
    📦 PySide6.QtWidgets.QRadioButton
    📦 PySide6.QtWidgets.QVBoxLayout
  Calls:
    📞 __init__ (line 13)
    📞 super (line 13)
    📞 self.setWindowTitle (line 14)
    📞 self.setMinimumWidth (line 15)
    📞 QVBoxLayout (line 16)
    📞 QLabel (line 17)
    📞 layout.addWidget (line 18)
    📞 QButtonGroup (line 19)
    📞 QRadioButton (line 20)
    📞 QRadioButton (line 21)

📄 Editors\ImageEditor\core\ui\character_creator_dialog.py
  Imports:
    📦 PIL.Image
    📦 PySide6.QtCore.QRect
    📦 PySide6.QtCore.QTimer
    📦 PySide6.QtCore.Qt
    📦 PySide6.QtGui.QColor
    📦 PySide6.QtGui.QFont
    📦 PySide6.QtGui.QImage
    📦 PySide6.QtGui.QPainter
    📦 PySide6.QtGui.QPalette
    📦 PySide6.QtGui.QPixmap
    📦 PySide6.QtWidgets.QCheckBox
    📦 PySide6.QtWidgets.QColorDialog
    📦 PySide6.QtWidgets.QComboBox
    📦 PySide6.QtWidgets.QDialog
    📦 PySide6.QtWidgets.QFrame
    📦 PySide6.QtWidgets.QGridLayout
    📦 PySide6.QtWidgets.QGroupBox
    📦 PySide6.QtWidgets.QHBoxLayout
    📦 PySide6.QtWidgets.QLabel
    📦 PySide6.QtWidgets.QLineEdit
    📦 PySide6.QtWidgets.QMenu
    📦 PySide6.QtWidgets.QPushButton
    📦 PySide6.QtWidgets.QScrollArea
    📦 PySide6.QtWidgets.QSlider
    📦 PySide6.QtWidgets.QSpinBox
    📦 PySide6.QtWidgets.QSplitter
    📦 PySide6.QtWidgets.QTextEdit
    📦 PySide6.QtWidgets.QVBoxLayout
    📦 PySide6.QtWidgets.QWidget
    📦 core.state.state
    📦 core.texture_utils.generate_block_texture_qimage
    📦 core.texture_utils.hex_to_qcolor
    📦 hashlib
    📦 math
    📦 numpy
    📦 os
    📦 random
    📦 sys
    📦 tempfile
  Calls:
    📞 COLOR_NAMES.get (line 57)
    📞 hex_color.upper (line 57)
    📞 COLOR_NAMES.items (line 61)
    📞 name.lower (line 62)
    📞 color_name.lower (line 62)
    📞 __init__ (line 68)
    📞 super (line 68)
    📞 self.setup_ui (line 83)
    📞 QHBoxLayout (line 86)
    📞 layout.setContentsMargins (line 87)

📄 Editors\ImageEditor\core\ui\dialogs\new_image_dialog.py
  Imports:
    📦 PySide6.QtCore.Qt
    📦 PySide6.QtWidgets.QDialog
    📦 PySide6.QtWidgets.QDialogButtonBox
    📦 PySide6.QtWidgets.QGridLayout
    📦 PySide6.QtWidgets.QGroupBox
    📦 PySide6.QtWidgets.QHBoxLayout
    📦 PySide6.QtWidgets.QLabel
    📦 PySide6.QtWidgets.QLineEdit
    📦 PySide6.QtWidgets.QPushButton
    📦 PySide6.QtWidgets.QVBoxLayout
  Calls:
    📞 __init__ (line 15)
    📞 super (line 15)
    📞 self.setWindowTitle (line 16)
    📞 self.setMinimumWidth (line 17)
    📞 QVBoxLayout (line 18)
    📞 QGroupBox (line 21)
    📞 QGridLayout (line 22)
    📞 size_layout.addWidget (line 24)
    📞 QLabel (line 24)
    📞 QLineEdit (line 25)

📄 Editors\ImageEditor\core\ui\dialogs\origin_dialog.py
  Imports:
    📦 PySide6.QtWidgets.QDialog
    📦 PySide6.QtWidgets.QDialogButtonBox
    📦 PySide6.QtWidgets.QGroupBox
    📦 PySide6.QtWidgets.QLabel
    📦 PySide6.QtWidgets.QRadioButton
    📦 PySide6.QtWidgets.QVBoxLayout
  Calls:
    📞 __init__ (line 14)
    📞 super (line 14)
    📞 self.setWindowTitle (line 15)
    📞 self.setModal (line 16)
    📞 self.resize (line 17)
    📞 QVBoxLayout (line 20)
    📞 QLabel (line 22)
    📞 layout.addWidget (line 23)
    📞 QRadioButton (line 26)
    📞 setChecked (line 27)

📄 Editors\ImageEditor\core\ui\dialogs\parameter_widgets.py
  Imports:
    📦 PySide6.QtCore.Qt
    📦 PySide6.QtCore.Signal
    📦 PySide6.QtGui.QColor
    📦 PySide6.QtGui.QPixmap
    📦 PySide6.QtWidgets.QCheckBox
    📦 PySide6.QtWidgets.QColorDialog
    📦 PySide6.QtWidgets.QComboBox
    📦 PySide6.QtWidgets.QDoubleSpinBox
    📦 PySide6.QtWidgets.QHBoxLayout
    📦 PySide6.QtWidgets.QLabel
    📦 PySide6.QtWidgets.QLineEdit
    📦 PySide6.QtWidgets.QListWidget
    📦 PySide6.QtWidgets.QListWidgetItem
    📦 PySide6.QtWidgets.QPushButton
    📦 PySide6.QtWidgets.QSlider
    📦 PySide6.QtWidgets.QSpinBox
    📦 PySide6.QtWidgets.QVBoxLayout
    📦 PySide6.QtWidgets.QWidget
  Calls:
    📞 Signal (line 17)
    📞 __init__ (line 20)
    📞 super (line 20)
    📞 self.setup_ui (line 22)
    📞 QHBoxLayout (line 25)
    📞 layout.setContentsMargins (line 26)
    📞 QLabel (line 28)
    📞 get (line 28)
    📞 layout.addWidget (line 29)
    📞 self.setLayout (line 31)

📄 Editors\ImageEditor\core\ui\dialogs\preview_widgets.py
  Imports:
    📦 PySide6.QtCore.Qt
    📦 PySide6.QtGui.QColor
    📦 PySide6.QtGui.QPainter
    📦 PySide6.QtGui.QPixmap
    📦 PySide6.QtWidgets.QLabel
    📦 PySide6.QtWidgets.QVBoxLayout
    📦 PySide6.QtWidgets.QWidget
  Calls:
    📞 __init__ (line 13)
    📞 super (line 13)
    📞 QVBoxLayout (line 14)
    📞 self.setLayout (line 16)
    📞 removeWidget (line 21)
    📞 label.deleteLater (line 22)
    📞 QLabel (line 26)
    📞 label.setStyleSheet (line 27)
    📞 addWidget (line 28)
    📞 append (line 29)

📄 Editors\ImageEditor\core\ui\dialogs.py
  Imports:
    📦 Core.Debug.debug
    📦 PySide6.QtCore.QTimer
    📦 PySide6.QtCore.Qt
    📦 PySide6.QtCore.Signal
    📦 PySide6.QtGui.QColor
    📦 PySide6.QtGui.QFont
    📦 PySide6.QtGui.QImage
    📦 PySide6.QtGui.QPainter
    📦 PySide6.QtGui.QPixmap
    📦 PySide6.QtWidgets.QButtonGroup
    📦 PySide6.QtWidgets.QCheckBox
    📦 PySide6.QtWidgets.QColorDialog
    📦 PySide6.QtWidgets.QComboBox
    📦 PySide6.QtWidgets.QDialog
    📦 PySide6.QtWidgets.QDialogButtonBox
    📦 PySide6.QtWidgets.QFormLayout
    📦 PySide6.QtWidgets.QGroupBox
    📦 PySide6.QtWidgets.QHBoxLayout
    📦 PySide6.QtWidgets.QInputDialog
    📦 PySide6.QtWidgets.QLabel
    📦 PySide6.QtWidgets.QLineEdit
    📦 PySide6.QtWidgets.QListWidget
    📦 PySide6.QtWidgets.QListWidgetItem
    📦 PySide6.QtWidgets.QPushButton
    📦 PySide6.QtWidgets.QRadioButton
    📦 PySide6.QtWidgets.QScrollArea
    📦 PySide6.QtWidgets.QSizePolicy
    📦 PySide6.QtWidgets.QSlider
    📦 PySide6.QtWidgets.QSpinBox
    📦 PySide6.QtWidgets.QTabWidget
    📦 PySide6.QtWidgets.QTextEdit
    📦 PySide6.QtWidgets.QVBoxLayout
    📦 PySide6.QtWidgets.QWidget
    📦 collections
    📦 core.settings.settings
    📦 core.themes.THEMES
    📦 json
    📦 numpy
    📦 os
    📦 ui.dialogs.effect_dialog.EFFECT_REGISTRY
    📦 ui.dialogs.effect_dialog.UnifiedEffectDialog
    📦 ui.dialogs.merge_replace_dialog.MergeReplaceDialog
    📦 ui.dialogs.new_image_dialog.NewImageDialog
    📦 ui.dialogs.parameter_widgets.CheckboxWidget
    📦 ui.dialogs.parameter_widgets.ColorListWidget
    📦 ui.dialogs.parameter_widgets.ColorPickerWidget
    📦 ui.dialogs.parameter_widgets.DoubleSliderWidget
    📦 ui.dialogs.parameter_widgets.DropdownWidget
    📦 ui.dialogs.parameter_widgets.ParameterWidget
    📦 ui.dialogs.parameter_widgets.SliderWidget
    📦 ui.dialogs.parameter_widgets.TextBoxWidget
    📦 ui.dialogs.preferences_dialog.PreferencesDialog
    📦 ui.dialogs.preview_widgets.CheckerboardPreviewWidget
    📦 ui.dialogs.preview_widgets.LeftPanelPreviewWidget
    📦 ui.dialogs.preview_widgets.RightPanelPreviewWidget
  Calls:
    📞 expanduser (line 26)
    📞 expanduser (line 27)

📄 Editors\ImageEditor\core\ui\dialogs\preferences_dialog.py
  Imports:
    📦 PySide6.QtCore.Qt
    📦 PySide6.QtGui.QColor
    📦 PySide6.QtWidgets.QCheckBox
    📦 PySide6.QtWidgets.QColorDialog
    📦 PySide6.QtWidgets.QComboBox
    📦 PySide6.QtWidgets.QDialog
    📦 PySide6.QtWidgets.QDialogButtonBox
    📦 PySide6.QtWidgets.QFormLayout
    📦 PySide6.QtWidgets.QGroupBox
    📦 PySide6.QtWidgets.QHBoxLayout
    📦 PySide6.QtWidgets.QInputDialog
    📦 PySide6.QtWidgets.QLabel
    📦 PySide6.QtWidgets.QListWidget
    📦 PySide6.QtWidgets.QListWidgetItem
    📦 PySide6.QtWidgets.QMessageBox
    📦 PySide6.QtWidgets.QPushButton
    📦 PySide6.QtWidgets.QSizePolicy
    📦 PySide6.QtWidgets.QSlider
    📦 PySide6.QtWidgets.QTabWidget
    📦 PySide6.QtWidgets.QVBoxLayout
    📦 PySide6.QtWidgets.QWidget
    📦 collections
    📦 core.settings.settings
    📦 core.themes.THEMES
    📦 json
    📦 os
    📦 preview_widgets.LeftPanelPreviewWidget
    📦 preview_widgets.RightPanelPreviewWidget
  Calls:
    📞 expanduser (line 20)
    📞 expanduser (line 21)
    📞 __init__ (line 26)
    📞 super (line 26)
    📞 self.setWindowTitle (line 28)
    📞 self.resize (line 29)
    📞 hasattr (line 31)
    📞 dict (line 31)
    📞 getattr (line 32)
    📞 self._load_custom_preset (line 33)

📄 Editors\ImageEditor\core\ui\mirror_flip_dialog.py
  Imports:
    📦 PySide6.QtCore.Qt
    📦 PySide6.QtCore.Signal
    📦 PySide6.QtGui.QBrush
    📦 PySide6.QtGui.QColor
    📦 PySide6.QtGui.QPainter
    📦 PySide6.QtGui.QPen
    📦 PySide6.QtGui.QPixmap
    📦 PySide6.QtWidgets.QButtonGroup
    📦 PySide6.QtWidgets.QComboBox
    📦 PySide6.QtWidgets.QDialog
    📦 PySide6.QtWidgets.QDialogButtonBox
    📦 PySide6.QtWidgets.QFormLayout
    📦 PySide6.QtWidgets.QGroupBox
    📦 PySide6.QtWidgets.QHBoxLayout
    📦 PySide6.QtWidgets.QLabel
    📦 PySide6.QtWidgets.QPushButton
    📦 PySide6.QtWidgets.QRadioButton
    📦 PySide6.QtWidgets.QSlider
    📦 PySide6.QtWidgets.QSpinBox
    📦 PySide6.QtWidgets.QVBoxLayout
  Calls:
    📞 __init__ (line 9)
    📞 super (line 9)
    📞 self.setWindowTitle (line 10)
    📞 self.setModal (line 11)
    📞 self.setFixedSize (line 12)
    📞 self.setup_ui (line 14)
    📞 QVBoxLayout (line 17)
    📞 QGroupBox (line 20)
    📞 QVBoxLayout (line 21)
    📞 QButtonGroup (line 23)

📄 Editors\ImageEditor\core\ui\nine_slice_importer.py
  Imports:
    📦 PIL.Image
    📦 PySide6.QtCore.QRect
    📦 PySide6.QtCore.Qt
    📦 PySide6.QtGui.QColor
    📦 PySide6.QtGui.QImage
    📦 PySide6.QtGui.QPainter
    📦 PySide6.QtGui.QPen
    📦 PySide6.QtGui.QPixmap
    📦 PySide6.QtWidgets.QButtonGroup
    📦 PySide6.QtWidgets.QCheckBox
    📦 PySide6.QtWidgets.QColorDialog
    📦 PySide6.QtWidgets.QDialog
    📦 PySide6.QtWidgets.QGroupBox
    📦 PySide6.QtWidgets.QHBoxLayout
    📦 PySide6.QtWidgets.QLabel
    📦 PySide6.QtWidgets.QMessageBox
    📦 PySide6.QtWidgets.QPushButton
    📦 PySide6.QtWidgets.QRadioButton
    📦 PySide6.QtWidgets.QScrollArea
    📦 PySide6.QtWidgets.QSlider
    📦 PySide6.QtWidgets.QSpinBox
    📦 PySide6.QtWidgets.QVBoxLayout
    📦 PySide6.QtWidgets.QWidget
    📦 cv2
    📦 numpy
  Calls:
    📞 __init__ (line 28)
    📞 super (line 28)
    📞 self.setWindowTitle (line 50)
    📞 self.setModal (line 51)
    📞 self.resize (line 52)
    📞 len (line 57)
    📞 np.dstack (line 59)
    📞 np.full_like (line 59)
    📞 np.dstack (line 62)
    📞 np.full (line 62)

📄 Editors\ImageEditor\core\ui\rotate_dialog.py
  Imports:
    📦 PIL.Image
    📦 PySide6.QtCore.QTimer
    📦 PySide6.QtCore.Qt
    📦 PySide6.QtCore.Signal
    📦 PySide6.QtGui.QBrush
    📦 PySide6.QtGui.QColor
    📦 PySide6.QtGui.QImage
    📦 PySide6.QtGui.QPainter
    📦 PySide6.QtGui.QPen
    📦 PySide6.QtGui.QPixmap
    📦 PySide6.QtGui.QTransform
    📦 PySide6.QtWidgets.QButtonGroup
    📦 PySide6.QtWidgets.QDialog
    📦 PySide6.QtWidgets.QDialogButtonBox
    📦 PySide6.QtWidgets.QHBoxLayout
    📦 PySide6.QtWidgets.QLabel
    📦 PySide6.QtWidgets.QPushButton
    📦 PySide6.QtWidgets.QRadioButton
    📦 PySide6.QtWidgets.QSlider
    📦 PySide6.QtWidgets.QSpinBox
    📦 PySide6.QtWidgets.QVBoxLayout
    📦 PySide6.QtWidgets.QWidget
    📦 core.state.state
    📦 numpy
    📦 traceback
  Calls:
    📞 __init__ (line 13)
    📞 super (line 13)
    📞 self.setMinimumSize (line 14)
    📞 self.setAlignment (line 15)
    📞 self.setText (line 16)
    📞 self.setStyleSheet (line 17)
    📞 self.update (line 23)
    📞 QPainter (line 27)
    📞 painter.setRenderHint (line 28)
    📞 self.width (line 31)

📄 Editors\ImageEditor\core\ui\panels\left_panel.py
  Imports:
    📦 PySide6.QtCore.QPoint
    📦 PySide6.QtCore.Qt
    📦 PySide6.QtGui.QBrush
    📦 PySide6.QtGui.QColor
    📦 PySide6.QtGui.QPainter
    📦 PySide6.QtGui.QPen
    📦 PySide6.QtWidgets.QCheckBox
    📦 PySide6.QtWidgets.QColorDialog
    📦 PySide6.QtWidgets.QFrame
    📦 PySide6.QtWidgets.QGridLayout
    📦 PySide6.QtWidgets.QHBoxLayout
    📦 PySide6.QtWidgets.QLabel
    📦 PySide6.QtWidgets.QLineEdit
    📦 PySide6.QtWidgets.QPushButton
    📦 PySide6.QtWidgets.QScrollArea
    📦 PySide6.QtWidgets.QSizePolicy
    📦 PySide6.QtWidgets.QSlider
    📦 PySide6.QtWidgets.QToolButton
    📦 PySide6.QtWidgets.QVBoxLayout
    📦 PySide6.QtWidgets.QWidget
    📦 core.settings.settings
    📦 core.state.state
    📦 core.themes.get_theme
    📦 ui.tooltips.attach_tooltip
  Calls:
    📞 __init__ (line 11)
    📞 super (line 11)
    📞 self.setFixedSize (line 12)
    📞 self.setMinimumSize (line 13)
    📞 self.setMaximumSize (line 14)
    📞 QPainter (line 17)
    📞 painter.setRenderHint (line 18)
    📞 painter.fillRect (line 21)
    📞 self.rect (line 21)
    📞 QColor (line 21)

📄 Editors\ImageEditor\core\ui\panels\right_panel.py
  Imports:
    📦 PySide6.QtCore.QTimer
    📦 PySide6.QtCore.Qt
    📦 PySide6.QtWidgets.QCheckBox
    📦 PySide6.QtWidgets.QColorDialog
    📦 PySide6.QtWidgets.QFrame
    📦 PySide6.QtWidgets.QHBoxLayout
    📦 PySide6.QtWidgets.QInputDialog
    📦 PySide6.QtWidgets.QLabel
    📦 PySide6.QtWidgets.QLineEdit
    📦 PySide6.QtWidgets.QMenu
    📦 PySide6.QtWidgets.QPushButton
    📦 PySide6.QtWidgets.QScrollArea
    📦 PySide6.QtWidgets.QSizePolicy
    📦 PySide6.QtWidgets.QSlider
    📦 PySide6.QtWidgets.QTabWidget
    📦 PySide6.QtWidgets.QVBoxLayout
    📦 PySide6.QtWidgets.QWidget
    📦 copy
    📦 core.settings.settings
    📦 core.state.state
    📦 core.themes.get_theme
    📦 ui.main_window.MainWindow
    📦 ui.preview.PreviewBox
    📦 ui.tooltips.attach_tooltip
  Calls:
    📞 __init__ (line 15)
    📞 super (line 15)
    📞 QPushButton (line 16)
    📞 setCheckable (line 17)
    📞 setChecked (line 18)
    📞 connect (line 19)
    📞 setStyleSheet (line 21)
    📞 setStyleSheet (line 37)
    📞 setVisible (line 54)
    📞 setSizePolicy (line 55)

📄 Editors\ImageEditor\core\ui\sprite_sheet_importer.py
  Imports:
    📦 PIL.Image
    📦 PySide6.QtCore.Qt
    📦 PySide6.QtGui.QColor
    📦 PySide6.QtGui.QImage
    📦 PySide6.QtGui.QPainter
    📦 PySide6.QtGui.QPen
    📦 PySide6.QtGui.QPixmap
    📦 PySide6.QtWidgets.QButtonGroup
    📦 PySide6.QtWidgets.QCheckBox
    📦 PySide6.QtWidgets.QColorDialog
    📦 PySide6.QtWidgets.QDialog
    📦 PySide6.QtWidgets.QFrame
    📦 PySide6.QtWidgets.QGroupBox
    📦 PySide6.QtWidgets.QHBoxLayout
    📦 PySide6.QtWidgets.QLabel
    📦 PySide6.QtWidgets.QMessageBox
    📦 PySide6.QtWidgets.QPushButton
    📦 PySide6.QtWidgets.QRadioButton
    📦 PySide6.QtWidgets.QScrollArea
    📦 PySide6.QtWidgets.QSpinBox
    📦 PySide6.QtWidgets.QVBoxLayout
    📦 PySide6.QtWidgets.QWidget
    📦 collections.Counter
    📦 cv2
    📦 numpy
  Calls:
    📞 __init__ (line 21)
    📞 super (line 21)
    📞 self.setMinimumSize (line 22)
    📞 image_array.copy (line 34)
    📞 self.update (line 35)
    📞 self.update (line 40)
    📞 self.update (line 45)
    📞 QPainter (line 49)
    📞 painter.setRenderHint (line 50)
    📞 painter.fillRect (line 53)

📄 Editors\ImageEditor\core\ui\tooltips.py
  Imports:
    📦 PySide6.QtCore.QPoint
    📦 PySide6.QtCore.QTimer
    📦 PySide6.QtCore.Qt
    📦 PySide6.QtWidgets.QApplication
    📦 PySide6.QtWidgets.QLabel
  Calls:
    📞 __init__ (line 6)
    📞 super (line 6)
    📞 self.setWindowFlags (line 7)
    📞 self.setStyleSheet (line 8)
    📞 self.setAlignment (line 9)
    📞 self.adjustSize (line 10)
    📞 _tooltip_instance.hide (line 18)
    📞 _tooltip_instance.deleteLater (line 19)
    📞 CustomTooltip (line 20)
    📞 widget.mapToGlobal (line 21)

📄 Editors\ImageEditor\ui\__init__.py

📄 Editors\ImageEditor\ImageEditor.py
  Imports:
    📦 core.app.*
    📦 ui.main_window.MainWindow

📄 Editors\ModelEditor\__init__.py

📄 Editors\ImageEditor\core\ui\texture_atlas_dialog.py
  Imports:
    📦 PIL.Image
    📦 PySide6.QtCore.QMimeData
    📦 PySide6.QtCore.QPoint
    📦 PySide6.QtCore.QRect
    📦 PySide6.QtCore.QTimer
    📦 PySide6.QtCore.Qt
    📦 PySide6.QtCore.Signal
    📦 PySide6.QtGui.QBrush
    📦 PySide6.QtGui.QColor
    📦 PySide6.QtGui.QDrag
    📦 PySide6.QtGui.QImage
    📦 PySide6.QtGui.QPainter
    📦 PySide6.QtGui.QPen
    📦 PySide6.QtGui.QPixmap
    📦 PySide6.QtWidgets.QButtonGroup
    📦 PySide6.QtWidgets.QCheckBox
    📦 PySide6.QtWidgets.QColorDialog
    📦 PySide6.QtWidgets.QComboBox
    📦 PySide6.QtWidgets.QDialog
    📦 PySide6.QtWidgets.QDialogButtonBox
    📦 PySide6.QtWidgets.QFormLayout
    📦 PySide6.QtWidgets.QFrame
    📦 PySide6.QtWidgets.QGridLayout
    📦 PySide6.QtWidgets.QGroupBox
    📦 PySide6.QtWidgets.QHBoxLayout
    📦 PySide6.QtWidgets.QLabel
    📦 PySide6.QtWidgets.QLineEdit
    📦 PySide6.QtWidgets.QListWidget
    📦 PySide6.QtWidgets.QListWidgetItem
    📦 PySide6.QtWidgets.QMainWindow
    📦 PySide6.QtWidgets.QMenu
    📦 PySide6.QtWidgets.QMessageBox
    📦 PySide6.QtWidgets.QPushButton
    📦 PySide6.QtWidgets.QRadioButton
    📦 PySide6.QtWidgets.QScrollArea
    📦 PySide6.QtWidgets.QSizePolicy
    📦 PySide6.QtWidgets.QSlider
    📦 PySide6.QtWidgets.QSpacerItem
    📦 PySide6.QtWidgets.QSpinBox
    📦 PySide6.QtWidgets.QSplitter
    📦 PySide6.QtWidgets.QTabWidget
    📦 PySide6.QtWidgets.QVBoxLayout
    📦 PySide6.QtWidgets.QWidget
    📦 core.atlas_manager.AtlasCell
    📦 core.atlas_manager.AtlasManager
    📦 core.state.state
    📦 core.texture_utils.generate_block_texture_qimage
    📦 numpy
    📦 os
    📦 tempfile
    📦 time
  Calls:
    📞 Signal (line 19)
    📞 Signal (line 20)
    📞 __init__ (line 23)
    📞 super (line 23)
    📞 self.setDragDropMode (line 24)
    📞 self.setAcceptDrops (line 25)
    📞 self.setDragEnabled (line 26)
    📞 self.setDropIndicatorShown (line 27)
    📞 self.currentRow (line 31)
    📞 startDrag (line 32)

📄 Editors\ImageEditor\core\ui\dialogs\effect_dialog.py
  Imports:
    📦 Core.Debug.debug
    📦 PIL.Image
    📦 PIL.ImageEnhance
    📦 PIL.ImageFilter
    📦 PySide6.QtCore.QTimer
    📦 PySide6.QtCore.Qt
    📦 PySide6.QtCore.Signal
    📦 PySide6.QtGui.QBrush
    📦 PySide6.QtGui.QColor
    📦 PySide6.QtGui.QImage
    📦 PySide6.QtGui.QPainter
    📦 PySide6.QtGui.QPen
    📦 PySide6.QtGui.QPixmap
    📦 PySide6.QtWidgets.QCheckBox
    📦 PySide6.QtWidgets.QColorDialog
    📦 PySide6.QtWidgets.QComboBox
    📦 PySide6.QtWidgets.QDialog
    📦 PySide6.QtWidgets.QDoubleSpinBox
    📦 PySide6.QtWidgets.QFileDialog
    📦 PySide6.QtWidgets.QFrame
    📦 PySide6.QtWidgets.QGridLayout
    📦 PySide6.QtWidgets.QGroupBox
    📦 PySide6.QtWidgets.QHBoxLayout
    📦 PySide6.QtWidgets.QLabel
    📦 PySide6.QtWidgets.QLineEdit
    📦 PySide6.QtWidgets.QListWidget
    📦 PySide6.QtWidgets.QListWidgetItem
    📦 PySide6.QtWidgets.QPushButton
    📦 PySide6.QtWidgets.QRadioButton
    📦 PySide6.QtWidgets.QScrollArea
    📦 PySide6.QtWidgets.QSlider
    📦 PySide6.QtWidgets.QSpinBox
    📦 PySide6.QtWidgets.QTabWidget
    📦 PySide6.QtWidgets.QTextEdit
    📦 PySide6.QtWidgets.QVBoxLayout
    📦 PySide6.QtWidgets.QWidget
    📦 atmospheric_lighting_helpers.AtmosphericLightingSystem
    📦 atmospheric_lighting_helpers.LightSource
    📦 colorsys.hsv_to_rgb
    📦 colorsys.rgb_to_hsv
    📦 core.state.state
    📦 core.texture_utils.generate_block_texture_qimage
    📦 cv2
    📦 math
    📦 numpy
    📦 random
    📦 scipy.ndimage
    📦 traceback
    📦 ui.dialogs.parameter_widgets.CheckboxWidget
    📦 ui.dialogs.parameter_widgets.ColorListWidget
    📦 ui.dialogs.parameter_widgets.ColorPickerWidget
    📦 ui.dialogs.parameter_widgets.DoubleSliderWidget
    📦 ui.dialogs.parameter_widgets.DropdownWidget
    📦 ui.dialogs.parameter_widgets.ParameterWidget
    📦 ui.dialogs.parameter_widgets.SliderWidget
    📦 ui.dialogs.parameter_widgets.TextBoxWidget
    📦 ui.dialogs.preview_widgets.CheckerboardPreviewWidget
    📦 ui.main_window.MapAnimationSystem
  Calls:
    📞 __init__ (line 26)
    📞 super (line 26)
    📞 QTimer (line 32)
    📞 connect (line 33)
    📞 setSingleShot (line 34)
    📞 self._get_editor_state (line 49)
    📞 self.setup_ui (line 51)
    📞 hasattr (line 57)
    📞 lm.get_current_layer (line 60)
    📞 len (line 62)

📄 Editors\ImageEditor\core\ui\timeline.py
  Imports:
    📦 Core.Debug.debug
    📦 PySide6.QtCore.QPoint
    📦 PySide6.QtCore.QRect
    📦 PySide6.QtCore.QTimer
    📦 PySide6.QtCore.Qt
    📦 PySide6.QtCore.Signal
    📦 PySide6.QtGui.QBrush
    📦 PySide6.QtGui.QColor
    📦 PySide6.QtGui.QFont
    📦 PySide6.QtGui.QImage
    📦 PySide6.QtGui.QKeySequence
    📦 PySide6.QtGui.QPainter
    📦 PySide6.QtGui.QPen
    📦 PySide6.QtGui.QPixmap
    📦 PySide6.QtGui.QPolygon
    📦 PySide6.QtGui.QShortcut
    📦 PySide6.QtGui.QWheelEvent
    📦 PySide6.QtWidgets.QCheckBox
    📦 PySide6.QtWidgets.QColorDialog
    📦 PySide6.QtWidgets.QComboBox
    📦 PySide6.QtWidgets.QFrame
    📦 PySide6.QtWidgets.QHBoxLayout
    📦 PySide6.QtWidgets.QInputDialog
    📦 PySide6.QtWidgets.QLabel
    📦 PySide6.QtWidgets.QMenu
    📦 PySide6.QtWidgets.QMessageBox
    📦 PySide6.QtWidgets.QPushButton
    📦 PySide6.QtWidgets.QScrollArea
    📦 PySide6.QtWidgets.QSizePolicy
    📦 PySide6.QtWidgets.QSlider
    📦 PySide6.QtWidgets.QVBoxLayout
    📦 PySide6.QtWidgets.QWidget
    📦 core.state.state
    📦 cv2
    📦 layers.layer.Frame
    📦 numpy
  Calls:
    📞 __init__ (line 21)
    📞 super (line 21)
    📞 self.setMinimumHeight (line 24)
    📞 self.setMaximumHeight (line 25)
    📞 y (line 31)
    📞 event.angleDelta (line 31)
    📞 horizontalScrollBar (line 34)
    📞 event.modifiers (line 38)
    📞 wheelEvent (line 40)
    📞 super (line 40)

📄 Editors\ModelEditor\examples\GoodPerformanceButOnlyShowsModels.py
  Imports:
    📦 OpenGL.GL.*
    📦 OpenGL.GLU.*
    📦 math
    📦 numpy
    📦 os
    📦 pygame
    📦 pygame.locals.*
    📦 pygltflib.GLTF2
    📦 tkinter.Tk
    📦 tkinter.filedialog
    📦 traceback
  Calls:
    📞 np.array (line 12)
    📞 np.array (line 13)
    📞 np.array (line 14)
    📞 self.update_vectors (line 32)
    📞 np.array (line 35)
    📞 math.cos (line 36)
    📞 math.radians (line 36)
    📞 math.cos (line 36)
    📞 math.radians (line 36)
    📞 math.sin (line 37)

📄 Editors\ImageEditor\core\ui\preview.py
  Imports:
    📦 PySide6.QtCore.QPoint
    📦 PySide6.QtCore.QRect
    📦 PySide6.QtCore.QTimer
    📦 PySide6.QtCore.Qt
    📦 PySide6.QtCore.Signal
    📦 PySide6.QtGui.QBrush
    📦 PySide6.QtGui.QColor
    📦 PySide6.QtGui.QCursor
    📦 PySide6.QtGui.QGuiApplication
    📦 PySide6.QtGui.QImage
    📦 PySide6.QtGui.QPainter
    📦 PySide6.QtGui.QPen
    📦 PySide6.QtGui.QPixmap
    📦 PySide6.QtWidgets.QSizePolicy
    📦 PySide6.QtWidgets.QWidget
    📦 core.selection_manager.SimpleSelectionManager
    📦 core.settings.settings
    📦 core.state.state
    📦 core.themes.get_theme
    📦 math
    📦 math.cos
    📦 math.radians
    📦 math.sin
    📦 matplotlib.path.Path
    📦 numpy
    📦 random
    📦 scipy.ndimage.convolve
    📦 scipy.ndimage.gaussian_filter
    📦 traceback
  Calls:
    📞 print (line 17)
    📞 Signal (line 21)
    📞 __init__ (line 24)
    📞 super (line 24)
    📞 QColor (line 25)
    📞 get_theme (line 27)
    📞 getattr (line 28)
    📞 self.setMinimumSize (line 29)
    📞 self.setSizePolicy (line 30)
    📞 self.setFocusPolicy (line 32)

📄 Editors\ObjectEditor\__init__.py

📄 Editors\ObjectEditor\Core\__init__.py
  Imports:
    📦 event_model.EventModel
    📦 object_model.ObjectModel

📄 Editors\ObjectEditor\Core\event_model.py
  Imports:
    📦 dataclasses.dataclass
    📦 typing.Optional

📄 Editors\ObjectEditor\Core\object_model.py
  Imports:
    📦 dataclasses.dataclass
    📦 dataclasses.field
    📦 datetime.datetime
    📦 typing.Dict
    📦 typing.List
    📦 typing.Optional
  Calls:
    📞 field (line 31)
    📞 isoformat (line 40)
    📞 datetime.now (line 40)
    📞 isoformat (line 41)
    📞 datetime.now (line 41)
    📞 cls (line 53)
    📞 data.get (line 54)
    📞 data.get (line 55)
    📞 data.get (line 56)
    📞 data.get (line 57)

📄 Editors\ObjectEditor\object_editor_menu.py
  Imports:
    📦 PySide6.QtCore.Qt
    📦 PySide6.QtGui.QAction
    📦 PySide6.QtGui.QKeySequence
    📦 PySide6.QtWidgets.QMenu
    📦 PySide6.QtWidgets.QMenuBar
  Calls:
    📞 __init__ (line 18)
    📞 super (line 18)
    📞 self.setMaximumHeight (line 20)
    📞 self.setMinimumHeight (line 21)
    📞 self._create_menus (line 22)
    📞 self.addMenu (line 28)
    📞 QAction (line 30)
    📞 setShortcut (line 31)
    📞 setStatusTip (line 32)
    📞 file_menu.addAction (line 33)

📄 Editors\ImageEditor\core\ui\main_window.py
  Imports:
    📦 Core.Debug.debug
    📦 Core.Rendering.Canvas_2D.Canvas_2D
    📦 Core.VenvManager.VenvManager
    📦 PIL.Image
    📦 PIL.ImageEnhance
    📦 PIL.ImageFilter
    📦 PySide6.QtCore.QCoreApplication
    📦 PySide6.QtCore.QTimer
    📦 PySide6.QtCore.Qt
    📦 PySide6.QtGui.QAction
    📦 PySide6.QtGui.QImage
    📦 PySide6.QtGui.QKeySequence
    📦 PySide6.QtGui.QShortcut
    📦 PySide6.QtWidgets.QApplication
    📦 PySide6.QtWidgets.QButtonGroup
    📦 PySide6.QtWidgets.QCheckBox
    📦 PySide6.QtWidgets.QComboBox
    📦 PySide6.QtWidgets.QDialog
    📦 PySide6.QtWidgets.QDialogButtonBox
    📦 PySide6.QtWidgets.QFileDialog
    📦 PySide6.QtWidgets.QHBoxLayout
    📦 PySide6.QtWidgets.QLabel
    📦 PySide6.QtWidgets.QMainWindow
    📦 PySide6.QtWidgets.QMenuBar
    📦 PySide6.QtWidgets.QMessageBox
    📦 PySide6.QtWidgets.QProgressDialog
    📦 PySide6.QtWidgets.QPushButton
    📦 PySide6.QtWidgets.QRadioButton
    📦 PySide6.QtWidgets.QSizePolicy
    📦 PySide6.QtWidgets.QSpacerItem
    📦 PySide6.QtWidgets.QSpinBox
    📦 PySide6.QtWidgets.QVBoxLayout
    📦 PySide6.QtWidgets.QWidget
    📦 core.ai_helpers.apply_cumulative_changes
    📦 core.ai_helpers.generate_frames_parallel
    📦 core.ai_image_operations.AIImageOperations
    📦 core.ai_image_operations.AIQuotaExceededError
    📦 core.ai_requirements.RequirementChecker
    📦 core.ai_worker_threads.AnchorDetectionWorkerThread
    📦 core.ai_worker_threads.AnimationWorkerThread
    📦 core.ai_worker_threads.BaseImageWorkerThread
    📦 core.atlas_manager.AtlasManager
    📦 core.gemini_client.GeminiClient
    📦 core.history.HistoryManager
    📦 core.pgsprite_io
    📦 core.pgsprite_io.pgsprite_io
    📦 core.rigging.RigAnimation
    📦 core.settings.settings
    📦 core.smart_layer_separation.SmartLayerSeparator
    📦 core.state.state
    📦 core.texture_utils.generate_block_texture_qimage
    📦 core.themes.THEMES
    📦 core.themes.get_theme
    📦 cv2
    📦 datetime
    📦 importlib
    📦 json
    📦 layers.layer.Frame
    📦 math
    📦 numpy
    📦 os
    📦 pathlib.Path
    📦 pypatchmatch.inpaint
    📦 random
    📦 scipy.ndimage
    📦 services.effect_processor.EffectProcessor
    📦 sys
    📦 traceback
    📦 ui.ai_dialogs.AIAnimationDialog
    📦 ui.ai_dialogs.AIBaseImageDialog
    📦 ui.ai_dialogs.AIChatDialog
    📦 ui.ai_dialogs.AIJSONEditorDialog
    📦 ui.ai_dialogs.AIProgressDialog
    📦 ui.ai_dialogs.AIRequestSpecDialog
    📦 ui.ai_dialogs.ChangePreviewWidget
    📦 ui.background_removal_dialog.BackgroundRemovalDialog
    📦 ui.character_creator_dialog.CharacterCreatorDialog
    📦 ui.components.menu_bar.ImageEditorMenuBar
    📦 ui.components.status_bar.ImageEditorStatusBar
    📦 ui.dialogs.EFFECT_REGISTRY
    📦 ui.dialogs.MergeReplaceDialog
    📦 ui.dialogs.NewImageDialog
    📦 ui.dialogs.OriginSelectionDialog
    📦 ui.dialogs.PreferencesDialog
    📦 ui.dialogs.UnifiedEffectDialog
    📦 ui.mirror_flip_dialog.MirrorFlipDialog
    📦 ui.nine_slice_importer.NineSliceDialog
    📦 ui.panels.left_panel.LeftPanel
    📦 ui.panels.right_panel.RightPanel
    📦 ui.preview.CheckerboardCanvas
    📦 ui.rotate_dialog.RotateDialog
    📦 ui.sprite_sheet_importer.SpriteSheetImporterDialog
    📦 ui.texture_atlas_dialog.TextureAtlasDialog
    📦 ui.timeline.TimelineWidget
  Calls:
    📞 get (line 86)
    📞 self._detect_features (line 89)
    📞 biome_animations.items (line 93)
    📞 self._is_animation_applicable (line 95)
    📞 self._get_animation_display_name (line 97)
    📞 self._get_animation_description (line 98)
    📞 self._count_animation_pixels (line 99)
    📞 np.array (line 106)
    📞 self._get_water_pixels (line 112)
    📞 self._get_land_pixels (line 116)

📄 Editors\ObjectEditor\object_editor_ui.py
  Imports:
    📦 PySide6.QtCore.Qt
    📦 PySide6.QtWidgets.QFrame
    📦 PySide6.QtWidgets.QHBoxLayout
    📦 PySide6.QtWidgets.QLabel
    📦 PySide6.QtWidgets.QSplitter
    📦 PySide6.QtWidgets.QVBoxLayout
    📦 PySide6.QtWidgets.QWidget
  Calls:
    📞 __init__ (line 23)
    📞 super (line 23)
    📞 QVBoxLayout (line 25)
    📞 layout.setContentsMargins (line 26)
    📞 QSplitter (line 31)
    📞 setChildrenCollapsible (line 32)
    📞 layout.addWidget (line 33)
    📞 self._make_placeholder (line 40)
    📞 addWidget (line 41)
    📞 self._make_placeholder (line 44)

📄 Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py
  Imports:
    📦 OpenGL.GL.*
    📦 OpenGL.GLU.*
    📦 OpenGL.arrays.vbo
    📦 PySide6.QtCore.QPoint
    📦 PySide6.QtCore.QTimer
    📦 PySide6.QtCore.Qt
    📦 PySide6.QtCore.Signal
    📦 PySide6.QtGui.QAction
    📦 PySide6.QtGui.QColor
    📦 PySide6.QtGui.QKeySequence
    📦 PySide6.QtOpenGLWidgets.QOpenGLWidget
    📦 PySide6.QtWidgets.QApplication
    📦 PySide6.QtWidgets.QCheckBox
    📦 PySide6.QtWidgets.QColorDialog
    📦 PySide6.QtWidgets.QDoubleSpinBox
    📦 PySide6.QtWidgets.QFileDialog
    📦 PySide6.QtWidgets.QFrame
    📦 PySide6.QtWidgets.QGroupBox
    📦 PySide6.QtWidgets.QHBoxLayout
    📦 PySide6.QtWidgets.QLabel
    📦 PySide6.QtWidgets.QListWidget
    📦 PySide6.QtWidgets.QMainWindow
    📦 PySide6.QtWidgets.QMenu
    📦 PySide6.QtWidgets.QMenuBar
    📦 PySide6.QtWidgets.QMessageBox
    📦 PySide6.QtWidgets.QPushButton
    📦 PySide6.QtWidgets.QSlider
    📦 PySide6.QtWidgets.QSplitter
    📦 PySide6.QtWidgets.QStatusBar
    📦 PySide6.QtWidgets.QVBoxLayout
    📦 PySide6.QtWidgets.QWidget
    📦 collections.deque
    📦 dataclasses.asdict
    📦 dataclasses.dataclass
    📦 enum.Enum
    📦 json
    📦 math
    📦 moderngl
    📦 numpy
    📦 os
    📦 sys
    📦 trimesh
    📦 typing.List
    📦 typing.Optional
    📦 typing.Tuple
  Calls:
    📞 asdict (line 54)
    📞 cls (line 62)
    📞 Vector3 (line 63)
    📞 data.get (line 64)
    📞 tuple (line 65)
    📞 data.get (line 65)
    📞 data.get (line 66)
    📞 asdict (line 79)
    📞 asdict (line 80)
    📞 cls (line 87)

📄 Editors\ObjectEditor\object_editor.py
  Imports:
    📦 Core.Debug.debug
    📦 Core.Debug.debug_critical
    📦 Core.EditorInterface.EditorInterface
    📦 PySide6.QtCore.QObject
    📦 PySide6.QtCore.Qt
    📦 PySide6.QtCore.Signal
    📦 PySide6.QtGui.QPixmap
    📦 PySide6.QtWidgets.QFrame
    📦 PySide6.QtWidgets.QHBoxLayout
    📦 PySide6.QtWidgets.QMainWindow
    📦 PySide6.QtWidgets.QMessageBox
    📦 PySide6.QtWidgets.QSplitter
    📦 PySide6.QtWidgets.QStackedWidget
    📦 PySide6.QtWidgets.QTabBar
    📦 PySide6.QtWidgets.QVBoxLayout
    📦 PySide6.QtWidgets.QWidget
    📦 UI.code_editor_widget.CodeEditorDock
    📦 UI.events_panel.DEFAULT_EVENT_CATEGORIES
    📦 UI.events_panel.ObjectEventsPanel
    📦 UI.object_editor_menu.ObjectEditorMenu
    📦 UI.properties_panel.ObjectPropertiesPanel
    📦 json
    📦 object_events_panel.DEFAULT_EVENT_CATEGORIES
    📦 pathlib.Path
  Calls:
    📞 Signal (line 40)
    📞 Signal (line 41)
    📞 Signal (line 43)
    📞 __init__ (line 46)
    📞 super (line 46)
    📞 isinstance (line 51)
    📞 self._create_default_resource (line 52)
    📞 self._build_ui (line 62)
    📞 self._load_object_into_panels (line 63)
    📞 QVBoxLayout (line 73)

📄 Editors\ObjectEditor\object_events_panel.py
  Imports:
    📦 PySide6.QtCore.Qt
    📦 PySide6.QtCore.Signal
    📦 PySide6.QtGui.QColor
    📦 PySide6.QtGui.QFont
    📦 PySide6.QtWidgets.QDialog
    📦 PySide6.QtWidgets.QGroupBox
    📦 PySide6.QtWidgets.QHBoxLayout
    📦 PySide6.QtWidgets.QLabel
    📦 PySide6.QtWidgets.QListWidget
    📦 PySide6.QtWidgets.QListWidgetItem
    📦 PySide6.QtWidgets.QPushButton
    📦 PySide6.QtWidgets.QTreeWidget
    📦 PySide6.QtWidgets.QTreeWidgetItem
    📦 PySide6.QtWidgets.QVBoxLayout
    📦 PySide6.QtWidgets.QWidget
    📦 __future__.annotations
    📦 typing.Dict
    📦 typing.List
    📦 typing.Optional
  Calls:
    📞 range (line 68)
    📞 range (line 74)
    📞 Signal (line 101)
    📞 Signal (line 102)
    📞 Signal (line 103)
    📞 __init__ (line 110)
    📞 super (line 110)
    📞 self._build_ui (line 117)
    📞 QVBoxLayout (line 124)
    📞 layout.setContentsMargins (line 125)

📄 Editors\ObjectEditor\object_properties_panel.py
  Imports:
    📦 Core.Debug.debug
    📦 PySide6.QtCore.QSize
    📦 PySide6.QtCore.Qt
    📦 PySide6.QtCore.Signal
    📦 PySide6.QtGui.QFont
    📦 PySide6.QtGui.QIcon
    📦 PySide6.QtGui.QPixmap
    📦 PySide6.QtWidgets.QCheckBox
    📦 PySide6.QtWidgets.QComboBox
    📦 PySide6.QtWidgets.QDialog
    📦 PySide6.QtWidgets.QFileDialog
    📦 PySide6.QtWidgets.QFormLayout
    📦 PySide6.QtWidgets.QGroupBox
    📦 PySide6.QtWidgets.QHBoxLayout
    📦 PySide6.QtWidgets.QLabel
    📦 PySide6.QtWidgets.QLineEdit
    📦 PySide6.QtWidgets.QListWidgetItem
    📦 PySide6.QtWidgets.QPushButton
    📦 PySide6.QtWidgets.QSizePolicy
    📦 PySide6.QtWidgets.QSpinBox
    📦 PySide6.QtWidgets.QTreeWidget
    📦 PySide6.QtWidgets.QTreeWidgetItem
    📦 PySide6.QtWidgets.QVBoxLayout
    📦 PySide6.QtWidgets.QWidget
    📦 __future__.annotations
    📦 pathlib.Path
    📦 typing.Dict
    📦 typing.List
    📦 typing.Optional
  Calls:
    📞 __init__ (line 38)
    📞 super (line 38)
    📞 self.setWindowTitle (line 43)
    📞 self.setMinimumSize (line 44)
    📞 QVBoxLayout (line 46)
    📞 QLabel (line 49)
    📞 layout.addWidget (line 50)
    📞 QTreeWidget (line 53)
    📞 setHeaderHidden (line 54)
    📞 connect (line 55)

📄 Editors\ObjectEditor\Services\__init__.py
  Imports:
    📦 object_file_service.ObjectFileService
    📦 object_validation_service.ObjectValidationService

📄 Editors\ObjectEditor\Services\object_file_service.py
  Imports:
    📦 Core.Debug.debug
    📦 Editors.ObjectEditor.Core.object_model.ObjectModel
    📦 json
    📦 pathlib.Path
    📦 typing.Dict
    📦 typing.Optional
  Calls:
    📞 folder_path.mkdir (line 26)
    📞 folder_path.mkdir (line 36)
    📞 object_file_path.exists (line 43)
    📞 open (line 46)
    📞 json.load (line 47)
    📞 ObjectModel.from_dict (line 49)
    📞 debug (line 52)
    📞 object_model.update_modified (line 58)
    📞 self.get_object_file_path (line 59)
    📞 mkdir (line 64)

📄 Editors\ObjectEditor\sprite_browser_widget.py

📄 Editors\ObjectEditor\UI\__init__.py
  Imports:
    📦 code_editor_widget.CodeEditorDock
    📦 events_panel.DEFAULT_EVENT_CATEGORIES
    📦 events_panel.ObjectEventsPanel
    📦 object_editor_menu.ObjectEditorMenu
    📦 parent_child_panel.ParentChildPanel
    📦 properties_panel.ObjectPropertiesPanel

📄 Editors\ObjectEditor\Services\object_validation_service.py
  Imports:
    📦 Core.CodeSystem.parser.PGSLParser
    📦 Core.CodeSystem.parser.ParseError
    📦 Core.CodeSystem.syntax.SyntaxValidator
    📦 typing.Dict
    📦 typing.List
    📦 typing.Optional
    📦 typing.Tuple
  Calls:
    📞 SyntaxValidator (line 15)
    📞 validate (line 24)
    📞 code.split (line 28)
    📞 join (line 30)
    📞 validate (line 31)
    📞 events.items (line 46)
    📞 validate (line 54)
    📞 PGSLParser (line 62)
    📞 parser.parse (line 63)

📄 Editors\ObjectEditor\UI\code_editor_widget.py
  Imports:
    📦 Core.Code.Unified.EditorContext
    📦 Core.Code.Unified.UnifiedCodeEditor
    📦 PySide6.QtCore.Qt
    📦 PySide6.QtCore.Signal
    📦 PySide6.QtWidgets.QFrame
    📦 PySide6.QtWidgets.QHBoxLayout
    📦 PySide6.QtWidgets.QLabel
    📦 PySide6.QtWidgets.QMessageBox
    📦 PySide6.QtWidgets.QPushButton
    📦 PySide6.QtWidgets.QVBoxLayout
    📦 PySide6.QtWidgets.QWidget
    📦 ast
  Calls:
    📞 Signal (line 21)
    📞 Signal (line 22)
    📞 Signal (line 23)
    📞 __init__ (line 26)
    📞 super (line 26)
    📞 self._build_ui (line 39)
    📞 connect (line 42)
    📞 QVBoxLayout (line 46)
    📞 layout.setContentsMargins (line 47)
    📞 layout.setSpacing (line 48)

📄 Editors\ObjectEditor\UI\object_editor_menu.py
  Imports:
    📦 PySide6.QtCore.Qt
    📦 PySide6.QtGui.QAction
    📦 PySide6.QtGui.QKeySequence
    📦 PySide6.QtWidgets.QMenu
    📦 PySide6.QtWidgets.QMenuBar
  Calls:
    📞 __init__ (line 18)
    📞 super (line 18)
    📞 self.setMaximumHeight (line 20)
    📞 self.setMinimumHeight (line 21)
    📞 self._create_menus (line 22)
    📞 self.addMenu (line 28)
    📞 QAction (line 30)
    📞 setShortcut (line 31)
    📞 setStatusTip (line 32)
    📞 file_menu.addAction (line 33)

📄 Editors\ObjectEditor\UI\parent_child_panel.py
  Imports:
    📦 PySide6.QtCore.Qt
    📦 PySide6.QtCore.Signal
    📦 PySide6.QtWidgets.QComboBox
    📦 PySide6.QtWidgets.QGroupBox
    📦 PySide6.QtWidgets.QHBoxLayout
    📦 PySide6.QtWidgets.QLabel
    📦 PySide6.QtWidgets.QListWidget
    📦 PySide6.QtWidgets.QListWidgetItem
    📦 PySide6.QtWidgets.QPushButton
    📦 PySide6.QtWidgets.QVBoxLayout
    📦 PySide6.QtWidgets.QWidget
    📦 typing.Dict
    📦 typing.List
    📦 typing.Optional
  Calls:
    📞 Signal (line 18)
    📞 Signal (line 19)
    📞 __init__ (line 22)
    📞 super (line 22)
    📞 self._build_ui (line 24)
    📞 QVBoxLayout (line 28)
    📞 layout.setContentsMargins (line 29)
    📞 layout.setSpacing (line 30)
    📞 QGroupBox (line 33)
    📞 QVBoxLayout (line 34)

📄 Editors\ObjectEditor\UI\events_panel.py
  Imports:
    📦 PySide6.QtCore.Qt
    📦 PySide6.QtCore.Signal
    📦 PySide6.QtGui.QColor
    📦 PySide6.QtGui.QFont
    📦 PySide6.QtGui.QIcon
    📦 PySide6.QtWidgets.QDialog
    📦 PySide6.QtWidgets.QGroupBox
    📦 PySide6.QtWidgets.QHBoxLayout
    📦 PySide6.QtWidgets.QLabel
    📦 PySide6.QtWidgets.QListWidget
    📦 PySide6.QtWidgets.QListWidgetItem
    📦 PySide6.QtWidgets.QPushButton
    📦 PySide6.QtWidgets.QTreeWidget
    📦 PySide6.QtWidgets.QTreeWidgetItem
    📦 PySide6.QtWidgets.QVBoxLayout
    📦 PySide6.QtWidgets.QWidget
    📦 __future__.annotations
    📦 pathlib.Path
    📦 typing.Dict
    📦 typing.List
    📦 typing.Optional
  Calls:
    📞 range (line 64)
    📞 range (line 70)
    📞 Signal (line 97)
    📞 Signal (line 98)
    📞 Signal (line 99)
    📞 __init__ (line 107)
    📞 super (line 107)
    📞 hasattr (line 113)
    📞 self._build_ui (line 119)
    📞 QVBoxLayout (line 126)

📄 Editors\ObjectEditor\UI\properties_panel.py
  Imports:
    📦 Core.Debug.debug
    📦 PySide6.QtCore.QSize
    📦 PySide6.QtCore.Qt
    📦 PySide6.QtCore.Signal
    📦 PySide6.QtGui.QFont
    📦 PySide6.QtGui.QIcon
    📦 PySide6.QtGui.QPixmap
    📦 PySide6.QtWidgets.QCheckBox
    📦 PySide6.QtWidgets.QComboBox
    📦 PySide6.QtWidgets.QDialog
    📦 PySide6.QtWidgets.QFileDialog
    📦 PySide6.QtWidgets.QFormLayout
    📦 PySide6.QtWidgets.QGroupBox
    📦 PySide6.QtWidgets.QHBoxLayout
    📦 PySide6.QtWidgets.QLabel
    📦 PySide6.QtWidgets.QLineEdit
    📦 PySide6.QtWidgets.QPushButton
    📦 PySide6.QtWidgets.QSizePolicy
    📦 PySide6.QtWidgets.QSpinBox
    📦 PySide6.QtWidgets.QTabWidget
    📦 PySide6.QtWidgets.QTreeWidget
    📦 PySide6.QtWidgets.QTreeWidgetItem
    📦 PySide6.QtWidgets.QVBoxLayout
    📦 PySide6.QtWidgets.QWidget
    📦 __future__.annotations
    📦 pathlib.Path
    📦 typing.Dict
    📦 typing.List
    📦 typing.Optional
  Calls:
    📞 __init__ (line 39)
    📞 super (line 39)
    📞 self.setWindowTitle (line 44)
    📞 self.setMinimumSize (line 45)
    📞 QVBoxLayout (line 47)
    📞 QLabel (line 50)
    📞 layout.addWidget (line 51)
    📞 QTreeWidget (line 54)
    📞 setHeaderHidden (line 55)
    📞 connect (line 56)

📄 Editors\RoomEditor\__init__.py

📄 Editors\Shared\__init__.py

📄 Editors\RoomEditor\RoomEditor.py
  Imports:
    📦 Core.Debug.debug
    📦 Core.EditorInterface.EditorInterface
    📦 PySide6.QtCore.QPoint
    📦 PySide6.QtCore.QSize
    📦 PySide6.QtCore.Qt
    📦 PySide6.QtGui.QBrush
    📦 PySide6.QtGui.QColor
    📦 PySide6.QtGui.QMouseEvent
    📦 PySide6.QtGui.QPainter
    📦 PySide6.QtGui.QPen
    📦 PySide6.QtGui.QWheelEvent
    📦 PySide6.QtWidgets.QCheckBox
    📦 PySide6.QtWidgets.QColorDialog
    📦 PySide6.QtWidgets.QComboBox
    📦 PySide6.QtWidgets.QDoubleSpinBox
    📦 PySide6.QtWidgets.QFileDialog
    📦 PySide6.QtWidgets.QFrame
    📦 PySide6.QtWidgets.QGroupBox
    📦 PySide6.QtWidgets.QHBoxLayout
    📦 PySide6.QtWidgets.QInputDialog
    📦 PySide6.QtWidgets.QLabel
    📦 PySide6.QtWidgets.QLineEdit
    📦 PySide6.QtWidgets.QListWidget
    📦 PySide6.QtWidgets.QListWidgetItem
    📦 PySide6.QtWidgets.QMenu
    📦 PySide6.QtWidgets.QMessageBox
    📦 PySide6.QtWidgets.QPushButton
    📦 PySide6.QtWidgets.QScrollArea
    📦 PySide6.QtWidgets.QSizePolicy
    📦 PySide6.QtWidgets.QSpinBox
    📦 PySide6.QtWidgets.QSplitter
    📦 PySide6.QtWidgets.QTabWidget
    📦 PySide6.QtWidgets.QVBoxLayout
    📦 PySide6.QtWidgets.QWidget
    📦 json
    📦 typing.Any
    📦 typing.Dict
    📦 typing.List
    📦 typing.Optional
  Calls:
    📞 __init__ (line 41)
    📞 super (line 41)
    📞 get (line 56)
    📞 self.setup_ui (line 58)
    📞 self.open_resource (line 62)
    📞 self.update_instances_list (line 74)
    📞 self.update_views_list (line 75)
    📞 QVBoxLayout (line 83)
    📞 main_layout.setContentsMargins (line 84)
    📞 main_layout.setSpacing (line 85)

📄 Editors\SoundEditor\__init__.py

📄 Editors\RoomEditor\ui\main_window.py
  Imports:
    📦 Core.Debug.debug
    📦 Core.EditorInterface.EditorInterface
    📦 PySide6.QtCore.QPoint
    📦 PySide6.QtCore.Qt
    📦 PySide6.QtGui.QColor
    📦 PySide6.QtWidgets.QCheckBox
    📦 PySide6.QtWidgets.QColorDialog
    📦 PySide6.QtWidgets.QComboBox
    📦 PySide6.QtWidgets.QDoubleSpinBox
    📦 PySide6.QtWidgets.QFileDialog
    📦 PySide6.QtWidgets.QFrame
    📦 PySide6.QtWidgets.QGroupBox
    📦 PySide6.QtWidgets.QHBoxLayout
    📦 PySide6.QtWidgets.QInputDialog
    📦 PySide6.QtWidgets.QLabel
    📦 PySide6.QtWidgets.QLineEdit
    📦 PySide6.QtWidgets.QListWidget
    📦 PySide6.QtWidgets.QListWidgetItem
    📦 PySide6.QtWidgets.QMenu
    📦 PySide6.QtWidgets.QMessageBox
    📦 PySide6.QtWidgets.QPushButton
    📦 PySide6.QtWidgets.QScrollArea
    📦 PySide6.QtWidgets.QSpinBox
    📦 PySide6.QtWidgets.QSplitter
    📦 PySide6.QtWidgets.QTabWidget
    📦 PySide6.QtWidgets.QVBoxLayout
    📦 PySide6.QtWidgets.QWidget
    📦 core.room_data.RoomDataManager
    📦 services.room_io.RoomIOService
    📦 typing.Any
    📦 typing.Dict
    📦 typing.List
    📦 typing.Optional
    📦 widgets.room_canvas.RoomCanvas
  Calls:
    📞 __init__ (line 33)
    📞 super (line 33)
    📞 RoomIOService (line 39)
    📞 get (line 51)
    📞 self.setup_ui (line 53)
    📞 self.open_resource (line 57)
    📞 RoomDataManager.create_default_room (line 60)
    📞 default_room.items (line 61)
    📞 self.update_instances_list (line 65)
    📞 self.update_views_list (line 66)

📄 Editors\Shared\BaseImageResourceEditor.py
  Imports:
    📦 Core.Debug.debug
    📦 Core.EditorInterface.EditorInterface
    📦 Core.EditorOptimizer.EditorOptimizer
    📦 Editors.SpriteEditor.SpriteEditor.SpritePreviewCanvas
    📦 PySide6.QtCore.QSize
    📦 PySide6.QtCore.QTimer
    📦 PySide6.QtCore.Qt
    📦 PySide6.QtCore.Signal
    📦 PySide6.QtGui.QAction
    📦 PySide6.QtGui.QBrush
    📦 PySide6.QtGui.QColor
    📦 PySide6.QtGui.QFont
    📦 PySide6.QtGui.QPainter
    📦 PySide6.QtGui.QPen
    📦 PySide6.QtGui.QPixmap
    📦 PySide6.QtWidgets.QCheckBox
    📦 PySide6.QtWidgets.QComboBox
    📦 PySide6.QtWidgets.QFileDialog
    📦 PySide6.QtWidgets.QFrame
    📦 PySide6.QtWidgets.QGridLayout
    📦 PySide6.QtWidgets.QGroupBox
    📦 PySide6.QtWidgets.QHBoxLayout
    📦 PySide6.QtWidgets.QInputDialog
    📦 PySide6.QtWidgets.QLabel
    📦 PySide6.QtWidgets.QLineEdit
    📦 PySide6.QtWidgets.QListWidget
    📦 PySide6.QtWidgets.QListWidgetItem
    📦 PySide6.QtWidgets.QMessageBox
    📦 PySide6.QtWidgets.QPushButton
    📦 PySide6.QtWidgets.QScrollArea
    📦 PySide6.QtWidgets.QSizePolicy
    📦 PySide6.QtWidgets.QSlider
    📦 PySide6.QtWidgets.QSpinBox
    📦 PySide6.QtWidgets.QTabWidget
    📦 PySide6.QtWidgets.QVBoxLayout
    📦 PySide6.QtWidgets.QWidget
    📦 json
    📦 os
    📦 typing.Dict
    📦 typing.Optional
  Calls:
    📞 __init__ (line 40)
    📞 super (line 40)
    📞 QTimer (line 48)
    📞 connect (line 49)
    📞 hasattr (line 60)
    📞 get_resource_file_path (line 61)
    📞 hasattr (line 66)
    📞 connect (line 67)
    📞 connect (line 68)
    📞 hasattr (line 69)

📄 Editors\SpriteEditor\__init__.py

📄 Editors\SpriteEditor\core\__init__.py

📄 Editors\SpriteEditor\services\__init__.py

📄 Editors\SoundEditor\core\WaveForge.py
  Imports:
    📦 PySide6.QtCore.QPoint
    📦 PySide6.QtCore.QRect
    📦 PySide6.QtCore.QTimer
    📦 PySide6.QtCore.Qt
    📦 PySide6.QtCore.Signal
    📦 PySide6.QtGui.QAction
    📦 PySide6.QtGui.QBrush
    📦 PySide6.QtGui.QColor
    📦 PySide6.QtGui.QContextMenuEvent
    📦 PySide6.QtGui.QFont
    📦 PySide6.QtGui.QKeySequence
    📦 PySide6.QtGui.QPainter
    📦 PySide6.QtGui.QPen
    📦 PySide6.QtWidgets.QCheckBox
    📦 PySide6.QtWidgets.QComboBox
    📦 PySide6.QtWidgets.QDialog
    📦 PySide6.QtWidgets.QDialogButtonBox
    📦 PySide6.QtWidgets.QDoubleSpinBox
    📦 PySide6.QtWidgets.QFileDialog
    📦 PySide6.QtWidgets.QFrame
    📦 PySide6.QtWidgets.QGroupBox
    📦 PySide6.QtWidgets.QHBoxLayout
    📦 PySide6.QtWidgets.QLabel
    📦 PySide6.QtWidgets.QListWidget
    📦 PySide6.QtWidgets.QListWidgetItem
    📦 PySide6.QtWidgets.QMenu
    📦 PySide6.QtWidgets.QMenuBar
    📦 PySide6.QtWidgets.QMessageBox
    📦 PySide6.QtWidgets.QPushButton
    📦 PySide6.QtWidgets.QScrollArea
    📦 PySide6.QtWidgets.QSizePolicy
    📦 PySide6.QtWidgets.QSlider
    📦 PySide6.QtWidgets.QSpinBox
    📦 PySide6.QtWidgets.QSplitter
    📦 PySide6.QtWidgets.QTabWidget
    📦 PySide6.QtWidgets.QTextEdit
    📦 PySide6.QtWidgets.QVBoxLayout
    📦 PySide6.QtWidgets.QWidget
    📦 copy
    📦 json
    📦 numpy
    📦 os
    📦 pydub.AudioSegment
    📦 pydub.utils.which
    📦 pygame
    📦 tempfile
    📦 wave
  Calls:
    📞 print (line 30)
    📞 print (line 37)
    📞 __init__ (line 44)
    📞 super (line 44)
    📞 self.setFixedHeight (line 50)
    📞 self.setStyleSheet (line 51)
    📞 QPainter (line 60)
    📞 painter.setRenderHint (line 61)
    📞 self.width (line 63)
    📞 self.height (line 64)

📄 Editors\Shared\IntegratedImageEditor.py
  Imports:
    📦 Core.Debug.debug
    📦 Core.EditorInterface.EditorInterface
    📦 Editors.Shared.BaseImageResourceEditor.BaseImageResourceEditor
    📦 PIL.Image
    📦 PySide6.QtCore.QSize
    📦 PySide6.QtCore.QTimer
    📦 PySide6.QtCore.Qt
    📦 PySide6.QtCore.Signal
    📦 PySide6.QtGui.QAction
    📦 PySide6.QtGui.QBrush
    📦 PySide6.QtGui.QColor
    📦 PySide6.QtGui.QFont
    📦 PySide6.QtGui.QKeySequence
    📦 PySide6.QtGui.QPainter
    📦 PySide6.QtGui.QPen
    📦 PySide6.QtGui.QPixmap
    📦 PySide6.QtWidgets.QCheckBox
    📦 PySide6.QtWidgets.QComboBox
    📦 PySide6.QtWidgets.QDialog
    📦 PySide6.QtWidgets.QDialogButtonBox
    📦 PySide6.QtWidgets.QFileDialog
    📦 PySide6.QtWidgets.QFrame
    📦 PySide6.QtWidgets.QGridLayout
    📦 PySide6.QtWidgets.QGroupBox
    📦 PySide6.QtWidgets.QHBoxLayout
    📦 PySide6.QtWidgets.QInputDialog
    📦 PySide6.QtWidgets.QLabel
    📦 PySide6.QtWidgets.QLineEdit
    📦 PySide6.QtWidgets.QListWidget
    📦 PySide6.QtWidgets.QListWidgetItem
    📦 PySide6.QtWidgets.QMenu
    📦 PySide6.QtWidgets.QMenuBar
    📦 PySide6.QtWidgets.QMessageBox
    📦 PySide6.QtWidgets.QPushButton
    📦 PySide6.QtWidgets.QScrollArea
    📦 PySide6.QtWidgets.QSizePolicy
    📦 PySide6.QtWidgets.QSlider
    📦 PySide6.QtWidgets.QSpinBox
    📦 PySide6.QtWidgets.QSplitter
    📦 PySide6.QtWidgets.QTabWidget
    📦 PySide6.QtWidgets.QTextEdit
    📦 PySide6.QtWidgets.QVBoxLayout
    📦 PySide6.QtWidgets.QWidget
    📦 base64
    📦 core.state.EditorState
    📦 core.state.state
    📦 io
    📦 json
    📦 numpy
    📦 os
    📦 sys
    📦 traceback
    📦 typing.Dict
    📦 typing.Optional
    📦 ui.dialogs.NewImageDialog
    📦 ui.main_window.MainWindow
  Calls:
    📞 __init__ (line 27)
    📞 super (line 27)
    📞 hasattr (line 38)
    📞 self.setup_ui (line 44)
    📞 self.initialize_editor (line 45)
    📞 self.apply_theme (line 46)
    📞 QVBoxLayout (line 50)
    📞 layout.setContentsMargins (line 51)
    📞 self.create_image_editor_menu (line 54)
    📞 layout.addWidget (line 55)

📄 Editors\SpriteEditor\SpriteEditor.py
  Imports:
    📦 Core.Debug.debug
    📦 Core.EditorInterface.EditorInterface
    📦 Core.EditorOptimizer.EditorOptimizer
    📦 Editors.Shared.BaseImageResourceEditor.BaseImageResourceEditor
    📦 Editors.Shared.IntegratedImageEditor.IntegratedImageEditor
    📦 PIL.Image
    📦 PySide6.QtCore.QSize
    📦 PySide6.QtCore.QTimer
    📦 PySide6.QtCore.Qt
    📦 PySide6.QtCore.Signal
    📦 PySide6.QtGui.QAction
    📦 PySide6.QtGui.QBrush
    📦 PySide6.QtGui.QColor
    📦 PySide6.QtGui.QFont
    📦 PySide6.QtGui.QImage
    📦 PySide6.QtGui.QPainter
    📦 PySide6.QtGui.QPen
    📦 PySide6.QtGui.QPixmap
    📦 PySide6.QtWidgets.QCheckBox
    📦 PySide6.QtWidgets.QComboBox
    📦 PySide6.QtWidgets.QDialog
    📦 PySide6.QtWidgets.QDialogButtonBox
    📦 PySide6.QtWidgets.QFileDialog
    📦 PySide6.QtWidgets.QFrame
    📦 PySide6.QtWidgets.QGridLayout
    📦 PySide6.QtWidgets.QGroupBox
    📦 PySide6.QtWidgets.QHBoxLayout
    📦 PySide6.QtWidgets.QInputDialog
    📦 PySide6.QtWidgets.QLabel
    📦 PySide6.QtWidgets.QLineEdit
    📦 PySide6.QtWidgets.QListWidget
    📦 PySide6.QtWidgets.QListWidgetItem
    📦 PySide6.QtWidgets.QMenu
    📦 PySide6.QtWidgets.QMenuBar
    📦 PySide6.QtWidgets.QMessageBox
    📦 PySide6.QtWidgets.QPushButton
    📦 PySide6.QtWidgets.QScrollArea
    📦 PySide6.QtWidgets.QSizePolicy
    📦 PySide6.QtWidgets.QSlider
    📦 PySide6.QtWidgets.QSpinBox
    📦 PySide6.QtWidgets.QSplitter
    📦 PySide6.QtWidgets.QTabWidget
    📦 PySide6.QtWidgets.QTextEdit
    📦 PySide6.QtWidgets.QVBoxLayout
    📦 PySide6.QtWidgets.QWidget
    📦 base64
    📦 core.state.EditorState
    📦 core.state.state
    📦 io
    📦 json
    📦 numpy
    📦 os
    📦 sys
    📦 traceback
    📦 typing.Dict
    📦 typing.Optional
    📦 ui.dialogs.NewImageDialog
    📦 ui.main_window.MainWindow
  Calls:
    📞 __init__ (line 31)
    📞 super (line 31)
    📞 QFileDialog (line 36)
    📞 file_dialog.setNameFilter (line 37)
    📞 file_dialog.setFileMode (line 38)
    📞 file_dialog.exec (line 40)
    📞 file_dialog.selectedFiles (line 41)
    📞 self.load_sprite_from_files (line 42)
    📞 hasattr (line 55)
    📞 text (line 55)

📄 Editors\SoundEditor\SoundEditor.py
  Imports:
    📦 Core.EditorInterface.EditorInterface
    📦 Editors.SoundEditor.core.WaveForge.WaveForge
    📦 PySide6.QtCore.QSize
    📦 PySide6.QtCore.QThread
    📦 PySide6.QtCore.QTimer
    📦 PySide6.QtCore.Qt
    📦 PySide6.QtCore.Signal
    📦 PySide6.QtGui.QAction
    📦 PySide6.QtGui.QBrush
    📦 PySide6.QtGui.QColor
    📦 PySide6.QtGui.QFont
    📦 PySide6.QtGui.QPainter
    📦 PySide6.QtGui.QPen
    📦 PySide6.QtGui.QPixmap
    📦 PySide6.QtWidgets.QCheckBox
    📦 PySide6.QtWidgets.QComboBox
    📦 PySide6.QtWidgets.QDialog
    📦 PySide6.QtWidgets.QDialogButtonBox
    📦 PySide6.QtWidgets.QFileDialog
    📦 PySide6.QtWidgets.QFrame
    📦 PySide6.QtWidgets.QGridLayout
    📦 PySide6.QtWidgets.QGroupBox
    📦 PySide6.QtWidgets.QHBoxLayout
    📦 PySide6.QtWidgets.QInputDialog
    📦 PySide6.QtWidgets.QLabel
    📦 PySide6.QtWidgets.QLineEdit
    📦 PySide6.QtWidgets.QListWidget
    📦 PySide6.QtWidgets.QListWidgetItem
    📦 PySide6.QtWidgets.QMenu
    📦 PySide6.QtWidgets.QMenuBar
    📦 PySide6.QtWidgets.QMessageBox
    📦 PySide6.QtWidgets.QProgressBar
    📦 PySide6.QtWidgets.QPushButton
    📦 PySide6.QtWidgets.QScrollArea
    📦 PySide6.QtWidgets.QSizePolicy
    📦 PySide6.QtWidgets.QSlider
    📦 PySide6.QtWidgets.QSpinBox
    📦 PySide6.QtWidgets.QSplitter
    📦 PySide6.QtWidgets.QTabWidget
    📦 PySide6.QtWidgets.QTextEdit
    📦 PySide6.QtWidgets.QVBoxLayout
    📦 PySide6.QtWidgets.QWidget
    📦 contextlib
    📦 glob
    📦 io
    📦 json
    📦 librosa
    📦 mido
    📦 music21.duration
    📦 music21.key
    📦 music21.meter
    📦 music21.note
    📦 music21.pitch
    📦 music21.stream
    📦 music21.tempo
    📦 numpy
    📦 os
    📦 pydub.AudioSegment
    📦 pydub.utils.which
    📦 pygame
    📦 pygame.sndarray
    📦 re
    📦 soundfile
    📦 tempfile
    📦 threading
    📦 time
    📦 traceback
    📦 typing.Dict
    📦 typing.Optional
    📦 uuid
    📦 warnings
    📦 wave
  Calls:
    📞 print (line 32)
    📞 print (line 40)
    📞 print (line 47)
    📞 print (line 54)
    📞 print (line 61)
    📞 warnings.filterwarnings (line 69)
    📞 warnings.filterwarnings (line 75)
    📞 __init__ (line 86)
    📞 super (line 86)
    📞 self.setMinimumHeight (line 99)

📄 Editors\ModelEditor\ModelEditor.py
  Imports:
    📦 Core.Debug.debug
    📦 Core.EditorInterface.EditorInterface
    📦 OpenGL.GL.*
    📦 OpenGL.GLU.*
    📦 PIL.Image
    📦 PySide6.QtCore.QPoint
    📦 PySide6.QtCore.QTimer
    📦 PySide6.QtCore.Qt
    📦 PySide6.QtGui.QAction
    📦 PySide6.QtGui.QColor
    📦 PySide6.QtGui.QFont
    📦 PySide6.QtGui.QIcon
    📦 PySide6.QtGui.QImage
    📦 PySide6.QtGui.QKeySequence
    📦 PySide6.QtGui.QPainter
    📦 PySide6.QtGui.QPen
    📦 PySide6.QtGui.QPixmap
    📦 PySide6.QtOpenGLWidgets.QOpenGLWidget
    📦 PySide6.QtWidgets.QApplication
    📦 PySide6.QtWidgets.QCheckBox
    📦 PySide6.QtWidgets.QColorDialog
    📦 PySide6.QtWidgets.QComboBox
    📦 PySide6.QtWidgets.QDialog
    📦 PySide6.QtWidgets.QDialogButtonBox
    📦 PySide6.QtWidgets.QDoubleSpinBox
    📦 PySide6.QtWidgets.QFileDialog
    📦 PySide6.QtWidgets.QFrame
    📦 PySide6.QtWidgets.QGridLayout
    📦 PySide6.QtWidgets.QGroupBox
    📦 PySide6.QtWidgets.QHBoxLayout
    📦 PySide6.QtWidgets.QInputDialog
    📦 PySide6.QtWidgets.QLabel
    📦 PySide6.QtWidgets.QLineEdit
    📦 PySide6.QtWidgets.QListWidget
    📦 PySide6.QtWidgets.QListWidgetItem
    📦 PySide6.QtWidgets.QMainWindow
    📦 PySide6.QtWidgets.QMenu
    📦 PySide6.QtWidgets.QMenuBar
    📦 PySide6.QtWidgets.QMessageBox
    📦 PySide6.QtWidgets.QPushButton
    📦 PySide6.QtWidgets.QScrollArea
    📦 PySide6.QtWidgets.QSplitter
    📦 PySide6.QtWidgets.QStatusBar
    📦 PySide6.QtWidgets.QVBoxLayout
    📦 PySide6.QtWidgets.QWidget
    📦 UI.CommonDialogs.PreferencesDialog.PreferencesDialog
    📦 base64
    📦 collada
    📦 importlib.util
    📦 json
    📦 math
    📦 numpy
    📦 os
    📦 shutil
    📦 struct
    📦 sys
    📦 tempfile
    📦 traceback
    📦 trimesh
    📦 typing.Dict
    📦 typing.Optional
    📦 xml.etree.ElementTree
  Calls:
    📞 len (line 67)
    📞 len (line 69)
    📞 len (line 71)
    📞 UnifiedMaterial (line 89)
    📞 len (line 92)
    📞 len (line 94)
    📞 len (line 96)
    📞 mtl_data.get (line 101)
    📞 self._resolve_texture_path (line 103)
    📞 UnifiedMaterial (line 111)

📄 Editors\SpriteEditor\widgets\__init__.py

📄 Editors\SpriteEditor\ui\__init__.py

📄 Editors\TextureEditor\__init__.py

📄 GenerateSummary.py
  Imports:
    📦 argparse
    📦 ast
    📦 collections.Counter
    📦 os
    📦 pathlib.Path
    📦 sys
  Calls:
    📞 path.open (line 47)
    📞 f.read (line 48)
    📞 path.read_text (line 58)
    📞 ast.parse (line 59)
    📞 ast.get_docstring (line 60)
    📞 doc.strip (line 61)
    📞 len (line 62)
    📞 path.open (line 71)
    📞 line.strip (line 73)
    📞 stripped.startswith (line 76)

📄 Editors\TextureEditor\TextureEditor.py
  Imports:
    📦 Core.Debug.debug
    📦 Core.EditorInterface.EditorInterface
    📦 Editors.ImageEditor.core.core.state.EditorState
    📦 Editors.ImageEditor.core.ui.dialogs.new_image_dialog.NewImageDialog
    📦 Editors.ImageEditor.core.ui.main_window.MainWindow
    📦 Editors.Shared.BaseImageResourceEditor.BaseImageResourceEditor
    📦 Editors.Shared.IntegratedImageEditor.IntegratedImageEditor
    📦 Editors.SpriteEditor.SpriteEditor.IntegratedImageEditor
    📦 PIL.Image
    📦 PySide6.QtCore.QSize
    📦 PySide6.QtCore.QTimer
    📦 PySide6.QtCore.Qt
    📦 PySide6.QtCore.Signal
    📦 PySide6.QtGui.QAction
    📦 PySide6.QtGui.QBrush
    📦 PySide6.QtGui.QColor
    📦 PySide6.QtGui.QFont
    📦 PySide6.QtGui.QImage
    📦 PySide6.QtGui.QPainter
    📦 PySide6.QtGui.QPen
    📦 PySide6.QtGui.QPixmap
    📦 PySide6.QtWidgets.QCheckBox
    📦 PySide6.QtWidgets.QComboBox
    📦 PySide6.QtWidgets.QDialog
    📦 PySide6.QtWidgets.QDialogButtonBox
    📦 PySide6.QtWidgets.QFileDialog
    📦 PySide6.QtWidgets.QFrame
    📦 PySide6.QtWidgets.QGridLayout
    📦 PySide6.QtWidgets.QGroupBox
    📦 PySide6.QtWidgets.QHBoxLayout
    📦 PySide6.QtWidgets.QInputDialog
    📦 PySide6.QtWidgets.QLabel
    📦 PySide6.QtWidgets.QLineEdit
    📦 PySide6.QtWidgets.QListWidget
    📦 PySide6.QtWidgets.QListWidgetItem
    📦 PySide6.QtWidgets.QMenu
    📦 PySide6.QtWidgets.QMenuBar
    📦 PySide6.QtWidgets.QMessageBox
    📦 PySide6.QtWidgets.QPushButton
    📦 PySide6.QtWidgets.QScrollArea
    📦 PySide6.QtWidgets.QSizePolicy
    📦 PySide6.QtWidgets.QSlider
    📦 PySide6.QtWidgets.QSpinBox
    📦 PySide6.QtWidgets.QSplitter
    📦 PySide6.QtWidgets.QTabWidget
    📦 PySide6.QtWidgets.QTextEdit
    📦 PySide6.QtWidgets.QVBoxLayout
    📦 PySide6.QtWidgets.QWidget
    📦 base64
    📦 core.state.state
    📦 json
    📦 numpy
    📦 os
    📦 sys
    📦 traceback
    📦 typing.Dict
    📦 typing.Optional
  Calls:
    📞 __init__ (line 29)
    📞 super (line 29)
    📞 hasattr (line 41)
    📞 get_resource_file_path (line 42)
    📞 hasattr (line 47)
    📞 connect (line 48)
    📞 connect (line 49)
    📞 hasattr (line 50)
    📞 connect (line 51)
    📞 hasattr (line 66)

📄 main.py
  Imports:
    📦 Config.Settings.Settings
    📦 Config.ThemeManager.ThemeManager
    📦 Core.Debug.debug
    📦 Core.Debug.debug_critical
    📦 Core.Debug.init_debug
    📦 Core.DeletePyCache.delete_pycache
    📦 Core.ExtensionsManager.ExtensionsManager
    📦 Core.ModulePreloader.ModulePreloader
    📦 Core.PackageInstaller.UnifiedPackageInstaller
    📦 Core.ProjectManager.ProjectManager
    📦 Core.ResourceManager.ResourceManager
    📦 Core.UtilityOperations.UndoRedoManager
    📦 Core.VenvManager.VenvManager
    📦 PySide6.QtCore.QSettings
    📦 PySide6.QtCore.QTimer
    📦 PySide6.QtCore.Qt
    📦 PySide6.QtGui.QAction
    📦 PySide6.QtGui.QIcon
    📦 PySide6.QtGui.QKeySequence
    📦 PySide6.QtWidgets.QApplication
    📦 PySide6.QtWidgets.QFileDialog
    📦 PySide6.QtWidgets.QHBoxLayout
    📦 PySide6.QtWidgets.QInputDialog
    📦 PySide6.QtWidgets.QMainWindow
    📦 PySide6.QtWidgets.QMenu
    📦 PySide6.QtWidgets.QMenuBar
    📦 PySide6.QtWidgets.QMessageBox
    📦 PySide6.QtWidgets.QSplitter
    📦 PySide6.QtWidgets.QStatusBar
    📦 PySide6.QtWidgets.QTextEdit
    📦 PySide6.QtWidgets.QToolBar
    📦 PySide6.QtWidgets.QTreeWidget
    📦 PySide6.QtWidgets.QTreeWidgetItem
    📦 PySide6.QtWidgets.QVBoxLayout
    📦 PySide6.QtWidgets.QWidget
    📦 UI.CommonDialogs.PreferencesDialog.PreferencesDialog
    📦 UI.MainWindow.MainWindow.MainWindow
    📦 importlib
    📦 json
    📦 os
    📦 pathlib.Path
    📦 shutil
    📦 signal
    📦 subprocess
    📦 sys
    📦 traceback
    📦 warnings
  Calls:
    📞 signal.signal (line 15)
    📞 debug_critical (line 29)
    📞 Path (line 32)
    📞 VenvManager (line 35)
    📞 venv_manager.venv_exists (line 38)
    📞 debug (line 39)
    📞 venv_manager.validate_venv (line 40)
    📞 debug_critical (line 43)
    📞 debug (line 44)
    📞 exists (line 48)

📄 Tools\BackupManager\__init__.py

📄 Tools\ProjectMaintenance\__init__.py

📄 Tools\ScreenRecording\__init__.py
  Imports:
    📦 Tools.ScreenRecording.screen_recorder.GifProcessingThread
    📦 Tools.ScreenRecording.screen_recorder.ScreenCaptureThread
    📦 Tools.ScreenRecording.screen_recorder.ScreenRecorderWidget

📄 Tools\BackupManager\BackupManager.py
  Imports:
    📦 os
    📦 packaging.version
    📦 pathlib.Path
    📦 subprocess
    📦 sys
    📦 typing.Callable
    📦 typing.List
    📦 typing.Optional
    📦 typing.Set
    📦 zipfile
  Calls:
    📞 subprocess.check_call (line 19)
    📞 int (line 29)
    📞 split (line 29)
    📞 int (line 30)
    📞 split (line 30)
    📞 type (line 34)
    📞 set (line 50)
    📞 self.progress_callback (line 54)
    📞 base_path.exists (line 73)
    📞 base_path.iterdir (line 74)

📄 Tools\ScreenRecording\screen_recorder.py
  Imports:
    📦 PIL.Image
    📦 PySide6.QtCore.QMutex
    📦 PySide6.QtCore.QMutexLocker
    📦 PySide6.QtCore.QThread
    📦 PySide6.QtCore.QTimer
    📦 PySide6.QtCore.Qt
    📦 PySide6.QtCore.Signal
    📦 PySide6.QtGui.QFont
    📦 PySide6.QtWidgets.QCheckBox
    📦 PySide6.QtWidgets.QComboBox
    📦 PySide6.QtWidgets.QFileDialog
    📦 PySide6.QtWidgets.QGroupBox
    📦 PySide6.QtWidgets.QHBoxLayout
    📦 PySide6.QtWidgets.QLabel
    📦 PySide6.QtWidgets.QMessageBox
    📦 PySide6.QtWidgets.QProgressBar
    📦 PySide6.QtWidgets.QPushButton
    📦 PySide6.QtWidgets.QSlider
    📦 PySide6.QtWidgets.QVBoxLayout
    📦 PySide6.QtWidgets.QWidget
    📦 mss
    📦 numpy
    📦 pathlib.Path
    📦 sys
    📦 threading
    📦 time
    📦 typing.List
    📦 typing.Optional
    📦 zlib
  Calls:
    📞 Signal (line 29)
    📞 __init__ (line 32)
    📞 super (line 32)
    📞 QMutex (line 40)
    📞 np.array (line 45)
    📞 int (line 88)
    📞 int (line 89)
    📞 frame.astype (line 94)
    📞 zlib.compress (line 95)
    📞 frame.tobytes (line 95)

📄 Tools\VenvManagement\__init__.py

📄 UI\__init__.py

📄 UI\CommonDialogs\BackupFolderDialog.py
  Imports:
    📦 PySide6.QtCore.Qt
    📦 PySide6.QtWidgets.QCheckBox
    📦 PySide6.QtWidgets.QDialog
    📦 PySide6.QtWidgets.QGroupBox
    📦 PySide6.QtWidgets.QHBoxLayout
    📦 PySide6.QtWidgets.QLabel
    📦 PySide6.QtWidgets.QListWidget
    📦 PySide6.QtWidgets.QListWidgetItem
    📦 PySide6.QtWidgets.QMessageBox
    📦 PySide6.QtWidgets.QPushButton
    📦 PySide6.QtWidgets.QVBoxLayout
    📦 PySide6.QtWidgets.QWidget
    📦 pathlib.Path
    📦 typing.Dict
    📦 typing.Optional
    📦 typing.Set
  Calls:
    📞 __init__ (line 25)
    📞 super (line 25)
    📞 Path (line 26)
    📞 self.setup_ui (line 29)
    📞 self.load_defaults (line 30)
    📞 self.populate_folders (line 31)
    📞 self.setWindowTitle (line 35)
    📞 capitalize (line 35)
    📞 self.setMinimumSize (line 36)
    📞 QVBoxLayout (line 38)

📄 UI\CommonDialogs\ResourceFolderDialog.py
  Imports:
    📦 PySide6.QtCore.Qt
    📦 PySide6.QtWidgets.QButtonGroup
    📦 PySide6.QtWidgets.QDialog
    📦 PySide6.QtWidgets.QGroupBox
    📦 PySide6.QtWidgets.QHBoxLayout
    📦 PySide6.QtWidgets.QLabel
    📦 PySide6.QtWidgets.QListWidget
    📦 PySide6.QtWidgets.QListWidgetItem
    📦 PySide6.QtWidgets.QMessageBox
    📦 PySide6.QtWidgets.QPushButton
    📦 PySide6.QtWidgets.QRadioButton
    📦 PySide6.QtWidgets.QVBoxLayout
    📦 PySide6.QtWidgets.QWidget
    📦 pathlib.Path
    📦 typing.Optional
    📦 typing.Set
  Calls:
    📞 __init__ (line 24)
    📞 super (line 24)
    📞 Path (line 25)
    📞 set (line 26)
    📞 self.setup_ui (line 27)
    📞 self.populate_resource_folders (line 28)
    📞 self.setWindowTitle (line 32)
    📞 self.setMinimumSize (line 33)
    📞 QVBoxLayout (line 35)
    📞 QLabel (line 38)

📄 UI\CommonDialogs\RestoreDialog.py
  Imports:
    📦 PySide6.QtCore.Qt
    📦 PySide6.QtWidgets.QCheckBox
    📦 PySide6.QtWidgets.QDialog
    📦 PySide6.QtWidgets.QGroupBox
    📦 PySide6.QtWidgets.QHBoxLayout
    📦 PySide6.QtWidgets.QLabel
    📦 PySide6.QtWidgets.QListWidget
    📦 PySide6.QtWidgets.QListWidgetItem
    📦 PySide6.QtWidgets.QMessageBox
    📦 PySide6.QtWidgets.QProgressDialog
    📦 PySide6.QtWidgets.QPushButton
    📦 PySide6.QtWidgets.QVBoxLayout
    📦 Tools.BackupManager.BackupManager.BackupManager
    📦 datetime.datetime
    📦 pathlib.Path
  Calls:
    📞 __init__ (line 29)
    📞 super (line 29)
    📞 self.setWindowTitle (line 34)
    📞 backup_type.capitalize (line 34)
    📞 self.setMinimumSize (line 35)
    📞 self.setup_ui (line 37)
    📞 self.load_backups (line 38)
    📞 QVBoxLayout (line 42)
    📞 QLabel (line 45)
    📞 layout.addWidget (line 46)

📄 UI\CommonDialogs\ExtensionsDialog.py
  Imports:
    📦 Core.Debug.debug
    📦 Core.ExtensionsManager.ExtensionsManager
    📦 Core.PackageLoadThread.PackageLoadThread
    📦 Core.PackageSearchThread.PackageSearchThread
    📦 Core.PyPILoadThread.PyPILoadThread
    📦 PySide6.QtCore.QTimer
    📦 PySide6.QtCore.Qt
    📦 PySide6.QtGui.QBrush
    📦 PySide6.QtGui.QColor
    📦 PySide6.QtGui.QContextMenuEvent
    📦 PySide6.QtWidgets.QCheckBox
    📦 PySide6.QtWidgets.QDialog
    📦 PySide6.QtWidgets.QHBoxLayout
    📦 PySide6.QtWidgets.QLabel
    📦 PySide6.QtWidgets.QLineEdit
    📦 PySide6.QtWidgets.QMenu
    📦 PySide6.QtWidgets.QMessageBox
    📦 PySide6.QtWidgets.QProgressBar
    📦 PySide6.QtWidgets.QPushButton
    📦 PySide6.QtWidgets.QTabWidget
    📦 PySide6.QtWidgets.QTableWidget
    📦 PySide6.QtWidgets.QTableWidgetItem
    📦 PySide6.QtWidgets.QVBoxLayout
    📦 PySide6.QtWidgets.QWidget
    📦 json
    📦 pathlib.Path
    📦 traceback
  Calls:
    📞 __init__ (line 32)
    📞 super (line 32)
    📞 getattr (line 36)
    📞 getattr (line 37)
    📞 QMessageBox.critical (line 40)
    📞 self.reject (line 41)
    📞 ExtensionsManager (line 44)
    📞 connect (line 47)
    📞 connect (line 48)
    📞 connect (line 49)

📄 UI\CommonDialogs\PreferencesDialog.py
  Imports:
    📦 Core.Debug._debug_manager
    📦 Core.Debug.init_debug
    📦 GenerateSummary.summarize_project
    📦 PySide6.QtCore.QCoreApplication
    📦 PySide6.QtCore.Qt
    📦 PySide6.QtCore.Signal
    📦 PySide6.QtGui.QColor
    📦 PySide6.QtGui.QFont
    📦 PySide6.QtWidgets.QCheckBox
    📦 PySide6.QtWidgets.QColorDialog
    📦 PySide6.QtWidgets.QComboBox
    📦 PySide6.QtWidgets.QDialog
    📦 PySide6.QtWidgets.QDialogButtonBox
    📦 PySide6.QtWidgets.QDoubleSpinBox
    📦 PySide6.QtWidgets.QFileDialog
    📦 PySide6.QtWidgets.QGridLayout
    📦 PySide6.QtWidgets.QGroupBox
    📦 PySide6.QtWidgets.QHBoxLayout
    📦 PySide6.QtWidgets.QInputDialog
    📦 PySide6.QtWidgets.QLabel
    📦 PySide6.QtWidgets.QLineEdit
    📦 PySide6.QtWidgets.QListWidget
    📦 PySide6.QtWidgets.QListWidgetItem
    📦 PySide6.QtWidgets.QMessageBox
    📦 PySide6.QtWidgets.QPushButton
    📦 PySide6.QtWidgets.QScrollArea
    📦 PySide6.QtWidgets.QSlider
    📦 PySide6.QtWidgets.QSpinBox
    📦 PySide6.QtWidgets.QSplitter
    📦 PySide6.QtWidgets.QTabWidget
    📦 PySide6.QtWidgets.QTextEdit
    📦 PySide6.QtWidgets.QVBoxLayout
    📦 PySide6.QtWidgets.QWidget
    📦 core.settings.settings
    📦 os
    📦 pathlib.Path
    📦 sys
    📦 traceback
    📦 ui.settings_dialog.AppearanceTab
  Calls:
    📞 Signal (line 19)
    📞 __init__ (line 22)
    📞 super (line 22)
    📞 self.setup_ui (line 26)
    📞 self.load_settings (line 27)
    📞 self.apply_theme (line 28)
    📞 self.setWindowTitle (line 32)
    📞 self.setModal (line 33)
    📞 self.resize (line 36)
    📞 self.setMinimumSize (line 37)

📄 UI\Panels\__init__.py

📄 UI\Widgets\LoadingWidget.py
  Imports:
    📦 PySide6.QtCore.QTimer
    📦 PySide6.QtCore.Qt
    📦 PySide6.QtGui.QFont
    📦 PySide6.QtWidgets.QLabel
    📦 PySide6.QtWidgets.QVBoxLayout
    📦 PySide6.QtWidgets.QWidget
  Calls:
    📞 __init__ (line 14)
    📞 super (line 14)
    📞 self.setup_ui (line 16)
    📞 QVBoxLayout (line 22)
    📞 layout.setAlignment (line 23)
    📞 QLabel (line 26)
    📞 QFont (line 27)
    📞 font.setPointSize (line 28)
    📞 setFont (line 29)
    📞 setAlignment (line 30)

📄 UI\Widgets\ParallelThumbnailLoader.py
  Imports:
    📦 Core.Debug.debug
    📦 Core.ThumbnailCache.ThumbnailCache
    📦 PySide6.QtCore.QMutex
    📦 PySide6.QtCore.QMutexLocker
    📦 PySide6.QtCore.QSize
    📦 PySide6.QtCore.QThread
    📦 PySide6.QtCore.Qt
    📦 PySide6.QtCore.Signal
    📦 PySide6.QtGui.QIcon
    📦 PySide6.QtGui.QImage
    📦 PySide6.QtGui.QPixmap
    📦 UI.Widgets.ThumbnailLoader.ThumbnailLoader
    📦 json
    📦 os
    📦 pathlib.Path
  Calls:
    📞 Signal (line 19)
    📞 __init__ (line 22)
    📞 super (line 22)
    📞 self._get_image_path (line 33)
    📞 get_thumbnail (line 35)
    📞 emit (line 39)
    📞 self._load_thumbnail (line 43)
    📞 save_thumbnail (line 47)
    📞 emit (line 50)
    📞 debug (line 53)

📄 UI\Widgets\TerminalWidget.py
  Imports:
    📦 PySide6.QtCore.QObject
    📦 PySide6.QtCore.QTimer
    📦 PySide6.QtCore.Qt
    📦 PySide6.QtCore.Signal
    📦 PySide6.QtGui.QColor
    📦 PySide6.QtGui.QFont
    📦 PySide6.QtGui.QTextCharFormat
    📦 PySide6.QtGui.QTextCursor
    📦 PySide6.QtWidgets.QTextEdit
    📦 PySide6.QtWidgets.QVBoxLayout
    📦 PySide6.QtWidgets.QWidget
    📦 sys
    📦 time
  Calls:
    📞 Signal (line 14)
    📞 __init__ (line 17)
    📞 super (line 17)
    📞 emit (line 23)
    📞 __init__ (line 37)
    📞 super (line 37)
    📞 self.setup_ui (line 53)
    📞 self.apply_theme (line 54)
    📞 QTimer.singleShot (line 57)
    📞 QVBoxLayout (line 61)

📄 UI\MainWindow\MainWindow.py
  Imports:
    📦 Core.AI.PyGenesisAssistant.NovaWidget.NovaWidget
    📦 Core.Debug.debug
    📦 Core.EditorFactory.EditorFactory
    📦 Core.GameGenerator.GameGenerator
    📦 Core.Services.script_checker.ScriptChecker
    📦 PIL.Image
    📦 PySide6.QtCore.QCoreApplication
    📦 PySide6.QtCore.QMutex
    📦 PySide6.QtCore.QMutexLocker
    📦 PySide6.QtCore.QSettings
    📦 PySide6.QtCore.QThread
    📦 PySide6.QtCore.QTimer
    📦 PySide6.QtCore.Qt
    📦 PySide6.QtCore.Signal
    📦 PySide6.QtGui.QAction
    📦 PySide6.QtGui.QColor
    📦 PySide6.QtGui.QFont
    📦 PySide6.QtGui.QIcon
    📦 PySide6.QtGui.QKeySequence
    📦 PySide6.QtGui.QPainter
    📦 PySide6.QtGui.QPixmap
    📦 PySide6.QtWidgets.QApplication
    📦 PySide6.QtWidgets.QDialog
    📦 PySide6.QtWidgets.QDockWidget
    📦 PySide6.QtWidgets.QFileDialog
    📦 PySide6.QtWidgets.QFrame
    📦 PySide6.QtWidgets.QHBoxLayout
    📦 PySide6.QtWidgets.QInputDialog
    📦 PySide6.QtWidgets.QLabel
    📦 PySide6.QtWidgets.QMainWindow
    📦 PySide6.QtWidgets.QMenu
    📦 PySide6.QtWidgets.QMenuBar
    📦 PySide6.QtWidgets.QMessageBox
    📦 PySide6.QtWidgets.QProgressDialog
    📦 PySide6.QtWidgets.QPushButton
    📦 PySide6.QtWidgets.QSplitter
    📦 PySide6.QtWidgets.QStatusBar
    📦 PySide6.QtWidgets.QTabWidget
    📦 PySide6.QtWidgets.QTextEdit
    📦 PySide6.QtWidgets.QToolBar
    📦 PySide6.QtWidgets.QTreeWidget
    📦 PySide6.QtWidgets.QTreeWidgetItem
    📦 PySide6.QtWidgets.QVBoxLayout
    📦 PySide6.QtWidgets.QWidget
    📦 Tools.BackupManager.BackupManager.BackupManager
    📦 Tools.ScreenRecording.screen_recorder.GifProcessingThread
    📦 Tools.ScreenRecording.screen_recorder.ScreenCaptureThread
    📦 UI.CommonDialogs.BackupFolderDialog.BackupFolderDialog
    📦 UI.CommonDialogs.ExtensionsDialog.ExtensionsDialog
    📦 UI.CommonDialogs.PreferencesDialog.PreferencesDialog
    📦 UI.CommonDialogs.ResourceFolderDialog.ResourceFolderDialog
    📦 UI.CommonDialogs.RestoreDialog.RestoreDialog
    📦 UI.Widgets.LoadingWidget.LoadingWidget
    📦 UI.Widgets.ResourceTree.ResourceTree
    📦 UI.Widgets.TerminalWidget.TerminalWidget
    📦 glob
    📦 json
    📦 mss
    📦 numpy
    📦 os
    📦 pathlib.Path
    📦 subprocess
    📦 sys
    📦 time
    📦 traceback
    📦 zlib
  Calls:
    📞 Signal (line 46)
    📞 Signal (line 47)
    📞 __init__ (line 50)
    📞 super (line 50)
    📞 Path (line 51)
    📞 QMutex (line 55)
    📞 QMutexLocker (line 77)
    📞 clear (line 80)
    📞 clear (line 81)
    📞 QMutexLocker (line 86)

📄 UI\Widgets\ResourceTree.py
  Imports:
    📦 Core.Debug.debug
    📦 Core.ThumbnailCache.ThumbnailCache
    📦 Core.UtilityOperations.ClipboardManager
    📦 PIL.Image
    📦 PySide6.QtCore.QByteArray
    📦 PySide6.QtCore.QMimeData
    📦 PySide6.QtCore.QSize
    📦 PySide6.QtCore.QTimer
    📦 PySide6.QtCore.Qt
    📦 PySide6.QtCore.Signal
    📦 PySide6.QtGui.QColor
    📦 PySide6.QtGui.QDrag
    📦 PySide6.QtGui.QFont
    📦 PySide6.QtGui.QIcon
    📦 PySide6.QtGui.QImage
    📦 PySide6.QtGui.QPainter
    📦 PySide6.QtGui.QPixmap
    📦 PySide6.QtWidgets.QApplication
    📦 PySide6.QtWidgets.QFileDialog
    📦 PySide6.QtWidgets.QHeaderView
    📦 PySide6.QtWidgets.QInputDialog
    📦 PySide6.QtWidgets.QMenu
    📦 PySide6.QtWidgets.QMessageBox
    📦 PySide6.QtWidgets.QStyle
    📦 PySide6.QtWidgets.QTreeWidget
    📦 PySide6.QtWidgets.QTreeWidgetItem
    📦 UI.Widgets.ThumbnailLoader.ThumbnailLoader
    📦 json
    📦 os
    📦 pathlib.Path
    📦 platform
    📦 pydub.AudioSegment
    📦 re
    📦 shutil
    📦 subprocess
    📦 traceback
  Calls:
    📞 Signal (line 21)
    📞 Signal (line 22)
    📞 __init__ (line 25)
    📞 super (line 25)
    📞 self.setup_ui (line 28)
    📞 self.setup_connections (line 29)
    📞 self.setup_drag_drop (line 30)
    📞 ClipboardManager (line 48)
    📞 ThumbnailLoader (line 51)
    📞 connect (line 52)

📄 UI\Widgets\ThumbnailLoader.py
  Imports:
    📦 Core.Debug.debug
    📦 Core.ThumbnailCache.ThumbnailCache
    📦 PySide6.QtCore.QMutex
    📦 PySide6.QtCore.QMutexLocker
    📦 PySide6.QtCore.QSize
    📦 PySide6.QtCore.QThread
    📦 PySide6.QtCore.Qt
    📦 PySide6.QtCore.Signal
    📦 PySide6.QtGui.QIcon
    📦 PySide6.QtGui.QImage
    📦 PySide6.QtGui.QPixmap
    📦 json
    📦 os
    📦 pathlib.Path
    📦 traceback
  Calls:
    📞 Signal (line 21)
    📞 __init__ (line 24)
    📞 super (line 24)
    📞 QMutex (line 25)
    📞 QMutexLocker (line 32)
    📞 append (line 33)
    📞 QMutexLocker (line 37)
    📞 debug (line 42)
    📞 QMutexLocker (line 49)
    📞 debug (line 51)


