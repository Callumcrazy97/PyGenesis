🔄 COMPLETE WORKFLOW
========================================

🏗️ __init__
   📄 Core\AI\PyGenesisAssistant\Nova\core\operation_planner.py (line 58)
   📞 Called by:
      • Core\AI\PyGenesisAssistant\Nova\ui\settings_dialog.py (line 12)
      • Core\AI\PyGenesisAssistant\Nova\ui\settings_dialog.py (line 312)
      • Core\AI\PyGenesisAssistant\Nova\ui\settings_dialog.py (line 367)
      • Editors\ImageEditor\core\ui\tooltips.py (line 6)
      • Core\AI\PyGenesisAssistant\Nova\ui\tasks_dialog.py (line 38)
      • Core\AI\PyGenesisAssistant\Nova\ui\tasks_dialog.py (line 169)
      • Core\AI\PyGenesisAssistant\CodeAnalyser.py (line 23)
      • Core\Code\Unified\unified_code_editor.py (line 36)
      • Core\Code\Unified\unified_code_editor.py (line 137)
      • Core\Code\Unified\unified_code_editor.py (line 226)
      • Core\AI\PyGenesisAssistant\Nova\ui\project_management_dialog.py (line 26)
      • Core\AI\PyGenesisAssistant\Nova\ui\project_management_dialog.py (line 48)
      • Core\AI\PyGenesisAssistant\Nova\ui\project_management_dialog.py (line 190)
      • Core\AI\PyGenesisAssistant\Nova\ui\project_management_dialog.py (line 313)
      • Core\AI\PyGenesisAssistant\Nova\ui\project_management_dialog.py (line 428)
      • Core\AI\PyGenesisAssistant\Nova\ui\project_management_dialog.py (line 496)
      • Config\ThemeManager.py (line 18)
      • Editors\ImageEditor\core\ui\panels\right_panel.py (line 15)
      • Editors\ImageEditor\core\ui\panels\right_panel.py (line 69)
      • Editors\ImageEditor\core\ui\panels\right_panel.py (line 136)
      • Editors\ImageEditor\core\ui\panels\right_panel.py (line 269)
      • Core\AI\PyGenesisAssistant\Nova\ui\theme_editor.py (line 15)
      • Core\AI\PyGenesisAssistant\Nova\ui\theme_editor.py (line 78)
      • Core\CodeSystem\ast.py (line 59)
      • Core\CodeSystem\ast.py (line 72)
      • Core\CodeSystem\ast.py (line 85)
      • Core\CodeSystem\ast.py (line 97)
      • Core\CodeSystem\ast.py (line 108)
      • Core\CodeSystem\ast.py (line 123)
      • Core\CodeSystem\ast.py (line 136)
      • Core\CodeSystem\ast.py (line 150)
      • Core\CodeSystem\ast.py (line 165)
      • Core\CodeSystem\ast.py (line 180)
      • Core\CodeSystem\ast.py (line 197)
      • Core\CodeSystem\ast.py (line 211)
      • Core\CodeSystem\ast.py (line 226)
      • Core\CodeSystem\ast.py (line 240)
      • Core\AI\PyGenesisAssistant\Nova\ui\preview_widget.py (line 20)
      • Core\AI\PyGenesisAssistant\Nova\ui\preview_widget.py (line 46)
      • Core\AI\PyGenesisAssistant\Nova\ui\preview_widget.py (line 112)
      • Core\AI\PyGenesisAssistant\Nova\ui\preview_widget.py (line 175)
      • Core\AI\PyGenesisAssistant\Nova\ui\preview_widget.py (line 234)
      • Core\AI\PyGenesisAssistant\code_analysis.py (line 32)
      • Core\AI\PyGenesisAssistant\code_analysis.py (line 91)
      • Core\AI\PyGenesisAssistant\Nova\ui\preview_dialog.py (line 22)
      • Editors\ImageEditor\core\ui\rotate_dialog.py (line 13)
      • Editors\ImageEditor\core\ui\rotate_dialog.py (line 70)
      • Editors\ImageEditor\core\ui\nine_slice_importer.py (line 28)
      • Core\AI\PyGenesisAssistant\Nova\ui\input_bar.py (line 31)
      • Core\AI\PyGenesisAssistant\Nova\ui\input_bar.py (line 54)
      • Core\Code\Unified\test_harness.py (line 20)
      • Editors\ImageEditor\core\ui\mirror_flip_dialog.py (line 9)
      • Core\AI\PyGenesisAssistant\Nova\ui\header.py (line 9)
      • Core\AI\PyGenesisAssistant\Nova\ui\header.py (line 276)
      • Core\AI\PyGenesisAssistant\Nova\ui\conversations_dialog.py (line 20)
      • Core\AI\PyGenesisAssistant\Nova\ui\conversations_dialog.py (line 112)
      • Editors\ImageEditor\core\ui\dialogs\preferences_dialog.py (line 26)
      • Core\AI\PyGenesisAssistant\Nova\ui\chat_view.py (line 24)
      • Core\AI\PyGenesisAssistant\Nova\ui\chat_view.py (line 106)
      • Core\AI\PyGenesisAssistant\Nova\ui\chat_view.py (line 130)
      • Core\AI\PyGenesisAssistant\Nova\ui\chat_view.py (line 175)
      • Editors\ImageEditor\core\ui\dialogs\preview_widgets.py (line 13)
      • Editors\ImageEditor\core\ui\dialogs\preview_widgets.py (line 34)
      • Editors\ImageEditor\core\ui\dialogs\preview_widgets.py (line 45)
      • Editors\ImageEditor\core\ui\dialogs\parameter_widgets.py (line 20)
      • Core\PyPILoadThread.py (line 18)
      • Core\PackageSearchThread.py (line 18)
      • Core\PackageLoadThread.py (line 20)
      • Editors\ImageEditor\core\ui\timeline.py (line 21)
      • Editors\ImageEditor\core\ui\timeline.py (line 61)
      • Editors\ImageEditor\core\ui\timeline.py (line 298)
      • Core\ModulePreloader.py (line 19)
      • Core\ModulePreloader.py (line 95)
      • Core\CodeSystem\parser.py (line 23)
      • Core\CodeSystem\parser.py (line 25)
      • Editors\ImageEditor\core\ui\dialogs\effect_dialog.py (line 26)
      • Core\PackageInstaller.py (line 37)
      • Core\CodeSystem\syntax.py (line 16)
      • Editors\ImageEditor\core\ui\texture_atlas_dialog.py (line 23)
      • Editors\ImageEditor\core\ui\texture_atlas_dialog.py (line 53)
      • Editors\ImageEditor\core\ui\texture_atlas_dialog.py (line 167)
      • Editors\ImageEditor\core\ui\texture_atlas_dialog.py (line 411)
      • Editors\ImageEditor\core\ui\texture_atlas_dialog.py (line 470)
      • Editors\ImageEditor\core\ui\texture_atlas_dialog.py (line 634)
      • Core\ExtensionsManager.py (line 96)
      • Editors\CodeEditor\ScriptEditor.py (line 23)
      • Editors\CodeEditor\PGSLCodeEditor.py (line 97)
      • Editors\CodeEditor\PGSLCodeEditor.py (line 141)
      • Editors\CodeEditor\PGSLCodeEditor.py (line 186)
      • Editors\BackgroundEditor\BackgroundEditor.py (line 15)
      • Core\ProjectManager.py (line 22)
      • Core\Rendering\Canvas_2D.py (line 39)
      • Core\Services\async_project_saver.py (line 21)
      • Core\Services\async_project_loader.py (line 30)
      • Editors\ImageEditor\core\core\ai_test_app.py (line 298)
      • Editors\ImageEditor\core\core\ai_test_app.py (line 354)
      • Core\Services\async_editor_loader.py (line 19)
      • Editors\ImageEditor\core\core\background_processor.py (line 33)
      • Editors\ImageEditor\core\core\background_processor.py (line 94)
      • Editors\ImageEditor\core\core\ai_worker_threads.py (line 25)
      • Editors\ImageEditor\core\core\ai_worker_threads.py (line 65)
      • Editors\ImageEditor\core\core\ai_worker_threads.py (line 141)
      • Editors\ImageEditor\core\core\ai_image_operations.py (line 18)
      • Editors\ImageEditor\core\ui\dialogs\origin_dialog.py (line 14)
      • Editors\ImageEditor\core\ui\dialogs\new_image_dialog.py (line 15)
      • Editors\ImageEditor\core\ui\character_creator_dialog.py (line 68)
      • Editors\ImageEditor\core\ui\character_creator_dialog.py (line 295)
      • Core\AI\PyGenesisAssistant\Nova\core\executors\code_search_executor.py (line 69)
      • Editors\ImageEditor\core\ui\dialogs\merge_replace_dialog.py (line 13)
      • Core\UtilityOperations.py (line 17)
      • Core\UtilityOperations.py (line 203)
      • Core\ResourceManager.py (line 20)
      • Core\Code\Shared\code_completer.py (line 24)
      • Editors\ImageEditor\core\ui\block_texture_dialog.py (line 14)
      • Core\Services\incremental_resource_reloader.py (line 23)
      • Editors\ImageEditor\core\ui\ai_dialogs.py (line 31)
      • Editors\ImageEditor\core\ui\ai_dialogs.py (line 82)
      • Editors\ImageEditor\core\ui\ai_dialogs.py (line 169)
      • Editors\ImageEditor\core\ui\ai_dialogs.py (line 258)
      • Editors\ImageEditor\core\ui\ai_dialogs.py (line 328)
      • Editors\ImageEditor\core\ui\ai_dialogs.py (line 448)
      • Editors\ImageEditor\core\ui\ai_dialogs.py (line 510)
      • Editors\ImageEditor\core\ui\ai_dialogs.py (line 635)
      • Core\AI\PyGenesisAssistant\Nova\core\async_scanner.py (line 18)
      • Editors\ImageEditor\core\ui\background_removal_dialog.py (line 22)
      • Core\Code\Base\base_syntax_highlighter.py (line 15)
      • Editors\ImageEditor\core\ui\api_key_dialog.py (line 17)
      • Core\AI\PyGenesisAssistant\NovaWidget.py (line 29)
      • Core\AI\PyGenesisAssistant\Nova\core\executors\resource_operation_executor.py (line 57)
      • Editors\ObjectEditor\object_editor.py (line 46)
      • Editors\ObjectEditor\UI\code_editor_widget.py (line 26)
      • Editors\ObjectEditor\UI\object_editor_menu.py (line 18)
      • Editors\ObjectEditor\UI\parent_child_panel.py (line 22)
      • Editors\ObjectEditor\UI\events_panel.py (line 107)
      • Editors\ObjectEditor\UI\events_panel.py (line 363)
      • Editors\ObjectEditor\UI\properties_panel.py (line 39)
      • Editors\ObjectEditor\UI\properties_panel.py (line 197)
      • Editors\RoomEditor\RoomEditor.py (line 41)
      • Editors\RoomEditor\RoomEditor.py (line 1238)
      • Editors\ImageEditor\core\ui\sprite_sheet_importer.py (line 21)
      • Editors\ImageEditor\core\ui\sprite_sheet_importer.py (line 151)
      • Editors\RoomEditor\ui\main_window.py (line 33)
      • Editors\ImageEditor\core\ui\panels\left_panel.py (line 11)
      • Editors\ImageEditor\core\ui\panels\left_panel.py (line 109)
      • Editors\ImageEditor\core\ui\panels\left_panel.py (line 149)
      • Editors\Shared\BaseImageResourceEditor.py (line 40)
      • Editors\ObjectEditor\object_editor_menu.py (line 18)
      • Editors\ObjectEditor\object_properties_panel.py (line 38)
      • Editors\ObjectEditor\object_properties_panel.py (line 194)
      • Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 262)
      • Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 2343)
      • Editors\TextureEditor\TextureEditor.py (line 29)
      • Editors\TextureEditor\TextureEditor.py (line 735)
      • Editors\TextureEditor\TextureEditor.py (line 1000)
      • UI\CommonDialogs\BackupFolderDialog.py (line 25)
      • UI\CommonDialogs\ResourceFolderDialog.py (line 24)
      • UI\CommonDialogs\RestoreDialog.py (line 29)
      • UI\CommonDialogs\ExtensionsDialog.py (line 32)
      • Editors\SoundEditor\SoundEditor.py (line 86)
      • Editors\SoundEditor\SoundEditor.py (line 328)
      • Editors\SoundEditor\SoundEditor.py (line 631)
      • Editors\SoundEditor\SoundEditor.py (line 688)
      • Editors\SoundEditor\SoundEditor.py (line 2226)
      • UI\Widgets\LoadingWidget.py (line 14)
      • UI\Widgets\ParallelThumbnailLoader.py (line 22)
      • UI\Widgets\TerminalWidget.py (line 17)
      • UI\Widgets\TerminalWidget.py (line 37)
      • UI\Widgets\ResourceTree.py (line 25)
      • UI\CommonDialogs\PreferencesDialog.py (line 22)
      • main.py (line 495)
      • UI\Widgets\ThumbnailLoader.py (line 24)
      • Editors\ObjectEditor\object_editor_ui.py (line 23)
      • Editors\ImageEditor\core\ui\preview.py (line 24)
      • Editors\ImageEditor\core\ui\preview.py (line 3101)
      • Tools\ScreenRecording\screen_recorder.py (line 32)
      • Tools\ScreenRecording\screen_recorder.py (line 244)
      • Tools\ScreenRecording\screen_recorder.py (line 322)
      • Editors\Shared\IntegratedImageEditor.py (line 27)
      • Editors\SoundEditor\core\WaveForge.py (line 44)
      • Editors\SoundEditor\core\WaveForge.py (line 143)
      • Editors\SoundEditor\core\WaveForge.py (line 390)
      • Editors\ImageEditor\core\ui\main_window.py (line 314)
      • Editors\ImageEditor\core\ui\main_window.py (line 325)
      • UI\MainWindow\MainWindow.py (line 50)
      • UI\MainWindow\MainWindow.py (line 276)
      • Editors\ObjectEditor\object_events_panel.py (line 110)
      • Editors\SpriteEditor\SpriteEditor.py (line 31)
      • Editors\SpriteEditor\SpriteEditor.py (line 975)
      • Editors\SpriteEditor\SpriteEditor.py (line 1240)
      • Editors\ModelEditor\ModelEditor.py (line 539)
      • Editors\ModelEditor\ModelEditor.py (line 998)
      • Editors\ModelEditor\ModelEditor.py (line 8125)
      • Editors\ModelEditor\ModelEditor.py (line 8196)

🏗️ plan
   📄 Core\AI\PyGenesisAssistant\Nova\core\operation_planner.py (line 70)
   📞 Called by:
      • Core\AI\PyGenesisAssistant\Nova\core\workflow.py (line 378)

🏗️ _generate_plan_name
   📄 Core\AI\PyGenesisAssistant\Nova\core\operation_planner.py (line 119)
   ⚠️  Never called

🏗️ _determine_priority
   📄 Core\AI\PyGenesisAssistant\Nova\core\operation_planner.py (line 128)
   ⚠️  Never called

🏗️ _generate_rationale
   📄 Core\AI\PyGenesisAssistant\Nova\core\operation_planner.py (line 137)
   ⚠️  Never called

🏗️ _assess_risk
   📄 Core\AI\PyGenesisAssistant\Nova\core\operation_planner.py (line 141)
   ⚠️  Never called

🏗️ _generate_expected_outcome
   📄 Core\AI\PyGenesisAssistant\Nova\core\operation_planner.py (line 156)
   ⚠️  Never called

🏗️ _requires_confirmation
   📄 Core\AI\PyGenesisAssistant\Nova\core\operation_planner.py (line 165)
   ⚠️  Never called

🏗️ _plan_resource_operation
   📄 Core\AI\PyGenesisAssistant\Nova\core\operation_planner.py (line 188)
   ⚠️  Never called

🏗️ _plan_project_modification
   📄 Core\AI\PyGenesisAssistant\Nova\core\operation_planner.py (line 247)
   ⚠️  Never called

🏗️ _plan_code_query
   📄 Core\AI\PyGenesisAssistant\Nova\core\operation_planner.py (line 300)
   ⚠️  Never called

🏗️ _plan_simple_operation
   📄 Core\AI\PyGenesisAssistant\Nova\core\operation_planner.py (line 315)
   ⚠️  Never called

🏗️ validate_plan
   📄 Core\AI\PyGenesisAssistant\Nova\core\operation_planner.py (line 329)
   📞 Called by:
      • Core\AI\PyGenesisAssistant\Nova\core\workflow.py (line 382)

🏗️ get_plan_summary
   📄 Core\AI\PyGenesisAssistant\Nova\core\operation_planner.py (line 362)
   📞 Called by:
      • Core\AI\PyGenesisAssistant\Nova\core\workflow.py (line 395)
      • Core\AI\PyGenesisAssistant\Nova\core\workflow.py (line 415)

🏗️ process
   📄 Core\AI\PyGenesisAssistant\Nova\core\engines\dictionary_engine.py (line 55)
   📞 Called by:
      • Core\AI\PyGenesisAssistant\NovaWidget.py (line 285)

🏗️ _extract_word
   📄 Core\AI\PyGenesisAssistant\Nova\core\engines\dictionary_engine.py (line 80)
   ⚠️  Never called

🏗️ _lookup_wordnet
   📄 Core\AI\PyGenesisAssistant\Nova\core\engines\dictionary_engine.py (line 105)
   ⚠️  Never called

🏗️ correct_spelling
   📄 Core\AI\PyGenesisAssistant\Nova\core\language_utils.py (line 114)
   📞 Called by:
      • Core\AI\PyGenesisAssistant\Nova\core\workflow.py (line 445)

🏗️ _correct_text_spelling
   📄 Core\AI\PyGenesisAssistant\Nova\core\language_utils.py (line 159)
   ⚠️  Never called

🏗️ _get_case_pattern
   📄 Core\AI\PyGenesisAssistant\Nova\core\language_utils.py (line 194)
   ⚠️  Never called

🏗️ _apply_case_pattern
   📄 Core\AI\PyGenesisAssistant\Nova\core\language_utils.py (line 207)
   ⚠️  Never called

🏗️ check_spelling
   📄 Core\AI\PyGenesisAssistant\Nova\core\language_utils.py (line 220)
   ⚠️  Never called

🏗️ get_language_name
   📄 Core\AI\PyGenesisAssistant\Nova\core\language_utils.py (line 267)
   ⚠️  Never called

🏗️ get_language_from_setting
   📄 Core\AI\PyGenesisAssistant\Nova\core\language_utils.py (line 275)
   ⚠️  Never called

🏗️ _apply_style
   📄 Core\AI\PyGenesisAssistant\Nova\ui\settings_dialog.py (line 340)
   ⚠️  Never called

🏗️ _populate_theme_list
   📄 Core\AI\PyGenesisAssistant\Nova\ui\settings_dialog.py (line 97)
   📞 Called by:
      • Core\AI\PyGenesisAssistant\Nova\ui\settings_dialog.py (line 454)

🏗️ _on_theme_selected
   📄 Core\AI\PyGenesisAssistant\Nova\ui\settings_dialog.py (line 108)
   ⚠️  Never called

🏗️ _on_theme_list_clicked
   📄 Core\AI\PyGenesisAssistant\Nova\ui\settings_dialog.py (line 119)
   ⚠️  Never called

🏗️ _add_theme
   📄 Core\AI\PyGenesisAssistant\Nova\ui\settings_dialog.py (line 132)
   ⚠️  Never called

🏗️ _delete_theme
   📄 Core\AI\PyGenesisAssistant\Nova\ui\settings_dialog.py (line 179)
   ⚠️  Never called

🏗️ _rename_theme
   📄 Core\AI\PyGenesisAssistant\Nova\ui\settings_dialog.py (line 210)
   ⚠️  Never called

🏗️ _edit_theme_properties
   📄 Core\AI\PyGenesisAssistant\Nova\ui\settings_dialog.py (line 220)
   ⚠️  Never called

🏗️ _edit_theme_name
   📄 Core\AI\PyGenesisAssistant\Nova\ui\settings_dialog.py (line 249)
   ⚠️  Never called

🏗️ _save_settings
   📄 Core\AI\PyGenesisAssistant\Nova\ui\settings_dialog.py (line 437)
   ⚠️  Never called

🏗️ showEvent
   📄 Core\AI\PyGenesisAssistant\Nova\ui\settings_dialog.py (line 449)
   📞 Called by:
      • Core\AI\PyGenesisAssistant\Nova\ui\settings_dialog.py (line 452)
      • UI\Widgets\LoadingWidget.py (line 43)

🏗️ selected_theme
   📄 Core\AI\PyGenesisAssistant\Nova\ui\settings_dialog.py (line 460)
   ⚠️  Never called

🏗️ _load_knowledge_base
   📄 Core\AI\PyGenesisAssistant\Nova\core\engines\conversation_engine.py (line 127)
   ⚠️  Never called

🏗️ _lookup_knowledge_base
   📄 Core\AI\PyGenesisAssistant\Nova\core\engines\conversation_engine.py (line 141)
   ⚠️  Never called

🏗️ _handle_context_reference
   📄 Core\AI\PyGenesisAssistant\Nova\core\engines\conversation_engine.py (line 215)
   ⚠️  Never called

🏗️ _add_follow_up
   📄 Core\AI\PyGenesisAssistant\Nova\core\engines\conversation_engine.py (line 240)
   ⚠️  Never called

🏗️ _get_time_date_response
   📄 Core\AI\PyGenesisAssistant\Nova\core\engines\conversation_engine.py (line 253)
   ⚠️  Never called

🏗️ _generate_contextual_response
   📄 Core\AI\PyGenesisAssistant\Nova\core\engines\conversation_engine.py (line 269)
   ⚠️  Never called

🏗️ __post_init__
   📄 Core\AI\PyGenesisAssistant\Nova\core\models.py (line 73)
   ⚠️  Never called

🏗️ update
   📄 Core\AI\PyGenesisAssistant\Nova\core\models.py (line 130)
   📞 Called by:
      • Editors\ImageEditor\core\ui\panels\right_panel.py (line 115)
      • Editors\ImageEditor\core\ui\panels\right_panel.py (line 132)
      • Editors\ImageEditor\core\ui\panels\right_panel.py (line 517)
      • Editors\ImageEditor\core\ui\panels\right_panel.py (line 535)
      • Editors\ImageEditor\core\ui\panels\right_panel.py (line 538)
      • Editors\ImageEditor\core\ui\panels\right_panel.py (line 646)
      • Editors\ImageEditor\core\ui\panels\right_panel.py (line 648)
      • Editors\ImageEditor\core\ui\panels\right_panel.py (line 735)
      • Editors\ImageEditor\core\ui\panels\right_panel.py (line 750)
      • Editors\ImageEditor\core\ui\panels\right_panel.py (line 842)
      • Editors\ImageEditor\core\ui\dialogs\preferences_dialog.py (line 493)
      • Core\AI\PyGenesisAssistant\Nova\core\workflow.py (line 240)
      • Core\AI\PyGenesisAssistant\Nova\core\workflow.py (line 448)
      • Editors\ImageEditor\core\ui\timeline.py (line 1082)
      • Editors\ImageEditor\core\ui\timeline.py (line 1091)
      • Editors\ImageEditor\core\ui\texture_atlas_dialog.py (line 762)
      • Editors\ImageEditor\core\ui\texture_atlas_dialog.py (line 772)
      • Editors\ImageEditor\core\app.py (line 24)
      • Core\AI\PyGenesisAssistant\Nova\core\slm\custom_neural_model.py (line 674)
      • Editors\BackgroundEditor\BackgroundEditor.py (line 127)
      • Editors\BackgroundEditor\BackgroundEditor.py (line 316)
      • Editors\BackgroundEditor\BackgroundEditor.py (line 336)
      • Core\Rendering\Canvas_2D.py (line 471)
      • Core\Rendering\Canvas_2D.py (line 482)
      • Core\Rendering\Canvas_2D.py (line 484)
      • Core\Rendering\Canvas_2D.py (line 701)
      • Editors\ImageEditor\core\core\state.py (line 71)
      • Editors\ImageEditor\core\core\settings.py (line 24)
      • Editors\RoomEditor\RoomEditor.py (line 799)
      • Editors\RoomEditor\RoomEditor.py (line 846)
      • Editors\RoomEditor\RoomEditor.py (line 883)
      • Editors\RoomEditor\RoomEditor.py (line 906)
      • Editors\RoomEditor\RoomEditor.py (line 927)
      • Editors\RoomEditor\RoomEditor.py (line 942)
      • Editors\RoomEditor\RoomEditor.py (line 954)
      • Editors\RoomEditor\RoomEditor.py (line 972)
      • Editors\RoomEditor\RoomEditor.py (line 983)
      • Editors\RoomEditor\RoomEditor.py (line 995)
      • Editors\RoomEditor\RoomEditor.py (line 1009)
      • Editors\RoomEditor\RoomEditor.py (line 1014)
      • Editors\RoomEditor\RoomEditor.py (line 1151)
      • Editors\RoomEditor\RoomEditor.py (line 1186)
      • Editors\ImageEditor\core\ui\sprite_sheet_importer.py (line 774)
      • Editors\RoomEditor\ui\main_window.py (line 782)
      • Editors\RoomEditor\ui\main_window.py (line 829)
      • Editors\RoomEditor\ui\main_window.py (line 866)
      • Editors\RoomEditor\ui\main_window.py (line 889)
      • Editors\RoomEditor\ui\main_window.py (line 910)
      • Editors\RoomEditor\ui\main_window.py (line 925)
      • Editors\RoomEditor\ui\main_window.py (line 937)
      • Editors\RoomEditor\ui\main_window.py (line 955)
      • Editors\RoomEditor\ui\main_window.py (line 966)
      • Editors\RoomEditor\ui\main_window.py (line 978)
      • Editors\RoomEditor\ui\main_window.py (line 992)
      • Editors\RoomEditor\ui\main_window.py (line 997)
      • Editors\RoomEditor\ui\main_window.py (line 1134)
      • Editors\RoomEditor\ui\main_window.py (line 1169)
      • Editors\ImageEditor\core\ui\panels\left_panel.py (line 572)
      • Editors\ImageEditor\core\ui\panels\left_panel.py (line 581)
      • Editors\ImageEditor\core\ui\panels\left_panel.py (line 591)
      • Editors\ImageEditor\core\ui\panels\left_panel.py (line 598)
      • Editors\ImageEditor\core\ui\panels\left_panel.py (line 648)
      • Editors\ImageEditor\core\ui\panels\left_panel.py (line 654)
      • Editors\ImageEditor\core\ui\panels\left_panel.py (line 727)
      • Editors\ImageEditor\core\ui\panels\left_panel.py (line 831)
      • Editors\ImageEditor\core\ui\panels\left_panel.py (line 847)
      • Editors\ImageEditor\core\ui\panels\left_panel.py (line 903)
      • Editors\ImageEditor\core\ui\panels\left_panel.py (line 909)
      • Editors\Shared\BaseImageResourceEditor.py (line 511)
      • Editors\Shared\BaseImageResourceEditor.py (line 529)
      • Editors\Shared\BaseImageResourceEditor.py (line 549)
      • Editors\Shared\BaseImageResourceEditor.py (line 555)
      • Editors\Shared\BaseImageResourceEditor.py (line 606)
      • Editors\Shared\BaseImageResourceEditor.py (line 645)
      • Editors\Shared\BaseImageResourceEditor.py (line 674)
      • Editors\Shared\BaseImageResourceEditor.py (line 696)
      • Editors\Shared\BaseImageResourceEditor.py (line 916)
      • Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 2806)
      • Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 2861)
      • Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 2903)
      • Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 3092)
      • Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 3245)
      • Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 3397)
      • Editors\TextureEditor\TextureEditor.py (line 85)
      • Editors\TextureEditor\TextureEditor.py (line 268)
      • Editors\TextureEditor\TextureEditor.py (line 387)
      • Editors\TextureEditor\TextureEditor.py (line 557)
      • Editors\TextureEditor\TextureEditor.py (line 581)
      • Editors\ImageEditor\core\ui\preview.py (line 104)
      • Editors\ImageEditor\core\ui\preview.py (line 114)
      • Editors\ImageEditor\core\ui\preview.py (line 125)
      • Editors\ImageEditor\core\ui\preview.py (line 127)
      • Editors\ImageEditor\core\ui\preview.py (line 2162)
      • Editors\ImageEditor\core\ui\preview.py (line 2173)
      • Editors\ImageEditor\core\ui\preview.py (line 2179)
      • Editors\ImageEditor\core\ui\preview.py (line 2182)
      • Editors\Shared\IntegratedImageEditor.py (line 774)
      • Editors\Shared\IntegratedImageEditor.py (line 796)
      • Editors\Shared\IntegratedImageEditor.py (line 828)
      • Editors\Shared\IntegratedImageEditor.py (line 1148)
      • Editors\ImageEditor\core\ui\main_window.py (line 363)
      • Editors\ImageEditor\core\ui\main_window.py (line 365)
      • Editors\ImageEditor\core\ui\main_window.py (line 1007)
      • Editors\ImageEditor\core\ui\main_window.py (line 1087)
      • Editors\ImageEditor\core\ui\main_window.py (line 1216)
      • Editors\ImageEditor\core\ui\main_window.py (line 1261)
      • Editors\ImageEditor\core\ui\main_window.py (line 1321)
      • Editors\ImageEditor\core\ui\main_window.py (line 1488)
      • Editors\ImageEditor\core\ui\main_window.py (line 1878)
      • Editors\ImageEditor\core\ui\main_window.py (line 1998)
      • Editors\ImageEditor\core\ui\main_window.py (line 2060)
      • Editors\ImageEditor\core\ui\main_window.py (line 2096)
      • Editors\ImageEditor\core\ui\main_window.py (line 2804)
      • Editors\ImageEditor\core\ui\main_window.py (line 2817)
      • Editors\ImageEditor\core\ui\main_window.py (line 2821)
      • Editors\SpriteEditor\SpriteEditor.py (line 136)
      • Editors\SpriteEditor\SpriteEditor.py (line 271)
      • Editors\SpriteEditor\SpriteEditor.py (line 436)
      • Editors\SpriteEditor\SpriteEditor.py (line 510)
      • Editors\SpriteEditor\SpriteEditor.py (line 684)
      • Editors\SpriteEditor\SpriteEditor.py (line 752)
      • Editors\SpriteEditor\SpriteEditor.py (line 774)
      • Editors\SpriteEditor\SpriteEditor.py (line 775)
      • Editors\SpriteEditor\SpriteEditor.py (line 796)
      • Editors\ModelEditor\ModelEditor.py (line 670)
      • Editors\ModelEditor\ModelEditor.py (line 684)
      • Editors\ModelEditor\ModelEditor.py (line 691)
      • Editors\ModelEditor\ModelEditor.py (line 972)
      • Editors\ModelEditor\ModelEditor.py (line 4766)
      • Editors\ModelEditor\ModelEditor.py (line 4774)
      • Editors\ModelEditor\ModelEditor.py (line 8161)
      • Editors\ModelEditor\ModelEditor.py (line 8982)
      • Editors\ModelEditor\ModelEditor.py (line 8997)
      • Editors\ModelEditor\ModelEditor.py (line 9281)
      • Editors\ModelEditor\ModelEditor.py (line 9412)
      • Editors\ModelEditor\ModelEditor.py (line 9570)
      • Editors\ModelEditor\ModelEditor.py (line 9646)
      • Editors\ModelEditor\ModelEditor.py (line 9654)
      • Editors\ModelEditor\ModelEditor.py (line 9662)
      • Editors\ModelEditor\ModelEditor.py (line 9835)
      • Editors\ModelEditor\ModelEditor.py (line 9870)
      • Editors\ModelEditor\ModelEditor.py (line 9905)
      • Editors\ModelEditor\ModelEditor.py (line 10281)
      • Editors\ModelEditor\ModelEditor.py (line 10542)
      • Editors\ModelEditor\ModelEditor.py (line 10566)
      • Editors\ModelEditor\ModelEditor.py (line 11781)

🏗️ set_pending_plan
   📄 Core\AI\PyGenesisAssistant\Nova\core\models.py (line 151)
   📞 Called by:
      • Core\AI\PyGenesisAssistant\Nova\core\workflow.py (line 401)
      • Core\AI\PyGenesisAssistant\Nova\core\workflow.py (line 418)

🏗️ clear_pending_plan
   📄 Core\AI\PyGenesisAssistant\Nova\core\models.py (line 158)
   📞 Called by:
      • Core\AI\PyGenesisAssistant\Nova\core\workflow.py (line 220)
      • Core\AI\PyGenesisAssistant\Nova\core\workflow.py (line 251)

🏗️ has_pending_plan
   📄 Core\AI\PyGenesisAssistant\Nova\core\models.py (line 166)
   📞 Called by:
      • Core\AI\PyGenesisAssistant\Nova\core\workflow.py (line 208)

🏗️ __new__
   📄 Core\Debug.py (line 12)
   📞 Called by:
      • Core\Debug.py (line 14)
      • Core\Events.py (line 67)
      • Core\Rendering\OpenGLRuntime.py (line 25)

🏗️ set_settings
   📄 Core\Debug.py (line 17)
   ⚠️  Never called

🏗️ is_debug_enabled
   📄 Core\Debug.py (line 22)
   ⚠️  Never called

🏗️ force_debug
   📄 Core\Debug.py (line 45)
   ⚠️  Never called

🏗️ reset
   📄 Core\Debug.py (line 49)
   ⚠️  Never called

🏗️ debug
   📄 Core\Debug.py (line 56)
   📞 Called by:
      • Config\ThemeManager.py (line 644)
      • Core\Rendering\BufferManager.py (line 60)
      • Core\Rendering\BufferManager.py (line 75)
      • Core\Rendering\BufferManager.py (line 105)
      • Core\Rendering\BufferManager.py (line 120)
      • Core\Rendering\BufferManager.py (line 190)
      • Core\Rendering\BufferManager.py (line 244)
      • Core\Rendering\BufferManager.py (line 251)
      • Core\Rendering\BufferManager.py (line 260)
      • Core\Rendering\BufferManager.py (line 285)
      • Core\PyPILoadThread.py (line 24)
      • Core\PyPILoadThread.py (line 27)
      • Core\PyPILoadThread.py (line 29)
      • Core\PyPILoadThread.py (line 31)
      • Core\EditorOptimizer.py (line 45)
      • Core\EditorOptimizer.py (line 47)
      • Core\EditorOptimizer.py (line 61)
      • Core\EditorOptimizer.py (line 63)
      • Core\EditorOptimizer.py (line 97)
      • Core\ProjectIndexManager.py (line 31)
      • Core\ProjectIndexManager.py (line 58)
      • Core\ProjectIndexManager.py (line 63)
      • Core\ProjectIndexManager.py (line 65)
      • Core\ProjectIndexManager.py (line 74)
      • Core\ProjectIndexManager.py (line 83)
      • Core\ProjectIndexManager.py (line 88)
      • Core\ProjectIndexManager.py (line 91)
      • Core\ProjectIndexManager.py (line 97)
      • Core\ProjectIndexManager.py (line 99)
      • Core\ProjectIndexManager.py (line 128)
      • Core\ProjectIndexManager.py (line 134)
      • Core\PackageSearchThread.py (line 27)
      • Core\PackageSearchThread.py (line 31)
      • Core\PackageSearchThread.py (line 33)
      • Core\EditorFactory.py (line 53)
      • Core\EditorFactory.py (line 56)
      • Core\PackageLoadThread.py (line 27)
      • Core\PackageLoadThread.py (line 32)
      • Core\PackageLoadThread.py (line 37)
      • Core\PackageLoadThread.py (line 40)
      • Core\PackageLoadThread.py (line 42)
      • Editors\ImageEditor\core\ui\timeline.py (line 549)
      • Editors\ImageEditor\core\ui\timeline.py (line 552)
      • Editors\ImageEditor\core\ui\timeline.py (line 555)
      • Editors\ImageEditor\core\ui\timeline.py (line 607)
      • Editors\ImageEditor\core\ui\timeline.py (line 609)
      • Editors\ImageEditor\core\ui\timeline.py (line 611)
      • Editors\ImageEditor\core\ui\timeline.py (line 660)
      • Editors\ImageEditor\core\ui\timeline.py (line 666)
      • Editors\ImageEditor\core\ui\timeline.py (line 669)
      • Editors\ImageEditor\core\ui\timeline.py (line 681)
      • Editors\ImageEditor\core\ui\timeline.py (line 687)
      • Editors\ImageEditor\core\ui\timeline.py (line 698)
      • Editors\ImageEditor\core\ui\timeline.py (line 1337)
      • Editors\ImageEditor\core\ui\timeline.py (line 1346)
      • Editors\ImageEditor\core\ui\timeline.py (line 1353)
      • Editors\ImageEditor\core\ui\timeline.py (line 1357)
      • Editors\ImageEditor\core\ui\timeline.py (line 1395)
      • Editors\ImageEditor\core\ui\timeline.py (line 1404)
      • Core\ModulePreloader.py (line 45)
      • Core\ModulePreloader.py (line 105)
      • Core\ModulePreloader.py (line 109)
      • Core\ModulePreloader.py (line 118)
      • Core\ModulePreloader.py (line 141)
      • Core\ModulePreloader.py (line 143)
      • Core\ModulePreloader.py (line 151)
      • Core\ModulePreloader.py (line 160)
      • Core\ModulePreloader.py (line 168)
      • Core\ModulePreloader.py (line 170)
      • Core\ModulePreloader.py (line 177)
      • Core\ModulePreloader.py (line 181)
      • Core\ModulePreloader.py (line 191)
      • Core\ModulePreloader.py (line 195)
      • Core\ModulePreloader.py (line 197)
      • Core\ModulePreloader.py (line 199)
      • Core\ModulePreloader.py (line 212)
      • Core\ModulePreloader.py (line 217)
      • Core\ModulePreloader.py (line 219)
      • Editors\ImageEditor\core\ui\dialogs\effect_dialog.py (line 793)
      • Editors\ImageEditor\core\ui\dialogs\effect_dialog.py (line 797)
      • Editors\ImageEditor\core\ui\dialogs\effect_dialog.py (line 798)
      • Editors\ImageEditor\core\ui\dialogs\effect_dialog.py (line 802)
      • Editors\ImageEditor\core\ui\dialogs\effect_dialog.py (line 806)
      • Editors\ImageEditor\core\ui\dialogs\effect_dialog.py (line 821)
      • Editors\ImageEditor\core\ui\dialogs\effect_dialog.py (line 825)
      • Core\ExtensionsManager.py (line 67)
      • Core\ExtensionsManager.py (line 82)
      • Core\ExtensionsManager.py (line 162)
      • Core\ExtensionsManager.py (line 173)
      • Core\ExtensionsManager.py (line 193)
      • Core\ExtensionsManager.py (line 198)
      • Core\ExtensionsManager.py (line 215)
      • Core\ExtensionsManager.py (line 243)
      • Core\ExtensionsManager.py (line 269)
      • Core\ExtensionsManager.py (line 277)
      • Core\ExtensionsManager.py (line 279)
      • Core\ExtensionsManager.py (line 281)
      • Core\ExtensionsManager.py (line 303)
      • Core\ExtensionsManager.py (line 317)
      • Core\ExtensionsManager.py (line 337)
      • Core\ExtensionsManager.py (line 341)
      • Core\ExtensionsManager.py (line 343)
      • Core\ExtensionsManager.py (line 377)
      • Core\ExtensionsManager.py (line 389)
      • Core\ExtensionsManager.py (line 428)
      • Core\ExtensionsManager.py (line 430)
      • Core\ExtensionsManager.py (line 555)
      • Core\ExtensionsManager.py (line 562)
      • Core\ExtensionsManager.py (line 663)
      • Core\ExtensionsManager.py (line 708)
      • Core\Events.py (line 78)
      • Core\Events.py (line 94)
      • Core\Events.py (line 107)
      • Core\Events.py (line 126)
      • Core\Events.py (line 134)
      • Core\Events.py (line 145)
      • Core\Events.py (line 148)
      • Editors\BackgroundEditor\BackgroundEditor.py (line 39)
      • Editors\BackgroundEditor\BackgroundEditor.py (line 69)
      • Editors\BackgroundEditor\BackgroundEditor.py (line 89)
      • Editors\BackgroundEditor\BackgroundEditor.py (line 148)
      • Editors\BackgroundEditor\BackgroundEditor.py (line 151)
      • Editors\BackgroundEditor\BackgroundEditor.py (line 162)
      • Editors\BackgroundEditor\BackgroundEditor.py (line 200)
      • Editors\BackgroundEditor\BackgroundEditor.py (line 327)
      • Editors\BackgroundEditor\BackgroundEditor.py (line 329)
      • Editors\BackgroundEditor\BackgroundEditor.py (line 343)
      • Editors\BackgroundEditor\BackgroundEditor.py (line 345)
      • Editors\BackgroundEditor\BackgroundEditor.py (line 347)
      • Editors\BackgroundEditor\BackgroundEditor.py (line 376)
      • Editors\BackgroundEditor\BackgroundEditor.py (line 399)
      • Editors\BackgroundEditor\BackgroundEditor.py (line 412)
      • Editors\BackgroundEditor\BackgroundEditor.py (line 417)
      • Editors\BackgroundEditor\BackgroundEditor.py (line 459)
      • Editors\BackgroundEditor\BackgroundEditor.py (line 468)
      • Editors\BackgroundEditor\BackgroundEditor.py (line 471)
      • Editors\BackgroundEditor\BackgroundEditor.py (line 491)
      • Editors\BackgroundEditor\BackgroundEditor.py (line 494)
      • Core\Rendering\SuperShader_2D.py (line 69)
      • Core\Rendering\SuperShader_2D.py (line 72)
      • Core\Rendering\SuperShader_2D.py (line 76)
      • Core\ProjectManager.py (line 127)
      • Core\ProjectManager.py (line 129)
      • Core\ProjectManager.py (line 137)
      • Core\ProjectManager.py (line 139)
      • Core\ProjectManager.py (line 258)
      • Core\ProjectManager.py (line 260)
      • Core\ProjectManager.py (line 268)
      • Core\ProjectManager.py (line 270)
      • Core\ProjectManager.py (line 284)
      • Core\ProjectManager.py (line 298)
      • Core\ProjectManager.py (line 309)
      • Core\ProjectManager.py (line 314)
      • Core\ProjectManager.py (line 366)
      • Core\ProjectManager.py (line 371)
      • Core\ProjectManager.py (line 378)
      • Core\ProjectManager.py (line 391)
      • Core\ProjectManager.py (line 395)
      • Core\ProjectManager.py (line 396)
      • Core\ProjectManager.py (line 407)
      • Core\ProjectManager.py (line 410)
      • Core\ProjectManager.py (line 421)
      • Core\ProjectManager.py (line 426)
      • Core\ProjectManager.py (line 433)
      • Core\ProjectManager.py (line 442)
      • Core\ProjectManager.py (line 445)
      • Core\ProjectManager.py (line 447)
      • Core\ProjectManager.py (line 451)
      • Core\ProjectManager.py (line 452)
      • Core\ProjectManager.py (line 455)
      • Core\ProjectManager.py (line 466)
      • Core\ProjectManager.py (line 471)
      • Core\ProjectManager.py (line 478)
      • Core\ProjectManager.py (line 484)
      • Core\ProjectManager.py (line 485)
      • Core\ProjectManager.py (line 488)
      • Core\ProjectManager.py (line 490)
      • Core\ProjectManager.py (line 496)
      • Core\ProjectManager.py (line 499)
      • Core\ProjectManager.py (line 501)
      • Core\ProjectManager.py (line 505)
      • Core\ProjectManager.py (line 508)
      • Core\ProjectManager.py (line 519)
      • Core\ProjectManager.py (line 524)
      • Core\ProjectManager.py (line 531)
      • Core\ProjectManager.py (line 544)
      • Core\ProjectManager.py (line 552)
      • Core\ProjectManager.py (line 563)
      • Core\ProjectManager.py (line 570)
      • Core\ProjectManager.py (line 582)
      • Core\ProjectManager.py (line 598)
      • Core\ProjectManager.py (line 605)
      • Core\ProjectManager.py (line 615)
      • Core\ProjectManager.py (line 622)
      • Core\ProjectManager.py (line 633)
      • Core\ProjectManager.py (line 640)
      • Core\ProjectManager.py (line 646)
      • Core\ProjectManager.py (line 648)
      • Core\ProjectManager.py (line 652)
      • Core\ProjectManager.py (line 655)
      • Core\ProjectManager.py (line 666)
      • Core\ProjectManager.py (line 671)
      • Core\ProjectManager.py (line 678)
      • Core\ProjectManager.py (line 689)
      • Core\ProjectManager.py (line 691)
      • Core\ProjectManager.py (line 700)
      • Core\ProjectManager.py (line 703)
      • Core\ProjectManager.py (line 707)
      • Core\ProjectManager.py (line 711)
      • Core\ProjectManager.py (line 714)
      • Core\ProjectManager.py (line 725)
      • Core\ProjectManager.py (line 730)
      • Core\ProjectManager.py (line 732)
      • Core\ProjectManager.py (line 736)
      • Core\ProjectManager.py (line 739)
      • Core\ProjectManager.py (line 750)
      • Core\ProjectManager.py (line 755)
      • Core\ProjectManager.py (line 762)
      • Core\ProjectManager.py (line 773)
      • Core\ProjectManager.py (line 775)
      • Core\ProjectManager.py (line 784)
      • Core\ProjectManager.py (line 787)
      • Core\ProjectManager.py (line 791)
      • Core\ProjectManager.py (line 795)
      • Core\ProjectManager.py (line 800)
      • Core\ProjectManager.py (line 803)
      • Core\ProjectManager.py (line 814)
      • Core\ProjectManager.py (line 819)
      • Core\ProjectManager.py (line 826)
      • Core\ProjectManager.py (line 836)
      • Core\ProjectManager.py (line 838)
      • Core\ProjectManager.py (line 840)
      • Core\ProjectManager.py (line 842)
      • Core\ProjectManager.py (line 846)
      • Core\ProjectManager.py (line 849)
      • Core\ProjectManager.py (line 860)
      • Core\ProjectManager.py (line 865)
      • Core\ProjectManager.py (line 867)
      • Core\ProjectManager.py (line 915)
      • Core\ProjectManager.py (line 916)
      • Core\ProjectManager.py (line 922)
      • Core\ProjectManager.py (line 923)
      • Core\ProjectManager.py (line 929)
      • Core\ProjectManager.py (line 934)
      • Core\ProjectManager.py (line 948)
      • Core\ProjectManager.py (line 1030)
      • Core\ProjectManager.py (line 1042)
      • Core\ProjectManager.py (line 1046)
      • Core\ProjectManager.py (line 1086)
      • Core\ProjectManager.py (line 1094)
      • Core\ProjectManager.py (line 1101)
      • Core\ProjectManager.py (line 1164)
      • Core\ProjectManager.py (line 1181)
      • Core\ProjectManager.py (line 1185)
      • Core\ProjectManager.py (line 1186)
      • Core\ProjectManager.py (line 1191)
      • Core\ProjectManager.py (line 1192)
      • Core\ProjectManager.py (line 1194)
      • Core\ProjectManager.py (line 1201)
      • Core\ProjectManager.py (line 1210)
      • Core\ProjectManager.py (line 1223)
      • Core\ProjectManager.py (line 1225)
      • Core\ProjectManager.py (line 1234)
      • Core\ProjectManager.py (line 1278)
      • Core\ProjectManager.py (line 1313)
      • Core\ProjectManager.py (line 1315)
      • Core\ProjectManager.py (line 1327)
      • Core\ProjectManager.py (line 1332)
      • Core\ProjectManager.py (line 1407)
      • Core\ProjectManager.py (line 1409)
      • Core\Rendering\Canvas_2D.py (line 106)
      • Core\Rendering\Canvas_2D.py (line 111)
      • Core\Rendering\Canvas_2D.py (line 234)
      • Core\Rendering\Canvas_2D.py (line 674)
      • Core\Rendering\ShaderManager.py (line 74)
      • Core\Rendering\ShaderManager.py (line 79)
      • Core\Rendering\ShaderManager.py (line 143)
      • Core\Rendering\ShaderManager.py (line 156)
      • Core\Rendering\ShaderManager.py (line 159)
      • Core\Rendering\ShaderManager.py (line 184)
      • Core\Rendering\ShaderManager.py (line 223)
      • Core\Rendering\OpenGLRuntime.py (line 51)
      • Core\Rendering\OpenGLRuntime.py (line 62)
      • Core\Rendering\OpenGLRuntime.py (line 80)
      • Core\Rendering\OpenGLRuntime.py (line 81)
      • Core\Rendering\OpenGLRuntime.py (line 101)
      • Core\Rendering\OpenGLRuntime.py (line 127)
      • Core\Rendering\OpenGLRuntime.py (line 137)
      • Core\Rendering\OpenGLRuntime.py (line 169)
      • Core\Rendering\OpenGLRuntime.py (line 197)
      • Core\Rendering\OpenGLRuntime.py (line 230)
      • Core\Rendering\OpenGLRuntime.py (line 241)
      • Core\Rendering\OpenGLRuntime.py (line 253)
      • Core\Services\async_project_saver.py (line 66)
      • Core\Services\async_project_saver.py (line 72)
      • Core\Services\async_project_saver.py (line 74)
      • Core\Services\async_project_loader.py (line 59)
      • Core\Services\async_project_loader.py (line 87)
      • Core\Services\async_project_loader.py (line 116)
      • Core\Services\async_project_loader.py (line 118)
      • Core\Services\async_editor_loader.py (line 27)
      • Core\Services\async_editor_loader.py (line 38)
      • Core\Services\async_editor_loader.py (line 48)
      • Core\Services\async_editor_loader.py (line 50)
      • Core\Rendering\TextureManager.py (line 98)
      • Core\Rendering\TextureManager.py (line 131)
      • Core\Rendering\TextureManager.py (line 176)
      • Core\Rendering\TextureManager.py (line 227)
      • Core\Rendering\TextureManager.py (line 261)
      • Core\Rendering\TextureManager.py (line 279)
      • Core\UtilityOperations.py (line 357)
      • Core\UtilityOperations.py (line 401)
      • Core\ResourceManager.py (line 272)
      • Core\ResourceManager.py (line 296)
      • Core\ResourceManager.py (line 301)
      • Core\ResourceManager.py (line 515)
      • Core\ResourceManager.py (line 567)
      • Core\ResourceManager.py (line 570)
      • Core\ResourceManager.py (line 604)
      • Core\ResourceManager.py (line 607)
      • Core\ResourceManager.py (line 622)
      • Core\ResourceManager.py (line 639)
      • Core\ResourceManager.py (line 693)
      • Core\ResourceManager.py (line 709)
      • Core\ResourceManager.py (line 751)
      • Core\ResourceManager.py (line 754)
      • Core\ResourceManager.py (line 759)
      • Core\ResourceManager.py (line 877)
      • Core\ResourceManager.py (line 950)
      • Core\ResourceManager.py (line 962)
      • Core\ResourceManager.py (line 971)
      • Core\ResourceManager.py (line 978)
      • Core\ResourceManager.py (line 986)
      • Core\ResourceManager.py (line 988)
      • Core\ResourceManager.py (line 999)
      • Core\ResourceManager.py (line 1011)
      • Core\ResourceManager.py (line 1012)
      • Core\ResourceManager.py (line 1013)
      • Core\ResourceManager.py (line 1026)
      • Core\ResourceManager.py (line 1042)
      • Core\ResourceManager.py (line 1054)
      • Core\ResourceManager.py (line 1061)
      • Core\ResourceManager.py (line 1069)
      • Core\ResourceManager.py (line 1071)
      • Core\ResourceManager.py (line 1082)
      • Core\ResourceManager.py (line 1122)
      • Core\ResourceManager.py (line 1145)
      • Core\ResourceManager.py (line 1153)
      • Core\ResourceManager.py (line 1193)
      • Core\ResourceManager.py (line 1206)
      • Core\ResourceManager.py (line 1224)
      • Core\ResourceManager.py (line 1234)
      • Core\ResourceManager.py (line 1236)
      • Core\ResourceManager.py (line 1238)
      • Core\ResourceManager.py (line 1239)
      • Core\ResourceManager.py (line 1240)
      • Core\ResourceManager.py (line 1274)
      • Core\ResourceManager.py (line 1295)
      • Core\ResourceManager.py (line 1305)
      • Core\ResourceManager.py (line 1307)
      • Core\ResourceManager.py (line 1323)
      • Core\ResourceManager.py (line 1358)
      • Core\ResourceManager.py (line 1385)
      • Core\ResourceManager.py (line 1394)
      • Core\ResourceManager.py (line 1403)
      • Core\ResourceManager.py (line 1423)
      • Core\ResourceManager.py (line 1425)
      • Core\ResourceManager.py (line 1472)
      • Core\ResourceManager.py (line 1480)
      • Core\ResourceManager.py (line 1483)
      • Core\ResourceManager.py (line 1495)
      • Core\ResourceManager.py (line 1514)
      • Core\ResourceManager.py (line 1535)
      • Core\ResourceManager.py (line 1541)
      • Core\ResourceManager.py (line 1542)
      • Core\ResourceManager.py (line 1574)
      • Core\ResourceManager.py (line 1576)
      • Core\ResourceManager.py (line 1586)
      • Core\ResourceManager.py (line 1588)
      • Core\ResourceManager.py (line 1599)
      • Core\ResourceManager.py (line 1601)
      • Core\ResourceManager.py (line 1611)
      • Core\ResourceManager.py (line 1629)
      • Core\ResourceManager.py (line 1650)
      • Core\ResourceManager.py (line 1660)
      • Core\ResourceManager.py (line 1938)
      • Core\ThumbnailCache.py (line 68)
      • Core\ThumbnailCache.py (line 75)
      • Core\ThumbnailCache.py (line 79)
      • Core\ThumbnailCache.py (line 116)
      • Core\ThumbnailCache.py (line 120)
      • Core\ThumbnailCache.py (line 134)
      • Core\ThumbnailCache.py (line 137)
      • Core\ThumbnailCache.py (line 172)
      • Core\ThumbnailCache.py (line 175)
      • Core\ThumbnailCache.py (line 199)
      • Core\ThumbnailCache.py (line 208)
      • Core\Services\resource_service.py (line 40)
      • Core\Services\resource_service.py (line 45)
      • Core\Services\resource_service.py (line 79)
      • Core\Services\incremental_resource_reloader.py (line 92)
      • Core\Services\incremental_resource_reloader.py (line 94)
      • Core\Services\incremental_resource_reloader.py (line 170)
      • Core\Services\project_service.py (line 37)
      • Core\Services\project_service.py (line 68)
      • Core\Services\file_service.py (line 30)
      • Core\Services\file_service.py (line 36)
      • Core\Services\file_service.py (line 58)
      • Core\Services\file_service.py (line 71)
      • Editors\ObjectEditor\object_editor.py (line 168)
      • Editors\ObjectEditor\object_editor.py (line 276)
      • Editors\ObjectEditor\object_editor.py (line 285)
      • Editors\ObjectEditor\object_editor.py (line 299)
      • Editors\ObjectEditor\object_editor.py (line 358)
      • Editors\ObjectEditor\object_editor.py (line 473)
      • Editors\ObjectEditor\object_editor.py (line 1118)
      • Editors\ObjectEditor\object_editor.py (line 1227)
      • Editors\ObjectEditor\Services\object_file_service.py (line 52)
      • Editors\ObjectEditor\Services\object_file_service.py (line 72)
      • Editors\ObjectEditor\Services\object_file_service.py (line 83)
      • Editors\ObjectEditor\Services\object_file_service.py (line 94)
      • Editors\ObjectEditor\UI\properties_panel.py (line 420)
      • Editors\ObjectEditor\UI\properties_panel.py (line 424)
      • Editors\ObjectEditor\UI\properties_panel.py (line 427)
      • Editors\RoomEditor\RoomEditor.py (line 1110)
      • Editors\RoomEditor\ui\main_window.py (line 1093)
      • Editors\ObjectEditor\object_properties_panel.py (line 381)
      • Editors\ObjectEditor\object_properties_panel.py (line 385)
      • Editors\ObjectEditor\object_properties_panel.py (line 388)
      • Editors\TextureEditor\TextureEditor.py (line 114)
      • Editors\TextureEditor\TextureEditor.py (line 298)
      • Editors\TextureEditor\TextureEditor.py (line 303)
      • Editors\TextureEditor\TextureEditor.py (line 345)
      • Editors\TextureEditor\TextureEditor.py (line 354)
      • Editors\TextureEditor\TextureEditor.py (line 357)
      • Editors\TextureEditor\TextureEditor.py (line 377)
      • Editors\TextureEditor\TextureEditor.py (line 380)
      • Editors\TextureEditor\TextureEditor.py (line 594)
      • Editors\TextureEditor\TextureEditor.py (line 596)
      • Editors\TextureEditor\TextureEditor.py (line 598)
      • Editors\TextureEditor\TextureEditor.py (line 604)
      • Editors\TextureEditor\TextureEditor.py (line 608)
      • Editors\TextureEditor\TextureEditor.py (line 642)
      • Editors\TextureEditor\TextureEditor.py (line 648)
      • UI\CommonDialogs\ExtensionsDialog.py (line 87)
      • UI\CommonDialogs\ExtensionsDialog.py (line 89)
      • UI\CommonDialogs\ExtensionsDialog.py (line 276)
      • UI\CommonDialogs\ExtensionsDialog.py (line 311)
      • UI\CommonDialogs\ExtensionsDialog.py (line 317)
      • UI\CommonDialogs\ExtensionsDialog.py (line 396)
      • UI\CommonDialogs\ExtensionsDialog.py (line 420)
      • UI\CommonDialogs\ExtensionsDialog.py (line 488)
      • UI\CommonDialogs\ExtensionsDialog.py (line 508)
      • UI\CommonDialogs\ExtensionsDialog.py (line 1019)
      • UI\Widgets\ParallelThumbnailLoader.py (line 53)
      • UI\Widgets\ParallelThumbnailLoader.py (line 92)
      • UI\Widgets\ResourceTree.py (line 138)
      • UI\Widgets\ResourceTree.py (line 168)
      • UI\Widgets\ResourceTree.py (line 170)
      • UI\Widgets\ResourceTree.py (line 183)
      • UI\Widgets\ResourceTree.py (line 185)
      • UI\Widgets\ResourceTree.py (line 212)
      • UI\Widgets\ResourceTree.py (line 214)
      • UI\Widgets\ResourceTree.py (line 651)
      • UI\Widgets\ResourceTree.py (line 855)
      • UI\Widgets\ResourceTree.py (line 861)
      • UI\Widgets\ResourceTree.py (line 873)
      • UI\Widgets\ResourceTree.py (line 883)
      • UI\Widgets\ResourceTree.py (line 885)
      • UI\Widgets\ResourceTree.py (line 887)
      • UI\Widgets\ResourceTree.py (line 1529)
      • UI\Widgets\ResourceTree.py (line 1531)
      • UI\Widgets\ResourceTree.py (line 1988)
      • UI\Widgets\ResourceTree.py (line 2012)
      • UI\Widgets\ResourceTree.py (line 2018)
      • main.py (line 39)
      • main.py (line 44)
      • main.py (line 51)
      • main.py (line 59)
      • main.py (line 62)
      • main.py (line 65)
      • main.py (line 68)
      • main.py (line 76)
      • main.py (line 89)
      • main.py (line 92)
      • main.py (line 99)
      • main.py (line 100)
      • main.py (line 237)
      • main.py (line 243)
      • main.py (line 319)
      • main.py (line 439)
      • main.py (line 469)
      • main.py (line 572)
      • main.py (line 574)
      • main.py (line 578)
      • UI\Widgets\ThumbnailLoader.py (line 42)
      • UI\Widgets\ThumbnailLoader.py (line 51)
      • UI\Widgets\ThumbnailLoader.py (line 57)
      • UI\Widgets\ThumbnailLoader.py (line 71)
      • UI\Widgets\ThumbnailLoader.py (line 80)
      • UI\Widgets\ThumbnailLoader.py (line 91)
      • UI\Widgets\ThumbnailLoader.py (line 95)
      • UI\Widgets\ThumbnailLoader.py (line 97)
      • UI\Widgets\ThumbnailLoader.py (line 99)
      • UI\Widgets\ThumbnailLoader.py (line 104)
      • UI\Widgets\ThumbnailLoader.py (line 252)
      • UI\Widgets\ThumbnailLoader.py (line 262)
      • UI\Widgets\ThumbnailLoader.py (line 270)
      • UI\Widgets\ThumbnailLoader.py (line 273)
      • UI\Widgets\ThumbnailLoader.py (line 277)
      • UI\Widgets\ThumbnailLoader.py (line 438)
      • Editors\Shared\IntegratedImageEditor.py (line 348)
      • Editors\Shared\IntegratedImageEditor.py (line 352)
      • Editors\Shared\IntegratedImageEditor.py (line 355)
      • Editors\Shared\IntegratedImageEditor.py (line 359)
      • Editors\Shared\IntegratedImageEditor.py (line 362)
      • Editors\Shared\IntegratedImageEditor.py (line 410)
      • Editors\Shared\IntegratedImageEditor.py (line 419)
      • Editors\Shared\IntegratedImageEditor.py (line 426)
      • Editors\Shared\IntegratedImageEditor.py (line 458)
      • Editors\Shared\IntegratedImageEditor.py (line 460)
      • Editors\Shared\IntegratedImageEditor.py (line 467)
      • Editors\Shared\IntegratedImageEditor.py (line 469)
      • Editors\Shared\IntegratedImageEditor.py (line 476)
      • Editors\Shared\IntegratedImageEditor.py (line 479)
      • Editors\Shared\IntegratedImageEditor.py (line 483)
      • Editors\Shared\IntegratedImageEditor.py (line 562)
      • Editors\Shared\IntegratedImageEditor.py (line 580)
      • Editors\Shared\IntegratedImageEditor.py (line 595)
      • Editors\Shared\IntegratedImageEditor.py (line 597)
      • Editors\Shared\IntegratedImageEditor.py (line 639)
      • Editors\Shared\IntegratedImageEditor.py (line 649)
      • Editors\Shared\IntegratedImageEditor.py (line 652)
      • Editors\Shared\IntegratedImageEditor.py (line 656)
      • Editors\Shared\IntegratedImageEditor.py (line 661)
      • Editors\Shared\IntegratedImageEditor.py (line 665)
      • Editors\Shared\IntegratedImageEditor.py (line 692)
      • Editors\Shared\IntegratedImageEditor.py (line 694)
      • Editors\Shared\IntegratedImageEditor.py (line 742)
      • Editors\Shared\IntegratedImageEditor.py (line 744)
      • Editors\Shared\IntegratedImageEditor.py (line 750)
      • Editors\Shared\IntegratedImageEditor.py (line 755)
      • Editors\Shared\IntegratedImageEditor.py (line 760)
      • Editors\Shared\IntegratedImageEditor.py (line 763)
      • Editors\Shared\IntegratedImageEditor.py (line 766)
      • Editors\Shared\IntegratedImageEditor.py (line 772)
      • Editors\Shared\IntegratedImageEditor.py (line 779)
      • Editors\Shared\IntegratedImageEditor.py (line 782)
      • Editors\Shared\IntegratedImageEditor.py (line 787)
      • Editors\Shared\IntegratedImageEditor.py (line 791)
      • Editors\Shared\IntegratedImageEditor.py (line 798)
      • Editors\Shared\IntegratedImageEditor.py (line 804)
      • Editors\Shared\IntegratedImageEditor.py (line 808)
      • Editors\Shared\IntegratedImageEditor.py (line 810)
      • Editors\Shared\IntegratedImageEditor.py (line 812)
      • Editors\Shared\IntegratedImageEditor.py (line 814)
      • Editors\Shared\IntegratedImageEditor.py (line 817)
      • Editors\Shared\IntegratedImageEditor.py (line 826)
      • Editors\Shared\IntegratedImageEditor.py (line 835)
      • Editors\Shared\IntegratedImageEditor.py (line 837)
      • Editors\Shared\IntegratedImageEditor.py (line 972)
      • Editors\Shared\IntegratedImageEditor.py (line 1010)
      • Editors\Shared\IntegratedImageEditor.py (line 1015)
      • Editors\Shared\IntegratedImageEditor.py (line 1017)
      • Editors\Shared\IntegratedImageEditor.py (line 1019)
      • Editors\Shared\IntegratedImageEditor.py (line 1021)
      • Editors\Shared\IntegratedImageEditor.py (line 1023)
      • Editors\Shared\IntegratedImageEditor.py (line 1024)
      • Editors\Shared\IntegratedImageEditor.py (line 1027)
      • Editors\Shared\IntegratedImageEditor.py (line 1036)
      • Editors\Shared\IntegratedImageEditor.py (line 1390)
      • Editors\Shared\IntegratedImageEditor.py (line 1471)
      • Editors\Shared\IntegratedImageEditor.py (line 1472)
      • Editors\Shared\IntegratedImageEditor.py (line 1473)
      • Editors\Shared\IntegratedImageEditor.py (line 1475)
      • Editors\Shared\IntegratedImageEditor.py (line 1476)
      • Editors\Shared\IntegratedImageEditor.py (line 1478)
      • Editors\Shared\IntegratedImageEditor.py (line 1480)
      • Editors\Shared\IntegratedImageEditor.py (line 1481)
      • Editors\Shared\IntegratedImageEditor.py (line 1595)
      • Editors\Shared\IntegratedImageEditor.py (line 1597)
      • Editors\Shared\IntegratedImageEditor.py (line 1600)
      • Editors\Shared\IntegratedImageEditor.py (line 1664)
      • Editors\Shared\IntegratedImageEditor.py (line 1666)
      • Editors\Shared\IntegratedImageEditor.py (line 1683)
      • Editors\Shared\IntegratedImageEditor.py (line 1698)
      • Editors\Shared\IntegratedImageEditor.py (line 1700)
      • Editors\Shared\IntegratedImageEditor.py (line 1711)
      • Editors\Shared\IntegratedImageEditor.py (line 1722)
      • Editors\Shared\IntegratedImageEditor.py (line 1725)
      • Editors\Shared\IntegratedImageEditor.py (line 1730)
      • Editors\Shared\IntegratedImageEditor.py (line 1734)
      • Editors\Shared\IntegratedImageEditor.py (line 1738)
      • Editors\Shared\IntegratedImageEditor.py (line 1741)
      • Editors\Shared\IntegratedImageEditor.py (line 1745)
      • Editors\Shared\IntegratedImageEditor.py (line 1748)
      • Editors\Shared\IntegratedImageEditor.py (line 1752)
      • Editors\ImageEditor\core\ui\main_window.py (line 1125)
      • Editors\ImageEditor\core\ui\main_window.py (line 1127)
      • Editors\ImageEditor\core\ui\main_window.py (line 1199)
      • Editors\ImageEditor\core\ui\main_window.py (line 1203)
      • Editors\ImageEditor\core\ui\main_window.py (line 1207)
      • Editors\ImageEditor\core\ui\main_window.py (line 1211)
      • Editors\ImageEditor\core\ui\main_window.py (line 3096)
      • Editors\ImageEditor\core\ui\main_window.py (line 3100)
      • Editors\ImageEditor\core\ui\main_window.py (line 3117)
      • Editors\ImageEditor\core\ui\main_window.py (line 3119)
      • Editors\ImageEditor\core\ui\main_window.py (line 3125)
      • Editors\ImageEditor\core\ui\main_window.py (line 3134)
      • Editors\ImageEditor\core\ui\main_window.py (line 3137)
      • Editors\ImageEditor\core\ui\main_window.py (line 3139)
      • Editors\ImageEditor\core\ui\main_window.py (line 3141)
      • Editors\ImageEditor\core\ui\main_window.py (line 3166)
      • Editors\ImageEditor\core\ui\main_window.py (line 3167)
      • Editors\ImageEditor\core\ui\main_window.py (line 3168)
      • UI\MainWindow\MainWindow.py (line 642)
      • UI\MainWindow\MainWindow.py (line 722)
      • UI\MainWindow\MainWindow.py (line 724)
      • UI\MainWindow\MainWindow.py (line 1765)
      • UI\MainWindow\MainWindow.py (line 1800)
      • Editors\SpriteEditor\SpriteEditor.py (line 57)
      • Editors\SpriteEditor\SpriteEditor.py (line 87)
      • Editors\SpriteEditor\SpriteEditor.py (line 107)
      • Editors\SpriteEditor\SpriteEditor.py (line 326)
      • Editors\SpriteEditor\SpriteEditor.py (line 329)
      • Editors\SpriteEditor\SpriteEditor.py (line 332)
      • Editors\SpriteEditor\SpriteEditor.py (line 343)
      • Editors\SpriteEditor\SpriteEditor.py (line 422)
      • Editors\SpriteEditor\SpriteEditor.py (line 432)
      • Editors\SpriteEditor\SpriteEditor.py (line 433)
      • Editors\SpriteEditor\SpriteEditor.py (line 447)
      • Editors\SpriteEditor\SpriteEditor.py (line 449)
      • Editors\SpriteEditor\SpriteEditor.py (line 471)
      • Editors\SpriteEditor\SpriteEditor.py (line 476)
      • Editors\SpriteEditor\SpriteEditor.py (line 502)
      • Editors\SpriteEditor\SpriteEditor.py (line 505)
      • Editors\SpriteEditor\SpriteEditor.py (line 604)
      • Editors\SpriteEditor\SpriteEditor.py (line 605)
      • Editors\SpriteEditor\SpriteEditor.py (line 606)
      • Editors\SpriteEditor\SpriteEditor.py (line 636)
      • Editors\SpriteEditor\SpriteEditor.py (line 656)
      • Editors\SpriteEditor\SpriteEditor.py (line 722)
      • Editors\SpriteEditor\SpriteEditor.py (line 755)
      • Editors\SpriteEditor\SpriteEditor.py (line 760)
      • Editors\SpriteEditor\SpriteEditor.py (line 767)
      • Editors\SpriteEditor\SpriteEditor.py (line 808)
      • Editors\SpriteEditor\SpriteEditor.py (line 810)
      • Editors\SpriteEditor\SpriteEditor.py (line 812)
      • Editors\SpriteEditor\SpriteEditor.py (line 818)
      • Editors\SpriteEditor\SpriteEditor.py (line 822)
      • Editors\SpriteEditor\SpriteEditor.py (line 832)
      • Editors\SpriteEditor\SpriteEditor.py (line 833)
      • Editors\SpriteEditor\SpriteEditor.py (line 834)
      • Editors\SpriteEditor\SpriteEditor.py (line 838)
      • Editors\SpriteEditor\SpriteEditor.py (line 868)
      • Editors\SpriteEditor\SpriteEditor.py (line 874)
      • Editors\SpriteEditor\SpriteEditor.py (line 894)
      • Editors\SpriteEditor\SpriteEditor.py (line 896)
      • Editors\SpriteEditor\SpriteEditor.py (line 902)
      • Editors\SpriteEditor\SpriteEditor.py (line 904)
      • Editors\SpriteEditor\SpriteEditor.py (line 938)
      • Editors\SpriteEditor\SpriteEditor.py (line 940)
      • Editors\SpriteEditor\SpriteEditor.py (line 944)
      • Editors\SpriteEditor\SpriteEditor.py (line 954)
      • Editors\SpriteEditor\SpriteEditor.py (line 956)
      • Editors\ModelEditor\ModelEditor.py (line 251)
      • Editors\ModelEditor\ModelEditor.py (line 626)
      • Editors\ModelEditor\ModelEditor.py (line 803)
      • Editors\ModelEditor\ModelEditor.py (line 891)
      • Editors\ModelEditor\ModelEditor.py (line 1194)
      • Editors\ModelEditor\ModelEditor.py (line 1198)
      • Editors\ModelEditor\ModelEditor.py (line 1447)
      • Editors\ModelEditor\ModelEditor.py (line 1451)
      • Editors\ModelEditor\ModelEditor.py (line 1455)
      • Editors\ModelEditor\ModelEditor.py (line 1459)
      • Editors\ModelEditor\ModelEditor.py (line 1463)
      • Editors\ModelEditor\ModelEditor.py (line 1467)
      • Editors\ModelEditor\ModelEditor.py (line 1524)
      • Editors\ModelEditor\ModelEditor.py (line 1539)
      • Editors\ModelEditor\ModelEditor.py (line 1563)
      • Editors\ModelEditor\ModelEditor.py (line 1593)
      • Editors\ModelEditor\ModelEditor.py (line 1596)
      • Editors\ModelEditor\ModelEditor.py (line 1598)
      • Editors\ModelEditor\ModelEditor.py (line 1600)
      • Editors\ModelEditor\ModelEditor.py (line 1780)
      • Editors\ModelEditor\ModelEditor.py (line 1785)
      • Editors\ModelEditor\ModelEditor.py (line 1788)
      • Editors\ModelEditor\ModelEditor.py (line 1794)
      • Editors\ModelEditor\ModelEditor.py (line 1796)
      • Editors\ModelEditor\ModelEditor.py (line 2026)
      • Editors\ModelEditor\ModelEditor.py (line 2101)
      • Editors\ModelEditor\ModelEditor.py (line 2344)
      • Editors\ModelEditor\ModelEditor.py (line 2708)
      • Editors\ModelEditor\ModelEditor.py (line 2752)
      • Editors\ModelEditor\ModelEditor.py (line 2767)
      • Editors\ModelEditor\ModelEditor.py (line 2772)
      • Editors\ModelEditor\ModelEditor.py (line 2778)
      • Editors\ModelEditor\ModelEditor.py (line 2779)
      • Editors\ModelEditor\ModelEditor.py (line 2780)
      • Editors\ModelEditor\ModelEditor.py (line 2788)
      • Editors\ModelEditor\ModelEditor.py (line 2882)
      • Editors\ModelEditor\ModelEditor.py (line 2885)
      • Editors\ModelEditor\ModelEditor.py (line 2890)
      • Editors\ModelEditor\ModelEditor.py (line 2897)
      • Editors\ModelEditor\ModelEditor.py (line 2903)
      • Editors\ModelEditor\ModelEditor.py (line 2906)
      • Editors\ModelEditor\ModelEditor.py (line 2916)
      • Editors\ModelEditor\ModelEditor.py (line 2919)
      • Editors\ModelEditor\ModelEditor.py (line 2920)
      • Editors\ModelEditor\ModelEditor.py (line 2921)
      • Editors\ModelEditor\ModelEditor.py (line 2922)
      • Editors\ModelEditor\ModelEditor.py (line 2923)
      • Editors\ModelEditor\ModelEditor.py (line 2925)
      • Editors\ModelEditor\ModelEditor.py (line 2928)
      • Editors\ModelEditor\ModelEditor.py (line 2931)
      • Editors\ModelEditor\ModelEditor.py (line 2934)
      • Editors\ModelEditor\ModelEditor.py (line 2936)
      • Editors\ModelEditor\ModelEditor.py (line 3039)
      • Editors\ModelEditor\ModelEditor.py (line 3043)
      • Editors\ModelEditor\ModelEditor.py (line 3093)
      • Editors\ModelEditor\ModelEditor.py (line 3106)
      • Editors\ModelEditor\ModelEditor.py (line 3113)
      • Editors\ModelEditor\ModelEditor.py (line 3117)
      • Editors\ModelEditor\ModelEditor.py (line 3151)
      • Editors\ModelEditor\ModelEditor.py (line 3154)
      • Editors\ModelEditor\ModelEditor.py (line 3171)
      • Editors\ModelEditor\ModelEditor.py (line 3182)
      • Editors\ModelEditor\ModelEditor.py (line 3184)
      • Editors\ModelEditor\ModelEditor.py (line 3190)
      • Editors\ModelEditor\ModelEditor.py (line 3195)
      • Editors\ModelEditor\ModelEditor.py (line 3202)
      • Editors\ModelEditor\ModelEditor.py (line 3226)
      • Editors\ModelEditor\ModelEditor.py (line 3236)
      • Editors\ModelEditor\ModelEditor.py (line 3259)
      • Editors\ModelEditor\ModelEditor.py (line 3265)
      • Editors\ModelEditor\ModelEditor.py (line 3274)
      • Editors\ModelEditor\ModelEditor.py (line 3282)
      • Editors\ModelEditor\ModelEditor.py (line 3288)
      • Editors\ModelEditor\ModelEditor.py (line 3293)
      • Editors\ModelEditor\ModelEditor.py (line 3307)
      • Editors\ModelEditor\ModelEditor.py (line 3320)
      • Editors\ModelEditor\ModelEditor.py (line 3326)
      • Editors\ModelEditor\ModelEditor.py (line 3328)
      • Editors\ModelEditor\ModelEditor.py (line 3335)
      • Editors\ModelEditor\ModelEditor.py (line 3342)
      • Editors\ModelEditor\ModelEditor.py (line 3347)
      • Editors\ModelEditor\ModelEditor.py (line 3354)
      • Editors\ModelEditor\ModelEditor.py (line 3388)
      • Editors\ModelEditor\ModelEditor.py (line 3405)
      • Editors\ModelEditor\ModelEditor.py (line 3410)
      • Editors\ModelEditor\ModelEditor.py (line 3414)
      • Editors\ModelEditor\ModelEditor.py (line 3416)
      • Editors\ModelEditor\ModelEditor.py (line 3421)
      • Editors\ModelEditor\ModelEditor.py (line 3423)
      • Editors\ModelEditor\ModelEditor.py (line 3425)
      • Editors\ModelEditor\ModelEditor.py (line 3428)
      • Editors\ModelEditor\ModelEditor.py (line 3429)
      • Editors\ModelEditor\ModelEditor.py (line 3455)
      • Editors\ModelEditor\ModelEditor.py (line 3458)
      • Editors\ModelEditor\ModelEditor.py (line 3461)
      • Editors\ModelEditor\ModelEditor.py (line 3467)
      • Editors\ModelEditor\ModelEditor.py (line 3470)
      • Editors\ModelEditor\ModelEditor.py (line 3477)
      • Editors\ModelEditor\ModelEditor.py (line 3483)
      • Editors\ModelEditor\ModelEditor.py (line 3487)
      • Editors\ModelEditor\ModelEditor.py (line 3521)
      • Editors\ModelEditor\ModelEditor.py (line 3529)
      • Editors\ModelEditor\ModelEditor.py (line 3533)
      • Editors\ModelEditor\ModelEditor.py (line 3537)
      • Editors\ModelEditor\ModelEditor.py (line 3570)
      • Editors\ModelEditor\ModelEditor.py (line 3572)
      • Editors\ModelEditor\ModelEditor.py (line 3575)
      • Editors\ModelEditor\ModelEditor.py (line 3577)
      • Editors\ModelEditor\ModelEditor.py (line 3585)
      • Editors\ModelEditor\ModelEditor.py (line 3590)
      • Editors\ModelEditor\ModelEditor.py (line 3627)
      • Editors\ModelEditor\ModelEditor.py (line 3631)
      • Editors\ModelEditor\ModelEditor.py (line 3644)
      • Editors\ModelEditor\ModelEditor.py (line 3656)
      • Editors\ModelEditor\ModelEditor.py (line 3696)
      • Editors\ModelEditor\ModelEditor.py (line 3699)
      • Editors\ModelEditor\ModelEditor.py (line 3724)
      • Editors\ModelEditor\ModelEditor.py (line 3737)
      • Editors\ModelEditor\ModelEditor.py (line 3755)
      • Editors\ModelEditor\ModelEditor.py (line 3757)
      • Editors\ModelEditor\ModelEditor.py (line 3774)
      • Editors\ModelEditor\ModelEditor.py (line 3791)
      • Editors\ModelEditor\ModelEditor.py (line 3834)
      • Editors\ModelEditor\ModelEditor.py (line 3855)
      • Editors\ModelEditor\ModelEditor.py (line 3860)
      • Editors\ModelEditor\ModelEditor.py (line 3872)
      • Editors\ModelEditor\ModelEditor.py (line 3875)
      • Editors\ModelEditor\ModelEditor.py (line 3881)
      • Editors\ModelEditor\ModelEditor.py (line 3911)
      • Editors\ModelEditor\ModelEditor.py (line 3912)
      • Editors\ModelEditor\ModelEditor.py (line 3913)
      • Editors\ModelEditor\ModelEditor.py (line 3925)
      • Editors\ModelEditor\ModelEditor.py (line 3927)
      • Editors\ModelEditor\ModelEditor.py (line 3929)
      • Editors\ModelEditor\ModelEditor.py (line 3931)
      • Editors\ModelEditor\ModelEditor.py (line 3933)
      • Editors\ModelEditor\ModelEditor.py (line 3958)
      • Editors\ModelEditor\ModelEditor.py (line 3975)
      • Editors\ModelEditor\ModelEditor.py (line 3992)
      • Editors\ModelEditor\ModelEditor.py (line 4035)
      • Editors\ModelEditor\ModelEditor.py (line 4082)
      • Editors\ModelEditor\ModelEditor.py (line 4086)
      • Editors\ModelEditor\ModelEditor.py (line 4088)
      • Editors\ModelEditor\ModelEditor.py (line 4107)
      • Editors\ModelEditor\ModelEditor.py (line 4130)
      • Editors\ModelEditor\ModelEditor.py (line 4153)
      • Editors\ModelEditor\ModelEditor.py (line 4158)
      • Editors\ModelEditor\ModelEditor.py (line 4159)
      • Editors\ModelEditor\ModelEditor.py (line 4166)
      • Editors\ModelEditor\ModelEditor.py (line 4187)
      • Editors\ModelEditor\ModelEditor.py (line 4208)
      • Editors\ModelEditor\ModelEditor.py (line 4220)
      • Editors\ModelEditor\ModelEditor.py (line 4236)
      • Editors\ModelEditor\ModelEditor.py (line 4248)
      • Editors\ModelEditor\ModelEditor.py (line 4251)
      • Editors\ModelEditor\ModelEditor.py (line 4260)
      • Editors\ModelEditor\ModelEditor.py (line 4275)
      • Editors\ModelEditor\ModelEditor.py (line 4297)
      • Editors\ModelEditor\ModelEditor.py (line 4322)
      • Editors\ModelEditor\ModelEditor.py (line 4324)
      • Editors\ModelEditor\ModelEditor.py (line 4342)
      • Editors\ModelEditor\ModelEditor.py (line 4363)
      • Editors\ModelEditor\ModelEditor.py (line 4365)
      • Editors\ModelEditor\ModelEditor.py (line 4369)
      • Editors\ModelEditor\ModelEditor.py (line 4385)
      • Editors\ModelEditor\ModelEditor.py (line 4402)
      • Editors\ModelEditor\ModelEditor.py (line 4422)
      • Editors\ModelEditor\ModelEditor.py (line 4430)
      • Editors\ModelEditor\ModelEditor.py (line 4431)
      • Editors\ModelEditor\ModelEditor.py (line 4482)
      • Editors\ModelEditor\ModelEditor.py (line 4489)
      • Editors\ModelEditor\ModelEditor.py (line 4554)
      • Editors\ModelEditor\ModelEditor.py (line 4582)
      • Editors\ModelEditor\ModelEditor.py (line 4592)
      • Editors\ModelEditor\ModelEditor.py (line 4612)
      • Editors\ModelEditor\ModelEditor.py (line 4637)
      • Editors\ModelEditor\ModelEditor.py (line 4643)
      • Editors\ModelEditor\ModelEditor.py (line 4649)
      • Editors\ModelEditor\ModelEditor.py (line 4658)
      • Editors\ModelEditor\ModelEditor.py (line 4660)
      • Editors\ModelEditor\ModelEditor.py (line 4671)
      • Editors\ModelEditor\ModelEditor.py (line 4677)
      • Editors\ModelEditor\ModelEditor.py (line 4714)
      • Editors\ModelEditor\ModelEditor.py (line 4784)
      • Editors\ModelEditor\ModelEditor.py (line 4813)
      • Editors\ModelEditor\ModelEditor.py (line 4834)
      • Editors\ModelEditor\ModelEditor.py (line 4836)
      • Editors\ModelEditor\ModelEditor.py (line 4840)
      • Editors\ModelEditor\ModelEditor.py (line 4934)
      • Editors\ModelEditor\ModelEditor.py (line 5039)
      • Editors\ModelEditor\ModelEditor.py (line 5042)
      • Editors\ModelEditor\ModelEditor.py (line 5105)
      • Editors\ModelEditor\ModelEditor.py (line 5108)
      • Editors\ModelEditor\ModelEditor.py (line 5183)
      • Editors\ModelEditor\ModelEditor.py (line 5263)
      • Editors\ModelEditor\ModelEditor.py (line 5266)
      • Editors\ModelEditor\ModelEditor.py (line 5297)
      • Editors\ModelEditor\ModelEditor.py (line 5298)
      • Editors\ModelEditor\ModelEditor.py (line 5351)
      • Editors\ModelEditor\ModelEditor.py (line 5408)
      • Editors\ModelEditor\ModelEditor.py (line 5424)
      • Editors\ModelEditor\ModelEditor.py (line 5426)
      • Editors\ModelEditor\ModelEditor.py (line 5430)
      • Editors\ModelEditor\ModelEditor.py (line 5452)
      • Editors\ModelEditor\ModelEditor.py (line 5470)
      • Editors\ModelEditor\ModelEditor.py (line 5472)
      • Editors\ModelEditor\ModelEditor.py (line 5477)
      • Editors\ModelEditor\ModelEditor.py (line 5498)
      • Editors\ModelEditor\ModelEditor.py (line 5512)
      • Editors\ModelEditor\ModelEditor.py (line 5527)
      • Editors\ModelEditor\ModelEditor.py (line 5544)
      • Editors\ModelEditor\ModelEditor.py (line 5557)
      • Editors\ModelEditor\ModelEditor.py (line 5560)
      • Editors\ModelEditor\ModelEditor.py (line 5569)
      • Editors\ModelEditor\ModelEditor.py (line 5572)
      • Editors\ModelEditor\ModelEditor.py (line 5594)
      • Editors\ModelEditor\ModelEditor.py (line 5633)
      • Editors\ModelEditor\ModelEditor.py (line 5656)
      • Editors\ModelEditor\ModelEditor.py (line 5666)
      • Editors\ModelEditor\ModelEditor.py (line 5669)
      • Editors\ModelEditor\ModelEditor.py (line 5696)
      • Editors\ModelEditor\ModelEditor.py (line 5746)
      • Editors\ModelEditor\ModelEditor.py (line 5833)
      • Editors\ModelEditor\ModelEditor.py (line 5907)
      • Editors\ModelEditor\ModelEditor.py (line 6035)
      • Editors\ModelEditor\ModelEditor.py (line 6048)
      • Editors\ModelEditor\ModelEditor.py (line 6075)
      • Editors\ModelEditor\ModelEditor.py (line 6081)
      • Editors\ModelEditor\ModelEditor.py (line 6195)
      • Editors\ModelEditor\ModelEditor.py (line 6196)
      • Editors\ModelEditor\ModelEditor.py (line 6197)
      • Editors\ModelEditor\ModelEditor.py (line 6198)
      • Editors\ModelEditor\ModelEditor.py (line 6199)
      • Editors\ModelEditor\ModelEditor.py (line 6218)
      • Editors\ModelEditor\ModelEditor.py (line 6221)
      • Editors\ModelEditor\ModelEditor.py (line 6227)
      • Editors\ModelEditor\ModelEditor.py (line 6228)
      • Editors\ModelEditor\ModelEditor.py (line 6229)
      • Editors\ModelEditor\ModelEditor.py (line 6230)
      • Editors\ModelEditor\ModelEditor.py (line 6231)
      • Editors\ModelEditor\ModelEditor.py (line 6233)
      • Editors\ModelEditor\ModelEditor.py (line 6234)
      • Editors\ModelEditor\ModelEditor.py (line 6235)
      • Editors\ModelEditor\ModelEditor.py (line 6236)
      • Editors\ModelEditor\ModelEditor.py (line 6237)
      • Editors\ModelEditor\ModelEditor.py (line 6238)
      • Editors\ModelEditor\ModelEditor.py (line 6290)
      • Editors\ModelEditor\ModelEditor.py (line 6339)
      • Editors\ModelEditor\ModelEditor.py (line 6359)
      • Editors\ModelEditor\ModelEditor.py (line 6360)
      • Editors\ModelEditor\ModelEditor.py (line 6361)
      • Editors\ModelEditor\ModelEditor.py (line 6362)
      • Editors\ModelEditor\ModelEditor.py (line 8263)
      • Editors\ModelEditor\ModelEditor.py (line 8321)
      • Editors\ModelEditor\ModelEditor.py (line 8630)
      • Editors\ModelEditor\ModelEditor.py (line 8903)
      • Editors\ModelEditor\ModelEditor.py (line 8905)
      • Editors\ModelEditor\ModelEditor.py (line 8914)
      • Editors\ModelEditor\ModelEditor.py (line 8915)
      • Editors\ModelEditor\ModelEditor.py (line 8917)
      • Editors\ModelEditor\ModelEditor.py (line 8918)
      • Editors\ModelEditor\ModelEditor.py (line 8920)
      • Editors\ModelEditor\ModelEditor.py (line 9015)
      • Editors\ModelEditor\ModelEditor.py (line 9248)
      • Editors\ModelEditor\ModelEditor.py (line 9279)
      • Editors\ModelEditor\ModelEditor.py (line 9283)
      • Editors\ModelEditor\ModelEditor.py (line 9286)
      • Editors\ModelEditor\ModelEditor.py (line 9316)
      • Editors\ModelEditor\ModelEditor.py (line 9340)
      • Editors\ModelEditor\ModelEditor.py (line 9342)
      • Editors\ModelEditor\ModelEditor.py (line 9345)
      • Editors\ModelEditor\ModelEditor.py (line 10243)
      • Editors\ModelEditor\ModelEditor.py (line 10279)
      • Editors\ModelEditor\ModelEditor.py (line 10284)
      • Editors\ModelEditor\ModelEditor.py (line 10297)
      • Editors\ModelEditor\ModelEditor.py (line 10303)
      • Editors\ModelEditor\ModelEditor.py (line 10316)
      • Editors\ModelEditor\ModelEditor.py (line 10349)
      • Editors\ModelEditor\ModelEditor.py (line 10358)
      • Editors\ModelEditor\ModelEditor.py (line 10363)
      • Editors\ModelEditor\ModelEditor.py (line 10564)
      • Editors\ModelEditor\ModelEditor.py (line 10626)
      • Editors\ModelEditor\ModelEditor.py (line 10635)
      • Editors\ModelEditor\ModelEditor.py (line 10645)
      • Editors\ModelEditor\ModelEditor.py (line 10647)
      • Editors\ModelEditor\ModelEditor.py (line 10667)
      • Editors\ModelEditor\ModelEditor.py (line 10669)
      • Editors\ModelEditor\ModelEditor.py (line 10672)
      • Editors\ModelEditor\ModelEditor.py (line 10676)
      • Editors\ModelEditor\ModelEditor.py (line 10693)
      • Editors\ModelEditor\ModelEditor.py (line 10702)
      • Editors\ModelEditor\ModelEditor.py (line 10711)
      • Editors\ModelEditor\ModelEditor.py (line 10715)
      • Editors\ModelEditor\ModelEditor.py (line 10735)
      • Editors\ModelEditor\ModelEditor.py (line 10736)
      • Editors\ModelEditor\ModelEditor.py (line 10738)
      • Editors\ModelEditor\ModelEditor.py (line 10770)
      • Editors\ModelEditor\ModelEditor.py (line 10781)
      • Editors\ModelEditor\ModelEditor.py (line 10783)
      • Editors\ModelEditor\ModelEditor.py (line 10790)
      • Editors\ModelEditor\ModelEditor.py (line 10791)
      • Editors\ModelEditor\ModelEditor.py (line 10792)
      • Editors\ModelEditor\ModelEditor.py (line 10800)
      • Editors\ModelEditor\ModelEditor.py (line 10808)
      • Editors\ModelEditor\ModelEditor.py (line 10812)
      • Editors\ModelEditor\ModelEditor.py (line 10827)
      • Editors\ModelEditor\ModelEditor.py (line 10831)
      • Editors\ModelEditor\ModelEditor.py (line 10832)
      • Editors\ModelEditor\ModelEditor.py (line 10833)
      • Editors\ModelEditor\ModelEditor.py (line 10835)
      • Editors\ModelEditor\ModelEditor.py (line 10836)
      • Editors\ModelEditor\ModelEditor.py (line 10840)
      • Editors\ModelEditor\ModelEditor.py (line 10841)
      • Editors\ModelEditor\ModelEditor.py (line 10842)
      • Editors\ModelEditor\ModelEditor.py (line 10843)
      • Editors\ModelEditor\ModelEditor.py (line 10849)
      • Editors\ModelEditor\ModelEditor.py (line 10871)
      • Editors\ModelEditor\ModelEditor.py (line 10874)
      • Editors\ModelEditor\ModelEditor.py (line 10879)
      • Editors\ModelEditor\ModelEditor.py (line 10881)
      • Editors\ModelEditor\ModelEditor.py (line 10886)
      • Editors\ModelEditor\ModelEditor.py (line 11180)
      • Editors\ModelEditor\ModelEditor.py (line 11327)
      • Editors\ModelEditor\ModelEditor.py (line 11353)
      • Editors\ModelEditor\ModelEditor.py (line 11370)
      • Editors\ModelEditor\ModelEditor.py (line 11380)
      • Editors\ModelEditor\ModelEditor.py (line 11520)
      • Editors\ModelEditor\ModelEditor.py (line 11544)
      • Editors\ModelEditor\ModelEditor.py (line 11579)
      • Editors\ModelEditor\ModelEditor.py (line 11675)
      • Editors\ModelEditor\ModelEditor.py (line 11708)
      • Editors\ModelEditor\ModelEditor.py (line 11724)
      • Editors\ModelEditor\ModelEditor.py (line 11771)
      • Editors\ModelEditor\ModelEditor.py (line 11962)
      • Editors\ModelEditor\ModelEditor.py (line 11971)
      • Editors\ModelEditor\ModelEditor.py (line 12005)
      • Editors\ModelEditor\ModelEditor.py (line 12014)
      • Editors\ModelEditor\ModelEditor.py (line 12031)

🏗️ debug_critical
   📄 Core\Debug.py (line 65)
   📞 Called by:
      • Editors\ObjectEditor\object_editor.py (line 409)
      • main.py (line 29)
      • main.py (line 43)
      • main.py (line 58)
      • main.py (line 75)
      • main.py (line 81)
      • main.py (line 113)
      • main.py (line 118)
      • main.py (line 141)
      • main.py (line 150)
      • main.py (line 161)
      • main.py (line 173)
      • main.py (line 176)
      • main.py (line 177)
      • main.py (line 180)
      • main.py (line 184)
      • main.py (line 186)
      • main.py (line 203)
      • main.py (line 207)
      • main.py (line 209)
      • main.py (line 211)
      • main.py (line 212)
      • main.py (line 214)
      • main.py (line 215)
      • main.py (line 219)
      • main.py (line 221)
      • main.py (line 225)
      • main.py (line 227)
      • main.py (line 229)
      • main.py (line 231)
      • main.py (line 250)
      • main.py (line 277)
      • main.py (line 283)
      • main.py (line 294)
      • main.py (line 297)
      • main.py (line 299)
      • main.py (line 304)
      • main.py (line 313)
      • main.py (line 318)
      • main.py (line 329)
      • main.py (line 384)
      • main.py (line 416)
      • main.py (line 419)
      • main.py (line 422)
      • main.py (line 423)
      • main.py (line 426)
      • main.py (line 427)
      • main.py (line 431)
      • main.py (line 433)
      • main.py (line 434)
      • main.py (line 435)
      • main.py (line 436)
      • main.py (line 455)
      • main.py (line 456)
      • main.py (line 474)
      • main.py (line 477)
      • main.py (line 539)
      • main.py (line 541)
      • main.py (line 543)
      • main.py (line 545)
      • main.py (line 547)
      • main.py (line 561)
      • main.py (line 563)
      • main.py (line 586)
      • main.py (line 588)

🏗️ init_debug
   📄 Core\Debug.py (line 73)
   📞 Called by:
      • UI\CommonDialogs\PreferencesDialog.py (line 2495)
      • main.py (line 518)

🏗️ attach_tooltip
   📄 Editors\ImageEditor\core\ui\tooltips.py (line 14)
   📞 Called by:
      • Editors\ImageEditor\core\ui\panels\right_panel.py (line 289)
      • Editors\ImageEditor\core\ui\panels\right_panel.py (line 349)
      • Editors\ImageEditor\core\ui\panels\right_panel.py (line 350)
      • Editors\ImageEditor\core\ui\panels\right_panel.py (line 351)
      • Editors\ImageEditor\core\ui\panels\right_panel.py (line 352)
      • Editors\ImageEditor\core\ui\panels\right_panel.py (line 353)
      • Editors\ImageEditor\core\ui\panels\right_panel.py (line 354)
      • Editors\ImageEditor\core\ui\panels\left_panel.py (line 258)
      • Editors\ImageEditor\core\ui\panels\left_panel.py (line 281)
      • Editors\ImageEditor\core\ui\panels\left_panel.py (line 304)
      • Editors\ImageEditor\core\ui\panels\left_panel.py (line 313)
      • Editors\ImageEditor\core\ui\panels\left_panel.py (line 332)
      • Editors\ImageEditor\core\ui\panels\left_panel.py (line 348)
      • Editors\ImageEditor\core\ui\panels\left_panel.py (line 349)
      • Editors\ImageEditor\core\ui\panels\left_panel.py (line 414)
      • Editors\ImageEditor\core\ui\panels\left_panel.py (line 427)
      • Editors\ImageEditor\core\ui\panels\left_panel.py (line 430)
      • Editors\ImageEditor\core\ui\panels\left_panel.py (line 513)
      • Editors\ImageEditor\core\ui\panels\left_panel.py (line 518)
      • Editors\ImageEditor\core\ui\panels\left_panel.py (line 535)
      • Editors\ImageEditor\core\ui\panels\left_panel.py (line 640)

🏗️ show_tooltip
   📄 Editors\ImageEditor\core\ui\tooltips.py (line 15)
   ⚠️  Never called

🏗️ hide_tooltip
   📄 Editors\ImageEditor\core\ui\tooltips.py (line 24)
   ⚠️  Never called

🏗️ _build_ui
   📄 Core\AI\PyGenesisAssistant\Nova\ui\tasks_dialog.py (line 179)
   ⚠️  Never called

🏗️ _format_metadata
   📄 Core\AI\PyGenesisAssistant\Nova\ui\tasks_dialog.py (line 122)
   ⚠️  Never called

🏗️ _set_filter
   📄 Core\AI\PyGenesisAssistant\Nova\ui\tasks_dialog.py (line 234)
   ⚠️  Never called

🏗️ _refresh_tasks
   📄 Core\AI\PyGenesisAssistant\Nova\ui\tasks_dialog.py (line 246)
   ⚠️  Never called

🏗️ _on_start_task
   📄 Core\AI\PyGenesisAssistant\Nova\ui\tasks_dialog.py (line 270)
   ⚠️  Never called

🏗️ _on_delete_task
   📄 Core\AI\PyGenesisAssistant\Nova\ui\tasks_dialog.py (line 275)
   ⚠️  Never called

🏗️ _on_move_up
   📄 Core\AI\PyGenesisAssistant\Nova\ui\tasks_dialog.py (line 280)
   ⚠️  Never called

🏗️ _on_move_down
   📄 Core\AI\PyGenesisAssistant\Nova\ui\tasks_dialog.py (line 304)
   ⚠️  Never called

🏗️ toggle
   📄 Core\AI\PyGenesisAssistant\CodeAnalyser.py (line 46)
   ⚠️  Never called

🏗️ set_title
   📄 Core\AI\PyGenesisAssistant\CodeAnalyser.py (line 54)
   📞 Called by:
      • Core\AI\PyGenesisAssistant\CodeAnalyser.py (line 523)
      • Core\AI\PyGenesisAssistant\CodeAnalyser.py (line 524)
      • Core\AI\PyGenesisAssistant\CodeAnalyser.py (line 525)
      • Core\AI\PyGenesisAssistant\CodeAnalyser.py (line 854)
      • Core\AI\PyGenesisAssistant\CodeAnalyser.py (line 855)
      • Core\AI\PyGenesisAssistant\CodeAnalyser.py (line 856)

🏗️ create_widgets
   📄 Core\AI\PyGenesisAssistant\CodeAnalyser.py (line 74)
   ⚠️  Never called

🏗️ create_summary_tab
   📄 Core\AI\PyGenesisAssistant\CodeAnalyser.py (line 228)
   ⚠️  Never called

🏗️ create_detailed_tab
   📄 Core\AI\PyGenesisAssistant\CodeAnalyser.py (line 250)
   ⚠️  Never called

🏗️ browse_folder
   📄 Core\AI\PyGenesisAssistant\CodeAnalyser.py (line 299)
   ⚠️  Never called

🏗️ refresh_files
   📄 Core\AI\PyGenesisAssistant\CodeAnalyser.py (line 306)
   ⚠️  Never called

🏗️ select_all_files
   📄 Core\AI\PyGenesisAssistant\CodeAnalyser.py (line 342)
   ⚠️  Never called

🏗️ select_no_files
   📄 Core\AI\PyGenesisAssistant\CodeAnalyser.py (line 346)
   ⚠️  Never called

🏗️ start_analysis
   📄 Core\AI\PyGenesisAssistant\CodeAnalyser.py (line 350)
   ⚠️  Never called

🏗️ run_analysis
   📄 Core\AI\PyGenesisAssistant\CodeAnalyser.py (line 370)
   ⚠️  Never called

🏗️ update_progress
   📄 Core\AI\PyGenesisAssistant\CodeAnalyser.py (line 403)
   ⚠️  Never called

🏗️ analysis_complete
   📄 Core\AI\PyGenesisAssistant\CodeAnalyser.py (line 407)
   ⚠️  Never called

🏗️ analysis_error
   📄 Core\AI\PyGenesisAssistant\CodeAnalyser.py (line 417)
   ⚠️  Never called

🏗️ display_results
   📄 Core\AI\PyGenesisAssistant\CodeAnalyser.py (line 425)
   ⚠️  Never called

🏗️ display_summary
   📄 Core\AI\PyGenesisAssistant\CodeAnalyser.py (line 436)
   ⚠️  Never called

🏗️ _display_grouped_summary
   📄 Core\AI\PyGenesisAssistant\CodeAnalyser.py (line 459)
   ⚠️  Never called

🏗️ _display_basic_summary
   📄 Core\AI\PyGenesisAssistant\CodeAnalyser.py (line 507)
   ⚠️  Never called

🏗️ display_detailed_results
   📄 Core\AI\PyGenesisAssistant\CodeAnalyser.py (line 520)
   ⚠️  Never called

🏗️ _display_detailed_errors
   📄 Core\AI\PyGenesisAssistant\CodeAnalyser.py (line 547)
   ⚠️  Never called

🏗️ _display_detailed_warnings
   📄 Core\AI\PyGenesisAssistant\CodeAnalyser.py (line 576)
   ⚠️  Never called

🏗️ _insert_collapsible_file_section
   📄 Core\AI\PyGenesisAssistant\CodeAnalyser.py (line 603)
   ⚠️  Never called

🏗️ _toggle_file_section
   📄 Core\AI\PyGenesisAssistant\CodeAnalyser.py (line 645)
   ⚠️  Never called

🏗️ _hide_file_content
   📄 Core\AI\PyGenesisAssistant\CodeAnalyser.py (line 680)
   ⚠️  Never called

🏗️ _show_file_content
   📄 Core\AI\PyGenesisAssistant\CodeAnalyser.py (line 710)
   ⚠️  Never called

🏗️ _adjust_text_index
   📄 Core\AI\PyGenesisAssistant\CodeAnalyser.py (line 743)
   ⚠️  Never called

🏗️ _display_import_analysis
   📄 Core\AI\PyGenesisAssistant\CodeAnalyser.py (line 752)
   ⚠️  Never called

🏗️ save_summary
   📄 Core\AI\PyGenesisAssistant\CodeAnalyser.py (line 808)
   ⚠️  Never called

🏗️ copy_summary
   📄 Core\AI\PyGenesisAssistant\CodeAnalyser.py (line 828)
   ⚠️  Never called

🏗️ clear_results
   📄 Core\AI\PyGenesisAssistant\CodeAnalyser.py (line 841)
   ⚠️  Never called

🏗️ save_report
   📄 Core\AI\PyGenesisAssistant\CodeAnalyser.py (line 858)
   ⚠️  Never called

🏗️ export_json
   📄 Core\AI\PyGenesisAssistant\CodeAnalyser.py (line 898)
   ⚠️  Never called

🏗️ analyze
   📄 Core\AI\PyGenesisAssistant\CodeAnalyser.py (line 972)
   📞 Called by:
      • Core\AI\PyGenesisAssistant\DependencyAnalyser.py (line 299)

🏗️ _update_progress
   📄 Core\AI\PyGenesisAssistant\CodeAnalyser.py (line 994)
   ⚠️  Never called

🏗️ _parse_all_files
   📄 Core\AI\PyGenesisAssistant\CodeAnalyser.py (line 999)
   ⚠️  Never called

🏗️ _extract_definitions
   📄 Core\AI\PyGenesisAssistant\CodeAnalyser.py (line 1017)
   ⚠️  Never called

🏗️ _extract_imports
   📄 Core\AI\PyGenesisAssistant\CodeAnalyser.py (line 1037)
   ⚠️  Never called

🏗️ _analyze_imports
   📄 Core\AI\PyGenesisAssistant\CodeAnalyser.py (line 1064)
   ⚠️  Never called

🏗️ _analyze_files
   📄 Core\AI\PyGenesisAssistant\CodeAnalyser.py (line 1082)
   ⚠️  Never called

🏗️ _analyze_file
   📄 Core\AI\PyGenesisAssistant\CodeAnalyser.py (line 1097)
   ⚠️  Never called

🏗️ _check_name_usage
   📄 Core\AI\PyGenesisAssistant\CodeAnalyser.py (line 1110)
   ⚠️  Never called

🏗️ _check_attribute_usage
   📄 Core\AI\PyGenesisAssistant\CodeAnalyser.py (line 1157)
   ⚠️  Never called

🏗️ _group_issues
   📄 Core\AI\PyGenesisAssistant\CodeAnalyser.py (line 1182)
   ⚠️  Never called

🏗️ _module_exists
   📄 Core\AI\PyGenesisAssistant\CodeAnalyser.py (line 1242)
   ⚠️  Never called

🏗️ _is_local_module
   📄 Core\AI\PyGenesisAssistant\CodeAnalyser.py (line 1250)
   ⚠️  Never called

🏗️ _module_has_attribute
   📄 Core\AI\PyGenesisAssistant\CodeAnalyser.py (line 1259)
   ⚠️  Never called

🏗️ main
   📄 Core\AI\PyGenesisAssistant\CodeAnalyser.py (line 1268)
   📞 Called by:
      • Core\AI\PyGenesisAssistant\CodeAnalyser.py (line 1281)
      • Core\AI\PyGenesisAssistant\DependencyAnalyser.py (line 937)
      • Core\AI\PyGenesisAssistant\Nova\core\slm\train_model.py (line 322)
      • Core\AI\PyGenesisAssistant\Nova\core\slm\generate_training_data.py (line 161)
      • Editors\ImageEditor\core\core\ai_test_app.py (line 785)
      • check_dependencies.py (line 82)
      • Core\AI\PyGenesisAssistant\UnifiedCodeAnalyzer.py (line 1230)
      • Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 3404)
      • Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 3406)
      • GenerateSummary.py (line 300)
      • main.py (line 592)
      • Editors\ModelEditor\ModelEditor.py (line 12072)

🏗️ scan_project
   📄 Core\AI\PyGenesisAssistant\Nova\core\project_scanner.py (line 27)
   📞 Called by:
      • Core\AI\PyGenesisAssistant\Nova\core\workflow.py (line 468)
      • Core\AI\PyGenesisAssistant\Nova\core\workflow.py (line 491)
      • Core\AI\PyGenesisAssistant\Nova\core\async_scanner.py (line 32)
      • Core\AI\PyGenesisAssistant\Nova\core\intent_router.py (line 584)
      • Core\AI\PyGenesisAssistant\Nova\core\intent_router.py (line 742)

🏗️ find_class
   📄 Core\AI\PyGenesisAssistant\Nova\core\project_scanner.py (line 50)
   ⚠️  Never called

🏗️ find_function
   📄 Core\AI\PyGenesisAssistant\Nova\core\project_scanner.py (line 70)
   ⚠️  Never called

🏗️ get_file_analysis
   📄 Core\AI\PyGenesisAssistant\Nova\core\project_scanner.py (line 90)
   ⚠️  Never called

🏗️ get_dependencies
   📄 Core\AI\PyGenesisAssistant\Nova\core\project_scanner.py (line 111)
   ⚠️  Never called

🏗️ get_class_methods
   📄 Core\AI\PyGenesisAssistant\Nova\core\project_scanner.py (line 136)
   ⚠️  Never called

🏗️ get_statistics
   📄 Core\AI\PyGenesisAssistant\Nova\core\project_scanner.py (line 183)
   ⚠️  Never called

🏗️ setup_ui
   📄 Core\Code\Unified\unified_code_editor.py (line 40)
   ⚠️  Never called

🏗️ _toggle_collapse
   📄 Core\Code\Unified\unified_code_editor.py (line 89)
   ⚠️  Never called

🏗️ set_diagnostics
   📄 Core\Code\Unified\unified_code_editor.py (line 615)
   📞 Called by:
      • Core\Code\Unified\unified_code_editor.py (line 601)
      • Core\Code\Unified\unified_code_editor.py (line 625)
      • Core\Code\Unified\unified_code_editor.py (line 635)

🏗️ setup_highlighting
   📄 Core\Code\Unified\unified_code_editor.py (line 141)
   ⚠️  Never called

🏗️ highlightBlock
   📄 Core\Code\Unified\unified_code_editor.py (line 169)
   ⚠️  Never called

🏗️ _get_advanced_mode_setting
   📄 Core\Code\Unified\unified_code_editor.py (line 266)
   ⚠️  Never called

🏗️ _build_toolbar
   📄 Core\Code\Unified\unified_code_editor.py (line 310)
   ⚠️  Never called

🏗️ _update_mode_ui
   📄 Core\Code\Unified\unified_code_editor.py (line 363)
   ⚠️  Never called

🏗️ _update_highlighter_initial
   📄 Core\Code\Unified\unified_code_editor.py (line 369)
   ⚠️  Never called

🏗️ _detect_code_mode
   📄 Core\Code\Unified\unified_code_editor.py (line 394)
   📞 Called by:
      • Editors\ObjectEditor\UI\code_editor_widget.py (line 202)
      • Editors\ObjectEditor\UI\code_editor_widget.py (line 275)

🏗️ _update_highlighter
   📄 Core\Code\Unified\unified_code_editor.py (line 468)
   ⚠️  Never called

🏗️ _on_text_changed
   📄 Core\Code\Unified\unified_code_editor.py (line 532)
   ⚠️  Never called

🏗️ _update_highlighter_debounced
   📄 Core\Code\Unified\unified_code_editor.py (line 551)
   ⚠️  Never called

🏗️ get_code
   📄 Core\Code\Unified\unified_code_editor.py (line 560)
   📞 Called by:
      • Core\Code\Unified\test_harness.py (line 104)
      • Editors\CodeEditor\ScriptEditor.py (line 112)
      • Editors\ObjectEditor\object_editor.py (line 400)
      • Editors\ObjectEditor\object_editor.py (line 432)
      • Editors\ObjectEditor\UI\code_editor_widget.py (line 145)

🏗️ set_code
   📄 Core\Code\Unified\unified_code_editor.py (line 564)
   📞 Called by:
      • Core\Code\Unified\test_harness.py (line 137)
      • Core\Code\Unified\test_harness.py (line 147)
      • Core\Code\Unified\test_harness.py (line 159)
      • Editors\CodeEditor\ScriptEditor.py (line 90)
      • Editors\ObjectEditor\object_editor.py (line 302)
      • Editors\ObjectEditor\UI\code_editor_widget.py (line 141)
      • Editors\ObjectEditor\UI\code_editor_widget.py (line 149)

🏗️ get_selected_code
   📄 Core\Code\Unified\unified_code_editor.py (line 579)
   📞 Called by:
      • Editors\ObjectEditor\UI\code_editor_widget.py (line 154)

🏗️ clear_editor
   📄 Core\Code\Unified\unified_code_editor.py (line 595)
   📞 Called by:
      • Editors\ObjectEditor\object_editor.py (line 188)

🏗️ is_dirty
   📄 Core\Code\Unified\unified_code_editor.py (line 603)
   ⚠️  Never called

🏗️ set_dirty
   📄 Core\Code\Unified\unified_code_editor.py (line 607)
   ⚠️  Never called

🏗️ get_diagnostics
   📄 Core\Code\Unified\unified_code_editor.py (line 627)
   ⚠️  Never called

🏗️ clear_diagnostics
   📄 Core\Code\Unified\unified_code_editor.py (line 631)
   📞 Called by:
      • Editors\ObjectEditor\UI\code_editor_widget.py (line 150)

🏗️ get_mode
   📄 Core\Code\Unified\unified_code_editor.py (line 641)
   ⚠️  Never called

🏗️ set_mode
   📄 Core\Code\Unified\unified_code_editor.py (line 646)
   📞 Called by:
      • Core\Code\Unified\test_harness.py (line 149)
      • Editors\ModelEditor\examples\GoodPerformanceButOnlyShowsModels.py (line 291)
      • Core\Code\PGSL\pgsl_runtime.py (line 63)

🏗️ get_context
   📄 Core\Code\Unified\unified_code_editor.py (line 652)
   ⚠️  Never called

🏗️ set_status
   📄 Core\Code\Unified\unified_code_editor.py (line 656)
   ⚠️  Never called

🏗️ _output_to_terminal
   📄 Core\Code\Unified\unified_code_editor.py (line 664)
   ⚠️  Never called

🏗️ check_selected_code
   📄 Core\Code\Unified\unified_code_editor.py (line 671)
   📞 Called by:
      • Editors\ObjectEditor\UI\code_editor_widget.py (line 158)

🏗️ check_full_code
   📄 Core\Code\Unified\unified_code_editor.py (line 732)
   📞 Called by:
      • Editors\ObjectEditor\UI\code_editor_widget.py (line 162)

🏗️ _perform_validation
   📄 Core\Code\Unified\unified_code_editor.py (line 806)
   ⚠️  Never called

🏗️ enable_real_time_validation
   📄 Core\Code\Unified\unified_code_editor.py (line 827)
   ⚠️  Never called

🏗️ test_selected_code
   📄 Core\Code\Unified\unified_code_editor.py (line 837)
   ⚠️  Never called

🏗️ test_code
   📄 Core\Code\Unified\unified_code_editor.py (line 891)
   ⚠️  Never called

🏗️ _display_execution_result_terminal
   📄 Core\Code\Unified\unified_code_editor.py (line 935)
   ⚠️  Never called

🏗️ set_image
   📄 Editors\ImageEditor\core\ui\sprite_sheet_importer.py (line 31)
   📞 Called by:
      • Editors\ImageEditor\core\core\selection_manager.py (line 360)
      • Editors\ImageEditor\core\ui\sprite_sheet_importer.py (line 169)
      • Editors\ImageEditor\core\ui\sprite_sheet_importer.py (line 338)
      • Editors\ImageEditor\core\ui\sprite_sheet_importer.py (line 485)
      • Editors\ImageEditor\core\ui\sprite_sheet_importer.py (line 691)
      • Editors\ImageEditor\core\ui\main_window.py (line 1180)
      • Editors\ImageEditor\core\ui\main_window.py (line 1182)

🏗️ set_grid_info
   📄 Editors\ImageEditor\core\ui\sprite_sheet_importer.py (line 37)
   📞 Called by:
      • Editors\ImageEditor\core\ui\sprite_sheet_importer.py (line 486)
      • Editors\ImageEditor\core\ui\sprite_sheet_importer.py (line 692)

🏗️ set_frames_data
   📄 Editors\ImageEditor\core\ui\sprite_sheet_importer.py (line 42)
   📞 Called by:
      • Editors\ImageEditor\core\ui\sprite_sheet_importer.py (line 516)
      • Editors\ImageEditor\core\ui\sprite_sheet_importer.py (line 693)

🏗️ paintEvent
   📄 Editors\ImageEditor\core\ui\sprite_sheet_importer.py (line 47)
   📞 Called by:
      • Editors\ImageEditor\core\ui\preview.py (line 2595)
      • Editors\ModelEditor\ModelEditor.py (line 7314)

🏗️ load_image
   📄 Editors\ImageEditor\core\ui\sprite_sheet_importer.py (line 325)
   ⚠️  Never called

🏗️ crop_blank_edges
   📄 Editors\ImageEditor\core\ui\sprite_sheet_importer.py (line 343)
   ⚠️  Never called

🏗️ on_method_changed
   📄 Editors\ImageEditor\core\ui\sprite_sheet_importer.py (line 378)
   ⚠️  Never called

🏗️ on_bg_removal_toggled
   📄 Editors\ImageEditor\core\ui\sprite_sheet_importer.py (line 385)
   ⚠️  Never called

🏗️ on_tolerance_changed
   📄 Editors\ImageEditor\core\ui\sprite_sheet_importer.py (line 395)
   ⚠️  Never called

🏗️ on_auto_bg_toggled
   📄 Editors\ImageEditor\core\ui\sprite_sheet_importer.py (line 400)
   ⚠️  Never called

🏗️ auto_detect_background
   📄 Editors\ImageEditor\core\ui\sprite_sheet_importer.py (line 406)
   ⚠️  Never called

🏗️ pick_bg_color
   📄 Editors\ImageEditor\core\ui\sprite_sheet_importer.py (line 417)
   ⚠️  Never called

🏗️ preview_slice
   📄 Editors\ImageEditor\core\ui\sprite_sheet_importer.py (line 435)
   ⚠️  Never called

🏗️ slice_grid
   📄 Editors\ImageEditor\core\ui\sprite_sheet_importer.py (line 454)
   ⚠️  Never called

🏗️ slice_auto
   📄 Editors\ImageEditor\core\ui\sprite_sheet_importer.py (line 518)
   ⚠️  Never called

🏗️ remove_background
   📄 Editors\ImageEditor\core\ui\sprite_sheet_importer.py (line 695)
   ⚠️  Never called

🏗️ crop_to_content
   📄 Editors\ImageEditor\core\ui\sprite_sheet_importer.py (line 718)
   ⚠️  Never called

🏗️ center_frame
   📄 Editors\ImageEditor\core\ui\sprite_sheet_importer.py (line 746)
   ⚠️  Never called

🏗️ update_preview
   📄 Editors\ImageEditor\core\ui\sprite_sheet_importer.py (line 769)
   📞 Called by:
      • Editors\ImageEditor\core\ui\dialogs\preferences_dialog.py (line 592)

🏗️ get_results
   📄 Editors\ImageEditor\core\ui\sprite_sheet_importer.py (line 776)
   ⚠️  Never called

🏗️ run
   📄 Core\AI\PyGenesisAssistant\Nova\ui\project_management_dialog.py (line 31)
   ⚠️  Never called

🏗️ on_progress
   📄 Core\AI\PyGenesisAssistant\Nova\ui\project_management_dialog.py (line 239)
   ⚠️  Never called

🏗️ on_analysis_complete
   📄 Core\AI\PyGenesisAssistant\Nova\ui\project_management_dialog.py (line 243)
   ⚠️  Never called

🏗️ set_project_root
   📄 Core\AI\PyGenesisAssistant\Nova\ui\project_management_dialog.py (line 568)
   📞 Called by:
      • Core\AI\PyGenesisAssistant\Nova\ui\project_management_dialog.py (line 572)
      • Core\AI\PyGenesisAssistant\Nova\ui\project_management_dialog.py (line 574)
      • Core\AI\PyGenesisAssistant\Nova\ui\project_management_dialog.py (line 576)

🏗️ _populate_tree
   📄 Core\AI\PyGenesisAssistant\Nova\ui\project_management_dialog.py (line 338)
   ⚠️  Never called

🏗️ _add_directory
   📄 Core\AI\PyGenesisAssistant\Nova\ui\project_management_dialog.py (line 366)
   ⚠️  Never called

🏗️ on_item_double_clicked
   📄 Core\AI\PyGenesisAssistant\Nova\ui\project_management_dialog.py (line 389)
   ⚠️  Never called

🏗️ __repr__
   📄 Core\CodeSystem\lexer.py (line 82)
   ⚠️  Never called

🏗️ __eq__
   📄 Core\CodeSystem\lexer.py (line 85)
   ⚠️  Never called

🏗️ current_char
   📄 Core\CodeSystem\lexer.py (line 125)
   ⚠️  Never called

🏗️ peek_char
   📄 Core\CodeSystem\lexer.py (line 131)
   ⚠️  Never called

🏗️ advance
   📄 Core\CodeSystem\lexer.py (line 138)
   ⚠️  Never called

🏗️ skip_whitespace
   📄 Core\CodeSystem\lexer.py (line 154)
   ⚠️  Never called

🏗️ read_number
   📄 Core\CodeSystem\lexer.py (line 159)
   ⚠️  Never called

🏗️ read_string
   📄 Core\CodeSystem\lexer.py (line 173)
   ⚠️  Never called

🏗️ read_identifier
   📄 Core\CodeSystem\lexer.py (line 204)
   ⚠️  Never called

🏗️ read_comment
   📄 Core\CodeSystem\lexer.py (line 211)
   ⚠️  Never called

🏗️ read_pgsl_comment
   📄 Core\CodeSystem\lexer.py (line 219)
   ⚠️  Never called

🏗️ calculate_indent
   📄 Core\CodeSystem\lexer.py (line 228)
   ⚠️  Never called

🏗️ tokenize
   📄 Core\CodeSystem\lexer.py (line 240)
   📞 Called by:
      • Core\CodeSystem\parser.py (line 38)

🏗️ _pick_color
   📄 Core\AI\PyGenesisAssistant\Nova\ui\theme_editor.py (line 47)
   ⚠️  Never called

🏗️ _update_preview
   📄 Core\AI\PyGenesisAssistant\Nova\ui\theme_editor.py (line 66)
   ⚠️  Never called

🏗️ get_color
   📄 Core\AI\PyGenesisAssistant\Nova\ui\theme_editor.py (line 70)
   ⚠️  Never called

🏗️ _save_changes
   📄 Core\AI\PyGenesisAssistant\Nova\ui\theme_editor.py (line 185)
   ⚠️  Never called

🏗️ _get_dark_theme
   📄 Config\ThemeManager.py (line 33)
   ⚠️  Never called

🏗️ _get_light_theme
   📄 Config\ThemeManager.py (line 95)
   ⚠️  Never called

🏗️ _get_high_contrast_theme
   📄 Config\ThemeManager.py (line 157)
   ⚠️  Never called

🏗️ get_current_theme
   📄 Config\ThemeManager.py (line 215)
   📞 Called by:
      • UI\CommonDialogs\PreferencesDialog.py (line 2139)

🏗️ get_colors
   📄 Config\ThemeManager.py (line 219)
   📞 Called by:
      • Editors\TextureEditor\TextureEditor.py (line 751)
      • UI\Widgets\TerminalWidget.py (line 140)
      • UI\Widgets\TerminalWidget.py (line 170)
      • UI\Widgets\TerminalWidget.py (line 182)
      • UI\Widgets\TerminalWidget.py (line 205)
      • UI\Widgets\TerminalWidget.py (line 249)
      • UI\CommonDialogs\PreferencesDialog.py (line 1726)
      • UI\CommonDialogs\PreferencesDialog.py (line 1755)
      • UI\CommonDialogs\PreferencesDialog.py (line 1785)
      • UI\CommonDialogs\PreferencesDialog.py (line 1952)
      • UI\CommonDialogs\PreferencesDialog.py (line 2159)
      • UI\MainWindow\MainWindow.py (line 1772)
      • UI\MainWindow\MainWindow.py (line 1782)
      • Editors\SpriteEditor\SpriteEditor.py (line 991)
      • Editors\ModelEditor\ModelEditor.py (line 10581)

🏗️ set_theme
   📄 Config\ThemeManager.py (line 227)
   📞 Called by:
      • UI\CommonDialogs\PreferencesDialog.py (line 1772)
      • Editors\ImageEditor\core\ui\main_window.py (line 1098)

🏗️ get_available_themes
   📄 Config\ThemeManager.py (line 236)
   ⚠️  Never called

🏗️ apply_custom_colors
   📄 Config\ThemeManager.py (line 240)
   📞 Called by:
      • UI\CommonDialogs\PreferencesDialog.py (line 1993)
      • UI\MainWindow\MainWindow.py (line 1769)

🏗️ generate_custom_stylesheet
   📄 Config\ThemeManager.py (line 250)
   📞 Called by:
      • UI\MainWindow\MainWindow.py (line 1771)
      • UI\MainWindow\MainWindow.py (line 1781)

🏗️ get_stylesheet
   📄 Config\ThemeManager.py (line 380)
   📞 Called by:
      • UI\CommonDialogs\PreferencesDialog.py (line 1996)
      • UI\CommonDialogs\PreferencesDialog.py (line 1999)
      • Editors\Shared\IntegratedImageEditor.py (line 1402)
      • UI\MainWindow\MainWindow.py (line 1776)

🏗️ _load_custom_themes
   📄 Config\ThemeManager.py (line 557)
   ⚠️  Never called

🏗️ save_custom_theme
   📄 Config\ThemeManager.py (line 573)
   📞 Called by:
      • UI\CommonDialogs\PreferencesDialog.py (line 1896)

🏗️ delete_custom_theme
   📄 Config\ThemeManager.py (line 595)
   📞 Called by:
      • UI\CommonDialogs\PreferencesDialog.py (line 1938)

🏗️ get_custom_themes
   📄 Config\ThemeManager.py (line 617)
   📞 Called by:
      • UI\CommonDialogs\PreferencesDialog.py (line 1788)
      • UI\CommonDialogs\PreferencesDialog.py (line 1844)
      • UI\CommonDialogs\PreferencesDialog.py (line 1922)
      • UI\CommonDialogs\PreferencesDialog.py (line 2157)

🏗️ _load_custom_theme_colors
   📄 Config\ThemeManager.py (line 625)
   ⚠️  Never called

🏗️ add_child
   📄 Core\CodeSystem\ast.py (line 41)
   ⚠️  Never called

🏗️ accept
   📄 Core\CodeSystem\ast.py (line 245)
   📞 Called by:
      • Editors\ImageEditor\core\ui\dialogs\preferences_dialog.py (line 704)
      • Editors\ImageEditor\core\ui\texture_atlas_dialog.py (line 405)
      • Editors\ImageEditor\core\ui\texture_atlas_dialog.py (line 461)
      • Editors\ImageEditor\core\ui\texture_atlas_dialog.py (line 839)
      • Editors\ImageEditor\core\ui\texture_atlas_dialog.py (line 843)
      • UI\CommonDialogs\RestoreDialog.py (line 167)
      • UI\CommonDialogs\PreferencesDialog.py (line 2803)

🏗️ visit_program
   📄 Core\CodeSystem\ast.py (line 253)
   ⚠️  Never called

🏗️ visit_block
   📄 Core\CodeSystem\ast.py (line 257)
   ⚠️  Never called

🏗️ visit_literal
   📄 Core\CodeSystem\ast.py (line 261)
   ⚠️  Never called

🏗️ visit_identifier
   📄 Core\CodeSystem\ast.py (line 265)
   ⚠️  Never called

🏗️ visit_binary_op
   📄 Core\CodeSystem\ast.py (line 269)
   ⚠️  Never called

🏗️ visit_unary_op
   📄 Core\CodeSystem\ast.py (line 273)
   ⚠️  Never called

🏗️ visit_function_call
   📄 Core\CodeSystem\ast.py (line 277)
   ⚠️  Never called

🏗️ visit_variable_decl
   📄 Core\CodeSystem\ast.py (line 281)
   ⚠️  Never called

🏗️ visit_assignment
   📄 Core\CodeSystem\ast.py (line 285)
   ⚠️  Never called

🏗️ visit_if_statement
   📄 Core\CodeSystem\ast.py (line 289)
   ⚠️  Never called

🏗️ visit_while_loop
   📄 Core\CodeSystem\ast.py (line 293)
   ⚠️  Never called

🏗️ visit_for_loop
   📄 Core\CodeSystem\ast.py (line 297)
   ⚠️  Never called

🏗️ visit_function_def
   📄 Core\CodeSystem\ast.py (line 301)
   ⚠️  Never called

🏗️ visit_return_statement
   📄 Core\CodeSystem\ast.py (line 305)
   ⚠️  Never called

🏗️ generate_diff
   📄 Core\AI\PyGenesisAssistant\Nova\ui\preview_widget.py (line 84)
   ⚠️  Never called

🏗️ toggle_expanded
   📄 Core\AI\PyGenesisAssistant\Nova\ui\preview_widget.py (line 221)
   ⚠️  Never called

🏗️ toggle_content
   📄 Editors\ImageEditor\core\ui\panels\left_panel.py (line 139)
   ⚠️  Never called

🏗️ toggle_filled
   📄 Editors\ImageEditor\core\ui\panels\left_panel.py (line 541)
   ⚠️  Never called

🏗️ update_theme
   📄 Editors\ImageEditor\core\ui\panels\left_panel.py (line 549)
   📞 Called by:
      • Core\AI\PyGenesisAssistant\Nova\ui\theme_editor.py (line 201)
      • Editors\ImageEditor\core\ui\main_window.py (line 1096)
      • Editors\ImageEditor\core\ui\main_window.py (line 1097)

🏗️ toggle_fold
   📄 Editors\ImageEditor\core\ui\panels\left_panel.py (line 555)
   ⚠️  Never called

🏗️ on_radius_text_changed
   📄 Editors\ImageEditor\core\ui\panels\left_panel.py (line 567)
   ⚠️  Never called

🏗️ increase_radius
   📄 Editors\ImageEditor\core\ui\panels\left_panel.py (line 586)
   📞 Called by:
      • Editors\ImageEditor\core\ui\main_window.py (line 1000)

🏗️ decrease_radius
   📄 Editors\ImageEditor\core\ui\panels\left_panel.py (line 593)
   📞 Called by:
      • Editors\ImageEditor\core\ui\main_window.py (line 998)

🏗️ update_color_buttons
   📄 Editors\ImageEditor\core\ui\panels\left_panel.py (line 600)
   📞 Called by:
      • Editors\ImageEditor\core\ui\preview.py (line 2007)
      • Editors\ImageEditor\core\ui\main_window.py (line 1270)
      • Editors\ImageEditor\core\ui\main_window.py (line 1278)

🏗️ pick_left_color
   📄 Editors\ImageEditor\core\ui\panels\left_panel.py (line 604)
   ⚠️  Never called

🏗️ pick_right_color
   📄 Editors\ImageEditor\core\ui\panels\left_panel.py (line 611)
   ⚠️  Never called

🏗️ add_color_to_history
   📄 Editors\ImageEditor\core\ui\panels\left_panel.py (line 618)
   ⚠️  Never called

🏗️ update_color_history
   📄 Editors\ImageEditor\core\ui\panels\left_panel.py (line 627)
   ⚠️  Never called

🏗️ select_color_from_history
   📄 Editors\ImageEditor\core\ui\panels\left_panel.py (line 644)
   ⚠️  Never called

🏗️ select_tool
   📄 Editors\ImageEditor\core\ui\panels\left_panel.py (line 650)
   📞 Called by:
      • Editors\ImageEditor\core\ui\main_window.py (line 960)
      • Editors\ImageEditor\core\ui\main_window.py (line 964)

🏗️ update_tool_highlight
   📄 Editors\ImageEditor\core\ui\panels\left_panel.py (line 656)
   ⚠️  Never called

🏗️ select_shape_tool
   📄 Editors\ImageEditor\core\ui\panels\left_panel.py (line 663)
   📞 Called by:
      • Editors\ImageEditor\core\ui\main_window.py (line 968)

🏗️ update_shape_highlight
   📄 Editors\ImageEditor\core\ui\panels\left_panel.py (line 669)
   ⚠️  Never called

🏗️ select_selection_tool
   📄 Editors\ImageEditor\core\ui\panels\left_panel.py (line 676)
   📞 Called by:
      • Editors\ImageEditor\core\ui\main_window.py (line 972)

🏗️ update_selection_highlight
   📄 Editors\ImageEditor\core\ui\panels\left_panel.py (line 682)
   ⚠️  Never called

🏗️ update_current_tool_label
   📄 Editors\ImageEditor\core\ui\panels\left_panel.py (line 689)
   ⚠️  Never called

🏗️ toggle_grid
   📄 Editors\ImageEditor\core\ui\panels\left_panel.py (line 712)
   📞 Called by:
      • Editors\Shared\IntegratedImageEditor.py (line 1274)

🏗️ _get_canvas
   📄 Editors\ImageEditor\core\ui\panels\left_panel.py (line 732)
   ⚠️  Never called

🏗️ on_grid_size_text_changed
   📄 Editors\ImageEditor\core\ui\panels\left_panel.py (line 741)
   ⚠️  Never called

🏗️ increase_grid_size
   📄 Editors\ImageEditor\core\ui\panels\left_panel.py (line 764)
   ⚠️  Never called

🏗️ decrease_grid_size
   📄 Editors\ImageEditor\core\ui\panels\left_panel.py (line 773)
   ⚠️  Never called

🏗️ on_grid_rotation_text_changed
   📄 Editors\ImageEditor\core\ui\panels\left_panel.py (line 782)
   ⚠️  Never called

🏗️ increase_grid_rotation
   📄 Editors\ImageEditor\core\ui\panels\left_panel.py (line 805)
   ⚠️  Never called

🏗️ decrease_grid_rotation
   📄 Editors\ImageEditor\core\ui\panels\left_panel.py (line 814)
   ⚠️  Never called

🏗️ pick_grid_color
   📄 Editors\ImageEditor\core\ui\panels\left_panel.py (line 823)
   ⚠️  Never called

🏗️ toggle_grid_snap
   📄 Editors\ImageEditor\core\ui\panels\left_panel.py (line 835)
   📞 Called by:
      • Editors\Shared\IntegratedImageEditor.py (line 1280)

🏗️ toggle_global_grid
   📄 Editors\ImageEditor\core\ui\panels\left_panel.py (line 838)
   ⚠️  Never called

🏗️ zoom_in
   📄 Editors\ImageEditor\core\ui\panels\left_panel.py (line 851)
   📞 Called by:
      • Editors\Shared\IntegratedImageEditor.py (line 1256)
      • Editors\ImageEditor\core\ui\main_window.py (line 1011)

🏗️ zoom_out
   📄 Editors\ImageEditor\core\ui\panels\left_panel.py (line 858)
   📞 Called by:
      • Editors\Shared\IntegratedImageEditor.py (line 1262)
      • Editors\ImageEditor\core\ui\main_window.py (line 1013)

🏗️ zoom_reset
   📄 Editors\ImageEditor\core\ui\panels\left_panel.py (line 865)
   📞 Called by:
      • Editors\Shared\IntegratedImageEditor.py (line 1268)
      • Editors\ImageEditor\core\ui\main_window.py (line 1015)

🏗️ on_zoom_text_changed
   📄 Editors\ImageEditor\core\ui\panels\left_panel.py (line 872)
   ⚠️  Never called

🏗️ on_opacity_changed
   📄 Editors\ImageEditor\core\ui\panels\left_panel.py (line 905)
   ⚠️  Never called

🏗️ apply_section_layout
   📄 Editors\ImageEditor\core\ui\panels\left_panel.py (line 911)
   📞 Called by:
      • Editors\ImageEditor\core\ui\dialogs\preferences_dialog.py (line 595)

🏗️ apply_icon_layout
   📄 Editors\ImageEditor\core\ui\panels\left_panel.py (line 922)
   📞 Called by:
      • Editors\ImageEditor\core\ui\dialogs\preferences_dialog.py (line 297)
      • Editors\ImageEditor\core\ui\dialogs\preferences_dialog.py (line 616)
      • Editors\ImageEditor\core\ui\dialogs\preferences_dialog.py (line 667)

🏗️ wheelEvent
   📄 Editors\ImageEditor\core\ui\panels\left_panel.py (line 948)
   📞 Called by:
      • Editors\ImageEditor\core\ui\panels\right_panel.py (line 706)
      • Editors\ImageEditor\core\ui\timeline.py (line 40)
      • Editors\ImageEditor\core\ui\timeline.py (line 50)
      • Editors\ImageEditor\core\ui\panels\left_panel.py (line 950)
      • Editors\ImageEditor\core\ui\preview.py (line 243)

🏗️ setPixmap
   📄 Editors\ImageEditor\core\ui\rotate_dialog.py (line 20)
   📞 Called by:
      • Editors\ImageEditor\core\ui\rotate_dialog.py (line 270)
      • Editors\ImageEditor\core\ui\nine_slice_importer.py (line 765)
      • Editors\ImageEditor\core\ui\mirror_flip_dialog.py (line 123)
      • Editors\ImageEditor\core\ui\dialogs\effect_dialog.py (line 819)
      • Editors\ImageEditor\core\ui\texture_atlas_dialog.py (line 118)
      • Editors\ImageEditor\core\core\ai_test_app.py (line 666)
      • Editors\ImageEditor\core\core\ai_test_app.py (line 681)
      • Editors\ImageEditor\core\ui\character_creator_dialog.py (line 925)
      • Editors\ImageEditor\core\ui\character_creator_dialog.py (line 927)
      • Editors\ImageEditor\core\ui\character_creator_dialog.py (line 941)
      • Editors\ImageEditor\core\ui\character_creator_dialog.py (line 945)
      • Editors\ImageEditor\core\ui\block_texture_dialog.py (line 603)
      • Editors\ImageEditor\core\ui\ai_dialogs.py (line 914)
      • Editors\ImageEditor\core\ui\background_removal_dialog.py (line 111)
      • Editors\ImageEditor\core\ui\background_removal_dialog.py (line 125)
      • Editors\ObjectEditor\UI\properties_panel.py (line 412)
      • Editors\ObjectEditor\object_properties_panel.py (line 373)

🏗️ _load_current_image
   📄 Editors\ImageEditor\core\ui\rotate_dialog.py (line 90)
   ⚠️  Never called

🏗️ _on_preset_changed
   📄 Editors\ImageEditor\core\ui\rotate_dialog.py (line 184)
   ⚠️  Never called

🏗️ _on_angle_changed
   📄 Editors\ImageEditor\core\ui\rotate_dialog.py (line 204)
   ⚠️  Never called

🏗️ _on_custom_toggled
   📄 Editors\ImageEditor\core\ui\rotate_dialog.py (line 214)
   ⚠️  Never called

🏗️ get_angle
   📄 Editors\ImageEditor\core\ui\rotate_dialog.py (line 277)
   ⚠️  Never called

🏗️ get_parameters
   📄 Editors\ImageEditor\core\ui\rotate_dialog.py (line 286)
   ⚠️  Never called

🏗️ to_dict
   📄 Core\Code\Unified\validation_pipeline.py (line 54)
   📞 Called by:
      • Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 183)

🏗️ validate
   📄 Core\Code\Unified\validation_pipeline.py (line 91)
   📞 Called by:
      • Core\Code\Unified\unified_code_editor.py (line 751)
      • Core\Code\Unified\unified_code_editor.py (line 760)
      • Core\Code\Unified\unified_code_editor.py (line 771)
      • Core\Code\Unified\unified_code_editor.py (line 815)
      • Core\Code\Unified\unified_code_editor.py (line 908)
      • Core\Code\Unified\validation_pipeline.py (line 148)
      • Core\Code\Unified\acceptance_contract.py (line 89)
      • Editors\ObjectEditor\Services\object_validation_service.py (line 24)
      • Editors\ObjectEditor\Services\object_validation_service.py (line 31)
      • Editors\ObjectEditor\Services\object_validation_service.py (line 54)
      • Editors\ObjectEditor\UI\code_editor_widget.py (line 209)
      • Editors\ObjectEditor\UI\code_editor_widget.py (line 273)

🏗️ _validate_pgsl
   📄 Core\Code\Unified\validation_pipeline.py (line 124)
   ⚠️  Never called

🏗️ _validate_python
   📄 Core\Code\Unified\validation_pipeline.py (line 205)
   ⚠️  Never called

🏗️ validate_selection
   📄 Core\Code\Unified\validation_pipeline.py (line 327)
   📞 Called by:
      • Core\Code\Unified\unified_code_editor.py (line 694)
      • Core\Code\Unified\unified_code_editor.py (line 859)

🏗️ keyPressEvent
   📄 Core\AI\PyGenesisAssistant\Nova\ui\input_bar.py (line 20)
   📞 Called by:
      • Core\AI\PyGenesisAssistant\Nova\ui\input_bar.py (line 25)
      • Editors\CodeEditor\PGSLCodeEditor.py (line 236)
      • Editors\CodeEditor\PGSLCodeEditor.py (line 241)
      • Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 2321)
      • UI\Widgets\ResourceTree.py (line 126)
      • Editors\ImageEditor\core\ui\preview.py (line 924)
      • Editors\SoundEditor\core\WaveForge.py (line 1213)
      • Editors\ModelEditor\ModelEditor.py (line 2242)

🏗️ refresh_style
   📄 Core\AI\PyGenesisAssistant\Nova\ui\input_bar.py (line 183)
   📞 Called by:
      • Core\AI\PyGenesisAssistant\NovaWidget.py (line 205)
      • Core\AI\PyGenesisAssistant\NovaWidget.py (line 207)
      • Core\AI\PyGenesisAssistant\NovaWidget.py (line 209)

🏗️ _on_send_triggered
   📄 Core\AI\PyGenesisAssistant\Nova\ui\input_bar.py (line 187)
   ⚠️  Never called

🏗️ _toggle_expand
   📄 Core\AI\PyGenesisAssistant\Nova\ui\input_bar.py (line 194)
   ⚠️  Never called

🏗️ _reset_size
   📄 Core\AI\PyGenesisAssistant\Nova\ui\input_bar.py (line 202)
   ⚠️  Never called

🏗️ show_status
   📄 Core\AI\PyGenesisAssistant\Nova\ui\input_bar.py (line 207)
   📞 Called by:
      • Core\AI\PyGenesisAssistant\NovaWidget.py (line 250)
      • Core\AI\PyGenesisAssistant\NovaWidget.py (line 272)

🏗️ hide_status
   📄 Core\AI\PyGenesisAssistant\Nova\ui\input_bar.py (line 224)
   📞 Called by:
      • Core\AI\PyGenesisAssistant\NovaWidget.py (line 333)
      • Core\AI\PyGenesisAssistant\NovaWidget.py (line 357)

🏗️ _animate_status_dots
   📄 Core\AI\PyGenesisAssistant\Nova\ui\input_bar.py (line 229)
   ⚠️  Never called

🏗️ _on_code_changed
   📄 Core\Code\Unified\test_harness.py (line 102)
   ⚠️  Never called

🏗️ _on_mode_changed
   📄 Core\Code\Unified\test_harness.py (line 107)
   ⚠️  Never called

🏗️ _on_validation_complete
   📄 Core\Code\Unified\test_harness.py (line 111)
   ⚠️  Never called

🏗️ _load_python_sample
   📄 Core\Code\Unified\test_harness.py (line 122)
   ⚠️  Never called

🏗️ _load_pgsl_sample
   📄 Core\Code\Unified\test_harness.py (line 139)
   ⚠️  Never called

🏗️ _load_invalid_sample
   📄 Core\Code\Unified\test_harness.py (line 151)
   ⚠️  Never called

🏗️ create_test_window
   📄 Core\Code\Unified\test_harness.py (line 162)
   ⚠️  Never called

🏗️ _handle_mode_toggle
   📄 Core\AI\PyGenesisAssistant\Nova\ui\header.py (line 96)
   ⚠️  Never called

🏗️ update_mode_display
   📄 Core\AI\PyGenesisAssistant\Nova\ui\header.py (line 103)
   ⚠️  Never called

🏗️ _get_user_name
   📄 Core\AI\PyGenesisAssistant\Nova\ui\header.py (line 195)
   ⚠️  Never called

🏗️ refresh_user_name
   📄 Core\AI\PyGenesisAssistant\Nova\ui\header.py (line 206)
   ⚠️  Never called

🏗️ update_thinking_status
   📄 Core\AI\PyGenesisAssistant\Nova\ui\header.py (line 211)
   📞 Called by:
      • Core\AI\PyGenesisAssistant\NovaWidget.py (line 265)

🏗️ update_global_star
   📄 Core\AI\PyGenesisAssistant\Nova\ui\header.py (line 236)
   📞 Called by:
      • Core\AI\PyGenesisAssistant\NovaWidget.py (line 132)
      • Core\AI\PyGenesisAssistant\NovaWidget.py (line 418)
      • Core\AI\PyGenesisAssistant\NovaWidget.py (line 428)

🏗️ _on_global_star_clicked
   📄 Core\AI\PyGenesisAssistant\Nova\ui\header.py (line 254)
   ⚠️  Never called

🏗️ _on_star_clicked
   📄 Core\AI\PyGenesisAssistant\Nova\ui\conversations_dialog.py (line 74)
   ⚠️  Never called

🏗️ _setup_ui
   📄 Core\AI\PyGenesisAssistant\Nova\ui\conversations_dialog.py (line 120)
   ⚠️  Never called

🏗️ _load_conversations
   📄 Core\AI\PyGenesisAssistant\Nova\ui\conversations_dialog.py (line 167)
   ⚠️  Never called

🏗️ _on_selection_changed
   📄 Core\AI\PyGenesisAssistant\Nova\ui\conversations_dialog.py (line 186)
   ⚠️  Never called

🏗️ _on_conversation_double_clicked
   📄 Core\AI\PyGenesisAssistant\Nova\ui\conversations_dialog.py (line 192)
   ⚠️  Never called

🏗️ _on_new_chat
   📄 Core\AI\PyGenesisAssistant\Nova\ui\conversations_dialog.py (line 205)
   ⚠️  Never called

🏗️ _on_rename
   📄 Core\AI\PyGenesisAssistant\Nova\ui\conversations_dialog.py (line 211)
   ⚠️  Never called

🏗️ _on_delete
   📄 Core\AI\PyGenesisAssistant\Nova\ui\conversations_dialog.py (line 239)
   ⚠️  Never called

🏗️ _on_context_menu
   📄 Core\AI\PyGenesisAssistant\Nova\ui\conversations_dialog.py (line 268)
   ⚠️  Never called

🏗️ _load_custom_preset
   📄 Editors\ImageEditor\core\ui\dialogs\preferences_dialog.py (line 157)
   ⚠️  Never called

🏗️ _save_custom_preset
   📄 Editors\ImageEditor\core\ui\dialogs\preferences_dialog.py (line 167)
   ⚠️  Never called

🏗️ _load_left_panel_presets
   📄 Editors\ImageEditor\core\ui\dialogs\preferences_dialog.py (line 180)
   ⚠️  Never called

🏗️ _save_left_panel_presets
   📄 Editors\ImageEditor\core\ui\dialogs\preferences_dialog.py (line 186)
   ⚠️  Never called

🏗️ _update_preset_combo
   📄 Editors\ImageEditor\core\ui\dialogs\preferences_dialog.py (line 190)
   ⚠️  Never called

🏗️ _get_current_section_preset
   📄 Editors\ImageEditor\core\ui\dialogs\preferences_dialog.py (line 198)
   ⚠️  Never called

🏗️ _apply_section_preset
   📄 Editors\ImageEditor\core\ui\dialogs\preferences_dialog.py (line 202)
   ⚠️  Never called

🏗️ _get_current_left_panel_preset
   📄 Editors\ImageEditor\core\ui\dialogs\preferences_dialog.py (line 223)
   ⚠️  Never called

🏗️ _apply_left_panel_preset
   📄 Editors\ImageEditor\core\ui\dialogs\preferences_dialog.py (line 252)
   ⚠️  Never called

🏗️ _on_save_preset
   📄 Editors\ImageEditor\core\ui\dialogs\preferences_dialog.py (line 299)
   ⚠️  Never called

🏗️ _on_load_preset
   📄 Editors\ImageEditor\core\ui\dialogs\preferences_dialog.py (line 308)
   ⚠️  Never called

🏗️ _on_delete_preset
   📄 Editors\ImageEditor\core\ui\dialogs\preferences_dialog.py (line 315)
   ⚠️  Never called

🏗️ _init_ui
   📄 Editors\ImageEditor\core\ui\dialogs\preferences_dialog.py (line 324)
   ⚠️  Never called

🏗️ _setup_left_panel_tab
   📄 Editors\ImageEditor\core\ui\dialogs\preferences_dialog.py (line 346)
   ⚠️  Never called

🏗️ _setup_right_panel_tab
   📄 Editors\ImageEditor\core\ui\dialogs\preferences_dialog.py (line 410)
   ⚠️  Never called

🏗️ _apply_right_panel_settings
   📄 Editors\ImageEditor\core\ui\dialogs\preferences_dialog.py (line 477)
   ⚠️  Never called

🏗️ _setup_general_tab
   📄 Editors\ImageEditor\core\ui\dialogs\preferences_dialog.py (line 495)
   ⚠️  Never called

🏗️ _setup_editor_tab
   📄 Editors\ImageEditor\core\ui\dialogs\preferences_dialog.py (line 530)
   ⚠️  Never called

🏗️ _on_theme_changed
   📄 Editors\ImageEditor\core\ui\dialogs\preferences_dialog.py (line 558)
   ⚠️  Never called

🏗️ _update_color_buttons
   📄 Editors\ImageEditor\core\ui\dialogs\preferences_dialog.py (line 565)
   ⚠️  Never called

🏗️ _update_left_panel_preview_and_apply
   📄 Editors\ImageEditor\core\ui\dialogs\preferences_dialog.py (line 585)
   ⚠️  Never called

🏗️ _move_section_up_and_apply
   📄 Editors\ImageEditor\core\ui\dialogs\preferences_dialog.py (line 618)
   ⚠️  Never called

🏗️ _move_section_down_and_apply
   📄 Editors\ImageEditor\core\ui\dialogs\preferences_dialog.py (line 626)
   ⚠️  Never called

🏗️ _update_icon_list
   📄 Editors\ImageEditor\core\ui\dialogs\preferences_dialog.py (line 634)
   ⚠️  Never called

🏗️ _apply_icon_layout_to_left_panel
   📄 Editors\ImageEditor\core\ui\dialogs\preferences_dialog.py (line 663)
   ⚠️  Never called

🏗️ _move_icon_up
   📄 Editors\ImageEditor\core\ui\dialogs\preferences_dialog.py (line 669)
   ⚠️  Never called

🏗️ _move_icon_down
   📄 Editors\ImageEditor\core\ui\dialogs\preferences_dialog.py (line 678)
   ⚠️  Never called

🏗️ reject
   📄 Editors\ImageEditor\core\ui\dialogs\preferences_dialog.py (line 706)
   📞 Called by:
      • Editors\ImageEditor\core\ui\dialogs\preferences_dialog.py (line 707)

🏗️ refresh_bubbles
   📄 Core\AI\PyGenesisAssistant\Nova\ui\chat_view.py (line 214)
   📞 Called by:
      • Core\AI\PyGenesisAssistant\NovaWidget.py (line 471)

🏗️ add_message
   📄 Core\AI\PyGenesisAssistant\Nova\ui\chat_view.py (line 237)
   📞 Called by:
      • Core\AI\PyGenesisAssistant\NovaWidget.py (line 215)
      • Core\AI\PyGenesisAssistant\NovaWidget.py (line 231)
      • Core\AI\PyGenesisAssistant\NovaWidget.py (line 236)
      • Core\AI\PyGenesisAssistant\NovaWidget.py (line 325)
      • Core\AI\PyGenesisAssistant\NovaWidget.py (line 330)
      • Core\AI\PyGenesisAssistant\NovaWidget.py (line 347)
      • Core\AI\PyGenesisAssistant\NovaWidget.py (line 449)
      • Core\AI\PyGenesisAssistant\NovaWidget.py (line 683)

🏗️ _on_preview_requested
   📄 Core\AI\PyGenesisAssistant\Nova\ui\chat_view.py (line 274)
   ⚠️  Never called

🏗️ _alignment_for
   📄 Core\AI\PyGenesisAssistant\Nova\ui\chat_view.py (line 280)
   ⚠️  Never called

🏗️ _create_aligned_wrapper
   📄 Core\AI\PyGenesisAssistant\Nova\ui\chat_view.py (line 283)
   ⚠️  Never called

🏗️ _scroll_to_bottom
   📄 Core\AI\PyGenesisAssistant\Nova\ui\chat_view.py (line 305)
   ⚠️  Never called

🏗️ create_vbo
   📄 Core\Rendering\BufferManager.py (line 33)
   📞 Called by:
      • Core\Rendering\Canvas_2D.py (line 189)

🏗️ create_ibo
   📄 Core\Rendering\BufferManager.py (line 78)
   📞 Called by:
      • Core\Rendering\Canvas_2D.py (line 196)

🏗️ create_vao
   📄 Core\Rendering\BufferManager.py (line 123)
   📞 Called by:
      • Core\Rendering\Canvas_2D.py (line 223)

🏗️ get_vbo
   📄 Core\Rendering\BufferManager.py (line 193)
   ⚠️  Never called

🏗️ get_ibo
   📄 Core\Rendering\BufferManager.py (line 197)
   ⚠️  Never called

🏗️ get_vao
   📄 Core\Rendering\BufferManager.py (line 201)
   ⚠️  Never called

🏗️ bind_vao
   📄 Core\Rendering\BufferManager.py (line 205)
   ⚠️  Never called

🏗️ delete_buffer
   📄 Core\Rendering\BufferManager.py (line 221)
   ⚠️  Never called

🏗️ cleanup
   📄 Core\Rendering\BufferManager.py (line 267)
   📞 Called by:
      • Editors\ModelEditor\examples\GoodPerformanceButOnlyShowsModels.py (line 390)
      • Editors\ModelEditor\examples\GoodPerformanceButOnlyShowsModels.py (line 512)
      • Tools\ScreenRecording\screen_recorder.py (line 702)

🏗️ get_buffer_manager
   📄 Core\Rendering\BufferManager.py (line 292)
   📞 Called by:
      • Core\Rendering\Canvas_2D.py (line 44)

🏗️ _load_themes
   📄 Core\AI\PyGenesisAssistant\Nova\themes.py (line 20)
   📞 Called by:
      • Core\AI\PyGenesisAssistant\Nova\themes.py (line 92)

🏗️ _get_default_themes
   📄 Core\AI\PyGenesisAssistant\Nova\themes.py (line 36)
   📞 Called by:
      • Core\AI\PyGenesisAssistant\Nova\themes.py (line 28)
      • Core\AI\PyGenesisAssistant\Nova\themes.py (line 31)

🏗️ _save_themes
   📄 Core\AI\PyGenesisAssistant\Nova\themes.py (line 82)
   📞 Called by:
      • Core\AI\PyGenesisAssistant\Nova\themes.py (line 32)
      • Core\AI\PyGenesisAssistant\Nova\themes.py (line 102)
      • Core\AI\PyGenesisAssistant\Nova\themes.py (line 111)
      • Core\AI\PyGenesisAssistant\Nova\themes.py (line 127)
      • Core\AI\PyGenesisAssistant\Nova\themes.py (line 137)

🏗️ current_palette
   📄 Core\AI\PyGenesisAssistant\Nova\themes.py (line 95)
   📞 Called by:
      • Core\AI\PyGenesisAssistant\Nova\ui\settings_dialog.py (line 13)
      • Core\AI\PyGenesisAssistant\Nova\ui\settings_dialog.py (line 129)
      • Core\AI\PyGenesisAssistant\Nova\ui\settings_dialog.py (line 313)
      • Core\AI\PyGenesisAssistant\Nova\ui\settings_dialog.py (line 371)
      • Core\AI\PyGenesisAssistant\Nova\ui\tasks_dialog.py (line 134)
      • Core\AI\PyGenesisAssistant\Nova\ui\tasks_dialog.py (line 331)
      • Core\AI\PyGenesisAssistant\Nova\ui\project_management_dialog.py (line 170)
      • Core\AI\PyGenesisAssistant\Nova\ui\project_management_dialog.py (line 293)
      • Core\AI\PyGenesisAssistant\Nova\ui\project_management_dialog.py (line 402)
      • Core\AI\PyGenesisAssistant\Nova\ui\project_management_dialog.py (line 462)
      • Core\AI\PyGenesisAssistant\Nova\ui\project_management_dialog.py (line 501)
      • Core\AI\PyGenesisAssistant\Nova\ui\theme_editor.py (line 154)
      • Core\AI\PyGenesisAssistant\Nova\ui\input_bar.py (line 132)
      • Core\AI\PyGenesisAssistant\Nova\ui\header.py (line 108)
      • Core\AI\PyGenesisAssistant\Nova\ui\conversations_dialog.py (line 36)
      • Core\AI\PyGenesisAssistant\Nova\ui\conversations_dialog.py (line 331)
      • Core\AI\PyGenesisAssistant\Nova\ui\chat_view.py (line 26)
      • Core\AI\PyGenesisAssistant\Nova\ui\chat_view.py (line 107)
      • Core\AI\PyGenesisAssistant\Nova\ui\chat_view.py (line 132)
      • Core\AI\PyGenesisAssistant\Nova\ui\chat_view.py (line 194)
      • Core\AI\PyGenesisAssistant\Nova\ui\chat_view.py (line 211)
      • Core\AI\PyGenesisAssistant\NovaWidget.py (line 196)
      • Core\AI\PyGenesisAssistant\NovaWidget.py (line 598)

🏗️ add_custom_theme
   📄 Core\AI\PyGenesisAssistant\Nova\themes.py (line 99)
   📞 Called by:
      • Core\AI\PyGenesisAssistant\Nova\ui\settings_dialog.py (line 171)

🏗️ remove_custom_theme
   📄 Core\AI\PyGenesisAssistant\Nova\themes.py (line 105)
   📞 Called by:
      • Core\AI\PyGenesisAssistant\Nova\ui\settings_dialog.py (line 201)

🏗️ rename_theme
   📄 Core\AI\PyGenesisAssistant\Nova\themes.py (line 117)
   📞 Called by:
      • Core\AI\PyGenesisAssistant\Nova\ui\settings_dialog.py (line 295)

🏗️ subscribe
   📄 Core\Events.py (line 80)
   ⚠️  Never called

🏗️ unsubscribe
   📄 Core\Events.py (line 96)
   ⚠️  Never called

🏗️ publish
   📄 Core\Events.py (line 109)
   📞 Called by:
      • Core\Services\resource_service.py (line 53)
      • Core\Services\resource_service.py (line 87)
      • Core\Services\resource_service.py (line 115)
      • Core\Services\resource_service.py (line 142)
      • Core\Services\project_service.py (line 45)
      • Core\Services\project_service.py (line 76)
      • Core\Services\project_service.py (line 99)
      • Core\Services\project_service.py (line 124)

🏗️ clear_subscribers
   📄 Core\Events.py (line 136)
   ⚠️  Never called

🏗️ save
   📄 Core\AI\PyGenesisAssistant\Nova\settings.py (line 25)
   📞 Called by:
      • Tools\ScreenRecording\screen_recorder.py (line 302)
      • Editors\ImageEditor\core\ui\main_window.py (line 2086)
      • UI\MainWindow\MainWindow.py (line 191)
      • UI\MainWindow\MainWindow.py (line 260)
      • Editors\ModelEditor\ModelEditor.py (line 4184)
      • Editors\ModelEditor\ModelEditor.py (line 4272)

🏗️ load
   📄 Core\AI\PyGenesisAssistant\Nova\settings.py (line 37)
   📞 Called by:
      • Editors\ModelEditor\examples\GoodPerformanceButOnlyShowsModels.py (line 116)
      • Editors\SoundEditor\SoundEditor.py (line 1178)
      • Editors\SoundEditor\SoundEditor.py (line 1677)
      • Editors\SoundEditor\SoundEditor.py (line 1730)
      • Editors\SoundEditor\SoundEditor.py (line 1935)
      • Editors\SoundEditor\core\WaveForge.py (line 987)

🏗️ freeze_layout_updates
   📄 Core\EditorOptimizer.py (line 16)
   ⚠️  Never called

🏗️ defer_heavy_operation
   📄 Core\EditorOptimizer.py (line 28)
   ⚠️  Never called

🏗️ defer_preview_loading
   📄 Core\EditorOptimizer.py (line 36)
   ⚠️  Never called

🏗️ deferred_load
   📄 Core\EditorOptimizer.py (line 41)
   ⚠️  Never called

🏗️ defer_opengl_initialization
   📄 Core\EditorOptimizer.py (line 52)
   ⚠️  Never called

🏗️ deferred_init
   📄 Core\EditorOptimizer.py (line 57)
   ⚠️  Never called

🏗️ build_editor_before_show
   📄 Core\EditorOptimizer.py (line 68)
   ⚠️  Never called

🏗️ restore_state_after_docks
   📄 Core\EditorOptimizer.py (line 88)
   ⚠️  Never called

🏗️ deferred_restore
   📄 Core\EditorOptimizer.py (line 93)
   ⚠️  Never called

🏗️ cache_editor_geometry
   📄 Core\EditorOptimizer.py (line 102)
   ⚠️  Never called

🏗️ restore_editor_geometry
   📄 Core\EditorOptimizer.py (line 120)
   ⚠️  Never called

🏗️ register_engine
   📄 Core\AI\PyGenesisAssistant\Nova\core\workflow.py (line 105)
   📞 Called by:
      • Core\AI\PyGenesisAssistant\NovaWidget.py (line 180)
      • Core\AI\PyGenesisAssistant\NovaWidget.py (line 181)
      • Core\AI\PyGenesisAssistant\NovaWidget.py (line 182)
      • Core\AI\PyGenesisAssistant\NovaWidget.py (line 183)
      • Core\AI\PyGenesisAssistant\NovaWidget.py (line 184)

🏗️ register_executor
   📄 Core\AI\PyGenesisAssistant\Nova\core\workflow.py (line 109)
   📞 Called by:
      • Core\AI\PyGenesisAssistant\NovaWidget.py (line 187)
      • Core\AI\PyGenesisAssistant\NovaWidget.py (line 188)
      • Core\AI\PyGenesisAssistant\NovaWidget.py (line 189)
      • Core\AI\PyGenesisAssistant\NovaWidget.py (line 190)
      • Core\AI\PyGenesisAssistant\NovaWidget.py (line 191)

🏗️ _init_language_utils
   📄 Core\AI\PyGenesisAssistant\Nova\core\workflow.py (line 113)
   ⚠️  Never called

🏗️ _scan_project
   📄 Core\AI\PyGenesisAssistant\Nova\core\workflow.py (line 464)
   ⚠️  Never called

🏗️ _scan_project_cached
   📄 Core\AI\PyGenesisAssistant\Nova\core\workflow.py (line 476)
   ⚠️  Never called

🏗️ _lookup_knowledge
   📄 Core\AI\PyGenesisAssistant\Nova\core\workflow.py (line 500)
   ⚠️  Never called

🏗️ _should_use_cloud
   📄 Core\AI\PyGenesisAssistant\Nova\core\workflow.py (line 522)
   ⚠️  Never called

🏗️ _cloud_ai_process
   📄 Core\AI\PyGenesisAssistant\Nova\core\workflow.py (line 540)
   ⚠️  Never called

🏗️ _discover_capabilities
   📄 Core\AI\PyGenesisAssistant\Nova\core\workflow.py (line 545)
   ⚠️  Never called

🏗️ _execute
   📄 Core\AI\PyGenesisAssistant\Nova\core\workflow.py (line 565)
   ⚠️  Never called

🏗️ _execute_with_plan
   📄 Core\AI\PyGenesisAssistant\Nova\core\workflow.py (line 580)
   ⚠️  Never called

🏗️ _determine_response_strategy
   📄 Core\AI\PyGenesisAssistant\Nova\core\workflow.py (line 628)
   ⚠️  Never called

🏗️ _generate_smart_clarification
   📄 Core\AI\PyGenesisAssistant\Nova\core\workflow.py (line 708)
   ⚠️  Never called

🏗️ get_conversation_state
   📄 Core\AI\PyGenesisAssistant\Nova\core\workflow.py (line 751)
   ⚠️  Never called

🏗️ reset_conversation_state
   📄 Core\AI\PyGenesisAssistant\Nova\core\workflow.py (line 755)
   ⚠️  Never called

🏗️ _setup_backup_dir
   📄 Core\AI\PyGenesisAssistant\Nova\core\transaction_manager.py (line 73)
   ⚠️  Never called

🏗️ begin_transaction
   📄 Core\AI\PyGenesisAssistant\Nova\core\transaction_manager.py (line 81)
   📞 Called by:
      • Core\AI\PyGenesisAssistant\Nova\core\workflow.py (line 588)

🏗️ add_operation
   📄 Core\AI\PyGenesisAssistant\Nova\core\transaction_manager.py (line 111)
   📞 Called by:
      • Core\AI\PyGenesisAssistant\Nova\core\workflow.py (line 594)

🏗️ _backup_file
   📄 Core\AI\PyGenesisAssistant\Nova\core\transaction_manager.py (line 154)
   ⚠️  Never called

🏗️ _backup_resource
   📄 Core\AI\PyGenesisAssistant\Nova\core\transaction_manager.py (line 181)
   ⚠️  Never called

🏗️ _prepare_operation_rollback
   📄 Core\AI\PyGenesisAssistant\Nova\core\transaction_manager.py (line 206)
   ⚠️  Never called

🏗️ commit
   📄 Core\AI\PyGenesisAssistant\Nova\core\transaction_manager.py (line 265)
   📞 Called by:
      • Core\AI\PyGenesisAssistant\Nova\core\workflow.py (line 602)

🏗️ _execute_operation
   📄 Core\AI\PyGenesisAssistant\Nova\core\transaction_manager.py (line 314)
   ⚠️  Never called

🏗️ _rollback_operations
   📄 Core\AI\PyGenesisAssistant\Nova\core\transaction_manager.py (line 360)
   ⚠️  Never called

🏗️ _rollback_operation
   📄 Core\AI\PyGenesisAssistant\Nova\core\transaction_manager.py (line 371)
   ⚠️  Never called

🏗️ rollback
   📄 Core\AI\PyGenesisAssistant\Nova\core\transaction_manager.py (line 445)
   📞 Called by:
      • Core\AI\PyGenesisAssistant\Nova\core\workflow.py (line 625)
      • Core\AI\PyGenesisAssistant\Nova\core\feedback_handler.py (line 97)

🏗️ get_transaction_state
   📄 Core\AI\PyGenesisAssistant\Nova\core\transaction_manager.py (line 464)
   📞 Called by:
      • Core\AI\PyGenesisAssistant\Nova\core\workflow.py (line 619)
      • Core\AI\PyGenesisAssistant\Nova\core\feedback_handler.py (line 94)

🏗️ cleanup_backups
   📄 Core\AI\PyGenesisAssistant\Nova\core\transaction_manager.py (line 487)
   ⚠️  Never called

🏗️ generate_index
   📄 Core\ProjectIndexManager.py (line 25)
   ⚠️  Never called

🏗️ load_index
   📄 Core\ProjectIndexManager.py (line 68)
   ⚠️  Never called

🏗️ is_index_valid
   📄 Core\ProjectIndexManager.py (line 102)
   ⚠️  Never called

🏗️ _extract_metadata
   📄 Core\ProjectIndexManager.py (line 137)
   ⚠️  Never called

🏗️ _get_resource_file_path
   📄 Core\ProjectIndexManager.py (line 194)
   ⚠️  Never called

🏗️ _get_resource_file_path_from_metadata
   📄 Core\ProjectIndexManager.py (line 233)
   ⚠️  Never called

🏗️ open_resource
   📄 Core\EditorInterface.py (line 21)
   📞 Called by:
      • Editors\RoomEditor\RoomEditor.py (line 1039)
      • Editors\RoomEditor\ui\main_window.py (line 1022)
      • Editors\ModelEditor\ModelEditor.py (line 2521)

🏗️ save_resource
   📄 Core\EditorInterface.py (line 33)
   📞 Called by:
      • Editors\CodeEditor\ScriptEditor.py (line 121)
      • Editors\BackgroundEditor\BackgroundEditor.py (line 395)
      • Editors\RoomEditor\RoomEditor.py (line 1200)
      • Editors\RoomEditor\ui\main_window.py (line 1183)
      • Editors\TextureEditor\TextureEditor.py (line 623)
      • Editors\SoundEditor\SoundEditor.py (line 2679)
      • Editors\SoundEditor\SoundEditor.py (line 2953)
      • UI\Widgets\ResourceTree.py (line 1709)
      • Editors\SpriteEditor\SpriteEditor.py (line 849)
      • Editors\ModelEditor\ModelEditor.py (line 800)
      • Editors\ModelEditor\ModelEditor.py (line 9537)
      • Editors\ModelEditor\ModelEditor.py (line 11350)

🏗️ close_editor
   📄 Core\EditorInterface.py (line 42)
   ⚠️  Never called

🏗️ get_editor_widget
   📄 Core\EditorInterface.py (line 52)
   ⚠️  Never called

🏗️ get_resource_type
   📄 Core\EditorInterface.py (line 71)
   ⚠️  Never called

🏗️ get_resource_id
   📄 Core\EditorInterface.py (line 80)
   ⚠️  Never called

🏗️ get_resource_name
   📄 Core\EditorInterface.py (line 89)
   ⚠️  Never called

🏗️ can_close
   📄 Core\EditorInterface.py (line 99)
   ⚠️  Never called

🏗️ test_validation
   📄 Core\AI\PyGenesisAssistant\Nova\core\test_api_manifest.py (line 9)
   📞 Called by:
      • Core\AI\PyGenesisAssistant\Nova\core\test_api_manifest.py (line 95)

🏗️ create_editor
   📄 Core\EditorFactory.py (line 23)
   ⚠️  Never called

🏗️ _create_sprite_editor
   📄 Core\EditorFactory.py (line 62)
   ⚠️  Never called

🏗️ _create_room_editor
   📄 Core\EditorFactory.py (line 68)
   ⚠️  Never called

🏗️ _create_sound_editor
   📄 Core\EditorFactory.py (line 74)
   ⚠️  Never called

🏗️ _create_model_editor
   📄 Core\EditorFactory.py (line 80)
   ⚠️  Never called

🏗️ _create_texture_editor
   📄 Core\EditorFactory.py (line 87)
   ⚠️  Never called

🏗️ _create_background_editor
   📄 Core\EditorFactory.py (line 93)
   ⚠️  Never called

🏗️ _create_object_editor
   📄 Core\EditorFactory.py (line 99)
   ⚠️  Never called

🏗️ _create_code_editor
   📄 Core\EditorFactory.py (line 105)
   ⚠️  Never called

🏗️ _create_generic_editor
   📄 Core\EditorFactory.py (line 111)
   ⚠️  Never called

🏗️ get_editor_name
   📄 Core\EditorFactory.py (line 118)
   ⚠️  Never called

🏗️ is_editor_type_supported
   📄 Core\EditorFactory.py (line 140)
   ⚠️  Never called

🏗️ start
   📄 Core\AI\PyGenesisAssistant\Nova\core\tasks.py (line 48)
   📞 Called by:
      • Core\AI\PyGenesisAssistant\CodeAnalyser.py (line 362)
      • Core\Code\Unified\unified_code_editor.py (line 544)
      • Core\Code\Unified\unified_code_editor.py (line 549)
      • Core\AI\PyGenesisAssistant\Nova\ui\project_management_dialog.py (line 95)
      • Core\AI\PyGenesisAssistant\Nova\ui\project_management_dialog.py (line 237)
      • Editors\ImageEditor\core\ui\panels\right_panel.py (line 629)
      • Core\AI\PyGenesisAssistant\DependencyAnalyser.py (line 270)
      • Editors\ImageEditor\core\ui\rotate_dialog.py (line 212)
      • Core\AI\PyGenesisAssistant\Nova\ui\input_bar.py (line 220)
      • Editors\ImageEditor\core\ui\timeline.py (line 1315)
      • Editors\ImageEditor\core\ui\timeline.py (line 1415)
      • Editors\ImageEditor\core\ui\dialogs\effect_dialog.py (line 718)
      • Editors\ImageEditor\core\ui\texture_atlas_dialog.py (line 140)
      • Editors\ImageEditor\core\ui\texture_atlas_dialog.py (line 592)
      • Editors\CodeEditor\PGSLCodeEditor.py (line 244)
      • Core\ProjectManager.py (line 229)
      • Core\ProjectManager.py (line 349)
      • Core\Rendering\Canvas_2D.py (line 486)
      • Editors\ImageEditor\core\core\ai_test_app.py (line 723)
      • Editors\ImageEditor\core\ui\character_creator_dialog.py (line 910)
      • Core\AI\PyGenesisAssistant\UnifiedCodeAnalyzer.py (line 835)
      • Core\AI\PyGenesisAssistant\UnifiedCodeAnalyzer.py (line 848)
      • Core\AI\PyGenesisAssistant\UnifiedCodeAnalyzer.py (line 919)
      • Core\AI\PyGenesisAssistant\UnifiedCodeAnalyzer.py (line 932)
      • Editors\ImageEditor\core\ui\block_texture_dialog.py (line 519)
      • Editors\ImageEditor\core\ui\ai_dialogs.py (line 955)
      • Editors\Shared\BaseImageResourceEditor.py (line 625)
      • Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 331)
      • Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 2438)
      • UI\CommonDialogs\ExtensionsDialog.py (line 273)
      • UI\CommonDialogs\ExtensionsDialog.py (line 484)
      • UI\CommonDialogs\ExtensionsDialog.py (line 540)
      • UI\CommonDialogs\ExtensionsDialog.py (line 594)
      • UI\CommonDialogs\ExtensionsDialog.py (line 714)
      • UI\CommonDialogs\ExtensionsDialog.py (line 734)
      • UI\CommonDialogs\ExtensionsDialog.py (line 754)
      • Editors\SoundEditor\SoundEditor.py (line 779)
      • UI\Widgets\LoadingWidget.py (line 56)
      • UI\Widgets\ResourceTree.py (line 769)
      • UI\Widgets\ResourceTree.py (line 798)
      • UI\Widgets\ResourceTree.py (line 860)
      • Editors\ImageEditor\core\ui\preview.py (line 86)
      • Editors\ImageEditor\core\ui\preview.py (line 129)
      • Tools\ScreenRecording\screen_recorder.py (line 326)
      • Tools\ScreenRecording\screen_recorder.py (line 664)
      • Editors\SoundEditor\core\WaveForge.py (line 668)
      • UI\MainWindow\MainWindow.py (line 1878)
      • Editors\ModelEditor\ModelEditor.py (line 1020)
      • Editors\ModelEditor\ModelEditor.py (line 6605)
      • Editors\ModelEditor\ModelEditor.py (line 9776)
      • Editors\ModelEditor\ModelEditor.py (line 9956)

🏗️ complete
   📄 Core\AI\PyGenesisAssistant\Nova\core\tasks.py (line 53)
   ⚠️  Never called

🏗️ from_dict
   📄 Core\AI\PyGenesisAssistant\Nova\core\tasks.py (line 81)
   ⚠️  Never called

🏗️ create_task
   📄 Core\AI\PyGenesisAssistant\Nova\core\tasks.py (line 113)
   📞 Called by:
      • Core\AI\PyGenesisAssistant\Nova\core\workflow.py (line 162)
      • Core\AI\PyGenesisAssistant\Nova\core\workflow.py (line 196)
      • Core\AI\PyGenesisAssistant\Nova\core\workflow.py (line 226)
      • Core\AI\PyGenesisAssistant\Nova\core\workflow.py (line 259)
      • Core\AI\PyGenesisAssistant\Nova\core\workflow.py (line 300)
      • Core\AI\PyGenesisAssistant\Nova\core\operation_planner.py (line 82)
      • Core\AI\PyGenesisAssistant\Nova\core\operation_planner.py (line 191)
      • Core\AI\PyGenesisAssistant\Nova\core\operation_planner.py (line 199)
      • Core\AI\PyGenesisAssistant\Nova\core\operation_planner.py (line 206)
      • Core\AI\PyGenesisAssistant\Nova\core\operation_planner.py (line 213)
      • Core\AI\PyGenesisAssistant\Nova\core\operation_planner.py (line 250)
      • Core\AI\PyGenesisAssistant\Nova\core\operation_planner.py (line 258)
      • Core\AI\PyGenesisAssistant\Nova\core\operation_planner.py (line 265)
      • Core\AI\PyGenesisAssistant\Nova\core\operation_planner.py (line 272)
      • Core\AI\PyGenesisAssistant\Nova\core\operation_planner.py (line 279)
      • Core\AI\PyGenesisAssistant\Nova\core\operation_planner.py (line 303)
      • Core\AI\PyGenesisAssistant\Nova\core\operation_planner.py (line 317)

🏗️ _generate_task_number
   📄 Core\AI\PyGenesisAssistant\Nova\core\tasks.py (line 160)
   ⚠️  Never called

🏗️ get_task
   📄 Core\AI\PyGenesisAssistant\Nova\core\tasks.py (line 189)
   📞 Called by:
      • Core\AI\PyGenesisAssistant\Nova\ui\tasks_dialog.py (line 293)
      • Core\AI\PyGenesisAssistant\Nova\ui\tasks_dialog.py (line 317)
      • Core\AI\PyGenesisAssistant\Nova\core\workflow.py (line 387)
      • Core\AI\PyGenesisAssistant\Nova\core\workflow.py (line 407)
      • Core\AI\PyGenesisAssistant\Nova\core\workflow.py (line 424)
      • Core\AI\PyGenesisAssistant\Nova\core\workflow.py (line 458)

🏗️ get_tasks
   📄 Core\AI\PyGenesisAssistant\Nova\core\tasks.py (line 196)
   📞 Called by:
      • Core\AI\PyGenesisAssistant\Nova\ui\tasks_dialog.py (line 252)

🏗️ get_pending_tasks
   📄 Core\AI\PyGenesisAssistant\Nova\core\tasks.py (line 212)
   ⚠️  Never called

🏗️ get_active_tasks
   📄 Core\AI\PyGenesisAssistant\Nova\core\tasks.py (line 216)
   ⚠️  Never called

🏗️ get_completed_tasks
   📄 Core\AI\PyGenesisAssistant\Nova\core\tasks.py (line 220)
   ⚠️  Never called

🏗️ delete_task
   📄 Core\AI\PyGenesisAssistant\Nova\core\tasks.py (line 305)
   📞 Called by:
      • Core\AI\PyGenesisAssistant\Nova\ui\tasks_dialog.py (line 277)

🏗️ reorder_task
   📄 Core\AI\PyGenesisAssistant\Nova\core\tasks.py (line 232)
   📞 Called by:
      • Core\AI\PyGenesisAssistant\Nova\ui\tasks_dialog.py (line 300)
      • Core\AI\PyGenesisAssistant\Nova\ui\tasks_dialog.py (line 301)
      • Core\AI\PyGenesisAssistant\Nova\ui\tasks_dialog.py (line 324)
      • Core\AI\PyGenesisAssistant\Nova\ui\tasks_dialog.py (line 325)

🏗️ start_task
   📄 Core\AI\PyGenesisAssistant\Nova\core\tasks.py (line 245)
   📞 Called by:
      • Core\AI\PyGenesisAssistant\Nova\ui\tasks_dialog.py (line 272)

🏗️ complete_task
   📄 Core\AI\PyGenesisAssistant\Nova\core\tasks.py (line 253)
   ⚠️  Never called

🏗️ get_current_task
   📄 Core\AI\PyGenesisAssistant\Nova\core\tasks.py (line 261)
   ⚠️  Never called

🏗️ get_root_tasks
   📄 Core\AI\PyGenesisAssistant\Nova\core\tasks.py (line 266)
   ⚠️  Never called

🏗️ get_child_tasks
   📄 Core\AI\PyGenesisAssistant\Nova\core\tasks.py (line 270)
   ⚠️  Never called

🏗️ get_task_tree
   📄 Core\AI\PyGenesisAssistant\Nova\core\tasks.py (line 277)
   ⚠️  Never called

🏗️ get_all_tasks_hierarchical
   📄 Core\AI\PyGenesisAssistant\Nova\core\tasks.py (line 285)
   ⚠️  Never called

🏗️ add_task_and_children
   📄 Core\AI\PyGenesisAssistant\Nova\core\tasks.py (line 293)
   📞 Called by:
      • Core\AI\PyGenesisAssistant\Nova\core\tasks.py (line 298)
      • Core\AI\PyGenesisAssistant\Nova\core\tasks.py (line 301)

🏗️ process_mouse
   📄 Editors\ModelEditor\examples\GoodPerformanceButOnlyShowsModels.py (line 20)
   📞 Called by:
      • Editors\ModelEditor\examples\GoodPerformanceButOnlyShowsModels.py (line 466)

🏗️ update_vectors
   📄 Editors\ModelEditor\examples\GoodPerformanceButOnlyShowsModels.py (line 34)
   ⚠️  Never called

🏗️ get_view_matrix
   📄 Editors\ModelEditor\examples\GoodPerformanceButOnlyShowsModels.py (line 42)
   📞 Called by:
      • Editors\ModelEditor\examples\GoodPerformanceButOnlyShowsModels.py (line 476)

🏗️ load_obj
   📄 Editors\ModelEditor\examples\GoodPerformanceButOnlyShowsModels.py (line 61)
   📞 Called by:
      • Editors\ModelEditor\ModelEditor.py (line 8171)
      • Editors\ModelEditor\ModelEditor.py (line 10704)

🏗️ load_glb
   📄 Editors\ModelEditor\examples\GoodPerformanceButOnlyShowsModels.py (line 109)
   ⚠️  Never called

🏗️ calculate_normals
   📄 Editors\ModelEditor\examples\GoodPerformanceButOnlyShowsModels.py (line 178)
   ⚠️  Never called

🏗️ load_model
   📄 Editors\ModelEditor\examples\GoodPerformanceButOnlyShowsModels.py (line 202)
   ⚠️  Never called

🏗️ center_and_scale
   📄 Editors\ModelEditor\examples\GoodPerformanceButOnlyShowsModels.py (line 223)
   ⚠️  Never called

🏗️ setup_buffers
   📄 Editors\ModelEditor\examples\GoodPerformanceButOnlyShowsModels.py (line 237)
   ⚠️  Never called

🏗️ render
   📄 Editors\ModelEditor\examples\GoodPerformanceButOnlyShowsModels.py (line 468)
   📞 Called by:
      • Editors\ModelEditor\examples\GoodPerformanceButOnlyShowsModels.py (line 483)
      • Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 3385)

🏗️ create_grid
   📄 Editors\ModelEditor\examples\GoodPerformanceButOnlyShowsModels.py (line 344)
   ⚠️  Never called

🏗️ import_model
   📄 Editors\ModelEditor\examples\GoodPerformanceButOnlyShowsModels.py (line 371)
   📞 Called by:
      • Editors\ModelEditor\ModelEditor.py (line 11952)

🏗️ handle_events
   📄 Editors\ModelEditor\examples\GoodPerformanceButOnlyShowsModels.py (line 402)
   ⚠️  Never called

🏗️ handle_input
   📄 Editors\ModelEditor\examples\GoodPerformanceButOnlyShowsModels.py (line 439)
   ⚠️  Never called

🏗️ delete_pycache
   📄 Core\DeletePyCache.py (line 4)
   📞 Called by:
      • Core\DeletePyCache.py (line 19)
      • main.py (line 573)

🏗️ generate_task_name
   📄 Core\AI\PyGenesisAssistant\Nova\core\task_name_generator.py (line 13)
   📞 Called by:
      • Core\AI\PyGenesisAssistant\Nova\core\workflow.py (line 159)
      • Core\AI\PyGenesisAssistant\Nova\core\workflow.py (line 193)
      • Core\AI\PyGenesisAssistant\Nova\core\workflow.py (line 223)
      • Core\AI\PyGenesisAssistant\Nova\core\workflow.py (line 256)
      • Core\AI\PyGenesisAssistant\Nova\core\workflow.py (line 297)

🏗️ _generate_thumbnail
   📄 Editors\ImageEditor\core\ui\timeline.py (line 74)
   ⚠️  Never called

🏗️ mousePressEvent
   📄 Editors\ImageEditor\core\ui\timeline.py (line 238)
   📞 Called by:
      • Editors\ImageEditor\core\ui\timeline.py (line 247)
      • Core\Rendering\Canvas_2D.py (line 605)

🏗️ mouseDoubleClickEvent
   📄 Editors\ImageEditor\core\ui\timeline.py (line 249)
   📞 Called by:
      • Editors\ImageEditor\core\ui\panels\right_panel.py (line 101)
      • Editors\ImageEditor\core\ui\texture_atlas_dialog.py (line 47)

🏗️ enterEvent
   📄 Editors\ImageEditor\core\ui\timeline.py (line 253)
   ⚠️  Never called

🏗️ leaveEvent
   📄 Editors\ImageEditor\core\ui\timeline.py (line 257)
   📞 Called by:
      • Editors\ModelEditor\ModelEditor.py (line 685)

🏗️ mouseMoveEvent
   📄 Editors\ImageEditor\core\ui\timeline.py (line 1099)
   📞 Called by:
      • Editors\ImageEditor\core\ui\timeline.py (line 270)
      • Editors\ImageEditor\core\ui\timeline.py (line 1110)
      • Core\Rendering\Canvas_2D.py (line 596)
      • Editors\ModelEditor\ModelEditor.py (line 7825)
      • Editors\ModelEditor\ModelEditor.py (line 7828)
      • Editors\ModelEditor\ModelEditor.py (line 7836)

🏗️ mouseReleaseEvent
   📄 Editors\ImageEditor\core\ui\timeline.py (line 1112)
   📞 Called by:
      • Editors\ImageEditor\core\ui\timeline.py (line 288)
      • Editors\ImageEditor\core\ui\timeline.py (line 1136)
      • Core\Rendering\Canvas_2D.py (line 614)
      • Editors\ModelEditor\ModelEditor.py (line 7846)

🏗️ _connect_signals
   📄 Editors\ImageEditor\core\ui\timeline.py (line 485)
   ⚠️  Never called

🏗️ _toggle_color_by_tag
   📄 Editors\ImageEditor\core\ui\timeline.py (line 498)
   ⚠️  Never called

🏗️ _get_tag_color_for_frame
   📄 Editors\ImageEditor\core\ui\timeline.py (line 503)
   ⚠️  Never called

🏗️ set_layers
   📄 Editors\ImageEditor\core\ui\timeline.py (line 526)
   📞 Called by:
      • Editors\ImageEditor\core\ui\panels\right_panel.py (line 866)
      • Editors\Shared\IntegratedImageEditor.py (line 793)
      • Editors\ImageEditor\core\ui\main_window.py (line 1236)
      • Editors\ImageEditor\core\ui\main_window.py (line 1484)

🏗️ set_layer
   📄 Editors\ImageEditor\core\ui\timeline.py (line 557)
   📞 Called by:
      • Editors\ImageEditor\core\ui\main_window.py (line 2101)

🏗️ _update_layer_combo
   📄 Editors\ImageEditor\core\ui\timeline.py (line 567)
   ⚠️  Never called

🏗️ _on_layer_changed
   📄 Editors\ImageEditor\core\ui\timeline.py (line 577)
   ⚠️  Never called

🏗️ _update_timeline
   📄 Editors\ImageEditor\core\ui\timeline.py (line 589)
   📞 Called by:
      • Editors\ImageEditor\core\ui\main_window.py (line 428)
      • Editors\ImageEditor\core\ui\main_window.py (line 1727)

🏗️ _update_selection
   📄 Editors\ImageEditor\core\ui\timeline.py (line 648)
   ⚠️  Never called

🏗️ _frame_clicked
   📄 Editors\ImageEditor\core\ui\timeline.py (line 654)
   ⚠️  Never called

🏗️ _frame_double_clicked
   📄 Editors\ImageEditor\core\ui\timeline.py (line 705)
   ⚠️  Never called

🏗️ _frame_right_clicked
   📄 Editors\ImageEditor\core\ui\timeline.py (line 715)
   ⚠️  Never called

🏗️ _show_frame_context_menu
   📄 Editors\ImageEditor\core\ui\timeline.py (line 719)
   ⚠️  Never called

🏗️ _copy_selected_frames
   📄 Editors\ImageEditor\core\ui\timeline.py (line 848)
   ⚠️  Never called

🏗️ _delete_selected_frames
   📄 Editors\ImageEditor\core\ui\timeline.py (line 866)
   ⚠️  Never called

🏗️ _prev_frame
   📄 Editors\ImageEditor\core\ui\timeline.py (line 896)
   ⚠️  Never called

🏗️ _next_frame
   📄 Editors\ImageEditor\core\ui\timeline.py (line 903)
   ⚠️  Never called

🏗️ _add_frame
   📄 Editors\ImageEditor\core\ui\timeline.py (line 910)
   ⚠️  Never called

🏗️ _delete_frame
   📄 Editors\ImageEditor\core\ui\timeline.py (line 927)
   ⚠️  Never called

🏗️ _delete_frame_at_index
   📄 Editors\ImageEditor\core\ui\timeline.py (line 932)
   ⚠️  Never called

🏗️ _copy_frame
   📄 Editors\ImageEditor\core\ui\timeline.py (line 958)
   ⚠️  Never called

🏗️ _paste_frame
   📄 Editors\ImageEditor\core\ui\timeline.py (line 971)
   ⚠️  Never called

🏗️ _cut_frame
   📄 Editors\ImageEditor\core\ui\timeline.py (line 1006)
   ⚠️  Never called

🏗️ _setup_keyboard_shortcuts
   📄 Editors\ImageEditor\core\ui\timeline.py (line 1017)
   ⚠️  Never called

🏗️ _handle_copy_shortcut
   📄 Editors\ImageEditor\core\ui\timeline.py (line 1046)
   ⚠️  Never called

🏗️ _handle_cut_shortcut
   📄 Editors\ImageEditor\core\ui\timeline.py (line 1055)
   ⚠️  Never called

🏗️ _handle_paste_shortcut
   📄 Editors\ImageEditor\core\ui\timeline.py (line 1070)
   ⚠️  Never called

🏗️ _handle_undo_shortcut
   📄 Editors\ImageEditor\core\ui\timeline.py (line 1075)
   ⚠️  Never called

🏗️ _handle_redo_shortcut
   📄 Editors\ImageEditor\core\ui\timeline.py (line 1084)
   ⚠️  Never called

🏗️ _on_frame_drag_started
   📄 Editors\ImageEditor\core\ui\timeline.py (line 1093)
   ⚠️  Never called

🏗️ _add_tag
   📄 Editors\ImageEditor\core\ui\timeline.py (line 1138)
   ⚠️  Never called

🏗️ _add_tag_to_selection
   📄 Editors\ImageEditor\core\ui\timeline.py (line 1150)
   ⚠️  Never called

🏗️ _remove_tag
   📄 Editors\ImageEditor\core\ui\timeline.py (line 1163)
   ⚠️  Never called

🏗️ _remove_tag_by_name
   📄 Editors\ImageEditor\core\ui\timeline.py (line 1178)
   ⚠️  Never called

🏗️ _remove_tag_from_selection
   📄 Editors\ImageEditor\core\ui\timeline.py (line 1188)
   ⚠️  Never called

🏗️ _clear_tag_from_selection
   📄 Editors\ImageEditor\core\ui\timeline.py (line 1201)
   ⚠️  Never called

🏗️ _set_frame_color
   📄 Editors\ImageEditor\core\ui\timeline.py (line 1225)
   ⚠️  Never called

🏗️ _set_color_for_selection
   📄 Editors\ImageEditor\core\ui\timeline.py (line 1236)
   ⚠️  Never called

🏗️ _clear_frame_color
   📄 Editors\ImageEditor\core\ui\timeline.py (line 1250)
   ⚠️  Never called

🏗️ _clear_color_for_selection
   📄 Editors\ImageEditor\core\ui\timeline.py (line 1259)
   ⚠️  Never called

🏗️ set_current_frame
   📄 Editors\ImageEditor\core\ui\timeline.py (line 1270)
   📞 Called by:
      • Editors\Shared\IntegratedImageEditor.py (line 794)
      • Editors\ImageEditor\core\ui\main_window.py (line 1237)
      • Editors\ImageEditor\core\ui\main_window.py (line 1246)
      • Editors\ImageEditor\core\ui\main_window.py (line 1254)
      • Editors\ImageEditor\core\ui\main_window.py (line 1485)
      • Editors\ImageEditor\core\ui\main_window.py (line 2102)

🏗️ refresh_timeline
   📄 Editors\ImageEditor\core\ui\timeline.py (line 1276)
   ⚠️  Never called

🏗️ _toggle_playback
   📄 Editors\ImageEditor\core\ui\timeline.py (line 1284)
   ⚠️  Never called

🏗️ _start_playback
   📄 Editors\ImageEditor\core\ui\timeline.py (line 1291)
   ⚠️  Never called

🏗️ _pause_playback
   📄 Editors\ImageEditor\core\ui\timeline.py (line 1317)
   ⚠️  Never called

🏗️ _stop_playback
   📄 Editors\ImageEditor\core\ui\timeline.py (line 1326)
   ⚠️  Never called

🏗️ _setup_playback_frames
   📄 Editors\ImageEditor\core\ui\timeline.py (line 1333)
   ⚠️  Never called

🏗️ _playback_step
   📄 Editors\ImageEditor\core\ui\timeline.py (line 1368)
   ⚠️  Never called

🏗️ _on_play_tag_changed
   📄 Editors\ImageEditor\core\ui\timeline.py (line 1387)
   ⚠️  Never called

🏗️ _on_speed_changed
   📄 Editors\ImageEditor\core\ui\timeline.py (line 1407)
   ⚠️  Never called

🏗️ _update_play_tag_combo
   📄 Editors\ImageEditor\core\ui\timeline.py (line 1417)
   ⚠️  Never called

🏗️ parse_json_response
   📄 Editors\ImageEditor\core\core\ai_helpers.py (line 26)
   📞 Called by:
      • Editors\ImageEditor\core\core\gemini_client.py (line 190)
      • Editors\ImageEditor\core\core\gemini_client.py (line 241)
      • Editors\ImageEditor\core\core\gemini_client.py (line 276)

🏗️ extract_json_from_text
   📄 Editors\ImageEditor\core\core\ai_helpers.py (line 45)
   📞 Called by:
      • Editors\ImageEditor\core\core\ai_helpers.py (line 36)

🏗️ extract_json_fallback
   📄 Editors\ImageEditor\core\core\ai_helpers.py (line 68)
   📞 Called by:
      • Editors\ImageEditor\core\core\ai_helpers.py (line 41)

🏗️ clamp_region
   📄 Editors\ImageEditor\core\core\ai_helpers.py (line 104)
   📞 Called by:
      • Editors\ImageEditor\core\core\ai_helpers.py (line 153)
      • Editors\ImageEditor\core\core\ai_helpers.py (line 235)
      • Editors\ImageEditor\core\core\ai_helpers.py (line 236)
      • Editors\ImageEditor\core\core\ai_helpers.py (line 283)
      • Editors\ImageEditor\core\core\ai_helpers.py (line 340)

🏗️ validate_region
   📄 Editors\ImageEditor\core\core\ai_helpers.py (line 133)
   📞 Called by:
      • Editors\ImageEditor\core\core\ai_helpers.py (line 370)
      • Editors\ImageEditor\core\core\ai_helpers.py (line 371)
      • Editors\ImageEditor\core\core\ai_helpers.py (line 376)
      • Editors\ImageEditor\core\core\ai_helpers.py (line 383)
      • Editors\ImageEditor\core\core\ai_helpers.py (line 434)
      • Editors\ImageEditor\core\core\ai_helpers.py (line 435)
      • Editors\ImageEditor\core\core\ai_helpers.py (line 440)
      • Editors\ImageEditor\core\core\ai_helpers.py (line 447)
      • Editors\ImageEditor\core\core\gemini_client.py (line 328)
      • Editors\ImageEditor\core\core\gemini_client.py (line 335)
      • Editors\ImageEditor\core\core\gemini_client.py (line 342)

🏗️ compute_frame_diff
   📄 Editors\ImageEditor\core\core\ai_helpers.py (line 158)
   📞 Called by:
      • Editors\ImageEditor\core\core\ai_helpers.py (line 390)

🏗️ get_cache_key
   📄 Editors\ImageEditor\core\core\ai_helpers.py (line 186)
   📞 Called by:
      • Editors\ImageEditor\core\core\gemini_client.py (line 62)
      • Editors\ImageEditor\core\core\gemini_client.py (line 138)

🏗️ get_cached_response
   📄 Editors\ImageEditor\core\core\ai_helpers.py (line 192)
   📞 Called by:
      • Editors\ImageEditor\core\core\gemini_client.py (line 66)
      • Editors\ImageEditor\core\core\gemini_client.py (line 142)

🏗️ cache_response
   📄 Editors\ImageEditor\core\core\ai_helpers.py (line 207)
   📞 Called by:
      • Editors\ImageEditor\core\core\gemini_client.py (line 114)
      • Editors\ImageEditor\core\core\gemini_client.py (line 202)

🏗️ move_region
   📄 Editors\ImageEditor\core\core\ai_helpers.py (line 219)
   📞 Called by:
      • Editors\ImageEditor\core\core\ai_helpers.py (line 373)
      • Editors\ImageEditor\core\core\ai_helpers.py (line 437)

🏗️ modify_region
   📄 Editors\ImageEditor\core\core\ai_helpers.py (line 268)
   📞 Called by:
      • Editors\ImageEditor\core\core\ai_helpers.py (line 380)
      • Editors\ImageEditor\core\core\ai_helpers.py (line 444)

🏗️ paint_region
   📄 Editors\ImageEditor\core\core\ai_helpers.py (line 327)
   📞 Called by:
      • Editors\ImageEditor\core\core\ai_helpers.py (line 386)
      • Editors\ImageEditor\core\core\ai_helpers.py (line 450)

🏗️ generate_frames_parallel
   📄 Editors\ImageEditor\core\core\ai_helpers.py (line 346)
   📞 Called by:
      • Editors\ImageEditor\core\core\ai_worker_threads.py (line 110)
      • Editors\ImageEditor\core\ui\main_window.py (line 2403)

🏗️ generate_single_frame
   📄 Editors\ImageEditor\core\core\ai_helpers.py (line 362)
   ⚠️  Never called

🏗️ apply_cumulative_changes
   📄 Editors\ImageEditor\core\core\ai_helpers.py (line 412)
   📞 Called by:
      • Editors\ImageEditor\core\core\ai_worker_threads.py (line 106)
      • Editors\ImageEditor\core\ui\main_window.py (line 2400)

🏗️ _preload_image_editor
   📄 Core\ModulePreloader.py (line 48)
   ⚠️  Never called

🏗️ _preload_sprite_editor
   📄 Core\ModulePreloader.py (line 60)
   ⚠️  Never called

🏗️ _preload_sound_editor
   📄 Core\ModulePreloader.py (line 64)
   ⚠️  Never called

🏗️ _preload_model_editor
   📄 Core\ModulePreloader.py (line 69)
   ⚠️  Never called

🏗️ _preload_room_editor
   📄 Core\ModulePreloader.py (line 73)
   ⚠️  Never called

🏗️ _preload_object_editor
   📄 Core\ModulePreloader.py (line 77)
   ⚠️  Never called

🏗️ _preload_code_editor
   📄 Core\ModulePreloader.py (line 81)
   ⚠️  Never called

🏗️ preload_image_editor_modules
   📄 Core\ModulePreloader.py (line 102)
   ⚠️  Never called

🏗️ preload_all_editors
   📄 Core\ModulePreloader.py (line 114)
   ⚠️  Never called

🏗️ make_handler
   📄 Core\ModulePreloader.py (line 136)
   📞 Called by:
      • Core\ModulePreloader.py (line 146)

🏗️ handler
   📄 Core\ModulePreloader.py (line 137)
   ⚠️  Never called

🏗️ timeout_check
   📄 Core\ModulePreloader.py (line 156)
   ⚠️  Never called

🏗️ _on_editor_preloaded
   📄 Core\ModulePreloader.py (line 173)
   ⚠️  Never called

🏗️ _do_preload
   📄 Core\ModulePreloader.py (line 184)
   ⚠️  Never called

🏗️ are_modules_preloaded
   📄 Core\ModulePreloader.py (line 223)
   ⚠️  Never called

🏗️ is_editor_preloaded
   📄 Core\ModulePreloader.py (line 227)
   ⚠️  Never called

🏗️ get_preloaded_modules
   📄 Core\ModulePreloader.py (line 231)
   ⚠️  Never called

🏗️ parse
   📄 Core\CodeSystem\parser.py (line 36)
   📞 Called by:
      • Core\GameGenerator.py (line 422)

🏗️ is_at_end
   📄 Core\CodeSystem\parser.py (line 54)
   ⚠️  Never called

🏗️ peek
   📄 Core\CodeSystem\parser.py (line 58)
   ⚠️  Never called

🏗️ previous
   📄 Core\CodeSystem\parser.py (line 64)
   ⚠️  Never called

🏗️ check
   📄 Core\CodeSystem\parser.py (line 74)
   ⚠️  Never called

🏗️ match
   📄 Core\CodeSystem\parser.py (line 80)
   ⚠️  Never called

🏗️ consume
   📄 Core\CodeSystem\parser.py (line 88)
   ⚠️  Never called

🏗️ statement
   📄 Core\CodeSystem\parser.py (line 94)
   ⚠️  Never called

🏗️ if_statement
   📄 Core\CodeSystem\parser.py (line 111)
   ⚠️  Never called

🏗️ while_statement
   📄 Core\CodeSystem\parser.py (line 130)
   ⚠️  Never called

🏗️ for_statement
   📄 Core\CodeSystem\parser.py (line 141)
   ⚠️  Never called

🏗️ return_statement
   📄 Core\CodeSystem\parser.py (line 156)
   ⚠️  Never called

🏗️ variable_declaration
   📄 Core\CodeSystem\parser.py (line 167)
   ⚠️  Never called

🏗️ function_declaration
   📄 Core\CodeSystem\parser.py (line 182)
   ⚠️  Never called

🏗️ expression_statement
   📄 Core\CodeSystem\parser.py (line 208)
   ⚠️  Never called

🏗️ block
   📄 Core\CodeSystem\parser.py (line 214)
   ⚠️  Never called

🏗️ expression
   📄 Core\CodeSystem\parser.py (line 239)
   ⚠️  Never called

🏗️ assignment
   📄 Core\CodeSystem\parser.py (line 243)
   ⚠️  Never called

🏗️ or_expr
   📄 Core\CodeSystem\parser.py (line 258)
   ⚠️  Never called

🏗️ and_expr
   📄 Core\CodeSystem\parser.py (line 269)
   ⚠️  Never called

🏗️ equality
   📄 Core\CodeSystem\parser.py (line 280)
   ⚠️  Never called

🏗️ comparison
   📄 Core\CodeSystem\parser.py (line 291)
   ⚠️  Never called

🏗️ term
   📄 Core\CodeSystem\parser.py (line 303)
   ⚠️  Never called

🏗️ factor
   📄 Core\CodeSystem\parser.py (line 314)
   ⚠️  Never called

🏗️ unary
   📄 Core\CodeSystem\parser.py (line 325)
   ⚠️  Never called

🏗️ call
   📄 Core\CodeSystem\parser.py (line 334)
   ⚠️  Never called

🏗️ finish_call
   📄 Core\CodeSystem\parser.py (line 350)
   ⚠️  Never called

🏗️ primary
   📄 Core\CodeSystem\parser.py (line 368)
   ⚠️  Never called

🏗️ load_training_data
   📄 Core\AI\PyGenesisAssistant\Nova\core\slm\train_model.py (line 31)
   📞 Called by:
      • Core\AI\PyGenesisAssistant\Nova\core\slm\train_model.py (line 171)

🏗️ augment_training_data
   📄 Core\AI\PyGenesisAssistant\Nova\core\slm\train_model.py (line 58)
   📞 Called by:
      • Core\AI\PyGenesisAssistant\Nova\core\slm\train_model.py (line 205)

🏗️ load_misclassifications
   📄 Core\AI\PyGenesisAssistant\Nova\core\slm\train_model.py (line 84)
   📞 Called by:
      • Core\AI\PyGenesisAssistant\Nova\core\slm\train_model.py (line 175)

🏗️ clear_misclassifications
   📄 Core\AI\PyGenesisAssistant\Nova\core\slm\train_model.py (line 101)
   ⚠️  Never called

🏗️ create_model
   📄 Core\AI\PyGenesisAssistant\Nova\core\slm\train_model.py (line 112)
   📞 Called by:
      • Core\AI\PyGenesisAssistant\Nova\core\slm\train_model.py (line 283)

🏗️ prepare_training_data
   📄 Core\AI\PyGenesisAssistant\Nova\core\slm\train_model.py (line 131)
   📞 Called by:
      • Core\AI\PyGenesisAssistant\Nova\core\slm\train_model.py (line 273)

🏗️ train_model
   📄 Core\AI\PyGenesisAssistant\Nova\core\slm\train_model.py (line 182)
   📞 Called by:
      • Core\AI\PyGenesisAssistant\Nova\core\slm\train_model.py (line 295)

🏗️ test_model
   📄 Core\AI\PyGenesisAssistant\Nova\core\slm\train_model.py (line 225)
   📞 Called by:
      • Core\AI\PyGenesisAssistant\Nova\core\slm\train_model.py (line 314)

🏗️ is_admin
   📄 Editors\ImageEditor\core\core\admin_elevator.py (line 14)
   📞 Called by:
      • Editors\ImageEditor\core\core\admin_elevator.py (line 44)

🏗️ run_pip_with_admin
   📄 Editors\ImageEditor\core\core\admin_elevator.py (line 22)
   ⚠️  Never called

🏗️ _install_package
   📄 Core\PackageInstaller.py (line 65)
   ⚠️  Never called

🏗️ _update_package
   📄 Core\PackageInstaller.py (line 133)
   ⚠️  Never called

🏗️ _uninstall_package
   📄 Core\PackageInstaller.py (line 156)
   ⚠️  Never called

🏗️ _check_undefined_variables
   📄 Core\CodeSystem\syntax.py (line 154)
   ⚠️  Never called

🏗️ _check_unused_variables
   📄 Core\CodeSystem\syntax.py (line 159)
   ⚠️  Never called

🏗️ generate_from_templates
   📄 Core\AI\PyGenesisAssistant\Nova\core\slm\generate_training_data.py (line 13)
   📞 Called by:
      • Core\AI\PyGenesisAssistant\Nova\core\slm\generate_training_data.py (line 115)

🏗️ load_manual_examples
   📄 Core\AI\PyGenesisAssistant\Nova\core\slm\generate_training_data.py (line 66)
   📞 Called by:
      • Core\AI\PyGenesisAssistant\Nova\core\slm\generate_training_data.py (line 121)

🏗️ _bootstrap
   📄 Core\AI\PyGenesisAssistant\Nova\core\slm\tiny_intent_model.py (line 54)
   ⚠️  Never called

🏗️ _load
   📄 Core\AI\PyGenesisAssistant\Nova\core\slm\tiny_intent_model.py (line 90)
   ⚠️  Never called

🏗️ predict
   📄 Core\AI\PyGenesisAssistant\Nova\core\slm\tiny_intent_model.py (line 97)
   📞 Called by:
      • Editors\ImageEditor\core\core\selection_manager.py (line 361)
      • Core\AI\PyGenesisAssistant\Nova\core\intent_router.py (line 301)

🏗️ train
   📄 Core\AI\PyGenesisAssistant\Nova\core\slm\tiny_intent_model.py (line 127)
   ⚠️  Never called

🏗️ startDrag
   📄 Editors\ImageEditor\core\ui\texture_atlas_dialog.py (line 29)
   📞 Called by:
      • Editors\ImageEditor\core\ui\texture_atlas_dialog.py (line 32)

🏗️ dropEvent
   📄 Editors\ImageEditor\core\ui\texture_atlas_dialog.py (line 34)
   📞 Called by:
      • Editors\ImageEditor\core\ui\texture_atlas_dialog.py (line 36)

🏗️ toggle_play
   📄 Editors\ImageEditor\core\ui\texture_atlas_dialog.py (line 135)
   📞 Called by:
      • Editors\ImageEditor\core\ui\main_window.py (line 990)

🏗️ next_frame
   📄 Editors\ImageEditor\core\ui\texture_atlas_dialog.py (line 145)
   📞 Called by:
      • Editors\ImageEditor\core\ui\main_window.py (line 994)

🏗️ prev_frame
   📄 Editors\ImageEditor\core\ui\texture_atlas_dialog.py (line 151)
   📞 Called by:
      • Editors\ImageEditor\core\ui\main_window.py (line 992)

🏗️ set_cell_index
   📄 Editors\ImageEditor\core\ui\texture_atlas_dialog.py (line 157)
   ⚠️  Never called

🏗️ create_options_tab
   📄 Editors\ImageEditor\core\ui\texture_atlas_dialog.py (line 207)
   ⚠️  Never called

🏗️ on_style_changed
   📄 Editors\ImageEditor\core\ui\texture_atlas_dialog.py (line 288)
   ⚠️  Never called

🏗️ on_animated_changed
   📄 Editors\ImageEditor\core\ui\texture_atlas_dialog.py (line 296)
   ⚠️  Never called

🏗️ on_block_size_changed
   📄 Editors\ImageEditor\core\ui\texture_atlas_dialog.py (line 306)
   ⚠️  Never called

🏗️ on_ores_changed
   📄 Editors\ImageEditor\core\ui\texture_atlas_dialog.py (line 313)
   ⚠️  Never called

🏗️ on_num_ores_changed
   📄 Editors\ImageEditor\core\ui\texture_atlas_dialog.py (line 320)
   ⚠️  Never called

🏗️ pick_color
   📄 Editors\ImageEditor\core\ui\texture_atlas_dialog.py (line 327)
   ⚠️  Never called

🏗️ update_from_cell
   📄 Editors\ImageEditor\core\ui\texture_atlas_dialog.py (line 356)
   ⚠️  Never called

🏗️ _check_and_start_timer
   📄 Editors\ImageEditor\core\ui\texture_atlas_dialog.py (line 587)
   ⚠️  Never called

🏗️ update_timer_state
   📄 Editors\ImageEditor\core\ui\texture_atlas_dialog.py (line 597)
   📞 Called by:
      • Editors\ImageEditor\core\ui\texture_atlas_dialog.py (line 304)
      • Editors\ImageEditor\core\ui\texture_atlas_dialog.py (line 763)
      • Editors\ImageEditor\core\ui\texture_atlas_dialog.py (line 773)

🏗️ _get_cell_at_pos
   📄 Editors\ImageEditor\core\ui\texture_atlas_dialog.py (line 601)
   ⚠️  Never called

🏗️ connect_signals
   📄 Editors\ImageEditor\core\ui\texture_atlas_dialog.py (line 718)
   ⚠️  Never called

🏗️ update_grid_list
   📄 Editors\ImageEditor\core\ui\texture_atlas_dialog.py (line 725)
   ⚠️  Never called

🏗️ on_cell_selected
   📄 Editors\ImageEditor\core\ui\texture_atlas_dialog.py (line 734)
   ⚠️  Never called

🏗️ open_grid_settings
   📄 Editors\ImageEditor\core\ui\texture_atlas_dialog.py (line 739)
   ⚠️  Never called

🏗️ on_grid_reordered
   📄 Editors\ImageEditor\core\ui\texture_atlas_dialog.py (line 749)
   ⚠️  Never called

🏗️ add_grid
   📄 Editors\ImageEditor\core\ui\texture_atlas_dialog.py (line 758)
   ⚠️  Never called

🏗️ delete_grid
   📄 Editors\ImageEditor\core\ui\texture_atlas_dialog.py (line 766)
   ⚠️  Never called

🏗️ open_atlas_options
   📄 Editors\ImageEditor\core\ui\texture_atlas_dialog.py (line 777)
   ⚠️  Never called

🏗️ mark_changes_unsaved
   📄 Editors\ImageEditor\core\ui\texture_atlas_dialog.py (line 783)
   ⚠️  Never called

🏗️ mark_changes_saved
   📄 Editors\ImageEditor\core\ui\texture_atlas_dialog.py (line 790)
   ⚠️  Never called

🏗️ update_window_title
   📄 Editors\ImageEditor\core\ui\texture_atlas_dialog.py (line 797)
   📞 Called by:
      • Core\ResourceManager.py (line 706)

🏗️ closeEvent
   📄 Editors\ImageEditor\core\ui\texture_atlas_dialog.py (line 805)
   📞 Called by:
      • Editors\ImageEditor\core\ui\ai_dialogs.py (line 996)
      • Editors\SoundEditor\SoundEditor.py (line 2247)
      • UI\Widgets\TerminalWidget.py (line 299)
      • Editors\ModelEditor\ModelEditor.py (line 692)

🏗️ save_changes
   📄 Editors\ImageEditor\core\ui\texture_atlas_dialog.py (line 825)
   ⚠️  Never called

🏗️ apply_atlas_to_layer_and_close
   📄 Editors\ImageEditor\core\ui\texture_atlas_dialog.py (line 830)
   ⚠️  Never called

🏗️ apply_atlas_to_layer
   📄 Editors\ImageEditor\core\ui\texture_atlas_dialog.py (line 845)
   ⚠️  Never called

🏗️ fuzzy_score
   📄 Core\ExtensionsManager.py (line 32)
   📞 Called by:
      • Core\ExtensionsManager.py (line 619)
      • Core\ExtensionsManager.py (line 629)

🏗️ fetch_all_pypi_names
   📄 Core\ExtensionsManager.py (line 57)
   📞 Called by:
      • Core\ExtensionsManager.py (line 556)

🏗️ get_pypi_info
   📄 Core\ExtensionsManager.py (line 74)
   📞 Called by:
      • Core\ExtensionsManager.py (line 486)

🏗️ _load_pypi_cache
   📄 Core\ExtensionsManager.py (line 154)
   ⚠️  Never called

🏗️ _save_pypi_cache
   📄 Core\ExtensionsManager.py (line 165)
   ⚠️  Never called

🏗️ _load_installed_packages_cache
   📄 Core\ExtensionsManager.py (line 175)
   ⚠️  Never called

🏗️ _save_installed_packages_cache
   📄 Core\ExtensionsManager.py (line 200)
   ⚠️  Never called

🏗️ clear_installed_packages_cache
   📄 Core\ExtensionsManager.py (line 217)
   ⚠️  Never called

🏗️ get_all_installed_packages
   📄 Core\ExtensionsManager.py (line 232)
   📞 Called by:
      • UI\CommonDialogs\ExtensionsDialog.py (line 617)
      • UI\CommonDialogs\ExtensionsDialog.py (line 671)

🏗️ get_outdated_packages
   📄 Core\ExtensionsManager.py (line 285)
   📞 Called by:
      • UI\CommonDialogs\ExtensionsDialog.py (line 413)

🏗️ get_all_installed_libraries
   📄 Core\ExtensionsManager.py (line 350)
   📞 Called by:
      • Core\PackageLoadThread.py (line 28)
      • UI\CommonDialogs\ExtensionsDialog.py (line 329)

🏗️ get_core_libraries
   📄 Core\ExtensionsManager.py (line 433)
   ⚠️  Never called

🏗️ get_optional_libraries
   📄 Core\ExtensionsManager.py (line 438)
   ⚠️  Never called

🏗️ check_package_installed
   📄 Core\ExtensionsManager.py (line 447)
   📞 Called by:
      • UI\CommonDialogs\ExtensionsDialog.py (line 599)
      • UI\CommonDialogs\ExtensionsDialog.py (line 647)
      • UI\CommonDialogs\ExtensionsDialog.py (line 891)
      • UI\CommonDialogs\ExtensionsDialog.py (line 943)
      • UI\CommonDialogs\ExtensionsDialog.py (line 976)

🏗️ get_package_info
   📄 Core\ExtensionsManager.py (line 471)
   📞 Called by:
      • UI\CommonDialogs\ExtensionsDialog.py (line 1003)

🏗️ get_top_packages
   📄 Core\ExtensionsManager.py (line 519)
   📞 Called by:
      • Core\PackageLoadThread.py (line 33)
      • UI\CommonDialogs\ExtensionsDialog.py (line 290)
      • UI\CommonDialogs\ExtensionsDialog.py (line 494)

🏗️ load_pypi_names
   📄 Core\ExtensionsManager.py (line 550)
   📞 Called by:
      • Core\PyPILoadThread.py (line 25)

🏗️ search_pypi
   📄 Core\ExtensionsManager.py (line 581)
   📞 Called by:
      • Core\PackageSearchThread.py (line 28)

🏗️ install_package
   📄 Core\ExtensionsManager.py (line 670)
   📞 Called by:
      • UI\CommonDialogs\ExtensionsDialog.py (line 713)

🏗️ update_package
   📄 Core\ExtensionsManager.py (line 677)
   📞 Called by:
      • UI\CommonDialogs\ExtensionsDialog.py (line 733)

🏗️ uninstall_package
   📄 Core\ExtensionsManager.py (line 684)
   📞 Called by:
      • UI\CommonDialogs\ExtensionsDialog.py (line 753)

🏗️ _on_operation_finished
   📄 Core\ExtensionsManager.py (line 691)
   ⚠️  Never called

🏗️ expand
   📄 Core\AI\PyGenesisAssistant\Nova\core\slm\expand_intent_templates.py (line 5)
   📞 Called by:
      • Core\AI\PyGenesisAssistant\Nova\core\slm\expand_intent_templates.py (line 48)
      • Core\AI\PyGenesisAssistant\Nova\core\slm\Test\expand_intent_templates.py (line 48)

🏗️ generate_all
   📄 Core\AI\PyGenesisAssistant\Nova\core\slm\expand_intent_templates.py (line 41)
   📞 Called by:
      • Core\AI\PyGenesisAssistant\Nova\core\slm\expand_intent_templates.py (line 56)
      • Core\AI\PyGenesisAssistant\Nova\core\slm\Test\expand_intent_templates.py (line 56)

🏗️ _xavier_init
   📄 Core\AI\PyGenesisAssistant\Nova\core\slm\custom_neural_model.py (line 169)
   ⚠️  Never called

🏗️ _relu
   📄 Core\AI\PyGenesisAssistant\Nova\core\slm\custom_neural_model.py (line 177)
   ⚠️  Never called

🏗️ _relu_derivative
   📄 Core\AI\PyGenesisAssistant\Nova\core\slm\custom_neural_model.py (line 181)
   ⚠️  Never called

🏗️ _softmax
   📄 Core\AI\PyGenesisAssistant\Nova\core\slm\custom_neural_model.py (line 185)
   ⚠️  Never called

🏗️ _forward
   📄 Core\AI\PyGenesisAssistant\Nova\core\slm\custom_neural_model.py (line 208)
   ⚠️  Never called

🏗️ _text_to_features
   📄 Core\AI\PyGenesisAssistant\Nova\core\slm\custom_neural_model.py (line 230)
   ⚠️  Never called

🏗️ get_collision_rate
   📄 Core\AI\PyGenesisAssistant\Nova\core\slm\custom_neural_model.py (line 280)
   ⚠️  Never called

🏗️ explain_prediction
   📄 Core\AI\PyGenesisAssistant\Nova\core\slm\custom_neural_model.py (line 360)
   ⚠️  Never called

🏗️ log_misclassification
   📄 Core\AI\PyGenesisAssistant\Nova\core\slm\custom_neural_model.py (line 373)
   ⚠️  Never called

🏗️ get_capabilities_for_intent
   📄 Core\AI\PyGenesisAssistant\Nova\core\slm\custom_neural_model.py (line 415)
   ⚠️  Never called

🏗️ _forward_batch
   📄 Core\AI\PyGenesisAssistant\Nova\core\slm\custom_neural_model.py (line 565)
   ⚠️  Never called

🏗️ _backward
   📄 Core\AI\PyGenesisAssistant\Nova\core\slm\custom_neural_model.py (line 581)
   ⚠️  Never called

🏗️ _save
   📄 Core\AI\PyGenesisAssistant\Nova\core\slm\custom_neural_model.py (line 618)
   ⚠️  Never called

🏗️ promote_to_production
   📄 Core\AI\PyGenesisAssistant\Nova\core\slm\custom_neural_model.py (line 697)
   ⚠️  Never called

🏗️ get_confidence_band
   📄 Core\AI\PyGenesisAssistant\Nova\core\slm\custom_neural_model.py (line 706)
   📞 Called by:
      • Core\AI\PyGenesisAssistant\Nova\core\workflow.py (line 280)

🏗️ should_ask_clarification
   📄 Core\AI\PyGenesisAssistant\Nova\core\slm\custom_neural_model.py (line 723)
   ⚠️  Never called

🏗️ set_confidence_threshold
   📄 Core\AI\PyGenesisAssistant\Nova\core\slm\custom_neural_model.py (line 735)
   ⚠️  Never called

🏗️ generate_game
   📄 Core\GameGenerator.py (line 29)
   ⚠️  Never called

🏗️ _get_rooms
   📄 Core\GameGenerator.py (line 59)
   ⚠️  Never called

🏗️ _get_objects
   📄 Core\GameGenerator.py (line 70)
   ⚠️  Never called

🏗️ _get_sprites
   📄 Core\GameGenerator.py (line 75)
   ⚠️  Never called

🏗️ _generate_main_script
   📄 Core\GameGenerator.py (line 80)
   ⚠️  Never called

🏗️ _generate_runtime
   📄 Core\GameGenerator.py (line 172)
   ⚠️  Never called

🏗️ _generate_objects
   📄 Core\GameGenerator.py (line 343)
   ⚠️  Never called

🏗️ _indent_code
   📄 Core\GameGenerator.py (line 432)
   ⚠️  Never called

🏗️ _generate_room_list
   📄 Core\GameGenerator.py (line 447)
   ⚠️  Never called

🏗️ _get_setting
   📄 Core\GameGenerator.py (line 463)
   ⚠️  Never called

🏗️ get_template
   📄 Core\AI\PyGenesisAssistant\Nova\core\response_templates.py (line 146)
   ⚠️  Never called

🏗️ format_options_response
   📄 Core\AI\PyGenesisAssistant\Nova\core\response_templates.py (line 151)
   ⚠️  Never called

🏗️ format_explanation_response
   📄 Core\AI\PyGenesisAssistant\Nova\core\response_templates.py (line 171)
   ⚠️  Never called

🏗️ format_plan_preview
   📄 Core\AI\PyGenesisAssistant\Nova\core\response_templates.py (line 192)
   📞 Called by:
      • Core\AI\PyGenesisAssistant\Nova\core\workflow.py (line 396)

🏗️ format_confirmation_request
   📄 Core\AI\PyGenesisAssistant\Nova\core\response_templates.py (line 201)
   📞 Called by:
      • Core\AI\PyGenesisAssistant\Nova\core\workflow.py (line 416)

🏗️ format_clarification_request
   📄 Core\AI\PyGenesisAssistant\Nova\core\response_templates.py (line 207)
   📞 Called by:
      • Core\AI\PyGenesisAssistant\Nova\core\workflow.py (line 317)
      • Core\AI\PyGenesisAssistant\Nova\core\workflow.py (line 329)

🏗️ format_execution_report
   📄 Core\AI\PyGenesisAssistant\Nova\core\response_templates.py (line 216)
   ⚠️  Never called

🏗️ get_follow_up_question
   📄 Core\AI\PyGenesisAssistant\Nova\core\response_templates.py (line 225)
   ⚠️  Never called

🏗️ get_meta_prefix
   📄 Core\AI\PyGenesisAssistant\Nova\core\response_templates.py (line 232)
   ⚠️  Never called

🏗️ get_greeting_response
   📄 Core\AI\PyGenesisAssistant\Nova\core\response_templates.py (line 239)
   ⚠️  Never called

🏗️ check_and_install
   📄 check_dependencies.py (line 16)
   📞 Called by:
      • check_dependencies.py (line 60)
      • check_dependencies.py (line 67)

🏗️ set_var
   📄 Editors\CodeEditor\pgsl_runtime.py (line 26)
   ⚠️  Never called

🏗️ get_var
   📄 Editors\CodeEditor\pgsl_runtime.py (line 29)
   ⚠️  Never called

🏗️ exists
   📄 Editors\CodeEditor\pgsl_runtime.py (line 32)
   📞 Called by:
      • Core\AI\PyGenesisAssistant\Nova\core\engines\conversation_engine.py (line 134)
      • Core\AI\PyGenesisAssistant\Nova\core\project_scanner.py (line 39)
      • Core\AI\PyGenesisAssistant\Nova\core\project_scanner.py (line 102)
      • Core\AI\PyGenesisAssistant\Nova\core\project_scanner.py (line 106)
      • Core\AI\PyGenesisAssistant\Nova\ui\project_management_dialog.py (line 342)
      • Editors\ImageEditor\core\ui\dialogs\preferences_dialog.py (line 159)
      • Editors\ImageEditor\core\ui\dialogs\preferences_dialog.py (line 181)
      • Core\AI\PyGenesisAssistant\Nova\settings.py (line 58)
      • Core\ProjectIndexManager.py (line 73)
      • Core\ProjectIndexManager.py (line 107)
      • Core\AI\PyGenesisAssistant\Nova\core\transaction_manager.py (line 164)
      • Core\AI\PyGenesisAssistant\Nova\core\transaction_manager.py (line 231)
      • Core\AI\PyGenesisAssistant\Nova\core\transaction_manager.py (line 260)
      • Core\AI\PyGenesisAssistant\Nova\core\transaction_manager.py (line 384)
      • Core\AI\PyGenesisAssistant\Nova\core\transaction_manager.py (line 401)
      • Core\AI\PyGenesisAssistant\Nova\core\transaction_manager.py (line 494)
      • Editors\ImageEditor\core\core\admin_elevator.py (line 142)
      • Editors\ImageEditor\core\ui\texture_atlas_dialog.py (line 893)
      • Editors\BackgroundEditor\BackgroundEditor.py (line 371)
      • Core\ProjectManager.py (line 153)
      • Core\ProjectManager.py (line 389)
      • Core\ProjectManager.py (line 423)
      • Core\ProjectManager.py (line 440)
      • Core\ProjectManager.py (line 468)
      • Core\ProjectManager.py (line 486)
      • Core\ProjectManager.py (line 494)
      • Core\ProjectManager.py (line 521)
      • Core\ProjectManager.py (line 542)
      • Core\ProjectManager.py (line 550)
      • Core\ProjectManager.py (line 561)
      • Core\ProjectManager.py (line 568)
      • Core\ProjectManager.py (line 580)
      • Core\ProjectManager.py (line 596)
      • Core\ProjectManager.py (line 603)
      • Core\ProjectManager.py (line 613)
      • Core\ProjectManager.py (line 620)
      • Core\ProjectManager.py (line 631)
      • Core\ProjectManager.py (line 638)
      • Core\ProjectManager.py (line 668)
      • Core\ProjectManager.py (line 687)
      • Core\ProjectManager.py (line 698)
      • Core\ProjectManager.py (line 727)
      • Core\ProjectManager.py (line 752)
      • Core\ProjectManager.py (line 771)
      • Core\ProjectManager.py (line 782)
      • Core\ProjectManager.py (line 816)
      • Core\ProjectManager.py (line 834)
      • Core\ProjectManager.py (line 862)
      • Core\ProjectManager.py (line 873)
      • Core\ProjectManager.py (line 887)
      • Core\ProjectManager.py (line 898)
      • Core\ProjectManager.py (line 914)
      • Core\ProjectManager.py (line 933)
      • Core\ProjectManager.py (line 947)
      • Core\ProjectManager.py (line 1075)
      • Core\ProjectManager.py (line 1310)
      • Core\ProjectManager.py (line 1404)
      • Core\ProjectManager.py (line 1441)
      • Core\ProjectManager.py (line 1449)
      • Core\VenvManager.py (line 42)
      • Core\VenvManager.py (line 71)
      • Core\VenvManager.py (line 99)
      • Core\VenvManager.py (line 124)
      • Core\VenvManager.py (line 133)
      • Core\VenvManager.py (line 134)
      • Core\VenvManager.py (line 135)
      • Core\VenvManager.py (line 136)
      • Core\VenvManager.py (line 137)
      • Core\VenvManager.py (line 145)
      • Core\VenvManager.py (line 154)
      • Core\VenvManager.py (line 356)
      • Core\VenvManager.py (line 363)
      • Core\VenvManager.py (line 439)
      • Core\Rendering\ShaderManager.py (line 106)
      • Editors\ImageEditor\core\core\settings.py (line 20)
      • Editors\ImageEditor\core\core\atlas_manager.py (line 252)
      • Core\UtilityOperations.py (line 143)
      • Core\UtilityOperations.py (line 177)
      • Core\UtilityOperations.py (line 181)
      • Core\UtilityOperations.py (line 425)
      • Core\UtilityOperations.py (line 436)
      • Core\UtilityOperations.py (line 450)
      • Core\ResourceManager.py (line 206)
      • Core\ResourceManager.py (line 290)
      • Core\ResourceManager.py (line 474)
      • Core\ResourceManager.py (line 536)
      • Core\ResourceManager.py (line 563)
      • Core\ResourceManager.py (line 593)
      • Core\ResourceManager.py (line 689)
      • Core\ResourceManager.py (line 737)
      • Core\ResourceManager.py (line 793)
      • Core\ResourceManager.py (line 813)
      • Core\ResourceManager.py (line 867)
      • Core\ResourceManager.py (line 871)
      • Core\ResourceManager.py (line 875)
      • Core\ResourceManager.py (line 888)
      • Core\ResourceManager.py (line 927)
      • Core\ResourceManager.py (line 937)
      • Core\ResourceManager.py (line 952)
      • Core\ResourceManager.py (line 982)
      • Core\ResourceManager.py (line 1003)
      • Core\ResourceManager.py (line 1028)
      • Core\ResourceManager.py (line 1065)
      • Core\ResourceManager.py (line 1086)
      • Core\ResourceManager.py (line 1129)
      • Core\ResourceManager.py (line 1137)
      • Core\ResourceManager.py (line 1162)
      • Core\ResourceManager.py (line 1169)
      • Core\ResourceManager.py (line 1170)
      • Core\ResourceManager.py (line 1189)
      • Core\ResourceManager.py (line 1198)
      • Core\ResourceManager.py (line 1216)
      • Core\ResourceManager.py (line 1294)
      • Core\ResourceManager.py (line 1303)
      • Core\ResourceManager.py (line 1390)
      • Core\ResourceManager.py (line 1506)
      • Core\ResourceManager.py (line 1513)
      • Core\ResourceManager.py (line 1526)
      • Core\ResourceManager.py (line 1571)
      • Core\ResourceManager.py (line 1583)
      • Core\ResourceManager.py (line 1596)
      • Core\ResourceManager.py (line 1628)
      • Core\ResourceManager.py (line 1641)
      • Core\ResourceManager.py (line 1703)
      • Core\ResourceManager.py (line 1832)
      • Core\ResourceManager.py (line 1858)
      • Core\ThumbnailCache.py (line 42)
      • Core\ThumbnailCache.py (line 88)
      • Core\ThumbnailCache.py (line 192)
      • Core\AI\PyGenesisAssistant\Nova\core\engines\research_engine.py (line 61)
      • Core\Services\incremental_resource_reloader.py (line 101)
      • Core\Services\incremental_resource_reloader.py (line 157)
      • Core\Services\file_service.py (line 29)
      • Core\Services\file_service.py (line 63)
      • Core\AI\PyGenesisAssistant\Nova\core\ast_scanner.py (line 82)
      • Core\AI\PyGenesisAssistant\Nova\core\ast_scanner.py (line 123)
      • Core\AI\PyGenesisAssistant\Nova\core\intent_router.py (line 577)
      • Core\AI\PyGenesisAssistant\Nova\core\intent_router.py (line 581)
      • Core\AI\PyGenesisAssistant\Nova\core\executors\resource_operation_executor.py (line 611)
      • Core\AI\PyGenesisAssistant\Nova\core\executors\resource_operation_executor.py (line 645)
      • Core\AI\PyGenesisAssistant\Nova\core\executors\resource_operation_executor.py (line 690)
      • Core\AI\PyGenesisAssistant\Nova\core\executors\resource_operation_executor.py (line 694)
      • Editors\TextureEditor\TextureEditor.py (line 109)
      • Editors\TextureEditor\TextureEditor.py (line 665)
      • Editors\TextureEditor\TextureEditor.py (line 673)
      • Editors\TextureEditor\TextureEditor.py (line 695)
      • Editors\TextureEditor\TextureEditor.py (line 712)
      • UI\CommonDialogs\BackupFolderDialog.py (line 100)
      • UI\CommonDialogs\ResourceFolderDialog.py (line 94)
      • UI\CommonDialogs\RestoreDialog.py (line 99)
      • Editors\SoundEditor\SoundEditor.py (line 829)
      • Editors\SoundEditor\SoundEditor.py (line 1518)
      • Editors\SoundEditor\SoundEditor.py (line 1660)
      • Editors\SoundEditor\SoundEditor.py (line 1711)
      • Editors\SoundEditor\SoundEditor.py (line 1932)
      • Editors\SoundEditor\SoundEditor.py (line 2529)
      • Editors\SoundEditor\SoundEditor.py (line 2555)
      • Editors\SoundEditor\SoundEditor.py (line 2573)
      • Editors\SoundEditor\SoundEditor.py (line 2784)
      • Editors\SoundEditor\SoundEditor.py (line 2794)
      • Editors\SoundEditor\SoundEditor.py (line 2933)
      • UI\Widgets\ResourceTree.py (line 257)
      • UI\Widgets\ResourceTree.py (line 342)
      • UI\Widgets\ResourceTree.py (line 468)
      • UI\Widgets\ResourceTree.py (line 488)
      • UI\Widgets\ResourceTree.py (line 492)
      • UI\Widgets\ResourceTree.py (line 497)
      • UI\Widgets\ResourceTree.py (line 500)
      • UI\Widgets\ResourceTree.py (line 542)
      • UI\Widgets\ResourceTree.py (line 597)
      • UI\Widgets\ResourceTree.py (line 603)
      • UI\Widgets\ResourceTree.py (line 610)
      • UI\Widgets\ResourceTree.py (line 616)
      • UI\Widgets\ResourceTree.py (line 619)
      • UI\Widgets\ResourceTree.py (line 1114)
      • UI\Widgets\ResourceTree.py (line 1225)
      • UI\Widgets\ResourceTree.py (line 1328)
      • UI\Widgets\ResourceTree.py (line 1383)
      • UI\Widgets\ResourceTree.py (line 1510)
      • UI\Widgets\ResourceTree.py (line 1676)
      • UI\Widgets\ResourceTree.py (line 1681)
      • UI\Widgets\ResourceTree.py (line 1754)
      • UI\Widgets\ResourceTree.py (line 1874)
      • UI\CommonDialogs\PreferencesDialog.py (line 2229)
      • UI\CommonDialogs\PreferencesDialog.py (line 2388)
      • UI\CommonDialogs\PreferencesDialog.py (line 2593)
      • UI\CommonDialogs\PreferencesDialog.py (line 2758)
      • main.py (line 48)
      • UI\Widgets\ThumbnailLoader.py (line 115)
      • UI\Widgets\ThumbnailLoader.py (line 153)
      • UI\Widgets\ThumbnailLoader.py (line 157)
      • UI\Widgets\ThumbnailLoader.py (line 177)
      • UI\Widgets\ThumbnailLoader.py (line 224)
      • UI\Widgets\ThumbnailLoader.py (line 230)
      • UI\Widgets\ThumbnailLoader.py (line 237)
      • UI\Widgets\ThumbnailLoader.py (line 243)
      • UI\Widgets\ThumbnailLoader.py (line 246)
      • UI\Widgets\ThumbnailLoader.py (line 289)
      • UI\Widgets\ThumbnailLoader.py (line 325)
      • UI\Widgets\ThumbnailLoader.py (line 328)
      • UI\Widgets\ThumbnailLoader.py (line 352)
      • UI\Widgets\ThumbnailLoader.py (line 359)
      • UI\Widgets\ThumbnailLoader.py (line 365)
      • UI\Widgets\ThumbnailLoader.py (line 372)
      • UI\Widgets\ThumbnailLoader.py (line 376)
      • UI\Widgets\ThumbnailLoader.py (line 413)
      • UI\Widgets\ThumbnailLoader.py (line 419)
      • UI\Widgets\ThumbnailLoader.py (line 426)
      • UI\Widgets\ThumbnailLoader.py (line 432)
      • UI\Widgets\ThumbnailLoader.py (line 435)
      • UI\Widgets\ThumbnailLoader.py (line 471)
      • UI\Widgets\ThumbnailLoader.py (line 478)
      • Tools\ScreenRecording\screen_recorder.py (line 635)
      • Editors\Shared\IntegratedImageEditor.py (line 688)
      • Editors\SoundEditor\core\WaveForge.py (line 1105)
      • Editors\SoundEditor\core\WaveForge.py (line 1141)
      • Editors\SoundEditor\core\WaveForge.py (line 1151)
      • UI\MainWindow\MainWindow.py (line 600)
      • UI\MainWindow\MainWindow.py (line 619)
      • UI\MainWindow\MainWindow.py (line 756)
      • UI\MainWindow\MainWindow.py (line 771)
      • UI\MainWindow\MainWindow.py (line 804)
      • Editors\SpriteEditor\SpriteEditor.py (line 717)
      • Editors\SpriteEditor\SpriteEditor.py (line 891)
      • Editors\SpriteEditor\SpriteEditor.py (line 899)
      • Editors\SpriteEditor\SpriteEditor.py (line 925)
      • Editors\SpriteEditor\SpriteEditor.py (line 950)
      • Editors\ModelEditor\ModelEditor.py (line 175)
      • Editors\ModelEditor\ModelEditor.py (line 182)
      • Editors\ModelEditor\ModelEditor.py (line 188)
      • Editors\ModelEditor\ModelEditor.py (line 192)
      • Editors\ModelEditor\ModelEditor.py (line 202)
      • Editors\ModelEditor\ModelEditor.py (line 605)
      • Editors\ModelEditor\ModelEditor.py (line 766)
      • Editors\ModelEditor\ModelEditor.py (line 917)
      • Editors\ModelEditor\ModelEditor.py (line 1522)
      • Editors\ModelEditor\ModelEditor.py (line 2467)
      • Editors\ModelEditor\ModelEditor.py (line 2480)
      • Editors\ModelEditor\ModelEditor.py (line 2679)
      • Editors\ModelEditor\ModelEditor.py (line 2758)
      • Editors\ModelEditor\ModelEditor.py (line 2764)
      • Editors\ModelEditor\ModelEditor.py (line 2770)
      • Editors\ModelEditor\ModelEditor.py (line 3004)
      • Editors\ModelEditor\ModelEditor.py (line 3010)
      • Editors\ModelEditor\ModelEditor.py (line 3032)
      • Editors\ModelEditor\ModelEditor.py (line 3091)
      • Editors\ModelEditor\ModelEditor.py (line 3427)
      • Editors\ModelEditor\ModelEditor.py (line 4320)
      • Editors\ModelEditor\ModelEditor.py (line 4361)
      • Editors\ModelEditor\ModelEditor.py (line 4479)
      • Editors\ModelEditor\ModelEditor.py (line 4609)
      • Editors\ModelEditor\ModelEditor.py (line 4623)
      • Editors\ModelEditor\ModelEditor.py (line 4693)
      • Editors\ModelEditor\ModelEditor.py (line 5091)
      • Editors\ModelEditor\ModelEditor.py (line 5097)
      • Editors\ModelEditor\ModelEditor.py (line 5102)
      • Editors\ModelEditor\ModelEditor.py (line 5281)
      • Editors\ModelEditor\ModelEditor.py (line 5344)
      • Editors\ModelEditor\ModelEditor.py (line 5446)
      • Editors\ModelEditor\ModelEditor.py (line 5525)
      • Editors\ModelEditor\ModelEditor.py (line 5555)
      • Editors\ModelEditor\ModelEditor.py (line 5606)
      • Editors\ModelEditor\ModelEditor.py (line 5631)
      • Editors\ModelEditor\ModelEditor.py (line 5654)
      • Editors\ModelEditor\ModelEditor.py (line 5664)
      • Editors\ModelEditor\ModelEditor.py (line 5878)
      • Editors\ModelEditor\ModelEditor.py (line 8273)
      • Editors\ModelEditor\ModelEditor.py (line 8280)
      • Editors\ModelEditor\ModelEditor.py (line 8284)
      • Editors\ModelEditor\ModelEditor.py (line 8288)
      • Editors\ModelEditor\ModelEditor.py (line 9267)
      • Editors\ModelEditor\ModelEditor.py (line 9335)
      • Editors\ModelEditor\ModelEditor.py (line 10269)
      • Editors\ModelEditor\ModelEditor.py (line 10287)
      • Editors\ModelEditor\ModelEditor.py (line 10342)
      • Editors\ModelEditor\ModelEditor.py (line 10352)
      • Editors\ModelEditor\ModelEditor.py (line 10695)
      • Editors\ModelEditor\ModelEditor.py (line 10710)
      • Editors\ModelEditor\ModelEditor.py (line 10778)
      • Editors\ModelEditor\ModelEditor.py (line 10797)
      • Editors\ModelEditor\ModelEditor.py (line 10805)
      • Editors\ModelEditor\ModelEditor.py (line 10824)
      • Editors\ModelEditor\ModelEditor.py (line 10856)
      • Editors\ModelEditor\ModelEditor.py (line 10861)
      • Editors\ModelEditor\ModelEditor.py (line 10866)
      • Editors\ModelEditor\ModelEditor.py (line 10930)
      • Editors\ModelEditor\ModelEditor.py (line 10942)
      • Editors\ModelEditor\ModelEditor.py (line 11012)
      • Editors\ModelEditor\ModelEditor.py (line 11110)
      • Editors\ModelEditor\ModelEditor.py (line 11292)
      • Editors\ModelEditor\ModelEditor.py (line 11295)
      • Editors\ModelEditor\ModelEditor.py (line 11317)
      • Editors\ModelEditor\ModelEditor.py (line 11319)
      • Editors\ModelEditor\ModelEditor.py (line 11337)
      • Editors\ModelEditor\ModelEditor.py (line 11368)
      • Editors\ModelEditor\ModelEditor.py (line 11378)
      • Editors\ModelEditor\ModelEditor.py (line 11467)
      • Editors\ModelEditor\ModelEditor.py (line 11534)
      • Editors\ModelEditor\ModelEditor.py (line 11539)
      • Editors\ModelEditor\ModelEditor.py (line 11560)
      • Editors\ModelEditor\ModelEditor.py (line 11572)
      • Editors\ModelEditor\ModelEditor.py (line 11620)
      • Editors\ModelEditor\ModelEditor.py (line 11627)
      • Editors\ModelEditor\ModelEditor.py (line 11631)
      • Editors\ModelEditor\ModelEditor.py (line 11767)
      • Editors\ModelEditor\ModelEditor.py (line 11899)
      • Editors\ModelEditor\ModelEditor.py (line 11945)
      • Editors\ModelEditor\ModelEditor.py (line 11961)
      • Editors\ModelEditor\ModelEditor.py (line 11996)
      • Editors\ModelEditor\ModelEditor.py (line 12002)

🏗️ pgsl_run
   📄 Editors\CodeEditor\pgsl_runtime.py (line 48)
   ⚠️  Never called

🏗️ pgsl_debug_run
   📄 Editors\CodeEditor\pgsl_runtime.py (line 52)
   ⚠️  Never called

🏗️ pgsl_build
   📄 Editors\CodeEditor\pgsl_runtime.py (line 56)
   ⚠️  Never called

🏗️ pgsl_validate
   📄 Editors\CodeEditor\pgsl_runtime.py (line 60)
   ⚠️  Never called

🏗️ pgsl_game_end
   📄 Editors\CodeEditor\pgsl_runtime.py (line 64)
   ⚠️  Never called

🏗️ pgsl_game_save
   📄 Editors\CodeEditor\pgsl_runtime.py (line 68)
   ⚠️  Never called

🏗️ pgsl_game_load
   📄 Editors\CodeEditor\pgsl_runtime.py (line 72)
   ⚠️  Never called

🏗️ pgsl_window_set_size
   📄 Editors\CodeEditor\pgsl_runtime.py (line 76)
   ⚠️  Never called

🏗️ pgsl_window_set_title
   📄 Editors\CodeEditor\pgsl_runtime.py (line 80)
   ⚠️  Never called

🏗️ pgsl_game_set_speed
   📄 Editors\CodeEditor\pgsl_runtime.py (line 84)
   ⚠️  Never called

🏗️ pgsl_room_set_speed
   📄 Editors\CodeEditor\pgsl_runtime.py (line 88)
   ⚠️  Never called

🏗️ pgsl_variable_set
   📄 Editors\CodeEditor\pgsl_runtime.py (line 96)
   ⚠️  Never called

🏗️ pgsl_variable_get
   📄 Editors\CodeEditor\pgsl_runtime.py (line 100)
   ⚠️  Never called

🏗️ pgsl_variable_exists
   📄 Editors\CodeEditor\pgsl_runtime.py (line 104)
   ⚠️  Never called

🏗️ pgsl_wait
   📄 Editors\CodeEditor\pgsl_runtime.py (line 108)
   ⚠️  Never called

🏗️ pgsl_clamp
   📄 Editors\CodeEditor\pgsl_runtime.py (line 112)
   ⚠️  Never called

🏗️ pgsl_point_direction
   📄 Editors\CodeEditor\pgsl_runtime.py (line 116)
   ⚠️  Never called

🏗️ pgsl_point_distance
   📄 Editors\CodeEditor\pgsl_runtime.py (line 121)
   ⚠️  Never called

🏗️ pgsl_random_range
   📄 Editors\CodeEditor\pgsl_runtime.py (line 126)
   ⚠️  Never called

🏗️ pgsl_create_instance
   📄 Editors\CodeEditor\pgsl_runtime.py (line 134)
   ⚠️  Never called

🏗️ pgsl_instance_destroy
   📄 Editors\CodeEditor\pgsl_runtime.py (line 138)
   ⚠️  Never called

🏗️ pgsl_instance_find
   📄 Editors\CodeEditor\pgsl_runtime.py (line 142)
   ⚠️  Never called

🏗️ pgsl_instance_find_id
   📄 Editors\CodeEditor\pgsl_runtime.py (line 146)
   ⚠️  Never called

🏗️ pgsl_instance_find_nearest
   📄 Editors\CodeEditor\pgsl_runtime.py (line 150)
   ⚠️  Never called

🏗️ pgsl_instance_find_furthest
   📄 Editors\CodeEditor\pgsl_runtime.py (line 154)
   ⚠️  Never called

🏗️ pgsl_instance_exists
   📄 Editors\CodeEditor\pgsl_runtime.py (line 158)
   ⚠️  Never called

🏗️ pgsl_instance_get_count
   📄 Editors\CodeEditor\pgsl_runtime.py (line 162)
   ⚠️  Never called

🏗️ pgsl_place_free
   📄 Editors\CodeEditor\pgsl_runtime.py (line 166)
   ⚠️  Never called

🏗️ pgsl_instance_set_active
   📄 Editors\CodeEditor\pgsl_runtime.py (line 170)
   ⚠️  Never called

🏗️ pgsl_move3d_direction
   📄 Editors\CodeEditor\pgsl_runtime.py (line 178)
   ⚠️  Never called

🏗️ pgsl_move3d_stop
   📄 Editors\CodeEditor\pgsl_runtime.py (line 182)
   ⚠️  Never called

🏗️ pgsl_move3d_add_force
   📄 Editors\CodeEditor\pgsl_runtime.py (line 186)
   ⚠️  Never called

🏗️ pgsl_move3d_towards
   📄 Editors\CodeEditor\pgsl_runtime.py (line 190)
   ⚠️  Never called

🏗️ pgsl_draw_self_2d
   📄 Editors\CodeEditor\pgsl_runtime.py (line 198)
   ⚠️  Never called

🏗️ pgsl_draw_sprite_2d
   📄 Editors\CodeEditor\pgsl_runtime.py (line 202)
   ⚠️  Never called

🏗️ pgsl_draw_text_2d
   📄 Editors\CodeEditor\pgsl_runtime.py (line 206)
   ⚠️  Never called

🏗️ pgsl_draw_model_3d
   📄 Editors\CodeEditor\pgsl_runtime.py (line 210)
   ⚠️  Never called

🏗️ pgsl_draw_model_instanced
   📄 Editors\CodeEditor\pgsl_runtime.py (line 214)
   ⚠️  Never called

🏗️ pgsl_draw_2d
   📄 Editors\CodeEditor\pgsl_runtime.py (line 218)
   ⚠️  Never called

🏗️ pgsl_draw_self_3d
   📄 Editors\CodeEditor\pgsl_runtime.py (line 222)
   ⚠️  Never called

🏗️ pgsl_sprite_set_alpha
   📄 Editors\CodeEditor\pgsl_runtime.py (line 226)
   ⚠️  Never called

🏗️ pgsl_sprite_set_2d_size
   📄 Editors\CodeEditor\pgsl_runtime.py (line 230)
   ⚠️  Never called

🏗️ pgsl_sprite_set_color_tint
   📄 Editors\CodeEditor\pgsl_runtime.py (line 234)
   ⚠️  Never called

🏗️ pgsl_model_set_3d_scale
   📄 Editors\CodeEditor\pgsl_runtime.py (line 238)
   ⚠️  Never called

🏗️ pgsl_draw_hud
   📄 Editors\CodeEditor\pgsl_runtime.py (line 246)
   ⚠️  Never called

🏗️ pgsl_draw_hud_text
   📄 Editors\CodeEditor\pgsl_runtime.py (line 250)
   ⚠️  Never called

🏗️ pgsl_draw_bar
   📄 Editors\CodeEditor\pgsl_runtime.py (line 254)
   ⚠️  Never called

🏗️ pgsl_sprite_make_atlas
   📄 Editors\CodeEditor\pgsl_runtime.py (line 262)
   ⚠️  Never called

🏗️ pgsl_sprite_use_atlas
   📄 Editors\CodeEditor\pgsl_runtime.py (line 266)
   ⚠️  Never called

🏗️ pgsl_sprite_use_atlas_tile
   📄 Editors\CodeEditor\pgsl_runtime.py (line 270)
   ⚠️  Never called

🏗️ pgsl_sprite_get_width
   📄 Editors\CodeEditor\pgsl_runtime.py (line 274)
   ⚠️  Never called

🏗️ pgsl_sprite_get_height
   📄 Editors\CodeEditor\pgsl_runtime.py (line 278)
   ⚠️  Never called

🏗️ pgsl_sprite_get_frames
   📄 Editors\CodeEditor\pgsl_runtime.py (line 282)
   ⚠️  Never called

🏗️ pgsl_camera2d_set_position
   📄 Editors\CodeEditor\pgsl_runtime.py (line 290)
   ⚠️  Never called

🏗️ pgsl_camera2d_follow
   📄 Editors\CodeEditor\pgsl_runtime.py (line 294)
   ⚠️  Never called

🏗️ pgsl_camera2d_shake
   📄 Editors\CodeEditor\pgsl_runtime.py (line 298)
   ⚠️  Never called

🏗️ pgsl_camera3d_set_position
   📄 Editors\CodeEditor\pgsl_runtime.py (line 302)
   ⚠️  Never called

🏗️ pgsl_camera3d_set_target
   📄 Editors\CodeEditor\pgsl_runtime.py (line 306)
   ⚠️  Never called

🏗️ pgsl_camera3d_follow
   📄 Editors\CodeEditor\pgsl_runtime.py (line 310)
   ⚠️  Never called

🏗️ pgsl_camera3d_shake
   📄 Editors\CodeEditor\pgsl_runtime.py (line 314)
   ⚠️  Never called

🏗️ pgsl_viewport_create
   📄 Editors\CodeEditor\pgsl_runtime.py (line 318)
   ⚠️  Never called

🏗️ pgsl_viewport_set_camera
   📄 Editors\CodeEditor\pgsl_runtime.py (line 322)
   ⚠️  Never called

🏗️ pgsl_viewport_activate
   📄 Editors\CodeEditor\pgsl_runtime.py (line 326)
   ⚠️  Never called

🏗️ pgsl_sound_play
   📄 Editors\CodeEditor\pgsl_runtime.py (line 334)
   ⚠️  Never called

🏗️ pgsl_sound_stop
   📄 Editors\CodeEditor\pgsl_runtime.py (line 338)
   ⚠️  Never called

🏗️ pgsl_sound_stop_all
   📄 Editors\CodeEditor\pgsl_runtime.py (line 342)
   ⚠️  Never called

🏗️ pgsl_sound_pause_all
   📄 Editors\CodeEditor\pgsl_runtime.py (line 346)
   ⚠️  Never called

🏗️ pgsl_sound_resume_all
   📄 Editors\CodeEditor\pgsl_runtime.py (line 350)
   ⚠️  Never called

🏗️ pgsl_sound_is_active
   📄 Editors\CodeEditor\pgsl_runtime.py (line 354)
   ⚠️  Never called

🏗️ pgsl_key_check
   📄 Editors\CodeEditor\pgsl_runtime.py (line 362)
   ⚠️  Never called

🏗️ pgsl_key_pressed
   📄 Editors\CodeEditor\pgsl_runtime.py (line 366)
   ⚠️  Never called

🏗️ pgsl_key_released
   📄 Editors\CodeEditor\pgsl_runtime.py (line 370)
   ⚠️  Never called

🏗️ pgsl_mouse_position
   📄 Editors\CodeEditor\pgsl_runtime.py (line 374)
   ⚠️  Never called

🏗️ pgsl_mouse_delta
   📄 Editors\CodeEditor\pgsl_runtime.py (line 378)
   ⚠️  Never called

🏗️ pgsl_input_bind
   📄 Editors\CodeEditor\pgsl_runtime.py (line 382)
   ⚠️  Never called

🏗️ pgsl_input_check
   📄 Editors\CodeEditor\pgsl_runtime.py (line 386)
   ⚠️  Never called

🏗️ pgsl_net_host
   📄 Editors\CodeEditor\pgsl_runtime.py (line 394)
   ⚠️  Never called

🏗️ pgsl_net_connect
   📄 Editors\CodeEditor\pgsl_runtime.py (line 398)
   ⚠️  Never called

🏗️ pgsl_net_close
   📄 Editors\CodeEditor\pgsl_runtime.py (line 402)
   ⚠️  Never called

🏗️ pgsl_net_send_all
   📄 Editors\CodeEditor\pgsl_runtime.py (line 406)
   ⚠️  Never called

🏗️ pgsl_net_send_to
   📄 Editors\CodeEditor\pgsl_runtime.py (line 410)
   ⚠️  Never called

🏗️ pgsl_net_get
   📄 Editors\CodeEditor\pgsl_runtime.py (line 414)
   ⚠️  Never called

🏗️ pgsl_net_sync_position
   📄 Editors\CodeEditor\pgsl_runtime.py (line 418)
   ⚠️  Never called

🏗️ pgsl_net_sync_rotation
   📄 Editors\CodeEditor\pgsl_runtime.py (line 422)
   ⚠️  Never called

🏗️ pgsl_net_sync_variable
   📄 Editors\CodeEditor\pgsl_runtime.py (line 426)
   ⚠️  Never called

🏗️ pgsl_net_register_event
   📄 Editors\CodeEditor\pgsl_runtime.py (line 430)
   ⚠️  Never called

🏗️ pgsl_net_my_id
   📄 Editors\CodeEditor\pgsl_runtime.py (line 434)
   ⚠️  Never called

🏗️ pgsl_net_peers
   📄 Editors\CodeEditor\pgsl_runtime.py (line 438)
   ⚠️  Never called

🏗️ pgsl_shader_use
   📄 Editors\CodeEditor\pgsl_runtime.py (line 446)
   ⚠️  Never called

🏗️ pgsl_shader_remove
   📄 Editors\CodeEditor\pgsl_runtime.py (line 450)
   ⚠️  Never called

🏗️ pgsl_shader_set_uniform
   📄 Editors\CodeEditor\pgsl_runtime.py (line 454)
   ⚠️  Never called

🏗️ pgsl_shader_set_uniform_vec3
   📄 Editors\CodeEditor\pgsl_runtime.py (line 458)
   ⚠️  Never called

🏗️ pgsl_shader_set_uniform_color
   📄 Editors\CodeEditor\pgsl_runtime.py (line 462)
   ⚠️  Never called

🏗️ pgsl_shader_use_object
   📄 Editors\CodeEditor\pgsl_runtime.py (line 466)
   ⚠️  Never called

🏗️ pgsl_shader_set_uniform_object
   📄 Editors\CodeEditor\pgsl_runtime.py (line 470)
   ⚠️  Never called

🏗️ pgsl_compute_shader_load
   📄 Editors\CodeEditor\pgsl_runtime.py (line 478)
   ⚠️  Never called

🏗️ pgsl_compute_set_uniform
   📄 Editors\CodeEditor\pgsl_runtime.py (line 482)
   ⚠️  Never called

🏗️ pgsl_compute_buffer_create
   📄 Editors\CodeEditor\pgsl_runtime.py (line 486)
   ⚠️  Never called

🏗️ pgsl_compute_buffer_write
   📄 Editors\CodeEditor\pgsl_runtime.py (line 490)
   ⚠️  Never called

🏗️ pgsl_compute_buffer_read
   📄 Editors\CodeEditor\pgsl_runtime.py (line 494)
   ⚠️  Never called

🏗️ pgsl_compute_shader_run
   📄 Editors\CodeEditor\pgsl_runtime.py (line 498)
   ⚠️  Never called

🏗️ pgsl_particle_system_create
   📄 Editors\CodeEditor\pgsl_runtime.py (line 507)
   ⚠️  Never called

🏗️ pgsl_particle_system_emit
   📄 Editors\CodeEditor\pgsl_runtime.py (line 511)
   ⚠️  Never called

🏗️ pgsl_particle_system_set_uniform
   📄 Editors\CodeEditor\pgsl_runtime.py (line 515)
   ⚠️  Never called

🏗️ pgsl_particle_set_color
   📄 Editors\CodeEditor\pgsl_runtime.py (line 519)
   ⚠️  Never called

🏗️ pgsl_particle_set_color_range
   📄 Editors\CodeEditor\pgsl_runtime.py (line 523)
   ⚠️  Never called

🏗️ pgsl_particle_set_emissive
   📄 Editors\CodeEditor\pgsl_runtime.py (line 527)
   ⚠️  Never called

🏗️ pgsl_bake_mesh_from_map
   📄 Editors\CodeEditor\pgsl_runtime.py (line 535)
   ⚠️  Never called

🏗️ pgsl_chunk_set_active
   📄 Editors\CodeEditor\pgsl_runtime.py (line 539)
   ⚠️  Never called

🏗️ pgsl_chunk_set_position
   📄 Editors\CodeEditor\pgsl_runtime.py (line 543)
   ⚠️  Never called

🏗️ pgsl_chunk_destroy
   📄 Editors\CodeEditor\pgsl_runtime.py (line 547)
   ⚠️  Never called

🏗️ show_suggestions
   📄 Editors\CodeEditor\PGSLCodeEditor.py (line 160)
   📞 Called by:
      • Editors\CodeEditor\PGSLCodeEditor.py (line 262)

🏗️ accept_current
   📄 Editors\CodeEditor\PGSLCodeEditor.py (line 172)
   📞 Called by:
      • Editors\CodeEditor\PGSLCodeEditor.py (line 221)

🏗️ update_autocomplete
   📄 Editors\CodeEditor\PGSLCodeEditor.py (line 251)
   ⚠️  Never called

🏗️ insert_completion
   📄 Editors\CodeEditor\PGSLCodeEditor.py (line 264)
   📞 Called by:
      • Editors\CodeEditor\PGSLCodeEditor.py (line 177)

🏗️ load_resource_files
   📄 Editors\BackgroundEditor\BackgroundEditor.py (line 18)
   ⚠️  Never called

🏗️ load_background_from_files
   📄 Editors\BackgroundEditor\BackgroundEditor.py (line 28)
   ⚠️  Never called

🏗️ open_image_editor
   📄 Editors\BackgroundEditor\BackgroundEditor.py (line 129)
   ⚠️  Never called

🏗️ show_image_editor
   📄 Editors\BackgroundEditor\BackgroundEditor.py (line 202)
   ⚠️  Never called

🏗️ close_image_editor
   📄 Editors\BackgroundEditor\BackgroundEditor.py (line 241)
   ⚠️  Never called

🏗️ get_background_data
   📄 Editors\BackgroundEditor\BackgroundEditor.py (line 257)
   ⚠️  Never called

🏗️ has_existing_background_data
   📄 Editors\BackgroundEditor\BackgroundEditor.py (line 284)
   ⚠️  Never called

🏗️ update_background_dimensions
   📄 Editors\BackgroundEditor\BackgroundEditor.py (line 289)
   ⚠️  Never called

🏗️ on_background_saved
   📄 Editors\BackgroundEditor\BackgroundEditor.py (line 297)
   ⚠️  Never called

🏗️ _load_runtime_frames
   📄 Editors\BackgroundEditor\BackgroundEditor.py (line 349)
   ⚠️  Never called

🏗️ save_frame_files_to_disk
   📄 Editors\BackgroundEditor\BackgroundEditor.py (line 403)
   ⚠️  Never called

🏗️ create_texture_from_array
   📄 Core\Rendering\TextureManager.py (line 29)
   📞 Called by:
      • Core\Rendering\Canvas_2D.py (line 345)
      • Core\Rendering\Canvas_2D.py (line 379)

🏗️ create_texture_from_file
   📄 Core\Rendering\TextureManager.py (line 134)
   ⚠️  Never called

🏗️ get_texture
   📄 Core\Rendering\TextureManager.py (line 179)
   ⚠️  Never called

🏗️ get_texture_info
   📄 Core\Rendering\TextureManager.py (line 183)
   ⚠️  Never called

🏗️ bind_texture
   📄 Core\Rendering\TextureManager.py (line 187)
   ⚠️  Never called

🏗️ delete_texture
   📄 Core\Rendering\TextureManager.py (line 205)
   📞 Called by:
      • Core\Rendering\Canvas_2D.py (line 370)
      • Core\Rendering\Canvas_2D.py (line 736)
      • Core\Rendering\Canvas_2D.py (line 739)

🏗️ generate_mipmaps
   📄 Core\Rendering\TextureManager.py (line 233)
   ⚠️  Never called

🏗️ get_texture_manager
   📄 Core\Rendering\TextureManager.py (line 286)
   📞 Called by:
      • Core\Rendering\Canvas_2D.py (line 43)

🏗️ _convert_line
   📄 Editors\CodeEditor\pgsl_parser.py (line 201)
   ⚠️  Never called

🏗️ compile
   📄 Core\Rendering\SuperShader_2D.py (line 46)
   📞 Called by:
      • Core\Rendering\Canvas_2D.py (line 105)
      • Core\Code\Unified\execution_engine.py (line 160)
      • Core\Code\Shared\script_validator.py (line 155)
      • Core\Code\Shared\script_validator.py (line 450)
      • Core\Code\Shared\script_validator.py (line 455)
      • Core\Code\Shared\script_validator.py (line 475)

🏗️ _get_vertex_shader_source
   📄 Core\Rendering\SuperShader_2D.py (line 80)
   ⚠️  Never called

🏗️ _get_fragment_shader_source
   📄 Core\Rendering\SuperShader_2D.py (line 117)
   ⚠️  Never called

🏗️ _cache_uniform_locations
   📄 Core\Rendering\SuperShader_2D.py (line 175)
   ⚠️  Never called

🏗️ use
   📄 Core\Rendering\SuperShader_2D.py (line 201)
   📞 Called by:
      • Core\Rendering\Canvas_2D.py (line 134)

🏗️ _set_blend_state
   📄 Core\Rendering\SuperShader_2D.py (line 218)
   ⚠️  Never called

🏗️ set_model_matrix
   📄 Core\Rendering\SuperShader_2D.py (line 238)
   📞 Called by:
      • Core\Rendering\Canvas_2D.py (line 317)

🏗️ set_projection_matrix
   📄 Core\Rendering\SuperShader_2D.py (line 252)
   📞 Called by:
      • Core\Rendering\Canvas_2D.py (line 257)

🏗️ set_texture
   📄 Core\Rendering\SuperShader_2D.py (line 265)
   📞 Called by:
      • Core\Rendering\Canvas_2D.py (line 148)

🏗️ set_color_modulation
   📄 Core\Rendering\SuperShader_2D.py (line 279)
   ⚠️  Never called

🏗️ set_flip
   📄 Core\Rendering\SuperShader_2D.py (line 292)
   ⚠️  Never called

🏗️ set_blend_mode
   📄 Core\Rendering\SuperShader_2D.py (line 305)
   ⚠️  Never called

🏗️ set_checkerboard
   📄 Core\Rendering\SuperShader_2D.py (line 330)
   📞 Called by:
      • Core\Rendering\Canvas_2D.py (line 138)

🏗️ set_pixel_perfect
   📄 Core\Rendering\SuperShader_2D.py (line 346)
   📞 Called by:
      • Core\Rendering\Canvas_2D.py (line 139)
      • Editors\ImageEditor\core\ui\main_window.py (line 1122)
      • Editors\ImageEditor\core\ui\main_window.py (line 6274)

🏗️ set_alpha
   📄 Core\Rendering\SuperShader_2D.py (line 360)
   ⚠️  Never called

🏗️ set_selection_mask
   📄 Core\Rendering\SuperShader_2D.py (line 370)
   📞 Called by:
      • Core\Rendering\Canvas_2D.py (line 143)
      • Core\Rendering\Canvas_2D.py (line 145)
      • Editors\ImageEditor\core\ui\main_window.py (line 1186)
      • Editors\ImageEditor\core\ui\main_window.py (line 1188)
      • Editors\ImageEditor\core\ui\main_window.py (line 1215)

🏗️ get_super_shader_2d
   📄 Core\Rendering\SuperShader_2D.py (line 392)
   📞 Called by:
      • Core\Rendering\Canvas_2D.py (line 45)

🏗️ create_project
   📄 Core\ProjectManager.py (line 36)
   📞 Called by:
      • Core\Services\project_service.py (line 41)
      • UI\MainWindow\MainWindow.py (line 611)

🏗️ deferred_purge
   📄 Core\ProjectManager.py (line 240)
   ⚠️  Never called

🏗️ load_project
   📄 Core\ProjectManager.py (line 150)
   📞 Called by:
      • Core\Services\project_service.py (line 72)
      • UI\CommonDialogs\PreferencesDialog.py (line 2787)
      • UI\MainWindow\MainWindow.py (line 626)
      • UI\MainWindow\MainWindow.py (line 757)
      • UI\MainWindow\MainWindow.py (line 1649)

🏗️ _on_metadata_loaded
   📄 Core\ProjectManager.py (line 281)
   ⚠️  Never called

🏗️ _on_resource_loaded
   📄 Core\ProjectManager.py (line 287)
   ⚠️  Never called

🏗️ _on_loading_complete
   📄 Core\ProjectManager.py (line 294)
   ⚠️  Never called

🏗️ _on_loading_error
   📄 Core\ProjectManager.py (line 311)
   ⚠️  Never called

🏗️ save_project
   📄 Core\ProjectManager.py (line 319)
   📞 Called by:
      • Core\Services\project_service.py (line 95)
      • UI\Widgets\ResourceTree.py (line 264)
      • UI\Widgets\ResourceTree.py (line 1712)
      • UI\MainWindow\MainWindow.py (line 650)

🏗️ _on_save_complete
   📄 Core\ProjectManager.py (line 358)
   ⚠️  Never called

🏗️ _on_save_progress
   📄 Core\ProjectManager.py (line 375)
   ⚠️  Never called

🏗️ purge_files_not_in_project
   📄 Core\ProjectManager.py (line 381)
   📞 Called by:
      • UI\MainWindow\MainWindow.py (line 1807)

🏗️ get_project_name
   📄 Core\ProjectManager.py (line 974)
   📞 Called by:
      • Core\GameGenerator.py (line 85)
      • Core\GameGenerator.py (line 102)
      • Core\ResourceManager.py (line 705)
      • UI\CommonDialogs\PreferencesDialog.py (line 2794)
      • UI\CommonDialogs\PreferencesDialog.py (line 2797)
      • UI\MainWindow\MainWindow.py (line 628)
      • UI\MainWindow\MainWindow.py (line 754)
      • UI\MainWindow\MainWindow.py (line 758)
      • UI\MainWindow\MainWindow.py (line 777)
      • UI\MainWindow\MainWindow.py (line 808)

🏗️ get_project_path
   📄 Core\ProjectManager.py (line 978)
   📞 Called by:
      • Core\Code\Unified\unified_code_editor.py (line 250)
      • Core\AI\PyGenesisAssistant\Nova\core\workflow.py (line 554)
      • Core\AI\PyGenesisAssistant\Nova\core\transaction_manager.py (line 76)
      • Core\AI\PyGenesisAssistant\Nova\core\transaction_manager.py (line 395)
      • Editors\BackgroundEditor\BackgroundEditor.py (line 43)
      • Editors\BackgroundEditor\BackgroundEditor.py (line 359)
      • Editors\BackgroundEditor\BackgroundEditor.py (line 415)
      • Core\AI\PyGenesisAssistant\Nova\core\executors\code_search_executor.py (line 176)
      • Core\AI\PyGenesisAssistant\Nova\core\executors\code_search_executor.py (line 179)
      • Core\AI\PyGenesisAssistant\Nova\core\executors\code_search_executor.py (line 240)
      • Core\AI\PyGenesisAssistant\Nova\core\executors\code_search_executor.py (line 243)
      • Core\AI\PyGenesisAssistant\Nova\core\executors\code_search_executor.py (line 302)
      • Core\AI\PyGenesisAssistant\Nova\core\executors\code_search_executor.py (line 305)
      • Core\ResourceManager.py (line 191)
      • Core\ResourceManager.py (line 307)
      • Core\ResourceManager.py (line 461)
      • Core\ResourceManager.py (line 523)
      • Core\ResourceManager.py (line 549)
      • Core\ResourceManager.py (line 578)
      • Core\ResourceManager.py (line 668)
      • Core\ResourceManager.py (line 724)
      • Core\ResourceManager.py (line 768)
      • Core\ResourceManager.py (line 843)
      • Core\ResourceManager.py (line 914)
      • Core\ResourceManager.py (line 958)
      • Core\ResourceManager.py (line 1034)
      • Core\ResourceManager.py (line 1278)
      • Core\ResourceManager.py (line 1500)
      • Core\ResourceManager.py (line 1555)
      • Core\ResourceManager.py (line 1616)
      • Core\ResourceManager.py (line 1680)
      • Core\ResourceManager.py (line 1686)
      • Core\ResourceManager.py (line 1908)
      • Core\AI\PyGenesisAssistant\Nova\core\engines\research_engine.py (line 1197)
      • Core\AI\PyGenesisAssistant\NovaWidget.py (line 41)
      • Core\AI\PyGenesisAssistant\NovaWidget.py (line 374)
      • Core\AI\PyGenesisAssistant\NovaWidget.py (line 486)
      • Core\AI\PyGenesisAssistant\Nova\core\executors\resource_operation_executor.py (line 328)
      • Core\AI\PyGenesisAssistant\Nova\core\executors\resource_operation_executor.py (line 597)
      • Core\AI\PyGenesisAssistant\Nova\core\executors\resource_operation_executor.py (line 601)
      • Core\AI\PyGenesisAssistant\Nova\core\executors\resource_operation_executor.py (line 635)
      • Core\AI\PyGenesisAssistant\Nova\core\executors\resource_operation_executor.py (line 677)
      • Core\AI\PyGenesisAssistant\Nova\core\operation_planner.py (line 342)
      • Editors\ObjectEditor\object_editor.py (line 384)
      • Editors\ObjectEditor\UI\properties_panel.py (line 84)
      • Editors\ObjectEditor\UI\properties_panel.py (line 387)
      • Editors\ObjectEditor\object_properties_panel.py (line 83)
      • Editors\ObjectEditor\object_properties_panel.py (line 348)
      • Editors\TextureEditor\TextureEditor.py (line 97)
      • Editors\TextureEditor\TextureEditor.py (line 301)
      • Editors\TextureEditor\TextureEditor.py (line 483)
      • Editors\TextureEditor\TextureEditor.py (line 656)
      • Editors\TextureEditor\TextureEditor.py (line 686)
      • Editors\SoundEditor\SoundEditor.py (line 1470)
      • Editors\SoundEditor\SoundEditor.py (line 2509)
      • Editors\SoundEditor\SoundEditor.py (line 2539)
      • Editors\SoundEditor\SoundEditor.py (line 2790)
      • Editors\SoundEditor\SoundEditor.py (line 2888)
      • UI\Widgets\ResourceTree.py (line 132)
      • UI\Widgets\ResourceTree.py (line 156)
      • UI\Widgets\ResourceTree.py (line 190)
      • UI\Widgets\ResourceTree.py (line 238)
      • UI\Widgets\ResourceTree.py (line 299)
      • UI\Widgets\ResourceTree.py (line 463)
      • UI\Widgets\ResourceTree.py (line 764)
      • UI\Widgets\ResourceTree.py (line 789)
      • UI\Widgets\ResourceTree.py (line 1080)
      • UI\Widgets\ResourceTree.py (line 1208)
      • UI\Widgets\ResourceTree.py (line 1325)
      • UI\Widgets\ResourceTree.py (line 1368)
      • UI\Widgets\ResourceTree.py (line 1651)
      • UI\Widgets\ResourceTree.py (line 1747)
      • UI\Widgets\ResourceTree.py (line 1851)
      • UI\CommonDialogs\PreferencesDialog.py (line 1636)
      • UI\CommonDialogs\PreferencesDialog.py (line 1640)
      • Editors\Shared\IntegratedImageEditor.py (line 674)
      • Editors\SoundEditor\core\WaveForge.py (line 1147)
      • UI\MainWindow\MainWindow.py (line 657)
      • UI\MainWindow\MainWindow.py (line 750)
      • UI\MainWindow\MainWindow.py (line 753)
      • UI\MainWindow\MainWindow.py (line 959)
      • UI\MainWindow\MainWindow.py (line 993)
      • UI\MainWindow\MainWindow.py (line 1053)
      • UI\MainWindow\MainWindow.py (line 1087)
      • UI\MainWindow\MainWindow.py (line 1144)
      • UI\MainWindow\MainWindow.py (line 1190)
      • UI\MainWindow\MainWindow.py (line 1683)
      • UI\MainWindow\MainWindow.py (line 1814)
      • UI\MainWindow\MainWindow.py (line 1908)
      • UI\MainWindow\MainWindow.py (line 1977)
      • UI\MainWindow\MainWindow.py (line 1997)
      • Editors\SpriteEditor\SpriteEditor.py (line 61)
      • Editors\SpriteEditor\SpriteEditor.py (line 474)
      • Editors\SpriteEditor\SpriteEditor.py (line 610)
      • Editors\SpriteEditor\SpriteEditor.py (line 704)
      • Editors\SpriteEditor\SpriteEditor.py (line 882)
      • Editors\SpriteEditor\SpriteEditor.py (line 912)
      • Editors\ModelEditor\ModelEditor.py (line 753)
      • Editors\ModelEditor\ModelEditor.py (line 856)
      • Editors\ModelEditor\ModelEditor.py (line 2998)
      • Editors\ModelEditor\ModelEditor.py (line 3020)
      • Editors\ModelEditor\ModelEditor.py (line 8269)
      • Editors\ModelEditor\ModelEditor.py (line 10681)
      • Editors\ModelEditor\ModelEditor.py (line 10755)
      • Editors\ModelEditor\ModelEditor.py (line 10762)
      • Editors\ModelEditor\ModelEditor.py (line 10926)
      • Editors\ModelEditor\ModelEditor.py (line 11750)
      • Editors\ModelEditor\ModelEditor.py (line 11761)
      • Editors\ModelEditor\ModelEditor.py (line 11836)
      • Editors\ModelEditor\ModelEditor.py (line 11908)
      • Editors\ModelEditor\ModelEditor.py (line 11989)

🏗️ get_project_data
   📄 Core\ProjectManager.py (line 982)
   📞 Called by:
      • UI\Widgets\ResourceTree.py (line 242)

🏗️ _ensure_resource_folders
   📄 Core\ProjectManager.py (line 986)
   ⚠️  Never called

🏗️ _load_runtime_resources
   📄 Core\ProjectManager.py (line 1003)
   ⚠️  Never called

🏗️ _save_runtime_to_project_data
   📄 Core\ProjectManager.py (line 1103)
   ⚠️  Never called

🏗️ get_runtime_resources
   📄 Core\ProjectManager.py (line 1166)
   📞 Called by:
      • Editors\RoomEditor\RoomEditor.py (line 320)
      • Editors\RoomEditor\RoomEditor.py (line 432)
      • Editors\RoomEditor\RoomEditor.py (line 434)
      • Editors\RoomEditor\ui\main_window.py (line 311)
      • Editors\RoomEditor\ui\main_window.py (line 423)
      • Editors\RoomEditor\ui\main_window.py (line 425)
      • Editors\SoundEditor\SoundEditor.py (line 1477)
      • Editors\SoundEditor\SoundEditor.py (line 2893)
      • UI\Widgets\ResourceTree.py (line 180)
      • UI\MainWindow\MainWindow.py (line 788)

🏗️ get_runtime_resource
   📄 Core\ProjectManager.py (line 1170)
   📞 Called by:
      • Core\ResourceManager.py (line 244)
      • Core\ResourceManager.py (line 282)
      • Core\ResourceManager.py (line 619)
      • Editors\RoomEditor\RoomEditor.py (line 785)
      • Editors\RoomEditor\RoomEditor.py (line 808)
      • Editors\RoomEditor\RoomEditor.py (line 919)
      • Editors\RoomEditor\RoomEditor.py (line 921)
      • Editors\RoomEditor\RoomEditor.py (line 1024)
      • Editors\RoomEditor\RoomEditor.py (line 1082)
      • Editors\RoomEditor\RoomEditor.py (line 1091)
      • Editors\RoomEditor\RoomEditor.py (line 1093)
      • Editors\RoomEditor\RoomEditor.py (line 1552)
      • Editors\RoomEditor\ui\main_window.py (line 768)
      • Editors\RoomEditor\ui\main_window.py (line 791)
      • Editors\RoomEditor\ui\main_window.py (line 902)
      • Editors\RoomEditor\ui\main_window.py (line 904)
      • Editors\RoomEditor\ui\main_window.py (line 1007)
      • Editors\RoomEditor\ui\main_window.py (line 1065)
      • Editors\RoomEditor\ui\main_window.py (line 1074)
      • Editors\RoomEditor\ui\main_window.py (line 1076)

🏗️ add_runtime_resource
   📄 Core\ProjectManager.py (line 1174)
   📞 Called by:
      • Core\ResourceManager.py (line 225)
      • Core\ResourceManager.py (line 1928)

🏗️ update_runtime_resource
   📄 Core\ProjectManager.py (line 1183)
   📞 Called by:
      • Core\ResourceManager.py (line 266)
      • Core\ResourceManager.py (line 387)
      • Editors\TextureEditor\TextureEditor.py (line 617)
      • Editors\TextureEditor\TextureEditor.py (line 641)
      • Editors\SoundEditor\SoundEditor.py (line 2674)
      • Editors\SpriteEditor\SpriteEditor.py (line 843)
      • Editors\SpriteEditor\SpriteEditor.py (line 867)

🏗️ remove_runtime_resource
   📄 Core\ProjectManager.py (line 1196)
   📞 Called by:
      • Core\ResourceManager.py (line 478)

🏗️ has_pending_changes
   📄 Core\ProjectManager.py (line 1203)
   📞 Called by:
      • UI\MainWindow\MainWindow.py (line 744)

🏗️ mark_project_dirty
   📄 Core\ProjectManager.py (line 1207)
   📞 Called by:
      • Editors\BackgroundEditor\BackgroundEditor.py (line 340)
      • Editors\TextureEditor\TextureEditor.py (line 287)
      • Editors\SpriteEditor\SpriteEditor.py (line 459)

🏗️ _release_editor_file_handles
   📄 Core\ProjectManager.py (line 1212)
   ⚠️  Never called

🏗️ _rename_files_to_match_runtime
   📄 Core\ProjectManager.py (line 1227)
   ⚠️  Never called

🏗️ _get_resource_extension
   📄 Core\ProjectManager.py (line 1366)
   ⚠️  Never called

🏗️ _rename_sprite_frame_files
   📄 Core\ProjectManager.py (line 1378)
   ⚠️  Never called

🏗️ _delete_sprite_files
   📄 Core\ProjectManager.py (line 1413)
   ⚠️  Never called

🏗️ add_resource
   📄 Core\ProjectManager.py (line 1452)
   📞 Called by:
      • UI\Widgets\ResourceTree.py (line 767)
      • UI\Widgets\ResourceTree.py (line 796)
      • UI\Widgets\ResourceTree.py (line 852)

🏗️ remove_resource
   📄 Core\ProjectManager.py (line 1458)
   ⚠️  Never called

🏗️ get_resources
   📄 Core\ProjectManager.py (line 1467)
   📞 Called by:
      • Core\AI\PyGenesisAssistant\Nova\core\executors\code_search_executor.py (line 186)
      • Core\AI\PyGenesisAssistant\Nova\core\executors\code_search_executor.py (line 250)
      • Core\AI\PyGenesisAssistant\Nova\core\executors\code_search_executor.py (line 312)
      • Core\ResourceManager.py (line 166)
      • Core\ResourceManager.py (line 390)
      • Core\ResourceManager.py (line 629)
      • Core\ResourceManager.py (line 1331)
      • Core\AI\PyGenesisAssistant\Nova\core\executors\resource_operation_executor.py (line 276)
      • Core\AI\PyGenesisAssistant\Nova\core\executors\resource_operation_executor.py (line 284)
      • Core\AI\PyGenesisAssistant\Nova\core\executors\resource_operation_executor.py (line 293)
      • Core\AI\PyGenesisAssistant\Nova\core\executors\resource_operation_executor.py (line 459)
      • Core\AI\PyGenesisAssistant\Nova\core\executors\resource_operation_executor.py (line 703)
      • UI\Widgets\ResourceTree.py (line 1690)
      • UI\CommonDialogs\PreferencesDialog.py (line 1497)
      • UI\CommonDialogs\PreferencesDialog.py (line 2312)
      • UI\CommonDialogs\PreferencesDialog.py (line 2342)
      • UI\CommonDialogs\PreferencesDialog.py (line 2674)
      • UI\CommonDialogs\PreferencesDialog.py (line 2695)
      • Editors\ModelEditor\ModelEditor.py (line 743)
      • Editors\ModelEditor\ModelEditor.py (line 2514)
      • Editors\ModelEditor\ModelEditor.py (line 9078)
      • Editors\ModelEditor\ModelEditor.py (line 9152)
      • Editors\ModelEditor\ModelEditor.py (line 9239)
      • Editors\ModelEditor\ModelEditor.py (line 9307)
      • Editors\ModelEditor\ModelEditor.py (line 10247)
      • Editors\ModelEditor\ModelEditor.py (line 10320)
      • Editors\ModelEditor\ModelEditor.py (line 10420)
      • Editors\ModelEditor\ModelEditor.py (line 10436)

🏗️ _attempt_project_recovery
   📄 Core\ProjectManager.py (line 1471)
   ⚠️  Never called

🏗️ _fix_common_json_issues
   📄 Core\ProjectManager.py (line 1499)
   ⚠️  Never called

🏗️ safe_run
   📄 Core\VenvManager.py (line 16)
   📞 Called by:
      • Core\VenvManager.py (line 233)
      • Core\VenvManager.py (line 237)

🏗️ _detect_paths
   📄 Core\VenvManager.py (line 65)
   ⚠️  Never called

🏗️ venv_exists
   📄 Core\VenvManager.py (line 97)
   ⚠️  Never called

🏗️ validate_venv
   📄 Core\VenvManager.py (line 101)
   ⚠️  Never called

🏗️ _test_python_version
   📄 Core\VenvManager.py (line 166)
   ⚠️  Never called

🏗️ _test_pip
   📄 Core\VenvManager.py (line 176)
   ⚠️  Never called

🏗️ create_venv
   📄 Core\VenvManager.py (line 187)
   ⚠️  Never called

🏗️ _install_core_requirements
   📄 Core\VenvManager.py (line 265)
   ⚠️  Never called

🏗️ _save_config
   📄 Core\VenvManager.py (line 338)
   ⚠️  Never called

🏗️ get_python_executable
   📄 Core\VenvManager.py (line 354)
   📞 Called by:
      • Core\PackageInstaller.py (line 47)
      • Core\ExtensionsManager.py (line 250)
      • Core\ExtensionsManager.py (line 309)

🏗️ get_pip_executable
   📄 Core\VenvManager.py (line 361)
   ⚠️  Never called

🏗️ activate_venv
   📄 Core\VenvManager.py (line 370)
   ⚠️  Never called

🏗️ verify_venv
   📄 Core\VenvManager.py (line 415)
   ⚠️  Never called

🏗️ get_status
   📄 Core\VenvManager.py (line 431)
   ⚠️  Never called

🏗️ initializeGL
   📄 Core\Rendering\Canvas_2D.py (line 96)
   ⚠️  Never called

🏗️ resizeGL
   📄 Core\Rendering\Canvas_2D.py (line 113)
   ⚠️  Never called

🏗️ paintGL
   📄 Core\Rendering\Canvas_2D.py (line 120)
   ⚠️  Never called

🏗️ _create_quad_buffers
   📄 Core\Rendering\Canvas_2D.py (line 163)
   ⚠️  Never called

🏗️ _update_projection_matrix
   📄 Core\Rendering\Canvas_2D.py (line 236)
   ⚠️  Never called

🏗️ _update_model_matrix
   📄 Core\Rendering\Canvas_2D.py (line 259)
   ⚠️  Never called

🏗️ mark_dirty_rectangle
   📄 Core\Rendering\Canvas_2D.py (line 390)
   ⚠️  Never called

🏗️ update_partial_texture
   📄 Core\Rendering\Canvas_2D.py (line 402)
   ⚠️  Never called

🏗️ _do_throttled_update
   📄 Core\Rendering\Canvas_2D.py (line 467)
   ⚠️  Never called

🏗️ set_zoom
   📄 Core\Rendering\Canvas_2D.py (line 489)
   📞 Called by:
      • Editors\SoundEditor\core\WaveForge.py (line 1056)

🏗️ reset_zoom
   📄 Core\Rendering\Canvas_2D.py (line 503)
   ⚠️  Never called

🏗️ widget_to_image_coords
   📄 Core\Rendering\Canvas_2D.py (line 538)
   ⚠️  Never called

🏗️ update_current_image_from_selected_layer
   📄 Core\Rendering\Canvas_2D.py (line 626)
   📞 Called by:
      • Editors\ImageEditor\core\ui\main_window.py (line 362)
      • Editors\ImageEditor\core\ui\main_window.py (line 1260)
      • Editors\ImageEditor\core\ui\main_window.py (line 2798)

🏗️ update_dirty_regions
   📄 Core\Rendering\Canvas_2D.py (line 637)
   📞 Called by:
      • Editors\ImageEditor\core\ui\main_window.py (line 1177)

🏗️ force_layer_frame_switch
   📄 Core\Rendering\Canvas_2D.py (line 678)
   📞 Called by:
      • Editors\ImageEditor\core\ui\panels\right_panel.py (line 534)
      • Editors\ImageEditor\core\ui\panels\right_panel.py (line 595)
      • Editors\ImageEditor\core\ui\panels\right_panel.py (line 612)
      • Editors\ImageEditor\core\ui\main_window.py (line 1244)
      • Editors\ImageEditor\core\ui\main_window.py (line 1252)
      • Editors\ImageEditor\core\ui\main_window.py (line 2802)

🏗️ set_image_size
   📄 Core\Rendering\Canvas_2D.py (line 683)
   📞 Called by:
      • Editors\ImageEditor\core\app.py (line 23)
      • Editors\Shared\IntegratedImageEditor.py (line 773)
      • Editors\ImageEditor\core\ui\main_window.py (line 1086)
      • Editors\ImageEditor\core\ui\main_window.py (line 1320)
      • Editors\ImageEditor\core\ui\main_window.py (line 1367)
      • Editors\ImageEditor\core\ui\main_window.py (line 1470)
      • Editors\ImageEditor\core\ui\main_window.py (line 1633)
      • Editors\ImageEditor\core\ui\main_window.py (line 1717)
      • Editors\ImageEditor\core\ui\main_window.py (line 1868)
      • Editors\ImageEditor\core\ui\main_window.py (line 1989)
      • Editors\ImageEditor\core\ui\main_window.py (line 2059)
      • Editors\ImageEditor\core\ui\main_window.py (line 2095)

🏗️ set_preview_box
   📄 Core\Rendering\Canvas_2D.py (line 694)
   📞 Called by:
      • Editors\ImageEditor\core\ui\panels\right_panel.py (line 306)

🏗️ _update_preview_box
   📄 Core\Rendering\Canvas_2D.py (line 698)
   📞 Called by:
      • Editors\ImageEditor\core\ui\panels\right_panel.py (line 536)
      • Editors\ImageEditor\core\ui\main_window.py (line 1192)

🏗️ on_undo_redo
   📄 Core\Rendering\Canvas_2D.py (line 707)
   📞 Called by:
      • Editors\ImageEditor\core\ui\main_window.py (line 1269)
      • Editors\ImageEditor\core\ui\main_window.py (line 1277)

🏗️ cut_selection
   📄 Core\Rendering\Canvas_2D.py (line 713)
   📞 Called by:
      • Editors\Shared\IntegratedImageEditor.py (line 1192)
      • Editors\SoundEditor\core\WaveForge.py (line 332)
      • Editors\ImageEditor\core\ui\main_window.py (line 976)
      • Editors\ImageEditor\core\ui\main_window.py (line 1284)

🏗️ copy_selection
   📄 Core\Rendering\Canvas_2D.py (line 717)
   📞 Called by:
      • Editors\Shared\IntegratedImageEditor.py (line 1197)
      • Editors\SoundEditor\core\WaveForge.py (line 337)
      • Editors\ImageEditor\core\ui\main_window.py (line 978)
      • Editors\ImageEditor\core\ui\main_window.py (line 1289)

🏗️ paste_selection
   📄 Core\Rendering\Canvas_2D.py (line 721)
   📞 Called by:
      • Editors\Shared\IntegratedImageEditor.py (line 1202)
      • Editors\SoundEditor\core\WaveForge.py (line 341)
      • Editors\ImageEditor\core\ui\main_window.py (line 980)
      • Editors\ImageEditor\core\ui\main_window.py (line 1294)

🏗️ select_all
   📄 Core\Rendering\Canvas_2D.py (line 725)
   📞 Called by:
      • Editors\ImageEditor\core\ui\preview.py (line 2540)
      • Editors\Shared\IntegratedImageEditor.py (line 1232)
      • Editors\ImageEditor\core\ui\main_window.py (line 1025)

🏗️ clear_selection
   📄 Core\Rendering\Canvas_2D.py (line 729)
   📞 Called by:
      • Editors\ImageEditor\core\ui\panels\right_panel.py (line 522)
      • Editors\ImageEditor\core\core\state.py (line 64)
      • Editors\ImageEditor\core\core\history.py (line 63)
      • Editors\ImageEditor\core\core\history.py (line 94)
      • Editors\ImageEditor\core\ui\preview.py (line 853)
      • Editors\ImageEditor\core\ui\preview.py (line 866)
      • Editors\ImageEditor\core\ui\preview.py (line 2299)
      • Editors\ImageEditor\core\ui\preview.py (line 2341)
      • Editors\ImageEditor\core\ui\preview.py (line 2437)
      • Editors\ImageEditor\core\ui\preview.py (line 2471)
      • Editors\ImageEditor\core\ui\preview.py (line 2498)
      • Editors\ImageEditor\core\ui\preview.py (line 2989)
      • Editors\Shared\IntegratedImageEditor.py (line 1238)
      • Editors\ImageEditor\core\ui\main_window.py (line 982)
      • Editors\ImageEditor\core\ui\main_window.py (line 1214)
      • Editors\ImageEditor\core\ui\main_window.py (line 2625)

🏗️ toggle_key_visibility
   📄 Editors\ImageEditor\core\ui\api_key_dialog.py (line 74)
   ⚠️  Never called

🏗️ open_api_key_page
   📄 Editors\ImageEditor\core\ui\api_key_dialog.py (line 83)
   ⚠️  Never called

🏗️ validate_and_accept
   📄 Editors\ImageEditor\core\ui\api_key_dialog.py (line 89)
   ⚠️  Never called

🏗️ get_api_key
   📄 Editors\ImageEditor\core\ui\api_key_dialog.py (line 106)
   ⚠️  Never called

🏗️ compile_shader
   📄 Core\Rendering\ShaderManager.py (line 28)
   📞 Called by:
      • Core\Rendering\SuperShader_2D.py (line 60)

🏗️ compile_shader_from_files
   📄 Core\Rendering\ShaderManager.py (line 82)
   ⚠️  Never called

🏗️ get_shader
   📄 Core\Rendering\ShaderManager.py (line 111)
   📞 Called by:
      • Core\Rendering\SuperShader_2D.py (line 327)

🏗️ use_shader
   📄 Core\Rendering\ShaderManager.py (line 115)
   📞 Called by:
      • Core\Rendering\SuperShader_2D.py (line 212)

🏗️ reload_shader
   📄 Core\Rendering\ShaderManager.py (line 131)
   ⚠️  Never called

🏗️ delete_shader
   📄 Core\Rendering\ShaderManager.py (line 162)
   ⚠️  Never called

🏗️ get_uniform_location
   📄 Core\Rendering\ShaderManager.py (line 190)
   📞 Called by:
      • Core\Rendering\SuperShader_2D.py (line 197)

🏗️ get_shader_manager
   📄 Core\Rendering\ShaderManager.py (line 230)
   📞 Called by:
      • Core\Rendering\SuperShader_2D.py (line 34)

🏗️ resize_image
   📄 Editors\ImageEditor\core\services\image_operations.py (line 18)
   ⚠️  Never called

🏗️ crop_image
   📄 Editors\ImageEditor\core\services\image_operations.py (line 27)
   ⚠️  Never called

🏗️ rotate_image
   📄 Editors\ImageEditor\core\services\image_operations.py (line 33)
   ⚠️  Never called

🏗️ flip_horizontal
   📄 Editors\ImageEditor\core\services\image_operations.py (line 39)
   ⚠️  Never called

🏗️ flip_vertical
   📄 Editors\ImageEditor\core\services\image_operations.py (line 45)
   ⚠️  Never called

🏗️ initialize_context
   📄 Core\Rendering\OpenGLRuntime.py (line 53)
   📞 Called by:
      • Core\Rendering\Canvas_2D.py (line 99)

🏗️ _query_gl_info
   📄 Core\Rendering\OpenGLRuntime.py (line 85)
   ⚠️  Never called

🏗️ _setup_default_state
   📄 Core\Rendering\OpenGLRuntime.py (line 106)
   ⚠️  Never called

🏗️ make_current
   📄 Core\Rendering\OpenGLRuntime.py (line 129)
   📞 Called by:
      • Core\Rendering\BufferManager.py (line 46)
      • Core\Rendering\BufferManager.py (line 91)
      • Core\Rendering\BufferManager.py (line 142)
      • Core\Rendering\BufferManager.py (line 237)
      • Core\Rendering\BufferManager.py (line 270)
      • Core\Rendering\Canvas_2D.py (line 102)
      • Core\Rendering\Canvas_2D.py (line 123)
      • Core\Rendering\Canvas_2D.py (line 169)
      • Core\Rendering\Canvas_2D.py (line 342)
      • Core\Rendering\Canvas_2D.py (line 377)
      • Core\Rendering\Canvas_2D.py (line 415)
      • Core\Rendering\Canvas_2D.py (line 517)
      • Core\Rendering\ShaderManager.py (line 46)
      • Core\Rendering\ShaderManager.py (line 178)
      • Core\Rendering\ShaderManager.py (line 211)
      • Core\Rendering\TextureManager.py (line 53)
      • Core\Rendering\TextureManager.py (line 221)
      • Core\Rendering\TextureManager.py (line 248)
      • Core\Rendering\TextureManager.py (line 267)

🏗️ is_current
   📄 Core\Rendering\OpenGLRuntime.py (line 143)
   📞 Called by:
      • Core\Rendering\BufferManager.py (line 45)
      • Core\Rendering\BufferManager.py (line 90)
      • Core\Rendering\BufferManager.py (line 141)
      • Core\Rendering\BufferManager.py (line 236)
      • Core\Rendering\BufferManager.py (line 269)
      • Core\Rendering\Canvas_2D.py (line 122)
      • Core\Rendering\Canvas_2D.py (line 168)
      • Core\Rendering\Canvas_2D.py (line 341)
      • Core\Rendering\Canvas_2D.py (line 376)
      • Core\Rendering\Canvas_2D.py (line 414)
      • Core\Rendering\Canvas_2D.py (line 516)
      • Core\Rendering\ShaderManager.py (line 45)
      • Core\Rendering\ShaderManager.py (line 177)
      • Core\Rendering\ShaderManager.py (line 210)
      • Core\Rendering\TextureManager.py (line 52)
      • Core\Rendering\TextureManager.py (line 220)
      • Core\Rendering\TextureManager.py (line 247)
      • Core\Rendering\TextureManager.py (line 266)

🏗️ done_current
   📄 Core\Rendering\OpenGLRuntime.py (line 150)
   ⚠️  Never called

🏗️ get_context_widget
   📄 Core\Rendering\OpenGLRuntime.py (line 155)
   ⚠️  Never called

🏗️ register_texture
   📄 Core\Rendering\OpenGLRuntime.py (line 159)
   📞 Called by:
      • Core\Rendering\TextureManager.py (line 129)

🏗️ unregister_texture
   📄 Core\Rendering\OpenGLRuntime.py (line 183)
   📞 Called by:
      • Core\Rendering\TextureManager.py (line 226)

🏗️ register_buffer
   📄 Core\Rendering\OpenGLRuntime.py (line 200)
   📞 Called by:
      • Core\Rendering\BufferManager.py (line 73)
      • Core\Rendering\BufferManager.py (line 118)
      • Core\Rendering\BufferManager.py (line 188)

🏗️ get_buffer
   📄 Core\Rendering\OpenGLRuntime.py (line 211)
   ⚠️  Never called

🏗️ unregister_buffer
   📄 Core\Rendering\OpenGLRuntime.py (line 223)
   📞 Called by:
      • Core\Rendering\BufferManager.py (line 243)
      • Core\Rendering\BufferManager.py (line 250)
      • Core\Rendering\BufferManager.py (line 257)

🏗️ get_capabilities
   📄 Core\Rendering\OpenGLRuntime.py (line 255)
   ⚠️  Never called

🏗️ get_runtime
   📄 Core\Rendering\OpenGLRuntime.py (line 272)
   📞 Called by:
      • Core\Rendering\BufferManager.py (line 31)
      • Core\Rendering\Canvas_2D.py (line 42)
      • Core\Rendering\ShaderManager.py (line 26)
      • Core\Rendering\TextureManager.py (line 27)

🏗️ save_image
   📄 Editors\ImageEditor\core\services\file_io.py (line 19)
   ⚠️  Never called

🏗️ export_sprite
   📄 Editors\ImageEditor\core\services\file_io.py (line 58)
   ⚠️  Never called

🏗️ set_size
   📄 Editors\ImageEditor\core\core\state.py (line 37)
   📞 Called by:
      • Editors\SpriteEditor\SpriteEditor.py (line 744)

🏗️ set_radius
   📄 Editors\ImageEditor\core\core\state.py (line 45)
   ⚠️  Never called

🏗️ set_left_color
   📄 Editors\ImageEditor\core\core\state.py (line 49)
   ⚠️  Never called

🏗️ set_right_color
   📄 Editors\ImageEditor\core\core\state.py (line 53)
   ⚠️  Never called

🏗️ set_tool
   📄 Editors\ImageEditor\core\core\state.py (line 57)
   ⚠️  Never called

🏗️ set_grid_visible
   📄 Editors\ImageEditor\core\core\state.py (line 73)
   ⚠️  Never called

🏗️ set_grid_size
   📄 Editors\ImageEditor\core\core\state.py (line 77)
   📞 Called by:
      • Editors\ImageEditor\core\ui\texture_atlas_dialog.py (line 460)

🏗️ set_grid_color
   📄 Editors\ImageEditor\core\core\state.py (line 81)
   ⚠️  Never called

🏗️ set_grid_rotation
   📄 Editors\ImageEditor\core\core\state.py (line 85)
   ⚠️  Never called

🏗️ set_grid_snap
   📄 Editors\ImageEditor\core\core\state.py (line 89)
   ⚠️  Never called

🏗️ undo
   📄 Editors\ImageEditor\core\core\state.py (line 93)
   📞 Called by:
      • Editors\ImageEditor\core\ui\timeline.py (line 1078)
      • Editors\ImageEditor\core\ui\preview.py (line 880)
      • Editors\Shared\IntegratedImageEditor.py (line 1182)
      • UI\MainWindow\MainWindow.py (line 874)
      • Editors\ModelEditor\ModelEditor.py (line 9653)

🏗️ redo
   📄 Editors\ImageEditor\core\core\state.py (line 100)
   📞 Called by:
      • Editors\ImageEditor\core\ui\timeline.py (line 1087)
      • Editors\ImageEditor\core\ui\preview.py (line 885)
      • Editors\Shared\IntegratedImageEditor.py (line 1187)
      • UI\MainWindow\MainWindow.py (line 886)
      • Editors\ModelEditor\ModelEditor.py (line 9661)

🏗️ add_layer
   📄 Editors\ImageEditor\core\core\state.py (line 107)
   📞 Called by:
      • Editors\ImageEditor\core\ui\panels\right_panel.py (line 119)
      • Editors\ImageEditor\core\ui\panels\right_panel.py (line 210)
      • Editors\ImageEditor\core\core\state.py (line 109)
      • Editors\ImageEditor\core\ui\main_window.py (line 630)

🏗️ add_frame
   📄 Editors\ImageEditor\core\core\state.py (line 111)
   📞 Called by:
      • Editors\ImageEditor\core\ui\panels\right_panel.py (line 541)
      • Editors\ImageEditor\core\ui\timeline.py (line 916)
      • Editors\ImageEditor\core\core\state.py (line 113)
      • Editors\ImageEditor\core\ui\main_window.py (line 2414)

🏗️ push_undo
   📄 Editors\ImageEditor\core\core\state.py (line 115)
   📞 Called by:
      • Editors\ImageEditor\core\ui\timeline.py (line 983)
      • Editors\ImageEditor\core\ui\timeline.py (line 1012)
      • Editors\ImageEditor\core\ui\timeline.py (line 1060)
      • Editors\ImageEditor\core\ui\timeline.py (line 1117)
      • Editors\Shared\IntegratedImageEditor.py (line 703)
      • Editors\ImageEditor\core\ui\main_window.py (line 399)
      • Editors\ImageEditor\core\ui\main_window.py (line 440)
      • Editors\ImageEditor\core\ui\main_window.py (line 461)
      • Editors\ImageEditor\core\ui\main_window.py (line 1313)
      • Editors\ImageEditor\core\ui\main_window.py (line 1350)
      • Editors\ImageEditor\core\ui\main_window.py (line 1558)
      • Editors\ImageEditor\core\ui\main_window.py (line 1833)
      • Editors\ImageEditor\core\ui\main_window.py (line 1976)
      • Editors\ImageEditor\core\ui\main_window.py (line 2042)
      • Editors\ModelEditor\ModelEditor.py (line 9614)

🏗️ mark_dirty_region
   📄 Editors\ImageEditor\core\core\state.py (line 122)
   ⚠️  Never called

🏗️ mark_dirty_point
   📄 Editors\ImageEditor\core\core\state.py (line 146)
   ⚠️  Never called

🏗️ merge_dirty_rectangles
   📄 Editors\ImageEditor\core\core\state.py (line 164)
   ⚠️  Never called

🏗️ _rectangles_adjacent
   📄 Editors\ImageEditor\core\core\state.py (line 206)
   ⚠️  Never called

🏗️ clear_dirty_rectangles
   📄 Editors\ImageEditor\core\core\state.py (line 215)
   ⚠️  Never called

🏗️ get_dirty_rectangles
   📄 Editors\ImageEditor\core\core\state.py (line 220)
   ⚠️  Never called

🏗️ has_dirty_regions
   📄 Editors\ImageEditor\core\core\state.py (line 232)
   ⚠️  Never called

🏗️ _lookup_wordnet_synonyms
   📄 Core\AI\PyGenesisAssistant\Nova\core\engines\thesaurus_engine.py (line 100)
   ⚠️  Never called

🏗️ _format_synonyms
   📄 Core\AI\PyGenesisAssistant\Nova\core\engines\thesaurus_engine.py (line 137)
   ⚠️  Never called

🏗️ generate_crosshair
   📄 Editors\ImageEditor\core\generate_textures.py (line 12)
   📞 Called by:
      • Editors\ImageEditor\core\generate_textures.py (line 445)

🏗️ generate_block_atlas
   📄 Editors\ImageEditor\core\generate_textures.py (line 30)
   📞 Called by:
      • Editors\ImageEditor\core\generate_textures.py (line 446)

🏗️ generate_dirt_texture
   📄 Editors\ImageEditor\core\generate_textures.py (line 109)
   📞 Called by:
      • Editors\ImageEditor\core\generate_textures.py (line 42)
      • Editors\ImageEditor\core\generate_textures.py (line 141)
      • Editors\ImageEditor\core\generate_textures.py (line 374)

🏗️ generate_grass_top_texture
   📄 Editors\ImageEditor\core\generate_textures.py (line 124)
   📞 Called by:
      • Editors\ImageEditor\core\generate_textures.py (line 43)

🏗️ generate_grass_side_texture
   📄 Editors\ImageEditor\core\generate_textures.py (line 139)
   📞 Called by:
      • Editors\ImageEditor\core\generate_textures.py (line 44)

🏗️ generate_stone_texture
   📄 Editors\ImageEditor\core\generate_textures.py (line 156)
   📞 Called by:
      • Editors\ImageEditor\core\generate_textures.py (line 45)
      • Editors\ImageEditor\core\generate_textures.py (line 173)

🏗️ generate_ore_texture
   📄 Editors\ImageEditor\core\generate_textures.py (line 171)
   📞 Called by:
      • Editors\ImageEditor\core\generate_textures.py (line 46)
      • Editors\ImageEditor\core\generate_textures.py (line 47)
      • Editors\ImageEditor\core\generate_textures.py (line 48)
      • Editors\ImageEditor\core\generate_textures.py (line 49)
      • Editors\ImageEditor\core\generate_textures.py (line 50)

🏗️ generate_water_texture
   📄 Editors\ImageEditor\core\generate_textures.py (line 185)
   📞 Called by:
      • Editors\ImageEditor\core\generate_textures.py (line 51)

🏗️ generate_lava_texture
   📄 Editors\ImageEditor\core\generate_textures.py (line 199)
   📞 Called by:
      • Editors\ImageEditor\core\generate_textures.py (line 52)

🏗️ generate_wood_top_texture
   📄 Editors\ImageEditor\core\generate_textures.py (line 215)
   📞 Called by:
      • Editors\ImageEditor\core\generate_textures.py (line 53)

🏗️ generate_wood_side_texture
   📄 Editors\ImageEditor\core\generate_textures.py (line 228)
   📞 Called by:
      • Editors\ImageEditor\core\generate_textures.py (line 54)

🏗️ generate_leaves_texture
   📄 Editors\ImageEditor\core\generate_textures.py (line 240)
   📞 Called by:
      • Editors\ImageEditor\core\generate_textures.py (line 55)

🏗️ generate_sand_texture
   📄 Editors\ImageEditor\core\generate_textures.py (line 255)
   📞 Called by:
      • Editors\ImageEditor\core\generate_textures.py (line 56)

🏗️ generate_sandstone_top_texture
   📄 Editors\ImageEditor\core\generate_textures.py (line 270)
   📞 Called by:
      • Editors\ImageEditor\core\generate_textures.py (line 57)

🏗️ generate_sandstone_side_texture
   📄 Editors\ImageEditor\core\generate_textures.py (line 291)
   📞 Called by:
      • Editors\ImageEditor\core\generate_textures.py (line 58)

🏗️ generate_sandstone_bottom_texture
   📄 Editors\ImageEditor\core\generate_textures.py (line 312)
   📞 Called by:
      • Editors\ImageEditor\core\generate_textures.py (line 59)

🏗️ generate_gravel_texture
   📄 Editors\ImageEditor\core\generate_textures.py (line 327)
   📞 Called by:
      • Editors\ImageEditor\core\generate_textures.py (line 60)

🏗️ generate_clay_texture
   📄 Editors\ImageEditor\core\generate_textures.py (line 342)
   📞 Called by:
      • Editors\ImageEditor\core\generate_textures.py (line 61)

🏗️ generate_snow_texture
   📄 Editors\ImageEditor\core\generate_textures.py (line 357)
   📞 Called by:
      • Editors\ImageEditor\core\generate_textures.py (line 62)

🏗️ generate_snow_dirt_side_texture
   📄 Editors\ImageEditor\core\generate_textures.py (line 372)
   📞 Called by:
      • Editors\ImageEditor\core\generate_textures.py (line 63)

🏗️ generate_coarse_dirt_texture
   📄 Editors\ImageEditor\core\generate_textures.py (line 389)
   📞 Called by:
      • Editors\ImageEditor\core\generate_textures.py (line 64)

🏗️ generate_sun_texture
   📄 Editors\ImageEditor\core\generate_textures.py (line 413)
   📞 Called by:
      • Editors\ImageEditor\core\generate_textures.py (line 65)

🏗️ generate_cloud_texture
   📄 Editors\ImageEditor\core\generate_textures.py (line 426)
   📞 Called by:
      • Editors\ImageEditor\core\generate_textures.py (line 66)

🏗️ detect_object_in_selection
   📄 Editors\ImageEditor\core\core\smart_layer_separation.py (line 25)
   ⚠️  Never called

🏗️ track_object_in_frame
   📄 Editors\ImageEditor\core\core\smart_layer_separation.py (line 59)
   ⚠️  Never called

🏗️ _track_with_template_matching
   📄 Editors\ImageEditor\core\core\smart_layer_separation.py (line 71)
   ⚠️  Never called

🏗️ _track_with_optical_flow
   📄 Editors\ImageEditor\core\core\smart_layer_separation.py (line 124)
   ⚠️  Never called

🏗️ extract_object_from_frame
   📄 Editors\ImageEditor\core\core\smart_layer_separation.py (line 130)
   ⚠️  Never called

🏗️ fill_gap_in_frame
   📄 Editors\ImageEditor\core\core\smart_layer_separation.py (line 153)
   ⚠️  Never called

🏗️ _get_bounds_from_mask
   📄 Editors\ImageEditor\core\core\smart_layer_separation.py (line 182)
   ⚠️  Never called

🏗️ create_conversation
   📄 Core\AI\PyGenesisAssistant\Nova\core\conversations.py (line 69)
   📞 Called by:
      • Core\AI\PyGenesisAssistant\Nova\ui\conversations_dialog.py (line 207)

🏗️ get_conversation
   📄 Core\AI\PyGenesisAssistant\Nova\core\conversations.py (line 97)
   📞 Called by:
      • Core\AI\PyGenesisAssistant\Nova\ui\conversations_dialog.py (line 199)
      • Core\AI\PyGenesisAssistant\Nova\ui\conversations_dialog.py (line 219)
      • Core\AI\PyGenesisAssistant\Nova\ui\conversations_dialog.py (line 235)
      • Core\AI\PyGenesisAssistant\Nova\ui\conversations_dialog.py (line 247)
      • Core\AI\PyGenesisAssistant\Nova\ui\conversations_dialog.py (line 276)
      • Core\AI\PyGenesisAssistant\NovaWidget.py (line 423)

🏗️ get_current_conversation
   📄 Core\AI\PyGenesisAssistant\Nova\core\conversations.py (line 129)
   📞 Called by:
      • Core\AI\PyGenesisAssistant\Nova\ui\header.py (line 242)
      • Core\AI\PyGenesisAssistant\Nova\ui\header.py (line 259)
      • Core\AI\PyGenesisAssistant\NovaWidget.py (line 234)
      • Core\AI\PyGenesisAssistant\NovaWidget.py (line 277)
      • Core\AI\PyGenesisAssistant\NovaWidget.py (line 328)

🏗️ ensure_conversation_exists
   📄 Core\AI\PyGenesisAssistant\Nova\core\conversations.py (line 135)
   📞 Called by:
      • Core\AI\PyGenesisAssistant\NovaWidget.py (line 116)
      • Core\AI\PyGenesisAssistant\NovaWidget.py (line 413)
      • Core\AI\PyGenesisAssistant\NovaWidget.py (line 665)

🏗️ set_current_conversation
   📄 Core\AI\PyGenesisAssistant\Nova\core\conversations.py (line 161)
   📞 Called by:
      • Core\AI\PyGenesisAssistant\NovaWidget.py (line 117)
      • Core\AI\PyGenesisAssistant\NovaWidget.py (line 415)
      • Core\AI\PyGenesisAssistant\NovaWidget.py (line 425)
      • Core\AI\PyGenesisAssistant\NovaWidget.py (line 667)

🏗️ list_conversations
   📄 Core\AI\PyGenesisAssistant\Nova\core\conversations.py (line 165)
   📞 Called by:
      • Core\AI\PyGenesisAssistant\Nova\ui\conversations_dialog.py (line 170)

🏗️ rename_conversation
   📄 Core\AI\PyGenesisAssistant\Nova\core\conversations.py (line 245)
   📞 Called by:
      • Core\AI\PyGenesisAssistant\Nova\ui\conversations_dialog.py (line 230)

🏗️ delete_conversation
   📄 Core\AI\PyGenesisAssistant\Nova\core\conversations.py (line 253)
   📞 Called by:
      • Core\AI\PyGenesisAssistant\Nova\ui\conversations_dialog.py (line 262)

🏗️ generate_summary
   📄 Core\AI\PyGenesisAssistant\Nova\core\conversations.py (line 288)
   ⚠️  Never called

🏗️ update_conversation_summary
   📄 Core\AI\PyGenesisAssistant\Nova\core\conversations.py (line 399)
   📞 Called by:
      • Core\AI\PyGenesisAssistant\NovaWidget.py (line 240)

🏗️ _save_conversation
   📄 Core\AI\PyGenesisAssistant\Nova\core\conversations.py (line 416)
   ⚠️  Never called

🏗️ toggle_global
   📄 Core\AI\PyGenesisAssistant\Nova\core\conversations.py (line 443)
   📞 Called by:
      • Core\AI\PyGenesisAssistant\Nova\ui\header.py (line 264)
      • Core\AI\PyGenesisAssistant\Nova\ui\conversations_dialog.py (line 79)
      • Core\AI\PyGenesisAssistant\Nova\ui\conversations_dialog.py (line 301)

🏗️ export_for_training
   📄 Core\AI\PyGenesisAssistant\Nova\core\conversations.py (line 466)
   ⚠️  Never called

🏗️ export_all_for_training
   📄 Core\AI\PyGenesisAssistant\Nova\core\conversations.py (line 511)
   ⚠️  Never called

🏗️ mask_to_smooth_qpaths
   📄 Editors\ImageEditor\core\selection_helpers.py (line 8)
   ⚠️  Never called

🏗️ _solve_math
   📄 Core\AI\PyGenesisAssistant\Nova\core\engines\math_engine.py (line 61)
   ⚠️  Never called

🏗️ _natural_language_to_math
   📄 Core\AI\PyGenesisAssistant\Nova\core\engines\math_engine.py (line 89)
   ⚠️  Never called

🏗️ _clean_expression
   📄 Core\AI\PyGenesisAssistant\Nova\core\engines\math_engine.py (line 152)
   ⚠️  Never called

🏗️ get_current_layer
   📄 Editors\ImageEditor\core\layers\manager.py (line 19)
   📞 Called by:
      • Editors\ImageEditor\core\ui\timeline.py (line 170)
      • Editors\ImageEditor\core\core\state.py (line 94)
      • Editors\ImageEditor\core\core\state.py (line 101)
      • Editors\ImageEditor\core\core\state.py (line 116)
      • Editors\ImageEditor\core\core\history.py (line 13)
      • Editors\ImageEditor\core\core\history.py (line 37)
      • Editors\ImageEditor\core\core\history.py (line 68)
      • Editors\ImageEditor\core\ui\preview.py (line 339)
      • Editors\ImageEditor\core\ui\preview.py (line 452)
      • Editors\ImageEditor\core\ui\preview.py (line 504)
      • Editors\ImageEditor\core\ui\preview.py (line 589)
      • Editors\ImageEditor\core\ui\preview.py (line 779)
      • Editors\ImageEditor\core\ui\preview.py (line 932)
      • Editors\ImageEditor\core\ui\preview.py (line 2253)
      • Editors\ImageEditor\core\ui\preview.py (line 2309)
      • Editors\ImageEditor\core\ui\preview.py (line 2355)
      • Editors\ImageEditor\core\ui\preview.py (line 2379)
      • Editors\ImageEditor\core\ui\preview.py (line 2447)
      • Editors\ImageEditor\core\ui\preview.py (line 2464)
      • Editors\ImageEditor\core\ui\preview.py (line 2507)
      • Editors\ImageEditor\core\ui\preview.py (line 2535)
      • Editors\ImageEditor\core\ui\preview.py (line 2546)
      • Editors\Shared\IntegratedImageEditor.py (line 708)
      • Editors\ImageEditor\core\ui\main_window.py (line 629)
      • Editors\ImageEditor\core\ui\main_window.py (line 828)
      • Editors\ImageEditor\core\ui\main_window.py (line 868)
      • Editors\ImageEditor\core\ui\main_window.py (line 1315)
      • Editors\ImageEditor\core\ui\main_window.py (line 1353)
      • Editors\ImageEditor\core\ui\main_window.py (line 1560)
      • Editors\ImageEditor\core\ui\main_window.py (line 1835)
      • Editors\ImageEditor\core\ui\main_window.py (line 1959)
      • Editors\ImageEditor\core\ui\main_window.py (line 2100)
      • Editors\ImageEditor\core\ui\main_window.py (line 2326)
      • Editors\ImageEditor\core\ui\main_window.py (line 2356)
      • Editors\ImageEditor\core\ui\main_window.py (line 2450)
      • Editors\ImageEditor\core\ui\main_window.py (line 2495)
      • Editors\ImageEditor\core\ui\main_window.py (line 2525)
      • Editors\ImageEditor\core\ui\main_window.py (line 2650)

🏗️ get_current_frame
   📄 Editors\ImageEditor\core\layers\manager.py (line 22)
   📞 Called by:
      • Editors\ImageEditor\core\ui\preview.py (line 993)
      • Editors\ImageEditor\core\ui\preview.py (line 1109)
      • Editors\ImageEditor\core\ui\preview.py (line 2571)
      • Editors\ImageEditor\core\ui\main_window.py (line 1167)

🏗️ get_current_image
   📄 Editors\ImageEditor\core\layers\manager.py (line 25)
   📞 Called by:
      • Editors\ImageEditor\core\ui\preview.py (line 340)
      • Editors\ImageEditor\core\ui\preview.py (line 453)
      • Editors\ImageEditor\core\ui\preview.py (line 556)
      • Editors\ImageEditor\core\ui\preview.py (line 590)
      • Editors\ImageEditor\core\ui\preview.py (line 780)
      • Editors\ImageEditor\core\ui\preview.py (line 933)
      • Editors\ImageEditor\core\ui\preview.py (line 1561)
      • Editors\ImageEditor\core\ui\preview.py (line 1623)
      • Editors\ImageEditor\core\ui\preview.py (line 1892)
      • Editors\ImageEditor\core\ui\preview.py (line 1984)
      • Editors\ImageEditor\core\ui\preview.py (line 2254)
      • Editors\ImageEditor\core\ui\preview.py (line 2310)
      • Editors\ImageEditor\core\ui\preview.py (line 2359)
      • Editors\ImageEditor\core\ui\preview.py (line 2383)
      • Editors\ImageEditor\core\ui\preview.py (line 2451)
      • Editors\ImageEditor\core\ui\preview.py (line 2465)
      • Editors\ImageEditor\core\ui\preview.py (line 2508)
      • Editors\ImageEditor\core\ui\preview.py (line 2536)
      • Editors\ImageEditor\core\ui\preview.py (line 2547)
      • Editors\ImageEditor\core\ui\preview.py (line 2616)
      • Editors\ImageEditor\core\ui\main_window.py (line 536)
      • Editors\ImageEditor\core\ui\main_window.py (line 560)

🏗️ composite_layers
   📄 Editors\ImageEditor\core\layers\manager.py (line 28)
   ⚠️  Never called

🏗️ invalidate_composite_cache
   📄 Editors\ImageEditor\core\layers\manager.py (line 87)
   📞 Called by:
      • Editors\ImageEditor\core\ui\preview.py (line 98)

🏗️ ensure_minimums
   📄 Editors\ImageEditor\core\layers\manager.py (line 133)
   📞 Called by:
      • Editors\ImageEditor\core\core\state.py (line 12)
      • Editors\ImageEditor\core\core\state.py (line 42)

🏗️ sort_layers
   📄 Editors\ImageEditor\core\layers\manager.py (line 143)
   ⚠️  Never called

🏗️ ensure_frame_independence
   📄 Editors\ImageEditor\core\layers\manager.py (line 147)
   📞 Called by:
      • Editors\ImageEditor\core\app.py (line 27)

🏗️ export_pgsprite
   📄 Editors\ImageEditor\core\core\pgsprite_io.py (line 18)
   📞 Called by:
      • Editors\Shared\IntegratedImageEditor.py (line 1161)

🏗️ import_pgsprite
   📄 Editors\ImageEditor\core\core\pgsprite_io.py (line 44)
   📞 Called by:
      • Editors\Shared\IntegratedImageEditor.py (line 861)

🏗️ _export_layers
   📄 Editors\ImageEditor\core\core\pgsprite_io.py (line 65)
   ⚠️  Never called

🏗️ _import_layers
   📄 Editors\ImageEditor\core\core\pgsprite_io.py (line 93)
   ⚠️  Never called

🏗️ _export_atlas
   📄 Editors\ImageEditor\core\core\pgsprite_io.py (line 118)
   ⚠️  Never called

🏗️ _import_atlas
   📄 Editors\ImageEditor\core\core\pgsprite_io.py (line 149)
   ⚠️  Never called

🏗️ _export_settings
   📄 Editors\ImageEditor\core\core\pgsprite_io.py (line 182)
   ⚠️  Never called

🏗️ _import_settings
   📄 Editors\ImageEditor\core\core\pgsprite_io.py (line 198)
   ⚠️  Never called

🏗️ _image_to_base64
   📄 Editors\ImageEditor\core\core\pgsprite_io.py (line 212)
   ⚠️  Never called

🏗️ _base64_to_image
   📄 Editors\ImageEditor\core\core\pgsprite_io.py (line 227)
   ⚠️  Never called

🏗️ _qimage_to_base64
   📄 Editors\ImageEditor\core\core\pgsprite_io.py (line 241)
   ⚠️  Never called

🏗️ _base64_to_qimage
   📄 Editors\ImageEditor\core\core\pgsprite_io.py (line 254)
   ⚠️  Never called

🏗️ read_json_file
   📄 Core\Services\file_service.py (line 18)
   ⚠️  Never called

🏗️ write_json_file
   📄 Core\Services\file_service.py (line 39)
   ⚠️  Never called

🏗️ file_exists
   📄 Core\Services\file_service.py (line 61)
   ⚠️  Never called

🏗️ ensure_directory
   📄 Core\Services\file_service.py (line 65)
   ⚠️  Never called

🏗️ hex_to_qcolor
   📄 Editors\ImageEditor\core\core\texture_utils.py (line 7)
   📞 Called by:
      • Editors\ImageEditor\core\core\texture_utils.py (line 424)

🏗️ lerp_color
   📄 Editors\ImageEditor\core\core\texture_utils.py (line 16)
   📞 Called by:
      • Editors\ImageEditor\core\core\texture_utils.py (line 32)

🏗️ make_gradient_palette_qt
   📄 Editors\ImageEditor\core\core\texture_utils.py (line 24)
   📞 Called by:
      • Editors\ImageEditor\core\core\texture_utils.py (line 428)

🏗️ vectorized_noise
   📄 Editors\ImageEditor\core\core\texture_utils.py (line 36)
   📞 Called by:
      • Editors\ImageEditor\core\ui\dialogs\effect_dialog.py (line 1718)
      • Editors\ImageEditor\core\ui\dialogs\effect_dialog.py (line 2146)
      • Editors\ImageEditor\core\ui\dialogs\effect_dialog.py (line 2147)
      • Editors\ImageEditor\core\ui\dialogs\effect_dialog.py (line 2148)
      • Editors\ImageEditor\core\ui\dialogs\effect_dialog.py (line 2149)
      • Editors\ImageEditor\core\core\texture_utils.py (line 65)
      • Editors\ImageEditor\core\core\texture_utils.py (line 66)
      • Editors\ImageEditor\core\core\texture_utils.py (line 67)
      • Editors\ImageEditor\core\core\texture_utils.py (line 68)
      • Editors\ImageEditor\core\services\effect_processor.py (line 421)
      • Editors\ImageEditor\core\ui\main_window.py (line 4867)
      • Editors\ImageEditor\core\ui\main_window.py (line 4868)
      • Editors\ImageEditor\core\ui\main_window.py (line 4869)
      • Editors\ImageEditor\core\ui\main_window.py (line 4870)

🏗️ vectorized_smooth_noise
   📄 Editors\ImageEditor\core\core\texture_utils.py (line 58)
   📞 Called by:
      • Editors\ImageEditor\core\ui\dialogs\effect_dialog.py (line 2163)
      • Editors\ImageEditor\core\core\texture_utils.py (line 82)
      • Editors\ImageEditor\core\ui\main_window.py (line 4884)

🏗️ vectorized_fractal_noise
   📄 Editors\ImageEditor\core\core\texture_utils.py (line 74)
   📞 Called by:
      • Editors\ImageEditor\core\ui\dialogs\effect_dialog.py (line 2194)
      • Editors\ImageEditor\core\ui\dialogs\effect_dialog.py (line 2197)
      • Editors\ImageEditor\core\ui\dialogs\effect_dialog.py (line 2198)
      • Editors\ImageEditor\core\ui\dialogs\effect_dialog.py (line 2226)
      • Editors\ImageEditor\core\ui\dialogs\effect_dialog.py (line 2231)
      • Editors\ImageEditor\core\ui\dialogs\effect_dialog.py (line 2236)
      • Editors\ImageEditor\core\ui\dialogs\effect_dialog.py (line 2241)
      • Editors\ImageEditor\core\ui\dialogs\effect_dialog.py (line 2245)
      • Editors\ImageEditor\core\ui\dialogs\effect_dialog.py (line 2246)
      • Editors\ImageEditor\core\core\texture_utils.py (line 105)
      • Editors\ImageEditor\core\core\texture_utils.py (line 108)
      • Editors\ImageEditor\core\core\texture_utils.py (line 111)
      • Editors\ImageEditor\core\core\texture_utils.py (line 179)
      • Editors\ImageEditor\core\core\texture_utils.py (line 182)
      • Editors\ImageEditor\core\core\texture_utils.py (line 222)
      • Editors\ImageEditor\core\core\texture_utils.py (line 225)
      • Editors\ImageEditor\core\core\texture_utils.py (line 228)
      • Editors\ImageEditor\core\core\texture_utils.py (line 260)
      • Editors\ImageEditor\core\core\texture_utils.py (line 263)
      • Editors\ImageEditor\core\core\texture_utils.py (line 266)
      • Editors\ImageEditor\core\core\texture_utils.py (line 298)
      • Editors\ImageEditor\core\core\texture_utils.py (line 301)
      • Editors\ImageEditor\core\core\texture_utils.py (line 339)
      • Editors\ImageEditor\core\core\texture_utils.py (line 342)
      • Editors\ImageEditor\core\core\texture_utils.py (line 375)
      • Editors\ImageEditor\core\core\texture_utils.py (line 378)
      • Editors\ImageEditor\core\core\texture_utils.py (line 381)
      • Editors\ImageEditor\core\core\texture_utils.py (line 480)
      • Editors\ImageEditor\core\core\texture_utils.py (line 490)
      • Editors\ImageEditor\core\core\texture_utils.py (line 491)
      • Editors\ImageEditor\core\core\texture_utils.py (line 498)
      • Editors\ImageEditor\core\ui\main_window.py (line 4904)
      • Editors\ImageEditor\core\ui\main_window.py (line 4907)
      • Editors\ImageEditor\core\ui\main_window.py (line 4908)
      • Editors\ImageEditor\core\ui\main_window.py (line 4936)
      • Editors\ImageEditor\core\ui\main_window.py (line 4941)
      • Editors\ImageEditor\core\ui\main_window.py (line 4946)
      • Editors\ImageEditor\core\ui\main_window.py (line 4951)
      • Editors\ImageEditor\core\ui\main_window.py (line 4955)
      • Editors\ImageEditor\core\ui\main_window.py (line 4956)

🏗️ animate_palette_qt
   📄 Editors\ImageEditor\core\core\texture_utils.py (line 89)
   📞 Called by:
      • Editors\ImageEditor\core\core\texture_utils.py (line 440)

🏗️ generate_block_texture_qimage
   📄 Editors\ImageEditor\core\core\texture_utils.py (line 417)
   📞 Called by:
      • Editors\ImageEditor\core\ui\dialogs\effect_dialog.py (line 2459)
      • Editors\ImageEditor\core\core\atlas_manager.py (line 159)
      • Editors\ImageEditor\core\ui\character_creator_dialog.py (line 1115)
      • Editors\ImageEditor\core\ui\character_creator_dialog.py (line 1140)
      • Editors\ImageEditor\core\ui\character_creator_dialog.py (line 1163)
      • Editors\ImageEditor\core\ui\character_creator_dialog.py (line 1190)
      • Editors\ImageEditor\core\ui\character_creator_dialog.py (line 1213)
      • Editors\ImageEditor\core\ui\character_creator_dialog.py (line 1241)
      • Editors\ImageEditor\core\ui\character_creator_dialog.py (line 1261)
      • Editors\ImageEditor\core\ui\character_creator_dialog.py (line 1278)
      • Editors\ImageEditor\core\ui\character_creator_dialog.py (line 1294)
      • Editors\ImageEditor\core\ui\character_creator_dialog.py (line 1311)
      • Editors\ImageEditor\core\ui\character_creator_dialog.py (line 1328)
      • Editors\ImageEditor\core\ui\character_creator_dialog.py (line 1337)
      • Editors\ImageEditor\core\ui\character_creator_dialog.py (line 1345)
      • Editors\ImageEditor\core\ui\character_creator_dialog.py (line 1354)
      • Editors\ImageEditor\core\ui\character_creator_dialog.py (line 1364)
      • Editors\ImageEditor\core\ui\character_creator_dialog.py (line 1386)
      • Editors\ImageEditor\core\ui\character_creator_dialog.py (line 1450)
      • Editors\ImageEditor\core\ui\character_creator_dialog.py (line 1470)
      • Editors\ImageEditor\core\ui\character_creator_dialog.py (line 1493)
      • Editors\ImageEditor\core\ui\character_creator_dialog.py (line 1520)
      • Editors\ImageEditor\core\ui\character_creator_dialog.py (line 1543)
      • Editors\ImageEditor\core\ui\character_creator_dialog.py (line 1571)
      • Editors\ImageEditor\core\ui\character_creator_dialog.py (line 1593)
      • Editors\ImageEditor\core\ui\character_creator_dialog.py (line 1609)
      • Editors\ImageEditor\core\ui\character_creator_dialog.py (line 1618)
      • Editors\ImageEditor\core\ui\character_creator_dialog.py (line 1626)
      • Editors\ImageEditor\core\ui\character_creator_dialog.py (line 1635)
      • Editors\ImageEditor\core\ui\character_creator_dialog.py (line 1645)
      • Editors\ImageEditor\core\ui\character_creator_dialog.py (line 1667)
      • Editors\ImageEditor\core\ui\character_creator_dialog.py (line 1731)
      • Editors\ImageEditor\core\ui\character_creator_dialog.py (line 1755)
      • Editors\ImageEditor\core\ui\character_creator_dialog.py (line 1780)
      • Editors\ImageEditor\core\ui\character_creator_dialog.py (line 1807)
      • Editors\ImageEditor\core\ui\character_creator_dialog.py (line 1827)
      • Editors\ImageEditor\core\ui\character_creator_dialog.py (line 1834)
      • Editors\ImageEditor\core\ui\character_creator_dialog.py (line 1860)
      • Editors\ImageEditor\core\ui\character_creator_dialog.py (line 1867)
      • Editors\ImageEditor\core\ui\character_creator_dialog.py (line 1891)
      • Editors\ImageEditor\core\ui\character_creator_dialog.py (line 1911)
      • Editors\ImageEditor\core\ui\character_creator_dialog.py (line 1927)
      • Editors\ImageEditor\core\ui\character_creator_dialog.py (line 2018)
      • Editors\ImageEditor\core\ui\character_creator_dialog.py (line 2040)
      • Editors\ImageEditor\core\ui\character_creator_dialog.py (line 2061)
      • Editors\ImageEditor\core\ui\character_creator_dialog.py (line 2077)
      • Editors\ImageEditor\core\ui\character_creator_dialog.py (line 2087)
      • Editors\ImageEditor\core\ui\character_creator_dialog.py (line 2095)
      • Editors\ImageEditor\core\ui\character_creator_dialog.py (line 2104)
      • Editors\ImageEditor\core\ui\character_creator_dialog.py (line 2114)
      • Editors\ImageEditor\core\ui\character_creator_dialog.py (line 2133)
      • Editors\ImageEditor\core\ui\block_texture_dialog.py (line 583)
      • Editors\ImageEditor\core\ui\main_window.py (line 5704)
      • Editors\ImageEditor\core\ui\main_window.py (line 5808)

🏗️ apply_style_effects
   📄 Editors\ImageEditor\core\core\texture_utils.py (line 523)
   📞 Called by:
      • Editors\ImageEditor\core\core\texture_utils.py (line 434)

🏗️ apply_water_style
   📄 Editors\ImageEditor\core\core\texture_utils.py (line 544)
   📞 Called by:
      • Editors\ImageEditor\core\core\texture_utils.py (line 526)

🏗️ apply_lava_style
   📄 Editors\ImageEditor\core\core\texture_utils.py (line 582)
   📞 Called by:
      • Editors\ImageEditor\core\core\texture_utils.py (line 528)

🏗️ apply_fire_style
   📄 Editors\ImageEditor\core\core\texture_utils.py (line 625)
   📞 Called by:
      • Editors\ImageEditor\core\core\texture_utils.py (line 530)

🏗️ apply_smoke_style
   📄 Editors\ImageEditor\core\core\texture_utils.py (line 675)
   📞 Called by:
      • Editors\ImageEditor\core\core\texture_utils.py (line 532)

🏗️ apply_fog_style
   📄 Editors\ImageEditor\core\core\texture_utils.py (line 721)
   📞 Called by:
      • Editors\ImageEditor\core\core\texture_utils.py (line 534)

🏗️ apply_crystal_style
   📄 Editors\ImageEditor\core\core\texture_utils.py (line 765)
   📞 Called by:
      • Editors\ImageEditor\core\core\texture_utils.py (line 536)

🏗️ apply_wind_style
   📄 Editors\ImageEditor\core\core\texture_utils.py (line 812)
   📞 Called by:
      • Editors\ImageEditor\core\core\texture_utils.py (line 538)

🏗️ apply_portal_style
   📄 Editors\ImageEditor\core\core\texture_utils.py (line 859)
   📞 Called by:
      • Editors\ImageEditor\core\core\texture_utils.py (line 540)

🏗️ clear_history
   📄 Editors\ImageEditor\core\core\history.py (line 96)
   ⚠️  Never called

🏗️ stop
   📄 Core\Services\async_project_saver.py (line 29)
   📞 Called by:
      • Core\AI\PyGenesisAssistant\CodeAnalyser.py (line 411)
      • Core\AI\PyGenesisAssistant\CodeAnalyser.py (line 421)
      • Core\Code\Unified\unified_code_editor.py (line 543)
      • Core\Code\Unified\unified_code_editor.py (line 548)
      • Core\Code\Unified\unified_code_editor.py (line 831)
      • Editors\ImageEditor\core\ui\panels\right_panel.py (line 634)
      • Core\AI\PyGenesisAssistant\DependencyAnalyser.py (line 315)
      • Core\AI\PyGenesisAssistant\DependencyAnalyser.py (line 325)
      • Editors\ImageEditor\core\ui\rotate_dialog.py (line 211)
      • Core\AI\PyGenesisAssistant\Nova\ui\input_bar.py (line 222)
      • Core\AI\PyGenesisAssistant\Nova\ui\input_bar.py (line 227)
      • Editors\ImageEditor\core\ui\timeline.py (line 1324)
      • Editors\ImageEditor\core\ui\texture_atlas_dialog.py (line 143)
      • Editors\ImageEditor\core\ui\texture_atlas_dialog.py (line 595)
      • Editors\ImageEditor\core\core\ai_test_app.py (line 729)
      • Editors\ImageEditor\core\ui\character_creator_dialog.py (line 904)
      • Core\AI\PyGenesisAssistant\UnifiedCodeAnalyzer.py (line 846)
      • Core\AI\PyGenesisAssistant\UnifiedCodeAnalyzer.py (line 942)
      • Core\AI\PyGenesisAssistant\UnifiedCodeAnalyzer.py (line 962)
      • Editors\ImageEditor\core\ui\ai_dialogs.py (line 962)
      • Editors\Shared\BaseImageResourceEditor.py (line 573)
      • Editors\Shared\BaseImageResourceEditor.py (line 637)
      • Editors\SoundEditor\SoundEditor.py (line 786)
      • Editors\SoundEditor\SoundEditor.py (line 789)
      • Editors\SoundEditor\SoundEditor.py (line 790)
      • Editors\SoundEditor\SoundEditor.py (line 1632)
      • Editors\SoundEditor\SoundEditor.py (line 1643)
      • Editors\SoundEditor\SoundEditor.py (line 1655)
      • Editors\SoundEditor\SoundEditor.py (line 1706)
      • Editors\SoundEditor\SoundEditor.py (line 1904)
      • Editors\SoundEditor\SoundEditor.py (line 1908)
      • UI\Widgets\LoadingWidget.py (line 61)
      • UI\Widgets\ResourceTree.py (line 139)
      • Editors\ImageEditor\core\ui\preview.py (line 110)
      • Editors\ImageEditor\core\ui\preview.py (line 2161)
      • Editors\SoundEditor\core\WaveForge.py (line 1011)
      • Editors\SoundEditor\core\WaveForge.py (line 1220)
      • Editors\SoundEditor\core\WaveForge.py (line 1221)
      • Editors\ModelEditor\ModelEditor.py (line 9784)
      • Editors\ModelEditor\ModelEditor.py (line 9950)

🏗️ __deepcopy__
   📄 Editors\ImageEditor\core\layers\layer.py (line 10)
   ⚠️  Never called

🏗️ get_frame
   📄 Editors\ImageEditor\core\layers\layer.py (line 57)
   📞 Called by:
      • Editors\ImageEditor\core\layers\manager.py (line 23)

🏗️ set_frame
   📄 Editors\ImageEditor\core\layers\layer.py (line 64)
   ⚠️  Never called

🏗️ get_history_for_frame
   📄 Editors\ImageEditor\core\layers\layer.py (line 67)
   ⚠️  Never called

🏗️ generate_base_image
   📄 Editors\ImageEditor\core\core\gemini_client.py (line 47)
   📞 Called by:
      • Editors\ImageEditor\core\core\ai_worker_threads.py (line 39)

🏗️ analyze_frame_changes
   📄 Editors\ImageEditor\core\core\gemini_client.py (line 122)
   📞 Called by:
      • Editors\ImageEditor\core\core\ai_worker_threads.py (line 82)

🏗️ refine_animation
   📄 Editors\ImageEditor\core\core\gemini_client.py (line 210)
   📞 Called by:
      • Editors\ImageEditor\core\core\ai_worker_threads.py (line 95)

🏗️ detect_anchors
   📄 Editors\ImageEditor\core\core\gemini_client.py (line 247)
   📞 Called by:
      • Editors\ImageEditor\core\core\ai_worker_threads.py (line 150)

🏗️ _extract_image_from_response
   📄 Editors\ImageEditor\core\core\gemini_client.py (line 282)
   ⚠️  Never called

🏗️ _encode_image_for_cache
   📄 Editors\ImageEditor\core\core\gemini_client.py (line 304)
   ⚠️  Never called

🏗️ _decode_image_from_cache
   📄 Editors\ImageEditor\core\core\gemini_client.py (line 311)
   ⚠️  Never called

🏗️ _validate_changes
   📄 Editors\ImageEditor\core\core\gemini_client.py (line 317)
   ⚠️  Never called

🏗️ has_selection
   📄 Editors\ImageEditor\core\core\selection_manager.py (line 34)
   📞 Called by:
      • Editors\ImageEditor\core\ui\dialogs\effect_dialog.py (line 68)
      • Editors\ImageEditor\core\core\state.py (line 63)
      • Editors\ImageEditor\core\core\history.py (line 19)
      • Editors\ImageEditor\core\core\history.py (line 43)
      • Editors\ImageEditor\core\core\history.py (line 74)
      • Editors\ImageEditor\core\ui\preview.py (line 230)
      • Editors\ImageEditor\core\ui\preview.py (line 271)
      • Editors\ImageEditor\core\ui\preview.py (line 368)
      • Editors\ImageEditor\core\ui\preview.py (line 419)
      • Editors\ImageEditor\core\ui\preview.py (line 930)
      • Editors\ImageEditor\core\ui\preview.py (line 1918)
      • Editors\ImageEditor\core\ui\preview.py (line 2298)
      • Editors\ImageEditor\core\ui\preview.py (line 2332)
      • Editors\ImageEditor\core\ui\preview.py (line 2352)
      • Editors\ImageEditor\core\ui\preview.py (line 2462)
      • Editors\ImageEditor\core\ui\preview.py (line 2482)
      • Editors\ImageEditor\core\ui\preview.py (line 2974)
      • Editors\ImageEditor\core\ui\main_window.py (line 481)
      • Editors\ImageEditor\core\ui\main_window.py (line 555)
      • Editors\ImageEditor\core\ui\main_window.py (line 754)
      • Editors\ImageEditor\core\ui\main_window.py (line 1185)
      • Editors\ImageEditor\core\ui\main_window.py (line 2534)
      • Editors\ImageEditor\core\ui\main_window.py (line 2836)
      • Editors\ImageEditor\core\ui\main_window.py (line 3208)
      • Editors\ImageEditor\core\ui\main_window.py (line 6189)

🏗️ get_selection_bounds
   📄 Editors\ImageEditor\core\core\selection_manager.py (line 43)
   📞 Called by:
      • Editors\ImageEditor\core\ui\dialogs\effect_dialog.py (line 70)
      • Editors\ImageEditor\core\ui\preview.py (line 438)
      • Editors\ImageEditor\core\ui\preview.py (line 466)
      • Editors\ImageEditor\core\ui\preview.py (line 1924)
      • Editors\ImageEditor\core\ui\preview.py (line 2363)
      • Editors\ImageEditor\core\ui\preview.py (line 2393)
      • Editors\ImageEditor\core\ui\main_window.py (line 485)
      • Editors\ImageEditor\core\ui\main_window.py (line 663)
      • Editors\ImageEditor\core\ui\main_window.py (line 759)
      • Editors\ImageEditor\core\ui\main_window.py (line 815)
      • Editors\ImageEditor\core\ui\main_window.py (line 2837)
      • Editors\ImageEditor\core\ui\main_window.py (line 3209)
      • Editors\ImageEditor\core\ui\main_window.py (line 6190)

🏗️ _update_bounds
   📄 Editors\ImageEditor\core\core\selection_manager.py (line 60)
   📞 Called by:
      • Editors\ImageEditor\core\ui\preview.py (line 363)
      • Editors\ImageEditor\core\ui\preview.py (line 598)
      • Editors\ImageEditor\core\ui\preview.py (line 2279)
      • Editors\ImageEditor\core\ui\preview.py (line 2500)

🏗️ select_rect
   📄 Editors\ImageEditor\core\core\selection_manager.py (line 67)
   📞 Called by:
      • Editors\ImageEditor\core\ui\preview.py (line 808)
      • Editors\ImageEditor\core\ui\preview.py (line 2424)
      • Editors\ImageEditor\core\ui\preview.py (line 2427)
      • Editors\ImageEditor\core\ui\preview.py (line 2456)
      • Editors\ImageEditor\core\ui\main_window.py (line 546)

🏗️ select_magic_wand_opencv
   📄 Editors\ImageEditor\core\core\selection_manager.py (line 82)
   ⚠️  Never called

🏗️ select_magic_wand_python
   📄 Editors\ImageEditor\core\core\selection_manager.py (line 229)
   ⚠️  Never called

🏗️ select_sam
   📄 Editors\ImageEditor\core\core\selection_manager.py (line 335)
   ⚠️  Never called

🏗️ brush_select
   📄 Editors\ImageEditor\core\core\selection_manager.py (line 376)
   📞 Called by:
      • Editors\ImageEditor\core\ui\preview.py (line 2325)

🏗️ lasso_select
   📄 Editors\ImageEditor\core\core\selection_manager.py (line 395)
   📞 Called by:
      • Editors\ImageEditor\core\ui\preview.py (line 2529)

🏗️ invert_selection
   📄 Editors\ImageEditor\core\core\selection_manager.py (line 925)
   📞 Called by:
      • Editors\ImageEditor\core\ui\preview.py (line 2550)

🏗️ expand_selection
   📄 Editors\ImageEditor\core\core\selection_manager.py (line 434)
   📞 Called by:
      • Editors\ImageEditor\core\ui\preview.py (line 2556)

🏗️ contract_selection
   📄 Editors\ImageEditor\core\core\selection_manager.py (line 457)
   📞 Called by:
      • Editors\ImageEditor\core\ui\preview.py (line 2562)

🏗️ update_marching_ants
   📄 Editors\ImageEditor\core\core\selection_manager.py (line 481)
   📞 Called by:
      • Editors\ImageEditor\core\ui\preview.py (line 231)

🏗️ get_handle_at_position
   📄 Editors\ImageEditor\core\core\selection_manager.py (line 485)
   📞 Called by:
      • Editors\ImageEditor\core\ui\preview.py (line 431)

🏗️ draw_selection_overlay
   📄 Editors\ImageEditor\core\core\selection_manager.py (line 519)
   📞 Called by:
      • Editors\ImageEditor\core\ui\preview.py (line 2980)

🏗️ draw_rectangle_preview
   📄 Editors\ImageEditor\core\core\selection_manager.py (line 665)
   📞 Called by:
      • Editors\ImageEditor\core\ui\preview.py (line 2881)

🏗️ _draw_resize_handles
   📄 Editors\ImageEditor\core\core\selection_manager.py (line 710)
   ⚠️  Never called

🏗️ _draw_resize_handles_rect
   📄 Editors\ImageEditor\core\core\selection_manager.py (line 728)
   ⚠️  Never called

🏗️ _draw_resize_handles_at_bounds
   📄 Editors\ImageEditor\core\core\selection_manager.py (line 732)
   ⚠️  Never called

🏗️ delete_selection
   📄 Editors\ImageEditor\core\core\selection_manager.py (line 769)
   📞 Called by:
      • Editors\ImageEditor\core\ui\preview.py (line 2338)
      • Editors\ImageEditor\core\ui\preview.py (line 2468)
      • Editors\SoundEditor\core\WaveForge.py (line 346)

🏗️ point_in_selection
   📄 Editors\ImageEditor\core\core\selection_manager.py (line 796)
   ⚠️  Never called

🏗️ move_selection
   📄 Editors\ImageEditor\core\core\selection_manager.py (line 805)
   📞 Called by:
      • Editors\ImageEditor\core\ui\preview.py (line 657)

🏗️ move_selection_by_keys
   📄 Editors\ImageEditor\core\core\selection_manager.py (line 852)
   📞 Called by:
      • Editors\ImageEditor\core\ui\preview.py (line 936)

🏗️ add_to_selection
   📄 Editors\ImageEditor\core\core\selection_manager.py (line 900)
   📞 Called by:
      • Editors\ImageEditor\core\ui\preview.py (line 356)
      • Editors\ImageEditor\core\ui\preview.py (line 794)
      • Editors\ImageEditor\core\ui\preview.py (line 2274)

🏗️ subtract_from_selection
   📄 Editors\ImageEditor\core\core\selection_manager.py (line 909)
   📞 Called by:
      • Editors\ImageEditor\core\ui\preview.py (line 359)
      • Editors\ImageEditor\core\ui\preview.py (line 805)
      • Editors\ImageEditor\core\ui\preview.py (line 2276)

🏗️ intersect_selection
   📄 Editors\ImageEditor\core\core\selection_manager.py (line 917)
   ⚠️  Never called

🏗️ get_selected_content
   📄 Editors\ImageEditor\core\core\selection_manager.py (line 938)
   ⚠️  Never called

🏗️ paste_content
   📄 Editors\ImageEditor\core\core\selection_manager.py (line 967)
   ⚠️  Never called

🏗️ check_and_install_dependencies
   📄 Editors\ImageEditor\core\core\ai_test_app.py (line 12)
   📞 Called by:
      • Editors\ImageEditor\core\core\ai_test_app.py (line 70)
      • main.py (line 473)

🏗️ load_tool_knowledge
   📄 Editors\ImageEditor\core\core\ai_test_app.py (line 497)
   📞 Called by:
      • Editors\ImageEditor\core\core\ai_test_app.py (line 139)
      • Editors\ImageEditor\core\core\ai_test_app.py (line 500)

🏗️ create_system_prompt
   📄 Editors\ImageEditor\core\core\ai_test_app.py (line 111)
   📞 Called by:
      • Editors\ImageEditor\core\core\ai_test_app.py (line 141)

🏗️ generate_instructions_with_ai
   📄 Editors\ImageEditor\core\core\ai_test_app.py (line 136)
   📞 Called by:
      • Editors\ImageEditor\core\core\ai_test_app.py (line 563)

🏗️ execute_instructions
   📄 Editors\ImageEditor\core\core\ai_test_app.py (line 235)
   📞 Called by:
      • Editors\ImageEditor\core\core\ai_test_app.py (line 596)
      • Editors\ImageEditor\core\core\ai_test_app.py (line 622)

🏗️ hex_to_rgba
   📄 Editors\ImageEditor\core\core\ai_test_app.py (line 241)
   📞 Called by:
      • Editors\ImageEditor\core\core\ai_test_app.py (line 276)
      • Editors\ImageEditor\core\core\ai_test_app.py (line 283)
      • Editors\ImageEditor\core\core\ai_test_app.py (line 287)
      • Editors\ImageEditor\core\core\ai_test_app.py (line 289)

🏗️ draw_circle
   📄 Editors\ImageEditor\core\core\ai_test_app.py (line 245)
   📞 Called by:
      • Editors\ImageEditor\core\core\ai_test_app.py (line 285)

🏗️ draw_rectangle
   📄 Editors\ImageEditor\core\core\ai_test_app.py (line 252)
   📞 Called by:
      • Editors\ImageEditor\core\core\ai_test_app.py (line 287)

🏗️ draw_ellipse
   📄 Editors\ImageEditor\core\core\ai_test_app.py (line 259)
   📞 Called by:
      • Editors\ImageEditor\core\core\ai_test_app.py (line 289)

🏗️ on_api_key_changed
   📄 Editors\ImageEditor\core\core\ai_test_app.py (line 504)
   ⚠️  Never called

🏗️ on_generate
   📄 Editors\ImageEditor\core\core\ai_test_app.py (line 522)
   ⚠️  Never called

🏗️ execute_instructions_animated
   📄 Editors\ImageEditor\core\core\ai_test_app.py (line 617)
   ⚠️  Never called

🏗️ draw_shooting_star
   📄 Editors\ImageEditor\core\core\ai_test_app.py (line 640)
   ⚠️  Never called

🏗️ update_frame_controls
   📄 Editors\ImageEditor\core\core\ai_test_app.py (line 683)
   ⚠️  Never called

🏗️ update_frame_counter
   📄 Editors\ImageEditor\core\core\ai_test_app.py (line 691)
   ⚠️  Never called

🏗️ toggle_playback
   📄 Editors\ImageEditor\core\core\ai_test_app.py (line 711)
   ⚠️  Never called

🏗️ start_playback
   📄 Editors\ImageEditor\core\core\ai_test_app.py (line 718)
   📞 Called by:
      • Editors\SoundEditor\SoundEditor.py (line 2766)

🏗️ pause_playback
   📄 Editors\ImageEditor\core\core\ai_test_app.py (line 725)
   ⚠️  Never called

🏗️ stop_playback
   📄 Editors\ImageEditor\core\core\ai_test_app.py (line 731)
   ⚠️  Never called

🏗️ on_playback_tick
   📄 Editors\ImageEditor\core\core\ai_test_app.py (line 738)
   ⚠️  Never called

🏗️ on_save
   📄 Editors\ImageEditor\core\core\ai_test_app.py (line 747)
   ⚠️  Never called

🏗️ check_venv_permissions
   📄 Editors\ImageEditor\core\core\venv_fix_tool.py (line 17)
   ⚠️  Never called

🏗️ find_locked_files
   📄 Editors\ImageEditor\core\core\venv_fix_tool.py (line 59)
   ⚠️  Never called

🏗️ check_running_python_processes
   📄 Editors\ImageEditor\core\core\venv_fix_tool.py (line 87)
   ⚠️  Never called

🏗️ suggest_fixes
   📄 Editors\ImageEditor\core\core\venv_fix_tool.py (line 119)
   ⚠️  Never called

🏗️ _create_default_grid
   📄 Editors\ImageEditor\core\core\atlas_manager.py (line 47)
   ⚠️  Never called

🏗️ set_canvas_size
   📄 Editors\ImageEditor\core\core\atlas_manager.py (line 62)
   📞 Called by:
      • Editors\ImageEditor\core\core\state.py (line 43)

🏗️ _recalculate_grid_layout
   📄 Editors\ImageEditor\core\core\atlas_manager.py (line 68)
   ⚠️  Never called

🏗️ add_cell
   📄 Editors\ImageEditor\core\core\atlas_manager.py (line 91)
   📞 Called by:
      • Editors\ImageEditor\core\ui\texture_atlas_dialog.py (line 760)

🏗️ remove_cell
   📄 Editors\ImageEditor\core\core\atlas_manager.py (line 110)
   📞 Called by:
      • Editors\ImageEditor\core\ui\texture_atlas_dialog.py (line 770)

🏗️ _generate_texture_using_2d_creation_logic
   📄 Editors\ImageEditor\core\core\atlas_manager.py (line 118)
   ⚠️  Never called

🏗️ generate_cell_texture
   📄 Editors\ImageEditor\core\core\atlas_manager.py (line 172)
   📞 Called by:
      • Editors\ImageEditor\core\ui\texture_atlas_dialog.py (line 110)
      • Editors\ImageEditor\core\ui\texture_atlas_dialog.py (line 524)
      • Editors\ImageEditor\core\ui\texture_atlas_dialog.py (line 527)

🏗️ generate_atlas_image
   📄 Editors\ImageEditor\core\core\atlas_manager.py (line 182)
   📞 Called by:
      • Editors\ImageEditor\core\ui\texture_atlas_dialog.py (line 877)

🏗️ generate_all_frames
   📄 Editors\ImageEditor\core\core\atlas_manager.py (line 221)
   ⚠️  Never called

🏗️ get_frame_count
   📄 Editors\ImageEditor\core\core\atlas_manager.py (line 230)
   ⚠️  Never called

🏗️ _qimage_to_numpy
   📄 Editors\ImageEditor\core\core\atlas_manager.py (line 234)
   ⚠️  Never called

🏗️ _numpy_to_qcolor
   📄 Editors\ImageEditor\core\core\atlas_manager.py (line 255)
   ⚠️  Never called

🏗️ get_atlas_state
   📄 Editors\ImageEditor\core\core\atlas_manager.py (line 319)
   ⚠️  Never called

🏗️ set_atlas_state
   📄 Editors\ImageEditor\core\core\atlas_manager.py (line 349)
   ⚠️  Never called

🏗️ get_theme
   📄 Editors\ImageEditor\core\core\themes.py (line 37)
   📞 Called by:
      • Editors\ImageEditor\core\ui\panels\right_panel.py (line 271)
      • Editors\ImageEditor\core\ui\panels\left_panel.py (line 537)
      • Editors\ImageEditor\core\ui\preview.py (line 27)
      • Editors\ImageEditor\core\ui\preview.py (line 3105)
      • Editors\ImageEditor\core\ui\main_window.py (line 1093)

🏗️ _start_workers
   📄 Editors\ImageEditor\core\core\background_processor.py (line 104)
   ⚠️  Never called

🏗️ submit_task
   📄 Editors\ImageEditor\core\core\background_processor.py (line 117)
   ⚠️  Never called

🏗️ get_task_status
   📄 Editors\ImageEditor\core\core\background_processor.py (line 130)
   ⚠️  Never called

🏗️ get_task_result
   📄 Editors\ImageEditor\core\core\background_processor.py (line 136)
   ⚠️  Never called

🏗️ cancel_task
   📄 Editors\ImageEditor\core\core\background_processor.py (line 142)
   ⚠️  Never called

🏗️ cleanup_completed_tasks
   📄 Editors\ImageEditor\core\core\background_processor.py (line 154)
   ⚠️  Never called

🏗️ shutdown
   📄 Editors\ImageEditor\core\core\background_processor.py (line 167)
   ⚠️  Never called

🏗️ get_background_processor
   📄 Editors\ImageEditor\core\core\background_processor.py (line 183)
   📞 Called by:
      • Editors\ImageEditor\core\app.py (line 12)

🏗️ shutdown_background_processor
   📄 Editors\ImageEditor\core\core\background_processor.py (line 190)
   📞 Called by:
      • Editors\ImageEditor\core\app.py (line 19)
      • Editors\ImageEditor\core\app.py (line 33)

🏗️ check_package_with_dependencies
   📄 Editors\ImageEditor\core\core\ai_requirements.py (line 43)
   ⚠️  Never called

🏗️ check_package
   📄 Editors\ImageEditor\core\core\ai_requirements.py (line 77)
   ⚠️  Never called

🏗️ check_all_packages
   📄 Editors\ImageEditor\core\core\ai_requirements.py (line 157)
   ⚠️  Never called

🏗️ get_missing_packages
   📄 Editors\ImageEditor\core\core\ai_requirements.py (line 171)
   ⚠️  Never called

🏗️ get_package_display_name
   📄 Editors\ImageEditor\core\core\ai_requirements.py (line 180)
   ⚠️  Never called

🏗️ get_package_description
   📄 Editors\ImageEditor\core\core\ai_requirements.py (line 186)
   ⚠️  Never called

🏗️ _check_and_raise_quota_error
   📄 Editors\ImageEditor\core\core\ai_image_operations.py (line 23)
   📞 Called by:
      • Editors\ImageEditor\core\core\ai_image_operations.py (line 221)
      • Editors\ImageEditor\core\core\ai_image_operations.py (line 251)
      • Editors\ImageEditor\core\core\ai_image_operations.py (line 289)
      • Editors\ImageEditor\core\core\ai_image_operations.py (line 324)

🏗️ generate_image
   📄 Editors\ImageEditor\core\core\ai_image_operations.py (line 114)
   ⚠️  Never called

🏗️ inpaint_image
   📄 Editors\ImageEditor\core\core\ai_image_operations.py (line 133)
   ⚠️  Never called

🏗️ generate_animation_frames
   📄 Editors\ImageEditor\core\core\ai_image_operations.py (line 171)
   ⚠️  Never called

🏗️ _remove_background_gemini
   📄 Editors\ImageEditor\core\core\ai_image_operations.py (line 193)
   ⚠️  Never called

🏗️ _generate_gemini
   📄 Editors\ImageEditor\core\core\ai_image_operations.py (line 225)
   ⚠️  Never called

🏗️ _inpaint_gemini
   📄 Editors\ImageEditor\core\core\ai_image_operations.py (line 255)
   ⚠️  Never called

🏗️ _generate_animation_gemini
   📄 Editors\ImageEditor\core\core\ai_image_operations.py (line 293)
   ⚠️  Never called

🏗️ _generate_openai
   📄 Editors\ImageEditor\core\core\ai_image_operations.py (line 330)
   ⚠️  Never called

🏗️ _inpaint_openai
   📄 Editors\ImageEditor\core\core\ai_image_operations.py (line 390)
   ⚠️  Never called

🏗️ _generate_animation_openai
   📄 Editors\ImageEditor\core\core\ai_image_operations.py (line 460)
   ⚠️  Never called

🏗️ _remove_background_claude
   📄 Editors\ImageEditor\core\core\ai_image_operations.py (line 477)
   ⚠️  Never called

🏗️ _generate_claude
   📄 Editors\ImageEditor\core\core\ai_image_operations.py (line 483)
   ⚠️  Never called

🏗️ _inpaint_claude
   📄 Editors\ImageEditor\core\core\ai_image_operations.py (line 490)
   ⚠️  Never called

🏗️ _generate_animation_claude
   📄 Editors\ImageEditor\core\core\ai_image_operations.py (line 497)
   ⚠️  Never called

🏗️ _extract_image_from_gemini_response
   📄 Editors\ImageEditor\core\core\ai_image_operations.py (line 504)
   ⚠️  Never called

🏗️ _extract_multiple_images_from_gemini_response
   📄 Editors\ImageEditor\core\core\ai_image_operations.py (line 524)
   ⚠️  Never called

🏗️ get_value
   📄 Editors\ImageEditor\core\ui\dialogs\parameter_widgets.py (line 241)
   ⚠️  Never called

🏗️ set_value
   📄 Editors\ImageEditor\core\ui\dialogs\parameter_widgets.py (line 248)
   📞 Called by:
      • Editors\ImageEditor\core\ui\dialogs\effect_dialog.py (line 2548)

🏗️ set_color
   📄 Editors\ImageEditor\core\ui\dialogs\parameter_widgets.py (line 116)
   📞 Called by:
      • Editors\ImageEditor\core\ui\character_creator_dialog.py (line 885)
      • Editors\ImageEditor\core\ui\character_creator_dialog.py (line 886)
      • Editors\ImageEditor\core\ui\character_creator_dialog.py (line 888)
      • Editors\ImageEditor\core\ui\character_creator_dialog.py (line 891)
      • Editors\ImageEditor\core\ui\character_creator_dialog.py (line 897)
      • Editors\ImageEditor\core\ui\character_creator_dialog.py (line 898)
      • Editors\ImageEditor\core\ui\character_creator_dialog.py (line 899)

🏗️ add_color_item
   📄 Editors\ImageEditor\core\ui\dialogs\parameter_widgets.py (line 217)
   ⚠️  Never called

🏗️ add_color
   📄 Editors\ImageEditor\core\ui\dialogs\parameter_widgets.py (line 229)
   ⚠️  Never called

🏗️ remove_color
   📄 Editors\ImageEditor\core\ui\dialogs\parameter_widgets.py (line 235)
   ⚠️  Never called

🏗️ _set_origin
   📄 Editors\ImageEditor\core\ui\dialogs\origin_dialog.py (line 68)
   ⚠️  Never called

🏗️ get_origin
   📄 Editors\ImageEditor\core\ui\dialogs\origin_dialog.py (line 72)
   ⚠️  Never called

🏗️ is_feedback_request
   📄 Core\AI\PyGenesisAssistant\Nova\core\feedback_handler.py (line 47)
   ⚠️  Never called

🏗️ handle_feedback
   📄 Core\AI\PyGenesisAssistant\Nova\core\feedback_handler.py (line 65)
   ⚠️  Never called

🏗️ record_operation_context
   📄 Core\AI\PyGenesisAssistant\Nova\core\feedback_handler.py (line 132)
   ⚠️  Never called

🏗️ _log_misinformation
   📄 Core\AI\PyGenesisAssistant\Nova\core\feedback_handler.py (line 157)
   ⚠️  Never called

🏗️ get_feedback_handler
   📄 Core\AI\PyGenesisAssistant\Nova\core\feedback_handler.py (line 193)
   ⚠️  Never called

🏗️ _collect_definitions
   📄 Core\AI\PyGenesisAssistant\code_analysis.py (line 58)
   ⚠️  Never called

🏗️ _check_undefined_names
   📄 Core\AI\PyGenesisAssistant\code_analysis.py (line 73)
   ⚠️  Never called

🏗️ visit_FunctionDef
   📄 Core\AI\PyGenesisAssistant\code_analysis.py (line 117)
   ⚠️  Never called

🏗️ visit_ClassDef
   📄 Core\AI\PyGenesisAssistant\code_analysis.py (line 124)
   ⚠️  Never called

🏗️ visit_Call
   📄 Core\AI\PyGenesisAssistant\code_analysis.py (line 131)
   ⚠️  Never called

🏗️ get_size
   📄 Editors\ImageEditor\core\ui\dialogs\new_image_dialog.py (line 79)
   ⚠️  Never called

🏗️ increase_width
   📄 Editors\ImageEditor\core\ui\dialogs\new_image_dialog.py (line 88)
   ⚠️  Never called

🏗️ decrease_width
   📄 Editors\ImageEditor\core\ui\dialogs\new_image_dialog.py (line 96)
   ⚠️  Never called

🏗️ increase_height
   📄 Editors\ImageEditor\core\ui\dialogs\new_image_dialog.py (line 104)
   ⚠️  Never called

🏗️ decrease_height
   📄 Editors\ImageEditor\core\ui\dialogs\new_image_dialog.py (line 112)
   ⚠️  Never called

🏗️ set_preset_size
   📄 Editors\ImageEditor\core\ui\dialogs\new_image_dialog.py (line 120)
   ⚠️  Never called

🏗️ execute
   📄 Core\AI\PyGenesisAssistant\Nova\core\executors\project_modification_executor.py (line 11)
   📞 Called by:
      • Core\Code\Unified\unified_code_editor.py (line 882)
      • Core\Code\Unified\unified_code_editor.py (line 926)

🏗️ _execute_pgsl
   📄 Core\Code\Unified\execution_engine.py (line 113)
   ⚠️  Never called

🏗️ _execute_python
   📄 Core\Code\Unified\execution_engine.py (line 131)
   ⚠️  Never called

🏗️ _get_safe_builtins
   📄 Core\Code\Unified\execution_engine.py (line 224)
   ⚠️  Never called

🏗️ get_color_name
   📄 Editors\ImageEditor\core\ui\character_creator_dialog.py (line 55)
   📞 Called by:
      • Editors\ImageEditor\core\ui\character_creator_dialog.py (line 155)
      • Editors\ImageEditor\core\ui\character_creator_dialog.py (line 168)

🏗️ get_hex_from_name
   📄 Editors\ImageEditor\core\ui\character_creator_dialog.py (line 59)
   ⚠️  Never called

🏗️ update_color_button
   📄 Editors\ImageEditor\core\ui\character_creator_dialog.py (line 125)
   ⚠️  Never called

🏗️ update_color_list
   📄 Editors\ImageEditor\core\ui\character_creator_dialog.py (line 143)
   ⚠️  Never called

🏗️ determine_color_category
   📄 Editors\ImageEditor\core\ui\character_creator_dialog.py (line 175)
   ⚠️  Never called

🏗️ show_color_picker
   📄 Editors\ImageEditor\core\ui\character_creator_dialog.py (line 209)
   ⚠️  Never called

🏗️ on_color_selected
   📄 Editors\ImageEditor\core\ui\character_creator_dialog.py (line 219)
   ⚠️  Never called

🏗️ on_hex_changed
   📄 Editors\ImageEditor\core\ui\character_creator_dialog.py (line 228)
   ⚠️  Never called

🏗️ set_color_changed_callback
   📄 Editors\ImageEditor\core\ui\character_creator_dialog.py (line 281)
   ⚠️  Never called

🏗️ create_preview_panel
   📄 Editors\ImageEditor\core\ui\character_creator_dialog.py (line 369)
   ⚠️  Never called

🏗️ create_controls_panel
   📄 Editors\ImageEditor\core\ui\character_creator_dialog.py (line 455)
   ⚠️  Never called

🏗️ create_basic_info_group
   📄 Editors\ImageEditor\core\ui\character_creator_dialog.py (line 490)
   ⚠️  Never called

🏗️ create_appearance_group
   📄 Editors\ImageEditor\core\ui\character_creator_dialog.py (line 526)
   ⚠️  Never called

🏗️ create_hair_face_group
   📄 Editors\ImageEditor\core\ui\character_creator_dialog.py (line 552)
   ⚠️  Never called

🏗️ create_clothing_group
   📄 Editors\ImageEditor\core\ui\character_creator_dialog.py (line 586)
   ⚠️  Never called

🏗️ create_actions_panel
   📄 Editors\ImageEditor\core\ui\character_creator_dialog.py (line 650)
   ⚠️  Never called

🏗️ initialize_custom_dimensions
   📄 Editors\ImageEditor\core\ui\character_creator_dialog.py (line 698)
   ⚠️  Never called

🏗️ on_name_changed
   📄 Editors\ImageEditor\core\ui\character_creator_dialog.py (line 711)
   📞 Called by:
      • Editors\TextureEditor\TextureEditor.py (line 130)
      • Editors\SpriteEditor\SpriteEditor.py (line 286)

🏗️ on_gender_changed
   📄 Editors\ImageEditor\core\ui\character_creator_dialog.py (line 716)
   ⚠️  Never called

🏗️ on_height_changed
   📄 Editors\ImageEditor\core\ui\character_creator_dialog.py (line 721)
   ⚠️  Never called

🏗️ on_weight_changed
   📄 Editors\ImageEditor\core\ui\character_creator_dialog.py (line 726)
   ⚠️  Never called

🏗️ on_skin_color_changed
   📄 Editors\ImageEditor\core\ui\character_creator_dialog.py (line 731)
   ⚠️  Never called

🏗️ on_eye_color_changed
   📄 Editors\ImageEditor\core\ui\character_creator_dialog.py (line 736)
   ⚠️  Never called

🏗️ on_eye_style_changed
   📄 Editors\ImageEditor\core\ui\character_creator_dialog.py (line 741)
   ⚠️  Never called

🏗️ on_hair_color_changed
   📄 Editors\ImageEditor\core\ui\character_creator_dialog.py (line 746)
   ⚠️  Never called

🏗️ on_hair_style_changed
   📄 Editors\ImageEditor\core\ui\character_creator_dialog.py (line 751)
   ⚠️  Never called

🏗️ on_facial_hair_changed
   📄 Editors\ImageEditor\core\ui\character_creator_dialog.py (line 756)
   ⚠️  Never called

🏗️ on_facial_hair_color_changed
   📄 Editors\ImageEditor\core\ui\character_creator_dialog.py (line 761)
   ⚠️  Never called

🏗️ on_jacket_changed
   📄 Editors\ImageEditor\core\ui\character_creator_dialog.py (line 766)
   ⚠️  Never called

🏗️ on_shirt_changed
   📄 Editors\ImageEditor\core\ui\character_creator_dialog.py (line 771)
   ⚠️  Never called

🏗️ on_pants_changed
   📄 Editors\ImageEditor\core\ui\character_creator_dialog.py (line 776)
   ⚠️  Never called

🏗️ on_shoes_changed
   📄 Editors\ImageEditor\core\ui\character_creator_dialog.py (line 781)
   ⚠️  Never called

🏗️ on_hat_changed
   📄 Editors\ImageEditor\core\ui\character_creator_dialog.py (line 786)
   ⚠️  Never called

🏗️ on_shirt_color_changed
   📄 Editors\ImageEditor\core\ui\character_creator_dialog.py (line 791)
   ⚠️  Never called

🏗️ on_pants_color_changed
   📄 Editors\ImageEditor\core\ui\character_creator_dialog.py (line 796)
   ⚠️  Never called

🏗️ on_shoes_color_changed
   📄 Editors\ImageEditor\core\ui\character_creator_dialog.py (line 801)
   ⚠️  Never called

🏗️ set_view_angle
   📄 Editors\ImageEditor\core\ui\character_creator_dialog.py (line 806)
   ⚠️  Never called

🏗️ reset_view
   📄 Editors\ImageEditor\core\ui\character_creator_dialog.py (line 821)
   ⚠️  Never called

🏗️ on_mouse_press
   📄 Editors\ImageEditor\core\ui\character_creator_dialog.py (line 829)
   ⚠️  Never called

🏗️ on_mouse_move
   📄 Editors\ImageEditor\core\ui\character_creator_dialog.py (line 833)
   ⚠️  Never called

🏗️ on_wheel
   📄 Editors\ImageEditor\core\ui\character_creator_dialog.py (line 843)
   ⚠️  Never called

🏗️ randomize_character
   📄 Editors\ImageEditor\core\ui\character_creator_dialog.py (line 852)
   ⚠️  Never called

🏗️ update_ui_from_data
   📄 Editors\ImageEditor\core\ui\character_creator_dialog.py (line 879)
   ⚠️  Never called

🏗️ update_character_preview
   📄 Editors\ImageEditor\core\ui\character_creator_dialog.py (line 901)
   ⚠️  Never called

🏗️ _perform_update
   📄 Editors\ImageEditor\core\ui\character_creator_dialog.py (line 912)
   ⚠️  Never called

🏗️ generate_character_image
   📄 Editors\ImageEditor\core\ui\character_creator_dialog.py (line 949)
   ⚠️  Never called

🏗️ generate_mugshot_image
   📄 Editors\ImageEditor\core\ui\character_creator_dialog.py (line 1026)
   ⚠️  Never called

🏗️ draw_character_components_front
   📄 Editors\ImageEditor\core\ui\character_creator_dialog.py (line 1058)
   ⚠️  Never called

🏗️ draw_character_head_front
   📄 Editors\ImageEditor\core\ui\character_creator_dialog.py (line 1105)
   ⚠️  Never called

🏗️ draw_character_body_front
   📄 Editors\ImageEditor\core\ui\character_creator_dialog.py (line 1129)
   ⚠️  Never called

🏗️ draw_character_arms_front
   📄 Editors\ImageEditor\core\ui\character_creator_dialog.py (line 1148)
   ⚠️  Never called

🏗️ draw_character_hands_front
   📄 Editors\ImageEditor\core\ui\character_creator_dialog.py (line 1173)
   ⚠️  Never called

🏗️ draw_character_legs_front
   📄 Editors\ImageEditor\core\ui\character_creator_dialog.py (line 1197)
   ⚠️  Never called

🏗️ draw_character_feet_front
   📄 Editors\ImageEditor\core\ui\character_creator_dialog.py (line 1223)
   ⚠️  Never called

🏗️ draw_character_eyes_front
   📄 Editors\ImageEditor\core\ui\character_creator_dialog.py (line 1252)
   ⚠️  Never called

🏗️ draw_character_mouth_front
   📄 Editors\ImageEditor\core\ui\character_creator_dialog.py (line 1270)
   ⚠️  Never called

🏗️ draw_character_facial_hair_front
   📄 Editors\ImageEditor\core\ui\character_creator_dialog.py (line 1283)
   ⚠️  Never called

🏗️ draw_character_hair_front
   📄 Editors\ImageEditor\core\ui\character_creator_dialog.py (line 1299)
   ⚠️  Never called

🏗️ draw_character_hat_front
   📄 Editors\ImageEditor\core\ui\character_creator_dialog.py (line 1316)
   ⚠️  Never called

🏗️ draw_character_clothing_body_front
   📄 Editors\ImageEditor\core\ui\character_creator_dialog.py (line 1333)
   ⚠️  Never called

🏗️ draw_character_clothing_arms_front
   📄 Editors\ImageEditor\core\ui\character_creator_dialog.py (line 1350)
   ⚠️  Never called

🏗️ draw_character_clothing_legs_front
   📄 Editors\ImageEditor\core\ui\character_creator_dialog.py (line 1360)
   ⚠️  Never called

🏗️ draw_character_shoes_front
   📄 Editors\ImageEditor\core\ui\character_creator_dialog.py (line 1370)
   ⚠️  Never called

🏗️ draw_character_components_back
   📄 Editors\ImageEditor\core\ui\character_creator_dialog.py (line 1393)
   ⚠️  Never called

🏗️ draw_character_head_back
   📄 Editors\ImageEditor\core\ui\character_creator_dialog.py (line 1440)
   ⚠️  Never called

🏗️ draw_character_body_back
   📄 Editors\ImageEditor\core\ui\character_creator_dialog.py (line 1459)
   ⚠️  Never called

🏗️ draw_character_arms_back
   📄 Editors\ImageEditor\core\ui\character_creator_dialog.py (line 1478)
   ⚠️  Never called

🏗️ draw_character_hands_back
   📄 Editors\ImageEditor\core\ui\character_creator_dialog.py (line 1503)
   ⚠️  Never called

🏗️ draw_character_legs_back
   📄 Editors\ImageEditor\core\ui\character_creator_dialog.py (line 1527)
   ⚠️  Never called

🏗️ draw_character_feet_back
   📄 Editors\ImageEditor\core\ui\character_creator_dialog.py (line 1553)
   ⚠️  Never called

🏗️ draw_character_hair_back
   📄 Editors\ImageEditor\core\ui\character_creator_dialog.py (line 1581)
   ⚠️  Never called

🏗️ draw_character_hat_back
   📄 Editors\ImageEditor\core\ui\character_creator_dialog.py (line 1598)
   ⚠️  Never called

🏗️ draw_character_clothing_body_back
   📄 Editors\ImageEditor\core\ui\character_creator_dialog.py (line 1614)
   ⚠️  Never called

🏗️ draw_character_clothing_arms_back
   📄 Editors\ImageEditor\core\ui\character_creator_dialog.py (line 1631)
   ⚠️  Never called

🏗️ draw_character_clothing_legs_back
   📄 Editors\ImageEditor\core\ui\character_creator_dialog.py (line 1641)
   ⚠️  Never called

🏗️ draw_character_shoes_back
   📄 Editors\ImageEditor\core\ui\character_creator_dialog.py (line 1651)
   ⚠️  Never called

🏗️ draw_character_components_side
   📄 Editors\ImageEditor\core\ui\character_creator_dialog.py (line 1674)
   ⚠️  Never called

🏗️ draw_character_head_side
   📄 Editors\ImageEditor\core\ui\character_creator_dialog.py (line 1721)
   ⚠️  Never called

🏗️ draw_character_body_side
   📄 Editors\ImageEditor\core\ui\character_creator_dialog.py (line 1744)
   ⚠️  Never called

🏗️ draw_character_arms_side
   📄 Editors\ImageEditor\core\ui\character_creator_dialog.py (line 1763)
   ⚠️  Never called

🏗️ draw_character_hands_side
   📄 Editors\ImageEditor\core\ui\character_creator_dialog.py (line 1788)
   ⚠️  Never called

🏗️ draw_character_legs_side
   📄 Editors\ImageEditor\core\ui\character_creator_dialog.py (line 1812)
   ⚠️  Never called

🏗️ draw_character_feet_side
   📄 Editors\ImageEditor\core\ui\character_creator_dialog.py (line 1843)
   ⚠️  Never called

🏗️ draw_character_eyes_side
   📄 Editors\ImageEditor\core\ui\character_creator_dialog.py (line 1877)
   ⚠️  Never called

🏗️ draw_character_mouth_side
   📄 Editors\ImageEditor\core\ui\character_creator_dialog.py (line 1896)
   ⚠️  Never called

🏗️ draw_character_facial_hair_side
   📄 Editors\ImageEditor\core\ui\character_creator_dialog.py (line 1916)
   ⚠️  Never called

🏗️ draw_character_hair_side
   📄 Editors\ImageEditor\core\ui\character_creator_dialog.py (line 1932)
   ⚠️  Never called

🏗️ draw_character_ear_side
   📄 Editors\ImageEditor\core\ui\character_creator_dialog.py (line 2047)
   ⚠️  Never called

🏗️ draw_character_hat_side
   📄 Editors\ImageEditor\core\ui\character_creator_dialog.py (line 2066)
   ⚠️  Never called

🏗️ draw_character_clothing_body_side
   📄 Editors\ImageEditor\core\ui\character_creator_dialog.py (line 2083)
   ⚠️  Never called

🏗️ draw_character_clothing_arms_side
   📄 Editors\ImageEditor\core\ui\character_creator_dialog.py (line 2100)
   ⚠️  Never called

🏗️ draw_character_clothing_legs_side
   📄 Editors\ImageEditor\core\ui\character_creator_dialog.py (line 2109)
   ⚠️  Never called

🏗️ draw_character_shoes_side
   📄 Editors\ImageEditor\core\ui\character_creator_dialog.py (line 2119)
   ⚠️  Never called

🏗️ _get_character_hash
   📄 Editors\ImageEditor\core\ui\character_creator_dialog.py (line 2138)
   ⚠️  Never called

🏗️ _clear_cache
   📄 Editors\ImageEditor\core\ui\character_creator_dialog.py (line 2145)
   ⚠️  Never called

🏗️ adjust_color
   📄 Editors\ImageEditor\core\ui\character_creator_dialog.py (line 2149)
   ⚠️  Never called

🏗️ apply_to_canvas
   📄 Editors\ImageEditor\core\ui\character_creator_dialog.py (line 2167)
   ⚠️  Never called

🏗️ _extract_search_info
   📄 Core\AI\PyGenesisAssistant\Nova\core\executors\code_search_executor.py (line 96)
   ⚠️  Never called

🏗️ _search_code
   📄 Core\AI\PyGenesisAssistant\Nova\core\executors\code_search_executor.py (line 148)
   ⚠️  Never called

🏗️ _search_objects
   📄 Core\AI\PyGenesisAssistant\Nova\core\executors\code_search_executor.py (line 172)
   ⚠️  Never called

🏗️ _search_scripts
   📄 Core\AI\PyGenesisAssistant\Nova\core\executors\code_search_executor.py (line 236)
   ⚠️  Never called

🏗️ _search_shaders
   📄 Core\AI\PyGenesisAssistant\Nova\core\executors\code_search_executor.py (line 298)
   ⚠️  Never called

🏗️ _format_results
   📄 Core\AI\PyGenesisAssistant\Nova\core\executors\code_search_executor.py (line 369)
   ⚠️  Never called

🏗️ can_accept
   📄 Core\Code\Unified\acceptance_contract.py (line 63)
   ⚠️  Never called

🏗️ check_mode_compatibility
   📄 Core\Code\Unified\acceptance_contract.py (line 120)
   ⚠️  Never called

🏗️ suggest_mode
   📄 Core\Code\Unified\acceptance_contract.py (line 151)
   ⚠️  Never called

🏗️ validate_for_nova
   📄 Core\Code\Unified\acceptance_contract.py (line 189)
   ⚠️  Never called

🏗️ _build_command_patterns
   📄 Core\Code\PGSL\pgsl_parser.py (line 22)
   ⚠️  Never called

🏗️ parse_file
   📄 Core\Code\PGSL\pgsl_parser.py (line 263)
   ⚠️  Never called

🏗️ cut_item
   📄 Core\UtilityOperations.py (line 22)
   📞 Called by:
      • UI\Widgets\ResourceTree.py (line 1579)
      • UI\Widgets\ResourceTree.py (line 1792)

🏗️ copy_item
   📄 Core\UtilityOperations.py (line 28)
   📞 Called by:
      • UI\Widgets\ResourceTree.py (line 1570)
      • UI\Widgets\ResourceTree.py (line 1805)

🏗️ paste_item
   📄 Core\UtilityOperations.py (line 34)
   📞 Called by:
      • UI\Widgets\ResourceTree.py (line 1929)

🏗️ _paste_resource
   📄 Core\UtilityOperations.py (line 50)
   ⚠️  Never called

🏗️ _paste_folder
   📄 Core\UtilityOperations.py (line 117)
   ⚠️  Never called

🏗️ _get_unique_name
   📄 Core\UtilityOperations.py (line 161)
   ⚠️  Never called

🏗️ _get_unique_folder_name
   📄 Core\UtilityOperations.py (line 175)
   ⚠️  Never called

🏗️ clear_clipboard
   📄 Core\UtilityOperations.py (line 186)
   ⚠️  Never called

🏗️ has_data
   📄 Core\UtilityOperations.py (line 192)
   📞 Called by:
      • UI\Widgets\ResourceTree.py (line 1907)
      • UI\Widgets\ResourceTree.py (line 1911)

🏗️ set_managers
   📄 Core\UtilityOperations.py (line 210)
   📞 Called by:
      • main.py (line 534)

🏗️ record_create
   📄 Core\UtilityOperations.py (line 215)
   📞 Called by:
      • Core\ResourceManager.py (line 229)

🏗️ record_delete
   📄 Core\UtilityOperations.py (line 229)
   📞 Called by:
      • Core\ResourceManager.py (line 445)

🏗️ record_rename
   📄 Core\UtilityOperations.py (line 243)
   📞 Called by:
      • Core\ResourceManager.py (line 643)

🏗️ record_copy
   📄 Core\UtilityOperations.py (line 258)
   📞 Called by:
      • Core\UtilityOperations.py (line 98)

🏗️ _limit_history
   📄 Core\UtilityOperations.py (line 273)
   ⚠️  Never called

🏗️ _perform_undo
   📄 Core\UtilityOperations.py (line 316)
   ⚠️  Never called

🏗️ _perform_redo
   📄 Core\UtilityOperations.py (line 360)
   ⚠️  Never called

🏗️ can_undo
   📄 Core\UtilityOperations.py (line 404)
   📞 Called by:
      • Editors\ImageEditor\core\ui\timeline.py (line 1077)
      • UI\MainWindow\MainWindow.py (line 873)

🏗️ can_redo
   📄 Core\UtilityOperations.py (line 408)
   📞 Called by:
      • Editors\ImageEditor\core\ui\timeline.py (line 1086)
      • UI\MainWindow\MainWindow.py (line 885)

🏗️ safe_rename
   📄 Core\UtilityOperations.py (line 422)
   ⚠️  Never called

🏗️ safe_delete
   📄 Core\UtilityOperations.py (line 433)
   ⚠️  Never called

🏗️ safe_copy
   📄 Core\UtilityOperations.py (line 447)
   ⚠️  Never called

🏗️ _output
   📄 Core\Code\Shared\script_validator.py (line 114)
   ⚠️  Never called

🏗️ check_code_string
   📄 Core\Code\Shared\script_validator.py (line 119)
   📞 Called by:
      • Core\Code\Unified\validation_pipeline.py (line 262)

🏗️ _clean_code_string
   📄 Core\Code\Shared\script_validator.py (line 204)
   ⚠️  Never called

🏗️ _analyze_code
   📄 Core\Code\Shared\script_validator.py (line 301)
   ⚠️  Never called

🏗️ _execute_code
   📄 Core\Code\Shared\script_validator.py (line 412)
   ⚠️  Never called

🏗️ create_resource
   📄 Core\ResourceManager.py (line 159)
   📞 Called by:
      • Core\Services\resource_service.py (line 49)
      • Core\AI\PyGenesisAssistant\Nova\core\executors\resource_operation_executor.py (line 477)
      • UI\Widgets\ResourceTree.py (line 1035)
      • UI\Widgets\ResourceTree.py (line 1077)
      • UI\Widgets\ResourceTree.py (line 1204)
      • UI\Widgets\ResourceTree.py (line 1321)
      • UI\MainWindow\MainWindow.py (line 953)
      • UI\MainWindow\MainWindow.py (line 955)
      • Editors\ModelEditor\ModelEditor.py (line 772)
      • Editors\ModelEditor\ModelEditor.py (line 11344)

🏗️ load_resource
   📄 Core\ResourceManager.py (line 238)
   📞 Called by:
      • Core\Services\resource_service.py (line 138)
      • Core\AI\PyGenesisAssistant\Nova\core\executors\resource_operation_executor.py (line 451)
      • UI\Widgets\ResourceTree.py (line 1568)
      • UI\Widgets\ResourceTree.py (line 1577)
      • UI\MainWindow\MainWindow.py (line 666)

🏗️ load_resource_from_disk
   📄 Core\ResourceManager.py (line 278)
   📞 Called by:
      • Editors\BackgroundEditor\BackgroundEditor.py (line 149)
      • Editors\Shared\BaseImageResourceEditor.py (line 826)
      • Editors\TextureEditor\TextureEditor.py (line 170)
      • Editors\SoundEditor\SoundEditor.py (line 2466)
      • Editors\Shared\IntegratedImageEditor.py (line 650)
      • Editors\SpriteEditor\SpriteEditor.py (line 327)

🏗️ get_resource_file_path
   📄 Core\ResourceManager.py (line 304)
   📞 Called by:
      • Editors\Shared\BaseImageResourceEditor.py (line 61)
      • Editors\Shared\BaseImageResourceEditor.py (line 809)
      • Editors\TextureEditor\TextureEditor.py (line 42)
      • Editors\TextureEditor\TextureEditor.py (line 67)
      • UI\Widgets\ResourceTree.py (line 1509)
      • Editors\SpriteEditor\SpriteEditor.py (line 248)

🏗️ _convert_numpy_types
   📄 Core\ResourceManager.py (line 322)
   ⚠️  Never called

🏗️ update_resource
   📄 Core\ResourceManager.py (line 342)
   📞 Called by:
      • Core\Services\resource_service.py (line 83)
      • Core\AI\PyGenesisAssistant\Nova\core\executors\resource_operation_executor.py (line 428)
      • Core\AI\PyGenesisAssistant\Nova\core\executors\resource_operation_executor.py (line 489)
      • Core\AI\PyGenesisAssistant\Nova\core\executors\resource_operation_executor.py (line 510)
      • Core\AI\PyGenesisAssistant\Nova\core\executors\resource_operation_executor.py (line 718)

🏗️ save_resource_file_only
   📄 Core\ResourceManager.py (line 403)
   📞 Called by:
      • Editors\SoundEditor\SoundEditor.py (line 2625)
      • Editors\ModelEditor\ModelEditor.py (line 888)
      • Editors\ModelEditor\ModelEditor.py (line 10644)
      • Editors\ModelEditor\ModelEditor.py (line 10666)
      • Editors\ModelEditor\ModelEditor.py (line 12018)
      • Editors\ModelEditor\ModelEditor.py (line 12029)

🏗️ delete_resource
   📄 Core\ResourceManager.py (line 435)
   📞 Called by:
      • Core\UtilityOperations.py (line 323)
      • Core\UtilityOperations.py (line 348)
      • Core\UtilityOperations.py (line 375)
      • Core\Services\resource_service.py (line 111)
      • Core\AI\PyGenesisAssistant\Nova\core\executors\resource_operation_executor.py (line 400)
      • UI\Widgets\ResourceTree.py (line 1627)

🏗️ _update_object_children_on_parent_delete
   📄 Core\ResourceManager.py (line 487)
   ⚠️  Never called

🏗️ _delete_sprite_frame_files
   📄 Core\ResourceManager.py (line 517)
   ⚠️  Never called

🏗️ _delete_object_event_files
   📄 Core\ResourceManager.py (line 543)
   ⚠️  Never called

🏗️ _rename_object_event_files
   📄 Core\ResourceManager.py (line 572)
   ⚠️  Never called

🏗️ rename_resource
   📄 Core\ResourceManager.py (line 615)
   📞 Called by:
      • Core\UtilityOperations.py (line 339)
      • Core\UtilityOperations.py (line 383)
      • Core\AI\PyGenesisAssistant\Nova\core\executors\resource_operation_executor.py (line 380)
      • UI\Widgets\ResourceTree.py (line 1559)
      • UI\MainWindow\MainWindow.py (line 933)
      • Editors\ModelEditor\ModelEditor.py (line 8897)

🏗️ _copy_sprite_frame_files
   📄 Core\ResourceManager.py (line 761)
   ⚠️  Never called

🏗️ _copy_sound_audio_file_for_copy
   📄 Core\ResourceManager.py (line 836)
   ⚠️  Never called

🏗️ _delete_sound_audio_files
   📄 Core\ResourceManager.py (line 908)
   ⚠️  Never called

🏗️ _copy_sound_audio_file
   📄 Core\ResourceManager.py (line 944)
   📞 Called by:
      • Editors\SoundEditor\SoundEditor.py (line 2546)

🏗️ _copy_model_file
   📄 Core\ResourceManager.py (line 1020)
   📞 Called by:
      • Editors\ModelEditor\ModelEditor.py (line 11279)
      • Editors\ModelEditor\ModelEditor.py (line 11922)

🏗️ _import_textures_for_model
   📄 Core\ResourceManager.py (line 1254)
   ⚠️  Never called

🏗️ _update_mtl_texture_references_simple
   📄 Core\ResourceManager.py (line 1429)
   ⚠️  Never called

🏗️ _rename_sound_audio_file
   📄 Core\ResourceManager.py (line 1486)
   ⚠️  Never called

🏗️ _delete_model_files
   📄 Core\ResourceManager.py (line 1549)
   ⚠️  Never called

🏗️ _rename_model_file
   📄 Core\ResourceManager.py (line 1603)
   ⚠️  Never called

🏗️ move_resource
   📄 Core\ResourceManager.py (line 1667)
   📞 Called by:
      • UI\Widgets\ResourceTree.py (line 1977)

🏗️ get_cached_texture
   📄 Core\ResourceManager.py (line 1714)
   ⚠️  Never called

🏗️ cache_texture
   📄 Core\ResourceManager.py (line 1734)
   ⚠️  Never called

🏗️ release_texture
   📄 Core\ResourceManager.py (line 1758)
   ⚠️  Never called

🏗️ remove_texture_from_cache
   📄 Core\ResourceManager.py (line 1777)
   ⚠️  Never called

🏗️ get_cached_materials
   📄 Core\ResourceManager.py (line 1787)
   ⚠️  Never called

🏗️ cache_materials
   📄 Core\ResourceManager.py (line 1801)
   ⚠️  Never called

🏗️ remove_materials_from_cache
   📄 Core\ResourceManager.py (line 1811)
   ⚠️  Never called

🏗️ get_cached_model
   📄 Core\ResourceManager.py (line 1820)
   ⚠️  Never called

🏗️ cache_model
   📄 Core\ResourceManager.py (line 1843)
   ⚠️  Never called

🏗️ clear_cache
   📄 Core\ResourceManager.py (line 1866)
   ⚠️  Never called

🏗️ get_cache_stats
   📄 Core\ResourceManager.py (line 1879)
   ⚠️  Never called

🏗️ set_undo_redo_manager
   📄 Core\ResourceManager.py (line 1899)
   📞 Called by:
      • main.py (line 535)

🏗️ restore_resource
   📄 Core\ResourceManager.py (line 1903)
   📞 Called by:
      • Core\UtilityOperations.py (line 331)
      • Core\UtilityOperations.py (line 367)
      • Core\UtilityOperations.py (line 392)

🏗️ _get_timestamp
   📄 Core\ResourceManager.py (line 1941)
   ⚠️  Never called

🏗️ create_status_bar
   📄 Editors\ImageEditor\core\ui\components\status_bar.py (line 27)
   ⚠️  Never called

🏗️ _update_position_status
   📄 Editors\ImageEditor\core\ui\components\status_bar.py (line 51)
   📞 Called by:
      • Editors\ImageEditor\core\ui\main_window.py (line 1065)

🏗️ update_tool
   📄 Editors\ImageEditor\core\ui\components\status_bar.py (line 56)
   ⚠️  Never called

🏗️ update_size
   📄 Editors\ImageEditor\core\ui\components\status_bar.py (line 61)
   ⚠️  Never called

🏗️ update_zoom
   📄 Editors\ImageEditor\core\ui\components\status_bar.py (line 66)
   ⚠️  Never called

🏗️ _get_cache_key
   📄 Core\AI\PyGenesisAssistant\UnifiedCodeAnalyzer.py (line 45)
   ⚠️  Never called

🏗️ get
   📄 Core\AI\PyGenesisAssistant\UnifiedCodeAnalyzer.py (line 53)
   📞 Called by:
      • Core\AI\PyGenesisAssistant\Nova\core\engines\conversation_engine.py (line 149)
      • Core\AI\PyGenesisAssistant\Nova\core\engines\conversation_engine.py (line 178)
      • Core\AI\PyGenesisAssistant\Nova\core\engines\conversation_engine.py (line 217)
      • Core\AI\PyGenesisAssistant\Nova\core\engines\conversation_engine.py (line 218)
      • Core\AI\PyGenesisAssistant\CodeAnalyser.py (line 47)
      • Core\AI\PyGenesisAssistant\CodeAnalyser.py (line 301)
      • Core\AI\PyGenesisAssistant\CodeAnalyser.py (line 310)
      • Core\AI\PyGenesisAssistant\CodeAnalyser.py (line 314)
      • Core\AI\PyGenesisAssistant\CodeAnalyser.py (line 375)
      • Core\AI\PyGenesisAssistant\CodeAnalyser.py (line 379)
      • Core\AI\PyGenesisAssistant\CodeAnalyser.py (line 387)
      • Core\AI\PyGenesisAssistant\CodeAnalyser.py (line 388)
      • Core\AI\PyGenesisAssistant\CodeAnalyser.py (line 389)
      • Core\AI\PyGenesisAssistant\CodeAnalyser.py (line 390)
      • Core\AI\PyGenesisAssistant\CodeAnalyser.py (line 454)
      • Core\AI\PyGenesisAssistant\CodeAnalyser.py (line 480)
      • Core\AI\PyGenesisAssistant\CodeAnalyser.py (line 502)
      • Core\AI\PyGenesisAssistant\CodeAnalyser.py (line 823)
      • Core\AI\PyGenesisAssistant\CodeAnalyser.py (line 836)
      • Core\AI\PyGenesisAssistant\CodeAnalyser.py (line 880)
      • Core\AI\PyGenesisAssistant\CodeAnalyser.py (line 886)
      • Core\AI\PyGenesisAssistant\CodeAnalyser.py (line 892)
      • Core\AI\PyGenesisAssistant\CodeAnalyser.py (line 1099)
      • Core\AI\PyGenesisAssistant\CodeAnalyser.py (line 1117)
      • Core\AI\PyGenesisAssistant\CodeAnalyser.py (line 1192)
      • Core\AI\PyGenesisAssistant\CodeAnalyser.py (line 1198)
      • Core\AI\PyGenesisAssistant\CodeAnalyser.py (line 1222)
      • Core\AI\PyGenesisAssistant\CodeAnalyser.py (line 1225)
      • Core\AI\PyGenesisAssistant\CodeAnalyser.py (line 1226)
      • Core\AI\PyGenesisAssistant\Nova\core\project_scanner.py (line 64)
      • Core\AI\PyGenesisAssistant\Nova\core\project_scanner.py (line 84)
      • Core\AI\PyGenesisAssistant\Nova\core\project_scanner.py (line 134)
      • Core\AI\PyGenesisAssistant\Nova\core\project_scanner.py (line 188)
      • Core\Code\Unified\unified_code_editor.py (line 269)
      • Config\ThemeManager.py (line 20)
      • Config\ThemeManager.py (line 21)
      • Config\ThemeManager.py (line 225)
      • Config\ThemeManager.py (line 559)
      • Config\ThemeManager.py (line 576)
      • Config\ThemeManager.py (line 598)
      • Core\CodeSystem\lexer.py (line 322)
      • Editors\ImageEditor\core\ui\panels\right_panel.py (line 324)
      • Editors\ImageEditor\core\ui\panels\right_panel.py (line 499)
      • Editors\ImageEditor\core\ui\panels\right_panel.py (line 499)
      • Core\AI\PyGenesisAssistant\DependencyAnalyser.py (line 217)
      • Core\AI\PyGenesisAssistant\DependencyAnalyser.py (line 226)
      • Core\AI\PyGenesisAssistant\DependencyAnalyser.py (line 283)
      • Core\AI\PyGenesisAssistant\DependencyAnalyser.py (line 287)
      • Core\AI\PyGenesisAssistant\DependencyAnalyser.py (line 494)
      • Core\AI\PyGenesisAssistant\Nova\ui\header.py (line 199)
      • Editors\ImageEditor\core\ui\dialogs\preferences_dialog.py (line 172)
      • Editors\ImageEditor\core\ui\dialogs\preferences_dialog.py (line 570)
      • Editors\ImageEditor\core\ui\dialogs\preferences_dialog.py (line 572)
      • Editors\ImageEditor\core\ui\dialogs\preferences_dialog.py (line 577)
      • Editors\ImageEditor\core\ui\dialogs\preferences_dialog.py (line 577)
      • Editors\ImageEditor\core\ui\dialogs\preferences_dialog.py (line 579)
      • Core\AI\PyGenesisAssistant\Nova\ui\chat_view.py (line 40)
      • Core\Rendering\BufferManager.py (line 52)
      • Core\Rendering\BufferManager.py (line 59)
      • Core\Rendering\BufferManager.py (line 72)
      • Core\Rendering\BufferManager.py (line 97)
      • Core\Rendering\BufferManager.py (line 104)
      • Core\Rendering\BufferManager.py (line 117)
      • Core\Rendering\BufferManager.py (line 146)
      • Core\Rendering\BufferManager.py (line 195)
      • Core\Rendering\BufferManager.py (line 199)
      • Core\Rendering\BufferManager.py (line 203)
      • Editors\ImageEditor\core\ui\dialogs\parameter_widgets.py (line 28)
      • Editors\ImageEditor\core\ui\dialogs\parameter_widgets.py (line 47)
      • Editors\ImageEditor\core\ui\dialogs\parameter_widgets.py (line 52)
      • Editors\ImageEditor\core\ui\dialogs\parameter_widgets.py (line 74)
      • Editors\ImageEditor\core\ui\dialogs\parameter_widgets.py (line 79)
      • Editors\ImageEditor\core\ui\dialogs\parameter_widgets.py (line 99)
      • Editors\ImageEditor\core\ui\dialogs\parameter_widgets.py (line 105)
      • Editors\ImageEditor\core\ui\dialogs\parameter_widgets.py (line 129)
      • Editors\ImageEditor\core\ui\dialogs\parameter_widgets.py (line 134)
      • Editors\ImageEditor\core\ui\dialogs\parameter_widgets.py (line 154)
      • Editors\ImageEditor\core\ui\dialogs\parameter_widgets.py (line 155)
      • Editors\ImageEditor\core\ui\dialogs\parameter_widgets.py (line 173)
      • Editors\ImageEditor\core\ui\dialogs\parameter_widgets.py (line 177)
      • Editors\ImageEditor\core\ui\dialogs\parameter_widgets.py (line 195)
      • Editors\ImageEditor\core\ui\dialogs\parameter_widgets.py (line 201)
      • Core\AI\PyGenesisAssistant\Nova\core\workflow.py (line 117)
      • Core\AI\PyGenesisAssistant\Nova\core\workflow.py (line 482)
      • Core\AI\PyGenesisAssistant\Nova\core\transaction_manager.py (line 134)
      • Core\AI\PyGenesisAssistant\Nova\core\transaction_manager.py (line 216)
      • Core\AI\PyGenesisAssistant\Nova\core\transaction_manager.py (line 217)
      • Core\AI\PyGenesisAssistant\Nova\core\transaction_manager.py (line 240)
      • Core\AI\PyGenesisAssistant\Nova\core\transaction_manager.py (line 246)
      • Core\AI\PyGenesisAssistant\Nova\core\transaction_manager.py (line 247)
      • Core\AI\PyGenesisAssistant\Nova\core\transaction_manager.py (line 275)
      • Core\AI\PyGenesisAssistant\Nova\core\transaction_manager.py (line 411)
      • Core\AI\PyGenesisAssistant\Nova\core\transaction_manager.py (line 412)
      • Core\AI\PyGenesisAssistant\Nova\core\transaction_manager.py (line 435)
      • Core\AI\PyGenesisAssistant\Nova\core\transaction_manager.py (line 436)
      • Core\AI\PyGenesisAssistant\Nova\core\transaction_manager.py (line 453)
      • Core\AI\PyGenesisAssistant\Nova\core\transaction_manager.py (line 474)
      • Core\AI\PyGenesisAssistant\Nova\core\tasks.py (line 172)
      • Core\AI\PyGenesisAssistant\Nova\core\tasks.py (line 180)
      • Core\AI\PyGenesisAssistant\Nova\core\tasks.py (line 185)
      • Editors\ModelEditor\examples\GoodPerformanceButOnlyShowsModels.py (line 403)
      • Core\AI\PyGenesisAssistant\Nova\core\slm\tiny_intent_model.py (line 123)
      • Core\ExtensionsManager.py (line 490)
      • Core\ExtensionsManager.py (line 491)
      • Core\ExtensionsManager.py (line 492)
      • Core\ExtensionsManager.py (line 493)
      • Core\ExtensionsManager.py (line 494)
      • Core\ExtensionsManager.py (line 495)
      • Core\Debug.py (line 34)
      • Core\AI\PyGenesisAssistant\Nova\core\slm\custom_neural_model.py (line 315)
      • Core\AI\PyGenesisAssistant\Nova\core\slm\custom_neural_model.py (line 351)
      • Core\AI\PyGenesisAssistant\Nova\core\slm\custom_neural_model.py (line 432)
      • Core\AI\PyGenesisAssistant\Nova\core\slm\custom_neural_model.py (line 688)
      • Core\GameGenerator.py (line 466)
      • Editors\CodeEditor\pgsl_runtime.py (line 30)
      • Editors\BackgroundEditor\BackgroundEditor.py (line 37)
      • Editors\BackgroundEditor\BackgroundEditor.py (line 48)
      • Editors\BackgroundEditor\BackgroundEditor.py (line 75)
      • Editors\BackgroundEditor\BackgroundEditor.py (line 146)
      • Editors\BackgroundEditor\BackgroundEditor.py (line 155)
      • Editors\BackgroundEditor\BackgroundEditor.py (line 260)
      • Editors\BackgroundEditor\BackgroundEditor.py (line 273)
      • Editors\BackgroundEditor\BackgroundEditor.py (line 274)
      • Editors\BackgroundEditor\BackgroundEditor.py (line 276)
      • Editors\BackgroundEditor\BackgroundEditor.py (line 277)
      • Editors\BackgroundEditor\BackgroundEditor.py (line 278)
      • Editors\BackgroundEditor\BackgroundEditor.py (line 280)
      • Editors\BackgroundEditor\BackgroundEditor.py (line 281)
      • Editors\BackgroundEditor\BackgroundEditor.py (line 286)
      • Editors\BackgroundEditor\BackgroundEditor.py (line 358)
      • Editors\BackgroundEditor\BackgroundEditor.py (line 360)
      • Editors\BackgroundEditor\BackgroundEditor.py (line 442)
      • Core\ProjectManager.py (line 199)
      • Core\ProjectManager.py (line 405)
      • Core\ProjectManager.py (line 450)
      • Core\ProjectManager.py (line 504)
      • Core\ProjectManager.py (line 651)
      • Core\ProjectManager.py (line 710)
      • Core\ProjectManager.py (line 735)
      • Core\ProjectManager.py (line 794)
      • Core\ProjectManager.py (line 845)
      • Core\ProjectManager.py (line 1050)
      • Core\ProjectManager.py (line 1168)
      • Core\ProjectManager.py (line 1172)
      • Core\ProjectManager.py (line 1172)
      • Core\ProjectManager.py (line 1192)
      • Core\ProjectManager.py (line 1421)
      • Core\ProjectManager.py (line 1421)
      • Core\ProjectManager.py (line 1469)
      • Core\Rendering\ShaderManager.py (line 50)
      • Core\Rendering\ShaderManager.py (line 113)
      • Core\Rendering\OpenGLRuntime.py (line 168)
      • Core\Rendering\OpenGLRuntime.py (line 181)
      • Core\Rendering\OpenGLRuntime.py (line 209)
      • Core\Rendering\OpenGLRuntime.py (line 221)
      • Core\AI\PyGenesisAssistant\Nova\core\conversations.py (line 314)
      • Editors\ImageEditor\core\core\pgsprite_io.py (line 51)
      • Editors\ImageEditor\core\layers\layer.py (line 68)
      • Core\Services\async_project_loader.py (line 46)
      • Core\Services\async_project_loader.py (line 47)
      • Core\Services\async_project_loader.py (line 48)
      • Core\Services\async_project_loader.py (line 88)
      • Core\Services\async_editor_loader.py (line 37)
      • Editors\ImageEditor\core\core\venv_fix_tool.py (line 99)
      • Editors\ImageEditor\core\core\venv_fix_tool.py (line 100)
      • Editors\ImageEditor\core\core\venv_fix_tool.py (line 105)
      • Editors\ImageEditor\core\core\venv_fix_tool.py (line 106)
      • Editors\ImageEditor\core\core\background_processor.py (line 43)
      • Core\Rendering\TextureManager.py (line 97)
      • Core\Rendering\TextureManager.py (line 158)
      • Core\Rendering\TextureManager.py (line 181)
      • Core\Rendering\TextureManager.py (line 185)
      • Editors\ImageEditor\core\core\ai_requirements.py (line 54)
      • Editors\ImageEditor\core\core\ai_requirements.py (line 89)
      • Editors\ImageEditor\core\core\ai_requirements.py (line 182)
      • Editors\ImageEditor\core\core\ai_requirements.py (line 188)
      • Editors\ImageEditor\core\ui\character_creator_dialog.py (line 152)
      • Editors\ImageEditor\core\ui\character_creator_dialog.py (line 260)
      • Core\AI\PyGenesisAssistant\Nova\core\executors\code_search_executor.py (line 220)
      • Core\UtilityOperations.py (line 61)
      • Core\ResourceManager.py (line 1834)
      • Core\AI\PyGenesisAssistant\UnifiedCodeAnalyzer.py (line 259)
      • Core\AI\PyGenesisAssistant\UnifiedCodeAnalyzer.py (line 420)
      • Core\AI\PyGenesisAssistant\UnifiedCodeAnalyzer.py (line 421)
      • Core\AI\PyGenesisAssistant\UnifiedCodeAnalyzer.py (line 673)
      • Core\AI\PyGenesisAssistant\UnifiedCodeAnalyzer.py (line 683)
      • Core\AI\PyGenesisAssistant\UnifiedCodeAnalyzer.py (line 752)
      • Core\AI\PyGenesisAssistant\UnifiedCodeAnalyzer.py (line 857)
      • Core\AI\PyGenesisAssistant\UnifiedCodeAnalyzer.py (line 888)
      • Core\AI\PyGenesisAssistant\UnifiedCodeAnalyzer.py (line 924)
      • Core\AI\PyGenesisAssistant\UnifiedCodeAnalyzer.py (line 1045)
      • Core\AI\PyGenesisAssistant\UnifiedCodeAnalyzer.py (line 1052)
      • Core\AI\PyGenesisAssistant\UnifiedCodeAnalyzer.py (line 1108)
      • Core\AI\PyGenesisAssistant\Nova\core\executors\code_query_executor.py (line 20)
      • Core\AI\PyGenesisAssistant\Nova\core\executors\code_query_executor.py (line 21)
      • Core\Code\PGSL\pgsl_runtime.py (line 129)
      • Core\AI\PyGenesisAssistant\Nova\core\engines\research_engine.py (line 291)
      • Core\AI\PyGenesisAssistant\Nova\core\engines\research_engine.py (line 400)
      • Core\AI\PyGenesisAssistant\Nova\core\engines\research_engine.py (line 1394)
      • Core\Services\incremental_resource_reloader.py (line 53)
      • Core\Services\incremental_resource_reloader.py (line 106)
      • Core\Services\incremental_resource_reloader.py (line 106)
      • Editors\ImageEditor\core\ui\ai_dialogs.py (line 383)
      • Core\AI\PyGenesisAssistant\Nova\core\context_analyzer.py (line 232)
      • Core\AI\PyGenesisAssistant\NovaWidget.py (line 297)
      • Core\AI\PyGenesisAssistant\Nova\core\intent_router.py (line 594)
      • Core\AI\PyGenesisAssistant\Nova\core\executors\resource_operation_executor.py (line 206)
      • Core\AI\PyGenesisAssistant\Nova\core\operation_planner.py (line 170)
      • Editors\ObjectEditor\object_editor.py (line 141)
      • Editors\ObjectEditor\object_editor.py (line 142)
      • Editors\ObjectEditor\object_editor.py (line 143)
      • Editors\ObjectEditor\object_editor.py (line 144)
      • Editors\ObjectEditor\object_editor.py (line 145)
      • Editors\ObjectEditor\object_editor.py (line 146)
      • Editors\ObjectEditor\object_editor.py (line 179)
      • Editors\ObjectEditor\object_editor.py (line 260)
      • Editors\ObjectEditor\object_editor.py (line 260)
      • Editors\ObjectEditor\object_editor.py (line 315)
      • Editors\ObjectEditor\object_editor.py (line 329)
      • Editors\ObjectEditor\object_editor.py (line 364)
      • Editors\ObjectEditor\object_editor.py (line 378)
      • Editors\ObjectEditor\object_editor.py (line 385)
      • Editors\ObjectEditor\object_editor.py (line 453)
      • Editors\ObjectEditor\object_editor.py (line 585)
      • Editors\ObjectEditor\object_editor.py (line 609)
      • Editors\ObjectEditor\object_editor.py (line 847)
      • Editors\ObjectEditor\object_editor.py (line 885)
      • Editors\ObjectEditor\object_editor.py (line 920)
      • Editors\ObjectEditor\object_editor.py (line 953)
      • Editors\ObjectEditor\object_editor.py (line 1096)
      • Editors\ObjectEditor\object_editor.py (line 1130)
      • Editors\ObjectEditor\UI\events_panel.py (line 311)
      • Editors\RoomEditor\RoomEditor.py (line 56)
      • Editors\RoomEditor\RoomEditor.py (line 738)
      • Editors\RoomEditor\RoomEditor.py (line 749)
      • Editors\RoomEditor\RoomEditor.py (line 764)
      • Editors\RoomEditor\RoomEditor.py (line 825)
      • Editors\RoomEditor\RoomEditor.py (line 852)
      • Editors\RoomEditor\RoomEditor.py (line 869)
      • Editors\RoomEditor\RoomEditor.py (line 891)
      • Editors\RoomEditor\RoomEditor.py (line 930)
      • Editors\RoomEditor\RoomEditor.py (line 1042)
      • Editors\RoomEditor\RoomEditor.py (line 1221)
      • Editors\RoomEditor\RoomEditor.py (line 1224)
      • Editors\RoomEditor\RoomEditor.py (line 1306)
      • Editors\RoomEditor\RoomEditor.py (line 1313)
      • Editors\RoomEditor\RoomEditor.py (line 1319)
      • Editors\RoomEditor\RoomEditor.py (line 1386)
      • Editors\RoomEditor\RoomEditor.py (line 1511)
      • Editors\RoomEditor\RoomEditor.py (line 1528)
      • Editors\RoomEditor\RoomEditor.py (line 1560)
      • Editors\RoomEditor\RoomEditor.py (line 1594)
      • Editors\ImageEditor\core\ui\sprite_sheet_importer.py (line 111)
      • Editors\ImageEditor\core\ui\sprite_sheet_importer.py (line 112)
      • Editors\ImageEditor\core\ui\sprite_sheet_importer.py (line 113)
      • Editors\ImageEditor\core\ui\sprite_sheet_importer.py (line 114)
      • Editors\ImageEditor\core\ui\sprite_sheet_importer.py (line 128)
      • Editors\RoomEditor\ui\main_window.py (line 51)
      • Editors\RoomEditor\ui\main_window.py (line 721)
      • Editors\RoomEditor\ui\main_window.py (line 732)
      • Editors\RoomEditor\ui\main_window.py (line 747)
      • Editors\RoomEditor\ui\main_window.py (line 808)
      • Editors\RoomEditor\ui\main_window.py (line 835)
      • Editors\RoomEditor\ui\main_window.py (line 852)
      • Editors\RoomEditor\ui\main_window.py (line 874)
      • Editors\RoomEditor\ui\main_window.py (line 913)
      • Editors\RoomEditor\ui\main_window.py (line 1025)
      • Editors\RoomEditor\ui\main_window.py (line 1204)
      • Editors\RoomEditor\ui\main_window.py (line 1207)
      • Editors\ImageEditor\core\ui\panels\left_panel.py (line 918)
      • Editors\Shared\BaseImageResourceEditor.py (line 251)
      • Editors\Shared\BaseImageResourceEditor.py (line 257)
      • Editors\Shared\BaseImageResourceEditor.py (line 444)
      • Editors\Shared\BaseImageResourceEditor.py (line 515)
      • Editors\Shared\BaseImageResourceEditor.py (line 516)
      • Editors\Shared\BaseImageResourceEditor.py (line 621)
      • Editors\Shared\BaseImageResourceEditor.py (line 726)
      • Editors\Shared\BaseImageResourceEditor.py (line 771)
      • Editors\Shared\BaseImageResourceEditor.py (line 824)
      • Editors\Shared\BaseImageResourceEditor.py (line 831)
      • Editors\Shared\BaseImageResourceEditor.py (line 834)
      • Editors\Shared\BaseImageResourceEditor.py (line 835)
      • Editors\Shared\BaseImageResourceEditor.py (line 840)
      • Editors\Shared\BaseImageResourceEditor.py (line 852)
      • Editors\Shared\BaseImageResourceEditor.py (line 855)
      • Editors\Shared\BaseImageResourceEditor.py (line 859)
      • Editors\Shared\BaseImageResourceEditor.py (line 860)
      • Editors\Shared\BaseImageResourceEditor.py (line 863)
      • Editors\Shared\BaseImageResourceEditor.py (line 864)
      • Editors\Shared\BaseImageResourceEditor.py (line 888)
      • Editors\Shared\BaseImageResourceEditor.py (line 889)
      • Editors\Shared\BaseImageResourceEditor.py (line 893)
      • Editors\Shared\BaseImageResourceEditor.py (line 894)
      • Editors\Shared\BaseImageResourceEditor.py (line 898)
      • Editors\Shared\BaseImageResourceEditor.py (line 899)
      • Editors\Shared\BaseImageResourceEditor.py (line 900)
      • Editors\Shared\BaseImageResourceEditor.py (line 902)
      • Editors\Shared\BaseImageResourceEditor.py (line 925)
      • Editors\Shared\BaseImageResourceEditor.py (line 929)
      • Editors\Shared\BaseImageResourceEditor.py (line 948)
      • Editors\Shared\BaseImageResourceEditor.py (line 954)
      • Editors\TextureEditor\TextureEditor.py (line 96)
      • Editors\TextureEditor\TextureEditor.py (line 98)
      • Editors\TextureEditor\TextureEditor.py (line 168)
      • Editors\TextureEditor\TextureEditor.py (line 175)
      • Editors\TextureEditor\TextureEditor.py (line 328)
      • Editors\TextureEditor\TextureEditor.py (line 412)
      • Editors\TextureEditor\TextureEditor.py (line 423)
      • Editors\TextureEditor\TextureEditor.py (line 425)
      • Editors\TextureEditor\TextureEditor.py (line 426)
      • Editors\TextureEditor\TextureEditor.py (line 427)
      • Editors\TextureEditor\TextureEditor.py (line 428)
      • Editors\TextureEditor\TextureEditor.py (line 429)
      • Editors\TextureEditor\TextureEditor.py (line 440)
      • Editors\TextureEditor\TextureEditor.py (line 475)
      • Editors\TextureEditor\TextureEditor.py (line 478)
      • Editors\TextureEditor\TextureEditor.py (line 488)
      • Editors\TextureEditor\TextureEditor.py (line 515)
      • Editors\TextureEditor\TextureEditor.py (line 615)
      • Editors\TextureEditor\TextureEditor.py (line 639)
      • Editors\TextureEditor\TextureEditor.py (line 648)
      • Editors\TextureEditor\TextureEditor.py (line 661)
      • Editors\TextureEditor\TextureEditor.py (line 691)
      • Editors\TextureEditor\TextureEditor.py (line 722)
      • Editors\TextureEditor\TextureEditor.py (line 779)
      • Editors\TextureEditor\TextureEditor.py (line 784)
      • Editors\TextureEditor\TextureEditor.py (line 785)
      • Editors\TextureEditor\TextureEditor.py (line 853)
      • Editors\TextureEditor\TextureEditor.py (line 854)
      • Editors\TextureEditor\TextureEditor.py (line 872)
      • Editors\TextureEditor\TextureEditor.py (line 873)
      • Editors\TextureEditor\TextureEditor.py (line 913)
      • Editors\TextureEditor\TextureEditor.py (line 914)
      • Editors\TextureEditor\TextureEditor.py (line 1137)
      • Editors\TextureEditor\TextureEditor.py (line 1138)
      • Editors\TextureEditor\TextureEditor.py (line 1141)
      • Editors\TextureEditor\TextureEditor.py (line 1152)
      • Editors\TextureEditor\TextureEditor.py (line 1153)
      • Editors\TextureEditor\TextureEditor.py (line 1154)
      • Editors\TextureEditor\TextureEditor.py (line 1155)
      • Editors\TextureEditor\TextureEditor.py (line 1157)
      • Editors\TextureEditor\TextureEditor.py (line 1162)
      • Editors\TextureEditor\TextureEditor.py (line 1163)
      • UI\CommonDialogs\ExtensionsDialog.py (line 441)
      • Editors\SoundEditor\SoundEditor.py (line 1506)
      • Editors\SoundEditor\SoundEditor.py (line 1770)
      • Editors\SoundEditor\SoundEditor.py (line 2464)
      • Editors\SoundEditor\SoundEditor.py (line 2475)
      • Editors\SoundEditor\SoundEditor.py (line 2479)
      • Editors\SoundEditor\SoundEditor.py (line 2483)
      • Editors\SoundEditor\SoundEditor.py (line 2484)
      • Editors\SoundEditor\SoundEditor.py (line 2485)
      • Editors\SoundEditor\SoundEditor.py (line 2488)
      • Editors\SoundEditor\SoundEditor.py (line 2506)
      • Editors\SoundEditor\SoundEditor.py (line 2554)
      • Editors\SoundEditor\SoundEditor.py (line 2560)
      • Editors\SoundEditor\SoundEditor.py (line 2672)
      • Editors\SoundEditor\SoundEditor.py (line 2710)
      • Editors\SoundEditor\SoundEditor.py (line 2714)
      • Editors\SoundEditor\SoundEditor.py (line 2778)
      • Editors\SoundEditor\SoundEditor.py (line 2788)
      • UI\Widgets\TerminalWidget.py (line 98)
      • UI\Widgets\TerminalWidget.py (line 99)
      • UI\Widgets\ResourceTree.py (line 111)
      • UI\Widgets\ResourceTree.py (line 116)
      • UI\Widgets\ResourceTree.py (line 161)
      • UI\Widgets\ResourceTree.py (line 430)
      • UI\Widgets\ResourceTree.py (line 809)
      • UI\Widgets\ResourceTree.py (line 846)
      • UI\Widgets\ResourceTree.py (line 881)
      • UI\Widgets\ResourceTree.py (line 2043)
      • UI\CommonDialogs\PreferencesDialog.py (line 919)
      • UI\CommonDialogs\PreferencesDialog.py (line 921)
      • UI\CommonDialogs\PreferencesDialog.py (line 923)
      • UI\CommonDialogs\PreferencesDialog.py (line 1466)
      • UI\CommonDialogs\PreferencesDialog.py (line 1479)
      • UI\CommonDialogs\PreferencesDialog.py (line 1677)
      • UI\CommonDialogs\PreferencesDialog.py (line 1714)
      • UI\CommonDialogs\PreferencesDialog.py (line 1723)
      • UI\CommonDialogs\PreferencesDialog.py (line 1877)
      • UI\CommonDialogs\PreferencesDialog.py (line 1891)
      • UI\CommonDialogs\PreferencesDialog.py (line 1963)
      • UI\CommonDialogs\PreferencesDialog.py (line 1987)
      • UI\CommonDialogs\PreferencesDialog.py (line 2076)
      • UI\CommonDialogs\PreferencesDialog.py (line 2085)
      • UI\CommonDialogs\PreferencesDialog.py (line 2094)
      • UI\CommonDialogs\PreferencesDialog.py (line 2095)
      • UI\CommonDialogs\PreferencesDialog.py (line 2100)
      • UI\CommonDialogs\PreferencesDialog.py (line 2146)
      • UI\CommonDialogs\PreferencesDialog.py (line 2151)
      • UI\CommonDialogs\PreferencesDialog.py (line 2194)
      • UI\CommonDialogs\PreferencesDialog.py (line 2202)
      • UI\CommonDialogs\PreferencesDialog.py (line 2245)
      • UI\CommonDialogs\PreferencesDialog.py (line 2246)
      • UI\CommonDialogs\PreferencesDialog.py (line 2247)
      • UI\CommonDialogs\PreferencesDialog.py (line 2270)
      • UI\CommonDialogs\PreferencesDialog.py (line 2278)
      • UI\CommonDialogs\PreferencesDialog.py (line 2287)
      • UI\CommonDialogs\PreferencesDialog.py (line 2293)
      • UI\CommonDialogs\PreferencesDialog.py (line 2295)
      • UI\CommonDialogs\PreferencesDialog.py (line 2299)
      • UI\CommonDialogs\PreferencesDialog.py (line 2306)
      • UI\CommonDialogs\PreferencesDialog.py (line 2308)
      • UI\CommonDialogs\PreferencesDialog.py (line 2325)
      • UI\CommonDialogs\PreferencesDialog.py (line 2330)
      • UI\CommonDialogs\PreferencesDialog.py (line 2331)
      • UI\CommonDialogs\PreferencesDialog.py (line 2336)
      • UI\CommonDialogs\PreferencesDialog.py (line 2338)
      • UI\CommonDialogs\PreferencesDialog.py (line 2355)
      • UI\CommonDialogs\PreferencesDialog.py (line 2360)
      • UI\CommonDialogs\PreferencesDialog.py (line 2361)
      • UI\CommonDialogs\PreferencesDialog.py (line 2368)
      • UI\CommonDialogs\PreferencesDialog.py (line 2410)
      • UI\CommonDialogs\PreferencesDialog.py (line 2411)
      • UI\CommonDialogs\PreferencesDialog.py (line 2414)
      • UI\CommonDialogs\PreferencesDialog.py (line 2419)
      • UI\CommonDialogs\PreferencesDialog.py (line 2421)
      • UI\CommonDialogs\PreferencesDialog.py (line 2423)
      • UI\CommonDialogs\PreferencesDialog.py (line 2427)
      • UI\CommonDialogs\PreferencesDialog.py (line 2718)
      • UI\CommonDialogs\PreferencesDialog.py (line 2719)
      • Editors\ImageEditor\core\ui\preview.py (line 2199)
      • Editors\ImageEditor\core\ui\preview.py (line 2619)
      • Editors\ImageEditor\core\ui\preview.py (line 2619)
      • Editors\ImageEditor\core\ui\preview.py (line 2699)
      • Editors\ImageEditor\core\ui\preview.py (line 2879)
      • Editors\ImageEditor\core\ui\preview.py (line 2879)
      • Editors\ImageEditor\core\ui\preview.py (line 2976)
      • Editors\ImageEditor\core\ui\preview.py (line 2976)
      • Editors\ImageEditor\core\ui\preview.py (line 3112)
      • Editors\ImageEditor\core\ui\preview.py (line 3120)
      • Editors\ImageEditor\core\ui\preview.py (line 3151)
      • Editors\ImageEditor\core\ui\preview.py (line 3157)
      • Editors\Shared\IntegratedImageEditor.py (line 547)
      • Editors\Shared\IntegratedImageEditor.py (line 548)
      • Editors\Shared\IntegratedImageEditor.py (line 647)
      • Editors\Shared\IntegratedImageEditor.py (line 664)
      • Editors\Shared\IntegratedImageEditor.py (line 679)
      • Editors\Shared\IntegratedImageEditor.py (line 735)
      • Editors\Shared\IntegratedImageEditor.py (line 747)
      • Editors\Shared\IntegratedImageEditor.py (line 878)
      • Editors\Shared\IntegratedImageEditor.py (line 890)
      • Editors\Shared\IntegratedImageEditor.py (line 891)
      • Editors\Shared\IntegratedImageEditor.py (line 893)
      • Editors\Shared\IntegratedImageEditor.py (line 894)
      • Editors\Shared\IntegratedImageEditor.py (line 895)
      • Editors\Shared\IntegratedImageEditor.py (line 896)
      • Editors\Shared\IntegratedImageEditor.py (line 897)
      • Editors\Shared\IntegratedImageEditor.py (line 899)
      • Editors\Shared\IntegratedImageEditor.py (line 900)
      • Editors\Shared\IntegratedImageEditor.py (line 901)
      • Editors\Shared\IntegratedImageEditor.py (line 902)
      • Editors\Shared\IntegratedImageEditor.py (line 903)
      • Editors\Shared\IntegratedImageEditor.py (line 904)
      • Editors\Shared\IntegratedImageEditor.py (line 905)
      • Editors\Shared\IntegratedImageEditor.py (line 906)
      • Editors\Shared\IntegratedImageEditor.py (line 991)
      • Editors\Shared\IntegratedImageEditor.py (line 1017)
      • Editors\Shared\IntegratedImageEditor.py (line 1129)
      • Editors\SoundEditor\core\WaveForge.py (line 763)
      • Editors\ImageEditor\core\ui\main_window.py (line 86)
      • Editors\ImageEditor\core\ui\main_window.py (line 2215)
      • Editors\ImageEditor\core\ui\main_window.py (line 2216)
      • Editors\ImageEditor\core\ui\main_window.py (line 2223)
      • Editors\ImageEditor\core\ui\main_window.py (line 2224)
      • Editors\ImageEditor\core\ui\main_window.py (line 5192)
      • Editors\ImageEditor\core\ui\main_window.py (line 5424)
      • Editors\ImageEditor\core\ui\main_window.py (line 5503)
      • Editors\ImageEditor\core\ui\main_window.py (line 5536)
      • Editors\ImageEditor\core\ui\main_window.py (line 5569)
      • Editors\ImageEditor\core\ui\main_window.py (line 5596)
      • Editors\ImageEditor\core\ui\main_window.py (line 5623)
      • UI\MainWindow\MainWindow.py (line 578)
      • UI\MainWindow\MainWindow.py (line 582)
      • UI\MainWindow\MainWindow.py (line 599)
      • UI\MainWindow\MainWindow.py (line 618)
      • UI\MainWindow\MainWindow.py (line 1218)
      • UI\MainWindow\MainWindow.py (line 1315)
      • UI\MainWindow\MainWindow.py (line 1424)
      • UI\MainWindow\MainWindow.py (line 1548)
      • UI\MainWindow\MainWindow.py (line 1740)
      • UI\MainWindow\MainWindow.py (line 1762)
      • Editors\SpriteEditor\SpriteEditor.py (line 55)
      • Editors\SpriteEditor\SpriteEditor.py (line 66)
      • Editors\SpriteEditor\SpriteEditor.py (line 93)
      • Editors\SpriteEditor\SpriteEditor.py (line 214)
      • Editors\SpriteEditor\SpriteEditor.py (line 280)
      • Editors\SpriteEditor\SpriteEditor.py (line 324)
      • Editors\SpriteEditor\SpriteEditor.py (line 336)
      • Editors\SpriteEditor\SpriteEditor.py (line 535)
      • Editors\SpriteEditor\SpriteEditor.py (line 546)
      • Editors\SpriteEditor\SpriteEditor.py (line 548)
      • Editors\SpriteEditor\SpriteEditor.py (line 549)
      • Editors\SpriteEditor\SpriteEditor.py (line 550)
      • Editors\SpriteEditor\SpriteEditor.py (line 551)
      • Editors\SpriteEditor\SpriteEditor.py (line 552)
      • Editors\SpriteEditor\SpriteEditor.py (line 556)
      • Editors\SpriteEditor\SpriteEditor.py (line 557)
      • Editors\SpriteEditor\SpriteEditor.py (line 558)
      • Editors\SpriteEditor\SpriteEditor.py (line 559)
      • Editors\SpriteEditor\SpriteEditor.py (line 560)
      • Editors\SpriteEditor\SpriteEditor.py (line 570)
      • Editors\SpriteEditor\SpriteEditor.py (line 602)
      • Editors\SpriteEditor\SpriteEditor.py (line 605)
      • Editors\SpriteEditor\SpriteEditor.py (line 615)
      • Editors\SpriteEditor\SpriteEditor.py (line 642)
      • Editors\SpriteEditor\SpriteEditor.py (line 695)
      • Editors\SpriteEditor\SpriteEditor.py (line 709)
      • Editors\SpriteEditor\SpriteEditor.py (line 758)
      • Editors\SpriteEditor\SpriteEditor.py (line 759)
      • Editors\SpriteEditor\SpriteEditor.py (line 765)
      • Editors\SpriteEditor\SpriteEditor.py (line 766)
      • Editors\SpriteEditor\SpriteEditor.py (line 838)
      • Editors\SpriteEditor\SpriteEditor.py (line 841)
      • Editors\SpriteEditor\SpriteEditor.py (line 865)
      • Editors\SpriteEditor\SpriteEditor.py (line 874)
      • Editors\SpriteEditor\SpriteEditor.py (line 887)
      • Editors\SpriteEditor\SpriteEditor.py (line 916)
      • Editors\SpriteEditor\SpriteEditor.py (line 921)
      • Editors\SpriteEditor\SpriteEditor.py (line 962)
      • Editors\SpriteEditor\SpriteEditor.py (line 1019)
      • Editors\SpriteEditor\SpriteEditor.py (line 1024)
      • Editors\SpriteEditor\SpriteEditor.py (line 1025)
      • Editors\SpriteEditor\SpriteEditor.py (line 1093)
      • Editors\SpriteEditor\SpriteEditor.py (line 1094)
      • Editors\SpriteEditor\SpriteEditor.py (line 1112)
      • Editors\SpriteEditor\SpriteEditor.py (line 1113)
      • Editors\SpriteEditor\SpriteEditor.py (line 1153)
      • Editors\SpriteEditor\SpriteEditor.py (line 1154)
      • Editors\SpriteEditor\SpriteEditor.py (line 1377)
      • Editors\SpriteEditor\SpriteEditor.py (line 1378)
      • Editors\SpriteEditor\SpriteEditor.py (line 1381)
      • Editors\SpriteEditor\SpriteEditor.py (line 1392)
      • Editors\SpriteEditor\SpriteEditor.py (line 1393)
      • Editors\SpriteEditor\SpriteEditor.py (line 1394)
      • Editors\SpriteEditor\SpriteEditor.py (line 1395)
      • Editors\SpriteEditor\SpriteEditor.py (line 1397)
      • Editors\SpriteEditor\SpriteEditor.py (line 1402)
      • Editors\SpriteEditor\SpriteEditor.py (line 1403)
      • Editors\ModelEditor\ModelEditor.py (line 586)
      • Editors\ModelEditor\ModelEditor.py (line 731)
      • Editors\ModelEditor\ModelEditor.py (line 838)
      • Editors\ModelEditor\ModelEditor.py (line 881)
      • Editors\ModelEditor\ModelEditor.py (line 2004)
      • Editors\ModelEditor\ModelEditor.py (line 2506)
      • Editors\ModelEditor\ModelEditor.py (line 3212)
      • Editors\ModelEditor\ModelEditor.py (line 3384)
      • Editors\ModelEditor\ModelEditor.py (line 3418)
      • Editors\ModelEditor\ModelEditor.py (line 3437)
      • Editors\ModelEditor\ModelEditor.py (line 3464)
      • Editors\ModelEditor\ModelEditor.py (line 3486)
      • Editors\ModelEditor\ModelEditor.py (line 3486)
      • Editors\ModelEditor\ModelEditor.py (line 3507)
      • Editors\ModelEditor\ModelEditor.py (line 3525)
      • Editors\ModelEditor\ModelEditor.py (line 3525)
      • Editors\ModelEditor\ModelEditor.py (line 3548)
      • Editors\ModelEditor\ModelEditor.py (line 3548)
      • Editors\ModelEditor\ModelEditor.py (line 3557)
      • Editors\ModelEditor\ModelEditor.py (line 3557)
      • Editors\ModelEditor\ModelEditor.py (line 4601)
      • Editors\ModelEditor\ModelEditor.py (line 5706)
      • Editors\ModelEditor\ModelEditor.py (line 8893)
      • Editors\ModelEditor\ModelEditor.py (line 8897)
      • Editors\ModelEditor\ModelEditor.py (line 9252)
      • Editors\ModelEditor\ModelEditor.py (line 9320)
      • Editors\ModelEditor\ModelEditor.py (line 9537)
      • Editors\ModelEditor\ModelEditor.py (line 10211)
      • Editors\ModelEditor\ModelEditor.py (line 10253)
      • Editors\ModelEditor\ModelEditor.py (line 10326)
      • Editors\ModelEditor\ModelEditor.py (line 10631)
      • Editors\ModelEditor\ModelEditor.py (line 10631)
      • Editors\ModelEditor\ModelEditor.py (line 10632)
      • Editors\ModelEditor\ModelEditor.py (line 10633)
      • Editors\ModelEditor\ModelEditor.py (line 10651)
      • Editors\ModelEditor\ModelEditor.py (line 10655)
      • Editors\ModelEditor\ModelEditor.py (line 10656)
      • Editors\ModelEditor\ModelEditor.py (line 10685)
      • Editors\ModelEditor\ModelEditor.py (line 10698)
      • Editors\ModelEditor\ModelEditor.py (line 10707)
      • Editors\ModelEditor\ModelEditor.py (line 10708)
      • Editors\ModelEditor\ModelEditor.py (line 10753)
      • Editors\ModelEditor\ModelEditor.py (line 10768)
      • Editors\ModelEditor\ModelEditor.py (line 10788)
      • Editors\ModelEditor\ModelEditor.py (line 10841)
      • Editors\ModelEditor\ModelEditor.py (line 10842)
      • Editors\ModelEditor\ModelEditor.py (line 10924)
      • Editors\ModelEditor\ModelEditor.py (line 10927)
      • Editors\ModelEditor\ModelEditor.py (line 10948)
      • Editors\ModelEditor\ModelEditor.py (line 11274)
      • Editors\ModelEditor\ModelEditor.py (line 11747)
      • Editors\ModelEditor\ModelEditor.py (line 11758)
      • Editors\ModelEditor\ModelEditor.py (line 11793)
      • Editors\ModelEditor\ModelEditor.py (line 11796)
      • Editors\ModelEditor\ModelEditor.py (line 11837)
      • Editors\ModelEditor\ModelEditor.py (line 11843)
      • Editors\ModelEditor\ModelEditor.py (line 11909)
      • Editors\ModelEditor\ModelEditor.py (line 11931)
      • Editors\ModelEditor\ModelEditor.py (line 11987)
      • Editors\ModelEditor\ModelEditor.py (line 12057)
      • Editors\ModelEditor\ModelEditor.py (line 12061)

🏗️ set
   📄 Core\AI\PyGenesisAssistant\UnifiedCodeAnalyzer.py (line 79)
   📞 Called by:
      • Core\AI\PyGenesisAssistant\CodeAnalyser.py (line 303)
      • Core\AI\PyGenesisAssistant\CodeAnalyser.py (line 405)
      • Core\AI\PyGenesisAssistant\CodeAnalyser.py (line 412)
      • Core\AI\PyGenesisAssistant\CodeAnalyser.py (line 422)
      • Core\AI\PyGenesisAssistant\CodeAnalyser.py (line 1020)
      • Core\AI\PyGenesisAssistant\CodeAnalyser.py (line 1021)
      • Core\AI\PyGenesisAssistant\CodeAnalyser.py (line 1022)
      • Core\AI\PyGenesisAssistant\CodeAnalyser.py (line 1118)
      • Core\AI\PyGenesisAssistant\CodeAnalyser.py (line 1119)
      • Core\AI\PyGenesisAssistant\CodeAnalyser.py (line 1120)
      • Config\ThemeManager.py (line 231)
      • Config\ThemeManager.py (line 587)
      • Config\ThemeManager.py (line 610)
      • Config\ThemeManager.py (line 643)
      • Core\AI\PyGenesisAssistant\DependencyAnalyser.py (line 219)
      • Core\AI\PyGenesisAssistant\DependencyAnalyser.py (line 309)
      • Core\AI\PyGenesisAssistant\DependencyAnalyser.py (line 316)
      • Core\AI\PyGenesisAssistant\DependencyAnalyser.py (line 326)
      • Core\AI\PyGenesisAssistant\DependencyAnalyser.py (line 556)
      • Core\AI\PyGenesisAssistant\DependencyAnalyser.py (line 557)
      • Core\AI\PyGenesisAssistant\DependencyAnalyser.py (line 701)
      • Core\AI\PyGenesisAssistant\DependencyAnalyser.py (line 916)
      • Core\AI\PyGenesisAssistant\DependencyAnalyser.py (line 920)
      • Core\AI\PyGenesisAssistant\code_analysis.py (line 33)
      • Core\AI\PyGenesisAssistant\code_analysis.py (line 168)
      • Core\Code\Unified\validation_pipeline.py (line 261)
      • Editors\ImageEditor\core\ui\nine_slice_importer.py (line 365)
      • Editors\ImageEditor\core\ui\nine_slice_importer.py (line 366)
      • Editors\ImageEditor\core\ui\timeline.py (line 304)
      • Editors\ImageEditor\core\ui\timeline.py (line 747)
      • Editors\ImageEditor\core\ui\timeline.py (line 1207)
      • Editors\ImageEditor\core\ui\timeline.py (line 1430)
      • Core\ModulePreloader.py (line 100)
      • Editors\ImageEditor\core\ui\texture_atlas_dialog.py (line 472)
      • Core\ExtensionsManager.py (line 359)
      • Core\ExtensionsManager.py (line 526)
      • Core\ExtensionsManager.py (line 558)
      • Core\AI\PyGenesisAssistant\Nova\core\slm\custom_neural_model.py (line 689)
      • Core\AI\PyGenesisAssistant\Nova\core\slm\custom_neural_model.py (line 689)
      • Core\ProjectManager.py (line 402)
      • Core\ProjectManager.py (line 871)
      • Core\AI\PyGenesisAssistant\Nova\core\engines\thesaurus_engine.py (line 109)
      • Core\AI\PyGenesisAssistant\Nova\core\engines\thesaurus_engine.py (line 119)
      • Editors\ImageEditor\core\core\selection_manager.py (line 248)
      • Editors\ImageEditor\core\core\ai_test_app.py (line 32)
      • Core\Code\Shared\script_validator.py (line 238)
      • Core\Code\Shared\script_validator.py (line 239)
      • Core\Code\Shared\script_validator.py (line 240)
      • Core\Code\Shared\script_validator.py (line 317)
      • Core\Code\Shared\script_validator.py (line 325)
      • Core\Code\Shared\script_validator.py (line 326)
      • Core\Code\Shared\script_validator.py (line 327)
      • Core\Code\Shared\script_validator.py (line 336)
      • Core\Code\Shared\script_validator.py (line 337)
      • Core\ResourceManager.py (line 1288)
      • Core\AI\PyGenesisAssistant\UnifiedCodeAnalyzer.py (line 286)
      • Core\AI\PyGenesisAssistant\UnifiedCodeAnalyzer.py (line 454)
      • Core\AI\PyGenesisAssistant\UnifiedCodeAnalyzer.py (line 463)
      • Core\AI\PyGenesisAssistant\UnifiedCodeAnalyzer.py (line 675)
      • Core\AI\PyGenesisAssistant\UnifiedCodeAnalyzer.py (line 738)
      • Core\AI\PyGenesisAssistant\UnifiedCodeAnalyzer.py (line 834)
      • Core\AI\PyGenesisAssistant\UnifiedCodeAnalyzer.py (line 936)
      • Core\AI\PyGenesisAssistant\UnifiedCodeAnalyzer.py (line 943)
      • Core\AI\PyGenesisAssistant\UnifiedCodeAnalyzer.py (line 963)
      • Core\ThumbnailCache.py (line 146)
      • Core\Services\script_checker.py (line 219)
      • Core\Services\script_checker.py (line 220)
      • Core\Services\script_checker.py (line 221)
      • Core\Services\script_checker.py (line 277)
      • Core\Services\script_checker.py (line 278)
      • Core\Services\script_checker.py (line 279)
      • Core\AI\PyGenesisAssistant\Nova\core\executors\code_query_executor.py (line 214)
      • Core\AI\PyGenesisAssistant\Nova\core\executors\code_query_executor.py (line 220)
      • Editors\ImageEditor\core\ui\atmospheric_lighting_helpers.py (line 286)
      • Core\Services\incremental_resource_reloader.py (line 56)
      • Core\AI\PyGenesisAssistant\Nova\core\codebase_analyzer.py (line 141)
      • Editors\ObjectEditor\object_editor.py (line 1086)
      • Editors\ObjectEditor\object_editor.py (line 1195)
      • Editors\ObjectEditor\UI\code_editor_widget.py (line 185)
      • Editors\ObjectEditor\UI\code_editor_widget.py (line 242)
      • Editors\Shared\BaseImageResourceEditor.py (line 772)
      • Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 270)
      • Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 271)
      • Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 607)
      • Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 2216)
      • Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 2217)
      • Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 2251)
      • Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 2252)
      • Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 3162)
      • Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 3219)
      • Tools\BackupManager\BackupManager.py (line 50)
      • Tools\BackupManager\BackupManager.py (line 145)
      • UI\CommonDialogs\BackupFolderDialog.py (line 91)
      • UI\CommonDialogs\ResourceFolderDialog.py (line 26)
      • UI\CommonDialogs\ResourceFolderDialog.py (line 121)
      • UI\CommonDialogs\ResourceFolderDialog.py (line 127)
      • UI\CommonDialogs\ResourceFolderDialog.py (line 129)
      • UI\CommonDialogs\ExtensionsDialog.py (line 618)
      • UI\CommonDialogs\ExtensionsDialog.py (line 672)
      • UI\Widgets\ResourceTree.py (line 1885)
      • UI\CommonDialogs\PreferencesDialog.py (line 928)
      • UI\CommonDialogs\PreferencesDialog.py (line 930)
      • UI\CommonDialogs\PreferencesDialog.py (line 932)
      • UI\CommonDialogs\PreferencesDialog.py (line 1471)
      • UI\CommonDialogs\PreferencesDialog.py (line 1484)
      • UI\CommonDialogs\PreferencesDialog.py (line 1541)
      • UI\CommonDialogs\PreferencesDialog.py (line 1553)
      • UI\CommonDialogs\PreferencesDialog.py (line 1741)
      • UI\CommonDialogs\PreferencesDialog.py (line 1796)
      • UI\CommonDialogs\PreferencesDialog.py (line 1820)
      • UI\CommonDialogs\PreferencesDialog.py (line 2173)
      • UI\CommonDialogs\PreferencesDialog.py (line 2454)
      • UI\CommonDialogs\PreferencesDialog.py (line 2456)
      • UI\CommonDialogs\PreferencesDialog.py (line 2458)
      • UI\CommonDialogs\PreferencesDialog.py (line 2464)
      • UI\CommonDialogs\PreferencesDialog.py (line 2466)
      • UI\CommonDialogs\PreferencesDialog.py (line 2470)
      • UI\CommonDialogs\PreferencesDialog.py (line 2473)
      • UI\CommonDialogs\PreferencesDialog.py (line 2474)
      • UI\CommonDialogs\PreferencesDialog.py (line 2475)
      • UI\CommonDialogs\PreferencesDialog.py (line 2476)
      • UI\CommonDialogs\PreferencesDialog.py (line 2477)
      • UI\CommonDialogs\PreferencesDialog.py (line 2478)
      • UI\CommonDialogs\PreferencesDialog.py (line 2479)
      • UI\CommonDialogs\PreferencesDialog.py (line 2480)
      • UI\CommonDialogs\PreferencesDialog.py (line 2483)
      • UI\CommonDialogs\PreferencesDialog.py (line 2484)
      • UI\CommonDialogs\PreferencesDialog.py (line 2487)
      • UI\CommonDialogs\PreferencesDialog.py (line 2490)
      • UI\CommonDialogs\PreferencesDialog.py (line 2506)
      • UI\CommonDialogs\PreferencesDialog.py (line 2508)
      • UI\CommonDialogs\PreferencesDialog.py (line 2510)
      • UI\CommonDialogs\PreferencesDialog.py (line 2512)
      • UI\CommonDialogs\PreferencesDialog.py (line 2539)
      • UI\CommonDialogs\PreferencesDialog.py (line 2540)
      • UI\CommonDialogs\PreferencesDialog.py (line 2541)
      • UI\CommonDialogs\PreferencesDialog.py (line 2542)
      • UI\CommonDialogs\PreferencesDialog.py (line 2543)
      • UI\CommonDialogs\PreferencesDialog.py (line 2546)
      • UI\CommonDialogs\PreferencesDialog.py (line 2547)
      • UI\CommonDialogs\PreferencesDialog.py (line 2548)
      • UI\CommonDialogs\PreferencesDialog.py (line 2549)
      • UI\CommonDialogs\PreferencesDialog.py (line 2550)
      • UI\CommonDialogs\PreferencesDialog.py (line 2551)
      • UI\CommonDialogs\PreferencesDialog.py (line 2552)
      • UI\CommonDialogs\PreferencesDialog.py (line 2553)
      • UI\CommonDialogs\PreferencesDialog.py (line 2554)
      • UI\CommonDialogs\PreferencesDialog.py (line 2557)
      • UI\CommonDialogs\PreferencesDialog.py (line 2558)
      • UI\CommonDialogs\PreferencesDialog.py (line 2559)
      • UI\CommonDialogs\PreferencesDialog.py (line 2562)
      • UI\CommonDialogs\PreferencesDialog.py (line 2563)
      • UI\CommonDialogs\PreferencesDialog.py (line 2564)
      • UI\CommonDialogs\PreferencesDialog.py (line 2565)
      • UI\CommonDialogs\PreferencesDialog.py (line 2566)
      • UI\CommonDialogs\PreferencesDialog.py (line 2567)
      • UI\CommonDialogs\PreferencesDialog.py (line 2570)
      • UI\CommonDialogs\PreferencesDialog.py (line 2571)
      • UI\CommonDialogs\PreferencesDialog.py (line 2572)
      • UI\CommonDialogs\PreferencesDialog.py (line 2573)
      • UI\CommonDialogs\PreferencesDialog.py (line 2574)
      • UI\CommonDialogs\PreferencesDialog.py (line 2575)
      • UI\CommonDialogs\PreferencesDialog.py (line 2578)
      • UI\CommonDialogs\PreferencesDialog.py (line 2579)
      • UI\CommonDialogs\PreferencesDialog.py (line 2580)
      • UI\CommonDialogs\PreferencesDialog.py (line 2581)
      • UI\CommonDialogs\PreferencesDialog.py (line 2582)
      • UI\CommonDialogs\PreferencesDialog.py (line 2608)
      • UI\CommonDialogs\PreferencesDialog.py (line 2611)
      • UI\CommonDialogs\PreferencesDialog.py (line 2612)
      • UI\CommonDialogs\PreferencesDialog.py (line 2613)
      • UI\CommonDialogs\PreferencesDialog.py (line 2614)
      • UI\CommonDialogs\PreferencesDialog.py (line 2615)
      • UI\CommonDialogs\PreferencesDialog.py (line 2618)
      • UI\CommonDialogs\PreferencesDialog.py (line 2619)
      • UI\CommonDialogs\PreferencesDialog.py (line 2620)
      • UI\CommonDialogs\PreferencesDialog.py (line 2621)
      • UI\CommonDialogs\PreferencesDialog.py (line 2624)
      • UI\CommonDialogs\PreferencesDialog.py (line 2625)
      • UI\CommonDialogs\PreferencesDialog.py (line 2626)
      • UI\CommonDialogs\PreferencesDialog.py (line 2627)
      • UI\CommonDialogs\PreferencesDialog.py (line 2630)
      • UI\CommonDialogs\PreferencesDialog.py (line 2631)
      • UI\CommonDialogs\PreferencesDialog.py (line 2632)
      • UI\CommonDialogs\PreferencesDialog.py (line 2633)
      • UI\CommonDialogs\PreferencesDialog.py (line 2636)
      • UI\CommonDialogs\PreferencesDialog.py (line 2637)
      • UI\CommonDialogs\PreferencesDialog.py (line 2641)
      • UI\CommonDialogs\PreferencesDialog.py (line 2643)
      • UI\CommonDialogs\PreferencesDialog.py (line 2650)
      • UI\CommonDialogs\PreferencesDialog.py (line 2654)
      • UI\CommonDialogs\PreferencesDialog.py (line 2660)
      • UI\CommonDialogs\PreferencesDialog.py (line 2661)
      • UI\CommonDialogs\PreferencesDialog.py (line 2662)
      • UI\CommonDialogs\PreferencesDialog.py (line 2663)
      • UI\CommonDialogs\PreferencesDialog.py (line 2669)
      • UI\CommonDialogs\PreferencesDialog.py (line 2677)
      • UI\CommonDialogs\PreferencesDialog.py (line 2680)
      • UI\CommonDialogs\PreferencesDialog.py (line 2682)
      • UI\CommonDialogs\PreferencesDialog.py (line 2684)
      • UI\CommonDialogs\PreferencesDialog.py (line 2690)
      • UI\CommonDialogs\PreferencesDialog.py (line 2698)
      • UI\CommonDialogs\PreferencesDialog.py (line 2701)
      • UI\CommonDialogs\PreferencesDialog.py (line 2703)
      • UI\CommonDialogs\PreferencesDialog.py (line 2705)
      • UI\CommonDialogs\PreferencesDialog.py (line 2708)
      • UI\CommonDialogs\PreferencesDialog.py (line 2709)
      • UI\CommonDialogs\PreferencesDialog.py (line 2710)
      • UI\CommonDialogs\PreferencesDialog.py (line 2713)
      • UI\CommonDialogs\PreferencesDialog.py (line 2714)
      • UI\CommonDialogs\PreferencesDialog.py (line 2715)
      • UI\CommonDialogs\PreferencesDialog.py (line 2718)
      • UI\CommonDialogs\PreferencesDialog.py (line 2719)
      • UI\CommonDialogs\PreferencesDialog.py (line 2722)
      • UI\CommonDialogs\PreferencesDialog.py (line 2723)
      • UI\CommonDialogs\PreferencesDialog.py (line 2724)
      • UI\CommonDialogs\PreferencesDialog.py (line 2727)
      • UI\CommonDialogs\PreferencesDialog.py (line 2728)
      • UI\CommonDialogs\PreferencesDialog.py (line 2729)
      • UI\CommonDialogs\PreferencesDialog.py (line 2730)
      • UI\CommonDialogs\PreferencesDialog.py (line 2731)
      • UI\CommonDialogs\PreferencesDialog.py (line 2740)
      • UI\CommonDialogs\PreferencesDialog.py (line 2765)
      • Editors\ImageEditor\core\ui\preview.py (line 1938)
      • UI\MainWindow\MainWindow.py (line 588)
      • UI\MainWindow\MainWindow.py (line 589)
      • UI\MainWindow\MainWindow.py (line 848)
      • Editors\ModelEditor\ModelEditor.py (line 2900)
      • Editors\ModelEditor\ModelEditor.py (line 2900)
      • Editors\ModelEditor\ModelEditor.py (line 4434)
      • Editors\ModelEditor\ModelEditor.py (line 6460)
      • Editors\ModelEditor\ModelEditor.py (line 6461)
      • Editors\ModelEditor\ModelEditor.py (line 6462)
      • Editors\ModelEditor\ModelEditor.py (line 6536)
      • Editors\ModelEditor\ModelEditor.py (line 6537)
      • Editors\ModelEditor\ModelEditor.py (line 6538)
      • Editors\ModelEditor\ModelEditor.py (line 6567)
      • Editors\ModelEditor\ModelEditor.py (line 6568)
      • Editors\ModelEditor\ModelEditor.py (line 6569)
      • Editors\ModelEditor\ModelEditor.py (line 6577)
      • Editors\ModelEditor\ModelEditor.py (line 6672)
      • Editors\ModelEditor\ModelEditor.py (line 6715)
      • Editors\ModelEditor\ModelEditor.py (line 6795)
      • Editors\ModelEditor\ModelEditor.py (line 7860)
      • Editors\ModelEditor\ModelEditor.py (line 9127)
      • Editors\ModelEditor\ModelEditor.py (line 9201)

🏗️ clear
   📄 Core\AI\PyGenesisAssistant\UnifiedCodeAnalyzer.py (line 98)
   📞 Called by:
      • Core\AI\PyGenesisAssistant\Nova\ui\settings_dialog.py (line 99)
      • Core\AI\PyGenesisAssistant\Nova\ui\settings_dialog.py (line 456)
      • Core\AI\PyGenesisAssistant\Nova\ui\tasks_dialog.py (line 248)
      • Core\Code\Unified\unified_code_editor.py (line 100)
      • Core\Code\Unified\unified_code_editor.py (line 597)
      • Core\AI\PyGenesisAssistant\Nova\ui\project_management_dialog.py (line 340)
      • Core\AI\PyGenesisAssistant\code_analysis.py (line 37)
      • Core\AI\PyGenesisAssistant\code_analysis.py (line 38)
      • Core\AI\PyGenesisAssistant\code_analysis.py (line 39)
      • Core\AI\PyGenesisAssistant\code_analysis.py (line 98)
      • Core\AI\PyGenesisAssistant\code_analysis.py (line 99)
      • Core\AI\PyGenesisAssistant\code_analysis.py (line 100)
      • Core\AI\PyGenesisAssistant\code_analysis.py (line 101)
      • Core\AI\PyGenesisAssistant\Nova\ui\input_bar.py (line 192)
      • Core\AI\PyGenesisAssistant\Nova\ui\conversations_dialog.py (line 169)
      • Editors\ImageEditor\core\ui\dialogs\preferences_dialog.py (line 192)
      • Editors\ImageEditor\core\ui\dialogs\preferences_dialog.py (line 207)
      • Editors\ImageEditor\core\ui\dialogs\preferences_dialog.py (line 255)
      • Editors\ImageEditor\core\ui\dialogs\preferences_dialog.py (line 286)
      • Editors\ImageEditor\core\ui\dialogs\preferences_dialog.py (line 641)
      • Core\AI\PyGenesisAssistant\Nova\ui\chat_view.py (line 223)
      • Core\Rendering\BufferManager.py (line 278)
      • Core\Rendering\BufferManager.py (line 279)
      • Core\Rendering\BufferManager.py (line 280)
      • Core\Rendering\BufferManager.py (line 281)
      • Core\Rendering\BufferManager.py (line 282)
      • Core\Rendering\BufferManager.py (line 283)
      • Editors\ImageEditor\core\ui\dialogs\parameter_widgets.py (line 249)
      • Editors\ImageEditor\core\ui\timeline.py (line 541)
      • Editors\ImageEditor\core\ui\timeline.py (line 563)
      • Editors\ImageEditor\core\ui\timeline.py (line 569)
      • Editors\ImageEditor\core\ui\timeline.py (line 582)
      • Editors\ImageEditor\core\ui\timeline.py (line 595)
      • Editors\ImageEditor\core\ui\timeline.py (line 678)
      • Editors\ImageEditor\core\ui\timeline.py (line 685)
      • Editors\ImageEditor\core\ui\timeline.py (line 694)
      • Editors\ImageEditor\core\ui\timeline.py (line 708)
      • Editors\ImageEditor\core\ui\timeline.py (line 885)
      • Editors\ImageEditor\core\ui\timeline.py (line 1064)
      • Editors\ImageEditor\core\ui\timeline.py (line 1426)
      • Editors\ImageEditor\core\ui\texture_atlas_dialog.py (line 575)
      • Editors\ImageEditor\core\ui\texture_atlas_dialog.py (line 727)
      • Core\Events.py (line 144)
      • Core\Events.py (line 147)
      • Core\Rendering\Canvas_2D.py (line 160)
      • Core\Rendering\ShaderManager.py (line 219)
      • Core\Rendering\ShaderManager.py (line 220)
      • Core\Rendering\ShaderManager.py (line 221)
      • Core\Rendering\OpenGLRuntime.py (line 244)
      • Core\Rendering\OpenGLRuntime.py (line 245)
      • Core\Rendering\OpenGLRuntime.py (line 246)
      • Editors\ImageEditor\core\core\state.py (line 144)
      • Editors\ImageEditor\core\core\state.py (line 217)
      • Editors\ImageEditor\core\core\pgsprite_io.py (line 98)
      • Editors\ImageEditor\core\core\pgsprite_io.py (line 157)
      • Editors\ImageEditor\core\core\history.py (line 32)
      • Editors\ImageEditor\core\core\history.py (line 97)
      • Editors\ImageEditor\core\core\history.py (line 98)
      • Editors\ImageEditor\core\core\atlas_manager.py (line 270)
      • Editors\ImageEditor\core\core\atlas_manager.py (line 316)
      • Editors\ImageEditor\core\core\atlas_manager.py (line 317)
      • Editors\ImageEditor\core\core\background_processor.py (line 178)
      • Core\Rendering\TextureManager.py (line 275)
      • Core\Rendering\TextureManager.py (line 276)
      • Core\Rendering\TextureManager.py (line 277)
      • Editors\ImageEditor\core\ui\character_creator_dialog.py (line 148)
      • Core\UtilityOperations.py (line 225)
      • Core\UtilityOperations.py (line 239)
      • Core\UtilityOperations.py (line 254)
      • Core\UtilityOperations.py (line 269)
      • Core\UtilityOperations.py (line 414)
      • Core\UtilityOperations.py (line 415)
      • Core\ResourceManager.py (line 1873)
      • Core\ResourceManager.py (line 1875)
      • Core\ResourceManager.py (line 1877)
      • Core\AI\PyGenesisAssistant\UnifiedCodeAnalyzer.py (line 100)
      • Core\Code\Shared\code_completer.py (line 117)
      • Core\Code\Shared\code_completer.py (line 339)
      • Editors\ImageEditor\core\ui\ai_dialogs.py (line 848)
      • Core\AI\PyGenesisAssistant\NovaWidget.py (line 405)
      • Core\AI\PyGenesisAssistant\NovaWidget.py (line 406)
      • Core\AI\PyGenesisAssistant\NovaWidget.py (line 430)
      • Core\AI\PyGenesisAssistant\NovaWidget.py (line 431)
      • Editors\ObjectEditor\UI\parent_child_panel.py (line 63)
      • Editors\ObjectEditor\UI\parent_child_panel.py (line 81)
      • Editors\ObjectEditor\UI\events_panel.py (line 162)
      • Editors\ObjectEditor\UI\events_panel.py (line 402)
      • Editors\ObjectEditor\UI\properties_panel.py (line 77)
      • Editors\ObjectEditor\UI\properties_panel.py (line 441)
      • Editors\ObjectEditor\UI\properties_panel.py (line 505)
      • Editors\ObjectEditor\UI\properties_panel.py (line 558)
      • Editors\RoomEditor\RoomEditor.py (line 316)
      • Editors\RoomEditor\RoomEditor.py (line 603)
      • Editors\RoomEditor\RoomEditor.py (line 737)
      • Editors\RoomEditor\RoomEditor.py (line 851)
      • Editors\RoomEditor\ui\main_window.py (line 307)
      • Editors\RoomEditor\ui\main_window.py (line 594)
      • Editors\RoomEditor\ui\main_window.py (line 720)
      • Editors\RoomEditor\ui\main_window.py (line 834)
      • Editors\ImageEditor\core\ui\panels\left_panel.py (line 632)
      • Editors\Shared\BaseImageResourceEditor.py (line 767)
      • Editors\ObjectEditor\object_properties_panel.py (line 76)
      • Editors\ObjectEditor\object_properties_panel.py (line 402)
      • Editors\ObjectEditor\object_properties_panel.py (line 487)
      • Editors\ObjectEditor\object_properties_panel.py (line 513)
      • Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 406)
      • Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 791)
      • Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 1851)
      • Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 1892)
      • Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 1897)
      • Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 1898)
      • Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 2103)
      • Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 2189)
      • Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 2267)
      • Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 2865)
      • Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 2891)
      • Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 2896)
      • Editors\TextureEditor\TextureEditor.py (line 647)
      • UI\CommonDialogs\BackupFolderDialog.py (line 98)
      • UI\CommonDialogs\ResourceFolderDialog.py (line 92)
      • UI\CommonDialogs\RestoreDialog.py (line 97)
      • UI\CommonDialogs\ExtensionsDialog.py (line 563)
      • UI\CommonDialogs\ExtensionsDialog.py (line 853)
      • Editors\SoundEditor\SoundEditor.py (line 670)
      • UI\Widgets\TerminalWidget.py (line 289)
      • UI\CommonDialogs\PreferencesDialog.py (line 1837)
      • UI\CommonDialogs\PreferencesDialog.py (line 2386)
      • UI\CommonDialogs\PreferencesDialog.py (line 2741)
      • Editors\ImageEditor\core\ui\preview.py (line 96)
      • Tools\ScreenRecording\screen_recorder.py (line 113)
      • Tools\ScreenRecording\screen_recorder.py (line 114)
      • Tools\ScreenRecording\screen_recorder.py (line 140)
      • Tools\ScreenRecording\screen_recorder.py (line 141)
      • Editors\Shared\IntegratedImageEditor.py (line 343)
      • Editors\Shared\IntegratedImageEditor.py (line 711)
      • Editors\Shared\IntegratedImageEditor.py (line 713)
      • Editors\SoundEditor\core\WaveForge.py (line 1115)
      • UI\MainWindow\MainWindow.py (line 80)
      • UI\MainWindow\MainWindow.py (line 81)
      • UI\MainWindow\MainWindow.py (line 176)
      • UI\MainWindow\MainWindow.py (line 177)
      • UI\MainWindow\MainWindow.py (line 242)
      • UI\MainWindow\MainWindow.py (line 243)
      • UI\MainWindow\MainWindow.py (line 1195)
      • Editors\ObjectEditor\object_events_panel.py (line 158)
      • Editors\SpriteEditor\SpriteEditor.py (line 873)
      • Editors\ModelEditor\ModelEditor.py (line 896)
      • Editors\ModelEditor\ModelEditor.py (line 3646)
      • Editors\ModelEditor\ModelEditor.py (line 3647)
      • Editors\ModelEditor\ModelEditor.py (line 3648)
      • Editors\ModelEditor\ModelEditor.py (line 3650)
      • Editors\ModelEditor\ModelEditor.py (line 3658)
      • Editors\ModelEditor\ModelEditor.py (line 3659)
      • Editors\ModelEditor\ModelEditor.py (line 3660)
      • Editors\ModelEditor\ModelEditor.py (line 3662)
      • Editors\ModelEditor\ModelEditor.py (line 3670)
      • Editors\ModelEditor\ModelEditor.py (line 3671)
      • Editors\ModelEditor\ModelEditor.py (line 3672)
      • Editors\ModelEditor\ModelEditor.py (line 3674)
      • Editors\ModelEditor\ModelEditor.py (line 3701)
      • Editors\ModelEditor\ModelEditor.py (line 3702)
      • Editors\ModelEditor\ModelEditor.py (line 3703)
      • Editors\ModelEditor\ModelEditor.py (line 3705)
      • Editors\ModelEditor\ModelEditor.py (line 6507)
      • Editors\ModelEditor\ModelEditor.py (line 6866)
      • Editors\ModelEditor\ModelEditor.py (line 7669)
      • Editors\ModelEditor\ModelEditor.py (line 7670)
      • Editors\ModelEditor\ModelEditor.py (line 7671)
      • Editors\ModelEditor\ModelEditor.py (line 8100)
      • Editors\ModelEditor\ModelEditor.py (line 9131)
      • Editors\ModelEditor\ModelEditor.py (line 9205)
      • Editors\ModelEditor\ModelEditor.py (line 9638)
      • Editors\ModelEditor\ModelEditor.py (line 9639)
      • Editors\ModelEditor\ModelEditor.py (line 9640)
      • Editors\ModelEditor\ModelEditor.py (line 9709)
      • Editors\ModelEditor\ModelEditor.py (line 10421)
      • Editors\ModelEditor\ModelEditor.py (line 10437)

🏗️ get_stats
   📄 Core\AI\PyGenesisAssistant\UnifiedCodeAnalyzer.py (line 107)
   📞 Called by:
      • Core\AI\PyGenesisAssistant\UnifiedCodeAnalyzer.py (line 949)
      • Core\AI\PyGenesisAssistant\UnifiedCodeAnalyzer.py (line 1001)

🏗️ parse_file_ast
   📄 Core\AI\PyGenesisAssistant\UnifiedCodeAnalyzer.py (line 119)
   ⚠️  Never called

🏗️ extract_definitions_fast
   📄 Core\AI\PyGenesisAssistant\UnifiedCodeAnalyzer.py (line 133)
   ⚠️  Never called

🏗️ visit_Import
   📄 Core\AI\PyGenesisAssistant\UnifiedCodeAnalyzer.py (line 168)
   ⚠️  Never called

🏗️ visit_ImportFrom
   📄 Core\AI\PyGenesisAssistant\UnifiedCodeAnalyzer.py (line 176)
   ⚠️  Never called

🏗️ _get_name
   📄 Core\AI\PyGenesisAssistant\UnifiedCodeAnalyzer.py (line 189)
   ⚠️  Never called

🏗️ extract_calls_fast
   📄 Core\AI\PyGenesisAssistant\UnifiedCodeAnalyzer.py (line 202)
   ⚠️  Never called

🏗️ _get_function_name
   📄 Core\AI\PyGenesisAssistant\UnifiedCodeAnalyzer.py (line 216)
   ⚠️  Never called

🏗️ analyze_files
   📄 Core\AI\PyGenesisAssistant\UnifiedCodeAnalyzer.py (line 251)
   📞 Called by:
      • Core\AI\PyGenesisAssistant\UnifiedCodeAnalyzer.py (line 926)

🏗️ _aggregate_results
   📄 Core\AI\PyGenesisAssistant\UnifiedCodeAnalyzer.py (line 329)
   ⚠️  Never called

🏗️ get_file_workflow
   📄 Core\AI\PyGenesisAssistant\UnifiedCodeAnalyzer.py (line 418)
   ⚠️  Never called

🏗️ get_function_workflow
   📄 Core\AI\PyGenesisAssistant\UnifiedCodeAnalyzer.py (line 431)
   📞 Called by:
      • Core\AI\PyGenesisAssistant\UnifiedCodeAnalyzer.py (line 1072)
      • Core\AI\PyGenesisAssistant\UnifiedCodeAnalyzer.py (line 1114)

🏗️ get_unused_functions
   📄 Core\AI\PyGenesisAssistant\UnifiedCodeAnalyzer.py (line 452)
   📞 Called by:
      • Core\AI\PyGenesisAssistant\UnifiedCodeAnalyzer.py (line 1154)

🏗️ create_overview_tab
   📄 Core\AI\PyGenesisAssistant\UnifiedCodeAnalyzer.py (line 607)
   ⚠️  Never called

🏗️ create_definitions_tab
   📄 Core\AI\PyGenesisAssistant\UnifiedCodeAnalyzer.py (line 619)
   ⚠️  Never called

🏗️ create_dependencies_tab
   📄 Core\AI\PyGenesisAssistant\UnifiedCodeAnalyzer.py (line 627)
   ⚠️  Never called

🏗️ create_workflow_tab
   📄 Core\AI\PyGenesisAssistant\UnifiedCodeAnalyzer.py (line 635)
   ⚠️  Never called

🏗️ create_unused_tab
   📄 Core\AI\PyGenesisAssistant\UnifiedCodeAnalyzer.py (line 655)
   ⚠️  Never called

🏗️ create_file_analysis_tab
   📄 Core\AI\PyGenesisAssistant\UnifiedCodeAnalyzer.py (line 663)
   ⚠️  Never called

🏗️ on_tree_click
   📄 Core\AI\PyGenesisAssistant\UnifiedCodeAnalyzer.py (line 743)
   ⚠️  Never called

🏗️ _toggle_children
   📄 Core\AI\PyGenesisAssistant\UnifiedCodeAnalyzer.py (line 770)
   ⚠️  Never called

🏗️ check_all
   📄 Core\AI\PyGenesisAssistant\UnifiedCodeAnalyzer.py (line 786)
   ⚠️  Never called

🏗️ uncheck_all
   📄 Core\AI\PyGenesisAssistant\UnifiedCodeAnalyzer.py (line 791)
   ⚠️  Never called

🏗️ _set_checked
   📄 Core\AI\PyGenesisAssistant\UnifiedCodeAnalyzer.py (line 796)
   ⚠️  Never called

🏗️ on_file_double_click
   📄 Core\AI\PyGenesisAssistant\UnifiedCodeAnalyzer.py (line 811)
   ⚠️  Never called

🏗️ on_file_right_click
   📄 Core\AI\PyGenesisAssistant\UnifiedCodeAnalyzer.py (line 821)
   ⚠️  Never called

🏗️ analyze_single_file
   📄 Core\AI\PyGenesisAssistant\UnifiedCodeAnalyzer.py (line 832)
   ⚠️  Never called

🏗️ analyze_selected
   📄 Core\AI\PyGenesisAssistant\UnifiedCodeAnalyzer.py (line 850)
   ⚠️  Never called

🏗️ collect_checked_files
   📄 Core\AI\PyGenesisAssistant\UnifiedCodeAnalyzer.py (line 885)
   📞 Called by:
      • Core\AI\PyGenesisAssistant\UnifiedCodeAnalyzer.py (line 869)
      • Core\AI\PyGenesisAssistant\UnifiedCodeAnalyzer.py (line 873)
      • Core\AI\PyGenesisAssistant\UnifiedCodeAnalyzer.py (line 898)
      • Core\AI\PyGenesisAssistant\UnifiedCodeAnalyzer.py (line 901)

🏗️ analyze_all
   📄 Core\AI\PyGenesisAssistant\UnifiedCodeAnalyzer.py (line 881)
   ⚠️  Never called

🏗️ display_overview
   📄 Core\AI\PyGenesisAssistant\UnifiedCodeAnalyzer.py (line 982)
   ⚠️  Never called

🏗️ display_definitions
   📄 Core\AI\PyGenesisAssistant\UnifiedCodeAnalyzer.py (line 1011)
   ⚠️  Never called

🏗️ display_dependencies
   📄 Core\AI\PyGenesisAssistant\UnifiedCodeAnalyzer.py (line 1034)
   ⚠️  Never called

🏗️ display_workflow
   📄 Core\AI\PyGenesisAssistant\UnifiedCodeAnalyzer.py (line 1060)
   ⚠️  Never called

🏗️ show_all_workflow
   📄 Core\AI\PyGenesisAssistant\UnifiedCodeAnalyzer.py (line 1064)
   ⚠️  Never called

🏗️ update_workflow
   📄 Core\AI\PyGenesisAssistant\UnifiedCodeAnalyzer.py (line 1106)
   ⚠️  Never called

🏗️ display_unused
   📄 Core\AI\PyGenesisAssistant\UnifiedCodeAnalyzer.py (line 1147)
   ⚠️  Never called

🏗️ display_file_analysis
   📄 Core\AI\PyGenesisAssistant\UnifiedCodeAnalyzer.py (line 1170)
   ⚠️  Never called

🏗️ get_thumbnail
   📄 Core\ThumbnailCache.py (line 37)
   📞 Called by:
      • UI\Widgets\ParallelThumbnailLoader.py (line 35)
      • UI\Widgets\ThumbnailLoader.py (line 77)

🏗️ save_thumbnail
   📄 Core\ThumbnailCache.py (line 84)
   📞 Called by:
      • UI\Widgets\ParallelThumbnailLoader.py (line 47)
      • UI\Widgets\ThumbnailLoader.py (line 89)

🏗️ cleanup_orphaned_cache
   📄 Core\ThumbnailCache.py (line 139)
   ⚠️  Never called

🏗️ _get_resource_image_path
   📄 Core\ThumbnailCache.py (line 183)
   ⚠️  Never called

🏗️ _load_cache_index
   📄 Core\ThumbnailCache.py (line 190)
   ⚠️  Never called

🏗️ _save_cache_index
   📄 Core\ThumbnailCache.py (line 202)
   ⚠️  Never called

🏗️ create_menu_bar
   📄 Editors\ImageEditor\core\ui\components\menu_bar.py (line 25)
   ⚠️  Never called

🏗️ _create_file_menu
   📄 Editors\ImageEditor\core\ui\components\menu_bar.py (line 38)
   ⚠️  Never called

🏗️ _create_edit_menu
   📄 Editors\ImageEditor\core\ui\components\menu_bar.py (line 70)
   ⚠️  Never called

🏗️ _create_view_menu
   📄 Editors\ImageEditor\core\ui\components\menu_bar.py (line 100)
   ⚠️  Never called

🏗️ _create_frame_menu
   📄 Editors\ImageEditor\core\ui\components\menu_bar.py (line 120)
   ⚠️  Never called

🏗️ _create_effects_menu
   📄 Editors\ImageEditor\core\ui\components\menu_bar.py (line 139)
   ⚠️  Never called

🏗️ _create_ai_menu
   📄 Editors\ImageEditor\core\ui\components\menu_bar.py (line 233)
   ⚠️  Never called

🏗️ setup_shortcuts
   📄 Editors\ImageEditor\core\ui\components\menu_bar.py (line 250)
   ⚠️  Never called

🏗️ load_default_settings
   📄 Config\Settings.py (line 15)
   ⚠️  Never called

🏗️ set_default_settings
   📄 Config\Settings.py (line 20)
   ⚠️  Never called

🏗️ get_recent_projects
   📄 Config\Settings.py (line 58)
   📞 Called by:
      • UI\CommonDialogs\PreferencesDialog.py (line 2385)
      • UI\CommonDialogs\PreferencesDialog.py (line 2762)

🏗️ add_recent_project
   📄 Config\Settings.py (line 66)
   📞 Called by:
      • UI\MainWindow\MainWindow.py (line 772)
      • UI\MainWindow\MainWindow.py (line 805)

🏗️ sync
   📄 Config\Settings.py (line 79)
   📞 Called by:
      • Config\ThemeManager.py (line 588)
      • Config\ThemeManager.py (line 611)
      • Config\Settings.py (line 81)
      • UI\CommonDialogs\PreferencesDialog.py (line 2735)
      • UI\MainWindow\MainWindow.py (line 590)

🏗️ check_script
   📄 Core\Services\script_checker.py (line 40)
   ⚠️  Never called

🏗️ check_all_scripts
   📄 Core\Services\script_checker.py (line 138)
   ⚠️  Never called

🏗️ set_completions
   📄 Core\Code\Shared\code_completer.py (line 79)
   ⚠️  Never called

🏗️ filter_completions
   📄 Core\Code\Shared\code_completer.py (line 94)
   ⚠️  Never called

🏗️ _update_list
   📄 Core\Code\Shared\code_completer.py (line 115)
   ⚠️  Never called

🏗️ _update_doc
   📄 Core\Code\Shared\code_completer.py (line 133)
   ⚠️  Never called

🏗️ _on_item_clicked
   📄 Core\Code\Shared\code_completer.py (line 146)
   ⚠️  Never called

🏗️ _on_item_double_clicked
   📄 Core\Code\Shared\code_completer.py (line 153)
   ⚠️  Never called

🏗️ show_at_position
   📄 Core\Code\Shared\code_completer.py (line 157)
   ⚠️  Never called

🏗️ select_next
   📄 Core\Code\Shared\code_completer.py (line 164)
   ⚠️  Never called

🏗️ select_previous
   📄 Core\Code\Shared\code_completer.py (line 171)
   ⚠️  Never called

🏗️ get_selected_completion
   📄 Core\Code\Shared\code_completer.py (line 178)
   ⚠️  Never called

🏗️ _show_completions
   📄 Core\Code\Shared\code_completer.py (line 185)
   ⚠️  Never called

🏗️ _get_python_keywords
   📄 Core\Code\Shared\code_completer.py (line 209)
   ⚠️  Never called

🏗️ _get_pgsl_commands
   📄 Core\Code\Shared\code_completer.py (line 221)
   ⚠️  Never called

🏗️ get_all_completions
   📄 Core\Code\Shared\code_completer.py (line 320)
   ⚠️  Never called

🏗️ add_custom_completion
   📄 Core\Code\Shared\code_completer.py (line 328)
   ⚠️  Never called

🏗️ clear_custom_completions
   📄 Core\Code\Shared\code_completer.py (line 337)
   ⚠️  Never called

🏗️ _extract_code_entity
   📄 Core\AI\PyGenesisAssistant\Nova\core\executors\code_query_executor.py (line 48)
   ⚠️  Never called

🏗️ _extract_class_name
   📄 Core\AI\PyGenesisAssistant\Nova\core\executors\code_query_executor.py (line 65)
   ⚠️  Never called

🏗️ _extract_function_name
   📄 Core\AI\PyGenesisAssistant\Nova\core\executors\code_query_executor.py (line 78)
   ⚠️  Never called

🏗️ _is_class_query
   📄 Core\AI\PyGenesisAssistant\Nova\core\executors\code_query_executor.py (line 86)
   ⚠️  Never called

🏗️ _is_function_query
   📄 Core\AI\PyGenesisAssistant\Nova\core\executors\code_query_executor.py (line 91)
   ⚠️  Never called

🏗️ _is_structure_query
   📄 Core\AI\PyGenesisAssistant\Nova\core\executors\code_query_executor.py (line 96)
   ⚠️  Never called

🏗️ _is_dependency_query
   📄 Core\AI\PyGenesisAssistant\Nova\core\executors\code_query_executor.py (line 101)
   ⚠️  Never called

🏗️ _answer_class_query
   📄 Core\AI\PyGenesisAssistant\Nova\core\executors\code_query_executor.py (line 106)
   ⚠️  Never called

🏗️ _answer_function_query
   📄 Core\AI\PyGenesisAssistant\Nova\core\executors\code_query_executor.py (line 136)
   ⚠️  Never called

🏗️ _answer_structure_query
   📄 Core\AI\PyGenesisAssistant\Nova\core\executors\code_query_executor.py (line 165)
   ⚠️  Never called

🏗️ _answer_dependency_query
   📄 Core\AI\PyGenesisAssistant\Nova\core\executors\code_query_executor.py (line 190)
   ⚠️  Never called

🏗️ _answer_generic_query
   📄 Core\AI\PyGenesisAssistant\Nova\core\executors\code_query_executor.py (line 225)
   ⚠️  Never called

🏗️ validate_resource_name
   📄 Core\Services\validation_service.py (line 16)
   ⚠️  Never called

🏗️ validate_resource_data
   📄 Core\Services\validation_service.py (line 40)
   ⚠️  Never called

🏗️ validate_project_path
   📄 Core\Services\validation_service.py (line 68)
   ⚠️  Never called

🏗️ set_game_runtime
   📄 Core\Code\PGSL\pgsl_runtime.py (line 26)
   ⚠️  Never called

🏗️ Run
   📄 Core\Code\PGSL\pgsl_runtime.py (line 33)
   ⚠️  Never called

🏗️ Debug_Run
   📄 Core\Code\PGSL\pgsl_runtime.py (line 38)
   ⚠️  Never called

🏗️ Build
   📄 Core\Code\PGSL\pgsl_runtime.py (line 43)
   ⚠️  Never called

🏗️ Validate
   📄 Core\Code\PGSL\pgsl_runtime.py (line 48)
   ⚠️  Never called

🏗️ game_end
   📄 Core\Code\PGSL\pgsl_runtime.py (line 53)
   ⚠️  Never called

🏗️ window_set_size
   📄 Core\Code\PGSL\pgsl_runtime.py (line 59)
   ⚠️  Never called

🏗️ window_set_title
   📄 Core\Code\PGSL\pgsl_runtime.py (line 66)
   ⚠️  Never called

🏗️ game_set_speed
   📄 Core\Code\PGSL\pgsl_runtime.py (line 72)
   ⚠️  Never called

🏗️ room_set_speed
   📄 Core\Code\PGSL\pgsl_runtime.py (line 77)
   ⚠️  Never called

🏗️ create_instance
   📄 Core\Code\PGSL\pgsl_runtime.py (line 84)
   ⚠️  Never called

🏗️ instance_destroy
   📄 Core\Code\PGSL\pgsl_runtime.py (line 92)
   ⚠️  Never called

🏗️ instance_find
   📄 Core\Code\PGSL\pgsl_runtime.py (line 99)
   ⚠️  Never called

🏗️ instance_find_nearest
   📄 Core\Code\PGSL\pgsl_runtime.py (line 107)
   ⚠️  Never called

🏗️ instance_find_furthest
   📄 Core\Code\PGSL\pgsl_runtime.py (line 116)
   ⚠️  Never called

🏗️ instance_find_id
   📄 Core\Code\PGSL\pgsl_runtime.py (line 125)
   ⚠️  Never called

🏗️ instance_get_count
   📄 Core\Code\PGSL\pgsl_runtime.py (line 133)
   ⚠️  Never called

🏗️ instance_exists
   📄 Core\Code\PGSL\pgsl_runtime.py (line 138)
   ⚠️  Never called

🏗️ instance_copy
   📄 Core\Code\PGSL\pgsl_runtime.py (line 143)
   ⚠️  Never called

🏗️ instance_set_motion
   📄 Core\Code\PGSL\pgsl_runtime.py (line 149)
   ⚠️  Never called

🏗️ instance_get_motion
   📄 Core\Code\PGSL\pgsl_runtime.py (line 158)
   ⚠️  Never called

🏗️ place_free
   📄 Core\Code\PGSL\pgsl_runtime.py (line 166)
   ⚠️  Never called

🏗️ place_free_3d
   📄 Core\Code\PGSL\pgsl_runtime.py (line 172)
   ⚠️  Never called

🏗️ Variable_set
   📄 Core\Code\PGSL\pgsl_runtime.py (line 180)
   ⚠️  Never called

🏗️ Variable_get
   📄 Core\Code\PGSL\pgsl_runtime.py (line 187)
   ⚠️  Never called

🏗️ Variable_exists
   📄 Core\Code\PGSL\pgsl_runtime.py (line 193)
   ⚠️  Never called

🏗️ Wait
   📄 Core\Code\PGSL\pgsl_runtime.py (line 199)
   ⚠️  Never called

🏗️ clamp
   📄 Core\Code\PGSL\pgsl_runtime.py (line 205)
   ⚠️  Never called

🏗️ lerp
   📄 Core\Code\PGSL\pgsl_runtime.py (line 210)
   ⚠️  Never called

🏗️ point_direction
   📄 Core\Code\PGSL\pgsl_runtime.py (line 215)
   ⚠️  Never called

🏗️ point_distance
   📄 Core\Code\PGSL\pgsl_runtime.py (line 222)
   ⚠️  Never called

🏗️ random_range
   📄 Core\Code\PGSL\pgsl_runtime.py (line 229)
   ⚠️  Never called

🏗️ random_int
   📄 Core\Code\PGSL\pgsl_runtime.py (line 234)
   ⚠️  Never called

🏗️ Move2D_direction
   📄 Core\Code\PGSL\pgsl_runtime.py (line 241)
   ⚠️  Never called

🏗️ Move2D_point
   📄 Core\Code\PGSL\pgsl_runtime.py (line 247)
   ⚠️  Never called

🏗️ Move3D_direction
   📄 Core\Code\PGSL\pgsl_runtime.py (line 253)
   ⚠️  Never called

🏗️ Move3D_towards
   📄 Core\Code\PGSL\pgsl_runtime.py (line 259)
   ⚠️  Never called

🏗️ Move3D_stop
   📄 Core\Code\PGSL\pgsl_runtime.py (line 265)
   ⚠️  Never called

🏗️ Move3D_add_force
   📄 Core\Code\PGSL\pgsl_runtime.py (line 271)
   ⚠️  Never called

🏗️ collision_point
   📄 Core\Code\PGSL\pgsl_runtime.py (line 277)
   ⚠️  Never called

🏗️ collision_rect
   📄 Core\Code\PGSL\pgsl_runtime.py (line 283)
   ⚠️  Never called

🏗️ Draw_Self_2D
   📄 Core\Code\PGSL\pgsl_runtime.py (line 291)
   ⚠️  Never called

🏗️ Draw_Sprite_2D
   📄 Core\Code\PGSL\pgsl_runtime.py (line 297)
   ⚠️  Never called

🏗️ Draw_Text_2D
   📄 Core\Code\PGSL\pgsl_runtime.py (line 303)
   ⚠️  Never called

🏗️ Draw_Rect_2D
   📄 Core\Code\PGSL\pgsl_runtime.py (line 309)
   ⚠️  Never called

🏗️ Draw_Self_3D
   📄 Core\Code\PGSL\pgsl_runtime.py (line 315)
   ⚠️  Never called

🏗️ Draw_Model_3D
   📄 Core\Code\PGSL\pgsl_runtime.py (line 321)
   ⚠️  Never called

🏗️ Draw_Text_3D
   📄 Core\Code\PGSL\pgsl_runtime.py (line 327)
   ⚠️  Never called

🏗️ Draw_HUD
   📄 Core\Code\PGSL\pgsl_runtime.py (line 333)
   ⚠️  Never called

🏗️ Draw_Bar
   📄 Core\Code\PGSL\pgsl_runtime.py (line 339)
   ⚠️  Never called

🏗️ Draw_HUD_Text
   📄 Core\Code\PGSL\pgsl_runtime.py (line 346)
   ⚠️  Never called

🏗️ Draw_HUD_Sprite
   📄 Core\Code\PGSL\pgsl_runtime.py (line 352)
   ⚠️  Never called

🏗️ Camera2D_set_position
   📄 Core\Code\PGSL\pgsl_runtime.py (line 360)
   ⚠️  Never called

🏗️ Camera2D_follow
   📄 Core\Code\PGSL\pgsl_runtime.py (line 366)
   ⚠️  Never called

🏗️ Camera2D_shake
   📄 Core\Code\PGSL\pgsl_runtime.py (line 372)
   ⚠️  Never called

🏗️ Camera3D_set_position
   📄 Core\Code\PGSL\pgsl_runtime.py (line 378)
   ⚠️  Never called

🏗️ Camera3D_set_target
   📄 Core\Code\PGSL\pgsl_runtime.py (line 384)
   ⚠️  Never called

🏗️ Camera3D_set_angle
   📄 Core\Code\PGSL\pgsl_runtime.py (line 390)
   ⚠️  Never called

🏗️ Camera3D_follow
   📄 Core\Code\PGSL\pgsl_runtime.py (line 396)
   ⚠️  Never called

🏗️ Camera3D_shake
   📄 Core\Code\PGSL\pgsl_runtime.py (line 402)
   ⚠️  Never called

🏗️ Viewport_create
   📄 Core\Code\PGSL\pgsl_runtime.py (line 408)
   ⚠️  Never called

🏗️ Viewport_set_camera
   📄 Core\Code\PGSL\pgsl_runtime.py (line 414)
   ⚠️  Never called

🏗️ Viewport_activate
   📄 Core\Code\PGSL\pgsl_runtime.py (line 420)
   ⚠️  Never called

🏗️ key_check
   📄 Core\Code\PGSL\pgsl_runtime.py (line 428)
   ⚠️  Never called

🏗️ key_pressed
   📄 Core\Code\PGSL\pgsl_runtime.py (line 434)
   ⚠️  Never called

🏗️ key_released
   📄 Core\Code\PGSL\pgsl_runtime.py (line 440)
   ⚠️  Never called

🏗️ mouse_position
   📄 Core\Code\PGSL\pgsl_runtime.py (line 446)
   ⚠️  Never called

🏗️ mouse_delta
   📄 Core\Code\PGSL\pgsl_runtime.py (line 451)
   ⚠️  Never called

🏗️ mouse_button_check
   📄 Core\Code\PGSL\pgsl_runtime.py (line 457)
   ⚠️  Never called

🏗️ mouse_button_pressed
   📄 Core\Code\PGSL\pgsl_runtime.py (line 462)
   ⚠️  Never called

🏗️ Input_bind
   📄 Core\Code\PGSL\pgsl_runtime.py (line 468)
   ⚠️  Never called

🏗️ Input_check
   📄 Core\Code\PGSL\pgsl_runtime.py (line 474)
   ⚠️  Never called

🏗️ Input_pressed
   📄 Core\Code\PGSL\pgsl_runtime.py (line 480)
   ⚠️  Never called

🏗️ sound_play
   📄 Core\Code\PGSL\pgsl_runtime.py (line 486)
   ⚠️  Never called

🏗️ sound_stop
   📄 Core\Code\PGSL\pgsl_runtime.py (line 492)
   ⚠️  Never called

🏗️ sound_stop_all
   📄 Core\Code\PGSL\pgsl_runtime.py (line 498)
   ⚠️  Never called

🏗️ sound_pause
   📄 Core\Code\PGSL\pgsl_runtime.py (line 504)
   ⚠️  Never called

🏗️ sound_pause_all
   📄 Core\Code\PGSL\pgsl_runtime.py (line 510)
   ⚠️  Never called

🏗️ sound_resume
   📄 Core\Code\PGSL\pgsl_runtime.py (line 516)
   ⚠️  Never called

🏗️ sound_resume_all
   📄 Core\Code\PGSL\pgsl_runtime.py (line 522)
   ⚠️  Never called

🏗️ sound_is_active
   📄 Core\Code\PGSL\pgsl_runtime.py (line 528)
   ⚠️  Never called

🏗️ net_host
   📄 Core\Code\PGSL\pgsl_runtime.py (line 536)
   ⚠️  Never called

🏗️ net_connect
   📄 Core\Code\PGSL\pgsl_runtime.py (line 542)
   ⚠️  Never called

🏗️ net_close
   📄 Core\Code\PGSL\pgsl_runtime.py (line 548)
   ⚠️  Never called

🏗️ net_send_all
   📄 Core\Code\PGSL\pgsl_runtime.py (line 554)
   ⚠️  Never called

🏗️ net_send_to
   📄 Core\Code\PGSL\pgsl_runtime.py (line 560)
   ⚠️  Never called

🏗️ net_get
   📄 Core\Code\PGSL\pgsl_runtime.py (line 566)
   ⚠️  Never called

🏗️ net_sync_position
   📄 Core\Code\PGSL\pgsl_runtime.py (line 572)
   ⚠️  Never called

🏗️ net_sync_variable
   📄 Core\Code\PGSL\pgsl_runtime.py (line 578)
   ⚠️  Never called

🏗️ net_register_event
   📄 Core\Code\PGSL\pgsl_runtime.py (line 584)
   ⚠️  Never called

🏗️ shader_get
   📄 Core\Code\PGSL\pgsl_runtime.py (line 592)
   ⚠️  Never called

🏗️ shader_use
   📄 Core\Code\PGSL\pgsl_runtime.py (line 598)
   ⚠️  Never called

🏗️ shader_reset
   📄 Core\Code\PGSL\pgsl_runtime.py (line 604)
   ⚠️  Never called

🏗️ shader_set_uniform
   📄 Core\Code\PGSL\pgsl_runtime.py (line 610)
   ⚠️  Never called

🏗️ shader_apply_global
   📄 Core\Code\PGSL\pgsl_runtime.py (line 616)
   ⚠️  Never called

🏗️ shader_remove_global
   📄 Core\Code\PGSL\pgsl_runtime.py (line 622)
   ⚠️  Never called

🏗️ compute_shader_get
   📄 Core\Code\PGSL\pgsl_runtime.py (line 628)
   ⚠️  Never called

🏗️ compute_shader_run
   📄 Core\Code\PGSL\pgsl_runtime.py (line 634)
   ⚠️  Never called

🏗️ particle_system_create
   📄 Core\Code\PGSL\pgsl_runtime.py (line 642)
   ⚠️  Never called

🏗️ particle_system_emit
   📄 Core\Code\PGSL\pgsl_runtime.py (line 648)
   ⚠️  Never called

🏗️ particle_system_set_property
   📄 Core\Code\PGSL\pgsl_runtime.py (line 654)
   ⚠️  Never called

🏗️ script_exists
   📄 Core\Code\PGSL\pgsl_runtime.py (line 662)
   ⚠️  Never called

🏗️ script_call
   📄 Core\Code\PGSL\pgsl_runtime.py (line 668)
   ⚠️  Never called

🏗️ script_get
   📄 Core\Code\PGSL\pgsl_runtime.py (line 674)
   ⚠️  Never called

🏗️ _setup_block_tab
   📄 Editors\ImageEditor\core\ui\block_texture_dialog.py (line 93)
   ⚠️  Never called

🏗️ _setup_style_tab
   📄 Editors\ImageEditor\core\ui\block_texture_dialog.py (line 153)
   ⚠️  Never called

🏗️ _setup_animation_tab
   📄 Editors\ImageEditor\core\ui\block_texture_dialog.py (line 187)
   ⚠️  Never called

🏗️ _setup_style_parameters
   📄 Editors\ImageEditor\core\ui\block_texture_dialog.py (line 223)
   ⚠️  Never called

🏗️ _add_water_parameters
   📄 Editors\ImageEditor\core\ui\block_texture_dialog.py (line 249)
   ⚠️  Never called

🏗️ _add_lava_parameters
   📄 Editors\ImageEditor\core\ui\block_texture_dialog.py (line 276)
   ⚠️  Never called

🏗️ _add_fire_parameters
   📄 Editors\ImageEditor\core\ui\block_texture_dialog.py (line 303)
   ⚠️  Never called

🏗️ _add_smoke_parameters
   📄 Editors\ImageEditor\core\ui\block_texture_dialog.py (line 330)
   ⚠️  Never called

🏗️ _add_fog_parameters
   📄 Editors\ImageEditor\core\ui\block_texture_dialog.py (line 357)
   ⚠️  Never called

🏗️ _add_crystal_parameters
   📄 Editors\ImageEditor\core\ui\block_texture_dialog.py (line 384)
   ⚠️  Never called

🏗️ _add_wind_parameters
   📄 Editors\ImageEditor\core\ui\block_texture_dialog.py (line 411)
   ⚠️  Never called

🏗️ _add_portal_parameters
   📄 Editors\ImageEditor\core\ui\block_texture_dialog.py (line 438)
   ⚠️  Never called

🏗️ _update_opacity_label
   📄 Editors\ImageEditor\core\ui\block_texture_dialog.py (line 506)
   ⚠️  Never called

🏗️ _update_anim_speed_label
   📄 Editors\ImageEditor\core\ui\block_texture_dialog.py (line 510)
   ⚠️  Never called

🏗️ _on_style_changed
   📄 Editors\ImageEditor\core\ui\block_texture_dialog.py (line 514)
   ⚠️  Never called

🏗️ schedule_preview_update
   📄 Editors\ImageEditor\core\ui\block_texture_dialog.py (line 518)
   ⚠️  Never called

🏗️ get_search_url
   📄 Core\AI\PyGenesisAssistant\Nova\core\engines\research_engine.py (line 31)
   ⚠️  Never called

🏗️ _load_safe_sites
   📄 Core\AI\PyGenesisAssistant\Nova\core\engines\research_engine.py (line 52)
   ⚠️  Never called

🏗️ _create_default_sites
   📄 Core\AI\PyGenesisAssistant\Nova\core\engines\research_engine.py (line 78)
   ⚠️  Never called

🏗️ _clean_query
   📄 Core\AI\PyGenesisAssistant\Nova\core\engines\research_engine.py (line 264)
   ⚠️  Never called

🏗️ _select_sites
   📄 Core\AI\PyGenesisAssistant\Nova\core\engines\research_engine.py (line 289)
   ⚠️  Never called

🏗️ _is_what_is_question
   📄 Core\AI\PyGenesisAssistant\Nova\core\engines\research_engine.py (line 325)
   ⚠️  Never called

🏗️ _is_programming_query
   📄 Core\AI\PyGenesisAssistant\Nova\core\engines\research_engine.py (line 352)
   ⚠️  Never called

🏗️ _fetch_site_info
   📄 Core\AI\PyGenesisAssistant\Nova\core\engines\research_engine.py (line 395)
   ⚠️  Never called

🏗️ _fetch_wikipedia_info
   📄 Core\AI\PyGenesisAssistant\Nova\core\engines\research_engine.py (line 410)
   ⚠️  Never called

🏗️ _handle_disambiguation
   📄 Core\AI\PyGenesisAssistant\Nova\core\engines\research_engine.py (line 471)
   ⚠️  Never called

🏗️ _search_wikipedia_article
   📄 Core\AI\PyGenesisAssistant\Nova\core\engines\research_engine.py (line 527)
   ⚠️  Never called

🏗️ _is_implementation_query
   📄 Core\AI\PyGenesisAssistant\Nova\core\engines\research_engine.py (line 577)
   ⚠️  Never called

🏗️ _is_guidance_query
   📄 Core\AI\PyGenesisAssistant\Nova\core\engines\research_engine.py (line 591)
   ⚠️  Never called

🏗️ _handle_guidance_query
   📄 Core\AI\PyGenesisAssistant\Nova\core\engines\research_engine.py (line 617)
   ⚠️  Never called

🏗️ _handle_multi_part_guidance
   📄 Core\AI\PyGenesisAssistant\Nova\core\engines\research_engine.py (line 687)
   ⚠️  Never called

🏗️ _extract_guidance_topic
   📄 Core\AI\PyGenesisAssistant\Nova\core\engines\research_engine.py (line 765)
   ⚠️  Never called

🏗️ _generate_guidance
   📄 Core\AI\PyGenesisAssistant\Nova\core\engines\research_engine.py (line 805)
   ⚠️  Never called

🏗️ _handle_implementation_query
   📄 Core\AI\PyGenesisAssistant\Nova\core\engines\research_engine.py (line 938)
   ⚠️  Never called

🏗️ _research_topic
   📄 Core\AI\PyGenesisAssistant\Nova\core\engines\research_engine.py (line 1009)
   ⚠️  Never called

🏗️ _generate_example_code
   📄 Core\AI\PyGenesisAssistant\Nova\core\engines\research_engine.py (line 1034)
   ⚠️  Never called

🏗️ _analyze_project_for_topic
   📄 Core\AI\PyGenesisAssistant\Nova\core\engines\research_engine.py (line 1187)
   ⚠️  Never called

🏗️ _generate_project_improvements
   📄 Core\AI\PyGenesisAssistant\Nova\core\engines\research_engine.py (line 1305)
   ⚠️  Never called

🏗️ _get_allow_auto_followup
   📄 Core\AI\PyGenesisAssistant\Nova\core\engines\research_engine.py (line 1384)
   ⚠️  Never called

🏗️ _clean_extract
   📄 Core\AI\PyGenesisAssistant\Nova\core\engines\research_engine.py (line 1400)
   ⚠️  Never called

🏗️ add_light_source
   📄 Editors\ImageEditor\core\ui\atmospheric_lighting_helpers.py (line 35)
   ⚠️  Never called

🏗️ detect_light_sources
   📄 Editors\ImageEditor\core\ui\atmospheric_lighting_helpers.py (line 39)
   ⚠️  Never called

🏗️ create_light_source_highlight
   📄 Editors\ImageEditor\core\ui\atmospheric_lighting_helpers.py (line 61)
   ⚠️  Never called

🏗️ _detect_brightness_lights_simple
   📄 Editors\ImageEditor\core\ui\atmospheric_lighting_helpers.py (line 125)
   ⚠️  Never called

🏗️ _detect_edge_lights
   📄 Editors\ImageEditor\core\ui\atmospheric_lighting_helpers.py (line 201)
   ⚠️  Never called

🏗️ _detect_color_lights
   📄 Editors\ImageEditor\core\ui\atmospheric_lighting_helpers.py (line 225)
   ⚠️  Never called

🏗️ _detect_template_lights
   📄 Editors\ImageEditor\core\ui\atmospheric_lighting_helpers.py (line 270)
   ⚠️  Never called

🏗️ _merge_nearby_lights
   📄 Editors\ImageEditor\core\ui\atmospheric_lighting_helpers.py (line 280)
   ⚠️  Never called

🏗️ create_lighting_map
   📄 Editors\ImageEditor\core\ui\atmospheric_lighting_helpers.py (line 327)
   ⚠️  Never called

🏗️ _create_single_light_map
   📄 Editors\ImageEditor\core\ui\atmospheric_lighting_helpers.py (line 342)
   ⚠️  Never called

🏗️ create_shadow_map
   📄 Editors\ImageEditor\core\ui\atmospheric_lighting_helpers.py (line 381)
   ⚠️  Never called

🏗️ apply_atmospheric_effects
   📄 Editors\ImageEditor\core\ui\atmospheric_lighting_helpers.py (line 419)
   ⚠️  Never called

🏗️ apply_lighting_to_image
   📄 Editors\ImageEditor\core\ui\atmospheric_lighting_helpers.py (line 465)
   ⚠️  Never called

🏗️ _hex_to_rgb
   📄 Editors\ImageEditor\core\ui\atmospheric_lighting_helpers.py (line 523)
   ⚠️  Never called

🏗️ create_atmospheric_lighting_system
   📄 Editors\ImageEditor\core\ui\atmospheric_lighting_helpers.py (line 529)
   📞 Called by:
      • Editors\ImageEditor\core\ui\atmospheric_lighting_helpers.py (line 538)

🏗️ detect_light_sources_advanced
   📄 Editors\ImageEditor\core\ui\atmospheric_lighting_helpers.py (line 533)
   ⚠️  Never called

🏗️ _resource_file_changed
   📄 Core\Services\incremental_resource_reloader.py (line 97)
   ⚠️  Never called

🏗️ _load_resource_from_disk
   📄 Core\Services\incremental_resource_reloader.py (line 153)
   ⚠️  Never called

🏗️ get_all_command_names
   📄 Core\Code\PGSL\PGSL_Commands.py (line 348)
   📞 Called by:
      • Core\Code\Unified\unified_code_editor.py (line 420)

🏗️ get_manual_entries
   📄 Core\Code\PGSL\PGSL_Commands.py (line 353)
   ⚠️  Never called

🏗️ process_effect
   📄 Editors\ImageEditor\core\services\effect_processor.py (line 25)
   ⚠️  Never called

🏗️ _apply_invert_effect
   📄 Editors\ImageEditor\core\services\effect_processor.py (line 144)
   ⚠️  Never called

🏗️ _apply_greyscale_effect
   📄 Editors\ImageEditor\core\services\effect_processor.py (line 153)
   ⚠️  Never called

🏗️ _apply_brightness_effect
   📄 Editors\ImageEditor\core\services\effect_processor.py (line 161)
   ⚠️  Never called

🏗️ _apply_contrast_effect
   📄 Editors\ImageEditor\core\services\effect_processor.py (line 175)
   ⚠️  Never called

🏗️ _apply_vignette
   📄 Editors\ImageEditor\core\services\effect_processor.py (line 189)
   ⚠️  Never called

🏗️ _apply_saturation
   📄 Editors\ImageEditor\core\services\effect_processor.py (line 221)
   ⚠️  Never called

🏗️ _apply_posterize
   📄 Editors\ImageEditor\core\services\effect_processor.py (line 235)
   ⚠️  Never called

🏗️ _apply_emboss
   📄 Editors\ImageEditor\core\services\effect_processor.py (line 252)
   ⚠️  Never called

🏗️ _apply_edge_detection
   📄 Editors\ImageEditor\core\services\effect_processor.py (line 275)
   ⚠️  Never called

🏗️ _apply_colorize
   📄 Editors\ImageEditor\core\services\effect_processor.py (line 299)
   ⚠️  Never called

🏗️ _apply_fade_effect
   📄 Editors\ImageEditor\core\services\effect_processor.py (line 326)
   ⚠️  Never called

🏗️ _apply_opacity_effect
   📄 Editors\ImageEditor\core\services\effect_processor.py (line 347)
   ⚠️  Never called

🏗️ _apply_blur_effect
   📄 Editors\ImageEditor\core\services\effect_processor.py (line 357)
   ⚠️  Never called

🏗️ _apply_sharpen_effect
   📄 Editors\ImageEditor\core\services\effect_processor.py (line 375)
   ⚠️  Never called

🏗️ _apply_noise_effect
   📄 Editors\ImageEditor\core\services\effect_processor.py (line 393)
   ⚠️  Never called

🏗️ _apply_oil_painting
   📄 Editors\ImageEditor\core\services\effect_processor.py (line 433)
   ⚠️  Never called

🏗️ _apply_glow
   📄 Editors\ImageEditor\core\services\effect_processor.py (line 454)
   ⚠️  Never called

🏗️ _apply_solarize
   📄 Editors\ImageEditor\core\services\effect_processor.py (line 477)
   ⚠️  Never called

🏗️ _apply_image_enhancement
   📄 Editors\ImageEditor\core\services\effect_processor.py (line 496)
   ⚠️  Never called

🏗️ _apply_quality_enhancement
   📄 Editors\ImageEditor\core\services\effect_processor.py (line 503)
   ⚠️  Never called

🏗️ _apply_upscale
   📄 Editors\ImageEditor\core\services\effect_processor.py (line 574)
   ⚠️  Never called

🏗️ _apply_motion_blur
   📄 Editors\ImageEditor\core\services\effect_processor.py (line 622)
   ⚠️  Never called

🏗️ _apply_shader_bloom
   📄 Editors\ImageEditor\core\services\effect_processor.py (line 651)
   ⚠️  Never called

🏗️ _apply_palette_cycler
   📄 Editors\ImageEditor\core\services\effect_processor.py (line 702)
   ⚠️  Never called

🏗️ _apply_pixel_depth
   📄 Editors\ImageEditor\core\services\effect_processor.py (line 734)
   ⚠️  Never called

🏗️ _apply_hd_crisp
   📄 Editors\ImageEditor\core\services\effect_processor.py (line 768)
   ⚠️  Never called

🏗️ _apply_mirror_horizontal_effect
   📄 Editors\ImageEditor\core\services\effect_processor.py (line 850)
   ⚠️  Never called

🏗️ _apply_mirror_vertical_effect
   📄 Editors\ImageEditor\core\services\effect_processor.py (line 855)
   ⚠️  Never called

🏗️ _apply_rotate_90_effect
   📄 Editors\ImageEditor\core\services\effect_processor.py (line 860)
   ⚠️  Never called

🏗️ _apply_rotate_180_effect
   📄 Editors\ImageEditor\core\services\effect_processor.py (line 865)
   ⚠️  Never called

🏗️ _apply_rotate_custom_effect
   📄 Editors\ImageEditor\core\services\effect_processor.py (line 870)
   ⚠️  Never called

🏗️ _apply_dither_effect
   📄 Editors\ImageEditor\core\services\effect_processor.py (line 876)
   ⚠️  Never called

🏗️ _apply_pixelate_effect
   📄 Editors\ImageEditor\core\services\effect_processor.py (line 896)
   ⚠️  Never called

🏗️ _pixelate_blocks
   📄 Editors\ImageEditor\core\services\effect_processor.py (line 920)
   ⚠️  Never called

🏗️ _apply_map_generator_effect
   📄 Editors\ImageEditor\core\services\effect_processor.py (line 938)
   ⚠️  Never called

🏗️ _apply_texture_2d_effect
   📄 Editors\ImageEditor\core\services\effect_processor.py (line 944)
   ⚠️  Never called

🏗️ _apply_generate_lod_effect
   📄 Editors\ImageEditor\core\services\effect_processor.py (line 948)
   ⚠️  Never called

🏗️ _apply_atmospheric_lighting_effect
   📄 Editors\ImageEditor\core\services\effect_processor.py (line 952)
   ⚠️  Never called

🏗️ _apply_wind_waker_effect
   📄 Editors\ImageEditor\core\services\effect_processor.py (line 956)
   ⚠️  Never called

🏗️ _apply_ocarina_of_time_effect
   📄 Editors\ImageEditor\core\services\effect_processor.py (line 960)
   ⚠️  Never called

🏗️ _apply_luigis_mansion_effect
   📄 Editors\ImageEditor\core\services\effect_processor.py (line 964)
   ⚠️  Never called

🏗️ _apply_eternal_darkness_effect
   📄 Editors\ImageEditor\core\services\effect_processor.py (line 968)
   ⚠️  Never called

🏗️ _apply_pokemon_colosseum_effect
   📄 Editors\ImageEditor\core\services\effect_processor.py (line 972)
   ⚠️  Never called

🏗️ _apply_mario_kart_8_effect
   📄 Editors\ImageEditor\core\services\effect_processor.py (line 976)
   ⚠️  Never called

🏗️ close_project
   📄 Core\Services\project_service.py (line 110)
   📞 Called by:
      • Core\Services\project_service.py (line 120)

🏗️ _parse_call
   📄 Core\Code\PGSL\Parser.py (line 26)
   📞 Called by:
      • Core\Code\PGSL\Parser.py (line 89)

🏗️ _split_args
   📄 Core\Code\PGSL\Parser.py (line 44)
   📞 Called by:
      • Core\Code\PGSL\Parser.py (line 99)

🏗️ transpile_line
   📄 Core\Code\PGSL\Parser.py (line 70)
   📞 Called by:
      • Core\Code\PGSL\Parser.py (line 124)

🏗️ transpile
   📄 Core\Code\PGSL\Parser.py (line 118)
   📞 Called by:
      • Core\Code\PGSL\Parser.py (line 138)

🏗️ execute_pgsl
   📄 Core\Code\PGSL\Parser.py (line 129)
   📞 Called by:
      • Core\Code\PGSL\Parser.py (line 164)

🏗️ set_worker_thread
   📄 Editors\ImageEditor\core\ui\ai_dialogs.py (line 57)
   ⚠️  Never called

🏗️ on_thread_finished
   📄 Editors\ImageEditor\core\ui\ai_dialogs.py (line 64)
   ⚠️  Never called

🏗️ on_thread_error
   📄 Editors\ImageEditor\core\ui\ai_dialogs.py (line 72)
   ⚠️  Never called

🏗️ validate_json
   📄 Editors\ImageEditor\core\ui\ai_dialogs.py (line 297)
   ⚠️  Never called

🏗️ on_accept
   📄 Editors\ImageEditor\core\ui\ai_dialogs.py (line 309)
   ⚠️  Never called

🏗️ get_json_data
   📄 Editors\ImageEditor\core\ui\ai_dialogs.py (line 316)
   ⚠️  Never called

🏗️ set_base_image
   📄 Editors\ImageEditor\core\ui\ai_dialogs.py (line 334)
   ⚠️  Never called

🏗️ set_changes
   📄 Editors\ImageEditor\core\ui\ai_dialogs.py (line 339)
   ⚠️  Never called

🏗️ toggle_overlay
   📄 Editors\ImageEditor\core\ui\ai_dialogs.py (line 349)
   ⚠️  Never called

🏗️ get_specification
   📄 Editors\ImageEditor\core\ui\ai_dialogs.py (line 607)
   ⚠️  Never called

🏗️ add_chat_message
   📄 Editors\ImageEditor\core\ui\ai_dialogs.py (line 821)
   ⚠️  Never called

🏗️ send_message
   📄 Editors\ImageEditor\core\ui\ai_dialogs.py (line 838)
   ⚠️  Never called

🏗️ simulate_ai_response
   📄 Editors\ImageEditor\core\ui\ai_dialogs.py (line 861)
   ⚠️  Never called

🏗️ update_preview_frame
   📄 Editors\ImageEditor\core\ui\ai_dialogs.py (line 889)
   ⚠️  Never called

🏗️ toggle_frame_controls
   📄 Editors\ImageEditor\core\ui\ai_dialogs.py (line 916)
   ⚠️  Never called

🏗️ previous_frame
   📄 Editors\ImageEditor\core\ui\ai_dialogs.py (line 929)
   ⚠️  Never called

🏗️ pause_animation
   📄 Editors\ImageEditor\core\ui\ai_dialogs.py (line 957)
   ⚠️  Never called

🏗️ stop_animation
   📄 Editors\ImageEditor\core\ui\ai_dialogs.py (line 964)
   ⚠️  Never called

🏗️ apply_changes
   📄 Editors\ImageEditor\core\ui\ai_dialogs.py (line 980)
   ⚠️  Never called

🏗️ _display_function_workflow
   📄 Core\AI\PyGenesisAssistant\DependencyAnalyser.py (line 502)
   ⚠️  Never called

🏗️ export_workflow
   📄 Core\AI\PyGenesisAssistant\DependencyAnalyser.py (line 583)
   ⚠️  Never called

🏗️ _export_text
   📄 Core\AI\PyGenesisAssistant\DependencyAnalyser.py (line 605)
   ⚠️  Never called

🏗️ _export_json
   📄 Core\AI\PyGenesisAssistant\DependencyAnalyser.py (line 643)
   ⚠️  Never called

🏗️ _extract_from_ast
   📄 Core\AI\PyGenesisAssistant\DependencyAnalyser.py (line 753)
   ⚠️  Never called

🏗️ _is_method
   📄 Core\AI\PyGenesisAssistant\DependencyAnalyser.py (line 795)
   ⚠️  Never called

🏗️ _is_toplevel_assignment
   📄 Core\AI\PyGenesisAssistant\DependencyAnalyser.py (line 803)
   ⚠️  Never called

🏗️ _analyze_calls_and_imports
   📄 Core\AI\PyGenesisAssistant\DependencyAnalyser.py (line 813)
   ⚠️  Never called

🏗️ _analyze_ast_calls_imports
   📄 Core\AI\PyGenesisAssistant\DependencyAnalyser.py (line 828)
   ⚠️  Never called

🏗️ _update_original_preview
   📄 Editors\ImageEditor\core\ui\background_removal_dialog.py (line 101)
   ⚠️  Never called

🏗️ _update_result_preview
   📄 Editors\ImageEditor\core\ui\background_removal_dialog.py (line 113)
   ⚠️  Never called

🏗️ _load_deeplabv3
   📄 Editors\ImageEditor\core\ui\background_removal_dialog.py (line 230)
   ⚠️  Never called

🏗️ _remove_background_deeplabv3
   📄 Editors\ImageEditor\core\ui\background_removal_dialog.py (line 274)
   ⚠️  Never called

🏗️ _remove_background
   📄 Editors\ImageEditor\core\ui\background_removal_dialog.py (line 311)
   ⚠️  Never called

🏗️ _on_process
   📄 Editors\ImageEditor\core\ui\background_removal_dialog.py (line 325)
   ⚠️  Never called

🏗️ _on_accept
   📄 Editors\ImageEditor\core\ui\background_removal_dialog.py (line 337)
   ⚠️  Never called

🏗️ get_result
   📄 Editors\ImageEditor\core\ui\background_removal_dialog.py (line 343)
   ⚠️  Never called

🏗️ cancel
   📄 Core\AI\PyGenesisAssistant\Nova\core\async_scanner.py (line 51)
   ⚠️  Never called

🏗️ _setup_highlighting
   📄 Core\Code\Base\base_syntax_highlighter.py (line 70)
   ⚠️  Never called

🏗️ scan_file
   📄 Core\AI\PyGenesisAssistant\Nova\core\ast_scanner.py (line 66)
   📞 Called by:
      • Core\AI\PyGenesisAssistant\Nova\core\project_scanner.py (line 103)
      • Core\AI\PyGenesisAssistant\Nova\core\project_scanner.py (line 107)

🏗️ scan_directory
   📄 Core\AI\PyGenesisAssistant\Nova\core\ast_scanner.py (line 110)
   ⚠️  Never called

🏗️ get_project_structure
   📄 Core\AI\PyGenesisAssistant\Nova\core\ast_scanner.py (line 136)
   📞 Called by:
      • Core\AI\PyGenesisAssistant\Nova\core\project_scanner.py (line 47)

🏗️ visit_AsyncFunctionDef
   📄 Core\AI\PyGenesisAssistant\Nova\core\ast_scanner.py (line 254)
   ⚠️  Never called

🏗️ _add_function
   📄 Core\AI\PyGenesisAssistant\Nova\core\ast_scanner.py (line 259)
   ⚠️  Never called

🏗️ visit_Assign
   📄 Core\AI\PyGenesisAssistant\Nova\core\ast_scanner.py (line 312)
   ⚠️  Never called

🏗️ _get_decorator_name
   📄 Core\AI\PyGenesisAssistant\Nova\core\ast_scanner.py (line 320)
   ⚠️  Never called

🏗️ _get_attr_name
   📄 Core\AI\PyGenesisAssistant\Nova\core\ast_scanner.py (line 328)
   ⚠️  Never called

🏗️ _get_annotation_name
   📄 Core\AI\PyGenesisAssistant\Nova\core\ast_scanner.py (line 336)
   ⚠️  Never called

🏗️ analyze_context
   📄 Core\AI\PyGenesisAssistant\Nova\core\context_analyzer.py (line 29)
   📞 Called by:
      • Core\AI\PyGenesisAssistant\Nova\core\workflow.py (line 147)

🏗️ _find_math_reference
   📄 Core\AI\PyGenesisAssistant\Nova\core\context_analyzer.py (line 106)
   ⚠️  Never called

🏗️ _find_general_reference
   📄 Core\AI\PyGenesisAssistant\Nova\core\context_analyzer.py (line 194)
   ⚠️  Never called

🏗️ _find_follow_up
   📄 Core\AI\PyGenesisAssistant\Nova\core\context_analyzer.py (line 219)
   ⚠️  Never called

🏗️ enhance_query_with_context
   📄 Core\AI\PyGenesisAssistant\Nova\core\context_analyzer.py (line 237)
   📞 Called by:
      • Core\AI\PyGenesisAssistant\Nova\core\workflow.py (line 149)

🏗️ _register_executors
   📄 Core\AI\PyGenesisAssistant\NovaWidget.py (line 165)
   ⚠️  Never called

🏗️ _apply_nova_theme
   📄 Core\AI\PyGenesisAssistant\NovaWidget.py (line 193)
   ⚠️  Never called

🏗️ _seed_greeting
   📄 Core\AI\PyGenesisAssistant\NovaWidget.py (line 211)
   ⚠️  Never called

🏗️ _handle_send
   📄 Core\AI\PyGenesisAssistant\NovaWidget.py (line 223)
   ⚠️  Never called

🏗️ process_workflow
   📄 Core\AI\PyGenesisAssistant\NovaWidget.py (line 555)
   ⚠️  Never called

🏗️ _open_project_management
   📄 Core\AI\PyGenesisAssistant\NovaWidget.py (line 369)
   ⚠️  Never called

🏗️ _open_tasks
   📄 Core\AI\PyGenesisAssistant\NovaWidget.py (line 386)
   ⚠️  Never called

🏗️ _open_conversations
   📄 Core\AI\PyGenesisAssistant\NovaWidget.py (line 392)
   ⚠️  Never called

🏗️ _on_conversation_deleted
   📄 Core\AI\PyGenesisAssistant\NovaWidget.py (line 400)
   ⚠️  Never called

🏗️ _on_conversation_selected
   📄 Core\AI\PyGenesisAssistant\NovaWidget.py (line 420)
   ⚠️  Never called

🏗️ _open_nova_settings
   📄 Core\AI\PyGenesisAssistant\NovaWidget.py (line 451)
   ⚠️  Never called

🏗️ open_settings
   📄 Core\AI\PyGenesisAssistant\NovaWidget.py (line 455)
   ⚠️  Never called

🏗️ _on_preferences_changed
   📄 Core\AI\PyGenesisAssistant\NovaWidget.py (line 467)
   ⚠️  Never called

🏗️ open_in_new_window
   📄 Core\AI\PyGenesisAssistant\NovaWidget.py (line 473)
   ⚠️  Never called

🏗️ handle_send
   📄 Core\AI\PyGenesisAssistant\NovaWidget.py (line 550)
   ⚠️  Never called

🏗️ on_window_close
   📄 Core\AI\PyGenesisAssistant\NovaWidget.py (line 613)
   ⚠️  Never called

🏗️ _register_executors_for_workflow
   📄 Core\AI\PyGenesisAssistant\NovaWidget.py (line 621)
   ⚠️  Never called

🏗️ on_project_changed
   📄 Core\AI\PyGenesisAssistant\NovaWidget.py (line 649)
   ⚠️  Never called

🏗️ find_code_files
   📄 Core\AI\PyGenesisAssistant\Nova\core\codebase_analyzer.py (line 24)
   ⚠️  Never called

🏗️ analyze_codebase
   📄 Core\AI\PyGenesisAssistant\Nova\core\codebase_analyzer.py (line 42)
   📞 Called by:
      • Core\AI\PyGenesisAssistant\Nova\ui\project_management_dialog.py (line 35)

🏗️ analyze_dependencies
   📄 Core\AI\PyGenesisAssistant\Nova\core\codebase_analyzer.py (line 146)
   📞 Called by:
      • Core\AI\PyGenesisAssistant\Nova\ui\project_management_dialog.py (line 39)

🏗️ validate_operation
   📄 Core\AI\PyGenesisAssistant\Nova\core\api_manifest.py (line 498)
   📞 Called by:
      • Core\AI\PyGenesisAssistant\Nova\core\test_api_manifest.py (line 27)
      • Core\AI\PyGenesisAssistant\Nova\core\test_api_manifest.py (line 38)
      • Core\AI\PyGenesisAssistant\Nova\core\test_api_manifest.py (line 49)
      • Core\AI\PyGenesisAssistant\Nova\core\test_api_manifest.py (line 64)
      • Core\AI\PyGenesisAssistant\Nova\core\test_api_manifest.py (line 79)
      • Core\AI\PyGenesisAssistant\Nova\core\operation_planner.py (line 352)

🏗️ _validate_params
   📄 Core\AI\PyGenesisAssistant\Nova\core\api_manifest.py (line 436)
   ⚠️  Never called

🏗️ get_method_info
   📄 Core\AI\PyGenesisAssistant\Nova\core\api_manifest.py (line 461)
   ⚠️  Never called

🏗️ list_available_methods
   📄 Core\AI\PyGenesisAssistant\Nova\core\api_manifest.py (line 469)
   ⚠️  Never called

🏗️ get_resource_types
   📄 Core\AI\PyGenesisAssistant\Nova\core\api_manifest.py (line 477)
   ⚠️  Never called

🏗️ is_valid_resource_type
   📄 Core\AI\PyGenesisAssistant\Nova\core\api_manifest.py (line 481)
   ⚠️  Never called

🏗️ get_validator
   📄 Core\AI\PyGenesisAssistant\Nova\core\api_manifest.py (line 490)
   📞 Called by:
      • Core\AI\PyGenesisAssistant\Nova\core\workflow.py (line 549)
      • Core\AI\PyGenesisAssistant\Nova\core\test_api_manifest.py (line 85)
      • Core\AI\PyGenesisAssistant\Nova\core\api_manifest.py (line 518)
      • Core\AI\PyGenesisAssistant\Nova\core\operation_planner.py (line 68)

🏗️ classify
   📄 Core\AI\PyGenesisAssistant\Nova\core\intent_router.py (line 130)
   📞 Called by:
      • Core\AI\PyGenesisAssistant\Nova\core\workflow.py (line 272)
      • Core\AI\PyGenesisAssistant\NovaWidget.py (line 261)

🏗️ _handle_clarification_response
   📄 Core\AI\PyGenesisAssistant\Nova\core\intent_router.py (line 490)
   ⚠️  Never called

🏗️ _generate_clarification_question
   📄 Core\AI\PyGenesisAssistant\Nova\core\intent_router.py (line 540)
   ⚠️  Never called

🏗️ _generate_project_clarification_question
   📄 Core\AI\PyGenesisAssistant\Nova\core\intent_router.py (line 552)
   ⚠️  Never called

🏗️ _is_project_loaded
   📄 Core\AI\PyGenesisAssistant\Nova\core\intent_router.py (line 564)
   ⚠️  Never called

🏗️ extract_entity
   📄 Core\AI\PyGenesisAssistant\Nova\core\intent_router.py (line 597)
   📞 Called by:
      • Core\AI\PyGenesisAssistant\Nova\core\workflow.py (line 278)

🏗️ _is_project_specific_query
   📄 Core\AI\PyGenesisAssistant\Nova\core\intent_router.py (line 636)
   ⚠️  Never called

🏗️ _is_code_search_query
   📄 Core\AI\PyGenesisAssistant\Nova\core\intent_router.py (line 679)
   ⚠️  Never called

🏗️ _extract_potential_entity
   📄 Core\AI\PyGenesisAssistant\Nova\core\intent_router.py (line 711)
   ⚠️  Never called

🏗️ _entity_exists_in_project
   📄 Core\AI\PyGenesisAssistant\Nova\core\intent_router.py (line 734)
   ⚠️  Never called

🏗️ _quick_pattern_check
   📄 Core\AI\PyGenesisAssistant\Nova\core\intent_router.py (line 770)
   ⚠️  Never called

🏗️ _pattern_classify_with_confidence
   📄 Core\AI\PyGenesisAssistant\Nova\core\intent_router.py (line 868)
   ⚠️  Never called

🏗️ _apply_context_weighting
   📄 Core\AI\PyGenesisAssistant\Nova\core\intent_router.py (line 893)
   ⚠️  Never called

🏗️ _infer_from_context
   📄 Core\AI\PyGenesisAssistant\Nova\core\intent_router.py (line 945)
   ⚠️  Never called

🏗️ detect_user_mode
   📄 Core\AI\PyGenesisAssistant\Nova\core\intent_router.py (line 974)
   📞 Called by:
      • Core\AI\PyGenesisAssistant\Nova\core\workflow.py (line 209)
      • Core\AI\PyGenesisAssistant\Nova\core\workflow.py (line 283)

🏗️ _detect_operation
   📄 Core\AI\PyGenesisAssistant\Nova\core\executors\resource_operation_executor.py (line 113)
   ⚠️  Never called

🏗️ _extract_resource_info
   📄 Core\AI\PyGenesisAssistant\Nova\core\executors\resource_operation_executor.py (line 137)
   ⚠️  Never called

🏗️ _find_resource_by_name
   📄 Core\AI\PyGenesisAssistant\Nova\core\executors\resource_operation_executor.py (line 273)
   ⚠️  Never called

🏗️ _find_folder
   📄 Core\AI\PyGenesisAssistant\Nova\core\executors\resource_operation_executor.py (line 291)
   ⚠️  Never called

🏗️ _create_resource
   📄 Core\AI\PyGenesisAssistant\Nova\core\executors\resource_operation_executor.py (line 315)
   ⚠️  Never called

🏗️ _rename_resource
   📄 Core\AI\PyGenesisAssistant\Nova\core\executors\resource_operation_executor.py (line 363)
   ⚠️  Never called

🏗️ _delete_resource
   📄 Core\AI\PyGenesisAssistant\Nova\core\executors\resource_operation_executor.py (line 387)
   ⚠️  Never called

🏗️ _move_resource
   📄 Core\AI\PyGenesisAssistant\Nova\core\executors\resource_operation_executor.py (line 407)
   ⚠️  Never called

🏗️ _copy_resource
   📄 Core\AI\PyGenesisAssistant\Nova\core\executors\resource_operation_executor.py (line 437)
   ⚠️  Never called

🏗️ _edit_resource
   📄 Core\AI\PyGenesisAssistant\Nova\core\executors\resource_operation_executor.py (line 494)
   ⚠️  Never called

🏗️ _is_folder_operation
   📄 Core\AI\PyGenesisAssistant\Nova\core\executors\resource_operation_executor.py (line 518)
   ⚠️  Never called

🏗️ _extract_folder_info
   📄 Core\AI\PyGenesisAssistant\Nova\core\executors\resource_operation_executor.py (line 528)
   ⚠️  Never called

🏗️ _create_folder
   📄 Core\AI\PyGenesisAssistant\Nova\core\executors\resource_operation_executor.py (line 584)
   ⚠️  Never called

🏗️ _delete_folder
   📄 Core\AI\PyGenesisAssistant\Nova\core\executors\resource_operation_executor.py (line 622)
   ⚠️  Never called

🏗️ _rename_folder
   📄 Core\AI\PyGenesisAssistant\Nova\core\executors\resource_operation_executor.py (line 663)
   ⚠️  Never called

🏗️ get_object_file_path
   📄 Editors\ObjectEditor\Services\object_file_service.py (line 19)
   ⚠️  Never called

🏗️ get_event_file_path
   📄 Editors\ObjectEditor\Services\object_file_service.py (line 29)
   ⚠️  Never called

🏗️ load_object
   📄 Editors\ObjectEditor\Services\object_file_service.py (line 40)
   ⚠️  Never called

🏗️ save_object
   📄 Editors\ObjectEditor\Services\object_file_service.py (line 55)
   ⚠️  Never called

🏗️ load_event_code
   📄 Editors\ObjectEditor\Services\object_file_service.py (line 75)
   ⚠️  Never called

🏗️ save_event_code
   📄 Editors\ObjectEditor\Services\object_file_service.py (line 86)
   ⚠️  Never called

🏗️ validate_event_code
   📄 Editors\ObjectEditor\Services\object_validation_service.py (line 17)
   ⚠️  Never called

🏗️ validate_selected_code
   📄 Editors\ObjectEditor\Services\object_validation_service.py (line 26)
   ⚠️  Never called

🏗️ validate_all_events
   📄 Editors\ObjectEditor\Services\object_validation_service.py (line 33)
   ⚠️  Never called

🏗️ parse_code
   📄 Editors\ObjectEditor\Services\object_validation_service.py (line 59)
   ⚠️  Never called

🏗️ _on_fullscreen_toggle
   📄 Editors\ObjectEditor\UI\code_editor_widget.py (line 83)
   ⚠️  Never called

🏗️ set_maximized
   📄 Editors\ObjectEditor\UI\code_editor_widget.py (line 96)
   📞 Called by:
      • Editors\ObjectEditor\object_editor.py (line 987)
      • Editors\ObjectEditor\object_editor.py (line 995)
      • Editors\ObjectEditor\object_editor.py (line 1010)

🏗️ set_docked
   📄 Editors\ObjectEditor\UI\code_editor_widget.py (line 106)
   📞 Called by:
      • Editors\ObjectEditor\object_editor.py (line 1011)

🏗️ set_event_context
   📄 Editors\ObjectEditor\UI\code_editor_widget.py (line 121)
   📞 Called by:
      • Editors\ObjectEditor\object_editor.py (line 306)

🏗️ clear_event_context
   📄 Editors\ObjectEditor\UI\code_editor_widget.py (line 128)
   ⚠️  Never called

🏗️ validate_highlighted
   📄 Editors\ObjectEditor\UI\code_editor_widget.py (line 164)
   ⚠️  Never called

🏗️ validate_current_event
   📄 Editors\ObjectEditor\UI\code_editor_widget.py (line 168)
   ⚠️  Never called

🏗️ check_multiple_code_blocks
   📄 Editors\ObjectEditor\UI\code_editor_widget.py (line 176)
   📞 Called by:
      • Editors\ObjectEditor\object_editor.py (line 482)

🏗️ _extract_variables_from_code
   📄 Editors\ObjectEditor\UI\code_editor_widget.py (line 240)
   ⚠️  Never called

🏗️ _validate_code_string
   📄 Editors\ObjectEditor\UI\code_editor_widget.py (line 271)
   📞 Called by:
      • Editors\ObjectEditor\object_editor.py (line 439)

🏗️ validator
   📄 Editors\ObjectEditor\UI\code_editor_widget.py (line 290)
   ⚠️  Never called

🏗️ _create_menus
   📄 Editors\ObjectEditor\UI\object_editor_menu.py (line 24)
   ⚠️  Never called

🏗️ set_object_name
   📄 Editors\ObjectEditor\UI\parent_child_panel.py (line 57)
   ⚠️  Never called

🏗️ set_parent_list
   📄 Editors\ObjectEditor\UI\parent_child_panel.py (line 61)
   📞 Called by:
      • Editors\ObjectEditor\object_editor.py (line 1103)
      • Editors\ObjectEditor\object_editor.py (line 1106)

🏗️ set_children
   📄 Editors\ObjectEditor\UI\parent_child_panel.py (line 79)
   ⚠️  Never called

🏗️ _on_parent_changed
   📄 Editors\ObjectEditor\UI\parent_child_panel.py (line 87)
   ⚠️  Never called

🏗️ _on_child_clicked
   📄 Editors\ObjectEditor\UI\parent_child_panel.py (line 92)
   ⚠️  Never called

🏗️ set_events
   📄 Editors\ObjectEditor\UI\events_panel.py (line 156)
   📞 Called by:
      • Editors\ObjectEditor\object_editor.py (line 180)
      • Editors\ObjectEditor\object_editor.py (line 365)

🏗️ _get_collision_event_label
   📄 Editors\ObjectEditor\UI\events_panel.py (line 204)
   ⚠️  Never called

🏗️ select_event
   📄 Editors\ObjectEditor\UI\events_panel.py (line 224)
   📞 Called by:
      • Editors\ObjectEditor\object_editor.py (line 309)

🏗️ _show_add_event_dialog
   📄 Editors\ObjectEditor\UI\events_panel.py (line 242)
   ⚠️  Never called

🏗️ _show_collision_object_dialog
   📄 Editors\ObjectEditor\UI\events_panel.py (line 303)
   ⚠️  Never called

🏗️ _on_tree_item_clicked
   📄 Editors\ObjectEditor\UI\events_panel.py (line 329)
   ⚠️  Never called

🏗️ _on_tree_item_double_clicked
   📄 Editors\ObjectEditor\UI\events_panel.py (line 338)
   ⚠️  Never called

🏗️ _highlight_selected
   📄 Editors\ObjectEditor\UI\events_panel.py (line 344)
   ⚠️  Never called

🏗️ _populate_object_tree
   📄 Editors\ObjectEditor\UI\events_panel.py (line 400)
   ⚠️  Never called

🏗️ _on_object_clicked
   📄 Editors\ObjectEditor\UI\events_panel.py (line 461)
   ⚠️  Never called

🏗️ _on_object_selected
   📄 Editors\ObjectEditor\UI\events_panel.py (line 469)
   ⚠️  Never called

🏗️ _populate_sprite_tree
   📄 Editors\ObjectEditor\UI\properties_panel.py (line 75)
   ⚠️  Never called

🏗️ _set_sprite_icon
   📄 Editors\ObjectEditor\UI\properties_panel.py (line 133)
   ⚠️  Never called

🏗️ _on_sprite_clicked
   📄 Editors\ObjectEditor\UI\properties_panel.py (line 163)
   ⚠️  Never called

🏗️ _on_sprite_selected
   📄 Editors\ObjectEditor\UI\properties_panel.py (line 171)
   ⚠️  Never called

🏗️ _browse_sprite
   📄 Editors\ObjectEditor\UI\properties_panel.py (line 343)
   ⚠️  Never called

🏗️ _set_sprite
   📄 Editors\ObjectEditor\UI\properties_panel.py (line 362)
   📞 Called by:
      • Editors\ObjectEditor\object_editor.py (line 176)

🏗️ set_object_data
   📄 Editors\ObjectEditor\UI\properties_panel.py (line 445)
   📞 Called by:
      • Editors\ObjectEditor\object_editor.py (line 171)

🏗️ _on_name_changed
   📄 Editors\ObjectEditor\UI\properties_panel.py (line 514)
   ⚠️  Never called

🏗️ _on_name_enter_pressed
   📄 Editors\ObjectEditor\UI\properties_panel.py (line 519)
   ⚠️  Never called

🏗️ _on_solid_changed
   📄 Editors\ObjectEditor\UI\properties_panel.py (line 526)
   ⚠️  Never called

🏗️ _on_depth_changed
   📄 Editors\ObjectEditor\UI\properties_panel.py (line 531)
   ⚠️  Never called

🏗️ _on_persistent_changed
   📄 Editors\ObjectEditor\UI\properties_panel.py (line 536)
   ⚠️  Never called

🏗️ _on_test_code_clicked
   📄 Editors\ObjectEditor\UI\properties_panel.py (line 547)
   ⚠️  Never called

🏗️ format_time
   📄 Editors\SoundEditor\core\WaveForge.py (line 1046)
   ⚠️  Never called

🏗️ set_duration
   📄 Editors\SoundEditor\core\WaveForge.py (line 121)
   📞 Called by:
      • Editors\SoundEditor\core\WaveForge.py (line 706)

🏗️ set_position
   📄 Editors\SoundEditor\core\WaveForge.py (line 380)
   📞 Called by:
      • Editors\SoundEditor\core\WaveForge.py (line 1033)

🏗️ draw_waveform
   📄 Editors\SoundEditor\core\WaveForge.py (line 197)
   ⚠️  Never called

🏗️ draw_selection
   📄 Editors\SoundEditor\core\WaveForge.py (line 217)
   ⚠️  Never called

🏗️ draw_needle
   📄 Editors\SoundEditor\core\WaveForge.py (line 236)
   ⚠️  Never called

🏗️ contextMenuEvent
   📄 Editors\SoundEditor\core\WaveForge.py (line 296)
   ⚠️  Never called

🏗️ emit_cut
   📄 Editors\SoundEditor\core\WaveForge.py (line 329)
   ⚠️  Never called

🏗️ emit_copy
   📄 Editors\SoundEditor\core\WaveForge.py (line 334)
   ⚠️  Never called

🏗️ emit_paste
   📄 Editors\SoundEditor\core\WaveForge.py (line 339)
   ⚠️  Never called

🏗️ emit_delete
   📄 Editors\SoundEditor\core\WaveForge.py (line 343)
   ⚠️  Never called

🏗️ get_selection
   📄 Editors\SoundEditor\core\WaveForge.py (line 766)
   ⚠️  Never called

🏗️ update_waveform
   📄 Editors\SoundEditor\core\WaveForge.py (line 374)
   ⚠️  Never called

🏗️ setup_menus
   📄 Editors\SoundEditor\core\WaveForge.py (line 509)
   ⚠️  Never called

🏗️ setup_effects_menu
   📄 Editors\SoundEditor\core\WaveForge.py (line 581)
   ⚠️  Never called

🏗️ setup_effects_tab
   📄 Editors\SoundEditor\core\WaveForge.py (line 610)
   ⚠️  Never called

🏗️ setup_playback
   📄 Editors\SoundEditor\core\WaveForge.py (line 664)
   ⚠️  Never called

🏗️ add_track
   📄 Editors\SoundEditor\core\WaveForge.py (line 674)
   📞 Called by:
      • Editors\SoundEditor\SoundEditor.py (line 1049)
      • Editors\SoundEditor\SoundEditor.py (line 1090)
      • Editors\SoundEditor\SoundEditor.py (line 1125)
      • Editors\SoundEditor\SoundEditor.py (line 1163)
      • Editors\SoundEditor\SoundEditor.py (line 1169)

🏗️ generate_waveform
   📄 Editors\SoundEditor\core\WaveForge.py (line 708)
   ⚠️  Never called

🏗️ on_selection_changed
   📄 Editors\SoundEditor\core\WaveForge.py (line 747)
   ⚠️  Never called

🏗️ get_active_track
   📄 Editors\SoundEditor\core\WaveForge.py (line 753)
   ⚠️  Never called

🏗️ get_active_track_widget
   📄 Editors\SoundEditor\core\WaveForge.py (line 759)
   ⚠️  Never called

🏗️ apply_fade_in
   📄 Editors\SoundEditor\core\WaveForge.py (line 857)
   ⚠️  Never called

🏗️ apply_fade_out
   📄 Editors\SoundEditor\core\WaveForge.py (line 879)
   ⚠️  Never called

🏗️ apply_normalize
   📄 Editors\SoundEditor\core\WaveForge.py (line 901)
   ⚠️  Never called

🏗️ show_amplify_dialog
   📄 Editors\SoundEditor\core\WaveForge.py (line 911)
   ⚠️  Never called

🏗️ apply_amplify
   📄 Editors\SoundEditor\core\WaveForge.py (line 934)
   ⚠️  Never called

🏗️ apply_reverse
   📄 Editors\SoundEditor\core\WaveForge.py (line 944)
   ⚠️  Never called

🏗️ resume_playback
   📄 Editors\SoundEditor\core\WaveForge.py (line 1001)
   ⚠️  Never called

🏗️ update_playback_position
   📄 Editors\SoundEditor\core\WaveForge.py (line 1018)
   ⚠️  Never called

🏗️ update_display
   📄 Editors\SoundEditor\core\WaveForge.py (line 1030)
   ⚠️  Never called

🏗️ on_zoom_changed
   📄 Editors\SoundEditor\core\WaveForge.py (line 1053)
   ⚠️  Never called

🏗️ open_file
   📄 Editors\SoundEditor\core\WaveForge.py (line 1059)
   ⚠️  Never called

🏗️ import_audio
   📄 Editors\SoundEditor\core\WaveForge.py (line 1073)
   ⚠️  Never called

🏗️ load_audio_file
   📄 Editors\SoundEditor\core\WaveForge.py (line 1092)
   📞 Called by:
      • Editors\SoundEditor\SoundEditor.py (line 2578)

🏗️ save_file
   📄 Editors\SoundEditor\core\WaveForge.py (line 1159)
   ⚠️  Never called

🏗️ save_as_file
   📄 Editors\SoundEditor\core\WaveForge.py (line 1164)
   ⚠️  Never called

🏗️ undo_action
   📄 Editors\SoundEditor\core\WaveForge.py (line 1190)
   ⚠️  Never called

🏗️ redo_action
   📄 Editors\SoundEditor\core\WaveForge.py (line 1195)
   ⚠️  Never called

🏗️ create_image_editor_menu
   📄 Editors\Shared\IntegratedImageEditor.py (line 65)
   ⚠️  Never called

🏗️ save_selection_to_memory
   📄 Editors\Shared\IntegratedImageEditor.py (line 317)
   📞 Called by:
      • Editors\Shared\IntegratedImageEditor.py (line 321)

🏗️ insert_memory_from_collections
   📄 Editors\Shared\IntegratedImageEditor.py (line 327)
   ⚠️  Never called

🏗️ sync_effects_menu_from_image_editor
   📄 Editors\Shared\IntegratedImageEditor.py (line 337)
   ⚠️  Never called

🏗️ sync_edit_menu_from_image_editor
   📄 Editors\Shared\IntegratedImageEditor.py (line 371)
   ⚠️  Never called

🏗️ _build_menu_from_data
   📄 Editors\Shared\IntegratedImageEditor.py (line 412)
   ⚠️  Never called

🏗️ _call_image_editor_method
   📄 Editors\Shared\IntegratedImageEditor.py (line 464)
   ⚠️  Never called

🏗️ create_toolbar
   📄 Editors\Shared\IntegratedImageEditor.py (line 491)
   ⚠️  Never called

🏗️ initialize_editor
   📄 Editors\Shared\IntegratedImageEditor.py (line 532)
   ⚠️  Never called

🏗️ create_image_editor_async
   📄 Editors\Shared\IntegratedImageEditor.py (line 539)
   ⚠️  Never called

🏗️ sync_menus
   📄 Editors\Shared\IntegratedImageEditor.py (line 568)
   ⚠️  Never called

🏗️ _get_resource_name
   📄 Editors\Shared\IntegratedImageEditor.py (line 617)
   ⚠️  Never called

🏗️ _get_resource_folder
   📄 Editors\Shared\IntegratedImageEditor.py (line 626)
   ⚠️  Never called

🏗️ load_sprite_data
   📄 Editors\Shared\IntegratedImageEditor.py (line 635)
   ⚠️  Never called

🏗️ force_canvas_refresh
   📄 Editors\Shared\IntegratedImageEditor.py (line 822)
   ⚠️  Never called

🏗️ import_image
   📄 Editors\Shared\IntegratedImageEditor.py (line 839)
   📞 Called by:
      • Editors\Shared\IntegratedImageEditor.py (line 845)

🏗️ import_gif
   📄 Editors\Shared\IntegratedImageEditor.py (line 847)
   📞 Called by:
      • Editors\Shared\IntegratedImageEditor.py (line 853)

🏗️ save_sprite
   📄 Editors\Shared\IntegratedImageEditor.py (line 863)
   ⚠️  Never called

🏗️ get_sprite_data
   📄 Editors\Shared\IntegratedImageEditor.py (line 875)
   ⚠️  Never called

🏗️ get_updated_sprite_data
   📄 Editors\Shared\IntegratedImageEditor.py (line 909)
   📞 Called by:
      • Editors\TextureEditor\TextureEditor.py (line 595)
      • Editors\SpriteEditor\SpriteEditor.py (line 809)

🏗️ cancel_editing
   📄 Editors\Shared\IntegratedImageEditor.py (line 1040)
   ⚠️  Never called

🏗️ new_sprite
   📄 Editors\Shared\IntegratedImageEditor.py (line 1051)
   ⚠️  Never called

🏗️ open_sprite
   📄 Editors\Shared\IntegratedImageEditor.py (line 1099)
   ⚠️  Never called

🏗️ open_image
   📄 Editors\Shared\IntegratedImageEditor.py (line 1104)
   ⚠️  Never called

🏗️ open_gif
   📄 Editors\Shared\IntegratedImageEditor.py (line 1109)
   ⚠️  Never called

🏗️ save_as_sprite
   📄 Editors\Shared\IntegratedImageEditor.py (line 1155)
   ⚠️  Never called

🏗️ save_as_image
   📄 Editors\Shared\IntegratedImageEditor.py (line 1163)
   ⚠️  Never called

🏗️ save_as_gif
   📄 Editors\Shared\IntegratedImageEditor.py (line 1171)
   ⚠️  Never called

🏗️ cut_action
   📄 Editors\Shared\IntegratedImageEditor.py (line 1189)
   ⚠️  Never called

🏗️ copy_action
   📄 Editors\Shared\IntegratedImageEditor.py (line 1194)
   ⚠️  Never called

🏗️ paste_action
   📄 Editors\Shared\IntegratedImageEditor.py (line 1199)
   ⚠️  Never called

🏗️ delete_action
   📄 Editors\Shared\IntegratedImageEditor.py (line 1204)
   ⚠️  Never called

🏗️ remove_blank_space_action
   📄 Editors\Shared\IntegratedImageEditor.py (line 1216)
   ⚠️  Never called

🏗️ resize_selection_action
   📄 Editors\Shared\IntegratedImageEditor.py (line 1222)
   ⚠️  Never called

🏗️ select_all_action
   📄 Editors\Shared\IntegratedImageEditor.py (line 1228)
   ⚠️  Never called

🏗️ clear_selection_action
   📄 Editors\Shared\IntegratedImageEditor.py (line 1234)
   ⚠️  Never called

🏗️ duplicate_frame_action
   📄 Editors\Shared\IntegratedImageEditor.py (line 1240)
   ⚠️  Never called

🏗️ clear_frame_action
   📄 Editors\Shared\IntegratedImageEditor.py (line 1246)
   ⚠️  Never called

🏗️ zoom_in_action
   📄 Editors\Shared\IntegratedImageEditor.py (line 1252)
   ⚠️  Never called

🏗️ zoom_out_action
   📄 Editors\Shared\IntegratedImageEditor.py (line 1258)
   ⚠️  Never called

🏗️ zoom_reset_action
   📄 Editors\Shared\IntegratedImageEditor.py (line 1264)
   ⚠️  Never called

🏗️ toggle_grid_action
   📄 Editors\Shared\IntegratedImageEditor.py (line 1270)
   ⚠️  Never called

🏗️ toggle_snap_to_grid_action
   📄 Editors\Shared\IntegratedImageEditor.py (line 1276)
   ⚠️  Never called

🏗️ ai_generate_base_sprite
   📄 Editors\Shared\IntegratedImageEditor.py (line 1284)
   📞 Called by:
      • Editors\Shared\IntegratedImageEditor.py (line 1288)

🏗️ ai_generate_animation
   📄 Editors\Shared\IntegratedImageEditor.py (line 1294)
   📞 Called by:
      • Editors\Shared\IntegratedImageEditor.py (line 1298)

🏗️ ai_generate_texture_pack
   📄 Editors\Shared\IntegratedImageEditor.py (line 1304)
   📞 Called by:
      • Editors\Shared\IntegratedImageEditor.py (line 1308)

🏗️ ai_detect_skeleton
   📄 Editors\Shared\IntegratedImageEditor.py (line 1314)
   📞 Called by:
      • Editors\Shared\IntegratedImageEditor.py (line 1318)

🏗️ ai_analyze_sprite
   📄 Editors\Shared\IntegratedImageEditor.py (line 1324)
   📞 Called by:
      • Editors\Shared\IntegratedImageEditor.py (line 1328)

🏗️ ai_upscale
   📄 Editors\Shared\IntegratedImageEditor.py (line 1334)
   📞 Called by:
      • Editors\Shared\IntegratedImageEditor.py (line 1338)

🏗️ ai_background_removal
   📄 Editors\Shared\IntegratedImageEditor.py (line 1344)
   📞 Called by:
      • Editors\Shared\IntegratedImageEditor.py (line 1348)

🏗️ ai_image_to_3d
   📄 Editors\Shared\IntegratedImageEditor.py (line 1354)
   📞 Called by:
      • Editors\Shared\IntegratedImageEditor.py (line 1358)

🏗️ ai_sprite_to_3d
   📄 Editors\Shared\IntegratedImageEditor.py (line 1364)
   📞 Called by:
      • Editors\Shared\IntegratedImageEditor.py (line 1368)

🏗️ sync_grid_states
   📄 Editors\Shared\IntegratedImageEditor.py (line 1374)
   ⚠️  Never called

🏗️ invert_colors
   📄 Editors\Shared\IntegratedImageEditor.py (line 1392)
   ⚠️  Never called

🏗️ apply_theme
   📄 Editors\Shared\IntegratedImageEditor.py (line 1397)
   📞 Called by:
      • UI\MainWindow\MainWindow.py (line 1727)

🏗️ blur_effect
   📄 Editors\Shared\IntegratedImageEditor.py (line 1410)
   ⚠️  Never called

🏗️ sharpen_effect
   📄 Editors\Shared\IntegratedImageEditor.py (line 1415)
   ⚠️  Never called

🏗️ show_preferences
   📄 Editors\Shared\IntegratedImageEditor.py (line 1420)
   ⚠️  Never called

🏗️ effect_invert
   📄 Editors\Shared\IntegratedImageEditor.py (line 1426)
   📞 Called by:
      • Editors\Shared\IntegratedImageEditor.py (line 1428)

🏗️ effect_brightness
   📄 Editors\Shared\IntegratedImageEditor.py (line 1430)
   📞 Called by:
      • Editors\Shared\IntegratedImageEditor.py (line 1432)

🏗️ effect_contrast
   📄 Editors\Shared\IntegratedImageEditor.py (line 1434)
   📞 Called by:
      • Editors\Shared\IntegratedImageEditor.py (line 1436)

🏗️ effect_greyscale
   📄 Editors\Shared\IntegratedImageEditor.py (line 1438)
   📞 Called by:
      • Editors\Shared\IntegratedImageEditor.py (line 1440)

🏗️ effect_fade
   📄 Editors\Shared\IntegratedImageEditor.py (line 1442)
   📞 Called by:
      • Editors\Shared\IntegratedImageEditor.py (line 1444)

🏗️ effect_opacity
   📄 Editors\Shared\IntegratedImageEditor.py (line 1446)
   📞 Called by:
      • Editors\Shared\IntegratedImageEditor.py (line 1448)

🏗️ effect_blur
   📄 Editors\Shared\IntegratedImageEditor.py (line 1450)
   📞 Called by:
      • Editors\Shared\IntegratedImageEditor.py (line 1452)

🏗️ effect_sharpen
   📄 Editors\Shared\IntegratedImageEditor.py (line 1454)
   📞 Called by:
      • Editors\Shared\IntegratedImageEditor.py (line 1456)

🏗️ effect_noise
   📄 Editors\Shared\IntegratedImageEditor.py (line 1458)
   📞 Called by:
      • Editors\Shared\IntegratedImageEditor.py (line 1460)

🏗️ effect_pixelate
   📄 Editors\Shared\IntegratedImageEditor.py (line 1462)
   📞 Called by:
      • Editors\Shared\IntegratedImageEditor.py (line 1464)

🏗️ effect_dither
   📄 Editors\Shared\IntegratedImageEditor.py (line 1466)
   📞 Called by:
      • Editors\Shared\IntegratedImageEditor.py (line 1468)

🏗️ effect_vignette
   📄 Editors\Shared\IntegratedImageEditor.py (line 1470)
   📞 Called by:
      • Editors\Shared\IntegratedImageEditor.py (line 1477)

🏗️ effect_saturation
   📄 Editors\Shared\IntegratedImageEditor.py (line 1483)
   📞 Called by:
      • Editors\Shared\IntegratedImageEditor.py (line 1485)

🏗️ effect_posterize
   📄 Editors\Shared\IntegratedImageEditor.py (line 1487)
   📞 Called by:
      • Editors\Shared\IntegratedImageEditor.py (line 1489)

🏗️ effect_emboss
   📄 Editors\Shared\IntegratedImageEditor.py (line 1491)
   📞 Called by:
      • Editors\Shared\IntegratedImageEditor.py (line 1493)

🏗️ effect_edge_detection
   📄 Editors\Shared\IntegratedImageEditor.py (line 1495)
   📞 Called by:
      • Editors\Shared\IntegratedImageEditor.py (line 1497)

🏗️ effect_colorize
   📄 Editors\Shared\IntegratedImageEditor.py (line 1499)
   📞 Called by:
      • Editors\Shared\IntegratedImageEditor.py (line 1501)

🏗️ effect_oil_painting
   📄 Editors\Shared\IntegratedImageEditor.py (line 1503)
   📞 Called by:
      • Editors\Shared\IntegratedImageEditor.py (line 1505)

🏗️ effect_glow
   📄 Editors\Shared\IntegratedImageEditor.py (line 1507)
   📞 Called by:
      • Editors\Shared\IntegratedImageEditor.py (line 1509)

🏗️ effect_solarize
   📄 Editors\Shared\IntegratedImageEditor.py (line 1511)
   📞 Called by:
      • Editors\Shared\IntegratedImageEditor.py (line 1513)

🏗️ effect_upscale
   📄 Editors\Shared\IntegratedImageEditor.py (line 1515)
   📞 Called by:
      • Editors\Shared\IntegratedImageEditor.py (line 1517)

🏗️ effect_motion_blur
   📄 Editors\Shared\IntegratedImageEditor.py (line 1519)
   📞 Called by:
      • Editors\Shared\IntegratedImageEditor.py (line 1521)

🏗️ effect_shader_bloom
   📄 Editors\Shared\IntegratedImageEditor.py (line 1523)
   📞 Called by:
      • Editors\Shared\IntegratedImageEditor.py (line 1525)

🏗️ effect_palette_cycler
   📄 Editors\Shared\IntegratedImageEditor.py (line 1527)
   📞 Called by:
      • Editors\Shared\IntegratedImageEditor.py (line 1529)

🏗️ effect_pixel_depth
   📄 Editors\Shared\IntegratedImageEditor.py (line 1531)
   📞 Called by:
      • Editors\Shared\IntegratedImageEditor.py (line 1533)

🏗️ effect_hd_crisp
   📄 Editors\Shared\IntegratedImageEditor.py (line 1535)
   📞 Called by:
      • Editors\Shared\IntegratedImageEditor.py (line 1537)

🏗️ effect_voxelize
   📄 Editors\Shared\IntegratedImageEditor.py (line 1540)
   📞 Called by:
      • Editors\Shared\IntegratedImageEditor.py (line 1542)

🏗️ effect_dream_diffuse
   📄 Editors\Shared\IntegratedImageEditor.py (line 1544)
   📞 Called by:
      • Editors\Shared\IntegratedImageEditor.py (line 1546)

🏗️ effect_vhs
   📄 Editors\Shared\IntegratedImageEditor.py (line 1548)
   📞 Called by:
      • Editors\Shared\IntegratedImageEditor.py (line 1550)

🏗️ effect_posterizer
   📄 Editors\Shared\IntegratedImageEditor.py (line 1552)
   📞 Called by:
      • Editors\Shared\IntegratedImageEditor.py (line 1554)

🏗️ effect_normal_map
   📄 Editors\Shared\IntegratedImageEditor.py (line 1557)
   📞 Called by:
      • Editors\Shared\IntegratedImageEditor.py (line 1559)

🏗️ effect_light_overlay
   📄 Editors\Shared\IntegratedImageEditor.py (line 1561)
   📞 Called by:
      • Editors\Shared\IntegratedImageEditor.py (line 1563)

🏗️ effect_mirror_horizontal
   📄 Editors\Shared\IntegratedImageEditor.py (line 1565)
   📞 Called by:
      • Editors\Shared\IntegratedImageEditor.py (line 1567)

🏗️ effect_mirror_vertical
   📄 Editors\Shared\IntegratedImageEditor.py (line 1569)
   📞 Called by:
      • Editors\Shared\IntegratedImageEditor.py (line 1571)

🏗️ effect_rotate_90
   📄 Editors\Shared\IntegratedImageEditor.py (line 1573)
   📞 Called by:
      • Editors\Shared\IntegratedImageEditor.py (line 1575)

🏗️ effect_rotate_180
   📄 Editors\Shared\IntegratedImageEditor.py (line 1577)
   📞 Called by:
      • Editors\Shared\IntegratedImageEditor.py (line 1579)

🏗️ effect_rotate_custom
   📄 Editors\Shared\IntegratedImageEditor.py (line 1581)
   📞 Called by:
      • Editors\Shared\IntegratedImageEditor.py (line 1583)

🏗️ effect_map_generator
   📄 Editors\Shared\IntegratedImageEditor.py (line 1585)
   📞 Called by:
      • Editors\Shared\IntegratedImageEditor.py (line 1587)

🏗️ effect_texture_2d
   📄 Editors\Shared\IntegratedImageEditor.py (line 1589)
   📞 Called by:
      • Editors\Shared\IntegratedImageEditor.py (line 1591)

🏗️ nine_slice_import
   📄 Editors\Shared\IntegratedImageEditor.py (line 1593)
   📞 Called by:
      • Editors\Shared\IntegratedImageEditor.py (line 1598)

🏗️ effect_generate_lod
   📄 Editors\Shared\IntegratedImageEditor.py (line 1605)
   📞 Called by:
      • Editors\Shared\IntegratedImageEditor.py (line 1607)

🏗️ effect_advanced_atlas
   📄 Editors\Shared\IntegratedImageEditor.py (line 1609)
   ⚠️  Never called

🏗️ effect_character_creation
   📄 Editors\Shared\IntegratedImageEditor.py (line 1613)
   ⚠️  Never called

🏗️ toggle_timeline
   📄 Editors\Shared\IntegratedImageEditor.py (line 1617)
   📞 Called by:
      • Editors\ImageEditor\core\ui\panels\right_panel.py (line 877)
      • Editors\Shared\IntegratedImageEditor.py (line 1621)

🏗️ toggle_fullscreen
   📄 Editors\Shared\IntegratedImageEditor.py (line 1623)
   📞 Called by:
      • Editors\ModelEditor\ModelEditor.py (line 10531)

🏗️ enter_fullscreen
   📄 Editors\Shared\IntegratedImageEditor.py (line 1630)
   ⚠️  Never called

🏗️ exit_fullscreen
   📄 Editors\Shared\IntegratedImageEditor.py (line 1668)
   ⚠️  Never called

🏗️ _restore_image_editor_tab
   📄 Editors\Shared\IntegratedImageEditor.py (line 1713)
   ⚠️  Never called

🏗️ fullscreen_close_event
   📄 Editors\Shared\IntegratedImageEditor.py (line 1750)
   ⚠️  Never called

🏗️ load_sprite_from_files
   📄 Editors\SpriteEditor\SpriteEditor.py (line 591)
   ⚠️  Never called

🏗️ load_resource_data
   📄 Editors\SpriteEditor\SpriteEditor.py (line 257)
   📞 Called by:
      • Editors\TextureEditor\TextureEditor.py (line 79)
      • Editors\SpriteEditor\SpriteEditor.py (line 260)

🏗️ _load_sprite_data_deferred
   📄 Editors\SpriteEditor\SpriteEditor.py (line 267)
   ⚠️  Never called

🏗️ on_tab_close_requested
   📄 Editors\SpriteEditor\SpriteEditor.py (line 290)
   ⚠️  Never called

🏗️ update_editor_tab_title
   📄 Editors\SpriteEditor\SpriteEditor.py (line 299)
   ⚠️  Never called

🏗️ on_sprite_saved
   📄 Editors\SpriteEditor\SpriteEditor.py (line 420)
   ⚠️  Never called

🏗️ refresh_preview
   📄 Editors\SpriteEditor\SpriteEditor.py (line 507)
   ⚠️  Never called

🏗️ has_existing_sprite_data
   📄 Editors\SpriteEditor\SpriteEditor.py (line 563)
   ⚠️  Never called

🏗️ load_sprite_files
   📄 Editors\SpriteEditor\SpriteEditor.py (line 581)
   ⚠️  Never called

🏗️ open_sprite_settings
   📄 Editors\SpriteEditor\SpriteEditor.py (line 769)
   ⚠️  Never called

🏗️ update_scale_mode_display
   📄 Editors\SpriteEditor\SpriteEditor.py (line 777)
   ⚠️  Never called

🏗️ update_sprite_dimensions
   📄 Editors\SpriteEditor\SpriteEditor.py (line 785)
   ⚠️  Never called

🏗️ update_project_data
   📄 Editors\SpriteEditor\SpriteEditor.py (line 859)
   ⚠️  Never called

🏗️ release_file_handles
   📄 Editors\SpriteEditor\SpriteEditor.py (line 870)
   ⚠️  Never called

🏗️ delete_sprite_files
   📄 Editors\SpriteEditor\SpriteEditor.py (line 876)
   ⚠️  Never called

🏗️ rename_sprite_files
   📄 Editors\SpriteEditor\SpriteEditor.py (line 906)
   ⚠️  Never called

🏗️ update_sprite_name
   📄 Editors\SpriteEditor\SpriteEditor.py (line 960)
   ⚠️  Never called

🏗️ draw_grid
   📄 Editors\SpriteEditor\SpriteEditor.py (line 1000)
   ⚠️  Never called

🏗️ draw_sprite
   📄 Editors\SpriteEditor\SpriteEditor.py (line 1014)
   ⚠️  Never called

🏗️ draw_placeholder
   📄 Editors\SpriteEditor\SpriteEditor.py (line 1085)
   ⚠️  Never called

🏗️ _get_sprite_coords_from_screen
   📄 Editors\SpriteEditor\SpriteEditor.py (line 1148)
   ⚠️  Never called

🏗️ create_origin_tab
   📄 Editors\SpriteEditor\SpriteEditor.py (line 1272)
   ⚠️  Never called

🏗️ create_collision_tab
   📄 Editors\SpriteEditor\SpriteEditor.py (line 1314)
   ⚠️  Never called

🏗️ load_settings
   📄 Editors\SpriteEditor\SpriteEditor.py (line 1374)
   ⚠️  Never called

🏗️ set_quick_origin
   📄 Editors\SpriteEditor\SpriteEditor.py (line 1400)
   ⚠️  Never called

🏗️ on_collision_type_changed
   📄 Editors\SpriteEditor\SpriteEditor.py (line 1422)
   ⚠️  Never called

🏗️ get_settings
   📄 Editors\SpriteEditor\SpriteEditor.py (line 1427)
   ⚠️  Never called

🏗️ update_modified
   📄 Editors\ObjectEditor\Core\object_model.py (line 68)
   ⚠️  Never called

🏗️ _build_ui_complete
   📄 Editors\Shared\BaseImageResourceEditor.py (line 80)
   ⚠️  Never called

🏗️ create_home_tab
   📄 Editors\Shared\BaseImageResourceEditor.py (line 112)
   ⚠️  Never called

🏗️ create_properties_panel
   📄 Editors\Shared\BaseImageResourceEditor.py (line 131)
   ⚠️  Never called

🏗️ on_frame_changed
   📄 Editors\Shared\BaseImageResourceEditor.py (line 498)
   ⚠️  Never called

🏗️ on_origin_changed
   📄 Editors\Shared\BaseImageResourceEditor.py (line 504)
   ⚠️  Never called

🏗️ center_origin
   📄 Editors\Shared\BaseImageResourceEditor.py (line 513)
   ⚠️  Never called

🏗️ set_origin_preset
   📄 Editors\Shared\BaseImageResourceEditor.py (line 520)
   ⚠️  Never called

🏗️ on_set_origin_mode_toggled
   📄 Editors\Shared\BaseImageResourceEditor.py (line 525)
   ⚠️  Never called

🏗️ on_collision_changed
   📄 Editors\Shared\BaseImageResourceEditor.py (line 531)
   ⚠️  Never called

🏗️ on_bbox_changed
   📄 Editors\Shared\BaseImageResourceEditor.py (line 538)
   ⚠️  Never called

🏗️ on_edit_bbox_mode_toggled
   📄 Editors\Shared\BaseImageResourceEditor.py (line 551)
   ⚠️  Never called

🏗️ modify_collision_mask
   📄 Editors\Shared\BaseImageResourceEditor.py (line 557)
   ⚠️  Never called

🏗️ on_texture_changed
   📄 Editors\Shared\BaseImageResourceEditor.py (line 561)
   ⚠️  Never called

🏗️ on_speed_changed
   📄 Editors\Shared\BaseImageResourceEditor.py (line 579)
   ⚠️  Never called

🏗️ toggle_scale_mode
   📄 Editors\Shared\BaseImageResourceEditor.py (line 590)
   ⚠️  Never called

🏗️ on_animation_changed
   📄 Editors\Shared\BaseImageResourceEditor.py (line 698)
   ⚠️  Never called

🏗️ _update_animation_frames
   📄 Editors\Shared\BaseImageResourceEditor.py (line 718)
   ⚠️  Never called

🏗️ update_frame_display
   📄 Editors\Shared\BaseImageResourceEditor.py (line 746)
   ⚠️  Never called

🏗️ _update_animation_combo
   📄 Editors\Shared\BaseImageResourceEditor.py (line 762)
   ⚠️  Never called

🏗️ on_resource_updated
   📄 Editors\Shared\BaseImageResourceEditor.py (line 946)
   ⚠️  Never called

🏗️ on_resource_deleted
   📄 Editors\Shared\BaseImageResourceEditor.py (line 952)
   ⚠️  Never called

🏗️ is_text_file
   📄 GenerateSummary.py (line 40)
   📞 Called by:
      • GenerateSummary.py (line 161)

🏗️ get_python_docstring
   📄 GenerateSummary.py (line 56)
   📞 Called by:
      • GenerateSummary.py (line 213)

🏗️ get_first_comment_or_line
   📄 GenerateSummary.py (line 69)
   📞 Called by:
      • GenerateSummary.py (line 223)
      • GenerateSummary.py (line 237)

🏗️ build_tree
   📄 GenerateSummary.py (line 88)
   📞 Called by:
      • GenerateSummary.py (line 197)

🏗️ walk
   📄 GenerateSummary.py (line 94)
   📞 Called by:
      • GenerateSummary.py (line 115)
      • GenerateSummary.py (line 126)

🏗️ summarize_project
   📄 GenerateSummary.py (line 130)
   📞 Called by:
      • GenerateSummary.py (line 289)
      • UI\CommonDialogs\PreferencesDialog.py (line 1653)
      • UI\CommonDialogs\PreferencesDialog.py (line 1697)

🏗️ setup_python_environment
   📄 main.py (line 20)
   📞 Called by:
      • main.py (line 468)

🏗️ _basic_dependency_check
   📄 main.py (line 104)
   📞 Called by:
      • main.py (line 217)

🏗️ on_finished
   📄 main.py (line 352)
   ⚠️  Never called

🏗️ _cleanup_pycache
   📄 main.py (line 567)
   ⚠️  Never called

🏗️ __lt__
   📄 Tools\BackupManager\BackupManager.py (line 27)
   ⚠️  Never called

🏗️ _log
   📄 Tools\BackupManager\BackupManager.py (line 52)
   ⚠️  Never called

🏗️ get_backup_destination
   📄 Tools\BackupManager\BackupManager.py (line 56)
   ⚠️  Never called

🏗️ set_folder_filters
   📄 Tools\BackupManager\BackupManager.py (line 133)
   ⚠️  Never called

🏗️ should_exclude
   📄 Tools\BackupManager\BackupManager.py (line 147)
   ⚠️  Never called

🏗️ get_relative_path
   📄 Tools\BackupManager\BackupManager.py (line 192)
   ⚠️  Never called

🏗️ format_path_for_display
   📄 Tools\BackupManager\BackupManager.py (line 199)
   ⚠️  Never called

🏗️ create_backup
   📄 Tools\BackupManager\BackupManager.py (line 206)
   ⚠️  Never called

🏗️ list_backups
   📄 Tools\BackupManager\BackupManager.py (line 357)
   ⚠️  Never called

🏗️ restore_backup
   📄 Tools\BackupManager\BackupManager.py (line 444)
   ⚠️  Never called

🏗️ set_capture_rate
   📄 Tools\ScreenRecording\screen_recorder.py (line 65)
   📞 Called by:
      • Tools\ScreenRecording\screen_recorder.py (line 509)
      • Tools\ScreenRecording\screen_recorder.py (line 524)

🏗️ set_playback_fps
   📄 Tools\ScreenRecording\screen_recorder.py (line 69)
   📞 Called by:
      • Tools\ScreenRecording\screen_recorder.py (line 510)
      • Tools\ScreenRecording\screen_recorder.py (line 531)

🏗️ set_capture_mode
   📄 Tools\ScreenRecording\screen_recorder.py (line 73)
   📞 Called by:
      • Tools\ScreenRecording\screen_recorder.py (line 489)

🏗️ set_realtime_compression
   📄 Tools\ScreenRecording\screen_recorder.py (line 77)
   📞 Called by:
      • Tools\ScreenRecording\screen_recorder.py (line 504)
      • Tools\ScreenRecording\screen_recorder.py (line 545)
      • Tools\ScreenRecording\screen_recorder.py (line 548)

🏗️ set_quality_preset
   📄 Tools\ScreenRecording\screen_recorder.py (line 83)
   📞 Called by:
      • Tools\ScreenRecording\screen_recorder.py (line 503)
      • Tools\ScreenRecording\screen_recorder.py (line 556)

🏗️ compress_frame
   📄 Tools\ScreenRecording\screen_recorder.py (line 91)
   ⚠️  Never called

🏗️ fast_map_to_primary_colors
   📄 Tools\ScreenRecording\screen_recorder.py (line 98)
   ⚠️  Never called

🏗️ start_recording
   📄 Tools\ScreenRecording\screen_recorder.py (line 571)
   📞 Called by:
      • Tools\ScreenRecording\screen_recorder.py (line 574)
      • UI\MainWindow\MainWindow.py (line 1877)

🏗️ pause_recording
   📄 Tools\ScreenRecording\screen_recorder.py (line 583)
   📞 Called by:
      • Tools\ScreenRecording\screen_recorder.py (line 587)

🏗️ resume_recording
   📄 Tools\ScreenRecording\screen_recorder.py (line 121)
   📞 Called by:
      • Tools\ScreenRecording\screen_recorder.py (line 593)

🏗️ stop_recording
   📄 Tools\ScreenRecording\screen_recorder.py (line 598)
   📞 Called by:
      • Tools\ScreenRecording\screen_recorder.py (line 604)
      • Tools\ScreenRecording\screen_recorder.py (line 698)
      • UI\MainWindow\MainWindow.py (line 1826)

🏗️ get_frames
   📄 Tools\ScreenRecording\screen_recorder.py (line 132)
   📞 Called by:
      • Tools\ScreenRecording\screen_recorder.py (line 627)

🏗️ clear_frames
   📄 Tools\ScreenRecording\screen_recorder.py (line 137)
   📞 Called by:
      • Tools\ScreenRecording\screen_recorder.py (line 667)

🏗️ on_mode_changed
   📄 Tools\ScreenRecording\screen_recorder.py (line 477)
   ⚠️  Never called

🏗️ toggle_defaults
   📄 Tools\ScreenRecording\screen_recorder.py (line 491)
   ⚠️  Never called

🏗️ apply_default_settings
   📄 Tools\ScreenRecording\screen_recorder.py (line 498)
   ⚠️  Never called

🏗️ update_control_states
   📄 Tools\ScreenRecording\screen_recorder.py (line 514)
   ⚠️  Never called

🏗️ update_capture_rate
   📄 Tools\ScreenRecording\screen_recorder.py (line 520)
   ⚠️  Never called

🏗️ update_playback_fps
   📄 Tools\ScreenRecording\screen_recorder.py (line 527)
   ⚠️  Never called

🏗️ update_info_label
   📄 Tools\ScreenRecording\screen_recorder.py (line 534)
   ⚠️  Never called

🏗️ toggle_realtime_compression
   📄 Tools\ScreenRecording\screen_recorder.py (line 541)
   ⚠️  Never called

🏗️ change_quality_preset
   📄 Tools\ScreenRecording\screen_recorder.py (line 551)
   ⚠️  Never called

🏗️ update_quality_info
   📄 Tools\ScreenRecording\screen_recorder.py (line 560)
   ⚠️  Never called

🏗️ update_frame_count
   📄 Tools\ScreenRecording\screen_recorder.py (line 567)
   ⚠️  Never called

🏗️ cancel_processing
   📄 Tools\ScreenRecording\screen_recorder.py (line 618)
   ⚠️  Never called

🏗️ start_gif_processing
   📄 Tools\ScreenRecording\screen_recorder.py (line 625)
   ⚠️  Never called

🏗️ update_gif_progress
   📄 Tools\ScreenRecording\screen_recorder.py (line 669)
   ⚠️  Never called

🏗️ gif_processing_completed
   📄 Tools\ScreenRecording\screen_recorder.py (line 673)
   ⚠️  Never called

🏗️ gif_processing_failed
   📄 Tools\ScreenRecording\screen_recorder.py (line 683)
   ⚠️  Never called

🏗️ reset_ui
   📄 Tools\ScreenRecording\screen_recorder.py (line 688)
   ⚠️  Never called

🏗️ create_top_toolbar
   📄 Editors\RoomEditor\ui\main_window.py (line 106)
   ⚠️  Never called

🏗️ create_left_tab_panel
   📄 Editors\RoomEditor\ui\main_window.py (line 188)
   ⚠️  Never called

🏗️ create_objects_group
   📄 Editors\RoomEditor\ui\main_window.py (line 245)
   ⚠️  Never called

🏗️ populate_objects_list
   📄 Editors\RoomEditor\ui\main_window.py (line 305)
   ⚠️  Never called

🏗️ create_background_group
   📄 Editors\RoomEditor\ui\main_window.py (line 322)
   ⚠️  Never called

🏗️ populate_backgrounds_combo
   📄 Editors\RoomEditor\ui\main_window.py (line 417)
   ⚠️  Never called

🏗️ create_settings_group
   📄 Editors\RoomEditor\ui\main_window.py (line 435)
   ⚠️  Never called

🏗️ create_views_group
   📄 Editors\RoomEditor\ui\main_window.py (line 513)
   ⚠️  Never called

🏗️ update_views_list
   📄 Editors\RoomEditor\ui\main_window.py (line 592)
   ⚠️  Never called

🏗️ on_views_enabled_changed
   📄 Editors\RoomEditor\ui\main_window.py (line 602)
   ⚠️  Never called

🏗️ add_view
   📄 Editors\RoomEditor\ui\main_window.py (line 606)
   ⚠️  Never called

🏗️ remove_selected_view
   📄 Editors\RoomEditor\ui\main_window.py (line 613)
   ⚠️  Never called

🏗️ on_view_selected
   📄 Editors\RoomEditor\ui\main_window.py (line 623)
   ⚠️  Never called

🏗️ clear_view_edit_fields
   📄 Editors\RoomEditor\ui\main_window.py (line 647)
   ⚠️  Never called

🏗️ on_view_property_changed
   📄 Editors\RoomEditor\ui\main_window.py (line 666)
   ⚠️  Never called

🏗️ create_instance_order_group
   📄 Editors\RoomEditor\ui\main_window.py (line 683)
   ⚠️  Never called

🏗️ update_instance_order_list
   📄 Editors\RoomEditor\ui\main_window.py (line 719)
   ⚠️  Never called

🏗️ move_instance_up
   📄 Editors\RoomEditor\ui\main_window.py (line 730)
   ⚠️  Never called

🏗️ move_instance_down
   📄 Editors\RoomEditor\ui\main_window.py (line 745)
   ⚠️  Never called

🏗️ on_object_selected
   📄 Editors\RoomEditor\ui\main_window.py (line 763)
   ⚠️  Never called

🏗️ on_objects_list_context_menu
   📄 Editors\RoomEditor\ui\main_window.py (line 784)
   ⚠️  Never called

🏗️ on_instances_list_context_menu
   📄 Editors\RoomEditor\ui\main_window.py (line 801)
   ⚠️  Never called

🏗️ on_instance_list_selected
   📄 Editors\RoomEditor\ui\main_window.py (line 824)
   ⚠️  Never called

🏗️ update_instances_list
   📄 Editors\RoomEditor\ui\main_window.py (line 833)
   📞 Called by:
      • Editors\RoomEditor\RoomEditor.py (line 1521)
      • Editors\RoomEditor\RoomEditor.py (line 1575)

🏗️ duplicate_selected_instance
   📄 Editors\RoomEditor\ui\main_window.py (line 846)
   ⚠️  Never called

🏗️ duplicate_instance
   📄 Editors\RoomEditor\ui\main_window.py (line 851)
   📞 Called by:
      • Editors\RoomEditor\RoomEditor.py (line 1600)

🏗️ remove_instance
   📄 Editors\RoomEditor\ui\main_window.py (line 868)
   ⚠️  Never called

🏗️ remove_instance_at_index
   📄 Editors\RoomEditor\ui\main_window.py (line 873)
   📞 Called by:
      • Editors\RoomEditor\RoomEditor.py (line 1604)

🏗️ on_background_selected
   📄 Editors\RoomEditor\ui\main_window.py (line 895)
   ⚠️  Never called

🏗️ on_bg_color_clicked
   📄 Editors\RoomEditor\ui\main_window.py (line 912)
   ⚠️  Never called

🏗️ on_background_settings_changed
   📄 Editors\RoomEditor\ui\main_window.py (line 927)
   ⚠️  Never called

🏗️ on_settings_changed
   📄 Editors\RoomEditor\ui\main_window.py (line 943)
   ⚠️  Never called

🏗️ on_size_changed
   📄 Editors\RoomEditor\ui\main_window.py (line 950)
   ⚠️  Never called

🏗️ on_grid_changed
   📄 Editors\RoomEditor\ui\main_window.py (line 957)
   ⚠️  Never called

🏗️ on_snap_changed
   📄 Editors\RoomEditor\ui\main_window.py (line 968)
   ⚠️  Never called

🏗️ on_show_grid_changed
   📄 Editors\RoomEditor\ui\main_window.py (line 974)
   ⚠️  Never called

🏗️ on_3d_mode_changed
   📄 Editors\RoomEditor\ui\main_window.py (line 981)
   ⚠️  Never called

🏗️ on_reset_zoom_clicked
   📄 Editors\RoomEditor\ui\main_window.py (line 999)
   ⚠️  Never called

🏗️ show_object_properties
   📄 Editors\RoomEditor\ui\main_window.py (line 1006)
   ⚠️  Never called

🏗️ open_object_editor
   📄 Editors\RoomEditor\ui\main_window.py (line 1020)
   ⚠️  Never called

🏗️ show_instance_properties
   📄 Editors\RoomEditor\ui\main_window.py (line 1024)
   📞 Called by:
      • Editors\RoomEditor\RoomEditor.py (line 1597)

🏗️ get_instance_draw_info
   📄 Editors\RoomEditor\ui\main_window.py (line 1041)
   📞 Called by:
      • Editors\RoomEditor\RoomEditor.py (line 1394)
      • Editors\RoomEditor\RoomEditor.py (line 1530)

🏗️ load_defaults
   📄 UI\CommonDialogs\BackupFolderDialog.py (line 82)
   ⚠️  Never called

🏗️ populate_folders
   📄 UI\CommonDialogs\BackupFolderDialog.py (line 96)
   ⚠️  Never called

🏗️ select_none
   📄 UI\CommonDialogs\BackupFolderDialog.py (line 139)
   ⚠️  Never called

🏗️ reset_to_defaults
   📄 UI\CommonDialogs\BackupFolderDialog.py (line 146)
   ⚠️  Never called

🏗️ get_folder_states
   📄 UI\CommonDialogs\BackupFolderDialog.py (line 151)
   ⚠️  Never called

🏗️ get_included_folders
   📄 UI\CommonDialogs\BackupFolderDialog.py (line 160)
   ⚠️  Never called

🏗️ get_excluded_folders
   📄 UI\CommonDialogs\BackupFolderDialog.py (line 165)
   ⚠️  Never called

🏗️ populate_resource_folders
   📄 UI\CommonDialogs\ResourceFolderDialog.py (line 90)
   ⚠️  Never called

🏗️ get_selected_folders
   📄 UI\CommonDialogs\ResourceFolderDialog.py (line 117)
   ⚠️  Never called

🏗️ load_backups
   📄 UI\CommonDialogs\RestoreDialog.py (line 95)
   ⚠️  Never called

🏗️ get_selected_backup
   📄 UI\CommonDialogs\RestoreDialog.py (line 137)
   ⚠️  Never called

🏗️ should_overwrite
   📄 UI\CommonDialogs\RestoreDialog.py (line 144)
   ⚠️  Never called

🏗️ _make_placeholder
   📄 Editors\ObjectEditor\object_editor_ui.py (line 58)
   ⚠️  Never called

🏗️ _make_scrollable
   📄 UI\CommonDialogs\PreferencesDialog.py (line 62)
   ⚠️  Never called

🏗️ create_general_tab
   📄 UI\CommonDialogs\PreferencesDialog.py (line 72)
   ⚠️  Never called

🏗️ create_project_tab
   📄 UI\CommonDialogs\PreferencesDialog.py (line 313)
   ⚠️  Never called

🏗️ create_appearance_tabs
   📄 UI\CommonDialogs\PreferencesDialog.py (line 385)
   ⚠️  Never called

🏗️ create_pygenesis_appearance_tab
   📄 UI\CommonDialogs\PreferencesDialog.py (line 408)
   ⚠️  Never called

🏗️ create_nova_appearance_tab
   📄 UI\CommonDialogs\PreferencesDialog.py (line 533)
   ⚠️  Never called

🏗️ create_code_tab
   📄 UI\CommonDialogs\PreferencesDialog.py (line 591)
   ⚠️  Never called

🏗️ create_pgsl_tab_old_removed
   📄 UI\CommonDialogs\PreferencesDialog.py (line 705)
   ⚠️  Never called

🏗️ browse_build_output
   📄 UI\CommonDialogs\PreferencesDialog.py (line 775)
   ⚠️  Never called

🏗️ create_ai_tab
   📄 UI\CommonDialogs\PreferencesDialog.py (line 787)
   ⚠️  Never called

🏗️ create_ai_appearance_tab
   📄 UI\CommonDialogs\PreferencesDialog.py (line 809)
   ⚠️  Never called

🏗️ create_ai_api_keys_tab
   📄 UI\CommonDialogs\PreferencesDialog.py (line 849)
   ⚠️  Never called

🏗️ load_api_keys
   📄 UI\CommonDialogs\PreferencesDialog.py (line 916)
   ⚠️  Never called

🏗️ save_api_keys
   📄 UI\CommonDialogs\PreferencesDialog.py (line 925)
   ⚠️  Never called

🏗️ create_ai_edits_tab
   📄 UI\CommonDialogs\PreferencesDialog.py (line 934)
   ⚠️  Never called

🏗️ test_api_key
   📄 UI\CommonDialogs\PreferencesDialog.py (line 1034)
   ⚠️  Never called

🏗️ create_editor_specific_tab
   📄 UI\CommonDialogs\PreferencesDialog.py (line 1043)
   ⚠️  Never called

🏗️ create_image_editor_tab
   📄 UI\CommonDialogs\PreferencesDialog.py (line 1067)
   ⚠️  Never called

🏗️ create_audio_editor_tab
   📄 UI\CommonDialogs\PreferencesDialog.py (line 1154)
   ⚠️  Never called

🏗️ create_background_editor_tab
   📄 UI\CommonDialogs\PreferencesDialog.py (line 1193)
   ⚠️  Never called

🏗️ create_object_editor_tab
   📄 UI\CommonDialogs\PreferencesDialog.py (line 1227)
   ⚠️  Never called

🏗️ create_model_editor_tab
   📄 UI\CommonDialogs\PreferencesDialog.py (line 1261)
   ⚠️  Never called

🏗️ choose_model_selection_color
   📄 UI\CommonDialogs\PreferencesDialog.py (line 1463)
   ⚠️  Never called

🏗️ choose_model_color
   📄 UI\CommonDialogs\PreferencesDialog.py (line 1476)
   ⚠️  Never called

🏗️ choose_model_texture
   📄 UI\CommonDialogs\PreferencesDialog.py (line 1489)
   ⚠️  Never called

🏗️ create_room_editor_tab
   📄 UI\CommonDialogs\PreferencesDialog.py (line 1562)
   ⚠️  Never called

🏗️ browse_project_path
   📄 UI\CommonDialogs\PreferencesDialog.py (line 1599)
   ⚠️  Never called

🏗️ browse_venv_path
   📄 UI\CommonDialogs\PreferencesDialog.py (line 1605)
   ⚠️  Never called

🏗️ browse_editor_backup_path
   📄 UI\CommonDialogs\PreferencesDialog.py (line 1611)
   ⚠️  Never called

🏗️ browse_project_backup_path
   📄 UI\CommonDialogs\PreferencesDialog.py (line 1617)
   ⚠️  Never called

🏗️ browse_editor_summary_path
   📄 UI\CommonDialogs\PreferencesDialog.py (line 1623)
   ⚠️  Never called

🏗️ generate_project_summary
   📄 UI\CommonDialogs\PreferencesDialog.py (line 1629)
   ⚠️  Never called

🏗️ generate_editor_summary
   📄 UI\CommonDialogs\PreferencesDialog.py (line 1668)
   ⚠️  Never called

🏗️ choose_accent_color
   📄 UI\CommonDialogs\PreferencesDialog.py (line 1712)
   ⚠️  Never called

🏗️ choose_color
   📄 UI\CommonDialogs\PreferencesDialog.py (line 1720)
   ⚠️  Never called

🏗️ reset_colors
   📄 UI\CommonDialogs\PreferencesDialog.py (line 1748)
   ⚠️  Never called

🏗️ on_theme_changed
   📄 UI\CommonDialogs\PreferencesDialog.py (line 1770)
   ⚠️  Never called

🏗️ on_ui_font_size_changed
   📄 UI\CommonDialogs\PreferencesDialog.py (line 1817)
   ⚠️  Never called

🏗️ refresh_theme_list
   📄 UI\CommonDialogs\PreferencesDialog.py (line 1834)
   ⚠️  Never called

🏗️ load_custom_colors
   📄 UI\CommonDialogs\PreferencesDialog.py (line 1949)
   ⚠️  Never called

🏗️ _get_bool
   📄 UI\CommonDialogs\PreferencesDialog.py (line 2074)
   ⚠️  Never called

🏗️ _get_int
   📄 UI\CommonDialogs\PreferencesDialog.py (line 2083)
   ⚠️  Never called

🏗️ apply_settings
   📄 UI\CommonDialogs\PreferencesDialog.py (line 2449)
   ⚠️  Never called

🏗️ clear_recent_projects
   📄 UI\CommonDialogs\PreferencesDialog.py (line 2738)
   ⚠️  Never called

🏗️ _on_recent_project_double_clicked
   📄 UI\CommonDialogs\PreferencesDialog.py (line 2743)
   ⚠️  Never called

🏗️ hideEvent
   📄 UI\Widgets\LoadingWidget.py (line 46)
   📞 Called by:
      • UI\Widgets\LoadingWidget.py (line 48)

🏗️ start_animation
   📄 UI\Widgets\LoadingWidget.py (line 51)
   ⚠️  Never called

🏗️ update_dots
   📄 UI\Widgets\LoadingWidget.py (line 64)
   ⚠️  Never called

🏗️ set_message
   📄 UI\Widgets\LoadingWidget.py (line 70)
   ⚠️  Never called

🏗️ _get_image_path
   📄 UI\Widgets\ParallelThumbnailLoader.py (line 55)
   ⚠️  Never called

🏗️ _load_thumbnail
   📄 UI\Widgets\ParallelThumbnailLoader.py (line 60)
   ⚠️  Never called

🏗️ start_loading
   📄 UI\Widgets\ParallelThumbnailLoader.py (line 90)
   ⚠️  Never called

🏗️ _process_batch
   📄 UI\Widgets\ParallelThumbnailLoader.py (line 104)
   ⚠️  Never called

🏗️ write
   📄 UI\Widgets\TerminalWidget.py (line 20)
   📞 Called by:
      • Core\Code\PGSL\Parser.py (line 165)
      • Core\Code\PGSL\Parser.py (line 166)
      • Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 3383)
      • Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 3384)
      • UI\Widgets\TerminalWidget.py (line 91)
      • UI\Widgets\TerminalWidget.py (line 125)
      • UI\Widgets\TerminalWidget.py (line 240)
      • UI\Widgets\TerminalWidget.py (line 281)

🏗️ flush
   📄 UI\Widgets\TerminalWidget.py (line 25)
   📞 Called by:
      • Core\Debug.py (line 63)
      • Core\Debug.py (line 71)
      • UI\Widgets\TerminalWidget.py (line 92)
      • UI\Widgets\TerminalWidget.py (line 126)
      • UI\Widgets\TerminalWidget.py (line 241)
      • UI\Widgets\TerminalWidget.py (line 282)

🏗️ isatty
   📄 UI\Widgets\TerminalWidget.py (line 29)
   ⚠️  Never called

🏗️ setup_streams
   📄 UI\Widgets\TerminalWidget.py (line 70)
   ⚠️  Never called

🏗️ get_editor_font
   📄 UI\Widgets\TerminalWidget.py (line 96)
   ⚠️  Never called

🏗️ append_text
   📄 UI\Widgets\TerminalWidget.py (line 105)
   📞 Called by:
      • Core\Code\Unified\unified_code_editor.py (line 667)
      • Editors\ObjectEditor\object_editor.py (line 968)
      • Editors\ObjectEditor\UI\code_editor_widget.py (line 267)
      • UI\MainWindow\MainWindow.py (line 968)
      • UI\MainWindow\MainWindow.py (line 978)
      • UI\MainWindow\MainWindow.py (line 979)
      • UI\MainWindow\MainWindow.py (line 1029)
      • UI\MainWindow\MainWindow.py (line 1030)
      • UI\MainWindow\MainWindow.py (line 1031)
      • UI\MainWindow\MainWindow.py (line 1036)
      • UI\MainWindow\MainWindow.py (line 1038)
      • UI\MainWindow\MainWindow.py (line 1042)
      • UI\MainWindow\MainWindow.py (line 1045)
      • UI\MainWindow\MainWindow.py (line 1062)
      • UI\MainWindow\MainWindow.py (line 1072)
      • UI\MainWindow\MainWindow.py (line 1073)
      • UI\MainWindow\MainWindow.py (line 1121)
      • UI\MainWindow\MainWindow.py (line 1122)
      • UI\MainWindow\MainWindow.py (line 1123)
      • UI\MainWindow\MainWindow.py (line 1127)
      • UI\MainWindow\MainWindow.py (line 1129)
      • UI\MainWindow\MainWindow.py (line 1133)
      • UI\MainWindow\MainWindow.py (line 1136)
      • UI\MainWindow\MainWindow.py (line 1153)
      • UI\MainWindow\MainWindow.py (line 1163)
      • UI\MainWindow\MainWindow.py (line 1164)
      • UI\MainWindow\MainWindow.py (line 1196)
      • UI\MainWindow\MainWindow.py (line 1197)

🏗️ _append_line
   📄 UI\Widgets\TerminalWidget.py (line 128)
   ⚠️  Never called

🏗️ append_error_text
   📄 UI\Widgets\TerminalWidget.py (line 220)
   ⚠️  Never called

🏗️ invalidate_caches
   📄 Editors\ImageEditor\core\ui\preview.py (line 88)
   ⚠️  Never called

🏗️ _force_immediate_update
   📄 Editors\ImageEditor\core\ui\preview.py (line 106)
   ⚠️  Never called

🏗️ _get_scale
   📄 Editors\ImageEditor\core\ui\preview.py (line 132)
   ⚠️  Never called

🏗️ _get_canvas_offset
   📄 Editors\ImageEditor\core\ui\preview.py (line 141)
   ⚠️  Never called

🏗️ _widget_pos_to_image_coords
   📄 Editors\ImageEditor\core\ui\preview.py (line 155)
   ⚠️  Never called

🏗️ _image_coords_to_widget_pos
   📄 Editors\ImageEditor\core\ui\preview.py (line 174)
   ⚠️  Never called

🏗️ _maybe_snap_widget_pos
   📄 Editors\ImageEditor\core\ui\preview.py (line 182)
   ⚠️  Never called

🏗️ _iter_line_points
   📄 Editors\ImageEditor\core\ui\preview.py (line 200)
   ⚠️  Never called

🏗️ _draw_snapped_path
   📄 Editors\ImageEditor\core\ui\preview.py (line 219)
   ⚠️  Never called

🏗️ _update_marching_ants
   📄 Editors\ImageEditor\core\ui\preview.py (line 228)
   ⚠️  Never called

🏗️ _get_resize_cursor
   📄 Editors\ImageEditor\core\ui\preview.py (line 482)
   ⚠️  Never called

🏗️ _snap_to_grid
   📄 Editors\ImageEditor\core\ui\preview.py (line 976)
   ⚠️  Never called

🏗️ _draw_at
   📄 Editors\ImageEditor\core\ui\preview.py (line 987)
   ⚠️  Never called

🏗️ _draw_path_batched
   📄 Editors\ImageEditor\core\ui\preview.py (line 1098)
   ⚠️  Never called

🏗️ _apply_brush_stroke
   📄 Editors\ImageEditor\core\ui\preview.py (line 1222)
   ⚠️  Never called

🏗️ _apply_pencil_stroke
   📄 Editors\ImageEditor\core\ui\preview.py (line 1256)
   ⚠️  Never called

🏗️ _apply_marker_stroke
   📄 Editors\ImageEditor\core\ui\preview.py (line 1282)
   ⚠️  Never called

🏗️ _apply_calligraphy_stroke
   📄 Editors\ImageEditor\core\ui\preview.py (line 1313)
   ⚠️  Never called

🏗️ _apply_airbrush_stroke
   📄 Editors\ImageEditor\core\ui\preview.py (line 1368)
   ⚠️  Never called

🏗️ _apply_gradient_stroke
   📄 Editors\ImageEditor\core\ui\preview.py (line 1405)
   ⚠️  Never called

🏗️ _apply_eraser_stroke
   📄 Editors\ImageEditor\core\ui\preview.py (line 1436)
   ⚠️  Never called

🏗️ _apply_dither_stroke
   📄 Editors\ImageEditor\core\ui\preview.py (line 1451)
   ⚠️  Never called

🏗️ _apply_blur_brush_stroke
   📄 Editors\ImageEditor\core\ui\preview.py (line 1487)
   ⚠️  Never called

🏗️ _apply_sharpen_brush_stroke
   📄 Editors\ImageEditor\core\ui\preview.py (line 1517)
   ⚠️  Never called

🏗️ _draw_line
   📄 Editors\ImageEditor\core\ui\preview.py (line 1554)
   ⚠️  Never called

🏗️ _draw_shape
   📄 Editors\ImageEditor\core\ui\preview.py (line 1619)
   ⚠️  Never called

🏗️ _draw_rect
   📄 Editors\ImageEditor\core\ui\preview.py (line 1674)
   ⚠️  Never called

🏗️ _draw_ellipse
   📄 Editors\ImageEditor\core\ui\preview.py (line 1685)
   ⚠️  Never called

🏗️ _draw_star
   📄 Editors\ImageEditor\core\ui\preview.py (line 1703)
   ⚠️  Never called

🏗️ _draw_polygon
   📄 Editors\ImageEditor\core\ui\preview.py (line 1761)
   ⚠️  Never called

🏗️ _draw_triangle
   📄 Editors\ImageEditor\core\ui\preview.py (line 1808)
   ⚠️  Never called

🏗️ _draw_line_on_image
   📄 Editors\ImageEditor\core\ui\preview.py (line 1852)
   ⚠️  Never called

🏗️ _flood_fill
   📄 Editors\ImageEditor\core\ui\preview.py (line 1890)
   ⚠️  Never called

🏗️ _draw_star_preview
   📄 Editors\ImageEditor\core\ui\preview.py (line 2019)
   ⚠️  Never called

🏗️ _draw_polygon_preview
   📄 Editors\ImageEditor\core\ui\preview.py (line 2047)
   ⚠️  Never called

🏗️ _draw_triangle_preview
   📄 Editors\ImageEditor\core\ui\preview.py (line 2071)
   ⚠️  Never called

🏗️ _emit_mouse_position
   📄 Editors\ImageEditor\core\ui\preview.py (line 2186)
   ⚠️  Never called

🏗️ _lasso_mask
   📄 Editors\ImageEditor\core\ui\preview.py (line 2203)
   ⚠️  Never called

🏗️ _handle_selection_click
   📄 Editors\ImageEditor\core\ui\preview.py (line 2222)
   ⚠️  Never called

🏗️ _start_region_selection
   📄 Editors\ImageEditor\core\ui\preview.py (line 2235)
   ⚠️  Never called

🏗️ _start_magic_wand_selection
   📄 Editors\ImageEditor\core\ui\preview.py (line 2249)
   ⚠️  Never called

🏗️ _start_brush_selection
   📄 Editors\ImageEditor\core\ui\preview.py (line 2285)
   ⚠️  Never called

🏗️ _continue_brush_selection
   📄 Editors\ImageEditor\core\ui\preview.py (line 2302)
   ⚠️  Never called

🏗️ _delete_selection
   📄 Editors\ImageEditor\core\ui\preview.py (line 2459)
   📞 Called by:
      • Editors\Shared\IntegratedImageEditor.py (line 1208)

🏗️ _deselect_area
   📄 Editors\ImageEditor\core\ui\preview.py (line 2478)
   ⚠️  Never called

🏗️ draw_onion_overlay
   📄 Editors\ImageEditor\core\ui\preview.py (line 2718)
   📞 Called by:
      • Editors\ImageEditor\core\ui\preview.py (line 2763)
      • Editors\ImageEditor\core\ui\preview.py (line 2767)
      • Editors\ImageEditor\core\ui\preview.py (line 2776)
      • Editors\ImageEditor\core\ui\preview.py (line 2780)
      • Editors\ImageEditor\core\ui\preview.py (line 2784)

🏗️ toggle_composite_view
   📄 Editors\ImageEditor\core\ui\preview.py (line 3006)
   📞 Called by:
      • Editors\ImageEditor\core\ui\main_window.py (line 6279)

🏗️ _fill_triangle
   📄 Editors\ImageEditor\core\ui\preview.py (line 3011)
   ⚠️  Never called

🏗️ barycentric
   📄 Editors\ImageEditor\core\ui\preview.py (line 3045)
   📞 Called by:
      • Editors\ImageEditor\core\ui\preview.py (line 3032)
      • Editors\ImageEditor\core\ui\preview.py (line 3057)

🏗️ _fill_triangle_mask
   📄 Editors\ImageEditor\core\ui\preview.py (line 3036)
   ⚠️  Never called

🏗️ _draw_line_mask
   📄 Editors\ImageEditor\core\ui\preview.py (line 3061)
   ⚠️  Never called

🏗️ setup_connections
   📄 UI\Widgets\ResourceTree.py (line 84)
   ⚠️  Never called

🏗️ setup_drag_drop
   📄 UI\Widgets\ResourceTree.py (line 94)
   ⚠️  Never called

🏗️ refresh
   📄 UI\Widgets\ResourceTree.py (line 128)
   📞 Called by:
      • UI\CommonDialogs\PreferencesDialog.py (line 2792)
      • UI\MainWindow\MainWindow.py (line 627)
      • UI\MainWindow\MainWindow.py (line 776)
      • UI\MainWindow\MainWindow.py (line 784)
      • UI\MainWindow\MainWindow.py (line 807)

🏗️ _get_resources_from_runtime
   📄 UI\Widgets\ResourceTree.py (line 178)
   ⚠️  Never called

🏗️ refresh_resource_type
   📄 UI\Widgets\ResourceTree.py (line 188)
   ⚠️  Never called

🏗️ _store_folder_expanded_states
   📄 UI\Widgets\ResourceTree.py (line 222)
   ⚠️  Never called

🏗️ cleanup_project_data
   📄 UI\Widgets\ResourceTree.py (line 236)
   ⚠️  Never called

🏗️ refresh_parent_item
   📄 UI\Widgets\ResourceTree.py (line 266)
   ⚠️  Never called

🏗️ add_resources_to_tree
   📄 UI\Widgets\ResourceTree.py (line 293)
   ⚠️  Never called

🏗️ _scan_folder_structure
   📄 UI\Widgets\ResourceTree.py (line 338)
   ⚠️  Never called

🏗️ _add_folder_structure
   📄 UI\Widgets\ResourceTree.py (line 354)
   ⚠️  Never called

🏗️ _get_resource_icon
   📄 UI\Widgets\ResourceTree.py (line 447)
   ⚠️  Never called

🏗️ _get_sprite_thumbnail
   📄 UI\Widgets\ResourceTree.py (line 459)
   ⚠️  Never called

🏗️ add_resource_item
   📄 UI\Widgets\ResourceTree.py (line 655)
   ⚠️  Never called

🏗️ _find_resource_item
   📄 UI\Widgets\ResourceTree.py (line 2105)
   ⚠️  Never called

🏗️ _find_resource_item_recursive
   📄 UI\Widgets\ResourceTree.py (line 684)
   ⚠️  Never called

🏗️ _find_or_create_folder_item
   📄 UI\Widgets\ResourceTree.py (line 699)
   ⚠️  Never called

🏗️ add_single_resource
   📄 UI\Widgets\ResourceTree.py (line 749)
   ⚠️  Never called

🏗️ update_single_resource
   📄 UI\Widgets\ResourceTree.py (line 771)
   📞 Called by:
      • Editors\ObjectEditor\object_editor.py (line 591)
      • UI\MainWindow\MainWindow.py (line 821)

🏗️ remove_single_resource
   📄 UI\Widgets\ResourceTree.py (line 800)
   📞 Called by:
      • UI\MainWindow\MainWindow.py (line 826)

🏗️ _start_thumbnail_loading
   📄 UI\Widgets\ResourceTree.py (line 818)
   ⚠️  Never called

🏗️ _get_resource_image_path_for_cache
   📄 UI\Widgets\ResourceTree.py (line 863)
   ⚠️  Never called

🏗️ on_thumbnail_ready
   📄 UI\Widgets\ResourceTree.py (line 869)
   ⚠️  Never called

🏗️ show_context_menu
   📄 UI\Widgets\ResourceTree.py (line 905)
   ⚠️  Never called

🏗️ quick_create_sprite_from_image
   📄 UI\Widgets\ResourceTree.py (line 1038)
   ⚠️  Never called

🏗️ open_editor
   📄 UI\Widgets\ResourceTree.py (line 1141)
   ⚠️  Never called

🏗️ quick_create_sound_from_file
   📄 UI\Widgets\ResourceTree.py (line 1167)
   ⚠️  Never called

🏗️ quick_create_object_from_sprite
   📄 UI\Widgets\ResourceTree.py (line 1265)
   ⚠️  Never called

🏗️ find_resource_references
   📄 UI\Widgets\ResourceTree.py (line 1356)
   ⚠️  Never called

🏗️ _check_resource_reference
   📄 UI\Widgets\ResourceTree.py (line 1414)
   ⚠️  Never called

🏗️ view_in_explorer
   📄 UI\Widgets\ResourceTree.py (line 1485)
   ⚠️  Never called

🏗️ copy_resource
   📄 UI\Widgets\ResourceTree.py (line 1563)
   📞 Called by:
      • UI\MainWindow\MainWindow.py (line 914)

🏗️ cut_resource
   📄 UI\Widgets\ResourceTree.py (line 1572)
   📞 Called by:
      • UI\MainWindow\MainWindow.py (line 901)

🏗️ rename_folder
   📄 UI\Widgets\ResourceTree.py (line 1638)
   📞 Called by:
      • UI\MainWindow\MainWindow.py (line 935)

🏗️ create_folder
   📄 UI\Widgets\ResourceTree.py (line 1724)
   📞 Called by:
      • UI\MainWindow\MainWindow.py (line 943)
      • UI\MainWindow\MainWindow.py (line 945)

🏗️ folder_exists
   📄 UI\Widgets\ResourceTree.py (line 1777)
   ⚠️  Never called

🏗️ cut_folder
   📄 UI\Widgets\ResourceTree.py (line 1782)
   📞 Called by:
      • UI\MainWindow\MainWindow.py (line 903)

🏗️ copy_folder
   📄 UI\Widgets\ResourceTree.py (line 1795)
   📞 Called by:
      • UI\MainWindow\MainWindow.py (line 916)

🏗️ delete_folder
   📄 UI\Widgets\ResourceTree.py (line 1807)
   ⚠️  Never called

🏗️ _clear_item_icons
   📄 UI\Widgets\ResourceTree.py (line 1893)
   ⚠️  Never called

🏗️ has_clipboard_data
   📄 UI\Widgets\ResourceTree.py (line 1905)
   ⚠️  Never called

🏗️ paste_resource
   📄 UI\Widgets\ResourceTree.py (line 1909)
   📞 Called by:
      • UI\MainWindow\MainWindow.py (line 925)

🏗️ dragEnterEvent
   📄 UI\Widgets\ResourceTree.py (line 1937)
   ⚠️  Never called

🏗️ on_resource_created
   📄 UI\Widgets\ResourceTree.py (line 2009)
   ⚠️  Never called

🏗️ _move_resource_item
   📄 UI\Widgets\ResourceTree.py (line 2021)
   ⚠️  Never called

🏗️ _setup_editor_listeners
   📄 UI\Widgets\ResourceTree.py (line 2055)
   ⚠️  Never called

🏗️ on_editor_changed
   📄 UI\Widgets\ResourceTree.py (line 2063)
   ⚠️  Never called

🏗️ _on_active_editor_changed
   📄 UI\Widgets\ResourceTree.py (line 2070)
   ⚠️  Never called

🏗️ _on_object_sprite_changed
   📄 UI\Widgets\ResourceTree.py (line 2091)
   ⚠️  Never called

🏗️ search
   📄 UI\Widgets\ResourceTree.py (line 2110)
   📞 Called by:
      • UI\Widgets\ResourceTree.py (line 2125)
      • UI\Widgets\ResourceTree.py (line 2131)

🏗️ _refresh_object_thumbnail
   📄 UI\Widgets\ResourceTree.py (line 2135)
   ⚠️  Never called

🏗️ _load_sprite_thumbnail
   📄 UI\Widgets\ResourceTree.py (line 2163)
   ⚠️  Never called

🏗️ _get_default_icon
   📄 UI\Widgets\ResourceTree.py (line 2205)
   ⚠️  Never called

🏗️ _get_image_path_for_cache
   📄 UI\Widgets\ThumbnailLoader.py (line 280)
   ⚠️  Never called

🏗️ room_to_screen
   📄 Editors\RoomEditor\RoomEditor.py (line 1273)
   ⚠️  Never called

🏗️ screen_to_room
   📄 Editors\RoomEditor\RoomEditor.py (line 1282)
   ⚠️  Never called

🏗️ snap_room_point
   📄 Editors\RoomEditor\RoomEditor.py (line 1287)
   ⚠️  Never called

🏗️ draw_background_layer
   📄 Editors\RoomEditor\RoomEditor.py (line 1347)
   ⚠️  Never called

🏗️ draw_instances
   📄 Editors\RoomEditor\RoomEditor.py (line 1385)
   ⚠️  Never called

🏗️ handle_left_click
   📄 Editors\RoomEditor\RoomEditor.py (line 1486)
   ⚠️  Never called

🏗️ handle_instance_drag
   📄 Editors\RoomEditor\RoomEditor.py (line 1510)
   ⚠️  Never called

🏗️ get_instance_at_screen_pos
   📄 Editors\RoomEditor\RoomEditor.py (line 1524)
   ⚠️  Never called

🏗️ place_instance_at_screen_pos
   📄 Editors\RoomEditor\RoomEditor.py (line 1548)
   ⚠️  Never called

🏗️ on_canvas_context_menu
   📄 Editors\RoomEditor\RoomEditor.py (line 1588)
   ⚠️  Never called

🏗️ __add__
   📄 Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 112)
   ⚠️  Never called

🏗️ __sub__
   📄 Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 115)
   ⚠️  Never called

🏗️ __mul__
   📄 Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 118)
   ⚠️  Never called

🏗️ dot
   📄 Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 121)
   📞 Called by:
      • Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 1469)
      • Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 1489)
      • Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 1490)
      • Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 1564)
      • Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 1729)
      • Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 1873)

🏗️ cross
   📄 Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 124)
   ⚠️  Never called

🏗️ length
   📄 Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 131)
   📞 Called by:
      • Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 821)
      • Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 1076)
      • Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 1508)
      • Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 1516)
      • Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 1525)
      • Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 1572)
      • Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 1878)
      • Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 1925)
      • Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 1936)
      • Editors\ModelEditor\ModelEditor.py (line 7216)
      • Editors\ModelEditor\ModelEditor.py (line 7378)
      • Editors\ModelEditor\ModelEditor.py (line 7422)
      • Editors\ModelEditor\ModelEditor.py (line 7445)
      • Editors\ModelEditor\ModelEditor.py (line 7872)
      • Editors\ModelEditor\ModelEditor.py (line 7874)
      • Editors\ModelEditor\ModelEditor.py (line 7883)
      • Editors\ModelEditor\ModelEditor.py (line 8079)
      • Editors\ModelEditor\ModelEditor.py (line 8081)

🏗️ normalize
   📄 Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 134)
   📞 Called by:
      • Editors\SoundEditor\core\WaveForge.py (line 908)
      • Editors\ModelEditor\ModelEditor.py (line 1096)

🏗️ get_forward
   📄 Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 209)
   📞 Called by:
      • Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 1425)
      • Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 2042)
      • Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 2127)
      • Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 2133)
      • Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 2146)
      • Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 3326)
      • Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 3326)
      • Editors\ModelEditor\ModelEditor.py (line 1162)
      • Editors\ModelEditor\ModelEditor.py (line 2570)
      • Editors\ModelEditor\ModelEditor.py (line 2586)
      • Editors\ModelEditor\ModelEditor.py (line 7175)
      • Editors\ModelEditor\ModelEditor.py (line 7287)
      • Editors\ModelEditor\ModelEditor.py (line 7353)
      • Editors\ModelEditor\ModelEditor.py (line 7914)

🏗️ get_right
   📄 Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 219)
   📞 Called by:
      • Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 1426)
      • Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 2025)
      • Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 2147)
      • Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 3327)
      • Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 3327)
      • Editors\ModelEditor\ModelEditor.py (line 2277)
      • Editors\ModelEditor\ModelEditor.py (line 2587)
      • Editors\ModelEditor\ModelEditor.py (line 7176)
      • Editors\ModelEditor\ModelEditor.py (line 7265)
      • Editors\ModelEditor\ModelEditor.py (line 7354)
      • Editors\ModelEditor\ModelEditor.py (line 7915)

🏗️ get_up
   📄 Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 228)
   📞 Called by:
      • Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 1427)
      • Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 2026)
      • Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 2148)
      • Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 3328)
      • Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 3328)
      • Editors\ModelEditor\ModelEditor.py (line 1164)
      • Editors\ModelEditor\ModelEditor.py (line 2278)
      • Editors\ModelEditor\ModelEditor.py (line 7177)
      • Editors\ModelEditor\ModelEditor.py (line 7266)
      • Editors\ModelEditor\ModelEditor.py (line 7355)
      • Editors\ModelEditor\ModelEditor.py (line 7916)

🏗️ set_projection
   📄 Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 232)
   📞 Called by:
      • Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 401)

🏗️ set_view
   📄 Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 239)
   📞 Called by:
      • Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 416)

🏗️ _draw_floor
   📄 Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 475)
   ⚠️  Never called

🏗️ _draw_sky
   📄 Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 493)
   ⚠️  Never called

🏗️ _draw_grid
   📄 Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 514)
   ⚠️  Never called

🏗️ _compile_grid
   📄 Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 521)
   ⚠️  Never called

🏗️ _draw_axes
   📄 Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 538)
   ⚠️  Never called

🏗️ _find_closed_loops
   📄 Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 559)
   ⚠️  Never called

🏗️ vertex_key
   📄 Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 568)
   📞 Called by:
      • Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 590)
      • Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 591)
      • Editors\ModelEditor\ModelEditor.py (line 6781)
      • Editors\ModelEditor\ModelEditor.py (line 6782)

🏗️ _calculate_face_normal
   📄 Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 690)
   📞 Called by:
      • Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 3357)

🏗️ _ensure_consistent_winding
   📄 Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 701)
   📞 Called by:
      • Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 3354)

🏗️ _triangulate_polygon
   📄 Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 750)
   📞 Called by:
      • Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 3355)

🏗️ _detect_faces
   📄 Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 788)
   📞 Called by:
      • Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 2858)
      • Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 3396)

🏗️ _draw_faces
   📄 Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 859)
   ⚠️  Never called

🏗️ _draw_edges
   📄 Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 928)
   ⚠️  Never called

🏗️ _compile_edges
   📄 Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 961)
   ⚠️  Never called

🏗️ _rebuild_gpu_buffers
   📄 Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 987)
   ⚠️  Never called

🏗️ _draw_vbo_faces
   📄 Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 1033)
   ⚠️  Never called

🏗️ _draw_vbo_edges
   📄 Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 1051)
   ⚠️  Never called

🏗️ _draw_temp_line
   📄 Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 1065)
   ⚠️  Never called

🏗️ _draw_primitive
   📄 Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 1146)
   ⚠️  Never called

🏗️ _draw_cube
   📄 Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 1179)
   ⚠️  Never called

🏗️ _draw_sphere
   📄 Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 1223)
   ⚠️  Never called

🏗️ _draw_cylinder
   📄 Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 1246)
   ⚠️  Never called

🏗️ _draw_plane
   📄 Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 1277)
   ⚠️  Never called

🏗️ _draw_selection_handles
   📄 Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 1290)
   ⚠️  Never called

🏗️ _draw_3d_cursor
   📄 Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 1337)
   ⚠️  Never called

🏗️ _apply_axis_constraints
   📄 Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 1399)
   ⚠️  Never called

🏗️ _get_mouse_ray
   📄 Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 1412)
   ⚠️  Never called

🏗️ _intersect_ray_plane
   📄 Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 1440)
   ⚠️  Never called

🏗️ _closest_point_on_line_segment
   📄 Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 1461)
   ⚠️  Never called

🏗️ _intersect_line_segments
   📄 Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 1474)
   ⚠️  Never called

🏗️ _snap_to_geometry
   📄 Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 1498)
   📞 Called by:
      • Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 3029)

🏗️ _find_line_intersections
   📄 Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 1532)
   ⚠️  Never called

🏗️ _screen_to_world_inference
   📄 Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 1580)
   ⚠️  Never called

🏗️ _screen_to_world
   📄 Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 1709)
   ⚠️  Never called

🏗️ _intersect_ray_face
   📄 Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 1714)
   ⚠️  Never called

🏗️ _get_ray_from_screen
   📄 Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 1763)
   ⚠️  Never called

🏗️ _intersect_ray_primitive
   📄 Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 1785)
   ⚠️  Never called

🏗️ _show_object_info_menu
   📄 Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 2064)
   ⚠️  Never called

🏗️ _select_primitive
   📄 Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 2099)
   ⚠️  Never called

🏗️ _delete_primitive
   📄 Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 2110)
   ⚠️  Never called

🏗️ _update_movement
   📄 Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 2137)
   ⚠️  Never called

🏗️ _create_edge
   📄 Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 2169)
   ⚠️  Never called

🏗️ _save_state
   📄 Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 2182)
   📞 Called by:
      • Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 2856)
      • Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 3081)

🏗️ delete_selected
   📄 Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 2261)
   ⚠️  Never called

🏗️ keyReleaseEvent
   📄 Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 2323)
   📞 Called by:
      • Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 2336)
      • Editors\ModelEditor\ModelEditor.py (line 2248)

🏗️ _create_menu_bar
   📄 Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 2440)
   ⚠️  Never called

🏗️ _create_left_panel
   📄 Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 2502)
   ⚠️  Never called

🏗️ _toggle_mgl
   📄 Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 2615)
   ⚠️  Never called

🏗️ _create_right_panel
   📄 Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 2662)
   ⚠️  Never called

🏗️ _set_tool_mode
   📄 Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 2787)
   ⚠️  Never called

🏗️ _create_primitive
   📄 Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 2808)
   ⚠️  Never called

🏗️ _select_color
   📄 Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 2814)
   ⚠️  Never called

🏗️ _update_component_list
   📄 Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 2863)
   ⚠️  Never called

🏗️ _on_component_selected
   📄 Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 2877)
   ⚠️  Never called

🏗️ _update_properties_panel
   📄 Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 2942)
   ⚠️  Never called

🏗️ _clear_properties
   📄 Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 2960)
   ⚠️  Never called

🏗️ _update_properties
   📄 Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 2992)
   ⚠️  Never called

🏗️ _update_selected_position
   📄 Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 3008)
   ⚠️  Never called

🏗️ _update_selected_rotation
   📄 Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 3012)
   ⚠️  Never called

🏗️ _update_selected_scale
   📄 Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 3016)
   ⚠️  Never called

🏗️ _update_status_bar
   📄 Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 3020)
   ⚠️  Never called

🏗️ _load_model
   📄 Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 3043)
   ⚠️  Never called

🏗️ _import_obj
   📄 Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 3099)
   ⚠️  Never called

🏗️ key_for
   📄 Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 3145)
   📞 Called by:
      • Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 3149)

🏗️ add_edge
   📄 Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 3221)
   📞 Called by:
      • Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 3180)
      • Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 3233)
      • Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 3234)
      • Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 3235)

🏗️ _import_gltf
   📄 Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 3187)
   ⚠️  Never called

🏗️ _reset_camera
   📄 Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 3240)
   ⚠️  Never called

🏗️ _show_shortcuts
   📄 Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 3247)
   ⚠️  Never called

🏗️ _build_mgl_program
   📄 Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 3288)
   ⚠️  Never called

🏗️ _proj_matrix
   📄 Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 3315)
   ⚠️  Never called

🏗️ _view_matrix
   📄 Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 3325)
   ⚠️  Never called

🏗️ _rebuild_mgl_buffers
   📄 Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 3344)
   ⚠️  Never called

🏗️ _draw_mgl
   📄 Editors\ModelEditor\examples\PoorPerformanceCreationAndLoading.py (line 3375)
   ⚠️  Never called

🏗️ on_texture_saved
   📄 Editors\TextureEditor\TextureEditor.py (line 259)
   ⚠️  Never called

🏗️ get_texture_data
   📄 Editors\TextureEditor\TextureEditor.py (line 409)
   ⚠️  Never called

🏗️ has_existing_texture_data
   📄 Editors\TextureEditor\TextureEditor.py (line 433)
   ⚠️  Never called

🏗️ load_texture_from_files
   📄 Editors\TextureEditor\TextureEditor.py (line 464)
   ⚠️  Never called

🏗️ create_installed_tab
   📄 UI\CommonDialogs\ExtensionsDialog.py (line 131)
   ⚠️  Never called

🏗️ create_store_tab
   📄 UI\CommonDialogs\ExtensionsDialog.py (line 188)
   ⚠️  Never called

🏗️ load_data_async
   📄 UI\CommonDialogs\ExtensionsDialog.py (line 261)
   ⚠️  Never called

🏗️ on_installed_libraries_loaded
   📄 UI\CommonDialogs\ExtensionsDialog.py (line 280)
   ⚠️  Never called

🏗️ on_top_packages_loaded
   📄 UI\CommonDialogs\ExtensionsDialog.py (line 285)
   ⚠️  Never called

🏗️ on_loading_finished
   📄 UI\CommonDialogs\ExtensionsDialog.py (line 307)
   ⚠️  Never called

🏗️ on_loading_error
   📄 UI\CommonDialogs\ExtensionsDialog.py (line 313)
   ⚠️  Never called

🏗️ load_installed_libraries
   📄 UI\CommonDialogs\ExtensionsDialog.py (line 323)
   ⚠️  Never called

🏗️ check_for_updates
   📄 UI\CommonDialogs\ExtensionsDialog.py (line 399)
   ⚠️  Never called

🏗️ _apply_outdated_to_installed_table
   📄 UI\CommonDialogs\ExtensionsDialog.py (line 426)
   ⚠️  Never called

🏗️ load_store_default
   📄 UI\CommonDialogs\ExtensionsDialog.py (line 471)
   ⚠️  Never called

🏗️ _on_pypi_names_loaded
   📄 UI\CommonDialogs\ExtensionsDialog.py (line 491)
   ⚠️  Never called

🏗️ _on_pypi_load_error
   📄 UI\CommonDialogs\ExtensionsDialog.py (line 511)
   ⚠️  Never called

🏗️ search_store
   📄 UI\CommonDialogs\ExtensionsDialog.py (line 517)
   ⚠️  Never called

🏗️ on_search_complete
   📄 UI\CommonDialogs\ExtensionsDialog.py (line 542)
   ⚠️  Never called

🏗️ on_search_error
   📄 UI\CommonDialogs\ExtensionsDialog.py (line 555)
   ⚠️  Never called

🏗️ clear_search
   📄 UI\CommonDialogs\ExtensionsDialog.py (line 561)
   ⚠️  Never called

🏗️ change_store_page
   📄 UI\CommonDialogs\ExtensionsDialog.py (line 566)
   ⚠️  Never called

🏗️ render_store_table
   📄 UI\CommonDialogs\ExtensionsDialog.py (line 609)
   ⚠️  Never called

🏗️ update_pagination
   📄 UI\CommonDialogs\ExtensionsDialog.py (line 661)
   ⚠️  Never called

🏗️ on_operation_progress
   📄 UI\CommonDialogs\ExtensionsDialog.py (line 760)
   ⚠️  Never called

🏗️ on_package_installed
   📄 UI\CommonDialogs\ExtensionsDialog.py (line 768)
   ⚠️  Never called

🏗️ on_package_updated
   📄 UI\CommonDialogs\ExtensionsDialog.py (line 784)
   ⚠️  Never called

🏗️ on_package_uninstalled
   📄 UI\CommonDialogs\ExtensionsDialog.py (line 796)
   ⚠️  Never called

🏗️ on_filter_changed
   📄 UI\CommonDialogs\ExtensionsDialog.py (line 815)
   ⚠️  Never called

🏗️ filter_installed_table
   📄 UI\CommonDialogs\ExtensionsDialog.py (line 824)
   ⚠️  Never called

🏗️ clear_installed_search
   📄 UI\CommonDialogs\ExtensionsDialog.py (line 851)
   ⚠️  Never called

🏗️ on_tab_changed
   📄 UI\CommonDialogs\ExtensionsDialog.py (line 860)
   ⚠️  Never called

🏗️ on_installed_double_click
   📄 UI\CommonDialogs\ExtensionsDialog.py (line 871)
   ⚠️  Never called

🏗️ on_store_double_click
   📄 UI\CommonDialogs\ExtensionsDialog.py (line 884)
   ⚠️  Never called

🏗️ show_installed_context_menu
   📄 UI\CommonDialogs\ExtensionsDialog.py (line 899)
   ⚠️  Never called

🏗️ show_store_context_menu
   📄 UI\CommonDialogs\ExtensionsDialog.py (line 931)
   ⚠️  Never called

🏗️ install_selected_from_store
   📄 UI\CommonDialogs\ExtensionsDialog.py (line 964)
   ⚠️  Never called

🏗️ _is_core_package
   📄 UI\CommonDialogs\ExtensionsDialog.py (line 982)
   ⚠️  Never called

🏗️ show_package_info
   📄 UI\CommonDialogs\ExtensionsDialog.py (line 1000)
   ⚠️  Never called

🏗️ get_available_animations
   📄 Editors\ImageEditor\core\ui\main_window.py (line 83)
   ⚠️  Never called

🏗️ _detect_features
   📄 Editors\ImageEditor\core\ui\main_window.py (line 104)
   ⚠️  Never called

🏗️ _get_water_pixels
   📄 Editors\ImageEditor\core\ui\main_window.py (line 137)
   📞 Called by:
      • Editors\ImageEditor\core\ui\main_window.py (line 5411)

🏗️ _get_land_pixels
   📄 Editors\ImageEditor\core\ui\main_window.py (line 145)
   ⚠️  Never called

🏗️ _get_green_pixels
   📄 Editors\ImageEditor\core\ui\main_window.py (line 150)
   📞 Called by:
      • Editors\ImageEditor\core\ui\main_window.py (line 5496)

🏗️ _get_sand_pixels
   📄 Editors\ImageEditor\core\ui\main_window.py (line 157)
   📞 Called by:
      • Editors\ImageEditor\core\ui\main_window.py (line 5529)

🏗️ _get_snow_pixels
   📄 Editors\ImageEditor\core\ui\main_window.py (line 164)
   📞 Called by:
      • Editors\ImageEditor\core\ui\main_window.py (line 5562)

🏗️ _detect_shorelines
   📄 Editors\ImageEditor\core\ui\main_window.py (line 171)
   ⚠️  Never called

🏗️ _dilate_mask
   📄 Editors\ImageEditor\core\ui\main_window.py (line 182)
   ⚠️  Never called

🏗️ _rgb_to_hsv
   📄 Editors\ImageEditor\core\ui\main_window.py (line 203)
   ⚠️  Never called

🏗️ _is_animation_applicable
   📄 Editors\ImageEditor\core\ui\main_window.py (line 231)
   ⚠️  Never called

🏗️ _get_animation_display_name
   📄 Editors\ImageEditor\core\ui\main_window.py (line 248)
   ⚠️  Never called

🏗️ _get_animation_description
   📄 Editors\ImageEditor\core\ui\main_window.py (line 261)
   ⚠️  Never called

🏗️ _count_animation_pixels
   📄 Editors\ImageEditor\core\ui\main_window.py (line 274)
   ⚠️  Never called

🏗️ build_global_stylesheet
   📄 Editors\ImageEditor\core\ui\main_window.py (line 291)
   📞 Called by:
      • Editors\ImageEditor\core\ui\main_window.py (line 1095)

🏗️ get_central_widget
   📄 Editors\ImageEditor\core\ui\main_window.py (line 344)
   📞 Called by:
      • Editors\Shared\IntegratedImageEditor.py (line 579)

🏗️ set_embedded_mode
   📄 Editors\ImageEditor\core\ui\main_window.py (line 348)
   ⚠️  Never called

🏗️ show_merge_replace_dialog
   📄 Editors\ImageEditor\core\ui\main_window.py (line 353)
   ⚠️  Never called

🏗️ force_canvas_and_preview_refresh
   📄 Editors\ImageEditor\core\ui\main_window.py (line 359)
   📞 Called by:
      • Editors\ImageEditor\core\ui\texture_atlas_dialog.py (line 902)

🏗️ _setup_menu
   📄 Editors\ImageEditor\core\ui\main_window.py (line 367)
   ⚠️  Never called

🏗️ flip_frame_horizontal
   📄 Editors\ImageEditor\core\ui\main_window.py (line 376)
   ⚠️  Never called

🏗️ flip_frame_vertical
   📄 Editors\ImageEditor\core\ui\main_window.py (line 380)
   ⚠️  Never called

🏗️ rotate_frame_90
   📄 Editors\ImageEditor\core\ui\main_window.py (line 384)
   ⚠️  Never called

🏗️ rotate_frame_180
   📄 Editors\ImageEditor\core\ui\main_window.py (line 388)
   ⚠️  Never called

🏗️ duplicate_frame
   📄 Editors\ImageEditor\core\ui\main_window.py (line 392)
   📞 Called by:
      • Editors\Shared\IntegratedImageEditor.py (line 1244)

🏗️ clear_frame
   📄 Editors\ImageEditor\core\ui\main_window.py (line 433)
   📞 Called by:
      • Editors\Shared\IntegratedImageEditor.py (line 1250)

🏗️ _apply_frame_transform_to_all_layers
   📄 Editors\ImageEditor\core\ui\main_window.py (line 454)
   ⚠️  Never called

🏗️ resize_selection_dialog
   📄 Editors\ImageEditor\core\ui\main_window.py (line 476)
   📞 Called by:
      • Editors\Shared\IntegratedImageEditor.py (line 1226)

🏗️ separate_selection_to_layer
   📄 Editors\ImageEditor\core\ui\main_window.py (line 549)
   ⚠️  Never called

🏗️ generate_tween_animation
   📄 Editors\ImageEditor\core\ui\main_window.py (line 749)
   ⚠️  Never called

🏗️ _setup_shortcuts
   📄 Editors\ImageEditor\core\ui\main_window.py (line 882)
   ⚠️  Never called

🏗️ _handle_shortcut
   📄 Editors\ImageEditor\core\ui\main_window.py (line 956)
   📞 Called by:
      • Editors\ImageEditor\core\ui\components\menu_bar.py (line 321)

🏗️ open_project
   📄 Editors\ImageEditor\core\ui\main_window.py (line 1034)
   ⚠️  Never called

🏗️ new_project
   📄 Editors\ImageEditor\core\ui\main_window.py (line 1039)
   ⚠️  Never called

🏗️ toggle_panels
   📄 Editors\ImageEditor\core\ui\main_window.py (line 1044)
   ⚠️  Never called

🏗️ _setup_status_bar
   📄 Editors\ImageEditor\core\ui\main_window.py (line 1049)
   ⚠️  Never called

🏗️ show_preferences_dialog
   📄 Editors\ImageEditor\core\ui\main_window.py (line 1067)
   ⚠️  Never called

🏗️ new_canvas
   📄 Editors\ImageEditor\core\ui\main_window.py (line 1072)
   ⚠️  Never called

🏗️ _setup_layout
   📄 Editors\ImageEditor\core\ui\main_window.py (line 1100)
   ⚠️  Never called

🏗️ _setup_gpu_canvas_compatibility
   📄 Editors\ImageEditor\core\ui\main_window.py (line 1160)
   ⚠️  Never called

🏗️ update_image
   📄 Editors\ImageEditor\core\ui\main_window.py (line 1166)
   📞 Called by:
      • Editors\ImageEditor\core\ui\main_window.py (line 1228)

🏗️ _on_frame_selected
   📄 Editors\ImageEditor\core\ui\main_window.py (line 1239)
   ⚠️  Never called

🏗️ _on_frame_navigated
   📄 Editors\ImageEditor\core\ui\main_window.py (line 1248)
   ⚠️  Never called

🏗️ _on_layer_selected
   📄 Editors\ImageEditor\core\ui\main_window.py (line 1256)
   ⚠️  Never called

🏗️ import_sprite_sheet
   📄 Editors\ImageEditor\core\ui\main_window.py (line 1323)
   ⚠️  Never called

🏗️ apply_nine_slice
   📄 Editors\ImageEditor\core\ui\main_window.py (line 1552)
   ⚠️  Never called

🏗️ _get_bounding_box
   📄 Editors\ImageEditor\core\ui\main_window.py (line 1735)
   ⚠️  Never called

🏗️ _position_image_with_origin
   📄 Editors\ImageEditor\core\ui\main_window.py (line 1768)
   ⚠️  Never called

🏗️ crop_canvas
   📄 Editors\ImageEditor\core\ui\main_window.py (line 1830)
   📞 Called by:
      • Editors\Shared\IntegratedImageEditor.py (line 1214)

🏗️ _remove_blank_space_from_frame
   📄 Editors\ImageEditor\core\ui\main_window.py (line 1882)
   ⚠️  Never called

🏗️ remove_blank_space
   📄 Editors\ImageEditor\core\ui\main_window.py (line 1957)
   📞 Called by:
      • Editors\Shared\IntegratedImageEditor.py (line 1220)

🏗️ export_image
   📄 Editors\ImageEditor\core\ui\main_window.py (line 2002)
   📞 Called by:
      • Editors\Shared\IntegratedImageEditor.py (line 1169)

🏗️ export_gif
   📄 Editors\ImageEditor\core\ui\main_window.py (line 2063)
   📞 Called by:
      • Editors\Shared\IntegratedImageEditor.py (line 1177)

🏗️ _check_ai_requirements
   📄 Editors\ImageEditor\core\ui\main_window.py (line 2133)
   ⚠️  Never called

🏗️ _get_ai_api_key
   📄 Editors\ImageEditor\core\ui\main_window.py (line 2205)
   ⚠️  Never called

🏗️ _show_ai_key_instructions
   📄 Editors\ImageEditor\core\ui\main_window.py (line 2233)
   ⚠️  Never called

🏗️ ai_assistant
   📄 Editors\ImageEditor\core\ui\main_window.py (line 2255)
   ⚠️  Never called

🏗️ ai_object_removal
   📄 Editors\ImageEditor\core\ui\main_window.py (line 2515)
   ⚠️  Never called

🏗️ ai_generate_animation_frames
   📄 Editors\ImageEditor\core\ui\main_window.py (line 2642)
   ⚠️  Never called

🏗️ _force_complete_refresh
   📄 Editors\ImageEditor\core\ui\main_window.py (line 2789)
   ⚠️  Never called

🏗️ _apply_greyscale_to_frame
   📄 Editors\ImageEditor\core\ui\main_window.py (line 2823)
   ⚠️  Never called

🏗️ effect_image_enhancement
   📄 Editors\ImageEditor\core\ui\main_window.py (line 2940)
   ⚠️  Never called

🏗️ effect_quality_enhancement
   📄 Editors\ImageEditor\core\ui\main_window.py (line 2943)
   ⚠️  Never called

🏗️ effect_atmospheric_lighting
   📄 Editors\ImageEditor\core\ui\main_window.py (line 2996)
   ⚠️  Never called

🏗️ effect_wind_waker
   📄 Editors\ImageEditor\core\ui\main_window.py (line 3006)
   ⚠️  Never called

🏗️ effect_ocarina_of_time
   📄 Editors\ImageEditor\core\ui\main_window.py (line 3016)
   ⚠️  Never called

🏗️ effect_luigis_mansion
   📄 Editors\ImageEditor\core\ui\main_window.py (line 3026)
   ⚠️  Never called

🏗️ effect_eternal_darkness
   📄 Editors\ImageEditor\core\ui\main_window.py (line 3036)
   ⚠️  Never called

🏗️ effect_pokemon_colosseum
   📄 Editors\ImageEditor\core\ui\main_window.py (line 3046)
   ⚠️  Never called

🏗️ effect_mario_kart_8
   📄 Editors\ImageEditor\core\ui\main_window.py (line 3056)
   ⚠️  Never called

🏗️ effect_mirror_flip
   📄 Editors\ImageEditor\core\ui\main_window.py (line 3074)
   ⚠️  Never called

🏗️ effect_rotate
   📄 Editors\ImageEditor\core\ui\main_window.py (line 3083)
   ⚠️  Never called

🏗️ _apply_unified_effect
   📄 Editors\ImageEditor\core\ui\main_window.py (line 3092)
   ⚠️  Never called

🏗️ _apply_effect_to_frame
   📄 Editors\ImageEditor\core\ui\main_window.py (line 3197)
   ⚠️  Never called

🏗️ _process_effect
   📄 Editors\ImageEditor\core\ui\main_window.py (line 3241)
   ⚠️  Never called

🏗️ _apply_torch_lighting_effect
   📄 Editors\ImageEditor\core\ui\main_window.py (line 3272)
   ⚠️  Never called

🏗️ _apply_color_vibrancy
   📄 Editors\ImageEditor\core\ui\main_window.py (line 3440)
   ⚠️  Never called

🏗️ _create_simple_lighting_map
   📄 Editors\ImageEditor\core\ui\main_window.py (line 3459)
   ⚠️  Never called

🏗️ _apply_torch_color_simple
   📄 Editors\ImageEditor\core\ui\main_window.py (line 3480)
   ⚠️  Never called

🏗️ _add_simple_flicker
   📄 Editors\ImageEditor\core\ui\main_window.py (line 3507)
   ⚠️  Never called

🏗️ _apply_simple_lighting
   📄 Editors\ImageEditor\core\ui\main_window.py (line 3522)
   ⚠️  Never called

🏗️ _apply_brightness_contrast
   📄 Editors\ImageEditor\core\ui\main_window.py (line 3544)
   ⚠️  Never called

🏗️ _add_simple_shadows
   📄 Editors\ImageEditor\core\ui\main_window.py (line 3559)
   ⚠️  Never called

🏗️ _apply_cel_shading
   📄 Editors\ImageEditor\core\ui\main_window.py (line 3598)
   ⚠️  Never called

🏗️ _apply_gentle_cel_shading
   📄 Editors\ImageEditor\core\ui\main_window.py (line 3622)
   ⚠️  Never called

🏗️ _detect_light_sources_advanced
   📄 Editors\ImageEditor\core\ui\main_window.py (line 3646)
   ⚠️  Never called

🏗️ _detect_objects_advanced
   📄 Editors\ImageEditor\core\ui\main_window.py (line 3755)
   ⚠️  Never called

🏗️ _find_fallback_light_position
   📄 Editors\ImageEditor\core\ui\main_window.py (line 3817)
   ⚠️  Never called

🏗️ _create_professional_lighting_map
   📄 Editors\ImageEditor\core\ui\main_window.py (line 3862)
   ⚠️  Never called

🏗️ _apply_torch_color_advanced
   📄 Editors\ImageEditor\core\ui\main_window.py (line 3891)
   ⚠️  Never called

🏗️ _add_realistic_flicker
   📄 Editors\ImageEditor\core\ui\main_window.py (line 3915)
   ⚠️  Never called

🏗️ _create_professional_shadow_map
   📄 Editors\ImageEditor\core\ui\main_window.py (line 3935)
   ⚠️  Never called

🏗️ _apply_professional_shadows
   📄 Editors\ImageEditor\core\ui\main_window.py (line 3991)
   ⚠️  Never called

🏗️ _apply_professional_lighting
   📄 Editors\ImageEditor\core\ui\main_window.py (line 4003)
   ⚠️  Never called

🏗️ _add_rim_lighting
   📄 Editors\ImageEditor\core\ui\main_window.py (line 4028)
   ⚠️  Never called

🏗️ _add_professional_atmosphere
   📄 Editors\ImageEditor\core\ui\main_window.py (line 4056)
   ⚠️  Never called

🏗️ _create_shadow_map
   📄 Editors\ImageEditor\core\ui\main_window.py (line 4079)
   ⚠️  Never called

🏗️ _apply_shadows
   📄 Editors\ImageEditor\core\ui\main_window.py (line 4131)
   ⚠️  Never called

🏗️ _apply_lighting_to_image
   📄 Editors\ImageEditor\core\ui\main_window.py (line 4143)
   ⚠️  Never called

🏗️ _add_atmospheric_effects
   📄 Editors\ImageEditor\core\ui\main_window.py (line 4166)
   ⚠️  Never called

🏗️ _apply_vibrant_cel_shading
   📄 Editors\ImageEditor\core\ui\main_window.py (line 4190)
   ⚠️  Never called

🏗️ _reduce_colors_vibrantly
   📄 Editors\ImageEditor\core\ui\main_window.py (line 4227)
   ⚠️  Never called

🏗️ _add_bold_outlines
   📄 Editors\ImageEditor\core\ui\main_window.py (line 4240)
   ⚠️  Never called

🏗️ _reduce_colors
   📄 Editors\ImageEditor\core\ui\main_window.py (line 4281)
   ⚠️  Never called

🏗️ _reduce_colors_lightly
   📄 Editors\ImageEditor\core\ui\main_window.py (line 4291)
   ⚠️  Never called

🏗️ _apply_dithering
   📄 Editors\ImageEditor\core\ui\main_window.py (line 4304)
   ⚠️  Never called

🏗️ _add_outlines
   📄 Editors\ImageEditor\core\ui\main_window.py (line 4366)
   ⚠️  Never called

🏗️ _apply_lighting_effect
   📄 Editors\ImageEditor\core\ui\main_window.py (line 4408)
   ⚠️  Never called

🏗️ _apply_artistic_style
   📄 Editors\ImageEditor\core\ui\main_window.py (line 4489)
   ⚠️  Never called

🏗️ _apply_mirror_flip_effect
   📄 Editors\ImageEditor\core\ui\main_window.py (line 4538)
   ⚠️  Never called

🏗️ _apply_rotate_effect
   📄 Editors\ImageEditor\core\ui\main_window.py (line 4577)
   ⚠️  Never called

🏗️ _fast_ordered_dither
   📄 Editors\ImageEditor\core\ui\main_window.py (line 4633)
   ⚠️  Never called

🏗️ _fast_random_dither
   📄 Editors\ImageEditor\core\ui\main_window.py (line 4669)
   ⚠️  Never called

🏗️ _quantize_minecraft_style
   📄 Editors\ImageEditor\core\ui\main_window.py (line 4711)
   ⚠️  Never called

🏗️ _quantize_retro_style
   📄 Editors\ImageEditor\core\ui\main_window.py (line 4741)
   ⚠️  Never called

🏗️ _quantize_custom_palette
   📄 Editors\ImageEditor\core\ui\main_window.py (line 4773)
   ⚠️  Never called

🏗️ _find_closest_color
   📄 Editors\ImageEditor\core\ui\main_window.py (line 4787)
   ⚠️  Never called

🏗️ hex_to_rgb
   📄 Editors\ImageEditor\core\ui\main_window.py (line 4848)
   📞 Called by:
      • Editors\ImageEditor\core\ui\dialogs\effect_dialog.py (line 2259)
      • Editors\ImageEditor\core\ui\dialogs\effect_dialog.py (line 2260)
      • Editors\ImageEditor\core\ui\dialogs\effect_dialog.py (line 2261)
      • Editors\ImageEditor\core\ui\dialogs\effect_dialog.py (line 2262)
      • Editors\ImageEditor\core\ui\dialogs\effect_dialog.py (line 2271)
      • Editors\ImageEditor\core\ui\dialogs\effect_dialog.py (line 2272)
      • Editors\ImageEditor\core\ui\dialogs\effect_dialog.py (line 2273)
      • Editors\ImageEditor\core\ui\dialogs\effect_dialog.py (line 2274)
      • Editors\ImageEditor\core\ui\dialogs\effect_dialog.py (line 2283)
      • Editors\ImageEditor\core\ui\dialogs\effect_dialog.py (line 2284)
      • Editors\ImageEditor\core\ui\dialogs\effect_dialog.py (line 2285)
      • Editors\ImageEditor\core\ui\dialogs\effect_dialog.py (line 2286)
      • Editors\ImageEditor\core\ui\dialogs\effect_dialog.py (line 2295)
      • Editors\ImageEditor\core\ui\dialogs\effect_dialog.py (line 2296)
      • Editors\ImageEditor\core\ui\dialogs\effect_dialog.py (line 2297)
      • Editors\ImageEditor\core\ui\dialogs\effect_dialog.py (line 2298)
      • Editors\ImageEditor\core\ui\dialogs\effect_dialog.py (line 2320)
      • Editors\ImageEditor\core\ui\dialogs\effect_dialog.py (line 2321)
      • Editors\ImageEditor\core\ui\dialogs\effect_dialog.py (line 2322)
      • Editors\ImageEditor\core\ui\dialogs\effect_dialog.py (line 2323)
      • Editors\ImageEditor\core\ui\dialogs\effect_dialog.py (line 2324)
      • Editors\ImageEditor\core\ui\dialogs\effect_dialog.py (line 2325)
      • Editors\ImageEditor\core\ui\dialogs\effect_dialog.py (line 2326)
      • Editors\ImageEditor\core\ui\dialogs\effect_dialog.py (line 2327)
      • Editors\ImageEditor\core\ui\dialogs\effect_dialog.py (line 2336)
      • Editors\ImageEditor\core\ui\dialogs\effect_dialog.py (line 2348)
      • Editors\ImageEditor\core\ui\dialogs\effect_dialog.py (line 2371)
      • Editors\ImageEditor\core\ui\dialogs\effect_dialog.py (line 2376)
      • Editors\ImageEditor\core\ui\dialogs\effect_dialog.py (line 2386)
      • Editors\ImageEditor\core\ui\dialogs\effect_dialog.py (line 2391)
      • Editors\ImageEditor\core\ui\main_window.py (line 4969)
      • Editors\ImageEditor\core\ui\main_window.py (line 4970)
      • Editors\ImageEditor\core\ui\main_window.py (line 4971)
      • Editors\ImageEditor\core\ui\main_window.py (line 4972)
      • Editors\ImageEditor\core\ui\main_window.py (line 4981)
      • Editors\ImageEditor\core\ui\main_window.py (line 4982)
      • Editors\ImageEditor\core\ui\main_window.py (line 4983)
      • Editors\ImageEditor\core\ui\main_window.py (line 4984)
      • Editors\ImageEditor\core\ui\main_window.py (line 4993)
      • Editors\ImageEditor\core\ui\main_window.py (line 4994)
      • Editors\ImageEditor\core\ui\main_window.py (line 4995)
      • Editors\ImageEditor\core\ui\main_window.py (line 4996)
      • Editors\ImageEditor\core\ui\main_window.py (line 5005)
      • Editors\ImageEditor\core\ui\main_window.py (line 5006)
      • Editors\ImageEditor\core\ui\main_window.py (line 5007)
      • Editors\ImageEditor\core\ui\main_window.py (line 5008)
      • Editors\ImageEditor\core\ui\main_window.py (line 5030)
      • Editors\ImageEditor\core\ui\main_window.py (line 5031)
      • Editors\ImageEditor\core\ui\main_window.py (line 5032)
      • Editors\ImageEditor\core\ui\main_window.py (line 5033)
      • Editors\ImageEditor\core\ui\main_window.py (line 5034)
      • Editors\ImageEditor\core\ui\main_window.py (line 5035)
      • Editors\ImageEditor\core\ui\main_window.py (line 5036)
      • Editors\ImageEditor\core\ui\main_window.py (line 5037)
      • Editors\ImageEditor\core\ui\main_window.py (line 5046)
      • Editors\ImageEditor\core\ui\main_window.py (line 5058)
      • Editors\ImageEditor\core\ui\main_window.py (line 5081)
      • Editors\ImageEditor\core\ui\main_window.py (line 5086)
      • Editors\ImageEditor\core\ui\main_window.py (line 5096)
      • Editors\ImageEditor\core\ui\main_window.py (line 5101)

🏗️ _apply_map_animations
   📄 Editors\ImageEditor\core\ui\main_window.py (line 5125)
   ⚠️  Never called

🏗️ _apply_shoreline_waves
   📄 Editors\ImageEditor\core\ui\main_window.py (line 5160)
   ⚠️  Never called

🏗️ _detect_deep_water_simple
   📄 Editors\ImageEditor\core\ui\main_window.py (line 5238)
   ⚠️  Never called

🏗️ _find_ocean_shorelines
   📄 Editors\ImageEditor\core\ui\main_window.py (line 5258)
   ⚠️  Never called

🏗️ _is_connected_to_deep_water
   📄 Editors\ImageEditor\core\ui\main_window.py (line 5290)
   ⚠️  Never called

🏗️ _get_wave_flow_direction
   📄 Editors\ImageEditor\core\ui\main_window.py (line 5304)
   ⚠️  Never called

🏗️ _detect_shallow_water
   📄 Editors\ImageEditor\core\ui\main_window.py (line 5339)
   ⚠️  Never called

🏗️ _detect_sand_areas
   📄 Editors\ImageEditor\core\ui\main_window.py (line 5361)
   ⚠️  Never called

🏗️ _find_shallow_water_sand_boundary
   📄 Editors\ImageEditor\core\ui\main_window.py (line 5379)
   ⚠️  Never called

🏗️ _apply_ocean_currents
   📄 Editors\ImageEditor\core\ui\main_window.py (line 5405)
   ⚠️  Never called

🏗️ _detect_deep_water
   📄 Editors\ImageEditor\core\ui\main_window.py (line 5445)
   ⚠️  Never called

🏗️ _is_away_from_shoreline
   📄 Editors\ImageEditor\core\ui\main_window.py (line 5470)
   ⚠️  Never called

🏗️ _apply_wind_sway
   📄 Editors\ImageEditor\core\ui\main_window.py (line 5490)
   ⚠️  Never called

🏗️ _apply_sand_dunes
   📄 Editors\ImageEditor\core\ui\main_window.py (line 5523)
   ⚠️  Never called

🏗️ _apply_snow_drift
   📄 Editors\ImageEditor\core\ui\main_window.py (line 5556)
   ⚠️  Never called

🏗️ _apply_rain_effects
   📄 Editors\ImageEditor\core\ui\main_window.py (line 5589)
   ⚠️  Never called

🏗️ _apply_fog_effects
   📄 Editors\ImageEditor\core\ui\main_window.py (line 5616)
   ⚠️  Never called

🏗️ _create_animated_texture_frames
   📄 Editors\ImageEditor\core\ui\main_window.py (line 5739)
   ⚠️  Never called

🏗️ _handle_animated_texture_creation
   📄 Editors\ImageEditor\core\ui\main_window.py (line 5849)
   ⚠️  Never called

🏗️ _apply_texture_atlas_effect
   📄 Editors\ImageEditor\core\ui\main_window.py (line 5976)
   ⚠️  Never called

🏗️ _apply_effect_over_frames
   📄 Editors\ImageEditor\core\ui\main_window.py (line 6088)
   ⚠️  Never called

🏗️ _interpolate_parameters
   📄 Editors\ImageEditor\core\ui\main_window.py (line 6137)
   ⚠️  Never called

🏗️ _apply_effect_to_frame_merge
   📄 Editors\ImageEditor\core\ui\main_window.py (line 6178)
   ⚠️  Never called

🏗️ _merge_images
   📄 Editors\ImageEditor\core\ui\main_window.py (line 6229)
   ⚠️  Never called

🏗️ apply_image_to_canvas
   📄 Editors\ImageEditor\core\ui\main_window.py (line 6245)
   📞 Called by:
      • Editors\ImageEditor\core\ui\character_creator_dialog.py (line 2196)

🏗️ open_advanced_atlas_dialog
   📄 Editors\ImageEditor\core\ui\main_window.py (line 6253)
   📞 Called by:
      • Editors\Shared\IntegratedImageEditor.py (line 1611)

🏗️ open_character_creator
   📄 Editors\ImageEditor\core\ui\main_window.py (line 6258)
   📞 Called by:
      • Editors\Shared\IntegratedImageEditor.py (line 1615)

🏗️ toggle_pixel_perfect
   📄 Editors\ImageEditor\core\ui\main_window.py (line 6263)
   ⚠️  Never called

🏗️ _handle_lod_export
   📄 Editors\ImageEditor\core\ui\main_window.py (line 6281)
   ⚠️  Never called

🏗️ get_effects_menu_structure
   📄 Editors\ImageEditor\core\ui\main_window.py (line 6353)
   📞 Called by:
      • Editors\Shared\IntegratedImageEditor.py (line 349)

🏗️ get_edit_menu_structure
   📄 Editors\ImageEditor\core\ui\main_window.py (line 6376)
   📞 Called by:
      • Editors\Shared\IntegratedImageEditor.py (line 378)

🏗️ _extract_menu_data
   📄 Editors\ImageEditor\core\ui\main_window.py (line 6399)
   ⚠️  Never called

🏗️ _get_action_method_name
   📄 Editors\ImageEditor\core\ui\main_window.py (line 6431)
   ⚠️  Never called

🏗️ _map_action_to_method
   📄 Editors\ImageEditor\core\ui\main_window.py (line 6436)
   ⚠️  Never called

🏗️ estimate_file_size
   📄 UI\MainWindow\MainWindow.py (line 213)
   ⚠️  Never called

🏗️ save_current_recording
   📄 UI\MainWindow\MainWindow.py (line 220)
   ⚠️  Never called

🏗️ setup_toolbar
   📄 UI\MainWindow\MainWindow.py (line 566)
   ⚠️  Never called

🏗️ setup_status_bar
   📄 UI\MainWindow\MainWindow.py (line 570)
   ⚠️  Never called

🏗️ save_settings
   📄 UI\MainWindow\MainWindow.py (line 586)
   ⚠️  Never called

🏗️ run_game
   📄 UI\MainWindow\MainWindow.py (line 957)
   ⚠️  Never called

🏗️ close_editor_tab
   📄 UI\MainWindow\MainWindow.py (line 732)
   ⚠️  Never called

🏗️ close_all_editor_tabs
   📄 UI\MainWindow\MainWindow.py (line 736)
   📞 Called by:
      • Core\ProjectManager.py (line 123)
      • Core\ProjectManager.py (line 254)

🏗️ reload_project
   📄 UI\MainWindow\MainWindow.py (line 748)
   ⚠️  Never called

🏗️ on_project_loaded
   📄 UI\MainWindow\MainWindow.py (line 765)
   ⚠️  Never called

🏗️ on_resources_loaded
   📄 UI\MainWindow\MainWindow.py (line 781)
   ⚠️  Never called

🏗️ on_project_created
   📄 UI\MainWindow\MainWindow.py (line 792)
   ⚠️  Never called

🏗️ show_about
   📄 UI\MainWindow\MainWindow.py (line 828)
   ⚠️  Never called

🏗️ _current_editor
   📄 UI\MainWindow\MainWindow.py (line 834)
   ⚠️  Never called

🏗️ _dispatch_edit_action
   📄 UI\MainWindow\MainWindow.py (line 840)
   ⚠️  Never called

🏗️ rename_action
   📄 UI\MainWindow\MainWindow.py (line 927)
   ⚠️  Never called

🏗️ create_folder_action
   📄 UI\MainWindow\MainWindow.py (line 937)
   ⚠️  Never called

🏗️ create_resource_action
   📄 UI\MainWindow\MainWindow.py (line 947)
   ⚠️  Never called

🏗️ debug_game
   📄 UI\MainWindow\MainWindow.py (line 1051)
   ⚠️  Never called

🏗️ build_game
   📄 UI\MainWindow\MainWindow.py (line 1142)
   ⚠️  Never called

🏗️ backup_editor
   📄 UI\MainWindow\MainWindow.py (line 1208)
   ⚠️  Never called

🏗️ progress_callback
   📄 UI\MainWindow\MainWindow.py (line 1590)
   📞 Called by:
      • Tools\BackupManager\BackupManager.py (line 309)
      • Tools\BackupManager\BackupManager.py (line 498)
      • Tools\BackupManager\BackupManager.py (line 524)

🏗️ backup_project
   📄 UI\MainWindow\MainWindow.py (line 1300)
   ⚠️  Never called

🏗️ restore_editor
   📄 UI\MainWindow\MainWindow.py (line 1414)
   ⚠️  Never called

🏗️ restore_project
   📄 UI\MainWindow\MainWindow.py (line 1533)
   ⚠️  Never called

🏗️ open_extensions_manager
   📄 UI\MainWindow\MainWindow.py (line 1657)
   ⚠️  Never called

🏗️ open_ai_assistant
   📄 UI\MainWindow\MainWindow.py (line 1663)
   ⚠️  Never called

🏗️ on_preferences_changed
   📄 UI\MainWindow\MainWindow.py (line 1722)
   ⚠️  Never called

🏗️ toggle_recording
   📄 UI\MainWindow\MainWindow.py (line 1812)
   ⚠️  Never called

🏗️ on_recording_file_saved
   📄 UI\MainWindow\MainWindow.py (line 1884)
   ⚠️  Never called

🏗️ on_recording_stopped
   📄 UI\MainWindow\MainWindow.py (line 1889)
   ⚠️  Never called

🏗️ update_recording_menu
   📄 UI\MainWindow\MainWindow.py (line 1894)
   ⚠️  Never called

🏗️ compress_recordings_auto
   📄 UI\MainWindow\MainWindow.py (line 1903)
   ⚠️  Never called

🏗️ view_recordings
   📄 UI\MainWindow\MainWindow.py (line 1975)
   ⚠️  Never called

🏗️ get_recordings_folder
   📄 UI\MainWindow\MainWindow.py (line 1995)
   ⚠️  Never called

🏗️ update_bg_color_display
   📄 Editors\ImageEditor\core\ui\nine_slice_importer.py (line 317)
   ⚠️  Never called

🏗️ remove_background_with_tolerance
   📄 Editors\ImageEditor\core\ui\nine_slice_importer.py (line 397)
   ⚠️  Never called

🏗️ auto_crop_image
   📄 Editors\ImageEditor\core\ui\nine_slice_importer.py (line 414)
   ⚠️  Never called

🏗️ detect_sprite_bboxes
   📄 Editors\ImageEditor\core\ui\nine_slice_importer.py (line 433)
   ⚠️  Never called

🏗️ split_touching_sprites
   📄 Editors\ImageEditor\core\ui\nine_slice_importer.py (line 484)
   ⚠️  Never called

🏗️ sort_sprites_by_position
   📄 Editors\ImageEditor\core\ui\nine_slice_importer.py (line 557)
   ⚠️  Never called

🏗️ extract_sprites_from_bboxes
   📄 Editors\ImageEditor\core\ui\nine_slice_importer.py (line 600)
   ⚠️  Never called

🏗️ center_sprite_in_canvas
   📄 Editors\ImageEditor\core\ui\nine_slice_importer.py (line 668)
   ⚠️  Never called

🏗️ update_preview_with_bboxes
   📄 Editors\ImageEditor\core\ui\nine_slice_importer.py (line 711)
   ⚠️  Never called

🏗️ update_style
   📄 Editors\ImageEditor\core\ui\panels\right_panel.py (line 84)
   ⚠️  Never called

🏗️ set_selected
   📄 Editors\ImageEditor\core\ui\panels\right_panel.py (line 90)
   ⚠️  Never called

🏗️ on_clicked
   📄 Editors\ImageEditor\core\ui\panels\right_panel.py (line 95)
   ⚠️  Never called

🏗️ update_tabs
   📄 Editors\ImageEditor\core\ui\panels\right_panel.py (line 163)
   📞 Called by:
      • Editors\ImageEditor\core\ui\panels\right_panel.py (line 114)
      • Editors\ImageEditor\core\ui\panels\right_panel.py (line 131)
      • Editors\ImageEditor\core\ui\panels\right_panel.py (line 544)
      • Editors\ImageEditor\core\ui\panels\right_panel.py (line 561)
      • Editors\ImageEditor\core\ui\panels\right_panel.py (line 578)
      • Editors\ImageEditor\core\ui\panels\right_panel.py (line 592)
      • Editors\ImageEditor\core\ui\panels\right_panel.py (line 609)
      • Editors\ImageEditor\core\ui\panels\right_panel.py (line 851)
      • Editors\ImageEditor\core\ui\main_window.py (line 1263)

🏗️ select_layer
   📄 Editors\ImageEditor\core\ui\panels\right_panel.py (line 178)
   📞 Called by:
      • Editors\ImageEditor\core\ui\panels\right_panel.py (line 96)

🏗️ switch_to_layer
   📄 Editors\ImageEditor\core\ui\panels\right_panel.py (line 189)
   📞 Called by:
      • Editors\ImageEditor\core\ui\panels\right_panel.py (line 100)

🏗️ delete_selected_layer
   📄 Editors\ImageEditor\core\ui\panels\right_panel.py (line 192)
   ⚠️  Never called

🏗️ delete_layer
   📄 Editors\ImageEditor\core\ui\panels\right_panel.py (line 195)
   📞 Called by:
      • Editors\ImageEditor\core\ui\panels\right_panel.py (line 117)

🏗️ rename_selected_layer
   📄 Editors\ImageEditor\core\ui\panels\right_panel.py (line 220)
   ⚠️  Never called

🏗️ rename_layer
   📄 Editors\ImageEditor\core\ui\panels\right_panel.py (line 223)
   📞 Called by:
      • Editors\ImageEditor\core\ui\panels\right_panel.py (line 121)

🏗️ toggle_visibility_selected_layer
   📄 Editors\ImageEditor\core\ui\panels\right_panel.py (line 231)
   ⚠️  Never called

🏗️ set_highlight_color
   📄 Editors\ImageEditor\core\ui\panels\right_panel.py (line 242)
   📞 Called by:
      • Editors\ImageEditor\core\ui\panels\right_panel.py (line 497)

🏗️ set_selected_layer_depth_dialog
   📄 Editors\ImageEditor\core\ui\panels\right_panel.py (line 246)
   ⚠️  Never called

🏗️ add_layer_and_refresh
   📄 Editors\ImageEditor\core\ui\panels\right_panel.py (line 379)
   ⚠️  Never called

🏗️ delete_layer_and_refresh
   📄 Editors\ImageEditor\core\ui\panels\right_panel.py (line 385)
   ⚠️  Never called

🏗️ rename_layer_and_refresh
   📄 Editors\ImageEditor\core\ui\panels\right_panel.py (line 391)
   ⚠️  Never called

🏗️ update_scroll_area_height
   📄 Editors\ImageEditor\core\ui\panels\right_panel.py (line 407)
   📞 Called by:
      • Editors\ImageEditor\core\ui\panels\right_panel.py (line 412)
      • Editors\ImageEditor\core\ui\panels\right_panel.py (line 414)

🏗️ get_highlight_color
   📄 Editors\ImageEditor\core\ui\panels\right_panel.py (line 498)
   ⚠️  Never called

🏗️ update_frame_label
   📄 Editors\ImageEditor\core\ui\panels\right_panel.py (line 512)
   📞 Called by:
      • Editors\ImageEditor\core\ui\main_window.py (line 1245)
      • Editors\ImageEditor\core\ui\main_window.py (line 1253)
      • Editors\ImageEditor\core\ui\main_window.py (line 1262)
      • Editors\ImageEditor\core\ui\main_window.py (line 1271)
      • Editors\ImageEditor\core\ui\main_window.py (line 1279)
      • Editors\ImageEditor\core\ui\main_window.py (line 1490)
      • Editors\ImageEditor\core\ui\main_window.py (line 1731)
      • Editors\ImageEditor\core\ui\main_window.py (line 1880)
      • Editors\ImageEditor\core\ui\main_window.py (line 2000)
      • Editors\ImageEditor\core\ui\main_window.py (line 2061)
      • Editors\ImageEditor\core\ui\main_window.py (line 2097)

🏗️ _clear_canvas_overlays
   📄 Editors\ImageEditor\core\ui\panels\right_panel.py (line 519)
   ⚠️  Never called

🏗️ delete_frame
   📄 Editors\ImageEditor\core\ui\panels\right_panel.py (line 552)
   ⚠️  Never called

🏗️ copy_frame
   📄 Editors\ImageEditor\core\ui\panels\right_panel.py (line 569)
   ⚠️  Never called

🏗️ play_next_frame
   📄 Editors\ImageEditor\core\ui\panels\right_panel.py (line 637)
   ⚠️  Never called

🏗️ on_speed_text_changed
   📄 Editors\ImageEditor\core\ui\panels\right_panel.py (line 652)
   ⚠️  Never called

🏗️ increase_speed
   📄 Editors\ImageEditor\core\ui\panels\right_panel.py (line 671)
   ⚠️  Never called

🏗️ decrease_speed
   📄 Editors\ImageEditor\core\ui\panels\right_panel.py (line 684)
   ⚠️  Never called

🏗️ on_speed_slider_changed
   📄 Editors\ImageEditor\core\ui\panels\right_panel.py (line 697)
   ⚠️  Never called

🏗️ _toggle_current_layer_controls
   📄 Editors\ImageEditor\core\ui\panels\right_panel.py (line 708)
   ⚠️  Never called

🏗️ _update_current_layer_controls
   📄 Editors\ImageEditor\core\ui\panels\right_panel.py (line 712)
   ⚠️  Never called

🏗️ _set_onion_setting
   📄 Editors\ImageEditor\core\ui\panels\right_panel.py (line 731)
   ⚠️  Never called

🏗️ _pick_onion_color
   📄 Editors\ImageEditor\core\ui\panels\right_panel.py (line 737)
   ⚠️  Never called

🏗️ _refresh_other_layers_section
   📄 Editors\ImageEditor\core\ui\panels\right_panel.py (line 752)
   ⚠️  Never called

🏗️ _pick_other_onion_color
   📄 Editors\ImageEditor\core\ui\panels\right_panel.py (line 835)
   ⚠️  Never called

🏗️ _connect_layer_selection
   📄 Editors\ImageEditor\core\ui\panels\right_panel.py (line 844)
   ⚠️  Never called

🏗️ _refresh_timeline
   📄 Editors\ImageEditor\core\ui\panels\right_panel.py (line 860)
   ⚠️  Never called

🏗️ _toggle_timeline
   📄 Editors\ImageEditor\core\ui\panels\right_panel.py (line 868)
   ⚠️  Never called

🏗️ resolve_material_from_obj_mtl
   📄 Editors\ModelEditor\ModelEditor.py (line 87)
   ⚠️  Never called

🏗️ resolve_material_from_dae
   📄 Editors\ModelEditor\ModelEditor.py (line 109)
   ⚠️  Never called

🏗️ resolve_material_from_gltf
   📄 Editors\ModelEditor\ModelEditor.py (line 141)
   ⚠️  Never called

🏗️ _resolve_texture_path
   📄 Editors\ModelEditor\ModelEditor.py (line 166)
   ⚠️  Never called

🏗️ find_textures_in_directory
   📄 Editors\ModelEditor\ModelEditor.py (line 197)
   ⚠️  Never called

🏗️ auto_assign_textures
   📄 Editors\ModelEditor\ModelEditor.py (line 239)
   ⚠️  Never called

🏗️ length_squared
   📄 Editors\ModelEditor\ModelEditor.py (line 272)
   ⚠️  Never called

🏗️ add_keyframe
   📄 Editors\ModelEditor\ModelEditor.py (line 304)
   📞 Called by:
      • Editors\ImageEditor\core\ui\main_window.py (line 877)

🏗️ evaluate
   📄 Editors\ModelEditor\ModelEditor.py (line 333)
   ⚠️  Never called

🏗️ _interpolate_vector
   📄 Editors\ModelEditor\ModelEditor.py (line 373)
   ⚠️  Never called

🏗️ _interpolate_quaternion
   📄 Editors\ModelEditor\ModelEditor.py (line 406)
   ⚠️  Never called

🏗️ _slerp
   📄 Editors\ModelEditor\ModelEditor.py (line 431)
   ⚠️  Never called

🏗️ get_node_names
   📄 Editors\ModelEditor\ModelEditor.py (line 469)
   ⚠️  Never called

🏗️ get_gl_position
   📄 Editors\ModelEditor\ModelEditor.py (line 494)
   ⚠️  Never called

🏗️ get_gl_color
   📄 Editors\ModelEditor\ModelEditor.py (line 501)
   ⚠️  Never called

🏗️ _populate_textures
   📄 Editors\ModelEditor\ModelEditor.py (line 579)
   ⚠️  Never called

🏗️ _on_texture_hover
   📄 Editors\ModelEditor\ModelEditor.py (line 659)
   ⚠️  Never called

🏗️ _check_hover_item
   📄 Editors\ModelEditor\ModelEditor.py (line 674)
   ⚠️  Never called

🏗️ _show_context_menu
   📄 Editors\ModelEditor\ModelEditor.py (line 694)
   ⚠️  Never called

🏗️ _edit_texture
   📄 Editors\ModelEditor\ModelEditor.py (line 711)
   ⚠️  Never called

🏗️ _assign_texture
   📄 Editors\ModelEditor\ModelEditor.py (line 825)
   ⚠️  Never called

🏗️ _toggle_texture
   📄 Editors\ModelEditor\ModelEditor.py (line 905)
   ⚠️  Never called

🏗️ get_enabled_textures
   📄 Editors\ModelEditor\ModelEditor.py (line 974)
   ⚠️  Never called

🏗️ get_disabled_textures
   📄 Editors\ModelEditor\ModelEditor.py (line 984)
   ⚠️  Never called

🏗️ _initialize_default_lights
   📄 Editors\ModelEditor\ModelEditor.py (line 1092)
   ⚠️  Never called

🏗️ _create_toon_ramp_texture
   📄 Editors\ModelEditor\ModelEditor.py (line 1101)
   ⚠️  Never called

🏗️ _setup_lighting
   📄 Editors\ModelEditor\ModelEditor.py (line 1186)
   ⚠️  Never called

🏗️ _get_light_position
   📄 Editors\ModelEditor\ModelEditor.py (line 1419)
   ⚠️  Never called

🏗️ _load_texture_if_needed
   📄 Editors\ModelEditor\ModelEditor.py (line 1520)
   ⚠️  Never called

🏗️ _draw_skyline
   📄 Editors\ModelEditor\ModelEditor.py (line 1566)
   ⚠️  Never called

🏗️ _draw_model
   📄 Editors\ModelEditor\ModelEditor.py (line 1879)
   ⚠️  Never called

🏗️ _pick_material
   📄 Editors\ModelEditor\ModelEditor.py (line 2294)
   ⚠️  Never called

🏗️ _show_texture_info_menu
   📄 Editors\ModelEditor\ModelEditor.py (line 2428)
   ⚠️  Never called

🏗️ _edit_texture_from_context
   📄 Editors\ModelEditor\ModelEditor.py (line 2497)
   ⚠️  Never called

🏗️ _pick_material_simple
   📄 Editors\ModelEditor\ModelEditor.py (line 2525)
   ⚠️  Never called

🏗️ _tick
   📄 Editors\ModelEditor\ModelEditor.py (line 2581)
   ⚠️  Never called

🏗️ _obj_index_to_zero_based
   📄 Editors\ModelEditor\ModelEditor.py (line 2654)
   ⚠️  Never called

🏗️ _load_mtl
   📄 Editors\ModelEditor\ModelEditor.py (line 2948)
   📞 Called by:
      • Editors\ModelEditor\ModelEditor.py (line 10713)
      • Editors\ModelEditor\ModelEditor.py (line 11523)
      • Editors\ModelEditor\ModelEditor.py (line 11963)

🏗️ _find_and_select_mtl_file
   📄 Editors\ModelEditor\ModelEditor.py (line 3081)
   ⚠️  Never called

🏗️ load_textures_from_files
   📄 Editors\ModelEditor\ModelEditor.py (line 3157)
   📞 Called by:
      • Editors\ModelEditor\ModelEditor.py (line 877)
      • Editors\ModelEditor\ModelEditor.py (line 10834)
      • Editors\ModelEditor\ModelEditor.py (line 10875)
      • Editors\ModelEditor\ModelEditor.py (line 11545)
      • Editors\ModelEditor\ModelEditor.py (line 11676)
      • Editors\ModelEditor\ModelEditor.py (line 11772)
      • Editors\ModelEditor\ModelEditor.py (line 11972)

🏗️ _setup_eye_texture_blending
   📄 Editors\ModelEditor\ModelEditor.py (line 3489)
   ⚠️  Never called

🏗️ _load_texture_image
   📄 Editors\ModelEditor\ModelEditor.py (line 3579)
   ⚠️  Never called

🏗️ _cleanup_textures
   📄 Editors\ModelEditor\ModelEditor.py (line 3639)
   ⚠️  Never called

🏗️ load_gltf
   📄 Editors\ModelEditor\ModelEditor.py (line 3710)
   📞 Called by:
      • Editors\ModelEditor\ModelEditor.py (line 8173)
      • Editors\ModelEditor\ModelEditor.py (line 10718)

🏗️ load_dae
   📄 Editors\ModelEditor\ModelEditor.py (line 3888)
   📞 Called by:
      • Editors\ModelEditor\ModelEditor.py (line 8175)
      • Editors\ModelEditor\ModelEditor.py (line 10720)

🏗️ _extract_gltf_textures
   📄 Editors\ModelEditor\ModelEditor.py (line 4143)
   ⚠️  Never called

🏗️ _extract_dae_textures
   📄 Editors\ModelEditor\ModelEditor.py (line 4406)
   ⚠️  Never called

🏗️ load_g3d
   📄 Editors\ModelEditor\ModelEditor.py (line 4681)
   📞 Called by:
      • Editors\ModelEditor\ModelEditor.py (line 8177)

🏗️ _parse_g3d_mesh_chunk
   📄 Editors\ModelEditor\ModelEditor.py (line 4845)
   ⚠️  Never called

🏗️ _parse_g3d_animation_chunk
   📄 Editors\ModelEditor\ModelEditor.py (line 4940)
   ⚠️  Never called

🏗️ _parse_g3d_texture_chunk
   📄 Editors\ModelEditor\ModelEditor.py (line 5048)
   ⚠️  Never called

🏗️ _parse_g3d_material_chunk
   📄 Editors\ModelEditor\ModelEditor.py (line 5114)
   ⚠️  Never called

🏗️ _parse_g3d_skeleton_chunk
   📄 Editors\ModelEditor\ModelEditor.py (line 5189)
   ⚠️  Never called

🏗️ load_json_model
   📄 Editors\ModelEditor\ModelEditor.py (line 5272)
   📞 Called by:
      • Editors\ModelEditor\ModelEditor.py (line 8179)
      • Editors\ModelEditor\ModelEditor.py (line 10722)

🏗️ _extract_dae_animations
   📄 Editors\ModelEditor\ModelEditor.py (line 5435)
   ⚠️  Never called

🏗️ _parse_collada_animation
   📄 Editors\ModelEditor\ModelEditor.py (line 5576)
   ⚠️  Never called

🏗️ _scan_for_external_animation_files
   📄 Editors\ModelEditor\ModelEditor.py (line 5596)
   ⚠️  Never called

🏗️ _extract_animations_from_scene
   📄 Editors\ModelEditor\ModelEditor.py (line 5675)
   ⚠️  Never called

🏗️ _parse_gltf_animations
   📄 Editors\ModelEditor\ModelEditor.py (line 5754)
   ⚠️  Never called

🏗️ _parse_gltf_accessor
   📄 Editors\ModelEditor\ModelEditor.py (line 5835)
   ⚠️  Never called

🏗️ _evaluate_animation_pose
   📄 Editors\ModelEditor\ModelEditor.py (line 5910)
   📞 Called by:
      • Editors\ModelEditor\ModelEditor.py (line 9732)
      • Editors\ModelEditor\ModelEditor.py (line 9831)
      • Editors\ModelEditor\ModelEditor.py (line 9868)
      • Editors\ModelEditor\ModelEditor.py (line 9903)

🏗️ _calculate_normals
   📄 Editors\ModelEditor\ModelEditor.py (line 5946)
   📞 Called by:
      • Editors\ModelEditor\ModelEditor.py (line 10540)

🏗️ _calculate_face_normals
   📄 Editors\ModelEditor\ModelEditor.py (line 5987)
   ⚠️  Never called

🏗️ _recalculate_normals_for_style
   📄 Editors\ModelEditor\ModelEditor.py (line 6027)
   📞 Called by:
      • Editors\ModelEditor\ModelEditor.py (line 9018)
      • Editors\ModelEditor\ModelEditor.py (line 10102)

🏗️ _get_speed_multiplier
   📄 Editors\ModelEditor\ModelEditor.py (line 6083)
   ⚠️  Never called

🏗️ _clamp_camera_position
   📄 Editors\ModelEditor\ModelEditor.py (line 6110)
   ⚠️  Never called

🏗️ _clamp_camera_position_outside_model
   📄 Editors\ModelEditor\ModelEditor.py (line 6121)
   ⚠️  Never called

🏗️ _center_and_scale
   📄 Editors\ModelEditor\ModelEditor.py (line 6170)
   ⚠️  Never called

🏗️ _delete_vertices
   📄 Editors\ModelEditor\ModelEditor.py (line 6571)
   📞 Called by:
      • Editors\ModelEditor\ModelEditor.py (line 9619)

🏗️ load_from_preview
   📄 Editors\ModelEditor\ModelEditor.py (line 6636)
   ⚠️  Never called

🏗️ _convert_vertices_to_edges_only
   📄 Editors\ModelEditor\ModelEditor.py (line 6665)
   ⚠️  Never called

🏗️ _convert_vertices_to_edges
   📄 Editors\ModelEditor\ModelEditor.py (line 6709)
   ⚠️  Never called

🏗️ export_to_preview
   📄 Editors\ModelEditor\ModelEditor.py (line 6740)
   📞 Called by:
      • Editors\ModelEditor\ModelEditor.py (line 9531)

🏗️ _detect_edit_faces
   📄 Editors\ModelEditor\ModelEditor.py (line 6888)
   ⚠️  Never called

🏗️ _rebuild_edit_geometry
   📄 Editors\ModelEditor\ModelEditor.py (line 6906)
   ⚠️  Never called

🏗️ add_vertex
   📄 Editors\ModelEditor\ModelEditor.py (line 7031)
   📞 Called by:
      • Editors\ModelEditor\ModelEditor.py (line 6951)
      • Editors\ModelEditor\ModelEditor.py (line 6953)
      • Editors\ModelEditor\ModelEditor.py (line 6954)
      • Editors\ModelEditor\ModelEditor.py (line 7043)
      • Editors\ModelEditor\ModelEditor.py (line 7045)
      • Editors\ModelEditor\ModelEditor.py (line 7046)

🏗️ _rebuild_geometry
   📄 Editors\ModelEditor\ModelEditor.py (line 6993)
   📞 Called by:
      • Editors\ModelEditor\ModelEditor.py (line 9644)

🏗️ _draw_edit_geometry
   📄 Editors\ModelEditor\ModelEditor.py (line 7092)
   ⚠️  Never called

🏗️ _draw_draw_preview
   📄 Editors\ModelEditor\ModelEditor.py (line 7128)
   ⚠️  Never called

🏗️ _ray_intersect_vertex
   📄 Editors\ModelEditor\ModelEditor.py (line 7368)
   ⚠️  Never called

🏗️ _ray_intersect_edge
   📄 Editors\ModelEditor\ModelEditor.py (line 7384)
   ⚠️  Never called

🏗️ _ray_intersect_face
   📄 Editors\ModelEditor\ModelEditor.py (line 7451)
   ⚠️  Never called

🏗️ _update_hovered_elements
   📄 Editors\ModelEditor\ModelEditor.py (line 7502)
   ⚠️  Never called

🏗️ _handle_selection
   📄 Editors\ModelEditor\ModelEditor.py (line 7657)
   ⚠️  Never called

🏗️ _draw_selection_highlights
   📄 Editors\ModelEditor\ModelEditor.py (line 7690)
   ⚠️  Never called

🏗️ _start_transform
   📄 Editors\ModelEditor\ModelEditor.py (line 7848)
   ⚠️  Never called

🏗️ _update_transform
   📄 Editors\ModelEditor\ModelEditor.py (line 7905)
   ⚠️  Never called

🏗️ _finish_transform
   📄 Editors\ModelEditor\ModelEditor.py (line 8086)
   ⚠️  Never called

🏗️ _handle_tool_click
   📄 Editors\ModelEditor\ModelEditor.py (line 8114)
   ⚠️  Never called

🏗️ _build_menu
   📄 Editors\ModelEditor\ModelEditor.py (line 8140)
   ⚠️  Never called

🏗️ _open_model
   📄 Editors\ModelEditor\ModelEditor.py (line 8163)
   ⚠️  Never called

🏗️ _on_resource_updated
   📄 Editors\ModelEditor\ModelEditor.py (line 8215)
   ⚠️  Never called

🏗️ setup_preview_mode
   📄 Editors\ModelEditor\ModelEditor.py (line 8355)
   ⚠️  Never called

🏗️ setup_edit_mode
   📄 Editors\ModelEditor\ModelEditor.py (line 8382)
   ⚠️  Never called

🏗️ _on_model_lit_changed
   📄 Editors\ModelEditor\ModelEditor.py (line 8899)
   ⚠️  Never called

🏗️ _on_external_light_changed
   📄 Editors\ModelEditor\ModelEditor.py (line 8908)
   ⚠️  Never called

🏗️ _pick_light_color
   📄 Editors\ModelEditor\ModelEditor.py (line 8926)
   ⚠️  Never called

🏗️ _update_color_button
   📄 Editors\ModelEditor\ModelEditor.py (line 8934)
   ⚠️  Never called

🏗️ _on_light_position_changed
   📄 Editors\ModelEditor\ModelEditor.py (line 8942)
   ⚠️  Never called

🏗️ _on_internal_brightness_changed
   📄 Editors\ModelEditor\ModelEditor.py (line 8949)
   ⚠️  Never called

🏗️ _on_external_brightness_changed
   📄 Editors\ModelEditor\ModelEditor.py (line 8955)
   ⚠️  Never called

🏗️ _on_smooth_movement_changed
   📄 Editors\ModelEditor\ModelEditor.py (line 8963)
   ⚠️  Never called

🏗️ _on_smooth_camera_changed
   📄 Editors\ModelEditor\ModelEditor.py (line 8984)
   ⚠️  Never called

🏗️ _on_preview_scale_changed
   📄 Editors\ModelEditor\ModelEditor.py (line 8999)
   ⚠️  Never called

🏗️ _on_lighting_style_changed
   📄 Editors\ModelEditor\ModelEditor.py (line 9011)
   ⚠️  Never called

🏗️ _pick_background_color
   📄 Editors\ModelEditor\ModelEditor.py (line 9023)
   ⚠️  Never called

🏗️ _update_background_color_button
   📄 Editors\ModelEditor\ModelEditor.py (line 9038)
   ⚠️  Never called

🏗️ _pick_skyline_color
   📄 Editors\ModelEditor\ModelEditor.py (line 9047)
   ⚠️  Never called

🏗️ _update_skyline_color_button
   📄 Editors\ModelEditor\ModelEditor.py (line 9061)
   ⚠️  Never called

🏗️ _browse_background_texture
   📄 Editors\ModelEditor\ModelEditor.py (line 9070)
   ⚠️  Never called

🏗️ _browse_skyline_texture
   📄 Editors\ModelEditor\ModelEditor.py (line 9144)
   ⚠️  Never called

🏗️ _on_background_texture_changed
   📄 Editors\ModelEditor\ModelEditor.py (line 9218)
   ⚠️  Never called

🏗️ _on_skyline_texture_changed
   📄 Editors\ModelEditor\ModelEditor.py (line 9290)
   ⚠️  Never called

🏗️ _on_background_texture_mode_changed
   📄 Editors\ModelEditor\ModelEditor.py (line 9349)
   ⚠️  Never called

🏗️ _on_skyline_texture_mode_changed
   📄 Editors\ModelEditor\ModelEditor.py (line 9365)
   ⚠️  Never called

🏗️ _on_background_scale_changed
   📄 Editors\ModelEditor\ModelEditor.py (line 9381)
   ⚠️  Never called

🏗️ _on_skyline_scale_changed
   📄 Editors\ModelEditor\ModelEditor.py (line 9395)
   ⚠️  Never called

🏗️ _refresh_model_view
   📄 Editors\ModelEditor\ModelEditor.py (line 9409)
   ⚠️  Never called

🏗️ _update_create_edit_button
   📄 Editors\ModelEditor\ModelEditor.py (line 9417)
   ⚠️  Never called

🏗️ toggle_edit_mode
   📄 Editors\ModelEditor\ModelEditor.py (line 9424)
   ⚠️  Never called

🏗️ save_model
   📄 Editors\ModelEditor\ModelEditor.py (line 10074)
   ⚠️  Never called

🏗️ save_model_as
   📄 Editors\ModelEditor\ModelEditor.py (line 9553)
   ⚠️  Never called

🏗️ show_lighting_settings
   📄 Editors\ModelEditor\ModelEditor.py (line 9674)
   ⚠️  Never called

🏗️ _update_selection_info
   📄 Editors\ModelEditor\ModelEditor.py (line 9679)
   ⚠️  Never called

🏗️ toggle_animation_playback
   📄 Editors\ModelEditor\ModelEditor.py (line 9737)
   ⚠️  Never called

🏗️ start_animation_playback
   📄 Editors\ModelEditor\ModelEditor.py (line 9750)
   ⚠️  Never called

🏗️ stop_animation_playback
   📄 Editors\ModelEditor\ModelEditor.py (line 9778)
   ⚠️  Never called

🏗️ _advance_animation_frame
   📄 Editors\ModelEditor\ModelEditor.py (line 9788)
   ⚠️  Never called

🏗️ next_animation_frame
   📄 Editors\ModelEditor\ModelEditor.py (line 9837)
   ⚠️  Never called

🏗️ previous_animation_frame
   📄 Editors\ModelEditor\ModelEditor.py (line 9872)
   ⚠️  Never called

🏗️ _update_animation_frame_counter
   📄 Editors\ModelEditor\ModelEditor.py (line 9907)
   ⚠️  Never called

🏗️ on_animation_loop_changed
   📄 Editors\ModelEditor\ModelEditor.py (line 9939)
   ⚠️  Never called

🏗️ on_animation_speed_changed
   📄 Editors\ModelEditor\ModelEditor.py (line 9944)
   ⚠️  Never called

🏗️ create_entity_info_panel_OLD
   📄 Editors\ModelEditor\ModelEditor.py (line 9958)
   ⚠️  Never called

🏗️ set_tool_OLD
   📄 Editors\ModelEditor\ModelEditor.py (line 10018)
   ⚠️  Never called

🏗️ pick_colour_OLD
   📄 Editors\ModelEditor\ModelEditor.py (line 10054)
   ⚠️  Never called

🏗️ pick_entity_color_OLD
   📄 Editors\ModelEditor\ModelEditor.py (line 10066)
   ⚠️  Never called

🏗️ save_model_as_OLD
   📄 Editors\ModelEditor\ModelEditor.py (line 10079)
   ⚠️  Never called

🏗️ _load_model_editor_settings
   📄 Editors\ModelEditor\ModelEditor.py (line 10091)
   ⚠️  Never called

🏗️ _save_model_editor_settings
   📄 Editors\ModelEditor\ModelEditor.py (line 10465)
   ⚠️  Never called

🏗️ exit_edit_mode_old
   📄 Editors\ModelEditor\ModelEditor.py (line 10526)
   ⚠️  Never called

🏗️ _on_model_creator_saved
   📄 Editors\ModelEditor\ModelEditor.py (line 10562)
   ⚠️  Never called

🏗️ _update_dimensions_display
   📄 Editors\ModelEditor\ModelEditor.py (line 10571)
   ⚠️  Never called

🏗️ load_model_file
   📄 Editors\ModelEditor\ModelEditor.py (line 10896)
   ⚠️  Never called

🏗️ _get_model_directory
   📄 Editors\ModelEditor\ModelEditor.py (line 10919)
   ⚠️  Never called

🏗️ _detect_related_model_files
   📄 Editors\ModelEditor\ModelEditor.py (line 10934)
   ⚠️  Never called

🏗️ _detect_related_files_for_import
   📄 Editors\ModelEditor\ModelEditor.py (line 10997)
   ⚠️  Never called

🏗️ _check_file_contains_animations
   📄 Editors\ModelEditor\ModelEditor.py (line 11097)
   ⚠️  Never called

🏗️ _prompt_and_import_related_files
   📄 Editors\ModelEditor\ModelEditor.py (line 11184)
   ⚠️  Never called

🏗️ _import_related_files
   📄 Editors\ModelEditor\ModelEditor.py (line 11247)
   ⚠️  Never called

🏗️ associate_other_model_files
   📄 Editors\ModelEditor\ModelEditor.py (line 11396)
   ⚠️  Never called

🏗️ associate_model_texture_files
   📄 Editors\ModelEditor\ModelEditor.py (line 11456)
   ⚠️  Never called

🏗️ _load_mtl_and_textures
   📄 Editors\ModelEditor\ModelEditor.py (line 11518)
   ⚠️  Never called

🏗️ associate_mtl_file
   📄 Editors\ModelEditor\ModelEditor.py (line 11548)
   ⚠️  Never called

🏗️ open_manage_textures_dialog
   📄 Editors\ModelEditor\ModelEditor.py (line 11740)
   ⚠️  Never called

🏗️ _serialize_model_to_json
   📄 Editors\ModelEditor\ModelEditor.py (line 11783)
   ⚠️  Never called

🏗️ load_model_file_from_path
   📄 Editors\ModelEditor\ModelEditor.py (line 11897)
   ⚠️  Never called

🏗️ _load_object_into_panels
   📄 Editors\ObjectEditor\object_editor.py (line 138)
   ⚠️  Never called

🏗️ _switch_to_event
   📄 Editors\ObjectEditor\object_editor.py (line 252)
   ⚠️  Never called

🏗️ add_or_open_event
   📄 Editors\ObjectEditor\object_editor.py (line 341)
   ⚠️  Never called

🏗️ _get_event_pgsl_file_path
   📄 Editors\ObjectEditor\object_editor.py (line 376)
   ⚠️  Never called

🏗️ _save_current_event_code
   📄 Editors\ObjectEditor\object_editor.py (line 395)
   ⚠️  Never called

🏗️ validate_event
   📄 Editors\ObjectEditor\object_editor.py (line 423)
   ⚠️  Never called

🏗️ validate_object
   📄 Editors\ObjectEditor\object_editor.py (line 449)
   ⚠️  Never called

🏗️ _connect_menu_actions
   📄 Editors\ObjectEditor\object_editor.py (line 490)
   ⚠️  Never called

🏗️ _connect_panel_signals
   📄 Editors\ObjectEditor\object_editor.py (line 510)
   ⚠️  Never called

🏗️ _connect_sprite_signals
   📄 Editors\ObjectEditor\object_editor.py (line 531)
   ⚠️  Never called

🏗️ _on_property_changed
   📄 Editors\ObjectEditor\object_editor.py (line 593)
   ⚠️  Never called

🏗️ _on_sprite_changed
   📄 Editors\ObjectEditor\object_editor.py (line 596)
   ⚠️  Never called

🏗️ _on_events_button_clicked
   📄 Editors\ObjectEditor\object_editor.py (line 617)
   ⚠️  Never called

🏗️ _on_child_selected
   📄 Editors\ObjectEditor\object_editor.py (line 637)
   ⚠️  Never called

🏗️ recurse_find
   📄 Editors\ObjectEditor\object_editor.py (line 661)
   📞 Called by:
      • Editors\ObjectEditor\object_editor.py (line 671)
      • Editors\ObjectEditor\object_editor.py (line 674)

🏗️ _on_code_edited
   📄 Editors\ObjectEditor\object_editor.py (line 693)
   ⚠️  Never called

🏗️ _create_default_resource
   📄 Editors\ObjectEditor\object_editor.py (line 735)
   ⚠️  Never called

🏗️ _toggle_fullscreen
   📄 Editors\ObjectEditor\object_editor.py (line 752)
   ⚠️  Never called

🏗️ _create_fullscreen_window
   📄 Editors\ObjectEditor\object_editor.py (line 776)
   ⚠️  Never called

🏗️ _update_fullscreen_tabs
   📄 Editors\ObjectEditor\object_editor.py (line 838)
   ⚠️  Never called

🏗️ _on_fullscreen_tab_changed
   📄 Editors\ObjectEditor\object_editor.py (line 875)
   ⚠️  Never called

🏗️ _on_fullscreen_close
   📄 Editors\ObjectEditor\object_editor.py (line 899)
   ⚠️  Never called

🏗️ _update_event_tabs
   📄 Editors\ObjectEditor\object_editor.py (line 911)
   ⚠️  Never called

🏗️ _on_tab_changed
   📄 Editors\ObjectEditor\object_editor.py (line 948)
   ⚠️  Never called

🏗️ _print_terminal
   📄 Editors\ObjectEditor\object_editor.py (line 966)
   ⚠️  Never called

🏗️ _on_code_editor_maximize
   📄 Editors\ObjectEditor\object_editor.py (line 972)
   ⚠️  Never called

🏗️ _on_code_editor_dock
   📄 Editors\ObjectEditor\object_editor.py (line 999)
   ⚠️  Never called

🏗️ _populate_parent_list
   📄 Editors\ObjectEditor\object_editor.py (line 1015)
   ⚠️  Never called

🏗️ _populate_children_list
   📄 Editors\ObjectEditor\object_editor.py (line 1122)
   ⚠️  Never called

🏗️ _get_event_label
   📄 Editors\ObjectEditor\object_editor.py (line 1231)
   ⚠️  Never called

🏗️ _setup_sprite_preview_widget
   📄 Editors\ObjectEditor\object_editor.py (line 1284)
   ⚠️  Never called

🏗️ _update_sprite_preview
   📄 Editors\ObjectEditor\object_editor.py (line 1294)
   ⚠️  Never called

🏗️ draw_midi_info
   📄 Editors\SoundEditor\SoundEditor.py (line 164)
   ⚠️  Never called

🏗️ draw_no_audio
   📄 Editors\SoundEditor\SoundEditor.py (line 180)
   ⚠️  Never called

🏗️ draw_playback_needle
   📄 Editors\SoundEditor\SoundEditor.py (line 195)
   ⚠️  Never called

🏗️ update_position
   📄 Editors\SoundEditor\SoundEditor.py (line 213)
   📞 Called by:
      • Editors\SoundEditor\SoundEditor.py (line 1418)

🏗️ update_waveform_data
   📄 Editors\SoundEditor\SoundEditor.py (line 310)
   📞 Called by:
      • Editors\SoundEditor\SoundEditor.py (line 606)

🏗️ update_midi_data
   📄 Editors\SoundEditor\SoundEditor.py (line 316)
   ⚠️  Never called

🏗️ on_mute_toggled
   📄 Editors\SoundEditor\SoundEditor.py (line 478)
   ⚠️  Never called

🏗️ on_overall_volume_changed
   📄 Editors\SoundEditor\SoundEditor.py (line 485)
   ⚠️  Never called

🏗️ on_left_toggled
   📄 Editors\SoundEditor\SoundEditor.py (line 492)
   ⚠️  Never called

🏗️ on_right_toggled
   📄 Editors\SoundEditor\SoundEditor.py (line 498)
   ⚠️  Never called

🏗️ on_left_volume_changed
   📄 Editors\SoundEditor\SoundEditor.py (line 504)
   ⚠️  Never called

🏗️ on_right_volume_changed
   📄 Editors\SoundEditor\SoundEditor.py (line 510)
   ⚠️  Never called

🏗️ update_playback_volume
   📄 Editors\SoundEditor\SoundEditor.py (line 516)
   ⚠️  Never called

🏗️ update_visual_state
   📄 Editors\SoundEditor\SoundEditor.py (line 550)
   ⚠️  Never called

🏗️ get_effective_volume_left
   📄 Editors\SoundEditor\SoundEditor.py (line 610)
   ⚠️  Never called

🏗️ get_effective_volume_right
   📄 Editors\SoundEditor\SoundEditor.py (line 618)
   ⚠️  Never called

🏗️ clear_tracks
   📄 Editors\SoundEditor\SoundEditor.py (line 666)
   📞 Called by:
      • Editors\SoundEditor\SoundEditor.py (line 1044)
      • Editors\SoundEditor\SoundEditor.py (line 1079)
      • Editors\SoundEditor\SoundEditor.py (line 1154)

🏗️ get_track
   📄 Editors\SoundEditor\SoundEditor.py (line 677)
   ⚠️  Never called

🏗️ setup_timer
   📄 Editors\SoundEditor\SoundEditor.py (line 775)
   ⚠️  Never called

🏗️ cleanup_on_close
   📄 Editors\SoundEditor\SoundEditor.py (line 781)
   📞 Called by:
      • Editors\SoundEditor\SoundEditor.py (line 2246)
      • Editors\SoundEditor\SoundEditor.py (line 2693)

🏗️ seek_to_position
   📄 Editors\SoundEditor\SoundEditor.py (line 1595)
   ⚠️  Never called

🏗️ _load_wav_without_ffmpeg
   📄 Editors\SoundEditor\SoundEditor.py (line 2634)
   📞 Called by:
      • Editors\SoundEditor\SoundEditor.py (line 2637)
      • Editors\SoundEditor\SoundEditor.py (line 2651)

🏗️ _load_wav_via_pygame
   📄 Editors\SoundEditor\SoundEditor.py (line 959)
   ⚠️  Never called

🏗️ generate_waveform_from_audio_segment
   📄 Editors\SoundEditor\SoundEditor.py (line 1003)
   ⚠️  Never called

🏗️ update_track_list_ui
   📄 Editors\SoundEditor\SoundEditor.py (line 1041)
   ⚠️  Never called

🏗️ load_midi_file
   📄 Editors\SoundEditor\SoundEditor.py (line 1061)
   ⚠️  Never called

🏗️ load_audio_file_pydub
   📄 Editors\SoundEditor\SoundEditor.py (line 1141)
   ⚠️  Never called

🏗️ generate_waveform_data
   📄 Editors\SoundEditor\SoundEditor.py (line 1193)
   ⚠️  Never called

🏗️ generate_waveform_from_audio_file
   📄 Editors\SoundEditor\SoundEditor.py (line 1203)
   ⚠️  Never called

🏗️ generate_midi_track_waveform
   📄 Editors\SoundEditor\SoundEditor.py (line 1295)
   ⚠️  Never called

🏗️ find_references
   📄 Editors\SoundEditor\SoundEditor.py (line 2843)
   ⚠️  Never called

🏗️ update_references_display
   📄 Editors\SoundEditor\SoundEditor.py (line 2867)
   ⚠️  Never called

🏗️ _find_resource_references
   📄 Editors\SoundEditor\SoundEditor.py (line 2884)
   ⚠️  Never called

🏗️ restart_playback_from_position
   📄 Editors\SoundEditor\SoundEditor.py (line 1611)
   ⚠️  Never called

🏗️ _old_restart_playback_from_position
   📄 Editors\SoundEditor\SoundEditor.py (line 1615)
   ⚠️  Never called

🏗️ restart_midi_playback_from_position
   📄 Editors\SoundEditor\SoundEditor.py (line 1699)
   ⚠️  Never called

🏗️ calculate_effective_volume
   📄 Editors\SoundEditor\SoundEditor.py (line 1767)
   ⚠️  Never called

🏗️ stop_audio_playback
   📄 Editors\SoundEditor\SoundEditor.py (line 1894)
   📞 Called by:
      • Editors\SoundEditor\SoundEditor.py (line 2765)

🏗️ start_midi_playback
   📄 Editors\SoundEditor\SoundEditor.py (line 1921)
   ⚠️  Never called

🏗️ _get_active_track_indices
   📄 Editors\SoundEditor\SoundEditor.py (line 1952)
   ⚠️  Never called

🏗️ _create_filtered_midi_file
   📄 Editors\SoundEditor\SoundEditor.py (line 1963)
   ⚠️  Never called

🏗️ _convert_midi_to_audio_for_playback
   📄 Editors\SoundEditor\SoundEditor.py (line 2027)
   ⚠️  Never called

🏗️ on_loop_toggled
   📄 Editors\SoundEditor\SoundEditor.py (line 2118)
   ⚠️  Never called

🏗️ on_progress_changed
   📄 Editors\SoundEditor\SoundEditor.py (line 2157)
   ⚠️  Never called

🏗️ on_progress_released
   📄 Editors\SoundEditor\SoundEditor.py (line 2168)
   ⚠️  Never called

🏗️ update_progress_bar
   📄 Editors\SoundEditor\SoundEditor.py (line 2175)
   ⚠️  Never called

🏗️ cleanup_temp_files
   📄 Editors\SoundEditor\SoundEditor.py (line 2183)
   ⚠️  Never called

🏗️ clear_audio
   📄 Editors\SoundEditor\SoundEditor.py (line 2212)
   ⚠️  Never called

🏗️ _handle_destroyed
   📄 Editors\SoundEditor\SoundEditor.py (line 2249)
   ⚠️  Never called

🏗️ load_audio_file_from_path
   📄 Editors\SoundEditor\SoundEditor.py (line 2527)
   ⚠️  Never called

🏗️ _read_wav_metadata
   📄 Editors\SoundEditor\SoundEditor.py (line 2640)
   ⚠️  Never called

🏗️ format_duration
   📄 Editors\SoundEditor\SoundEditor.py (line 2716)
   ⚠️  Never called

🏗️ on_volume_changed
   📄 Editors\SoundEditor\SoundEditor.py (line 2728)
   ⚠️  Never called

🏗️ on_loop_changed
   📄 Editors\SoundEditor\SoundEditor.py (line 2738)
   ⚠️  Never called

🏗️ on_preload_changed
   📄 Editors\SoundEditor\SoundEditor.py (line 2744)
   ⚠️  Never called

🏗️ on_frequency_changed
   📄 Editors\SoundEditor\SoundEditor.py (line 2749)
   ⚠️  Never called

🏗️ open_sound_file_editor
   📄 Editors\SoundEditor\SoundEditor.py (line 2771)
   ⚠️  Never called

🏗️ open_sound_creator
   📄 Editors\SoundEditor\SoundEditor.py (line 2834)
   ⚠️  Never called

🏗️ _get_editor_state
   📄 Editors\ImageEditor\core\ui\dialogs\effect_dialog.py (line 53)
   ⚠️  Never called

🏗️ _generate_summary
   📄 Editors\ImageEditor\core\ui\dialogs\effect_dialog.py (line 74)
   ⚠️  Never called

🏗️ _update_summary
   📄 Editors\ImageEditor\core\ui\dialogs\effect_dialog.py (line 106)
   ⚠️  Never called

🏗️ _on_frame_current_toggled
   📄 Editors\ImageEditor\core\ui\dialogs\effect_dialog.py (line 128)
   ⚠️  Never called

🏗️ _on_create_frames_toggled
   📄 Editors\ImageEditor\core\ui\dialogs\effect_dialog.py (line 134)
   ⚠️  Never called

🏗️ _on_frame_all_toggled
   📄 Editors\ImageEditor\core\ui\dialogs\effect_dialog.py (line 140)
   ⚠️  Never called

🏗️ _on_area_entire_toggled
   📄 Editors\ImageEditor\core\ui\dialogs\effect_dialog.py (line 147)
   ⚠️  Never called

🏗️ _on_area_selection_toggled
   📄 Editors\ImageEditor\core\ui\dialogs\effect_dialog.py (line 153)
   ⚠️  Never called

🏗️ get_frame_option
   📄 Editors\ImageEditor\core\ui\dialogs\effect_dialog.py (line 4679)
   ⚠️  Never called

🏗️ get_selection_option
   📄 Editors\ImageEditor\core\ui\dialogs\effect_dialog.py (line 4682)
   ⚠️  Never called

🏗️ get_merge_replace_mode
   📄 Editors\ImageEditor\core\ui\dialogs\effect_dialog.py (line 709)
   ⚠️  Never called

🏗️ get_export_options
   📄 Editors\ImageEditor\core\ui\dialogs\effect_dialog.py (line 4778)
   ⚠️  Never called

🏗️ create_parameter_widget
   📄 Editors\ImageEditor\core\ui\dialogs\effect_dialog.py (line 600)
   ⚠️  Never called

🏗️ create_advanced_section
   📄 Editors\ImageEditor\core\ui\dialogs\effect_dialog.py (line 620)
   ⚠️  Never called

🏗️ create_biome_settings
   📄 Editors\ImageEditor\core\ui\dialogs\effect_dialog.py (line 627)
   ⚠️  Never called

🏗️ create_animation_controls
   📄 Editors\ImageEditor\core\ui\dialogs\effect_dialog.py (line 650)
   ⚠️  Never called

🏗️ on_frame_option_changed
   📄 Editors\ImageEditor\core\ui\dialogs\effect_dialog.py (line 669)
   ⚠️  Never called

🏗️ on_selection_option_changed
   📄 Editors\ImageEditor\core\ui\dialogs\effect_dialog.py (line 684)
   ⚠️  Never called

🏗️ _toggle_upscale_size_visibility
   📄 Editors\ImageEditor\core\ui\dialogs\effect_dialog.py (line 695)
   ⚠️  Never called

🏗️ _toggle_upscale_quality_visibility
   📄 Editors\ImageEditor\core\ui\dialogs\effect_dialog.py (line 700)
   ⚠️  Never called

🏗️ on_parameter_changed
   📄 Editors\ImageEditor\core\ui\dialogs\effect_dialog.py (line 716)
   ⚠️  Never called

🏗️ toggle_advanced_options
   📄 Editors\ImageEditor\core\ui\dialogs\effect_dialog.py (line 724)
   ⚠️  Never called

🏗️ _update_features_info
   📄 Editors\ImageEditor\core\ui\dialogs\effect_dialog.py (line 733)
   ⚠️  Never called

🏗️ preview_prev_frame
   📄 Editors\ImageEditor\core\ui\dialogs\effect_dialog.py (line 768)
   ⚠️  Never called

🏗️ preview_next_frame
   📄 Editors\ImageEditor\core\ui\dialogs\effect_dialog.py (line 779)
   ⚠️  Never called

🏗️ _prepare_preview_image
   📄 Editors\ImageEditor\core\ui\dialogs\effect_dialog.py (line 830)
   ⚠️  Never called

🏗️ _apply_effect_to_preview
   📄 Editors\ImageEditor\core\ui\dialogs\effect_dialog.py (line 855)
   ⚠️  Never called

🏗️ _floyd_steinberg_dither
   📄 Editors\ImageEditor\core\ui\dialogs\effect_dialog.py (line 1774)
   ⚠️  Never called

🏗️ _ordered_dither
   📄 Editors\ImageEditor\core\ui\dialogs\effect_dialog.py (line 1819)
   ⚠️  Never called

🏗️ _random_dither
   📄 Editors\ImageEditor\core\ui\dialogs\effect_dialog.py (line 1865)
   ⚠️  Never called

🏗️ _toggle_custom_size_visibility
   📄 Editors\ImageEditor\core\ui\dialogs\effect_dialog.py (line 2509)
   ⚠️  Never called

🏗️ _toggle_custom_position_visibility
   📄 Editors\ImageEditor\core\ui\dialogs\effect_dialog.py (line 2520)
   ⚠️  Never called

🏗️ _toggle_animation_visibility
   📄 Editors\ImageEditor\core\ui\dialogs\effect_dialog.py (line 2531)
   ⚠️  Never called

🏗️ _toggle_texture_mode_visibility
   📄 Editors\ImageEditor\core\ui\dialogs\effect_dialog.py (line 2536)
   ⚠️  Never called

🏗️ _sync_slider_to_text
   📄 Editors\ImageEditor\core\ui\dialogs\effect_dialog.py (line 2545)
   ⚠️  Never called

🏗️ _sync_text_to_slider
   📄 Editors\ImageEditor\core\ui\dialogs\effect_dialog.py (line 2550)
   ⚠️  Never called

🏗️ _detect_dominant_colors
   📄 Editors\ImageEditor\core\ui\dialogs\effect_dialog.py (line 2761)
   ⚠️  Never called

🏗️ _get_warmth_color
   📄 Editors\ImageEditor\core\ui\dialogs\effect_dialog.py (line 2783)
   ⚠️  Never called

🏗️ _get_lighting_preset_configs
   📄 Editors\ImageEditor\core\ui\dialogs\effect_dialog.py (line 2805)
   ⚠️  Never called

🏗️ _get_default_parameter_value
   📄 Editors\ImageEditor\core\ui\dialogs\effect_dialog.py (line 2903)
   ⚠️  Never called

🏗️ _apply_simple_windwaker
   📄 Editors\ImageEditor\core\ui\dialogs\effect_dialog.py (line 2962)
   ⚠️  Never called

🏗️ _apply_n64_filter
   📄 Editors\ImageEditor\core\ui\dialogs\effect_dialog.py (line 3064)
   ⚠️  Never called

🏗️ _apply_mansion_filter
   📄 Editors\ImageEditor\core\ui\dialogs\effect_dialog.py (line 3201)
   ⚠️  Never called

🏗️ _apply_eternal_darkness_filter
   📄 Editors\ImageEditor\core\ui\dialogs\effect_dialog.py (line 3353)
   ⚠️  Never called

🏗️ _apply_pokemon_colosseum_filter
   📄 Editors\ImageEditor\core\ui\dialogs\effect_dialog.py (line 3478)
   ⚠️  Never called

🏗️ _apply_mario_kart_8_filter
   📄 Editors\ImageEditor\core\ui\dialogs\effect_dialog.py (line 3612)
   ⚠️  Never called

🏗️ _apply_upscale_effect
   📄 Editors\ImageEditor\core\ui\dialogs\effect_dialog.py (line 3678)
   ⚠️  Never called

🏗️ _apply_image_enhancement_effect
   📄 Editors\ImageEditor\core\ui\dialogs\effect_dialog.py (line 3736)
   ⚠️  Never called

🏗️ _apply_hd_crisp_for_final
   📄 Editors\ImageEditor\core\ui\dialogs\effect_dialog.py (line 3771)
   ⚠️  Never called

🏗️ _apply_quality_enhancement_effect
   📄 Editors\ImageEditor\core\ui\dialogs\effect_dialog.py (line 3855)
   ⚠️  Never called

🏗️ _apply_noise_reduction_effect
   📄 Editors\ImageEditor\core\ui\dialogs\effect_dialog.py (line 3947)
   ⚠️  Never called

🏗️ _apply_hdr_tone_mapping_effect
   📄 Editors\ImageEditor\core\ui\dialogs\effect_dialog.py (line 4002)
   ⚠️  Never called

🏗️ _detect_light_sources
   📄 Editors\ImageEditor\core\ui\dialogs\effect_dialog.py (line 4113)
   ⚠️  Never called

🏗️ _detect_objects
   📄 Editors\ImageEditor\core\ui\dialogs\effect_dialog.py (line 4168)
   ⚠️  Never called

🏗️ _create_lighting_map
   📄 Editors\ImageEditor\core\ui\dialogs\effect_dialog.py (line 4201)
   ⚠️  Never called

🏗️ _apply_torch_color
   📄 Editors\ImageEditor\core\ui\dialogs\effect_dialog.py (line 4222)
   ⚠️  Never called

🏗️ _add_flicker
   📄 Editors\ImageEditor\core\ui\dialogs\effect_dialog.py (line 4237)
   ⚠️  Never called

🏗️ randomize_parameters
   📄 Editors\ImageEditor\core\ui\dialogs\effect_dialog.py (line 4691)
   ⚠️  Never called

🏗️ browse_export_path
   📄 Editors\ImageEditor\core\ui\dialogs\effect_dialog.py (line 4753)
   ⚠️  Never called


