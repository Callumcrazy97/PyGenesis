# PyGenesis IDE - Comprehensive Codebase Summary

**Generated**: Based on analysis files and codebase exploration  
**Project**: PyGenesis IDE - A GameMaker-style IDE for Python game development  
**Root Path**: `C:\Design\Python\IDE Development\Newest PyGenesis\Original\Old Version\Temp`

---

## 📊 Executive Overview

**PyGenesis IDE** is a comprehensive, GameMaker-style integrated development environment for creating Python games. It combines visual editors, a custom scripting language (PGSL), AI assistance (Nova), and a complete game development workflow into a single application.

### Key Statistics
- **Total Files**: 376 files
- **Total Size**: ~29.0 MB
- **Python Files**: 260 files
- **Functions Defined**: 3,006
- **Classes Defined**: 345
- **Imports Found**: 595
- **Function Calls**: 45,156

### Technology Stack
- **GUI Framework**: PySide6 (Qt for Python)
- **Language**: Python 3.x
- **Rendering**: OpenGL (via PyOpenGL)
- **AI Integration**: Custom Nova assistant with SLM (Small Language Model)
- **Code Analysis**: AST-based static analysis
- **Project Management**: JSON-based resource system

---

## 🏗️ Architecture Overview

### Core Design Principles
1. **GameMaker-Style Interface**: Familiar layout with resource tree, editors, and properties panels
2. **Unified Code System**: Single code editor (`UnifiedCodeEditor`) used across all editors
3. **Metadata-Driven**: Resources stored as JSON with code in separate `.pgsl` files
4. **AI-Assisted Development**: Nova assistant for planning, code generation, and analysis
5. **Solo-Developer Focus**: Designed for single developers, not large teams

### Application Structure

```
PyGenesis IDE
├── Core/                    # Core systems and managers
├── Editors/                  # Resource editors (Sprite, Object, Room, etc.)
├── UI/                      # Main window and shared widgets
├── Config/                  # Settings and configuration
├── Tools/                   # Utility tools (Backup, Venv Management)
├── Documentation/           # Project documentation
└── test_scripts/            # Test cases and examples
```

---

## 🔧 Core Components

### 1. **Core/ - Foundation Systems**

#### **Project & Resource Management**
- **`ProjectManager.py`** (79.5 KB, 1533 lines)
  - Handles project creation, loading, and management
  - Runtime resource tracking
  - Project file structure management
  
- **`ResourceManager.py`** (85.7 KB, 1944 lines)
  - Resource creation, editing, and management
  - Supports: Sprites, Objects, Rooms, Sounds, Models, Textures, Backgrounds
  - Lazy loading for performance

#### **Code System**
- **`CodeSystem/`** - PGSL (PyGenesis Shortcut Language) implementation
  - `lexer.py` - Tokenization
  - `parser.py` - Syntax parsing
  - `ast.py` - Abstract syntax tree
  - `syntax.py` - Syntax validation
  
- **`Code/Unified/`** - Unified code editing system
  - `unified_code_editor.py` (39.2 KB) - Shared code editor widget
  - `validation_pipeline.py` - Unified validation for PGSL and Python
  - Supports both PGSL and Python modes
  - Context-aware validation (SCRIPT, OBJECT_EVENT, SHADER, PARTICLE)

- **`Code/Shared/`** - Shared validation and analysis
  - `script_validator.py` - Python code validation with AST analysis
  - Context-aware built-ins for object events
  - Predefined variable support across events

#### **Rendering System**
- **`Rendering/`** - OpenGL-based rendering
  - `OpenGLRuntime.py` - Main rendering runtime
  - `ShaderManager.py` - Shader management
  - `TextureManager.py` - Texture handling
  - `BufferManager.py` - Buffer management
  - `Canvas_2D.py` - 2D canvas operations
  - `SuperShader_2D.py` - 2D shader system

#### **AI Assistant (Nova)**
- **`AI/PyGenesisAssistant/Nova/`** - AI assistant system
  - **Core Components**:
    - `workflow.py` (33.6 KB) - Main processing pipeline
    - `intent_router.py` (50.3 KB) - Intent classification with 4-layer resolution
    - `research_engine.py` (64.5 KB) - Research queries with citations
    - `resource_operation_executor.py` (32.6 KB) - Resource operations
  - **SLM (Small Language Model)**:
    - Neural network-based intent classification
    - Keyword-based fallback system
    - Training data and model files included
  - **Features**:
    - Time-boxed execution (planned)
    - Operation-based code editing (planned)
    - Conversation management
    - Task management

#### **Services**
- **`Services/`** - Background services
  - `async_editor_loader.py` - Async editor loading
  - `async_project_loader.py` - Async project loading
  - `async_project_saver.py` - Async project saving
  - `file_service.py` - File operations
  - `resource_service.py` - Resource operations
  - `validation_service.py` - Validation services
  - `incremental_resource_reloader.py` - Incremental reloading

#### **Other Core Systems**
- **`EditorFactory.py`** - Factory for creating editors
- **`EditorInterface.py`** - Interface all editors implement
- **`ExtensionsManager.py`** - Package and extension management
- **`VenvManager.py`** - Virtual environment management
- **`PackageInstaller.py`** - Package installation
- **`GameGenerator.py`** - Game export/generation
- **`Debug.py`** - Debug logging system

### 2. **Editors/ - Resource Editors**

All editors follow a consistent GameMaker-style layout with properties panels, preview areas, and event/code editing.

#### **Object Editor (PGOE - Pygo)** ⭐ *Currently Active Development*
- **`object_editor.py`** (55.5 KB, 1307 lines)
  - Main controller for object editing
  - Event-based system (Create, Step, Draw, Collision, Alarm, etc.)
  - Integrated with `UnifiedCodeEditor`
  - Collision event system with object browser dialog
  - Code validation with cross-event variable recognition
  
- **Structure**:
  - `UI/` - UI components
    - `events_panel.py` - Event tree and management
    - `properties_panel.py` - Object properties
    - `code_editor_widget.py` - Code editor wrapper
  - `Core/` - Core logic
  - `Services/` - Background services

#### **Sprite Editor (PGIE - Piggie)**
- **`SpriteEditor.py`** (63.9 KB, 1439 lines)
  - GameMaker 8-style sprite editor
  - Frame management and animation
  - Preview with properties panel

#### **Image Editor (PGIE - Piggie)**
- **`ImageEditor/`** - Advanced image editing
  - **`core/ui/main_window.py`** (282.0 KB, 6495 lines) - Main window
  - **`core/ui/dialogs/effect_dialog.py`** (266.7 KB, 5814 lines) - Effect dialog
  - **`core/ui/preview.py`** (140.7 KB, 3160 lines) - Preview widget
  - Extensive effect library
  - Timeline-based animation
  - AI integration (Gemini) for image generation
  - Character creator
  - Texture atlas support

#### **Room Editor (PGRE - Pygress)**
- **`RoomEditor.py`** (60.7 KB, 1614 lines)
  - 2D room editor (3D planned)
  - GameMaker-style interface
  - Object placement and instance management
  - Background layers
  - Views and cameras
  - Grid and snap system

#### **Model Editor (PGME - Pigmie)**
- **`ModelEditor.py`** (590.2 KB, 12074 lines) - **Largest file**
  - 3D model viewer and editor
  - SketchUp-like interface
  - Real-time editing
  - Vertex, edge, face manipulation
  - Material and texture support

#### **Sound Editor (PGSE - Pigsey)**
- **`SoundEditor.py`** (121.1 KB, 2955 lines)
  - GameMaker 8-style sound editor
  - WaveForge integration (Audacity-style waveform editor)
  - Properties panel and preview

#### **Code Editor (PGCE - PyCode)**
- **`ScriptEditor.py`** - Script editing
- **`PGSLCodeEditor.py`** - PGSL-specific editor
- Integrated with `UnifiedCodeEditor`

#### **Other Editors**
- **`BackgroundEditor/`** - Background resource editor
- **`TextureEditor/`** (52.5 KB) - Texture editor
- **`Shared/`** - Shared editor components
  - `BaseImageResourceEditor.py` (41.5 KB) - Base class for image editors
  - `IntegratedImageEditor.py` (82.6 KB) - Integrated image editing

### 3. **UI/ - User Interface**

#### **Main Window**
- **`MainWindow/MainWindow.py`** (81.6 KB, 2002 lines)
  - GameMaker-style main window
  - Resource tree (left panel)
  - Editor area (center)
  - Terminal widget
  - Menu bar and toolbars

#### **Widgets**
- **`Widgets/ResourceTree.py`** (96.8 KB, 2217 lines)
  - Resource tree with drag-and-drop
  - Folder organization
  - Thumbnail loading
  - Context menus

- **`Widgets/TerminalWidget.py`** - Integrated terminal
- **`Widgets/ThumbnailLoader.py`** - Async thumbnail loading
- **`Widgets/ParallelThumbnailLoader.py`** - Parallel loading

#### **Dialogs**
- **`CommonDialogs/PreferencesDialog.py`** (132.0 KB, 2803 lines)
  - Centralized preferences
  - Theme management
  - Editor settings
  
- **`CommonDialogs/ExtensionsDialog.py`** (41.9 KB)
  - Extension/package management
  - Update checking
  
- **`CommonDialogs/BackupManager/`** - Backup and restore
- **`CommonDialogs/RestoreDialog.py`** - Restore dialog

### 4. **Config/ - Configuration**

- **`Settings.py`** - Centralized settings management
- **`ThemeManager.py`** - Theme system
- **`Requirements.json`** - Package requirements
- **`CoreRequirements.json`** - Core dependencies
- **`OptionalRequirements.json`** - Optional dependencies

### 5. **Tools/ - Utility Tools**

- **`BackupManager/`** - Project backup system
- **`VenvManagement/`** - Virtual environment tools
- **`ScreenRecording/`** - Screen recording
- **`ProjectMaintenance/`** - Project maintenance tools

---

## 🎯 Key Features

### Code System
1. **PGSL (PyGenesis Shortcut Language)**
   - GameMaker-like syntax
   - Transpiles to Python
   - Simplified API for common operations
   - Event-based programming model

2. **Unified Code Editor**
   - Single editor used across all editors
   - Syntax highlighting (PGSL and Python)
   - Real-time validation
   - Diagnostics panel
   - Context-aware validation
   - Sandboxed execution for testing

3. **Validation System**
   - AST-based static analysis
   - Cross-event variable recognition
   - Context-aware built-ins
   - Syntax and semantic checking
   - Warning and error reporting

### Resource System
1. **Resource Types**
   - Sprites (with animation)
   - Objects (with events)
   - Rooms (2D, 3D planned)
   - Sounds
   - Models (3D)
   - Textures
   - Backgrounds
   - Scripts

2. **Resource Management**
   - JSON-based metadata
   - Code in separate `.pgsl` files
   - Lazy loading for performance
   - Incremental reloading
   - Undo/redo support

### AI Assistant (Nova)
1. **Intent Classification**
   - 4-layer Intent Resolution Stack
   - SLM-based classification
   - Keyword fallback
   - Context-aware routing

2. **Capabilities** (Current & Planned)
   - Resource operations
   - Code analysis
   - Research queries
   - Conversation management
   - Task management
   - Code generation (planned)
   - Time-boxed execution (planned)

### Rendering
1. **OpenGL Runtime**
   - 2D rendering (current)
   - 3D rendering (planned)
   - Shader system
   - Texture management
   - Buffer management

---

## 📈 Development Status

### ✅ Completed Features
- Core architecture and project management
- Resource system with lazy loading
- Unified code editor
- Object Editor with event system
- Collision event system with object browser
- Cross-event variable recognition
- Sprite, Image, Room, Model, Sound editors
- Nova AI assistant (basic functionality)
- Validation system
- Backup and restore

### 🚧 In Progress
- Object Editor enhancements
- Collision and instance finding testing
- Code validation improvements

### 📋 Planned (from Plan.md)
1. **Time-Boxed Execution Controller** (Nova) - CRITICAL
2. **Constrained Code Authoring System** (Nova) - CRITICAL
3. **Physics-Driven Gameplay Framework** - HIGH
4. **Combat System Metadata** - HIGH
5. **Nova Code Generation Rules** - HIGH
6. **Operation Schema for Code Edits** - HIGH
7. **Engine Capability Introspection** - MEDIUM
8. **Deterministic Replay Core** - MEDIUM
9. **Task Graph Progress Reporting** - MEDIUM
10. **Nova-Assisted Balancing** - LOW (Phase 3)

---

## 🔍 Code Quality & Analysis

### Largest Files (by size)
1. `Editors/ModelEditor/ModelEditor.py` - 590.2 KB (12,074 lines)
2. `Editors/ImageEditor/core/ui/main_window.py` - 282.0 KB (6,495 lines)
3. `Editors/ImageEditor/core/ui/dialogs/effect_dialog.py` - 266.7 KB (5,814 lines)
4. `Editors/ImageEditor/core/ui/preview.py` - 140.7 KB (3,160 lines)
5. `UI/CommonDialogs/PreferencesDialog.py` - 132.0 KB (2,803 lines)

### Unused Code
Analysis identified **1065 lines** of potentially unused code, primarily:
- Camera functions in `pgsl_runtime.py`
- Drawing functions in `pgsl_runtime.py`
- Various helper functions in Image Editor
- Some Model Editor functions

### Dependencies
- **595 unique imports** across the codebase
- Heavy use of PySide6 for GUI
- OpenGL for rendering
- NumPy for image processing
- Various AI/ML libraries for Nova

---

## 🧪 Testing

### Test Scripts
Located in `test_scripts/`:
- **Collision Tests/** - Collision event testing
- **Instance Finding/** - Instance finding function tests
- **PGSL/** - PGSL syntax tests
- **Python/** - Python code tests
- **Stress Tests/** - Edge cases and nested structures

### Test Coverage
- Object Editor events (Create, Step, Draw, Collision)
- Code validation (syntax, semantics, cross-event variables)
- Error reporting
- Block structure stress tests
- Variable shadowing/reuse
- Function argument validation

---

## 📚 Documentation

### Location: `Documentation/`
- **AI/Nova/** - Nova assistant documentation
- **Editors/** - Editor-specific documentation
  - PGCE (Code Editor)
  - PGIE (Image/Sprite Editor)
  - PGME (Model Editor)
  - PGOE (Object Editor)
  - PGRE (Room Editor)
- **PyGenesis Plans/** - Roadmaps and plans
  - Roadmap/
  - Tutorials/
  - Misc/

### Key Documents
- `Plan.md` - Development plan with top 10 improvements
- `Analysis/CODEBASE_SUMMARY.md` - Automated codebase summary
- `Analysis/Workflow.md` - Complete workflow analysis
- `Analysis/Dependencies.md` - Dependency mapping
- `Analysis/Definitions.md` - All function/class definitions
- `Analysis/UnusedCode.md` - Unused code analysis

---

## 🎨 Design Patterns & Architecture

### Patterns Used
1. **Factory Pattern**: `EditorFactory` for editor creation
2. **Interface Pattern**: `EditorInterface` for editor contracts
3. **Manager Pattern**: Various managers (Project, Resource, etc.)
4. **Service Pattern**: Background services for async operations
5. **Observer Pattern**: Signal/slot system (Qt)
6. **Strategy Pattern**: Validation pipeline with different strategies

### Architecture Principles
1. **Separation of Concerns**: Clear separation between UI, Core, and Services
2. **Modularity**: Editors are independent modules
3. **Extensibility**: Plugin-like extension system
4. **Performance**: Lazy loading, async operations, caching
5. **User Experience**: GameMaker-style familiar interface

---

## 🚀 Performance Considerations

### Optimizations
- **Lazy Loading**: Resources loaded on-demand
- **AST Caching**: Cached AST parsing in code analyzer
- **Parallel Processing**: Multi-threaded code analysis
- **Incremental Reloading**: Only reload changed resources
- **Async Operations**: Non-blocking file operations
- **Thumbnail Caching**: Cached thumbnails for resources

### Known Performance Areas
- Image Editor has some performance bottlenecks (documented)
- Model Editor is large and may need optimization
- Large codebase analysis can be slow (mitigated with caching)

---

## 🔐 Security & Safety

### Code Execution
- **Sandboxed Execution**: Code testing in isolated environment
- **Validation Before Execution**: All code validated before running
- **No Direct File Writes**: Operations go through managers
- **User Override Policy**: User code always takes precedence

### AI Safety
- **Time-Boxed Execution**: Prevents runaway AI processes
- **Operation-Based Changes**: All changes are auditable
- **Failure as Valid Outcome**: AI can report failures honestly
- **No Free-Roaming AI**: Nova is constrained to specific operations

---

## 📦 Dependencies

### Core Dependencies
- **PySide6**: GUI framework
- **PyOpenGL**: OpenGL bindings
- **NumPy**: Numerical operations
- **Pillow/PIL**: Image processing (limited use per user preference)

### Optional Dependencies
- Various AI/ML libraries for Nova
- Audio libraries for sound editing
- Additional packages for specific features

---

## 🎯 Current Focus Areas

Based on recent development:

1. **Object Editor**
   - Collision event system (✅ completed)
   - Instance finding functions (✅ completed)
   - Cross-event variable recognition (✅ completed)
   - Code validation improvements (✅ completed)

2. **Code System**
   - Unified code editor integration
   - Validation pipeline enhancements
   - Context-aware validation

3. **Nova AI**
   - Intent routing improvements
   - Code generation (planned)
   - Time-boxed execution (planned)

---

## 📝 Notes

- **Codebase Size**: Large codebase with 376 files, ~29 MB
- **Active Development**: Object Editor and code testing system
- **Architecture**: Well-structured with clear separation of concerns
- **Documentation**: Comprehensive documentation in `Documentation/`
- **Testing**: Test scripts available for validation
- **Analysis Tools**: Built-in code analysis tools in `Analysis/`

---

## 🔗 Related Files

- `main.py` - Application entry point
- `Plan.md` - Development plan and roadmap
- `Analysis/` - Code analysis results
- `Documentation/` - Project documentation
- `Config/Settings.py` - Configuration system

---

**Last Updated**: Based on current codebase state and analysis files  
**Status**: Active development on Object Editor and code testing system

