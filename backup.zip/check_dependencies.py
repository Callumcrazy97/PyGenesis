"""
Dependency checker and installer for Nova Neural Network.
Checks for required and optional dependencies.
"""
import sys
import subprocess

REQUIRED = {
    'numpy': 'numpy',
}

OPTIONAL = {
    'PySide6': 'PySide6',
}

def check_and_install(package_name, import_name=None, required=True):
    """
    Check if a package is installed, and install it if missing.
    
    Args:
        package_name: Name for pip install
        import_name: Name for import (defaults to package_name)
        required: If True, install if missing. If False, just check.
    """
    if import_name is None:
        import_name = package_name
    
    try:
        __import__(import_name)
        print(f"✅ {package_name} is installed")
        return True
    except ImportError:
        if required:
            print(f"❌ {package_name} is missing. Installing...")
            try:
                subprocess.check_call([sys.executable, "-m", "pip", "install", package_name])
                print(f"✅ {package_name} installed successfully")
                return True
            except subprocess.CalledProcessError:
                print(f"❌ Failed to install {package_name}")
                print(f"   Please install manually: pip install {package_name}")
                return False
        else:
            print(f"⚠️  {package_name} is not installed (optional)")
            print(f"   Install for GUI features: pip install {package_name}")
            return False

def main():
    """Check and install all dependencies."""
    print("=" * 60)
    print("Nova Neural Network - Dependency Checker")
    print("=" * 60)
    print()
    
    all_ok = True
    
    # Check required dependencies
    print("Checking required dependencies...")
    for package, import_name in REQUIRED.items():
        if not check_and_install(package, import_name, required=True):
            all_ok = False
    print()
    
    # Check optional dependencies
    print("Checking optional dependencies...")
    for package, import_name in OPTIONAL.items():
        check_and_install(package, import_name, required=False)
    print()
    
    if all_ok:
        print("=" * 60)
        print("✅ All required dependencies are installed!")
        print("=" * 60)
        return 0
    else:
        print("=" * 60)
        print("❌ Some required dependencies are missing!")
        print("=" * 60)
        return 1

if __name__ == "__main__":
    sys.exit(main())

