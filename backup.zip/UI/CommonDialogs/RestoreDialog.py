"""
Restore Dialog for BackupManager
Allows users to select and restore backups for Editor or Project
"""

from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QListWidget, QListWidgetItem, QMessageBox, QProgressDialog,
    QGroupBox, QCheckBox
)
from PySide6.QtCore import Qt
from pathlib import Path
from datetime import datetime
from Tools.BackupManager.BackupManager import BackupManager


class RestoreDialog(QDialog):
    """Dialog for selecting and restoring backups"""
    
    def __init__(self, backup_type: str = "editor", backup_base_path: Path = None, parent=None):
        """
        Initialize restore dialog
        
        Args:
            backup_type: "editor" or "project"
            backup_base_path: Base path where backups are stored
            parent: Parent widget
        """
        super().__init__(parent)
        self.backup_type = backup_type
        self.backup_base_path = backup_base_path
        self.selected_backup = None
        
        self.setWindowTitle(f"Restore {backup_type.capitalize()} Backup")
        self.setMinimumSize(600, 400)
        
        self.setup_ui()
        self.load_backups()
    
    def setup_ui(self):
        """Setup the dialog UI"""
        layout = QVBoxLayout(self)
        
        # Instructions
        instructions = QLabel(f"Select a backup to restore for the {self.backup_type}:")
        layout.addWidget(instructions)
        
        # Backup list
        list_group = QGroupBox("Available Backups")
        list_layout = QVBoxLayout()
        
        self.backup_list = QListWidget()
        self.backup_list.setAlternatingRowColors(True)
        self.backup_list.itemDoubleClicked.connect(self.accept)
        list_layout.addWidget(self.backup_list)
        
        list_group.setLayout(list_layout)
        layout.addWidget(list_group)
        
        # Options
        options_group = QGroupBox("Restore Options")
        options_layout = QVBoxLayout()
        
        self.overwrite_checkbox = QCheckBox("Overwrite existing files")
        self.overwrite_checkbox.setChecked(True)
        self.overwrite_checkbox.setToolTip("If unchecked, existing files will be skipped during restore")
        options_layout.addWidget(self.overwrite_checkbox)
        
        options_group.setLayout(options_layout)
        layout.addWidget(options_group)
        
        # Buttons
        button_layout = QHBoxLayout()
        button_layout.addStretch()
        
        self.refresh_button = QPushButton("Refresh")
        self.refresh_button.clicked.connect(self.load_backups)
        button_layout.addWidget(self.refresh_button)
        
        self.restore_button = QPushButton("Restore")
        self.restore_button.clicked.connect(self.accept)
        self.restore_button.setDefault(True)
        self.restore_button.setEnabled(False)
        button_layout.addWidget(self.restore_button)
        
        cancel_button = QPushButton("Cancel")
        cancel_button.clicked.connect(self.reject)
        button_layout.addWidget(cancel_button)
        
        layout.addLayout(button_layout)
        
        # Connect selection change
        self.backup_list.itemSelectionChanged.connect(self.on_selection_changed)
    
    def load_backups(self):
        """Load and display available backups"""
        self.backup_list.clear()
        
        if not self.backup_base_path or not self.backup_base_path.exists():
            item = QListWidgetItem("No backup location found")
            item.setFlags(Qt.NoItemFlags)
            self.backup_list.addItem(item)
            return
        
        backup_mgr = BackupManager()
        backups = backup_mgr.list_backups(
            self.backup_base_path,
            use_version_structure=(self.backup_type == "project")
        )
        
        if not backups:
            item = QListWidgetItem("No backups found")
            item.setFlags(Qt.NoItemFlags)
            self.backup_list.addItem(item)
            return
        
        for backup in backups:
            # Format timestamp
            timestamp = datetime.fromtimestamp(backup["timestamp"])
            time_str = timestamp.strftime("%Y-%m-%d %H:%M:%S")
            
            # Create display text
            if backup["main_version"]:
                display_text = f"Backup #{backup['backup_number']} (v{backup['main_version']}, {backup['range']}) - {time_str}"
            else:
                display_text = f"Backup #{backup['backup_number']} ({backup['range']}) - {time_str}"
            
            item = QListWidgetItem(display_text)
            item.setData(Qt.UserRole, backup)
            self.backup_list.addItem(item)
    
    def on_selection_changed(self):
        """Handle backup selection change"""
        selected_items = self.backup_list.selectedItems()
        self.restore_button.setEnabled(len(selected_items) > 0)
    
    def get_selected_backup(self):
        """Get the selected backup info"""
        selected_items = self.backup_list.selectedItems()
        if selected_items:
            return selected_items[0].data(Qt.UserRole)
        return None
    
    def should_overwrite(self):
        """Check if overwrite option is enabled"""
        return self.overwrite_checkbox.isChecked()
    
    def accept(self):
        """Handle accept (restore button clicked)"""
        backup = self.get_selected_backup()
        if not backup:
            QMessageBox.warning(self, "No Selection", "Please select a backup to restore.")
            return
        
        # Confirm restore
        reply = QMessageBox.question(
            self,
            "Confirm Restore",
            f"Are you sure you want to restore Backup #{backup['backup_number']}?\n\n"
            f"This will {'overwrite' if self.should_overwrite() else 'skip'} existing files.",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No
        )
        
        if reply == QMessageBox.Yes:
            self.selected_backup = backup
            super().accept()

