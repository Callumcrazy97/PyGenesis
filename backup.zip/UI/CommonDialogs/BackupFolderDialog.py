"""
Dialog for selecting folders to include/exclude in backups
"""

from PySide6.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QWidget, 
                               QLabel, QPushButton, QCheckBox, QListWidget, 
                               QListWidgetItem, QGroupBox, QMessageBox)
from PySide6.QtCore import Qt
from pathlib import Path
from typing import Dict, Set, Optional


class BackupFolderDialog(QDialog):
    """Dialog for selecting which folders to include/exclude in backup"""
    
    def __init__(self, source_dir: Path, backup_type: str = "editor", parent=None):
        """
        Initialize backup folder dialog
        
        Args:
            source_dir: Source directory to backup
            backup_type: "editor" or "project"
            parent: Parent widget
        """
        super().__init__(parent)
        self.source_dir = Path(source_dir)
        self.backup_type = backup_type
        self.folder_states: Dict[str, bool] = {}  # folder_name -> include (True) or exclude (False)
        self.setup_ui()
        self.load_defaults()
        self.populate_folders()
    
    def setup_ui(self):
        """Setup the dialog UI"""
        self.setWindowTitle(f"Select Folders for {self.backup_type.capitalize()} Backup")
        self.setMinimumSize(500, 600)
        
        layout = QVBoxLayout(self)
        
        # Instructions
        info_label = QLabel(
            "Select which folders to include or exclude from the backup.\n"
            "Checked folders will be included, unchecked will be excluded."
        )
        info_label.setWordWrap(True)
        layout.addWidget(info_label)
        
        # Folder list
        folder_group = QGroupBox("Folders")
        folder_layout = QVBoxLayout(folder_group)
        
        self.folder_list = QListWidget()
        self.folder_list.setSelectionMode(QListWidget.MultiSelection)
        folder_layout.addWidget(self.folder_list)
        
        # Buttons for quick selection
        button_layout = QHBoxLayout()
        self.select_all_btn = QPushButton("Select All")
        self.select_all_btn.clicked.connect(self.select_all)
        self.select_none_btn = QPushButton("Select None")
        self.select_none_btn.clicked.connect(self.select_none)
        self.reset_defaults_btn = QPushButton("Reset to Defaults")
        self.reset_defaults_btn.clicked.connect(self.reset_to_defaults)
        button_layout.addWidget(self.select_all_btn)
        button_layout.addWidget(self.select_none_btn)
        button_layout.addWidget(self.reset_defaults_btn)
        folder_layout.addLayout(button_layout)
        
        layout.addWidget(folder_group)
        
        # Dialog buttons
        button_box = QHBoxLayout()
        self.ok_btn = QPushButton("OK")
        self.ok_btn.clicked.connect(self.accept)
        self.cancel_btn = QPushButton("Cancel")
        self.cancel_btn.clicked.connect(self.reject)
        button_box.addStretch()
        button_box.addWidget(self.ok_btn)
        button_box.addWidget(self.cancel_btn)
        layout.addLayout(button_box)
    
    def load_defaults(self):
        """Load default folder inclusion/exclusion settings"""
        # Editor defaults: exclude __pycache__, include venv
        if self.backup_type == "editor":
            self.default_includes = {"venv", "Core", "UI", "Editors", "Config"}
            self.default_excludes = {"__pycache__", ".git", ".idea", ".vscode", 
                                    "node_modules", "dist", "build", ".mypy_cache", 
                                    ".pytest_cache", ".tox", ".venv", "env", ".env"}
        else:  # project
            self.default_includes = set()  # User will specify
            self.default_excludes = {"__pycache__", ".git", ".idea", ".vscode",
                                    "node_modules", "dist", "build", ".mypy_cache",
                                    ".pytest_cache", ".tox"}
    
    def populate_folders(self):
        """Populate the folder list from source directory"""
        self.folder_list.clear()
        
        if not self.source_dir.exists():
            return
        
        # Get all top-level directories
        folders = []
        for item in sorted(self.source_dir.iterdir()):
            if item.is_dir():
                folder_name = item.name
                folders.append(folder_name)
                
                # Create list item with checkbox
                item_widget = QListWidgetItem(folder_name)
                item_widget.setFlags(item_widget.flags() | Qt.ItemIsUserCheckable)
                
                # Set default state
                if folder_name in self.default_includes:
                    item_widget.setCheckState(Qt.Checked)
                    self.folder_states[folder_name] = True
                elif folder_name in self.default_excludes:
                    item_widget.setCheckState(Qt.Unchecked)
                    self.folder_states[folder_name] = False
                else:
                    # Default: include for editor (except known excludes), exclude for project
                    if self.backup_type == "editor":
                        item_widget.setCheckState(Qt.Checked)
                        self.folder_states[folder_name] = True
                    else:
                        item_widget.setCheckState(Qt.Unchecked)
                        self.folder_states[folder_name] = False
                
                self.folder_list.addItem(item_widget)
    
    def select_all(self):
        """Select all folders"""
        for i in range(self.folder_list.count()):
            item = self.folder_list.item(i)
            item.setCheckState(Qt.Checked)
            self.folder_states[item.text()] = True
    
    def select_none(self):
        """Deselect all folders"""
        for i in range(self.folder_list.count()):
            item = self.folder_list.item(i)
            item.setCheckState(Qt.Unchecked)
            self.folder_states[item.text()] = False
    
    def reset_to_defaults(self):
        """Reset to default folder selections"""
        self.load_defaults()
        self.populate_folders()
    
    def get_folder_states(self) -> Dict[str, bool]:
        """Get current folder inclusion states"""
        # Update from current checkboxes
        for i in range(self.folder_list.count()):
            item = self.folder_list.item(i)
            folder_name = item.text()
            self.folder_states[folder_name] = (item.checkState() == Qt.Checked)
        return self.folder_states.copy()
    
    def get_included_folders(self) -> Set[str]:
        """Get set of included folder names"""
        states = self.get_folder_states()
        return {name for name, included in states.items() if included}
    
    def get_excluded_folders(self) -> Set[str]:
        """Get set of excluded folder names"""
        states = self.get_folder_states()
        return {name for name, included in states.items() if not included}

