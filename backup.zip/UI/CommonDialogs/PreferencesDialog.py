"""
Preferences Dialog for Python Game IDE
Centralized preferences for all editors and settings
"""

from PySide6.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QTabWidget, 
                               QWidget, QLabel, QPushButton, QComboBox, QSpinBox,
                               QDoubleSpinBox, QCheckBox, QLineEdit, QGroupBox, QGridLayout,
                               QFileDialog, QColorDialog, QListWidget,
                               QListWidgetItem, QSplitter, QTextEdit, QSlider,
                               QMessageBox, QScrollArea)
from PySide6.QtWidgets import QDialogButtonBox
from PySide6.QtCore import Qt, Signal, QCoreApplication
from PySide6.QtGui import QColor, QFont

class PreferencesDialog(QDialog):
    """Centralized preferences dialog"""
    
    preferences_changed = Signal()  # Emitted when preferences change
    
    def __init__(self, app, parent=None):
        super().__init__(parent)
        self.app = app
        self.theme_manager = app.theme_manager
        self.settings = app.settings
        self.setup_ui()
        self.load_settings()
        self.apply_theme()
    
    def setup_ui(self):
        """Setup the preferences UI"""
        self.setWindowTitle("Preferences")
        self.setModal(True)
        
        # Set a reasonable initial size that fits most screens
        self.resize(800, 650)
        self.setMinimumSize(700, 500)
        
        # Main layout
        layout = QVBoxLayout(self)
        layout.setContentsMargins(10, 10, 10, 10)
        layout.setSpacing(10)
        
        # Create tab widget
        self.tab_widget = QTabWidget()
        layout.addWidget(self.tab_widget)
        
        # Create tabs (each will be made scrollable internally)
        self.create_general_tab()
        self.create_project_tab()
        self.create_appearance_tabs()
        self.create_ai_tab()
        self.create_editor_specific_tab()  # This creates editor_tab_widget and calls create_code_tab()
        
        # Button box - always visible at bottom
        button_box = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel | QDialogButtonBox.Apply)
        button_box.accepted.connect(self.accept)
        button_box.rejected.connect(self.reject)
        button_box.button(QDialogButtonBox.Apply).clicked.connect(self.apply_settings)
        layout.addWidget(button_box)
    
    def _make_scrollable(self, widget):
        """Wrap a widget in a scroll area"""
        scroll = QScrollArea()
        scroll.setWidget(widget)
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QScrollArea.NoFrame)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        scroll.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        return scroll
    
    def create_general_tab(self):
        """Create General settings tab"""
        tab = QWidget()
        layout = QVBoxLayout(tab)
        
        # User Information group
        user_group = QGroupBox("User Information")
        user_layout = QGridLayout(user_group)
        
        # User name
        user_layout.addWidget(QLabel("Name:"), 0, 0)
        self.user_name = QLineEdit()
        self.user_name.setPlaceholderText("Engineer")
        user_layout.addWidget(self.user_name, 0, 1)
        
        user_info_label = QLabel(
            "Your name will appear in Nova chats, published games, and the 'About My Game' section. "
            "All fields are optional."
        )
        user_info_label.setWordWrap(True)
        user_info_label.setStyleSheet("color: #888; font-size: 9pt;")
        user_layout.addWidget(user_info_label, 1, 0, 1, 2)
        
        # Email (optional)
        user_layout.addWidget(QLabel("Email (optional):"), 2, 0)
        self.user_email = QLineEdit()
        self.user_email.setPlaceholderText("your.email@example.com")
        user_layout.addWidget(self.user_email, 2, 1)
        
        # Website (optional)
        user_layout.addWidget(QLabel("Website (optional):"), 3, 0)
        self.user_website = QLineEdit()
        self.user_website.setPlaceholderText("https://yourwebsite.com")
        user_layout.addWidget(self.user_website, 3, 1)
        
        layout.addWidget(user_group)
        
        # Language settings group
        language_group = QGroupBox("Language & Spelling")
        language_layout = QGridLayout(language_group)
        
        # Language preference
        language_layout.addWidget(QLabel("Language:"), 0, 0)
        self.language_combo = QComboBox()
        self.language_combo.addItem("English (UK)", "en_uk")
        self.language_combo.addItem("English (US)", "en_us")
        self.language_combo.setToolTip(
            "Select your preferred English variant. This affects:\n"
            "- Nova's responses (spelling and word choice)\n"
            "- Dictionary and thesaurus lookups\n"
            "- Spell checking\n"
            "- Code blocks are always in US English"
        )
        language_layout.addWidget(self.language_combo, 0, 1)
        
        language_info = QLabel(
            "Nova will use the selected language variant for responses and spell checking. "
            "Code examples and technical terms remain in US English."
        )
        language_info.setWordWrap(True)
        language_info.setStyleSheet("color: #888; font-size: 9pt;")
        language_layout.addWidget(language_info, 1, 0, 1, 2)
        
        layout.addWidget(language_group)
        
        # Advanced Mode group
        advanced_group = QGroupBox("Advanced Mode")
        advanced_layout = QGridLayout(advanced_group)
        
        # Advanced Mode checkbox
        self.advanced_mode = QCheckBox("Enable Advanced Mode")
        self.advanced_mode.setToolTip(
            "When enabled:\n"
            "- Nova can code in both PGSL and Python\n"
            "- Custom syntax checking is enabled\n"
            "- Full code generation capabilities\n\n"
            "When disabled:\n"
            "- Nova can only code in PGSL (Simple Mode)\n"
            "- Restricted to PGSL syntax only"
        )
        advanced_layout.addWidget(self.advanced_mode, 0, 0, 1, 2)
        
        advanced_info = QLabel(
            "Advanced Mode allows Nova to use both PGSL and Python for code generation. "
            "In Simple Mode, Nova is restricted to PGSL only. This setting affects all code editors "
            "(Script, Object, Shader, Particle, etc.)."
        )
        advanced_info.setWordWrap(True)
        advanced_info.setStyleSheet("color: #888; font-size: 9pt;")
        advanced_layout.addWidget(advanced_info, 1, 0, 1, 2)
        
        layout.addWidget(advanced_group)
        
        # Project settings group
        project_group = QGroupBox("Project Settings")
        project_layout = QGridLayout(project_group)
        
        # Default project location
        project_layout.addWidget(QLabel("Default Project Location:"), 0, 0)
        self.default_project_path = QLineEdit()
        self.browse_project_btn = QPushButton("Browse...")
        self.browse_project_btn.clicked.connect(self.browse_project_path)
        project_layout.addWidget(self.default_project_path, 0, 1)
        project_layout.addWidget(self.browse_project_btn, 0, 2)
        
        # Auto-save settings
        self.auto_save_enabled = QCheckBox("Enable Auto-Save")
        self.auto_save_interval = QSpinBox()
        self.auto_save_interval.setRange(1, 60)
        self.auto_save_interval.setSuffix(" minutes")
        project_layout.addWidget(self.auto_save_enabled, 1, 0, 1, 2)
        project_layout.addWidget(QLabel("Auto-Save Interval:"), 2, 0)
        project_layout.addWidget(self.auto_save_interval, 2, 1)
        
        layout.addWidget(project_group)
        
        # Environment settings group
        env_group = QGroupBox("Environment Settings")
        env_layout = QGridLayout(env_group)
        
        # Environment location (VENV path)
        env_layout.addWidget(QLabel("Environment Location:"), 0, 0)
        self.venv_path = QLineEdit()
        self.venv_path.setPlaceholderText("Leave empty to use default: C:\\Users\\YourName\\pygenesis\\venv")
        self.browse_venv_btn = QPushButton("Browse...")
        self.browse_venv_btn.clicked.connect(self.browse_venv_path)
        env_layout.addWidget(self.venv_path, 0, 1)
        env_layout.addWidget(self.browse_venv_btn, 0, 2)
        
        env_info = QLabel("Specify a custom path for the Python virtual environment.\nLeave empty to use the default user folder location.")
        env_info.setWordWrap(True)
        env_info.setStyleSheet("color: #888; font-size: 9pt;")
        env_layout.addWidget(env_info, 1, 0, 1, 3)
        
        layout.addWidget(env_group)
        
        # Debug settings group
        debug_group = QGroupBox("Debug Settings")
        debug_layout = QGridLayout(debug_group)
        
        self.debug_enabled = QCheckBox("Enable Debug Output")
        self.debug_enabled.setToolTip("When enabled, shows detailed debug messages. When disabled, only shows critical startup messages.")
        debug_layout.addWidget(self.debug_enabled, 0, 0, 1, 2)
        
        layout.addWidget(debug_group)
        
        # Editor settings group
        editor_group = QGroupBox("Editor Settings")
        editor_layout = QGridLayout(editor_group)
        
        # Grid settings
        self.show_grid = QCheckBox("Show Grid by Default")
        self.grid_size = QSpinBox()
        self.grid_size.setRange(8, 128)
        self.snap_to_grid = QCheckBox("Snap to Grid by Default")
        editor_layout.addWidget(self.show_grid, 0, 0)
        editor_layout.addWidget(QLabel("Default Grid Size:"), 1, 0)
        editor_layout.addWidget(self.grid_size, 1, 1)
        editor_layout.addWidget(self.snap_to_grid, 2, 0)
        
        # Undo/Redo settings
        self.undo_levels = QSpinBox()
        self.undo_levels.setRange(10, 1000)
        editor_layout.addWidget(QLabel("Undo Levels:"), 3, 0)
        editor_layout.addWidget(self.undo_levels, 3, 1)
        
        layout.addWidget(editor_group)
        
        # Recent projects group
        recent_group = QGroupBox("Recent Projects")
        recent_layout = QVBoxLayout(recent_group)
        
        self.recent_projects_list = QListWidget()
        self.recent_projects_list.itemDoubleClicked.connect(self._on_recent_project_double_clicked)
        self.clear_recent_btn = QPushButton("Clear Recent Projects")
        self.clear_recent_btn.clicked.connect(self.clear_recent_projects)
        recent_layout.addWidget(self.recent_projects_list)
        recent_layout.addWidget(self.clear_recent_btn)
        
        layout.addWidget(recent_group)
        
        # Backup settings group
        backup_group = QGroupBox("Backup Settings")
        backup_layout = QGridLayout(backup_group)
        
        # Editor backup location
        backup_layout.addWidget(QLabel("Editor Backup Location:"), 0, 0)
        self.editor_backup_path = QLineEdit()
        self.browse_editor_backup_btn = QPushButton("Browse...")
        self.browse_editor_backup_btn.clicked.connect(self.browse_editor_backup_path)
        backup_layout.addWidget(self.editor_backup_path, 0, 1)
        backup_layout.addWidget(self.browse_editor_backup_btn, 0, 2)
        
        editor_backup_info = QLabel("Location where editor backups are stored. Uses numeric category structure (0-9, 10-19, etc.)")
        editor_backup_info.setWordWrap(True)
        editor_backup_info.setStyleSheet("color: #888; font-size: 9pt;")
        backup_layout.addWidget(editor_backup_info, 1, 0, 1, 3)
        
        # Project backup location
        backup_layout.addWidget(QLabel("Project Backup Location:"), 2, 0)
        self.project_backup_path = QLineEdit()
        self.browse_project_backup_btn = QPushButton("Browse...")
        self.browse_project_backup_btn.clicked.connect(self.browse_project_backup_path)
        backup_layout.addWidget(self.project_backup_path, 2, 1)
        backup_layout.addWidget(self.browse_project_backup_btn, 2, 2)
        
        project_backup_info = QLabel("Base location for project backups. Each project is backed up to a subfolder with the project name.")
        project_backup_info.setWordWrap(True)
        project_backup_info.setStyleSheet("color: #888; font-size: 9pt;")
        backup_layout.addWidget(project_backup_info, 3, 0, 1, 3)
        
        layout.addWidget(backup_group)
        
        # Generate Summary settings group
        summary_group = QGroupBox("Generate Summary")
        summary_layout = QGridLayout(summary_group)
        
        # Editor summary location
        summary_layout.addWidget(QLabel("Editor Summary Location:"), 0, 0)
        self.editor_summary_path = QLineEdit()
        self.browse_editor_summary_btn = QPushButton("Browse...")
        self.browse_editor_summary_btn.clicked.connect(self.browse_editor_summary_path)
        summary_layout.addWidget(self.editor_summary_path, 0, 1)
        summary_layout.addWidget(self.browse_editor_summary_btn, 0, 2)
        
        editor_summary_info = QLabel("Location where editor codebase summaries are saved. Uses same location as Editor Backups by default.")
        editor_summary_info.setWordWrap(True)
        editor_summary_info.setStyleSheet("color: #888; font-size: 9pt;")
        summary_layout.addWidget(editor_summary_info, 1, 0, 1, 3)
        
        self.generate_editor_summary_btn = QPushButton("Generate Editor Summary")
        self.generate_editor_summary_btn.clicked.connect(self.generate_editor_summary)
        summary_layout.addWidget(self.generate_editor_summary_btn, 2, 0, 1, 3)
        
        layout.addWidget(summary_group)
        layout.addStretch()
        
        # Wrap in scroll area for smaller screens
        scroll_tab = self._make_scrollable(tab)
        self.tab_widget.addTab(scroll_tab, "General")
    
    def create_project_tab(self):
        """Create Project settings tab"""
        tab = QWidget()
        layout = QVBoxLayout(tab)
        
        # Project information group
        info_group = QGroupBox("Project Information")
        info_layout = QGridLayout(info_group)
        
        info_layout.addWidget(QLabel("Project Title:"), 0, 0)
        self.project_title = QLineEdit()
        info_layout.addWidget(self.project_title, 0, 1)
        
        info_layout.addWidget(QLabel("Author:"), 1, 0)
        self.project_author = QLineEdit()
        info_layout.addWidget(self.project_author, 1, 1)
        
        info_layout.addWidget(QLabel("Version:"), 2, 0)
        self.project_version = QLineEdit()
        info_layout.addWidget(self.project_version, 2, 1)
        
        info_layout.addWidget(QLabel("Description:"), 3, 0)
        self.project_description = QTextEdit()
        self.project_description.setMaximumHeight(100)
        info_layout.addWidget(self.project_description, 3, 1)
        
        layout.addWidget(info_group)
        
        # Game settings group
        game_group = QGroupBox("Game Settings")
        game_layout = QGridLayout(game_group)
        
        self.target_fps = QSpinBox()
        self.target_fps.setRange(30, 240)
        self.target_fps.setSuffix(" FPS")
        game_layout.addWidget(QLabel("Target FPS:"), 0, 0)
        game_layout.addWidget(self.target_fps, 0, 1)
        
        self.window_width = QSpinBox()
        self.window_width.setRange(320, 4096)
        self.window_height = QSpinBox()
        self.window_height.setRange(240, 4096)
        game_layout.addWidget(QLabel("Default Window Size:"), 1, 0)
        game_layout.addWidget(self.window_width, 1, 1)
        game_layout.addWidget(QLabel("x"), 1, 2)
        game_layout.addWidget(self.window_height, 1, 3)
        
        self.fullscreen = QCheckBox("Start in Fullscreen")
        game_layout.addWidget(self.fullscreen, 2, 0)
        
        layout.addWidget(game_group)
        
        # Generate Summary settings group (Project Specific)
        summary_group = QGroupBox("Generate Summary (Project Specific)")
        summary_layout = QGridLayout(summary_group)
        
        summary_info = QLabel("Project summaries are saved to the project root folder by default.")
        summary_info.setWordWrap(True)
        summary_info.setStyleSheet("color: #888; font-size: 9pt;")
        summary_layout.addWidget(summary_info, 0, 0, 1, 2)
        
        self.generate_project_summary_btn = QPushButton("Generate Project Summary")
        self.generate_project_summary_btn.clicked.connect(self.generate_project_summary)
        summary_layout.addWidget(self.generate_project_summary_btn, 1, 0, 1, 2)
        
        layout.addWidget(summary_group)
        layout.addStretch()
        
        # Wrap in scroll area for smaller screens
        scroll_tab = self._make_scrollable(tab)
        self.tab_widget.addTab(scroll_tab, "Project")
    
    def create_appearance_tabs(self):
        """Create Appearance settings with PyGenesis and Nova sub-tabs"""
        # Create container tab
        container_tab = QWidget()
        container_layout = QVBoxLayout(container_tab)
        container_layout.setContentsMargins(0, 0, 0, 0)
        
        # Create sub-tab widget
        appearance_tabs = QTabWidget()
        container_layout.addWidget(appearance_tabs)
        
        # Create PyGenesis Appearance tab
        pygenesis_tab = self.create_pygenesis_appearance_tab()
        appearance_tabs.addTab(pygenesis_tab, "PyGenesis")
        
        # Create Nova Appearance tab (already exists in AI tab, but we'll create it here too for consistency)
        nova_tab = self.create_nova_appearance_tab()
        appearance_tabs.addTab(nova_tab, "Nova")
        
        # Wrap in scroll area and add to main tab widget
        scroll_tab = self._make_scrollable(container_tab)
        self.tab_widget.addTab(scroll_tab, "Appearance")
    
    def create_pygenesis_appearance_tab(self):
        """Create PyGenesis Appearance settings tab"""
        tab = QWidget()
        layout = QVBoxLayout(tab)
        
        # Theme settings group
        theme_group = QGroupBox("Theme")
        theme_layout = QGridLayout(theme_group)
        
        theme_layout.addWidget(QLabel("Theme:"), 0, 0)
        self.theme_combo = QComboBox()
        self.refresh_theme_list()
        self.theme_combo.currentTextChanged.connect(self.on_theme_changed)
        theme_layout.addWidget(self.theme_combo, 0, 1)
        
        # Custom theme management buttons
        theme_btn_layout = QHBoxLayout()
        self.save_theme_btn = QPushButton("Save as Custom Theme")
        self.save_theme_btn.clicked.connect(self.save_custom_theme)
        theme_btn_layout.addWidget(self.save_theme_btn)
        
        self.delete_theme_btn = QPushButton("Delete Custom Theme")
        self.delete_theme_btn.clicked.connect(self.delete_custom_theme)
        theme_btn_layout.addWidget(self.delete_theme_btn)
        
        theme_layout.addLayout(theme_btn_layout, 1, 0, 1, 2)
        
        # Accent color
        theme_layout.addWidget(QLabel("Accent Color:"), 2, 0)
        self.accent_color_btn = QPushButton()
        self.accent_color_btn.clicked.connect(self.choose_accent_color)
        theme_layout.addWidget(self.accent_color_btn, 2, 1)
        
        # Font settings
        font_group = QGroupBox("Fonts")
        font_layout = QGridLayout(font_group)
        
        self.ui_font_size = QSpinBox()
        self.ui_font_size.setRange(8, 24)
        self.ui_font_size.setSuffix(" pt")
        self.ui_font_size.valueChanged.connect(self.on_ui_font_size_changed)
        font_layout.addWidget(QLabel("UI Font Size:"), 0, 0)
        font_layout.addWidget(self.ui_font_size, 0, 1)
        
        self.editor_font_size = QSpinBox()
        self.editor_font_size.setRange(8, 24)
        self.editor_font_size.setSuffix(" pt")
        font_layout.addWidget(QLabel("Editor Font Size:"), 1, 0)
        font_layout.addWidget(self.editor_font_size, 1, 1)
        
        self.editor_font_family = QComboBox()
        self.editor_font_family.addItems(["Consolas", "Courier New", "Monaco", "Source Code Pro"])
        font_layout.addWidget(QLabel("Editor Font Family:"), 2, 0)
        font_layout.addWidget(self.editor_font_family, 2, 1)
        
        # Color customization group
        color_group = QGroupBox("Color Customization")
        color_layout = QGridLayout(color_group)
        
        # Font color
        color_layout.addWidget(QLabel("Font Color:"), 0, 0)
        self.font_color_btn = QPushButton()
        self.font_color_btn.clicked.connect(lambda: self.choose_color("font_color"))
        color_layout.addWidget(self.font_color_btn, 0, 1)
        
        # Button color
        color_layout.addWidget(QLabel("Button Color:"), 1, 0)
        self.button_color_btn = QPushButton()
        self.button_color_btn.clicked.connect(lambda: self.choose_color("button_color"))
        color_layout.addWidget(self.button_color_btn, 1, 1)
        
        # Menu color
        color_layout.addWidget(QLabel("Menu Color:"), 2, 0)
        self.menu_color_btn = QPushButton()
        self.menu_color_btn.clicked.connect(lambda: self.choose_color("menu_color"))
        color_layout.addWidget(self.menu_color_btn, 2, 1)
        
        # Background color
        color_layout.addWidget(QLabel("Background Color:"), 3, 0)
        self.background_color_btn = QPushButton()
        self.background_color_btn.clicked.connect(lambda: self.choose_color("background_color"))
        color_layout.addWidget(self.background_color_btn, 3, 1)
        
        # Border color
        color_layout.addWidget(QLabel("Border Color:"), 4, 0)
        self.border_color_btn = QPushButton()
        self.border_color_btn.clicked.connect(lambda: self.choose_color("border_color"))
        color_layout.addWidget(self.border_color_btn, 4, 1)
        
        # Input field color
        color_layout.addWidget(QLabel("Input Field Color:"), 5, 0)
        self.input_color_btn = QPushButton()
        self.input_color_btn.clicked.connect(lambda: self.choose_color("input_color"))
        color_layout.addWidget(self.input_color_btn, 5, 1)
        
        # Reset colors button
        self.reset_colors_btn = QPushButton("Reset to Theme Defaults")
        self.reset_colors_btn.clicked.connect(self.reset_colors)
        color_layout.addWidget(self.reset_colors_btn, 6, 0, 1, 2)
        
        layout.addWidget(theme_group)
        layout.addWidget(font_group)
        layout.addWidget(color_group)
        
        # Preview group
        preview_group = QGroupBox("Preview")
        preview_layout = QVBoxLayout(preview_group)
        
        self.preview_widget = QWidget()
        self.preview_widget.setMinimumHeight(150)
        self.preview_widget.setStyleSheet("""
            QWidget {
                background-color: #2b2b2b;
                color: #ffffff;
                border: 1px solid #555555;
            }
        """)
        preview_layout.addWidget(self.preview_widget)
        
        layout.addWidget(preview_group)
        layout.addStretch()
        
        # Return tab (parent will handle scrolling/wrapping)
        return tab
    
    def create_nova_appearance_tab(self):
        """Create Nova Appearance settings tab (Nova-specific appearance settings)"""
        import sys
        import os
        from pathlib import Path
        
        tab = QWidget()
        layout = QVBoxLayout(tab)
        
        # Add Nova directory to path for imports
        # Path from UI/CommonDialogs/PreferencesDialog.py to Core/AI/PyGenesisAssistant/Nova
        # Go up: UI/CommonDialogs -> UI -> root (Temp) -> Core/AI/PyGenesisAssistant/Nova
        nova_dir = Path(__file__).parent.parent.parent / "Core" / "AI" / "PyGenesisAssistant" / "Nova"
        nova_dir_str = str(nova_dir.resolve())
        
        if not nova_dir.exists():
            # Fallback: try alternative path structure
            info = QLabel(f"Could not find Nova directory at:\n{nova_dir_str}\n\nNova appearance settings are not available.")
            info.setWordWrap(True)
            layout.addWidget(info)
            return tab
        
        if nova_dir_str not in sys.path:
            sys.path.insert(0, nova_dir_str)
        
        nova_parent = nova_dir.parent
        nova_parent_str = str(nova_parent.resolve())
        if nova_parent_str not in sys.path:
            sys.path.insert(0, nova_parent_str)
        
        try:
            # Change to nova directory temporarily for imports
            old_cwd = os.getcwd()
            try:
                os.chdir(nova_dir_str)
                from ui.settings_dialog import AppearanceTab
                nova_appearance = AppearanceTab(self)
                layout.addWidget(nova_appearance)
            finally:
                os.chdir(old_cwd)
        except ImportError as e:
            import traceback
            error_msg = f"Could not load Nova appearance settings: {e}"
            # Fallback if Nova imports fail
            info = QLabel(f"Could not load Nova appearance settings:\n{str(e)}\n\nPlease check that Nova is properly installed.")
            info.setWordWrap(True)
            layout.addWidget(info)
            print(f"Nova import error: {error_msg}\n{traceback.format_exc()}")
        except Exception as e:
            import traceback
            error_msg = f"Error loading Nova appearance: {e}"
            info = QLabel(f"Error loading Nova appearance settings:\n{str(e)}")
            info.setWordWrap(True)
            layout.addWidget(info)
            print(f"Nova error: {error_msg}\n{traceback.format_exc()}")
        
        return tab
    
    def create_code_tab(self):
        """Create Code editor settings tab (combines Script and PGSL settings)"""
        tab = QWidget()
        layout = QVBoxLayout(tab)
        
        # Editor behavior group
        behavior_group = QGroupBox("Editor Behavior")
        behavior_layout = QGridLayout(behavior_group)
        
        self.tab_size = QSpinBox()
        self.tab_size.setRange(2, 8)
        self.tab_size.setSuffix(" spaces")
        behavior_layout.addWidget(QLabel("Tab Size:"), 0, 0)
        behavior_layout.addWidget(self.tab_size, 0, 1)
        
        self.insert_spaces = QCheckBox("Insert Spaces for Tabs")
        behavior_layout.addWidget(self.insert_spaces, 1, 0)
        
        self.word_wrap = QCheckBox("Word Wrap")
        behavior_layout.addWidget(self.word_wrap, 2, 0)
        
        self.line_numbers = QCheckBox("Show Line Numbers")
        behavior_layout.addWidget(self.line_numbers, 3, 0)
        
        self.auto_indent = QCheckBox("Auto Indent")
        behavior_layout.addWidget(self.auto_indent, 4, 0)
        
        layout.addWidget(behavior_group)
        
        # Syntax highlighting group
        syntax_group = QGroupBox("Syntax Highlighting")
        syntax_layout = QGridLayout(syntax_group)
        
        self.syntax_highlighting = QCheckBox("Enable Syntax Highlighting")
        syntax_layout.addWidget(self.syntax_highlighting, 0, 0)
        
        self.bracket_matching = QCheckBox("Bracket Matching")
        syntax_layout.addWidget(self.bracket_matching, 1, 0)
        
        self.auto_completion = QCheckBox("Auto Completion")
        syntax_layout.addWidget(self.auto_completion, 2, 0)
        
        self.auto_completion_threshold = QSpinBox()
        self.auto_completion_threshold.setRange(1, 10)
        syntax_layout.addWidget(QLabel("Auto Completion Threshold:"), 3, 0)
        syntax_layout.addWidget(self.auto_completion_threshold, 3, 1)
        
        layout.addWidget(syntax_group)
        
        # PGSL Settings group
        pgsl_group = QGroupBox("PGSL (PyGenesis Scripting Language)")
        pgsl_layout = QGridLayout(pgsl_group)
        
        # Enable PGSL parsing
        self.pgsl_enabled = QCheckBox("Enable PGSL Parsing")
        self.pgsl_enabled.setToolTip("When enabled, PGSL commands in object events and scripts will be automatically converted to Python")
        pgsl_layout.addWidget(self.pgsl_enabled, 0, 0, 1, 2)
        
        # Show PGSL syntax highlighting
        self.pgsl_syntax_highlight = QCheckBox("Show PGSL Syntax Highlighting")
        self.pgsl_syntax_highlight.setToolTip("Highlight PGSL commands in code editors")
        pgsl_layout.addWidget(self.pgsl_syntax_highlight, 1, 0, 1, 2)
        
        # Auto-parse on save
        self.pgsl_auto_parse = QCheckBox("Auto-parse PGSL on Save")
        self.pgsl_auto_parse.setToolTip("Automatically parse PGSL code when saving objects/scripts")
        pgsl_layout.addWidget(self.pgsl_auto_parse, 2, 0, 1, 2)
        
        layout.addWidget(pgsl_group)
        
        # Compiler Settings group
        compiler_group = QGroupBox("Compiler & Build Settings")
        compiler_layout = QGridLayout(compiler_group)
        
        # Default window size (for new projects)
        compiler_layout.addWidget(QLabel("Default Window Width:"), 0, 0)
        self.default_window_width = QSpinBox()
        self.default_window_width.setRange(320, 7680)
        self.default_window_width.setValue(800)
        compiler_layout.addWidget(self.default_window_width, 0, 1)
        
        compiler_layout.addWidget(QLabel("Default Window Height:"), 1, 0)
        self.default_window_height = QSpinBox()
        self.default_window_height.setRange(240, 4320)
        self.default_window_height.setValue(600)
        compiler_layout.addWidget(self.default_window_height, 1, 1)
        
        # Default FPS
        compiler_layout.addWidget(QLabel("Default Game Speed (FPS):"), 2, 0)
        self.default_game_fps = QSpinBox()
        self.default_game_fps.setRange(1, 240)
        self.default_game_fps.setValue(60)
        compiler_layout.addWidget(self.default_game_fps, 2, 1)
        
        # Build output directory
        compiler_layout.addWidget(QLabel("Build Output Directory:"), 3, 0)
        self.build_output_dir = QLineEdit()
        self.browse_build_btn = QPushButton("Browse...")
        self.browse_build_btn.clicked.connect(self.browse_build_output)
        compiler_layout.addWidget(self.build_output_dir, 3, 1)
        compiler_layout.addWidget(self.browse_build_btn, 3, 2)
        
        # Validate scripts before run/debug/build
        self.validate_before_run = QCheckBox("Validate Scripts Before Run/Debug/Build")
        self.validate_before_run.setToolTip("Check all scripts for errors before running, debugging, or building the game")
        compiler_layout.addWidget(self.validate_before_run, 4, 0, 1, 3)
        
        layout.addWidget(compiler_group)
        layout.addStretch()
        
        # Add to tab widget under Editor Specific
        scroll = self._make_scrollable(tab)
        self.editor_tab_widget.addTab(scroll, "Code")
    
    def create_pgsl_tab_old_removed(self):
        """Create PGSL and Compiler settings tab"""
        tab = QWidget()
        layout = QVBoxLayout(tab)
        
        # PGSL Settings group
        pgsl_group = QGroupBox("PGSL (PyGenesis Shortcut Language) Settings")
        pgsl_layout = QGridLayout(pgsl_group)
        
        # Enable PGSL parsing
        self.pgsl_enabled = QCheckBox("Enable PGSL Parsing")
        self.pgsl_enabled.setToolTip("When enabled, PGSL commands in object events and scripts will be automatically converted to Python")
        pgsl_layout.addWidget(self.pgsl_enabled, 0, 0, 1, 2)
        
        # Show PGSL syntax highlighting
        self.pgsl_syntax_highlight = QCheckBox("Show PGSL Syntax Highlighting")
        self.pgsl_syntax_highlight.setToolTip("Highlight PGSL commands in code editors")
        pgsl_layout.addWidget(self.pgsl_syntax_highlight, 1, 0, 1, 2)
        
        # Auto-parse on save
        self.pgsl_auto_parse = QCheckBox("Auto-parse PGSL on Save")
        self.pgsl_auto_parse.setToolTip("Automatically parse PGSL code when saving objects/scripts")
        pgsl_layout.addWidget(self.pgsl_auto_parse, 2, 0, 1, 2)
        
        layout.addWidget(pgsl_group)
        
        # Compiler Settings group
        compiler_group = QGroupBox("Compiler & Build Settings")
        compiler_layout = QGridLayout(compiler_group)
        
        # Default window size (for new projects)
        compiler_layout.addWidget(QLabel("Default Window Width:"), 0, 0)
        self.default_window_width = QSpinBox()
        self.default_window_width.setRange(320, 7680)
        self.default_window_width.setValue(800)
        compiler_layout.addWidget(self.default_window_width, 0, 1)
        
        compiler_layout.addWidget(QLabel("Default Window Height:"), 1, 0)
        self.default_window_height = QSpinBox()
        self.default_window_height.setRange(240, 4320)
        self.default_window_height.setValue(600)
        compiler_layout.addWidget(self.default_window_height, 1, 1)
        
        # Default FPS
        compiler_layout.addWidget(QLabel("Default Game Speed (FPS):"), 2, 0)
        self.default_game_fps = QSpinBox()
        self.default_game_fps.setRange(1, 240)
        self.default_game_fps.setValue(60)
        compiler_layout.addWidget(self.default_game_fps, 2, 1)
        
        # Build output directory
        compiler_layout.addWidget(QLabel("Build Output Directory:"), 3, 0)
        self.build_output_dir = QLineEdit()
        self.browse_build_btn = QPushButton("Browse...")
        self.browse_build_btn.clicked.connect(self.browse_build_output)
        compiler_layout.addWidget(self.build_output_dir, 3, 1)
        compiler_layout.addWidget(self.browse_build_btn, 3, 2)
        
        # Validate scripts before run/debug/build
        self.validate_before_run = QCheckBox("Validate Scripts Before Run/Debug/Build")
        self.validate_before_run.setToolTip("Check all scripts for errors before running, debugging, or building the game")
        compiler_layout.addWidget(self.validate_before_run, 4, 0, 1, 3)
        
        layout.addWidget(compiler_group)
        layout.addStretch()
        
        # This method is deprecated - use create_code_tab() instead
        # Keeping for reference but not called
        pass
    
    def browse_build_output(self):
        """Open folder picker to set build output directory (safe stub)."""
        from PySide6.QtWidgets import QFileDialog
        from pathlib import Path
        try:
            start_dir = Path(self.build_output_dir.text() or Path.cwd())
        except Exception:
            start_dir = Path.cwd()
        directory = QFileDialog.getExistingDirectory(self, "Select Build Output Directory", str(start_dir))
        if directory:
            self.build_output_dir.setText(directory)
    
    def create_ai_tab(self):
        """Create AI tab with Appearance and API Keys sub-tabs"""
        tab = QWidget()
        layout = QVBoxLayout(tab)
        
        # Create sub-tab widget for AI settings
        self.ai_tab_widget = QTabWidget()
        layout.addWidget(self.ai_tab_widget)
        
        # Note: Nova Appearance is now in the main Appearance tab
        # No need for duplicate appearance tab here
        
        # Create API Keys tab
        self.create_ai_api_keys_tab()
        
        # Create Edits tab
        self.create_ai_edits_tab()
        
        # Wrap in scroll area and add tab
        scroll_tab = self._make_scrollable(tab)
        self.tab_widget.addTab(scroll_tab, "AI")
    
    def create_ai_appearance_tab(self):
        """Create Appearance tab for AI settings (from Nova)"""
        import sys
        import os
        from pathlib import Path
        
        # Add Nova directory to path for imports
        nova_dir = Path(__file__).parent.parent.parent / "AI" / "PyGenesisAssistant" / "Nova"
        nova_dir_str = str(nova_dir.resolve())  # Use absolute path
        if nova_dir_str not in sys.path:
            sys.path.insert(0, nova_dir_str)
        
        # Also add parent directory for relative imports
        nova_parent = nova_dir.parent
        nova_parent_str = str(nova_parent.resolve())
        if nova_parent_str not in sys.path:
            sys.path.insert(0, nova_parent_str)
        
        try:
            # Change to nova directory temporarily for imports
            old_cwd = os.getcwd()
            try:
                os.chdir(nova_dir_str)
                from ui.settings_dialog import AppearanceTab
                appearance_tab = AppearanceTab(self)
                self.ai_tab_widget.addTab(appearance_tab, "Nova")
            finally:
                os.chdir(old_cwd)
        except ImportError as e:
            import traceback
            error_msg = f"Could not load Nova appearance settings: {e}\n\n{traceback.format_exc()}"
            # Fallback if Nova imports fail
            fallback_tab = QWidget()
            layout = QVBoxLayout(fallback_tab)
            info = QLabel(f"Could not load Nova appearance settings:\n{str(e)}\n\nPlease check that Nova is properly installed.")
            info.setWordWrap(True)
            layout.addWidget(info)
            self.ai_tab_widget.addTab(fallback_tab, "Nova")
            print(f"Nova import error: {error_msg}")
    
    def create_ai_api_keys_tab(self):
        """Create API Keys tab for AI settings"""
        tab = QWidget()
        layout = QVBoxLayout(tab)
        layout.setSpacing(12)
        
        # API Keys group
        api_group = QGroupBox("API Keys")
        api_layout = QGridLayout(api_group)
        
        # OpenAI API Key
        api_layout.addWidget(QLabel("OpenAI API Key:"), 0, 0)
        self.openai_api_key = QLineEdit()
        self.openai_api_key.setPlaceholderText("sk-...")
        self.openai_api_key.setEchoMode(QLineEdit.Password)
        api_layout.addWidget(self.openai_api_key, 0, 1)
        
        show_openai_btn = QPushButton("Show")
        show_openai_btn.setCheckable(True)
        show_openai_btn.toggled.connect(lambda checked: self.openai_api_key.setEchoMode(QLineEdit.Normal if checked else QLineEdit.Password))
        api_layout.addWidget(show_openai_btn, 0, 2)
        
        test_openai_btn = QPushButton("Test")
        test_openai_btn.clicked.connect(lambda: self.test_api_key("OpenAI", self.openai_api_key.text()))
        api_layout.addWidget(test_openai_btn, 0, 3)
        
        # Gemini API Key
        api_layout.addWidget(QLabel("Google Gemini API Key:"), 1, 0)
        self.gemini_api_key = QLineEdit()
        self.gemini_api_key.setPlaceholderText("AIza...")
        self.gemini_api_key.setEchoMode(QLineEdit.Password)
        api_layout.addWidget(self.gemini_api_key, 1, 1)
        
        show_gemini_btn = QPushButton("Show")
        show_gemini_btn.setCheckable(True)
        show_gemini_btn.toggled.connect(lambda checked: self.gemini_api_key.setEchoMode(QLineEdit.Normal if checked else QLineEdit.Password))
        api_layout.addWidget(show_gemini_btn, 1, 2)
        
        test_gemini_btn = QPushButton("Test")
        test_gemini_btn.clicked.connect(lambda: self.test_api_key("Gemini", self.gemini_api_key.text()))
        api_layout.addWidget(test_gemini_btn, 1, 3)
        
        # Anthropic API Key
        api_layout.addWidget(QLabel("Anthropic API Key:"), 2, 0)
        self.anthropic_api_key = QLineEdit()
        self.anthropic_api_key.setPlaceholderText("sk-ant-...")
        self.anthropic_api_key.setEchoMode(QLineEdit.Password)
        api_layout.addWidget(self.anthropic_api_key, 2, 1)
        
        show_anthropic_btn = QPushButton("Show")
        show_anthropic_btn.setCheckable(True)
        show_anthropic_btn.toggled.connect(lambda checked: self.anthropic_api_key.setEchoMode(QLineEdit.Normal if checked else QLineEdit.Password))
        api_layout.addWidget(show_anthropic_btn, 2, 2)
        
        test_anthropic_btn = QPushButton("Test")
        test_anthropic_btn.clicked.connect(lambda: self.test_api_key("Anthropic", self.anthropic_api_key.text()))
        api_layout.addWidget(test_anthropic_btn, 2, 3)
        
        layout.addWidget(api_group)
        
        # Load saved API keys
        self.load_api_keys()
        
        layout.addStretch()
        
        self.ai_tab_widget.addTab(tab, "API Keys")
    
    def load_api_keys(self):
        """Load API keys from settings"""
        if hasattr(self, 'openai_api_key'):
            self.openai_api_key.setText(self.settings.get("AI_OpenAI_API_Key", ""))
        if hasattr(self, 'gemini_api_key'):
            self.gemini_api_key.setText(self.settings.get("AI_Gemini_API_Key", ""))
        if hasattr(self, 'anthropic_api_key'):
            self.anthropic_api_key.setText(self.settings.get("AI_Anthropic_API_Key", ""))
    
    def save_api_keys(self):
        """Save API keys to settings"""
        if hasattr(self, 'openai_api_key'):
            self.settings.set("AI_OpenAI_API_Key", self.openai_api_key.text())
        if hasattr(self, 'gemini_api_key'):
            self.settings.set("AI_Gemini_API_Key", self.gemini_api_key.text())
        if hasattr(self, 'anthropic_api_key'):
            self.settings.set("AI_Anthropic_API_Key", self.anthropic_api_key.text())
    
    def create_ai_edits_tab(self):
        """Create Edits tab for AI operation preferences"""
        tab = QWidget()
        layout = QVBoxLayout(tab)
        layout.setSpacing(12)
        
        # Edits group
        edits_group = QGroupBox("Edit Operations")
        edits_layout = QVBoxLayout(edits_group)
        
        # Allow High Risk checkbox
        self.allow_high_risk = QCheckBox("Allow High Risk Operations Without Confirmation")
        self.allow_high_risk.setToolTip(
            "When enabled, Nova can execute high-risk operations (like file deletion, "
            "project modifications) without requiring user confirmation.\n\n"
            "⚠️ Warning: Disabling confirmation can lead to accidental data loss. "
            "Only enable if you trust Nova's operation planning."
        )
        edits_layout.addWidget(self.allow_high_risk)
        
        info_label = QLabel(
            "High-risk operations include:\n"
            "• File deletion\n"
            "• Project structure modifications\n"
            "• Resource deletion\n"
            "• Multi-file operations"
        )
        info_label.setWordWrap(True)
        info_label.setStyleSheet("color: #888; font-size: 9pt; padding-left: 20px;")
        edits_layout.addWidget(info_label)
        
        layout.addWidget(edits_group)
        
        # Auto Followup group
        followup_group = QGroupBox("Uncertain Results")
        followup_layout = QVBoxLayout(followup_group)
        
        # Allow Auto Followup checkbox
        self.allow_auto_followup = QCheckBox("Allow Auto Followup for Uncertain Results")
        self.allow_auto_followup.setToolTip(
            "When enabled, Nova will proceed with uncertain results (like ambiguous search queries, "
            "disambiguation pages, or low-confidence matches) and provide information with a disclaimer.\n\n"
            "⚠️ Note: This may affect Nova's accuracy. When disabled, Nova will ask for clarification "
            "or return links instead of potentially incorrect information.\n\n"
            "Applies to:\n"
            "• Research queries (e.g., 'What is Godot?')\n"
            "• Code searches with multiple matches\n"
            "• File editing with uncertain context"
        )
        followup_layout.addWidget(self.allow_auto_followup)
        
        followup_info_label = QLabel(
            "When enabled, Nova will:\n"
            "• Return information from disambiguation pages with a disclaimer\n"
            "• Proceed with best-guess matches in code searches\n"
            "• Apply edits even when context is uncertain (with warnings)"
        )
        followup_info_label.setWordWrap(True)
        followup_info_label.setStyleSheet("color: #888; font-size: 9pt; padding-left: 20px;")
        followup_layout.addWidget(followup_info_label)
        
        layout.addWidget(followup_group)
        
        # Nova Settings group
        nova_group = QGroupBox("Nova Assistant Settings")
        nova_layout = QVBoxLayout(nova_group)
        
        # Show Thinking checkbox
        self.show_nova_thinking = QCheckBox("Show Nova's Thinking Status")
        self.show_nova_thinking.setToolTip(
            "When enabled, Nova displays her current intent and confidence level in the header.\n\n"
            "Example: 'Thinking About Math Query (95% Confidence)'\n\n"
            "This helps you understand what Nova is processing and how confident she is."
        )
        nova_layout.addWidget(self.show_nova_thinking)
        
        # Train Nova On Chats checkbox
        self.train_nova_on_chats = QCheckBox("Train Nova On Conversations")
        self.train_nova_on_chats.setToolTip(
            "When enabled, Nova will use your conversation history to improve her intent classification.\n\n"
            "Your conversations are stored and can be used for training Nova's neural network.\n\n"
            "⚠️ Note: Conversations are stored locally and only used for training if this option is enabled.\n"
            "You can review and manage conversations in Nova's conversation list."
        )
        nova_layout.addWidget(self.train_nova_on_chats)
        
        nova_info_label = QLabel(
            "Nova Settings:\n"
            "• Thinking Status: Shows intent and confidence in header\n"
            "• Training: Uses conversation history to improve accuracy"
        )
        nova_info_label.setWordWrap(True)
        nova_info_label.setStyleSheet("color: #888; font-size: 9pt; padding-left: 20px;")
        nova_layout.addWidget(nova_info_label)
        
        layout.addWidget(nova_group)
        layout.addStretch()
        
        self.ai_tab_widget.addTab(tab, "Edits")
    
    def test_api_key(self, provider, api_key):
        """Test an API key"""
        if not api_key:
            QMessageBox.warning(self, "Test Failed", f"No {provider} API key provided.")
            return
        
        # TODO: Implement actual API key testing
        QMessageBox.information(self, "Test", f"{provider} API key test not yet implemented.")
    
    def create_editor_specific_tab(self):
        """Create Editor Specific settings tab with sub-tabs for each editor type"""
        tab = QWidget()
        layout = QVBoxLayout(tab)
        
        # Create sub-tab widget for different editor types
        self.editor_tab_widget = QTabWidget()
        layout.addWidget(self.editor_tab_widget)
        
        # Create Code tab first (combines Script and PGSL settings)
        self.create_code_tab()
        
        # Create individual editor preference tabs
        self.create_image_editor_tab()
        self.create_audio_editor_tab()
        self.create_background_editor_tab()
        self.create_object_editor_tab()
        self.create_model_editor_tab()
        self.create_room_editor_tab()
        
        # Wrap in scroll area for smaller screens
        scroll_tab = self._make_scrollable(tab)
        self.tab_widget.addTab(scroll_tab, "Editor Specific")
    
    def create_image_editor_tab(self):
        """Create Image Editor specific settings"""
        tab = QWidget()
        layout = QVBoxLayout(tab)
        
        # Sprite settings group
        sprite_group = QGroupBox("Sprite Settings")
        sprite_layout = QGridLayout(sprite_group)
        
        # Default sprite dimensions
        sprite_layout.addWidget(QLabel("Default New Sprite Width:"), 0, 0)
        self.default_sprite_width = QSpinBox()
        self.default_sprite_width.setRange(8, 2048)
        self.default_sprite_width.setValue(32)
        sprite_layout.addWidget(self.default_sprite_width, 0, 1)
        
        sprite_layout.addWidget(QLabel("Default New Sprite Height:"), 1, 0)
        self.default_sprite_height = QSpinBox()
        self.default_sprite_height.setRange(8, 2048)
        self.default_sprite_height.setValue(32)
        sprite_layout.addWidget(self.default_sprite_height, 1, 1)
        
        # Default FPS for sprite animation
        sprite_layout.addWidget(QLabel("Default FPS:"), 2, 0)
        self.default_sprite_fps = QSpinBox()
        self.default_sprite_fps.setRange(1, 120)
        self.default_sprite_fps.setValue(30)
        sprite_layout.addWidget(self.default_sprite_fps, 2, 1)
        
        # Grid settings
        self.sprite_grid_visible = QCheckBox("Show Grid by Default")
        sprite_layout.addWidget(self.sprite_grid_visible, 3, 0)
        
        self.sprite_global_grid = QCheckBox("Use Global Grid by Default")
        sprite_layout.addWidget(self.sprite_global_grid, 4, 0)
        
        # Origin settings
        self.sprite_origin_visible = QCheckBox("Show Origin by Default")
        sprite_layout.addWidget(self.sprite_origin_visible, 5, 0)
        
        layout.addWidget(sprite_group)
        
        # Image Editor settings group
        image_group = QGroupBox("Image Editor Settings")
        image_layout = QGridLayout(image_group)
        
        # Default canvas settings
        image_layout.addWidget(QLabel("Default Canvas Width:"), 0, 0)
        self.default_canvas_width = QSpinBox()
        self.default_canvas_width.setRange(32, 4096)
        self.default_canvas_width.setValue(512)
        image_layout.addWidget(self.default_canvas_width, 0, 1)
        
        image_layout.addWidget(QLabel("Default Canvas Height:"), 1, 0)
        self.default_canvas_height = QSpinBox()
        self.default_canvas_height.setRange(32, 4096)
        self.default_canvas_height.setValue(512)
        image_layout.addWidget(self.default_canvas_height, 1, 1)
        
        # Default grid size
        image_layout.addWidget(QLabel("Default Grid Size:"), 2, 0)
        self.default_image_grid_size = QSpinBox()
        self.default_image_grid_size.setRange(1, 64)
        self.default_image_grid_size.setValue(32)
        image_layout.addWidget(self.default_image_grid_size, 2, 1)
        
        # Image editor behavior
        self.image_grid_visible = QCheckBox("Show Grid by Default")
        image_layout.addWidget(self.image_grid_visible, 3, 0)
        
        self.image_global_grid = QCheckBox("Use Global Grid by Default")
        image_layout.addWidget(self.image_global_grid, 4, 0)
        
        # Hardware rendering
        self.image_use_gpu_canvas = QCheckBox("Use Hardware Rendering")
        self.image_use_gpu_canvas.setToolTip(
            "Use GPU-accelerated rendering for better performance.\n"
            "If disabled, uses software rendering (QPainter-based canvas).\n"
            "Note: Changes take effect after restarting the Image Editor."
        )
        image_layout.addWidget(self.image_use_gpu_canvas, 5, 0)
        
        layout.addWidget(image_group)
        layout.addStretch()
        
        self.editor_tab_widget.addTab(tab, "Image")
    
    def create_audio_editor_tab(self):
        """Create Audio Editor specific settings"""
        tab = QWidget()
        layout = QVBoxLayout(tab)
        
        # Audio settings group
        audio_group = QGroupBox("Audio Settings")
        audio_layout = QGridLayout(audio_group)
        
        # Sample rate
        audio_layout.addWidget(QLabel("Default Sample Rate:"), 0, 0)
        self.default_sample_rate = QComboBox()
        self.default_sample_rate.addItems(["22050 Hz", "44100 Hz", "48000 Hz", "96000 Hz"])
        audio_layout.addWidget(self.default_sample_rate, 0, 1)
        
        # Bit depth
        audio_layout.addWidget(QLabel("Default Bit Depth:"), 1, 0)
        self.default_bit_depth = QComboBox()
        self.default_bit_depth.addItems(["8-bit", "16-bit", "24-bit", "32-bit"])
        audio_layout.addWidget(self.default_bit_depth, 1, 1)
        
        # Channels
        audio_layout.addWidget(QLabel("Default Channels:"), 2, 0)
        self.default_channels = QComboBox()
        self.default_channels.addItems(["Mono", "Stereo", "5.1 Surround", "7.1 Surround"])
        audio_layout.addWidget(self.default_channels, 2, 1)
        
        # Audio editor behavior
        self.audio_auto_play = QCheckBox("Auto-play on Load")
        audio_layout.addWidget(self.audio_auto_play, 3, 0)
        
        self.audio_loop_preview = QCheckBox("Loop Preview by Default")
        audio_layout.addWidget(self.audio_loop_preview, 4, 0)
        
        layout.addWidget(audio_group)
        layout.addStretch()
        
        self.editor_tab_widget.addTab(tab, "Audio")
    
    def create_background_editor_tab(self):
        """Create Background Editor specific settings"""
        tab = QWidget()
        layout = QVBoxLayout(tab)
        
        # Background settings group
        bg_group = QGroupBox("Background Settings")
        bg_layout = QGridLayout(bg_group)
        
        # Default background dimensions
        bg_layout.addWidget(QLabel("Default Background Width:"), 0, 0)
        self.default_bg_width = QSpinBox()
        self.default_bg_width.setRange(32, 4096)
        self.default_bg_width.setValue(1024)
        bg_layout.addWidget(self.default_bg_width, 0, 1)
        
        bg_layout.addWidget(QLabel("Default Background Height:"), 1, 0)
        self.default_bg_height = QSpinBox()
        self.default_bg_height.setRange(32, 4096)
        self.default_bg_height.setValue(768)
        bg_layout.addWidget(self.default_bg_height, 1, 1)
        
        # Background editor behavior
        self.bg_grid_visible = QCheckBox("Show Grid by Default")
        bg_layout.addWidget(self.bg_grid_visible, 2, 0)
        
        self.bg_tile_mode = QCheckBox("Enable Tile Mode by Default")
        bg_layout.addWidget(self.bg_tile_mode, 3, 0)
        
        layout.addWidget(bg_group)
        layout.addStretch()
        
        self.editor_tab_widget.addTab(tab, "Background")
    
    def create_object_editor_tab(self):
        """Create Object Editor specific settings"""
        tab = QWidget()
        layout = QVBoxLayout(tab)
        
        # Object settings group
        obj_group = QGroupBox("Object Settings")
        obj_layout = QGridLayout(obj_group)
        
        # Default object properties
        obj_layout.addWidget(QLabel("Default Object Width:"), 0, 0)
        self.default_obj_width = QSpinBox()
        self.default_obj_width.setRange(8, 512)
        self.default_obj_width.setValue(32)
        obj_layout.addWidget(self.default_obj_width, 0, 1)
        
        obj_layout.addWidget(QLabel("Default Object Height:"), 1, 0)
        self.default_obj_height = QSpinBox()
        self.default_obj_height.setRange(8, 512)
        self.default_obj_height.setValue(32)
        obj_layout.addWidget(self.default_obj_height, 1, 1)
        
        # Object editor behavior
        self.obj_show_events = QCheckBox("Show Events Panel by Default")
        obj_layout.addWidget(self.obj_show_events, 2, 0)
        
        self.obj_show_properties = QCheckBox("Show Properties Panel by Default")
        obj_layout.addWidget(self.obj_show_properties, 3, 0)
        
        layout.addWidget(obj_group)
        layout.addStretch()
        
        self.editor_tab_widget.addTab(tab, "Object")
    
    def create_model_editor_tab(self):
        """Create Model Editor specific settings"""
        tab = QWidget()
        layout = QVBoxLayout(tab)
        
        # Model settings group
        model_group = QGroupBox("Model Settings")
        model_layout = QGridLayout(model_group)
        
        # Default model properties
        model_layout.addWidget(QLabel("Default Model Scale:"), 0, 0)
        self.default_model_scale = QSpinBox()
        self.default_model_scale.setRange(1, 100)
        self.default_model_scale.setValue(10)
        model_layout.addWidget(self.default_model_scale, 0, 1)
        
        # Model editor behavior
        self.model_show_wireframe = QCheckBox("Show Wireframe by Default")
        model_layout.addWidget(self.model_show_wireframe, 1, 0)
        
        self.model_show_textures = QCheckBox("Show Textures by Default")
        model_layout.addWidget(self.model_show_textures, 2, 0)
        
        self.model_auto_rotate = QCheckBox("Auto-rotate Preview by Default")
        model_layout.addWidget(self.model_auto_rotate, 3, 0)
        
        # Lighting style
        model_layout.addWidget(QLabel("Default Lighting Style:"), 4, 0)
        self.model_lighting_style = QComboBox()
        self.model_lighting_style.addItems(["Default", "Toon Ramp", "Low Poly", "Wireframe", "Unlit"])
        model_layout.addWidget(self.model_lighting_style, 4, 1)
        
        # External light settings
        self.model_external_light_enabled = QCheckBox("Enable External Light by Default")
        model_layout.addWidget(self.model_external_light_enabled, 5, 0)
        
        model_layout.addWidget(QLabel("External Light Brightness:"), 6, 0)
        self.model_external_light_brightness = QSpinBox()
        self.model_external_light_brightness.setRange(1, 100)
        self.model_external_light_brightness.setValue(50)  # 5.0 scaled to 1-100 for UI
        self.model_external_light_brightness.setSuffix("%")
        model_layout.addWidget(self.model_external_light_brightness, 6, 1)
        
        # Light position
        model_layout.addWidget(QLabel("Light Position:"), 7, 0)
        self.model_light_position = QComboBox()
        self.model_light_position.addItems(["top", "bottom", "left", "right", "middle"])
        model_layout.addWidget(self.model_light_position, 7, 1)
        
        layout.addWidget(model_group)
        
        # Selection Colors Group
        selection_group = QGroupBox("Selection Colors")
        selection_layout = QGridLayout(selection_group)
        
        # Face selection color
        selection_layout.addWidget(QLabel("Selected Face Color:"), 0, 0)
        self.model_selection_face_color_btn = QPushButton()
        self.model_selection_face_color_btn.clicked.connect(lambda: self.choose_model_selection_color("face"))
        selection_layout.addWidget(self.model_selection_face_color_btn, 0, 1)
        
        # Edge selection color
        selection_layout.addWidget(QLabel("Selected Edge Color:"), 1, 0)
        self.model_selection_edge_color_btn = QPushButton()
        self.model_selection_edge_color_btn.clicked.connect(lambda: self.choose_model_selection_color("edge"))
        selection_layout.addWidget(self.model_selection_edge_color_btn, 1, 1)
        
        layout.addWidget(selection_group)
        
        # View Settings Group
        view_group = QGroupBox("View Settings")
        view_layout = QGridLayout(view_group)
        
        # Background/Floor color (single option for both background and floor)
        view_layout.addWidget(QLabel("Background/Floor Color:"), 0, 0)
        self.model_background_color_btn = QPushButton()
        self.model_background_color_btn.clicked.connect(lambda: self.choose_model_color("background"))
        view_layout.addWidget(self.model_background_color_btn, 0, 1)
        
        # Background/Floor texture (single option)
        view_layout.addWidget(QLabel("Background/Floor Texture:"), 1, 0)
        background_texture_layout = QHBoxLayout()
        self.model_background_texture_edit = QLineEdit()
        self.model_background_texture_edit.setPlaceholderText("None (use color)")
        self.model_background_texture_browse_btn = QPushButton("Browse...")
        self.model_background_texture_browse_btn.clicked.connect(lambda: self.choose_model_texture("background"))
        background_texture_layout.addWidget(self.model_background_texture_edit)
        background_texture_layout.addWidget(self.model_background_texture_browse_btn)
        view_layout.addLayout(background_texture_layout, 1, 1)
        
        # Background/Floor texture mapping options
        view_layout.addWidget(QLabel("Floor Texture Mode:"), 2, 0)
        self.model_background_texture_mode = QComboBox()
        self.model_background_texture_mode.addItems(["Stretch", "Repeat (1x1)", "Repeat (2x2)", "Repeat (4x4)", "Repeat (8x8)", "Repeat (Custom)"])
        view_layout.addWidget(self.model_background_texture_mode, 2, 1)
        
        # Custom repeat scale (only shown if "Repeat (Custom)" is selected)
        view_layout.addWidget(QLabel("Custom Repeat Scale:"), 3, 0)
        custom_repeat_layout = QHBoxLayout()
        self.model_background_custom_scale_x = QDoubleSpinBox()
        self.model_background_custom_scale_x.setRange(0.1, 100.0)
        self.model_background_custom_scale_x.setValue(1.0)
        self.model_background_custom_scale_x.setSingleStep(0.1)
        self.model_background_custom_scale_x.setDecimals(1)
        self.model_background_custom_scale_x.setSuffix("x")
        self.model_background_custom_scale_y = QDoubleSpinBox()
        self.model_background_custom_scale_y.setRange(0.1, 100.0)
        self.model_background_custom_scale_y.setValue(1.0)
        self.model_background_custom_scale_y.setSingleStep(0.1)
        self.model_background_custom_scale_y.setDecimals(1)
        self.model_background_custom_scale_y.setSuffix("x")
        custom_repeat_layout.addWidget(QLabel("X:"))
        custom_repeat_layout.addWidget(self.model_background_custom_scale_x)
        custom_repeat_layout.addWidget(QLabel("Y:"))
        custom_repeat_layout.addWidget(self.model_background_custom_scale_y)
        view_layout.addLayout(custom_repeat_layout, 3, 1)
        
        # Show grid
        self.model_show_grid = QCheckBox("Show Grid by Default")
        view_layout.addWidget(self.model_show_grid, 4, 0)
        
        # Show background
        self.model_show_background = QCheckBox("Show Background by Default")
        view_layout.addWidget(self.model_show_background, 5, 0)
        
        # Show skyline
        self.model_show_skyline = QCheckBox("Show Skyline by Default")
        view_layout.addWidget(self.model_show_skyline, 9, 0)
        
        # Skyline color
        view_layout.addWidget(QLabel("Skyline Color:"), 10, 0)
        self.model_skyline_color_btn = QPushButton()
        self.model_skyline_color_btn.clicked.connect(lambda: self.choose_model_color("skyline"))
        view_layout.addWidget(self.model_skyline_color_btn, 10, 1)
        
        # Skyline texture
        view_layout.addWidget(QLabel("Skyline Texture:"), 11, 0)
        skyline_texture_layout = QHBoxLayout()
        self.model_skyline_texture_edit = QLineEdit()
        self.model_skyline_texture_edit.setPlaceholderText("None (use color)")
        self.model_skyline_texture_browse_btn = QPushButton("Browse...")
        self.model_skyline_texture_browse_btn.clicked.connect(lambda: self.choose_model_texture("skyline"))
        skyline_texture_layout.addWidget(self.model_skyline_texture_edit)
        skyline_texture_layout.addWidget(self.model_skyline_texture_browse_btn)
        view_layout.addLayout(skyline_texture_layout, 11, 1)
        
        # Skyline texture mapping options
        view_layout.addWidget(QLabel("Skyline Texture Mode:"), 12, 0)
        self.model_skyline_texture_mode = QComboBox()
        self.model_skyline_texture_mode.addItems(["Stretch", "Repeat (1x1)", "Repeat (2x2)", "Repeat (4x4)", "Repeat (8x8)", "Repeat (Custom)"])
        view_layout.addWidget(self.model_skyline_texture_mode, 12, 1)
        
        # Custom repeat scale for skyline (only shown if "Repeat (Custom)" is selected)
        view_layout.addWidget(QLabel("Skyline Custom Scale:"), 13, 0)
        skyline_custom_repeat_layout = QHBoxLayout()
        self.model_skyline_custom_scale_x = QDoubleSpinBox()
        self.model_skyline_custom_scale_x.setRange(0.1, 100.0)
        self.model_skyline_custom_scale_x.setValue(1.0)
        self.model_skyline_custom_scale_x.setSingleStep(0.1)
        self.model_skyline_custom_scale_x.setDecimals(1)
        self.model_skyline_custom_scale_x.setSuffix("x")
        self.model_skyline_custom_scale_y = QDoubleSpinBox()
        self.model_skyline_custom_scale_y.setRange(0.1, 100.0)
        self.model_skyline_custom_scale_y.setValue(1.0)
        self.model_skyline_custom_scale_y.setSingleStep(0.1)
        self.model_skyline_custom_scale_y.setDecimals(1)
        self.model_skyline_custom_scale_y.setSuffix("x")
        skyline_custom_repeat_layout.addWidget(QLabel("X:"))
        skyline_custom_repeat_layout.addWidget(self.model_skyline_custom_scale_x)
        skyline_custom_repeat_layout.addWidget(QLabel("Y:"))
        skyline_custom_repeat_layout.addWidget(self.model_skyline_custom_scale_y)
        view_layout.addLayout(skyline_custom_repeat_layout, 13, 1)
        
        layout.addWidget(view_group)
        
        # Smooth Settings Group
        smooth_group = QGroupBox("Smooth Settings")
        smooth_layout = QGridLayout(smooth_group)
        
        # Smooth movement enabled by default
        self.model_smooth_movement_enabled = QCheckBox("Smooth Movement Enabled by Default")
        smooth_layout.addWidget(self.model_smooth_movement_enabled, 0, 0)
        
        # Smooth camera enabled by default
        self.model_smooth_camera_enabled = QCheckBox("Smooth Camera Enabled by Default")
        smooth_layout.addWidget(self.model_smooth_camera_enabled, 1, 0)
        
        # Smooth factor
        smooth_layout.addWidget(QLabel("Smooth Factor:"), 2, 0)
        self.model_smooth_factor = QDoubleSpinBox()
        self.model_smooth_factor.setRange(0.01, 1.0)
        self.model_smooth_factor.setValue(0.15)
        self.model_smooth_factor.setSingleStep(0.01)
        self.model_smooth_factor.setDecimals(2)
        smooth_layout.addWidget(self.model_smooth_factor, 2, 1)
        
        layout.addWidget(smooth_group)
        
        layout.addStretch()
        
        self.editor_tab_widget.addTab(tab, "Model")
    
    def choose_model_selection_color(self, color_type):
        """Choose a selection color for model editor"""
        key = f"Model_Selection_{color_type.title()}_Color"
        current_color_str = self.settings.get(key, "#00ffff")
        current_color = QColor(current_color_str)
        color = QColorDialog.getColor(current_color, self, f"Choose {color_type.title()} Selection Color")
        if color.isValid():
            color_name = color.name()
            self.settings.set(key, color_name)
            # Update button appearance
            btn = getattr(self, f"model_selection_{color_type}_color_btn")
            btn.setStyleSheet(f"background-color: {color_name}; border: 1px solid #555555; min-width: 50px; min-height: 25px;")
    
    def choose_model_color(self, color_type):
        """Choose a color for model editor (background, etc)"""
        key = f"Model_{color_type.title()}_Color"
        current_color_str = self.settings.get(key, "#1a1a1a")
        current_color = QColor(current_color_str)
        color = QColorDialog.getColor(current_color, self, f"Choose {color_type.title()} Color")
        if color.isValid():
            color_name = color.name()
            self.settings.set(key, color_name)
            # Update button appearance
            btn = getattr(self, f"model_{color_type}_color_btn")
            btn.setStyleSheet(f"background-color: {color_name}; border: 1px solid #555555; min-width: 50px; min-height: 25px;")
    
    def choose_model_texture(self, texture_type):
        """Choose a texture for model editor from project Textures folder"""
        if not self.app or not hasattr(self.app, 'project_manager'):
            QMessageBox.warning(self, "Error", "Project manager not available.")
            return
        
        # Get list of texture resources from project
        try:
            texture_resources = self.app.project_manager.get_resources("textures")
        except:
            texture_resources = []
        
        if not texture_resources:
            QMessageBox.information(self, "No Textures", "No texture resources found in the project.\nPlease create textures in the Textures folder first.")
            return
        
        # Create a simple dialog to select texture
        from PySide6.QtWidgets import QDialog, QVBoxLayout, QListWidget, QPushButton, QDialogButtonBox
        
        dialog = QDialog(self)
        dialog.setWindowTitle(f"Select {texture_type.title()} Texture")
        dialog.setMinimumWidth(400)
        dialog.setMinimumHeight(300)
        
        layout = QVBoxLayout(dialog)
        
        # List of textures
        texture_list = QListWidget()
        texture_list.addItem("None (use color)")  # Option to clear texture
        for texture_resource in texture_resources:
            texture_name = texture_resource.get("name", "Unknown")
            texture_list.addItem(texture_name)
        texture_list.setCurrentRow(0)
        
        layout.addWidget(QLabel(f"Select texture from project Textures:"))
        layout.addWidget(texture_list)
        
        # Buttons
        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.accepted.connect(dialog.accept)
        buttons.rejected.connect(dialog.reject)
        layout.addWidget(buttons)
        
        if dialog.exec() == QDialog.Accepted:
            selected_item = texture_list.currentItem()
            if selected_item:
                selected_name = selected_item.text()
                
                if selected_name == "None (use color)":
                    # Clear texture selection
                    texture_resource_id = None
                    key = f"Model_{texture_type.title()}_Texture"
                    self.settings.set(key, "")
                else:
                    # Find the texture resource ID
                    texture_resource_id = None
                    for texture_resource in texture_resources:
                        if texture_resource.get("name") == selected_name:
                            texture_resource_id = texture_resource.get("id")
                            break
                    
                    if texture_resource_id:
                        key = f"Model_{texture_type.title()}_Texture"
                        # Store the texture resource ID or name
                        self.settings.set(key, texture_resource_id)
                    else:
                        QMessageBox.warning(self, "Error", f"Could not find texture resource '{selected_name}'.")
                        return
                
                # Update text field with texture name
                edit = getattr(self, f"model_{texture_type}_texture_edit")
                edit.setText(selected_name if selected_name != "None (use color)" else "")
    
    def create_room_editor_tab(self):
        """Create Room Editor specific settings"""
        tab = QWidget()
        layout = QVBoxLayout(tab)
        
        # Room settings group
        room_group = QGroupBox("Room Settings")
        room_layout = QGridLayout(room_group)
        
        # Default room dimensions
        room_layout.addWidget(QLabel("Default Room Width:"), 0, 0)
        self.default_room_width = QSpinBox()
        self.default_room_width.setRange(320, 4096)
        self.default_room_width.setValue(1024)
        room_layout.addWidget(self.default_room_width, 0, 1)
        
        room_layout.addWidget(QLabel("Default Room Height:"), 1, 0)
        self.default_room_height = QSpinBox()
        self.default_room_height.setRange(240, 4096)
        self.default_room_height.setValue(768)
        room_layout.addWidget(self.default_room_height, 1, 1)
        
        # Room editor behavior
        self.room_grid_visible = QCheckBox("Show Grid by Default")
        room_layout.addWidget(self.room_grid_visible, 2, 0)
        
        self.room_snap_to_grid = QCheckBox("Snap to Grid by Default")
        room_layout.addWidget(self.room_snap_to_grid, 3, 0)
        
        self.room_show_layers = QCheckBox("Show Layers Panel by Default")
        room_layout.addWidget(self.room_show_layers, 4, 0)
        
        layout.addWidget(room_group)
        layout.addStretch()
        
        self.editor_tab_widget.addTab(tab, "Room")
    
    def browse_project_path(self):
        """Browse for default project path"""
        path = QFileDialog.getExistingDirectory(self, "Select Default Project Location")
        if path:
            self.default_project_path.setText(path)
    
    def browse_venv_path(self):
        """Browse for virtual environment path"""
        path = QFileDialog.getExistingDirectory(self, "Select Virtual Environment Location")
        if path:
            self.venv_path.setText(path)
    
    def browse_editor_backup_path(self):
        """Browse for editor backup path"""
        path = QFileDialog.getExistingDirectory(self, "Select Editor Backup Location")
        if path:
            self.editor_backup_path.setText(path)
    
    def browse_project_backup_path(self):
        """Browse for project backup path"""
        path = QFileDialog.getExistingDirectory(self, "Select Project Backup Location")
        if path:
            self.project_backup_path.setText(path)
    
    def browse_editor_summary_path(self):
        """Browse for editor summary path"""
        path = QFileDialog.getExistingDirectory(self, "Select Editor Summary Location")
        if path:
            self.editor_summary_path.setText(path)
    
    def generate_project_summary(self):
        """Generate summary for the current project"""
        from pathlib import Path
        import sys
        import os
        
        # Check if project is loaded
        if not hasattr(self.app, 'project_manager') or not self.app.project_manager.get_project_path():
            QMessageBox.warning(self, "No Project", "Please open a project first.")
            return
        
        project_path = Path(self.app.project_manager.get_project_path())
        output_path = project_path / "CODEBASE_SUMMARY.md"
        
        # Import GenerateSummary
        try:
            # Add project root to path if needed
            project_root = Path(__file__).parent.parent
            if str(project_root) not in sys.path:
                sys.path.insert(0, str(project_root))
            
            from GenerateSummary import summarize_project
            
            # Generate summary
            summary = summarize_project(project_path)
            output_path.write_text(summary, encoding="utf-8")
            
            QMessageBox.information(
                self, 
                "Summary Generated", 
                f"Project summary generated successfully!\n\nSaved to: {output_path}"
            )
        except Exception as e:
            QMessageBox.critical(
                self, 
                "Error", 
                f"Failed to generate project summary:\n{str(e)}"
            )
    
    def generate_editor_summary(self):
        """Generate summary for the editor"""
        from pathlib import Path
        import sys
        import os
        
        # Get editor summary location (defaults to editor backup location)
        user_home = Path.home()
        default_backup = os.path.join(str(user_home), "PyGenesis", "Backups", "Editor")
        backup_path = Path(self.settings.get("Editor_Backup_Location", default_backup))
        summary_path = Path(self.editor_summary_path.text() or str(backup_path))
        
        if not summary_path.exists():
            summary_path.mkdir(parents=True, exist_ok=True)
        
        output_path = summary_path / "CODEBASE_SUMMARY.md"
        
        # Get editor directory
        editor_path = Path(__file__).parent.parent  # Go up from UI/ to project root
        
        # Import GenerateSummary
        try:
            # Add project root to path if needed
            if str(editor_path) not in sys.path:
                sys.path.insert(0, str(editor_path))
            
            from GenerateSummary import summarize_project
            
            # Generate summary
            summary = summarize_project(editor_path)
            output_path.write_text(summary, encoding="utf-8")
            
            QMessageBox.information(
                self, 
                "Summary Generated", 
                f"Editor summary generated successfully!\n\nSaved to: {output_path}"
            )
        except Exception as e:
            QMessageBox.critical(
                self, 
                "Error", 
                f"Failed to generate editor summary:\n{str(e)}"
            )
    
    def choose_accent_color(self):
        """Choose accent color"""
        current_color = QColor(self.settings.get("Accent_Color", "#0078d4"))
        color = QColorDialog.getColor(current_color, self, "Choose Accent Color")
        if color.isValid():
            self.accent_color_btn.setStyleSheet(f"background-color: {color.name()}; border: 1px solid #555555;")
            self.accent_color = color.name()
    
    def choose_color(self, color_type):
        """Choose a custom color for UI elements"""
        # Get current color from settings or theme
        current_color_name = self.settings.get(f"Custom_{color_type.title()}", "")
        if not current_color_name:
            # Get default color from current theme
            colors = self.theme_manager.get_colors()
            color_mapping = {
                "font_color": "foreground",
                "button_color": "button_bg", 
                "menu_color": "menu_bar",
                "background_color": "background",
                "border_color": "border",
                "input_color": "input_bg"
            }
            current_color_name = colors.get(color_mapping.get(color_type, "foreground"), "#cccccc")
        
        current_color = QColor(current_color_name)
        color = QColorDialog.getColor(current_color, self, f"Choose {color_type.replace('_', ' ').title()}")
        if color.isValid():
            color_name = color.name()
            self.settings.set(f"Custom_{color_type.title()}", color_name)
            # Update the button appearance
            button = getattr(self, f"{color_type}_btn")
            button.setStyleSheet(f"background-color: {color_name}; border: 1px solid #555555;")
            # Apply theme immediately
            self.apply_theme()
    
    def reset_colors(self):
        """Reset all custom colors to theme defaults"""
        color_types = ["font_color", "button_color", "menu_color", "background_color", "border_color", "input_color"]
        for color_type in color_types:
            # Remove custom color setting
            self.settings.settings.remove(f"Custom_{color_type.title()}")
            # Reset button appearance to theme default
            colors = self.theme_manager.get_colors()
            color_mapping = {
                "font_color": "foreground",
                "button_color": "button_bg", 
                "menu_color": "menu_bar",
                "background_color": "background",
                "border_color": "border",
                "input_color": "input_bg"
            }
            default_color = colors.get(color_mapping.get(color_type, "foreground"), "#cccccc")
            button = getattr(self, f"{color_type}_btn")
            button.setStyleSheet(f"background-color: {default_color}; border: 1px solid #555555;")
        # Apply theme
        self.apply_theme()
    
    def on_theme_changed(self, theme_name):
        """Handle theme change - provides live preview"""
        self.theme_manager.set_theme(theme_name)
        
        # Color mapping
        color_mapping = {
            "font_color": "foreground",
            "button_color": "button_bg", 
            "menu_color": "menu_bar",
            "background_color": "background",
            "border_color": "border",
            "input_color": "input_bg"
        }
        
        # Get the theme colors
        theme_colors = self.theme_manager.get_colors()
        
        # Check if it's a custom theme
        custom_themes = self.theme_manager.get_custom_themes()
        
        if theme_name in custom_themes:
            # For custom themes, load the saved colors from the theme
            # and temporarily set them in settings for preview
            for color_type, theme_key in color_mapping.items():
                color = theme_colors.get(theme_key)
                if color:
                    self.settings.set(f"Custom_{color_type.title()}", color)
        else:
            # For built-in themes, clear custom color settings
            for color_type in color_mapping.keys():
                setting_key = f"Custom_{color_type.title()}"
                if self.settings.settings.contains(setting_key):
                    self.settings.settings.remove(setting_key)
        
        # Update color buttons with theme colors
        for color_type, theme_key in color_mapping.items():
            color = theme_colors.get(theme_key, "#cccccc")
            button = getattr(self, f"{color_type}_btn", None)
            if button:
                button.setStyleSheet(f"background-color: {color}; border: 1px solid #555555;")
        
        # Apply theme globally for live preview
        self.apply_theme()
        
        # Emit signal to update main window
        self.preferences_changed.emit()
    
    def on_ui_font_size_changed(self, size):
        """Handle UI font size change for live preview"""
        # Save the setting immediately
        self.settings.set("UI_Font_Size", size)
        
        # Apply font size to this dialog for preview
        font = QFont()
        font.setPointSize(size)
        self.setFont(font)
        
        # Apply to all child widgets
        for widget in self.findChildren(QWidget):
            widget.setFont(font)
        
        # Emit signal to update main window
        self.preferences_changed.emit()
    
    def refresh_theme_list(self):
        """Refresh the theme combo box with all available themes"""
        current_theme = self.theme_combo.currentText() if self.theme_combo.count() > 0 else None
        self.theme_combo.clear()
        
        # Add built-in themes
        built_in_themes = ["Dark", "Light", "High Contrast"]
        self.theme_combo.addItems(built_in_themes)
        
        # Add custom themes
        custom_themes = self.theme_manager.get_custom_themes()
        if custom_themes:
            self.theme_combo.insertSeparator(len(built_in_themes))
            self.theme_combo.addItems(custom_themes)
        
        # Restore selection
        if current_theme:
            index = self.theme_combo.findText(current_theme)
            if index >= 0:
                self.theme_combo.setCurrentIndex(index)
    
    def save_custom_theme(self):
        """Save current color settings as a custom theme"""
        from PySide6.QtWidgets import QInputDialog
        
        # Ask for theme name
        theme_name, ok = QInputDialog.getText(
            self, "Save Custom Theme", "Enter theme name:"
        )
        
        if not ok or not theme_name:
            return
        
        # Check if it's a built-in theme name
        if theme_name in ["Dark", "Light", "High Contrast"]:
            QMessageBox.warning(
                self, "Invalid Name", 
                "Cannot use built-in theme names. Please choose a different name."
            )
            return
        
        # Collect current custom colors
        theme_data = {
            "accent": self.settings.get("Accent_Color", "#0078d4")
        }
        
        color_types = ["font_color", "button_color", "menu_color", "background_color", "border_color", "input_color"]
        color_mapping = {
            "font_color": "foreground",
            "button_color": "button_bg", 
            "menu_color": "menu_bar",
            "background_color": "background",
            "border_color": "border",
            "input_color": "input_bg"
        }
        
        for color_type in color_types:
            custom_color = self.settings.get(f"Custom_{color_type.title()}", "")
            if custom_color:
                theme_data[color_mapping[color_type]] = custom_color
        
        # Save custom theme
        self.theme_manager.save_custom_theme(theme_name, theme_data)
        
        # Refresh theme list and select the new theme
        self.refresh_theme_list()
        index = self.theme_combo.findText(theme_name)
        if index >= 0:
            self.theme_combo.setCurrentIndex(index)
        
        QMessageBox.information(
            self, "Theme Saved", 
            f"Custom theme '{theme_name}' has been saved successfully!"
        )
    
    def delete_custom_theme(self):
        """Delete a custom theme"""
        current_theme = self.theme_combo.currentText()
        
        # Check if it's a built-in theme
        if current_theme in ["Dark", "Light", "High Contrast"]:
            QMessageBox.warning(
                self, "Cannot Delete", 
                "Built-in themes cannot be deleted."
            )
            return
        
        # Check if it's a custom theme
        custom_themes = self.theme_manager.get_custom_themes()
        if current_theme not in custom_themes:
            QMessageBox.warning(
                self, "Cannot Delete", 
                "Please select a custom theme to delete."
            )
            return
        
        # Confirm deletion
        reply = QMessageBox.question(
            self, "Delete Theme",
            f"Are you sure you want to delete the custom theme '{current_theme}'?",
            QMessageBox.Yes | QMessageBox.No
        )
        
        if reply == QMessageBox.Yes:
            self.theme_manager.delete_custom_theme(current_theme)
            
            # Refresh theme list and switch to Dark theme
            self.refresh_theme_list()
            self.theme_combo.setCurrentText("Dark")
            
            QMessageBox.information(
                self, "Theme Deleted", 
                f"Custom theme '{current_theme}' has been deleted."
            )
    
    def load_custom_colors(self):
        """Load custom colors and update button appearances"""
        color_types = ["font_color", "button_color", "menu_color", "background_color", "border_color", "input_color"]
        colors = self.theme_manager.get_colors()
        color_mapping = {
            "font_color": "foreground",
            "button_color": "button_bg", 
            "menu_color": "menu_bar",
            "background_color": "background",
            "border_color": "border",
            "input_color": "input_bg"
        }
        
        for color_type in color_types:
            custom_color = self.settings.get(f"Custom_{color_type.title()}", "")
            if custom_color:
                color = custom_color
            else:
                color = colors.get(color_mapping.get(color_type, "foreground"), "#cccccc")
            
            button = getattr(self, f"{color_type}_btn")
            button.setStyleSheet(f"background-color: {color}; border: 1px solid #555555;")
    
    def apply_theme(self):
        """Apply current theme to dialog"""
        # Get custom colors if they exist
        custom_colors = {}
        color_types = ["font_color", "button_color", "menu_color", "background_color", "border_color", "input_color"]
        color_mapping = {
            "font_color": "foreground",
            "button_color": "button_bg", 
            "menu_color": "menu_bar",
            "background_color": "background",
            "border_color": "border",
            "input_color": "input_bg"
        }
        
        for color_type in color_types:
            custom_color = self.settings.get(f"Custom_{color_type.title()}", "")
            if custom_color:
                custom_colors[color_mapping[color_type]] = custom_color
        
        # Apply custom colors globally through theme manager
        if custom_colors:
            self.theme_manager.apply_custom_colors(custom_colors)
        else:
            # Apply default theme
            QCoreApplication.instance().setStyleSheet(self.theme_manager.get_stylesheet("main"))
        
        # Apply to this dialog
        self.setStyleSheet(self.theme_manager.get_stylesheet("main"))
    
    def generate_custom_stylesheet(self, colors):
        """Generate stylesheet with custom colors"""
        return f"""
        QMainWindow, QWidget, QDockWidget {{
            background-color: {colors.get('background', '#2b2b2b')}; 
            color: {colors.get('foreground', '#cccccc')};
        }}
        QMenuBar {{
            background-color: {colors.get('menu_bar', '#3c3c3c')}; 
            color: {colors.get('foreground', '#cccccc')};
        }}
        QMenu {{
            background-color: {colors.get('menu_bar', '#3c3c3c')}; 
            color: {colors.get('foreground', '#cccccc')};
        }}
        QMenu::item:selected {{
            background-color: {self.accent_color};
        }}
        QTabWidget::pane {{
            border: 1px solid {colors.get('border', '#4a4a4a')};
        }}
        QTabBar::tab {{
            background: {colors.get('menu_bar', '#3c3c3c')}; 
            color: {colors.get('foreground', '#cccccc')}; 
            border: 1px solid {colors.get('border', '#4a4a4a')}; 
            border-bottom-color: {colors.get('menu_bar', '#3c3c3c')}; 
            padding: 5px;
        }}
        QTabBar::tab:selected {{
            background: {colors.get('background', '#2b2b2b')}; 
            border-bottom-color: {colors.get('background', '#2b2b2b')};
        }}
        QTreeWidget {{
            background-color: {colors.get('background', '#2b2b2b')}; 
            color: {colors.get('foreground', '#cccccc')}; 
            alternate-background-color: {colors.get('menu_bar', '#3c3c3c')};
        }}
        QTreeWidget::item:selected {{
            background-color: {self.accent_color}; 
            color: white;
        }}
        QLineEdit, QSpinBox, QComboBox, QTextEdit {{
            background-color: {colors.get('input_bg', '#3c3c3c')}; 
            color: {colors.get('foreground', '#cccccc')}; 
            border: 1px solid {colors.get('border', '#4a4a4a')};
        }}
        QPushButton {{
            background-color: {colors.get('button_bg', '#4a4a4a')}; 
            color: {colors.get('foreground', '#cccccc')}; 
            border: 1px solid {colors.get('border', '#5a5a5a')}; 
            padding: 5px;
        }}
        QPushButton:hover {{
            background-color: {colors.get('button_hover', '#5a5a5a')};
        }}
        QPushButton:pressed {{
            background-color: {colors.get('button_pressed', '#3a3a3a')};
        }}
        QLabel {{
            color: {colors.get('foreground', '#cccccc')};
        }}
        QGroupBox {{
            color: {colors.get('foreground', '#cccccc')}; 
            border: 1px solid {colors.get('border', '#4a4a4a')}; 
            margin-top: 10px;
        }}
        QGroupBox::title {{
            subcontrol-origin: margin; 
            subcontrol-position: top left; 
            padding: 0 3px;
        }}
        """
    
    def _get_bool(self, key, default=False):
        """Helper to get boolean value from settings"""
        value = self.settings.get(key, default)
        if isinstance(value, bool):
            return value
        if isinstance(value, str):
            return value.lower() in ('true', '1', 'yes')
        return bool(value)
    
    def _get_int(self, key, default=0):
        """Helper to get integer value from settings"""
        value = self.settings.get(key, default)
        try:
            return int(value)
        except (ValueError, TypeError):
            return default
    
    def load_settings(self):
        """Load current settings into UI"""
        # General settings
        self.default_project_path.setText(str(self.settings.get("Default_Project_Path", "")))
        self.venv_path.setText(str(self.settings.get("VENV_Path", "")))
        self.auto_save_enabled.setChecked(self._get_bool("Auto_Save_Enabled", False))
        self.auto_save_interval.setValue(self._get_int("Auto_Save_Interval", 5))
        
        # Debug settings
        debug_enabled = self.settings.get("Debug", False)
        if isinstance(debug_enabled, str):
            debug_enabled = debug_enabled.lower() == "true"
        self.debug_enabled.setChecked(bool(debug_enabled))
        self.show_grid.setChecked(self._get_bool("Show_Grid", True))
        self.grid_size.setValue(self._get_int("Grid_Size", 32))
        self.snap_to_grid.setChecked(self._get_bool("Snap_To_Grid", True))
        self.undo_levels.setValue(self._get_int("Undo_Levels", 50))
        
        # Project settings - load from project file if project is loaded, otherwise use defaults
        project_data = None
        if hasattr(self, 'app') and self.app and hasattr(self.app, 'project_manager'):
            project_data = self.app.project_manager.project_data
        
        if project_data:
            # Load from project file
            self.project_title.setText(str(project_data.get("title", project_data.get("name", ""))))
            self.project_author.setText(str(project_data.get("author", "")))
            self.project_version.setText(str(project_data.get("version", "1.0.0")))
            self.project_description.setPlainText(str(project_data.get("description", "")))
            
            # Game settings from project
            game_settings = project_data.get("game_settings", {})
            self.target_fps.setValue(game_settings.get("target_fps", 60))
            self.window_width.setValue(game_settings.get("window_width", 1024))
            self.window_height.setValue(game_settings.get("window_height", 768))
            self.fullscreen.setChecked(game_settings.get("fullscreen", False))
        else:
            # No project loaded - use defaults
            self.project_title.setText("")
            self.project_author.setText("")
            self.project_version.setText("1.0.0")
            self.project_description.setPlainText("")
            self.target_fps.setValue(60)
            self.window_width.setValue(1024)
            self.window_height.setValue(768)
            self.fullscreen.setChecked(False)
        
        # Appearance settings
        current_theme = self.theme_manager.get_current_theme()
        
        # Block signals to prevent triggering on_theme_changed during load
        self.theme_combo.blockSignals(True)
        self.theme_combo.setCurrentText(current_theme)
        self.theme_combo.blockSignals(False)
        
        accent_color = str(self.settings.get("Accent_Color", "#0078d4"))
        self.accent_color_btn.setStyleSheet(f"background-color: {accent_color}; border: 1px solid #555555;")
        self.accent_color = accent_color
        self.ui_font_size.setValue(self._get_int("UI_Font_Size", 9))
        self.editor_font_size.setValue(self._get_int("Editor_Font_Size", 10))
        self.editor_font_family.setCurrentText(str(self.settings.get("Editor_Font_Family", "Consolas")))
        
        # Load custom colors for the current theme
        self.load_custom_colors()
        
        # If it's a custom theme, load its colors into settings for proper application
        custom_themes = self.theme_manager.get_custom_themes()
        if current_theme in custom_themes:
            theme_colors = self.theme_manager.get_colors()
            color_mapping = {
                "font_color": "foreground",
                "button_color": "button_bg", 
                "menu_color": "menu_bar",
                "background_color": "background",
                "border_color": "border",
                "input_color": "input_bg"
            }
            
            # Load custom theme colors into settings
            for color_type, theme_key in color_mapping.items():
                color = theme_colors.get(theme_key)
                if color:
                    self.settings.set(f"Custom_{color_type.title()}", color)
        
        # Script settings
        self.tab_size.setValue(self._get_int("Tab_Size", 4))
        self.insert_spaces.setChecked(self._get_bool("Insert_Spaces", True))
        self.word_wrap.setChecked(self._get_bool("Word_Wrap", False))
        self.line_numbers.setChecked(self._get_bool("Line_Numbers", True))
        self.auto_indent.setChecked(self._get_bool("Auto_Indent", True))
        self.syntax_highlighting.setChecked(self._get_bool("Syntax_Highlighting", True))
        self.bracket_matching.setChecked(self._get_bool("Bracket_Matching", True))
        self.auto_completion.setChecked(self._get_bool("Auto_Completion", True))
        self.auto_completion_threshold.setValue(self._get_int("Auto_Completion_Threshold", 3))
        
        # PGSL settings
        if hasattr(self, 'pgsl_enabled'):
            self.pgsl_enabled.setChecked(self._get_bool("PGSL_Enabled", True))
            self.pgsl_syntax_highlight.setChecked(self._get_bool("PGSL_Syntax_Highlight", True))
            self.pgsl_auto_parse.setChecked(self._get_bool("PGSL_Auto_Parse", True))
        
        # Compiler settings
        if hasattr(self, 'default_window_width'):
            default_size = self.settings.get("Default_Room_Size", (800, 600))
            if isinstance(default_size, tuple) and len(default_size) >= 2:
                default_w, default_h = default_size[0], default_size[1]
            else:
                default_w, default_h = 800, 600
            self.default_window_width.setValue(self._get_int("Default_Window_Width", default_w))
            self.default_window_height.setValue(self._get_int("Default_Window_Height", default_h))
            self.default_game_fps.setValue(self._get_int("Default_Game_FPS", 60))
            self.build_output_dir.setText(str(self.settings.get("Build_Output_Directory", "")))
            self.validate_before_run.setChecked(self._get_bool("Validate_Before_Run", True))
        
        # Editor specific settings - Image Editor
        self.default_sprite_width.setValue(self._get_int("Default_Sprite_Width", 32))
        self.default_sprite_height.setValue(self._get_int("Default_Sprite_Height", 32))
        self.default_sprite_fps.setValue(self._get_int("Default_Sprite_FPS", 30))
        self.sprite_grid_visible.setChecked(self._get_bool("Sprite_Grid_Visible", True))
        self.sprite_global_grid.setChecked(self._get_bool("Sprite_Global_Grid", False))
        self.sprite_origin_visible.setChecked(self._get_bool("Sprite_Origin_Visible", True))
        
        # Image Editor settings
        self.default_canvas_width.setValue(self._get_int("Default_Canvas_Width", 512))
        self.default_canvas_height.setValue(self._get_int("Default_Canvas_Height", 512))
        self.default_image_grid_size.setValue(self._get_int("Default_Image_Grid_Size", 32))
        self.image_grid_visible.setChecked(self._get_bool("Image_Grid_Visible", True))
        self.image_global_grid.setChecked(self._get_bool("Image_Global_Grid", False))
        
        # Load hardware rendering setting from Image Editor's settings file
        try:
            import sys
            import os
            # Get path to Image Editor settings
            current_dir = os.path.dirname(os.path.abspath(__file__))  # UI/
            project_root = os.path.dirname(os.path.dirname(current_dir))  # Go up to project root
            image_editor_settings_path = os.path.join(project_root, "Editors", "Image", "2", "core", "settings.py")
            
            if os.path.exists(image_editor_settings_path):
                image_editor_path = os.path.join(project_root, "Editors", "Image", "2")
                if image_editor_path not in sys.path:
                    sys.path.insert(0, image_editor_path)
                    from core.settings import settings as image_settings
                    use_gpu = getattr(image_settings, 'use_gpu_canvas', False)
                    self.image_use_gpu_canvas.setChecked(use_gpu)
                    sys.path.remove(image_editor_path)
            else:
                # Fallback to QSettings
                self.image_use_gpu_canvas.setChecked(self._get_bool("Image_Use_GPU_Canvas", False))
        except Exception as e:
            # If loading fails, use QSettings fallback or default
            self.image_use_gpu_canvas.setChecked(self._get_bool("Image_Use_GPU_Canvas", False))
        
        # Audio Editor settings
        self.default_sample_rate.setCurrentText(str(self.settings.get("Default_Sample_Rate", "44100 Hz")))
        self.default_bit_depth.setCurrentText(str(self.settings.get("Default_Bit_Depth", "16-bit")))
        self.default_channels.setCurrentText(str(self.settings.get("Default_Channels", "Stereo")))
        self.audio_auto_play.setChecked(self._get_bool("Audio_Auto_Play", False))
        self.audio_loop_preview.setChecked(self._get_bool("Audio_Loop_Preview", False))
        
        # Background Editor settings
        self.default_bg_width.setValue(self._get_int("Default_Bg_Width", 1024))
        self.default_bg_height.setValue(self._get_int("Default_Bg_Height", 768))
        self.bg_grid_visible.setChecked(self._get_bool("Bg_Grid_Visible", True))
        self.bg_tile_mode.setChecked(self._get_bool("Bg_Tile_Mode", False))
        
        # Object Editor settings
        self.default_obj_width.setValue(self._get_int("Default_Obj_Width", 32))
        self.default_obj_height.setValue(self._get_int("Default_Obj_Height", 32))
        self.obj_show_events.setChecked(self._get_bool("Obj_Show_Events", True))
        self.obj_show_properties.setChecked(self._get_bool("Obj_Show_Properties", True))
        
        # Model Editor settings
        self.default_model_scale.setValue(self._get_int("Default_Model_Scale", 10))
        self.model_show_wireframe.setChecked(self._get_bool("Model_Show_Wireframe", True))
        self.model_show_textures.setChecked(self._get_bool("Model_Show_Textures", True))
        self.model_auto_rotate.setChecked(self._get_bool("Model_Auto_Rotate", False))
        
        # Model Editor lighting settings
        lighting_style = str(self.settings.get("Model_Editor_Lighting_Style", "Default"))
        index = self.model_lighting_style.findText(lighting_style)
        if index >= 0:
            self.model_lighting_style.setCurrentIndex(index)
        
        self.model_external_light_enabled.setChecked(self._get_bool("Model_Editor_External_Light_Enabled", False))
        
        # Brightness stored as float (0.0-10.0), but UI uses percentage (1-100)
        brightness = self.settings.get("Model_Editor_External_Light_Brightness", 5.0)
        try:
            brightness = float(brightness)  # Ensure it's a float
        except (ValueError, TypeError):
            brightness = 5.0  # Default fallback
        brightness_percent = int(brightness * 10.0)  # Convert 5.0 to 50%
        brightness_percent = max(1, min(100, brightness_percent))  # Clamp
        self.model_external_light_brightness.setValue(brightness_percent)
        
        light_position = str(self.settings.get("Model_Editor_Light_Position_Mode", "top"))
        index = self.model_light_position.findText(light_position)
        if index >= 0:
            self.model_light_position.setCurrentIndex(index)
        
        # Model Editor selection colors
        face_color_str = str(self.settings.get("Model_Selection_Face_Color", "#00ffff"))
        self.model_selection_face_color_btn.setStyleSheet(f"background-color: {face_color_str}; border: 1px solid #555555; min-width: 50px; min-height: 25px;")
        edge_color_str = str(self.settings.get("Model_Selection_Edge_Color", "#00ffff"))
        self.model_selection_edge_color_btn.setStyleSheet(f"background-color: {edge_color_str}; border: 1px solid #555555; min-width: 50px; min-height: 25px;")
        
        # Model Editor view settings
        bg_color_str = str(self.settings.get("Model_Background_Color", "#1a1a1a"))
        self.model_background_color_btn.setStyleSheet(f"background-color: {bg_color_str}; border: 1px solid #555555; min-width: 50px; min-height: 25px;")
        self.model_show_grid.setChecked(self._get_bool("Model_Show_Grid", True))
        self.model_show_background.setChecked(self._get_bool("Model_Show_Background", True))
        self.model_show_skyline.setChecked(self._get_bool("Model_Show_Skyline", False))
        
        # Skyline color and texture
        skyline_color_str = str(self.settings.get("Model_Skyline_Color", "#87ceeb"))  # Sky blue default
        self.model_skyline_color_btn.setStyleSheet(f"background-color: {skyline_color_str}; border: 1px solid #555555; min-width: 50px; min-height: 25px;")
        skyline_texture = self.settings.get("Model_Skyline_Texture", "")
        # Convert texture ID to name for display
        if skyline_texture and self.app and hasattr(self.app, 'project_manager'):
            try:
                texture_resources = self.app.project_manager.get_resources("textures")
                for tex in texture_resources:
                    if tex.get("id") == skyline_texture:
                        self.model_skyline_texture_edit.setText(tex.get("name", ""))
                        break
                else:
                    self.model_skyline_texture_edit.setText("")
            except:
                self.model_skyline_texture_edit.setText("")
        else:
            self.model_skyline_texture_edit.setText("")
        
        # Skyline texture mode and scale
        skyline_texture_mode = str(self.settings.get("Model_Skyline_Texture_Mode", "Stretch"))
        index = self.model_skyline_texture_mode.findText(skyline_texture_mode)
        if index >= 0:
            self.model_skyline_texture_mode.setCurrentIndex(index)
        
        skyline_scale_x = float(self.settings.get("Model_Skyline_Texture_Scale_X", 1.0))
        skyline_scale_y = float(self.settings.get("Model_Skyline_Texture_Scale_Y", 1.0))
        self.model_skyline_custom_scale_x.setValue(skyline_scale_x)
        self.model_skyline_custom_scale_y.setValue(skyline_scale_y)
        
        # Background/Floor color and texture (single setting)
        background_color_str = str(self.settings.get("Model_Background_Color", "#1a1a1a"))  # Dark gray default
        self.model_background_color_btn.setStyleSheet(f"background-color: {background_color_str}; border: 1px solid #555555; min-width: 50px; min-height: 25px;")
        background_texture = self.settings.get("Model_Background_Texture", "")
        # Convert texture ID to name for display
        if background_texture and self.app and hasattr(self.app, 'project_manager'):
            try:
                texture_resources = self.app.project_manager.get_resources("textures")
                for tex in texture_resources:
                    if tex.get("id") == background_texture:
                        self.model_background_texture_edit.setText(tex.get("name", ""))
                        break
                else:
                    self.model_background_texture_edit.setText("")
            except:
                self.model_background_texture_edit.setText("")
        else:
            self.model_background_texture_edit.setText("")
        
        # Background/Floor texture mode and scale
        background_texture_mode = str(self.settings.get("Model_Background_Texture_Mode", "Stretch"))
        index = self.model_background_texture_mode.findText(background_texture_mode)
        if index >= 0:
            self.model_background_texture_mode.setCurrentIndex(index)
        
        background_scale_x = float(self.settings.get("Model_Background_Texture_Scale_X", 1.0))
        background_scale_y = float(self.settings.get("Model_Background_Texture_Scale_Y", 1.0))
        self.model_background_custom_scale_x.setValue(background_scale_x)
        self.model_background_custom_scale_y.setValue(background_scale_y)
        
        # Model Editor smooth settings
        self.model_smooth_movement_enabled.setChecked(self._get_bool("Model_Smooth_Movement_Enabled", False))
        self.model_smooth_camera_enabled.setChecked(self._get_bool("Model_Smooth_Camera_Enabled", False))
        smooth_factor = self.settings.get("Model_Smooth_Factor", 0.15)
        try:
            smooth_factor = float(smooth_factor)  # Ensure it's a float
        except (ValueError, TypeError):
            smooth_factor = 0.15  # Default fallback
        self.model_smooth_factor.setValue(smooth_factor)
        
        # Room Editor settings
        self.default_room_width.setValue(self._get_int("Default_Room_Width", 1024))
        self.default_room_height.setValue(self._get_int("Default_Room_Height", 768))
        self.room_grid_visible.setChecked(self._get_bool("Room_Grid_Visible", True))
        self.room_snap_to_grid.setChecked(self._get_bool("Room_Snap_To_Grid", True))
        self.room_show_layers.setChecked(self._get_bool("Room_Show_Layers", True))
        
        # Load recent projects
        import os
        from pathlib import Path
        recent_projects = self.settings.get_recent_projects()
        self.recent_projects_list.clear()
        for project_path in recent_projects:
            if project_path and os.path.exists(project_path):
                # Display just the project name or folder name
                project_name = Path(project_path).stem  # Get filename without extension
                if project_name.endswith('.pgproject'):
                    project_name = project_name[:-10]  # Remove .pgproject extension
                # If still empty, use folder name
                if not project_name:
                    project_name = Path(project_path).parent.name
                # Create item with display text
                display_text = f"{project_name}"
                item = QListWidgetItem(display_text)
                # Store full path in item data (Qt.UserRole = 256)
                item.setData(256, project_path)
                item.setToolTip(project_path)  # Show full path on hover
                self.recent_projects_list.addItem(item)
        
        # Backup settings
        import os
        from pathlib import Path
        user_home = Path.home()
        default_editor_backup = os.path.join(str(user_home), "PyGenesis", "Backups", "Editor")
        default_project_backup = os.path.join(str(user_home), "PyGenesis", "Backups", "Projects")
        self.editor_backup_path.setText(str(self.settings.get("Editor_Backup_Location", default_editor_backup)))
        self.project_backup_path.setText(str(self.settings.get("Project_Backup_Location", default_project_backup)))
        
        # Generate Summary settings
        editor_summary_default = self.settings.get("Editor_Summary_Location", default_editor_backup)
        self.editor_summary_path.setText(str(editor_summary_default))
        
        # User Information settings
        if hasattr(self, 'user_name'):
            self.user_name.setText(self.settings.get("User_Name", "Engineer"))
        if hasattr(self, 'user_email'):
            self.user_email.setText(self.settings.get("User_Email", ""))
        if hasattr(self, 'user_website'):
            self.user_website.setText(self.settings.get("User_Website", ""))
        
        # Language settings
        if hasattr(self, 'language_combo'):
            language_setting = self.settings.get("Language", "en_uk")
            # Find and set the correct index
            for i in range(self.language_combo.count()):
                if self.language_combo.itemData(i) == language_setting:
                    self.language_combo.setCurrentIndex(i)
                    break
        
        # Advanced Mode setting
        if hasattr(self, 'advanced_mode'):
            self.advanced_mode.setChecked(self._get_bool("Advanced_Mode", False))
        
        # AI settings - API keys are loaded in load_api_keys() which is called from create_ai_api_keys_tab()
        # AI Edits settings
        if hasattr(self, 'allow_high_risk'):
            self.allow_high_risk.setChecked(self._get_bool("AI_Allow_High_Risk", False))
        if hasattr(self, 'allow_auto_followup'):
            self.allow_auto_followup.setChecked(self._get_bool("AI_Allow_Auto_Followup", False))
        if hasattr(self, 'show_nova_thinking'):
            self.show_nova_thinking.setChecked(self._get_bool("AI_Show_Nova_Thinking", False))
        if hasattr(self, 'train_nova_on_chats'):
            self.train_nova_on_chats.setChecked(self._get_bool("AI_Train_Nova_On_Chats", True))  # Default: True
    
    def apply_settings(self):
        """Apply current settings"""
        # User Information settings
        if hasattr(self, 'user_name'):
            user_name = self.user_name.text().strip()
            self.settings.set("User_Name", user_name if user_name else "Engineer")
        if hasattr(self, 'user_email'):
            self.settings.set("User_Email", self.user_email.text().strip())
        if hasattr(self, 'user_website'):
            self.settings.set("User_Website", self.user_website.text().strip())
        
        # Language settings
        if hasattr(self, 'language_combo'):
            language_value = self.language_combo.currentData()
            if language_value:
                self.settings.set("Language", language_value)
            else:
                self.settings.set("Language", "en_uk")  # Default
        
        # Advanced Mode setting
        if hasattr(self, 'advanced_mode'):
            self.settings.set("Advanced_Mode", self.advanced_mode.isChecked())
        
        # General settings
        self.settings.set("Default_Project_Path", self.default_project_path.text())
        self.settings.set("VENV_Path", self.venv_path.text())
        self.settings.set("Auto_Save_Enabled", self.auto_save_enabled.isChecked())
        self.settings.set("Auto_Save_Interval", self.auto_save_interval.value())
        self.settings.set("Show_Grid", self.show_grid.isChecked())
        self.settings.set("Grid_Size", self.grid_size.value())
        self.settings.set("Snap_To_Grid", self.snap_to_grid.isChecked())
        self.settings.set("Undo_Levels", self.undo_levels.value())
        
        # Backup settings
        self.settings.set("Editor_Backup_Location", self.editor_backup_path.text())
        self.settings.set("Project_Backup_Location", self.project_backup_path.text())
        
        # Generate Summary settings
        self.settings.set("Editor_Summary_Location", self.editor_summary_path.text())
        
        # Debug settings
        self.settings.set("Debug", self.debug_enabled.isChecked())
        
        # Initialize debug manager with updated settings
        try:
            from Core.Debug import init_debug, _debug_manager
            init_debug(self.settings)
            # Reset debug state to force re-check with new settings
            _debug_manager.reset()
        except ImportError:
            pass
        
        # AI settings - API Keys
        self.save_api_keys()
        
        # AI Edits settings
        if hasattr(self, 'allow_high_risk'):
            self.settings.set("AI_Allow_High_Risk", self.allow_high_risk.isChecked())
        if hasattr(self, 'allow_auto_followup'):
            self.settings.set("AI_Allow_Auto_Followup", self.allow_auto_followup.isChecked())
        if hasattr(self, 'show_nova_thinking'):
            self.settings.set("AI_Show_Nova_Thinking", self.show_nova_thinking.isChecked())
        if hasattr(self, 'train_nova_on_chats'):
            self.settings.set("AI_Train_Nova_On_Chats", self.train_nova_on_chats.isChecked())
        
        # Emit signal that preferences changed
        self.preferences_changed.emit()
        
        # Project settings - save to project file if project is loaded
        if hasattr(self, 'app') and self.app and hasattr(self.app, 'project_manager'):
            project_manager = self.app.project_manager
            if project_manager.project_data:
                # Update project data
                project_manager.project_data["title"] = self.project_title.text()
                project_manager.project_data["author"] = self.project_author.text()
                project_manager.project_data["version"] = self.project_version.text()
                project_manager.project_data["description"] = self.project_description.toPlainText()
                
                # Update game settings
                if "game_settings" not in project_manager.project_data:
                    project_manager.project_data["game_settings"] = {}
                project_manager.project_data["game_settings"]["target_fps"] = self.target_fps.value()
                project_manager.project_data["game_settings"]["window_width"] = self.window_width.value()
                project_manager.project_data["game_settings"]["window_height"] = self.window_height.value()
                project_manager.project_data["game_settings"]["fullscreen"] = self.fullscreen.isChecked()
                
                # Mark project as dirty so it gets saved
                project_manager.is_dirty = True
        
        # Appearance settings
        self.settings.set("Theme", self.theme_combo.currentText())
        self.settings.set("Accent_Color", self.accent_color)
        self.settings.set("UI_Font_Size", self.ui_font_size.value())
        self.settings.set("Editor_Font_Size", self.editor_font_size.value())
        self.settings.set("Editor_Font_Family", self.editor_font_family.currentText())
        
        # Script settings
        self.settings.set("Tab_Size", self.tab_size.value())
        self.settings.set("Insert_Spaces", self.insert_spaces.isChecked())
        self.settings.set("Word_Wrap", self.word_wrap.isChecked())
        self.settings.set("Line_Numbers", self.line_numbers.isChecked())
        self.settings.set("Auto_Indent", self.auto_indent.isChecked())
        self.settings.set("Syntax_Highlighting", self.syntax_highlighting.isChecked())
        self.settings.set("Bracket_Matching", self.bracket_matching.isChecked())
        self.settings.set("Auto_Completion", self.auto_completion.isChecked())
        self.settings.set("Auto_Completion_Threshold", self.auto_completion_threshold.value())
        
        # PGSL settings
        self.settings.set("PGSL_Enabled", self.pgsl_enabled.isChecked())
        self.settings.set("PGSL_Syntax_Highlight", self.pgsl_syntax_highlight.isChecked())
        self.settings.set("PGSL_Auto_Parse", self.pgsl_auto_parse.isChecked())
        
        # Compiler settings
        self.settings.set("Default_Window_Width", self.default_window_width.value())
        self.settings.set("Default_Window_Height", self.default_window_height.value())
        self.settings.set("Default_Game_FPS", self.default_game_fps.value())
        self.settings.set("Default_Room_Size", (self.default_window_width.value(), self.default_window_height.value()))
        self.settings.set("Build_Output_Directory", self.build_output_dir.text())
        self.settings.set("Validate_Before_Run", self.validate_before_run.isChecked())
        
        # Editor specific settings - Image Editor
        self.settings.set("Default_Sprite_Width", self.default_sprite_width.value())
        self.settings.set("Default_Sprite_Height", self.default_sprite_height.value())
        self.settings.set("Default_Sprite_FPS", self.default_sprite_fps.value())
        self.settings.set("Sprite_Grid_Visible", self.sprite_grid_visible.isChecked())
        self.settings.set("Sprite_Global_Grid", self.sprite_global_grid.isChecked())
        self.settings.set("Sprite_Origin_Visible", self.sprite_origin_visible.isChecked())
        
        # Image Editor settings
        self.settings.set("Default_Canvas_Width", self.default_canvas_width.value())
        self.settings.set("Default_Canvas_Height", self.default_canvas_height.value())
        self.settings.set("Default_Image_Grid_Size", self.default_image_grid_size.value())
        self.settings.set("Image_Grid_Visible", self.image_grid_visible.isChecked())
        self.settings.set("Image_Global_Grid", self.image_global_grid.isChecked())
        
        # Save hardware rendering setting to Image Editor's settings file
        try:
            import sys
            import os
            # Get path to Image Editor settings
            current_dir = os.path.dirname(os.path.abspath(__file__))  # UI/
            project_root = os.path.dirname(os.path.dirname(current_dir))  # Go up to project root
            image_editor_settings_path = os.path.join(project_root, "Editors", "Image", "2", "core", "settings.py")
            
            if os.path.exists(image_editor_settings_path):
                image_editor_path = os.path.join(project_root, "Editors", "Image", "2")
                if image_editor_path not in sys.path:
                    sys.path.insert(0, image_editor_path)
                    from core.settings import settings as image_settings
                    image_settings.use_gpu_canvas = self.image_use_gpu_canvas.isChecked()
                    image_settings.save()
                    sys.path.remove(image_editor_path)
        except Exception as e:
            # If saving fails, at least save to QSettings as backup
            import traceback
            traceback.print_exc()
            pass
        
        # Also save to QSettings as backup
        self.settings.set("Image_Use_GPU_Canvas", self.image_use_gpu_canvas.isChecked())
        
        # Audio Editor settings
        self.settings.set("Default_Sample_Rate", self.default_sample_rate.currentText())
        self.settings.set("Default_Bit_Depth", self.default_bit_depth.currentText())
        self.settings.set("Default_Channels", self.default_channels.currentText())
        self.settings.set("Audio_Auto_Play", self.audio_auto_play.isChecked())
        self.settings.set("Audio_Loop_Preview", self.audio_loop_preview.isChecked())
        
        # Background Editor settings
        self.settings.set("Default_Bg_Width", self.default_bg_width.value())
        self.settings.set("Default_Bg_Height", self.default_bg_height.value())
        self.settings.set("Bg_Grid_Visible", self.bg_grid_visible.isChecked())
        self.settings.set("Bg_Tile_Mode", self.bg_tile_mode.isChecked())
        
        # Object Editor settings
        self.settings.set("Default_Obj_Width", self.default_obj_width.value())
        self.settings.set("Default_Obj_Height", self.default_obj_height.value())
        self.settings.set("Obj_Show_Events", self.obj_show_events.isChecked())
        self.settings.set("Obj_Show_Properties", self.obj_show_properties.isChecked())
        
        # Model Editor settings
        self.settings.set("Default_Model_Scale", self.default_model_scale.value())
        self.settings.set("Model_Show_Wireframe", self.model_show_wireframe.isChecked())
        self.settings.set("Model_Show_Textures", self.model_show_textures.isChecked())
        self.settings.set("Model_Auto_Rotate", self.model_auto_rotate.isChecked())
        
        # Model Editor lighting settings
        self.settings.set("Model_Editor_Lighting_Style", self.model_lighting_style.currentText())
        self.settings.set("Model_Editor_External_Light_Enabled", self.model_external_light_enabled.isChecked())
        
        # Convert percentage back to float (50% -> 5.0)
        brightness_float = self.model_external_light_brightness.value() / 10.0
        self.settings.set("Model_Editor_External_Light_Brightness", brightness_float)
        
        self.settings.set("Model_Editor_Light_Position_Mode", self.model_light_position.currentText())
        
        # Model Editor selection colors (already saved when color button clicked, but ensure they're set)
        # Extract colors from button stylesheets if not already in settings
        face_color_style = self.model_selection_face_color_btn.styleSheet()
        if "background-color:" in face_color_style:
            face_color = face_color_style.split("background-color:")[1].split(";")[0].strip()
            self.settings.set("Model_Selection_Face_Color", face_color)
        edge_color_style = self.model_selection_edge_color_btn.styleSheet()
        if "background-color:" in edge_color_style:
            edge_color = edge_color_style.split("background-color:")[1].split(";")[0].strip()
            self.settings.set("Model_Selection_Edge_Color", edge_color)
        
        # Model Editor view settings
        bg_color_style = self.model_background_color_btn.styleSheet()
        if "background-color:" in bg_color_style:
            bg_color = bg_color_style.split("background-color:")[1].split(";")[0].strip()
            self.settings.set("Model_Background_Color", bg_color)
        self.settings.set("Model_Show_Grid", self.model_show_grid.isChecked())
        self.settings.set("Model_Show_Background", self.model_show_background.isChecked())
        self.settings.set("Model_Show_Skyline", self.model_show_skyline.isChecked())
        
        # Skyline color and texture
        skyline_color_style = self.model_skyline_color_btn.styleSheet()
        if "background-color:" in skyline_color_style:
            skyline_color = skyline_color_style.split("background-color:")[1].split(";")[0].strip()
            self.settings.set("Model_Skyline_Color", skyline_color)
        # Convert texture name back to ID if needed
        skyline_texture_name = self.model_skyline_texture_edit.text().strip()
        if skyline_texture_name and self.app and hasattr(self.app, 'project_manager'):
            try:
                texture_resources = self.app.project_manager.get_resources("textures")
                for tex in texture_resources:
                    if tex.get("name") == skyline_texture_name:
                        self.settings.set("Model_Skyline_Texture", tex.get("id"))
                        break
                else:
                    self.settings.set("Model_Skyline_Texture", "")
            except:
                self.settings.set("Model_Skyline_Texture", "")
        else:
            self.settings.set("Model_Skyline_Texture", "")
        
        # Background/Floor color and texture (single setting - used for both background and floor)
        background_color_style = self.model_background_color_btn.styleSheet()
        if "background-color:" in background_color_style:
            background_color = background_color_style.split("background-color:")[1].split(";")[0].strip()
            self.settings.set("Model_Background_Color", background_color)
        # Convert texture name back to ID if needed
        background_texture_name = self.model_background_texture_edit.text().strip()
        if background_texture_name and self.app and hasattr(self.app, 'project_manager'):
            try:
                texture_resources = self.app.project_manager.get_resources("textures")
                for tex in texture_resources:
                    if tex.get("name") == background_texture_name:
                        self.settings.set("Model_Background_Texture", tex.get("id"))
                        break
                else:
                    self.settings.set("Model_Background_Texture", "")
            except:
                self.settings.set("Model_Background_Texture", "")
        else:
            self.settings.set("Model_Background_Texture", "")
        
        # Background/Floor texture mode and scale
        self.settings.set("Model_Background_Texture_Mode", self.model_background_texture_mode.currentText())
        self.settings.set("Model_Background_Texture_Scale_X", self.model_background_custom_scale_x.value())
        self.settings.set("Model_Background_Texture_Scale_Y", self.model_background_custom_scale_y.value())
        
        # Skyline texture mode and scale
        self.settings.set("Model_Skyline_Texture_Mode", self.model_skyline_texture_mode.currentText())
        self.settings.set("Model_Skyline_Texture_Scale_X", self.model_skyline_custom_scale_x.value())
        self.settings.set("Model_Skyline_Texture_Scale_Y", self.model_skyline_custom_scale_y.value())
        
        # Also set as floor color/texture for backward compatibility
        self.settings.set("Model_Floor_Color", background_color if "background-color:" in background_color_style else str(self.settings.get("Model_Background_Color", "#1a1a1a")))
        self.settings.set("Model_Floor_Texture", self.settings.get("Model_Background_Texture", ""))
        
        # Model Editor smooth settings
        self.settings.set("Model_Smooth_Movement_Enabled", self.model_smooth_movement_enabled.isChecked())
        self.settings.set("Model_Smooth_Camera_Enabled", self.model_smooth_camera_enabled.isChecked())
        self.settings.set("Model_Smooth_Factor", self.model_smooth_factor.value())
        
        # Room Editor settings
        self.settings.set("Default_Room_Width", self.default_room_width.value())
        self.settings.set("Default_Room_Height", self.default_room_height.value())
        self.settings.set("Room_Grid_Visible", self.room_grid_visible.isChecked())
        self.settings.set("Room_Snap_To_Grid", self.room_snap_to_grid.isChecked())
        self.settings.set("Room_Show_Layers", self.room_show_layers.isChecked())
        
        # AI settings - API keys are saved in save_api_keys() which is called above
        
        self.settings.sync()
        self.preferences_changed.emit()
    
    def clear_recent_projects(self):
        """Clear recent projects list"""
        self.settings.set("Recent_Projects", [])
        self.recent_projects_list.clear()
    
    def _on_recent_project_double_clicked(self, item):
        """Handle double-click on recent project to open it"""
        import os
        from PySide6.QtWidgets import QMessageBox
        
        # Get project path from item data or text
        project_path = None
        if hasattr(item, 'data') and item.data(256):  # Qt.UserRole
            project_path = item.data(256)
        else:
            # Fallback: extract from text (format: "ProjectName (path)")
            text = item.text()
            if '(' in text and ')' in text:
                project_path = text[text.rfind('(')+1:text.rfind(')')]
        
        if not project_path or not os.path.exists(project_path):
            QMessageBox.warning(self, "Project Not Found", 
                              f"The project file could not be found:\n{project_path}")
            # Remove from recent projects
            recent_projects = self.settings.get_recent_projects()
            if project_path in recent_projects:
                recent_projects.remove(project_path)
                self.settings.set("Recent_Projects", recent_projects)
                # Reload the list
                self.load_settings()  # Reload to refresh UI
            return
        
        # Check if there are unsaved changes (if main_window has this method)
        if hasattr(self, 'parent') and self.parent():
            main_window = self.parent()
            # Check if we need to save current project
            if hasattr(main_window, 'check_for_unsaved_changes'):
                should_save = main_window.check_for_unsaved_changes()
                if should_save is None:  # User cancelled
                    return
                if should_save:  # User wants to save
                    if hasattr(main_window, 'save_project'):
                        main_window.save_project()
        
        # Close preferences dialog
        self.accept()
        
        # Open the project via app's project manager
        if hasattr(self, 'app') and self.app:
            if self.app.project_manager.load_project(project_path):
                # Update main window if available
                if hasattr(self, 'parent') and self.parent():
                    main_window = self.parent()
                    if hasattr(main_window, 'resource_tree'):
                        main_window.resource_tree.refresh()
                    if hasattr(main_window, 'setWindowTitle'):
                        project_name = self.app.project_manager.get_project_name()
                        main_window.setWindowTitle(f"Python Game IDE - {project_name}")
                    if hasattr(main_window, 'status_bar'):
                        project_name = self.app.project_manager.get_project_name()
                        main_window.status_bar.showMessage(f"Project loaded: {project_name}")
    
    def accept(self):
        """Accept and apply settings"""
        self.apply_settings()
        super().accept()
