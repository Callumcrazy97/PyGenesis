"""
Dialog for selecting resource folders to include in project backups
"""

from PySide6.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QWidget, 
                               QLabel, QPushButton, QRadioButton, QButtonGroup,
                               QListWidget, QListWidgetItem, QGroupBox, QMessageBox)
from PySide6.QtCore import Qt
from pathlib import Path
from typing import Set, Optional


class ResourceFolderDialog(QDialog):
    """Dialog for selecting resource folders to include in project backup"""
    
    def __init__(self, project_dir: Path, parent=None):
        """
        Initialize resource folder dialog
        
        Args:
            project_dir: Project directory
            parent: Parent widget
        """
        super().__init__(parent)
        self.project_dir = Path(project_dir)
        self.selected_folders: Set[str] = set()
        self.setup_ui()
        self.populate_resource_folders()
    
    def setup_ui(self):
        """Setup the dialog UI"""
        self.setWindowTitle("Select Resource Folders")
        self.setMinimumSize(400, 500)
        
        layout = QVBoxLayout(self)
        
        # Instructions
        info_label = QLabel(
            "Select which resource folders to include in the project backup.\n"
            "Resource folders typically contain Sprites, Objects, Rooms, etc."
        )
        info_label.setWordWrap(True)
        layout.addWidget(info_label)
        
        # Selection mode
        mode_group = QGroupBox("Selection Mode")
        mode_layout = QVBoxLayout(mode_group)
        
        self.button_group = QButtonGroup(self)
        self.all_radio = QRadioButton("All Resource Folders")
        self.all_radio.setChecked(True)
        self.none_radio = QRadioButton("No Resource Folders")
        self.user_radio = QRadioButton("User Specified")
        
        self.button_group.addButton(self.all_radio, 0)
        self.button_group.addButton(self.none_radio, 1)
        self.button_group.addButton(self.user_radio, 2)
        
        self.all_radio.toggled.connect(self.on_mode_changed)
        self.none_radio.toggled.connect(self.on_mode_changed)
        self.user_radio.toggled.connect(self.on_mode_changed)
        
        mode_layout.addWidget(self.all_radio)
        mode_layout.addWidget(self.none_radio)
        mode_layout.addWidget(self.user_radio)
        
        layout.addWidget(mode_group)
        
        # Resource folder list (only enabled for user specified)
        folder_group = QGroupBox("Resource Folders")
        folder_layout = QVBoxLayout(folder_group)
        
        self.folder_list = QListWidget()
        self.folder_list.setEnabled(False)
        folder_layout.addWidget(self.folder_list)
        
        layout.addWidget(folder_group)
        
        # Dialog buttons
        button_box = QHBoxLayout()
        self.ok_btn = QPushButton("OK")
        self.ok_btn.clicked.connect(self.accept)
        self.cancel_btn = QPushButton("Cancel")
        self.cancel_btn.clicked.connect(self.reject)
        button_box.addStretch()
        button_box.addWidget(self.ok_btn)
        button_box.addWidget(self.cancel_btn)
        layout.addLayout(button_box)
    
    def populate_resource_folders(self):
        """Populate the resource folder list"""
        self.folder_list.clear()
        
        if not self.project_dir.exists():
            return
        
        # Common resource folder names
        resource_names = ["Sprites", "Objects", "Rooms", "Backgrounds", "Sounds", 
                        "Scripts", "Fonts", "Paths", "Timelines", "Shaders"]
        
        # Find existing resource folders
        for item in sorted(self.project_dir.iterdir()):
            if item.is_dir() and item.name in resource_names:
                folder_name = item.name
                item_widget = QListWidgetItem(folder_name)
                item_widget.setFlags(item_widget.flags() | Qt.ItemIsUserCheckable)
                item_widget.setCheckState(Qt.Checked)  # Default to checked
                self.folder_list.addItem(item_widget)
    
    def on_mode_changed(self):
        """Handle mode change"""
        if self.user_radio.isChecked():
            self.folder_list.setEnabled(True)
        else:
            self.folder_list.setEnabled(False)
    
    def get_selected_folders(self) -> Set[str]:
        """Get set of selected resource folder names"""
        if self.all_radio.isChecked():
            # Return all resource folders
            folders = set()
            for i in range(self.folder_list.count()):
                item = self.folder_list.item(i)
                folders.add(item.text())
            return folders
        elif self.none_radio.isChecked():
            return set()
        else:  # user specified
            folders = set()
            for i in range(self.folder_list.count()):
                item = self.folder_list.item(i)
                if item.checkState() == Qt.Checked:
                    folders.add(item.text())
            return folders

