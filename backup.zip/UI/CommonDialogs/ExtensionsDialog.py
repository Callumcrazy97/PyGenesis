"""
Extensions Manager Dialog for PyGenesis IDE
Installed (Core/Optional/Other) + Store tabs.

This version:
- Uses your existing architecture and threads.
- Integrates with the updated ExtensionsManager (with get_outdated_packages).
- Adds a "Check Updates" button to highlight outdated packages in the Installed tab.
"""

from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QTabWidget, QWidget,
    QTableWidget, QTableWidgetItem, QPushButton, QLabel, QLineEdit,
    QMessageBox, QProgressBar, QCheckBox, QMenu
)
from PySide6.QtCore import Qt, QTimer
from PySide6.QtGui import QContextMenuEvent
from pathlib import Path

from Core.ExtensionsManager import ExtensionsManager
from Core.PackageLoadThread import PackageLoadThread
from Core.PackageSearchThread import PackageSearchThread
from Core.PyPILoadThread import PyPILoadThread
from Core.Debug import debug
import json


class ExtensionsDialog(QDialog):
    """Extensions Manager Dialog with Installed and Store tabs."""

    def __init__(self, app, parent=None):
        super().__init__(parent)
        self.app = app

        try:
            app_dir = getattr(self.app, 'app_dir', None)
            venv_manager = getattr(self.app, 'venv_manager', None)

            if not venv_manager:
                QMessageBox.critical(self, "Error", "VenvManager not available")
                self.reject()
                return

            self.extensions_manager = ExtensionsManager(venv_manager, app_dir)

            # Connect signals from backend manager
            self.extensions_manager.package_installed.connect(self.on_package_installed)
            self.extensions_manager.package_updated.connect(self.on_package_updated)
            self.extensions_manager.package_uninstalled.connect(self.on_package_uninstalled)
            self.extensions_manager.operation_progress.connect(self.on_operation_progress)

            # Thread handles
            self.active_thread = None
            self.load_thread: PackageLoadThread | None = None
            self.search_thread: PackageSearchThread | None = None
            self.pypi_load_thread: PyPILoadThread | None = None

            # Store tab state
            self.store_page = 1
            self.store_page_size = 20
            self.store_search_query = ""
            self.store_total_results = 0
            self.store_all_items = []

            # Cached data
            self.cached_installed_libs = []

            # Outdated packages cache (for UI view)
            # dict: lower_name -> {"name", "current_version", "latest_version"}
            self.outdated_packages = {}

            # Optional cached lists (used in your handlers)
            self.cached_core_libs = []
            self.cached_optional_libs = []

            self.setup_ui()

            # Load data asynchronously after UI is shown
            QTimer.singleShot(100, self.load_data_async)

            self.setWindowTitle("Extensions Manager")
            self.setMinimumSize(900, 650)
            self.resize(1100, 750)

        except Exception as e:
            QMessageBox.critical(None, "Error", f"Failed to initialize Extensions Manager: {str(e)}")
            debug(f"ExtensionsDialog initialization error: {e}")
            import traceback
            debug(traceback.format_exc())
            self.reject()

    # -------------------------------------------------------------------------
    # UI setup
    # -------------------------------------------------------------------------

    def setup_ui(self):
        """Setup the UI with two main tabs + status bar."""
        layout = QVBoxLayout(self)

        # Tab widget
        self.tabs = QTabWidget()
        self.tabs.currentChanged.connect(self.on_tab_changed)

        # Installed tab
        self.installed_tab = self.create_installed_tab()
        self.tabs.addTab(self.installed_tab, "Installed")

        # Store tab
        self.store_tab = self.create_store_tab()
        self.tabs.addTab(self.store_tab, "Store")

        layout.addWidget(self.tabs)

        # Status bar
        status_layout = QHBoxLayout()
        self.status_label = QLabel("Ready")
        self.progress_bar = QProgressBar()
        self.progress_bar.setVisible(False)
        status_layout.addWidget(self.status_label)
        status_layout.addWidget(self.progress_bar)
        layout.addLayout(status_layout)

        # Close button
        button_layout = QHBoxLayout()
        button_layout.addStretch()
        close_btn = QPushButton("Close")
        close_btn.clicked.connect(self.accept)
        button_layout.addWidget(close_btn)
        layout.addLayout(button_layout)

    def create_installed_tab(self) -> QWidget:
        """Create Installed tab showing all installed packages."""
        widget = QWidget()
        layout = QVBoxLayout(widget)

        # Info label
        info_label = QLabel("All installed packages in your virtual environment:")
        info_label.setWordWrap(True)
        layout.addWidget(info_label)

        # Search bar
        search_layout = QHBoxLayout()
        search_label = QLabel("Search:")
        self.installed_search_input = QLineEdit()
        self.installed_search_input.setPlaceholderText("Filter packages by name...")
        self.installed_search_input.textChanged.connect(self.filter_installed_table)
        clear_installed_btn = QPushButton("Clear")
        clear_installed_btn.clicked.connect(self.clear_installed_search)

        search_layout.addWidget(search_label)
        search_layout.addWidget(self.installed_search_input)
        search_layout.addWidget(clear_installed_btn)
        search_layout.addStretch()
        layout.addLayout(search_layout)

        # Controls row (e.g. Check Updates)
        controls_layout = QHBoxLayout()
        controls_layout.addStretch()

        self.check_updates_btn = QPushButton("Check Updates")
        self.check_updates_btn.setToolTip("Check for outdated packages using pip list --outdated")
        self.check_updates_btn.clicked.connect(self.check_for_updates)
        controls_layout.addWidget(self.check_updates_btn)

        layout.addLayout(controls_layout)

        # Table for installed libraries
        self.installed_table = QTableWidget()
        self.installed_table.setColumnCount(5)
        self.installed_table.setHorizontalHeaderLabels([
            "Package", "Category", "Installed Version", "Latest Version", "Actions"
        ])
        self.installed_table.horizontalHeader().setStretchLastSection(True)
        self.installed_table.setSelectionBehavior(QTableWidget.SelectRows)
        self.installed_table.setEditTriggers(QTableWidget.NoEditTriggers)
        self.installed_table.setContextMenuPolicy(Qt.CustomContextMenu)
        self.installed_table.customContextMenuRequested.connect(self.show_installed_context_menu)
        self.installed_table.itemDoubleClicked.connect(self.on_installed_double_click)
        
        # Enable sorting by clicking headers
        self.installed_table.setSortingEnabled(True)
        self.installed_table.sortItems(0, Qt.AscendingOrder)  # Sort by package name initially
        
        layout.addWidget(self.installed_table)

        return widget

    def create_store_tab(self) -> QWidget:
        """Create Store tab with PyPI integration."""
        widget = QWidget()
        layout = QVBoxLayout(widget)

        # Search bar
        search_layout = QHBoxLayout()
        search_label = QLabel("Search PyPI:")
        self.search_input = QLineEdit()
        self.search_input.setPlaceholderText("Enter package name...")
        self.search_input.returnPressed.connect(self.search_store)
        search_btn = QPushButton("Search")
        search_btn.clicked.connect(self.search_store)
        clear_btn = QPushButton("Clear")
        clear_btn.clicked.connect(self.clear_search)

        # Filter checkbox
        self.show_installed_checkbox = QCheckBox("Show installed packages")
        self.show_installed_checkbox.setChecked(False)
        self.show_installed_checkbox.stateChanged.connect(self.on_filter_changed)

        search_layout.addWidget(search_label)
        search_layout.addWidget(self.search_input)
        search_layout.addWidget(search_btn)
        search_layout.addWidget(clear_btn)
        search_layout.addStretch()
        search_layout.addWidget(self.show_installed_checkbox)
        layout.addLayout(search_layout)

        # Install button (prominent, separate from table actions)
        install_button_layout = QHBoxLayout()
        install_button_layout.addStretch()
        self.store_install_btn = QPushButton("Install Selected")
        self.store_install_btn.setToolTip("Install the selected package from the store")
        self.store_install_btn.clicked.connect(self.install_selected_from_store)
        install_button_layout.addWidget(self.store_install_btn)
        layout.addLayout(install_button_layout)

        # Store table
        self.store_table = QTableWidget()
        self.store_table.setColumnCount(4)
        self.store_table.setHorizontalHeaderLabels([
            "Package", "Version", "Description", "Actions"
        ])
        self.store_table.horizontalHeader().setStretchLastSection(True)
        self.store_table.setSelectionBehavior(QTableWidget.SelectRows)
        self.store_table.setEditTriggers(QTableWidget.NoEditTriggers)
        self.store_table.setContextMenuPolicy(Qt.CustomContextMenu)
        self.store_table.customContextMenuRequested.connect(self.show_store_context_menu)
        self.store_table.itemDoubleClicked.connect(self.on_store_double_click)
        layout.addWidget(self.store_table)

        # Pagination
        pagination_layout = QHBoxLayout()
        self.store_prev_btn = QPushButton("Previous")
        self.store_prev_btn.clicked.connect(lambda: self.change_store_page(-1))
        self.store_page_label = QLabel("Page 1 of 1")
        self.store_next_btn = QPushButton("Next")
        self.store_next_btn.clicked.connect(lambda: self.change_store_page(1))

        pagination_layout.addWidget(self.store_prev_btn)
        pagination_layout.addStretch()
        pagination_layout.addWidget(self.store_page_label)
        pagination_layout.addStretch()
        pagination_layout.addWidget(self.store_next_btn)
        layout.addLayout(pagination_layout)

        return widget

    # -------------------------------------------------------------------------
    # Async data loading
    # -------------------------------------------------------------------------

    def load_data_async(self):
        """Load package data asynchronously in background thread."""
        try:
            self.status_label.setText("Loading package data...")
            self.progress_bar.setVisible(True)
            self.progress_bar.setRange(0, 0)  # Indeterminate

            self.load_thread = PackageLoadThread(self.extensions_manager)
            self.load_thread.installed_libraries_loaded.connect(self.on_installed_libraries_loaded)
            self.load_thread.top_packages_loaded.connect(self.on_top_packages_loaded)
            self.load_thread.loading_finished.connect(self.on_loading_finished)
            self.load_thread.error_occurred.connect(self.on_loading_error)
            self.load_thread.start()

        except Exception as e:
            debug(f"Error starting async load: {e}")
            self.progress_bar.setVisible(False)
            self.status_label.setText("Error loading data")

    def on_installed_libraries_loaded(self, libraries):
        """Handle installed libraries loaded signal."""
        self.cached_installed_libs = libraries
        self.load_installed_libraries()

    def on_top_packages_loaded(self, packages):
        """Handle top packages loaded signal (for default store view)."""
        # Ensure we have at least top 100 packages
        if len(packages) < 100:
            # If we got fewer, try to get more from ExtensionsManager
            packages = self.extensions_manager.get_top_packages(limit=100)
        
        self.store_all_items = packages
        self.store_search_query = ""
        self.store_page = 1
        self.store_total_results = len(packages)

        # Always render if we're on store tab or if this is initial load
        if self.tabs.currentIndex() == 1:  # Store tab
            self.render_store_table()
            self.update_pagination()
        # Also render if this is the initial load (store_all_items was empty)
        elif not hasattr(self, '_store_initialized') or not self._store_initialized:
            self._store_initialized = True
            self.render_store_table()
            self.update_pagination()

    def on_loading_finished(self):
        """Handle loading finished signal."""
        self.progress_bar.setVisible(False)
        self.status_label.setText("Ready")
        debug("Package data loading completed")

    def on_loading_error(self, error_msg: str):
        """Handle loading error signal."""
        self.progress_bar.setVisible(False)
        self.status_label.setText(f"Error: {error_msg}")
        debug(f"Package loading error: {error_msg}")

    # -------------------------------------------------------------------------
    # Installed tab logic
    # -------------------------------------------------------------------------

    def load_installed_libraries(self):
        """Load all installed libraries into the installed table."""
        try:
            if self.cached_installed_libs:
                libraries = self.cached_installed_libs
            else:
                libraries = self.extensions_manager.get_all_installed_libraries()
                self.cached_installed_libs = libraries

            installed_libs = libraries
            # Temporarily disable sorting to populate table
            self.installed_table.setSortingEnabled(False)
            self.installed_table.setRowCount(len(installed_libs))

            for row, lib in enumerate(installed_libs):
                package_name = lib.get("name", "")
                category = lib.get("category", "Other")
                installed_version = lib.get("installed_version", "Unknown")

                # Package name
                name_item = QTableWidgetItem(package_name)
                self.installed_table.setItem(row, 0, name_item)

                # Category
                category_item = QTableWidgetItem(category)
                self.installed_table.setItem(row, 1, category_item)

                # Installed version
                version_item = QTableWidgetItem(installed_version)
                self.installed_table.setItem(row, 2, version_item)

                # Latest version – initially unknown
                latest_item = QTableWidgetItem("Click 'Check Updates' to fetch")
                self.installed_table.setItem(row, 3, latest_item)

                # Actions
                actions_widget = QWidget()
                actions_layout = QHBoxLayout(actions_widget)
                actions_layout.setContentsMargins(2, 2, 2, 2)

                update_btn = QPushButton("Update")
                update_btn.package_name = package_name
                update_btn.setToolTip("Update this package to the latest version (if available)")
                update_btn.clicked.connect(
                    lambda checked, btn=update_btn: self.update_package(btn.package_name)
                )
                actions_layout.addWidget(update_btn)

                uninstall_btn = QPushButton("Uninstall")
                uninstall_btn.package_name = package_name
                uninstall_btn.clicked.connect(
                    lambda checked, btn=uninstall_btn: self.uninstall_package(btn.package_name)
                )
                actions_layout.addWidget(uninstall_btn)

                actions_layout.addStretch()
                self.installed_table.setCellWidget(row, 4, actions_widget)

            # Re-enable sorting
            self.installed_table.setSortingEnabled(True)
            self.installed_table.sortItems(0, Qt.AscendingOrder)  # Sort by package name
            
            self.installed_table.resizeColumnsToContents()
            self.status_label.setText(f"Loaded {len(installed_libs)} installed packages")

            # If we already have outdated info, apply it
            if self.outdated_packages:
                self._apply_outdated_to_installed_table()
            
            # Apply search filter if active
            self.filter_installed_table()

        except Exception as e:
            debug(f"Error loading installed libraries: {e}")
            QMessageBox.warning(self, "Warning", f"Error loading libraries: {str(e)}")

    def check_for_updates(self):
        """
        Trigger a pip-based outdated check and highlight packages that have updates.
        Uses ExtensionsManager.get_outdated_packages().
        """
        if self.active_thread:
            QMessageBox.warning(self, "Busy", "Another operation is in progress")
            return

        self.status_label.setText("Checking for package updates...")
        self.progress_bar.setVisible(True)
        self.progress_bar.setRange(0, 0)

        try:
            outdated = self.extensions_manager.get_outdated_packages(use_cache=False)
            self.outdated_packages = outdated or {}
            self._apply_outdated_to_installed_table()

            count = len(self.outdated_packages)
            self.status_label.setText(f"Found {count} package(s) with updates available")
        except Exception as e:
            debug(f"Error checking for updates: {e}")
            QMessageBox.warning(self, "Error", f"Failed to check for updates: {str(e)}")
            self.status_label.setText("Error checking updates")
        finally:
            self.progress_bar.setVisible(False)

    def _apply_outdated_to_installed_table(self):
        """
        Apply outdated information to the installed table:
        - Fill 'Latest Version' column
        - Highlight rows that need updates with background color
        """
        from PySide6.QtGui import QColor, QBrush
        
        for row in range(self.installed_table.rowCount()):
            name_item = self.installed_table.item(row, 0)
            latest_item = self.installed_table.item(row, 3)
            if not name_item or not latest_item:
                continue

            pkg_name = name_item.text()
            info = self.outdated_packages.get(pkg_name.lower())

            if info:
                latest_version = info.get("latest_version", "Unknown")
                latest_item.setText(latest_version)
                latest_item.setToolTip(f"Current: {info.get('current_version', '')} → Latest: {latest_version}")
                # Highlight the latest version text in red
                latest_item.setForeground(QBrush(QColor(200, 0, 0)))  # Dark red
                
                # Highlight the entire row with a light yellow/orange background
                highlight_color = QColor(255, 248, 220)  # Light yellow/cream
                for col in range(self.installed_table.columnCount()):
                    item = self.installed_table.item(row, col)
                    if item:
                        item.setBackground(QBrush(highlight_color))
            else:
                latest_item.setText("Up to date")
                latest_item.setToolTip("Package is at latest version")
                latest_item.setForeground(QBrush(QColor(0, 150, 0)))  # Green
                
                # Reset background to default (white) for up-to-date packages
                for col in range(self.installed_table.columnCount()):
                    item = self.installed_table.item(row, col)
                    if item:
                        item.setBackground(QBrush(QColor(255, 255, 255)))  # White

    # -------------------------------------------------------------------------
    # Store tab logic
    # -------------------------------------------------------------------------

    def load_store_default(self):
        """Load top packages for Store tab (from PyPI index)."""
        try:
            self.status_label.setText("Loading PyPI package index…")
            self.progress_bar.setVisible(True)
            self.progress_bar.setRange(0, 0)

            if self.pypi_load_thread and self.pypi_load_thread.isRunning():
                return

            self.pypi_load_thread = PyPILoadThread(self.extensions_manager)
            self.pypi_load_thread.pypi_names_loaded.connect(self._on_pypi_names_loaded)
            self.pypi_load_thread.error_occurred.connect(self._on_pypi_load_error)
            self.pypi_load_thread.start()

        except Exception as e:
            self.progress_bar.setVisible(False)
            debug(f"Error loading PyPI index: {e}")
            QMessageBox.warning(self, "Error", f"Failed to load packages: {str(e)}")

    def _on_pypi_names_loaded(self):
        """Handle PyPI names loaded."""
        try:
            packages = self.extensions_manager.get_top_packages(limit=100)
            self.store_all_items = packages
            self.store_search_query = ""
            self.store_page = 1
            self.store_total_results = len(packages)

            self.render_store_table()
            self.update_pagination()

            self.progress_bar.setVisible(False)
            total_packages = len(self.extensions_manager.store_all_packages)
            self.status_label.setText(f"Loaded {total_packages} packages. Showing top 100.")
        except Exception as e:
            self.progress_bar.setVisible(False)
            debug(f"Error after PyPI load: {e}")
            self.status_label.setText(f"Error: {str(e)}")

    def _on_pypi_load_error(self, error_msg: str):
        """Handle PyPI load error."""
        self.progress_bar.setVisible(False)
        self.status_label.setText(f"Error loading PyPI index: {error_msg}")
        QMessageBox.warning(self, "Error", f"Failed to load PyPI package index: {error_msg}")

    def search_store(self):
        """Search PyPI for packages (async, fuzzy)."""
        query = self.search_input.text().strip()
        if not query:
            self.load_store_default()
            return

        if self.search_thread and self.search_thread.isRunning():
            self.search_thread.terminate()
            self.search_thread.wait()

        self.status_label.setText(f"Searching PyPI for '{query}'...")
        self.progress_bar.setVisible(True)
        self.progress_bar.setRange(0, 0)

        self.search_thread = PackageSearchThread(
            self.extensions_manager,
            query,
            page=1,
            page_size=self.store_page_size
        )
        self.search_thread.search_complete.connect(self.on_search_complete)
        self.search_thread.search_error.connect(self.on_search_error)
        self.search_thread.start()

    def on_search_complete(self, results, total: int):
        """Handle search completion."""
        self.store_all_items = results
        self.store_search_query = self.search_input.text().strip()
        self.store_page = 1
        self.store_total_results = total

        self.render_store_table()
        self.update_pagination()

        self.progress_bar.setVisible(False)
        self.status_label.setText(f"Found {total} results for '{self.store_search_query}'")

    def on_search_error(self, error_msg: str):
        """Handle search error."""
        self.progress_bar.setVisible(False)
        self.status_label.setText(f"Search error: {error_msg}")
        QMessageBox.warning(self, "Search Error", f"Failed to search PyPI: {error_msg}")

    def clear_search(self):
        """Clear search and show top packages."""
        self.search_input.clear()
        self.load_store_default()

    def change_store_page(self, direction: int):
        """Change store page."""
        if self.store_search_query:
            total_pages = (self.store_total_results + self.store_page_size - 1) // self.store_page_size if self.store_total_results > 0 else 1
            new_page = max(1, min(self.store_page + direction, total_pages))

            if new_page > total_pages or new_page < 1:
                return

            if new_page != self.store_page:
                self.store_page = new_page

                if self.search_thread and self.search_thread.isRunning():
                    self.search_thread.terminate()
                    self.search_thread.wait()

                self.status_label.setText(f"Loading page {new_page}...")
                self.progress_bar.setVisible(True)
                self.progress_bar.setRange(0, 0)

                self.search_thread = PackageSearchThread(
                    self.extensions_manager,
                    self.store_search_query,
                    page=new_page,
                    page_size=self.store_page_size
                )
                self.search_thread.search_complete.connect(self.on_search_complete)
                self.search_thread.search_error.connect(self.on_search_error)
                self.search_thread.start()
        else:
            filtered = [
                item for item in self.store_all_items
                if self.show_installed_checkbox.isChecked()
                or not self.extensions_manager.check_package_installed(item.get("name", ""))[0]
            ]
            total_pages = (len(filtered) + self.store_page_size - 1) // self.store_page_size if filtered else 1
            new_page = max(1, min(self.store_page + direction, total_pages))

            if new_page != self.store_page:
                self.store_page = new_page
                self.render_store_table()
                self.update_pagination()

    def render_store_table(self):
        """Render store table with current items, applying installed filter + pagination."""
        show_installed = self.show_installed_checkbox.isChecked()

        if show_installed:
            filtered_items = self.store_all_items
        else:
            filtered_items = []
            installed_packages = self.extensions_manager.get_all_installed_packages()
            installed_lower = set(k.lower() for k in installed_packages.keys())
            for item in self.store_all_items:
                package_name = item.get("name", "")
                if package_name and package_name.lower() not in installed_lower:
                    filtered_items.append(item)

        if self.store_search_query:
            page_items = filtered_items
        else:
            start = (self.store_page - 1) * self.store_page_size
            end = start + self.store_page_size
            page_items = filtered_items[start:end]

        self.store_table.setRowCount(len(page_items))

        for row, item in enumerate(page_items):
            package_name = item.get("name", "")
            version = item.get("version", "Unknown")
            description = item.get("description", "")

            name_item = QTableWidgetItem(package_name)
            self.store_table.setItem(row, 0, name_item)

            version_item = QTableWidgetItem(version)
            self.store_table.setItem(row, 1, version_item)

            desc_item = QTableWidgetItem(description)
            self.store_table.setItem(row, 2, desc_item)

            is_installed = self.extensions_manager.check_package_installed(package_name)[0]
            if is_installed:
                install_btn = QPushButton("Installed")
                install_btn.setEnabled(False)
            else:
                install_btn = QPushButton("Install")
                install_btn.package_name = package_name
                install_btn.clicked.connect(
                    lambda checked, btn=install_btn: self.install_package(btn.package_name)
                )
            self.store_table.setCellWidget(row, 3, install_btn)

        self.store_table.resizeColumnsToContents()

    def update_pagination(self):
        """Update pagination label and button states."""
        if self.store_search_query:
            total_pages = (self.store_total_results + self.store_page_size - 1) // self.store_page_size if self.store_total_results > 0 else 1
            self.store_page_label.setText(f"Page {self.store_page} of {total_pages} ({self.store_total_results} total)")
        else:
            show_installed = self.show_installed_checkbox.isChecked()
            if show_installed:
                filtered_count = len(self.store_all_items)
            else:
                installed_packages = self.extensions_manager.get_all_installed_packages()
                installed_lower = set(k.lower() for k in installed_packages.keys())
                filtered_count = sum(
                    1 for item in self.store_all_items
                    if item.get("name", "").lower() not in installed_lower
                )
            total_pages = (filtered_count + self.store_page_size - 1) // self.store_page_size if filtered_count > 0 else 1
            self.store_page_label.setText(f"Page {self.store_page} of {total_pages} ({filtered_count} packages)")

        try:
            text = self.store_page_label.text()
            if " of " in text:
                total_pages = int(text.split(" of ")[1].split(" ")[0])
            else:
                total_pages = 1
        except Exception:
            total_pages = 1

        self.store_prev_btn.setEnabled(self.store_page > 1)
        self.store_next_btn.setEnabled(self.store_page < total_pages)

    # -------------------------------------------------------------------------
    # Package operations: install/update/uninstall
    # -------------------------------------------------------------------------

    def install_package(self, package_name: str):
        """Install a package."""
        if self.active_thread:
            QMessageBox.warning(self, "Busy", "Another operation is in progress")
            return

        reply = QMessageBox.question(
            self, "Install Package",
            f"Install {package_name}?",
            QMessageBox.Yes | QMessageBox.No
        )

        if reply == QMessageBox.Yes:
            self.progress_bar.setVisible(True)
            self.progress_bar.setRange(0, 0)
            self.status_label.setText(f"Installing {package_name}...")

            self.active_thread = self.extensions_manager.install_package(package_name)
            self.active_thread.start()

    def update_package(self, package_name: str):
        """Update a package."""
        if self.active_thread:
            QMessageBox.warning(self, "Busy", "Another operation is in progress")
            return

        reply = QMessageBox.question(
            self, "Update Package",
            f"Update {package_name} to latest version?",
            QMessageBox.Yes | QMessageBox.No
        )

        if reply == QMessageBox.Yes:
            self.progress_bar.setVisible(True)
            self.progress_bar.setRange(0, 0)
            self.status_label.setText(f"Updating {package_name}...")

            self.active_thread = self.extensions_manager.update_package(package_name)
            self.active_thread.start()

    def uninstall_package(self, package_name: str):
        """Uninstall a package."""
        if self.active_thread:
            QMessageBox.warning(self, "Busy", "Another operation is in progress")
            return

        reply = QMessageBox.warning(
            self, "Uninstall Package",
            f"Uninstall {package_name}? This cannot be undone.",
            QMessageBox.Yes | QMessageBox.No
        )

        if reply == QMessageBox.Yes:
            self.progress_bar.setVisible(True)
            self.progress_bar.setRange(0, 0)
            self.status_label.setText(f"Uninstalling {package_name}...")

            self.active_thread = self.extensions_manager.uninstall_package(package_name)
            self.active_thread.start()

    # -------------------------------------------------------------------------
    # Signal handlers from backend / threads
    # -------------------------------------------------------------------------

    def on_operation_progress(self, message: str):
        """Handle operation progress updates."""
        self.status_label.setText(message)
        if message.startswith("ERROR:"):
            self.active_thread = None
            self.progress_bar.setVisible(False)
            QMessageBox.critical(self, "Operation Failed", message)

    def on_package_installed(self, package_name: str):
        """Handle package installation completion."""
        self.active_thread = None
        self.progress_bar.setVisible(False)
        self.status_label.setText(f"Successfully installed {package_name}")

        # Clear caches and reload
        self.cached_core_libs = []
        self.cached_optional_libs = []
        self.cached_installed_libs = []
        self.outdated_packages = {}
        self.load_data_async()

        if self.tabs.currentIndex() == 1:
            self.render_store_table()

    def on_package_updated(self, package_name: str):
        """Handle package update completion."""
        self.active_thread = None
        self.progress_bar.setVisible(False)
        self.status_label.setText(f"Successfully updated {package_name}")

        self.cached_core_libs = []
        self.cached_optional_libs = []
        self.cached_installed_libs = []
        self.outdated_packages = {}
        self.load_data_async()

    def on_package_uninstalled(self, package_name: str):
        """Handle package uninstallation completion."""
        self.active_thread = None
        self.progress_bar.setVisible(False)
        self.status_label.setText(f"Successfully uninstalled {package_name}")

        self.cached_core_libs = []
        self.cached_optional_libs = []
        self.cached_installed_libs = []
        self.outdated_packages = {}
        self.load_data_async()

        if self.tabs.currentIndex() == 1:
            self.render_store_table()

    # -------------------------------------------------------------------------
    # Filters
    # -------------------------------------------------------------------------

    def on_filter_changed(self):
        """Handle filter checkbox change."""
        self.render_store_table()
        self.update_pagination()

    # -------------------------------------------------------------------------
    # Installed tab filtering
    # -------------------------------------------------------------------------

    def filter_installed_table(self):
        """Filter the installed table based on search input."""
        search_text = self.installed_search_input.text().strip().lower()
        
        if not search_text:
            # Show all rows
            for row in range(self.installed_table.rowCount()):
                self.installed_table.setRowHidden(row, False)
            return
        
        # Filter rows based on search text
        for row in range(self.installed_table.rowCount()):
            name_item = self.installed_table.item(row, 0)
            category_item = self.installed_table.item(row, 1)
            
            if name_item and category_item:
                package_name = name_item.text().lower()
                category = category_item.text().lower()
                
                # Show row if search text matches package name or category
                if search_text in package_name or search_text in category:
                    self.installed_table.setRowHidden(row, False)
                else:
                    self.installed_table.setRowHidden(row, True)
            else:
                self.installed_table.setRowHidden(row, True)

    def clear_installed_search(self):
        """Clear the installed search input and show all packages."""
        self.installed_search_input.clear()
        self.filter_installed_table()

    # -------------------------------------------------------------------------
    # Tab change handler
    # -------------------------------------------------------------------------

    def on_tab_changed(self, index: int):
        """Handle tab change - load store default when switching to store tab."""
        if index == 1:  # Store tab
            if not self.store_all_items and not self.pypi_load_thread:
                # Only load if we don't have data yet and no thread is running
                self.load_store_default()

    # -------------------------------------------------------------------------
    # Double-click handlers
    # -------------------------------------------------------------------------

    def on_installed_double_click(self, item: QTableWidgetItem):
        """Handle double-click on installed table - show package info or update."""
        row = item.row()
        name_item = self.installed_table.item(row, 0)
        if name_item:
            package_name = name_item.text()
            # Check if package has updates available
            if package_name.lower() in self.outdated_packages:
                self.update_package(package_name)
            else:
                # Just show info or do nothing
                pass

    def on_store_double_click(self, item: QTableWidgetItem):
        """Handle double-click on store table - install the package."""
        row = item.row()
        name_item = self.store_table.item(row, 0)
        if name_item:
            package_name = name_item.text()
            # Check if already installed
            is_installed = self.extensions_manager.check_package_installed(package_name)[0]
            if not is_installed:
                self.install_package(package_name)

    # -------------------------------------------------------------------------
    # Context menu handlers
    # -------------------------------------------------------------------------

    def show_installed_context_menu(self, position):
        """Show context menu for installed table."""
        item = self.installed_table.itemAt(position)
        if not item:
            return

        row = item.row()
        name_item = self.installed_table.item(row, 0)
        if not name_item:
            return

        package_name = name_item.text()
        is_core = self._is_core_package(package_name)
        has_update = package_name.lower() in self.outdated_packages

        menu = QMenu(self)
        
        if has_update:
            update_action = menu.addAction("Update")
            update_action.triggered.connect(lambda: self.update_package(package_name))
            menu.addSeparator()

        if not is_core:
            uninstall_action = menu.addAction("Uninstall")
            uninstall_action.triggered.connect(lambda: self.uninstall_package(package_name))
            menu.addSeparator()

        info_action = menu.addAction("Show Info")
        info_action.triggered.connect(lambda: self.show_package_info(package_name))

        menu.exec_(self.installed_table.viewport().mapToGlobal(position))

    def show_store_context_menu(self, position):
        """Show context menu for store table."""
        item = self.store_table.itemAt(position)
        if not item:
            return

        row = item.row()
        name_item = self.store_table.item(row, 0)
        if not name_item:
            return

        package_name = name_item.text()
        is_installed = self.extensions_manager.check_package_installed(package_name)[0]

        menu = QMenu(self)

        if is_installed:
            update_action = menu.addAction("Update")
            update_action.triggered.connect(lambda: self.update_package(package_name))
            menu.addSeparator()
            uninstall_action = menu.addAction("Uninstall")
            uninstall_action.triggered.connect(lambda: self.uninstall_package(package_name))
            menu.addSeparator()
        else:
            install_action = menu.addAction("Install")
            install_action.triggered.connect(lambda: self.install_package(package_name))
            menu.addSeparator()

        info_action = menu.addAction("Show Info")
        info_action.triggered.connect(lambda: self.show_package_info(package_name))

        menu.exec_(self.store_table.viewport().mapToGlobal(position))

    def install_selected_from_store(self):
        """Install the currently selected package from the store table."""
        selected_items = self.store_table.selectedItems()
        if not selected_items:
            QMessageBox.information(self, "No Selection", "Please select a package to install.")
            return

        # Get the package name from the first column of the selected row
        row = selected_items[0].row()
        name_item = self.store_table.item(row, 0)
        if name_item:
            package_name = name_item.text()
            is_installed = self.extensions_manager.check_package_installed(package_name)[0]
            if is_installed:
                QMessageBox.information(self, "Already Installed", f"{package_name} is already installed.")
            else:
                self.install_package(package_name)

    def _is_core_package(self, package_name: str) -> bool:
        """Check if a package is a core package (cannot be uninstalled)."""
        try:
            app_dir = getattr(self.app, 'app_dir', None)
            if not app_dir:
                app_dir = Path(__file__).parent.parent
            core_file = Path(app_dir) / "Config" / "CoreRequirements.json"
            if core_file.exists():
                with open(core_file, 'r') as f:
                    core_data = json.load(f)
                    libraries = core_data.get("libraries", [])
                    for lib in libraries:
                        if lib.get("name", "").lower() == package_name.lower():
                            return True
        except Exception:
            pass
        return False

    def show_package_info(self, package_name: str):
        """Show package information dialog."""
        try:
            info = self.extensions_manager.get_package_info(package_name)
            if info:
                description = info.get("description", "No description available")
                version = info.get("version", "Unknown")
                homepage = info.get("homepage", "")
                
                msg = f"<b>{package_name}</b><br><br>"
                msg += f"<b>Version:</b> {version}<br><br>"
                msg += f"<b>Description:</b><br>{description}<br>"
                if homepage:
                    msg += f"<br><b>Homepage:</b> <a href='{homepage}'>{homepage}</a>"
                
                QMessageBox.information(self, f"Package Info: {package_name}", msg)
            else:
                QMessageBox.warning(self, "Package Info", f"Could not retrieve information for {package_name}")
        except Exception as e:
            debug(f"Error showing package info: {e}")
            QMessageBox.warning(self, "Error", f"Failed to get package info: {str(e)}")
