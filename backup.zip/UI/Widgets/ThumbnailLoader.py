"""
Background Thumbnail Loader for Resource Tree
Loads thumbnails asynchronously to avoid blocking project loading.
OPTIMIZED: Uses thumbnail cache to avoid regenerating thumbnails.
"""

from PySide6.QtCore import QThread, Signal, QMutex, QMutexLocker
from PySide6.QtGui import QPixmap, QIcon, QImage
from PySide6.QtCore import QSize, Qt
import os
import json
from pathlib import Path
from Core.Debug import debug
from Core.ThumbnailCache import ThumbnailCache


class ThumbnailLoader(QThread):
    """Background thread for loading resource thumbnails"""
    
    # Signal emitted when a thumbnail is ready: (resource_type, resource_id, icon)
    thumbnail_ready = Signal(str, str, object)  # resource_type, resource_id, QIcon
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self._mutex = QMutex()
        self._pending_resources = []  # List of (resource_type, resource_id, resource_data, project_path)
        self._stop_requested = False
        self._thumbnail_cache = None  # Will be initialized when project_path is known
        
    def add_resource(self, resource_type, resource_id, resource_data, project_path):
        """Add a resource to the thumbnail loading queue"""
        with QMutexLocker(self._mutex):
            self._pending_resources.append((resource_type, resource_id, resource_data, project_path))
    
    def stop(self):
        """Request the thread to stop"""
        with QMutexLocker(self._mutex):
            self._stop_requested = True
    
    def run(self):
        """Main thread execution - load thumbnails"""
        debug("ThumbnailLoader thread started")
        processed_count = 0
        
        # Process all items in the queue
        while True:
            # Get next resource to process
            resource_to_process = None
            with QMutexLocker(self._mutex):
                if self._stop_requested:
                    debug(f"ThumbnailLoader: Stop requested, processed {processed_count} thumbnails")
                    break
                if self._pending_resources:
                    resource_to_process = self._pending_resources.pop(0)
                else:
                    # No more work, exit
                    debug(f"ThumbnailLoader: No more pending resources, processed {processed_count} thumbnails, exiting")
                    break
            
            if not resource_to_process:
                break
                
            resource_type, resource_id, resource_data, project_path = resource_to_process
            
            # Initialize cache if needed
            if not self._thumbnail_cache and project_path:
                self._thumbnail_cache = ThumbnailCache(project_path)
            
            # Load thumbnail (outside mutex lock)
            try:
                debug(f"Loading thumbnail for {resource_type}/{resource_id}")
                
                # Try cache first
                image_path = self._get_image_path_for_cache(resource_type, resource_data, project_path)
                cached_icon = None
                if image_path and self._thumbnail_cache:
                    cached_icon = self._thumbnail_cache.get_thumbnail(resource_type, resource_id, image_path)
                
                if cached_icon:
                    debug(f"Thumbnail loaded from cache for {resource_type}/{resource_id}")
                    self.thumbnail_ready.emit(resource_type, resource_id, cached_icon)
                    processed_count += 1
                else:
                    # Generate thumbnail
                    icon = self._load_thumbnail(resource_type, resource_data, project_path)
                    if icon:
                        # Save to cache
                        if image_path and self._thumbnail_cache:
                            self._thumbnail_cache.save_thumbnail(resource_type, resource_id, image_path, icon)
                        
                        debug(f"Thumbnail loaded successfully for {resource_type}/{resource_id}, emitting signal")
                        self.thumbnail_ready.emit(resource_type, resource_id, icon)
                        processed_count += 1
                    else:
                        debug(f"No thumbnail found for {resource_type}/{resource_id}")
            except Exception as e:
                debug(f"Error loading thumbnail for {resource_type}/{resource_id}: {e}")
                import traceback
                debug(traceback.format_exc())
            
            # Small delay to prevent overwhelming the UI thread with signals
            self.msleep(10)
        
        debug("ThumbnailLoader thread finished")
    
    def _load_thumbnail(self, resource_type, resource_data, project_path):
        """Load thumbnail for a resource (same logic as ResourceTree._get_sprite_thumbnail)"""
        try:
            # Only load thumbnails for sprites, textures, objects, and backgrounds
            if resource_type not in ["sprites", "textures", "objects", "backgrounds"]:
                return None
            
            # Get resource file path
            resource_file = self._get_resource_file_path(resource_data, resource_type, project_path)
            if not resource_file or not os.path.exists(resource_file):
                return None
            
            # Load the resource data
            with open(resource_file, 'r', encoding='utf-8') as f:
                resource_json = json.load(f)
            
            # For backgrounds, check frames array (same as sprites/textures)
            if resource_type == "backgrounds":
                frames = resource_json.get("frames", [])
                if not frames:
                    return None
                
                # Get the first frame/image
                first_frame = frames[0]
                if isinstance(first_frame, dict):
                    image_path = first_frame.get("path") or first_frame.get("file")
                else:
                    image_path = first_frame
                
                if not image_path:
                    return None
            # For objects, check if they have a sprite assigned
            elif resource_type == "objects":
                sprite_name = resource_json.get("sprite", "")
                if not sprite_name:
                    return None
                
                # Find the sprite in runtime resources
                # We need to get the app to access runtime resources
                # For now, try to load sprite file directly
                sprite_parent_folder = resource_data.get("parent_folder", "")
                sprite_base_path = os.path.join(project_path, "Resources", "Sprites")
                if sprite_parent_folder:
                    sprite_base_path = os.path.join(sprite_base_path, sprite_parent_folder)
                
                # Try to find sprite file
                sprite_file = os.path.join(sprite_base_path, f"{sprite_name}.sprite")
                if not os.path.exists(sprite_file):
                    # Try without parent folder
                    sprite_file = os.path.join(project_path, "Resources", "Sprites", f"{sprite_name}.sprite")
                
                if os.path.exists(sprite_file):
                    with open(sprite_file, 'r', encoding='utf-8') as f:
                        sprite_data = json.load(f)
                    
                    frames = sprite_data.get("frames", [])
                    if frames:
                        first_frame = frames[0]
                        if isinstance(first_frame, dict):
                            image_path = first_frame.get("file") or first_frame.get("path")
                        else:
                            image_path = first_frame
                        
                        if image_path:
                            # Resolve sprite image path
                            sprite_parent = sprite_data.get("parent_folder", "")
                            sprite_img_base = os.path.join(project_path, "Resources", "Sprites")
                            if sprite_parent:
                                sprite_img_base = os.path.join(sprite_img_base, sprite_parent)
                            
                            image_path = os.path.join(sprite_img_base, image_path)
                            if not os.path.exists(image_path):
                                # Try without parent folder
                                image_path = os.path.join(project_path, "Resources", "Sprites", os.path.basename(image_path))
                        else:
                            return None
                    else:
                        return None
                else:
                    return None
            else:
                # For sprites and textures, check if resource has frames/images
                frames = resource_json.get("frames", [])
                if not frames:
                    return None
                
                # Get the first frame/image
                first_frame = frames[0]
                if isinstance(first_frame, dict):
                    image_path = first_frame.get("path") or first_frame.get("file")
                else:
                    image_path = first_frame
                
                if not image_path:
                    return None
            
            # Resolve the image path
            parent_folder = resource_data.get("parent_folder", "")
            resource_folder_map = {
                "sprites": "Sprites",
                "textures": "Textures",
                "objects": "Objects",
                "backgrounds": "Backgrounds",
                "sounds": "Sounds",
                "models": "Models",
                "rooms": "Rooms"
            }
            
            resource_folder = resource_folder_map.get(resource_type, "Sprites")
            base_path = os.path.join(project_path, "Resources", resource_folder)
            
            if parent_folder:
                base_path = os.path.join(base_path, parent_folder)
            
            # Try different path resolution strategies
            image_full_path = None
            
            # Strategy 1: If image_path is already absolute and exists
            if os.path.isabs(image_path) and os.path.exists(image_path):
                image_full_path = image_path
            
            # Strategy 2: Try relative to base_path
            if not image_full_path:
                test_path = os.path.join(base_path, image_path)
                if os.path.exists(test_path):
                    image_full_path = test_path
            
            # Strategy 3: Try with just the filename (basename)
            if not image_full_path:
                image_filename = os.path.basename(image_path)
                test_path = os.path.join(base_path, image_filename)
                if os.path.exists(test_path):
                    image_full_path = test_path
            
            # Strategy 4: Try relative to project_path (legacy support)
            if not image_full_path:
                test_path = os.path.join(project_path, image_path)
                if os.path.exists(test_path):
                    image_full_path = test_path
            
            if not image_full_path or not os.path.exists(image_full_path):
                return None
            
            # Load and resize the image for thumbnail
            image = QImage(image_full_path)
            if image.isNull():
                debug(f"Failed to load image: {image_full_path}")
                return None
            
            # Create a small thumbnail (24x24 pixels for better visibility)
            thumbnail = image.scaled(QSize(24, 24), Qt.KeepAspectRatio, Qt.SmoothTransformation)
            
            # Convert QImage to QPixmap for QIcon
            pixmap = QPixmap.fromImage(thumbnail)
            
            if pixmap.isNull():
                debug(f"Failed to create pixmap from thumbnail")
                return None
            
            # Convert to QIcon
            icon = QIcon(pixmap)
            
            # Verify icon is valid
            if icon.isNull():
                debug(f"Failed to create icon from pixmap")
                return None
            
            debug(f"Successfully created icon from {image_full_path}, size: {pixmap.size()}")
            return icon
            
        except Exception as e:
            debug(f"Error in _load_thumbnail: {e}")
            return None
    
    def _get_image_path_for_cache(self, resource_type, resource_data, project_path):
        """Get the image path for a resource (for cache lookup) - extracts path without loading full thumbnail"""
        try:
            # Only get paths for resources that have thumbnails
            if resource_type not in ["sprites", "textures", "objects", "backgrounds"]:
                return None
            
            # Get resource file path
            resource_file = self._get_resource_file_path(resource_data, resource_type, project_path)
            if not resource_file or not os.path.exists(resource_file):
                return None
            
            # Load the resource data to get image path
            with open(resource_file, 'r', encoding='utf-8') as f:
                resource_json = json.load(f)
            
            image_path = None
            
            # For backgrounds, check frames array (same as sprites/textures)
            if resource_type == "backgrounds":
                frames = resource_json.get("frames", [])
                if frames:
                    first_frame = frames[0]
                    if isinstance(first_frame, dict):
                        image_path = first_frame.get("path") or first_frame.get("file")
                    else:
                        image_path = first_frame
            
            # For objects, check if they have a sprite assigned
            elif resource_type == "objects":
                sprite_name = resource_json.get("sprite", "")
                if not sprite_name:
                    return None
                
                # Find sprite file - try to get from runtime resources first
                sprite_file = None
                
                # Try to find sprite in runtime resources (if available)
                # This is a fallback - we'll try file system first
                sprite_parent_folder = resource_data.get("parent_folder", "")
                sprite_base_path = os.path.join(project_path, "Resources", "Sprites")
                if sprite_parent_folder:
                    sprite_base_path = os.path.join(sprite_base_path, sprite_parent_folder)
                
                sprite_file = os.path.join(sprite_base_path, f"{sprite_name}.sprite")
                if not os.path.exists(sprite_file):
                    sprite_file = os.path.join(project_path, "Resources", "Sprites", f"{sprite_name}.sprite")
                
                if os.path.exists(sprite_file):
                    with open(sprite_file, 'r', encoding='utf-8') as f:
                        sprite_data = json.load(f)
                    
                    frames = sprite_data.get("frames", [])
                    if frames:
                        first_frame = frames[0]
                        if isinstance(first_frame, dict):
                            image_path = first_frame.get("file") or first_frame.get("path")
                        else:
                            image_path = first_frame
                        
                        if image_path:
                            # Resolve sprite image path using sprite's parent folder
                            sprite_parent = sprite_data.get("parent_folder", "")
                            sprite_img_base = os.path.join(project_path, "Resources", "Sprites")
                            if sprite_parent:
                                sprite_img_base = os.path.join(sprite_img_base, sprite_parent)
                            
                            # Try different path resolution strategies for sprite image
                            image_full_path = None
                            
                            # Strategy 1: Try relative to sprite's base path
                            test_path = os.path.join(sprite_img_base, image_path)
                            if os.path.exists(test_path):
                                image_full_path = test_path
                            
                            # Strategy 2: Try with just filename
                            if not image_full_path:
                                image_filename = os.path.basename(image_path)
                                test_path = os.path.join(sprite_img_base, image_filename)
                                if os.path.exists(test_path):
                                    image_full_path = test_path
                            
                            # Strategy 3: Try without sprite parent folder
                            if not image_full_path:
                                test_path = os.path.join(project_path, "Resources", "Sprites", image_path)
                                if os.path.exists(test_path):
                                    image_full_path = test_path
                            
                            # Strategy 4: Try with just filename in Sprites root
                            if not image_full_path:
                                image_filename = os.path.basename(image_path)
                                test_path = os.path.join(project_path, "Resources", "Sprites", image_filename)
                                if os.path.exists(test_path):
                                    image_full_path = test_path
                            
                            # Return the resolved path (already full path, no need for further resolution)
                            return image_full_path if image_full_path and os.path.exists(image_full_path) else None
                
                return None
            
            # For sprites, textures, and backgrounds, get first frame
            else:
                frames = resource_json.get("frames", [])
                if frames:
                    first_frame = frames[0]
                    if isinstance(first_frame, dict):
                        image_path = first_frame.get("path") or first_frame.get("file")
                    else:
                        image_path = first_frame
                else:
                    return None
            
            if not image_path:
                return None
            
            # Resolve the image path (same logic as _load_thumbnail)
            parent_folder = resource_data.get("parent_folder", "")
            resource_folder_map = {
                "sprites": "Sprites",
                "textures": "Textures",
                "backgrounds": "Backgrounds",
            }
            
            resource_folder = resource_folder_map.get(resource_type, "Sprites")
            base_path = os.path.join(project_path, "Resources", resource_folder)
            
            if parent_folder:
                base_path = os.path.join(base_path, parent_folder)
            
            # Try different path resolution strategies
            image_full_path = None
            
            # Strategy 1: If image_path is already absolute and exists
            if os.path.isabs(image_path) and os.path.exists(image_path):
                image_full_path = image_path
            
            # Strategy 2: Try relative to base_path
            if not image_full_path:
                test_path = os.path.join(base_path, image_path)
                if os.path.exists(test_path):
                    image_full_path = test_path
            
            # Strategy 3: Try with just the filename (basename)
            if not image_full_path:
                image_filename = os.path.basename(image_path)
                test_path = os.path.join(base_path, image_filename)
                if os.path.exists(test_path):
                    image_full_path = test_path
            
            # Strategy 4: Try relative to project_path (legacy support)
            if not image_full_path:
                test_path = os.path.join(project_path, image_path)
                if os.path.exists(test_path):
                    image_full_path = test_path
            
            return image_full_path if image_full_path and os.path.exists(image_full_path) else None
            
        except Exception as e:
            debug(f"Error in _get_image_path_for_cache: {e}")
            return None
    
    def _get_resource_file_path(self, resource, resource_type, project_path):
        """Get the actual file path for a resource"""
        if not resource or not project_path:
            return None
        
        resource_folder_map = {
            "sprites": "Sprites",
            "backgrounds": "Backgrounds",
            "textures": "Textures",
            "objects": "Objects",
            "sounds": "Sounds",
            "models": "Models",
            "rooms": "Rooms"
        }
        
        resource_folder = resource_folder_map.get(resource_type, "Sprites")
        parent_folder = resource.get("parent_folder", "")
        
        # Build the file path
        base_path = os.path.join(project_path, "Resources", resource_folder)
        if parent_folder:
            base_path = os.path.join(base_path, parent_folder)
        
        resource_name = resource.get("name", "Unknown")
        resource_id = resource.get("id", "")
        
        # Try different file extensions
        file_extensions = [".sprite", ".background", ".texture", ".object", ".sound", ".model", ".room"]
        for ext in file_extensions:
            file_path = os.path.join(base_path, f"{resource_name}{ext}")
            if os.path.exists(file_path):
                return file_path
        
        # Fallback: try with resource_id
        if resource_id:
            for ext in file_extensions:
                file_path = os.path.join(base_path, f"{resource_id}{ext}")
                if os.path.exists(file_path):
                    return file_path
        
        return None

