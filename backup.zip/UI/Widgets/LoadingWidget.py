"""
Loading Widget for Editor Initialization
Shows a loading indicator while editors are being initialized
"""
from PySide6.QtWidgets import QWidget, QVBoxLayout, QLabel
from PySide6.QtCore import Qt, QTimer
from PySide6.QtGui import QFont


class LoadingWidget(QWidget):
    """Simple loading indicator widget"""
    
    def __init__(self, message="Loading editor..."):
        super().__init__()
        self.message = message
        self.setup_ui()
        self._animation_timer = None
        self._dots = 0
    
    def setup_ui(self):
        """Setup the loading UI"""
        layout = QVBoxLayout(self)
        layout.setAlignment(Qt.AlignCenter)
        
        # Loading message
        self.label = QLabel(self.message)
        font = QFont()
        font.setPointSize(12)
        self.label.setFont(font)
        self.label.setAlignment(Qt.AlignCenter)
        layout.addWidget(self.label)
        
        # Style
        self.setStyleSheet("""
            QLabel {
                color: #888888;
                background: transparent;
            }
        """)
    
    def showEvent(self, event):
        """Start animation when shown"""
        super().showEvent(event)
        self.start_animation()
    
    def hideEvent(self, event):
        """Stop animation when hidden"""
        super().hideEvent(event)
        self.stop_animation()
    
    def start_animation(self):
        """Start the loading animation"""
        if self._animation_timer is None:
            self._animation_timer = QTimer()
            self._animation_timer.timeout.connect(self.update_dots)
            self._animation_timer.start(500)  # Update every 500ms
    
    def stop_animation(self):
        """Stop the loading animation"""
        if self._animation_timer:
            self._animation_timer.stop()
            self._animation_timer = None
    
    def update_dots(self):
        """Update the loading dots animation"""
        self._dots = (self._dots + 1) % 4
        dots_str = "." * self._dots
        self.label.setText(f"{self.message}{dots_str}")
    
    def set_message(self, message):
        """Update the loading message"""
        self.message = message
        dots_str = "." * self._dots
        self.label.setText(f"{self.message}{dots_str}")

