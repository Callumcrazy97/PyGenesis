"""
Resource Tree Widget for Python Game IDE
Displays project resources in a tree structure with drag and drop support
"""

from PySide6.QtWidgets import (QTreeWidget, QTreeWidgetItem, QMenu, QMessageBox, 
                               QInputDialog, QFileDialog, QHeaderView)
from PySide6.QtCore import Qt, Signal, QMimeData, QByteArray
from PySide6.QtGui import QDrag, QPixmap, QPainter, QColor, QFont, QIcon

from PySide6.QtGui import QIcon, QPixmap
from PySide6.QtCore import Qt
from pathlib import Path

import os
import json
from UI.Widgets.ThumbnailLoader import ThumbnailLoader

class ResourceTree(QTreeWidget):
    # Signals
    resource_selected = Signal(str, str)  # resource_type, resource_id
    resource_double_clicked = Signal(str, str)  # resource_type, resource_id
    
    def __init__(self, app, parent=None):
        super().__init__(parent)
        self.app = app
        self._current_editor = None
        self.setup_ui()
        self.setup_connections()
        self.setup_drag_drop()
        
        # Resource type icons (using emojis as requested)
        self.resource_icons = {
            "sprites": "🖼️",
            "backgrounds": "🎨",
            "objects": "📦",
            "sounds": "🔊",
            "models": "🎭",
            "rooms": "🏠",
            "textures": "🖼️",  # Use texture emoji
            "shaders": "✨",  # Sparkles for shaders
            "particles": "💫",  # Dizzy for particles
            "scripts": "📜"  # Scroll for scripts
        }
        
        # Initialize clipboard manager
        from Core.UtilityOperations import ClipboardManager
        self.clipboard_manager = ClipboardManager()
        
        # Initialize background thumbnail loader
        self.thumbnail_loader = ThumbnailLoader(self)
        self.thumbnail_loader.thumbnail_ready.connect(self.on_thumbnail_ready)
        self.thumbnail_items = {}  # Map of (resource_type, resource_id) -> QTreeWidgetItem
    
        # Listen for editor sprite changes
        self._setup_editor_listeners()
    
    def setup_ui(self):
        """Setup the resource tree UI"""
        # Set up columns first
        self.setColumnCount(1)
        
        # Hide header completely since QDockWidget already has title
        self.setHeaderHidden(True)
        header = self.header()
        if header:
            header.hide()
            # Ensure header is not visible
            header.setVisible(False)
        
        self.setRootIsDecorated(True)
        self.setAlternatingRowColors(True)
        self.setDragDropMode(QTreeWidget.InternalMove)
        self.setSelectionMode(QTreeWidget.ExtendedSelection)
        
        # Set header to stretch
        if header:
            header.setStretchLastSection(True)
        
        # Context menu
        self.setContextMenuPolicy(Qt.CustomContextMenu)
        self.customContextMenuRequested.connect(self.show_context_menu)
    
    def setup_connections(self):
        """Setup signal connections"""
        self.itemSelectionChanged.connect(self.on_selection_changed)
        self.itemDoubleClicked.connect(self.on_item_double_clicked)
        
        # Connect to resource manager signals
        self.app.resource_manager.resource_updated.connect(self.on_resource_updated)
        self.app.resource_manager.resource_created.connect(self.on_resource_created)
        self.app.resource_manager.resource_deleted.connect(self.on_resource_deleted)
    
    def setup_drag_drop(self):
        """Setup drag and drop functionality"""
        self.setDragEnabled(True)
        self.setDropIndicatorShown(True)
        self.setAcceptDrops(True)
    
    def keyPressEvent(self, event):
        """Handle keyboard events"""
        if event.key() == Qt.Key_Delete:
            # Get selected items
            selected_items = self.selectedItems()
            if not selected_items:
                return
            
            # Check if we have resources or folders
            has_resources = any(
                item.data(0, Qt.UserRole) and 
                item.data(0, Qt.UserRole).get("type") == "resource" 
                for item in selected_items
            )
            has_folders = any(
                item.data(0, Qt.UserRole) and 
                item.data(0, Qt.UserRole).get("type") == "folder" 
                for item in selected_items
            )
            
            # Delete based on what's selected
            if has_resources:
                self.delete_resource()
            if has_folders:
                self.delete_folder()
        
        super().keyPressEvent(event)
    
    def refresh(self):
        """Refresh the resource tree"""
        self.clear()
        
        if not self.app.project_manager.get_project_path():
            return
        
        # Stop any existing thumbnail loading
        if self.thumbnail_loader.isRunning():
            from Core.Debug import debug
            debug("Stopping existing thumbnail loader thread")
            self.thumbnail_loader.stop()
            self.thumbnail_loader.wait(1000)  # Wait up to 1 second
        
        # Clear thumbnail items cache
        self.thumbnail_items = {}
        
        # Create a new thumbnail loader instance to avoid issues with stopped thread
        self.thumbnail_loader = ThumbnailLoader(self)
        self.thumbnail_loader.thumbnail_ready.connect(self.on_thumbnail_ready)
        
        # Clean up project data by removing references to non-existent resources
        # Note: Don't auto-save here - only save when user explicitly saves
        # self.cleanup_project_data()
        
        # Create root items for each resource type
        self.resource_items = {}
        
        project_path = self.app.project_manager.get_project_path()
        
        for resource_type in ["sprites", "backgrounds", "textures", "objects", "sounds", "models", "rooms", "shaders", "particles", "scripts"]:
            # Create main resource type item
            type_item = QTreeWidgetItem(self)
            type_item.setText(0, f"{self.resource_icons.get(resource_type, '📁')} {resource_type.title()}")
            type_item.setData(0, Qt.UserRole, {"type": "resource_type", "resource_type": resource_type})
            type_item.setExpanded(True)
            
            # Add resources of this type - read from runtime
            resources = self._get_resources_from_runtime(resource_type)
            from Core.Debug import debug
            debug(f"DEBUG: Refreshing {resource_type}, found {len(resources)} resources from runtime")
            for resource in resources:
                debug(f"DEBUG: - {resource.get('name', 'NO_NAME')} (id: {resource.get('id', 'NO_ID')})")
            self.add_resources_to_tree(type_item, resources, resource_type)
            
            self.resource_items[resource_type] = type_item
        
        # Start background thumbnail loading (non-blocking)
        self._start_thumbnail_loading(project_path)
    
    def _get_resources_from_runtime(self, resource_type):
        """Get resources from runtime data"""
        runtime_resources = self.app.project_manager.get_runtime_resources(resource_type)
        resources = list(runtime_resources.values())
        from Core.Debug import debug
        debug(f"DEBUG: _get_resources_from_runtime({resource_type}) returned {len(resources)} resources")
        for resource in resources:
            debug(f"DEBUG:   - {resource.get('name', 'NO_NAME')} (id: {resource.get('id', 'NO_ID')})")
        return resources
    
    def refresh_resource_type(self, resource_type):
        """Refresh only a specific resource type while preserving expanded state of all folders"""
        if not self.app.project_manager.get_project_path():
            return
        
        # Find the existing resource type item
        if resource_type not in self.resource_items:
            return
        
        type_item = self.resource_items[resource_type]
        
        # Store the expanded state of the main type item
        was_expanded = type_item.isExpanded()
        
        # Store expanded states of all folders recursively
        folder_expanded_states = {}
        self._store_folder_expanded_states(type_item, folder_expanded_states, "")
        
        # Clear existing children
        type_item.takeChildren()
        
        # Get resources of this type from runtime
        resources = self._get_resources_from_runtime(resource_type)
        from Core.Debug import debug
        debug(f"DEBUG: Refreshing {resource_type}, found {len(resources)} resources from runtime")
        for resource in resources:
            debug(f"DEBUG: - {resource.get('name', 'NO_NAME')} (id: {resource.get('id', 'NO_ID')})")
        
        # Add resources to the tree
        self.add_resources_to_tree(type_item, resources, resource_type, "", folder_expanded_states)
        
        # Restore the expanded state of the main type item
        type_item.setExpanded(was_expanded)
    
    def _store_folder_expanded_states(self, item, folder_states, folder_path):
        """Recursively store expanded states of all folders"""
        for i in range(item.childCount()):
            child = item.child(i)
            child_data = child.data(0, Qt.UserRole)
            if child_data and child_data.get("type") == "folder":
                folder_name = child_data.get("folder", "")
                # Normalize path separators for consistency
                normalized_path = folder_name.replace("\\", "/")
                folder_states[normalized_path] = child.isExpanded()
                # Recursively store subfolder states
                self._store_folder_expanded_states(child, folder_states, normalized_path)
    
    
    def cleanup_project_data(self):
        """Remove references to resources that don't exist on disk"""
        project_path = self.app.project_manager.get_project_path()
        if not project_path:
            return
        
        project_data = self.app.project_manager.get_project_data()
        if not project_data or "resources" not in project_data:
            return
        
        # Clean up each resource type
        for resource_type in ["sprites", "backgrounds", "textures", "objects", "sounds", "models", "rooms", "shaders", "particles", "scripts"]:
            if resource_type not in project_data["resources"]:
                continue
            
            resources = project_data["resources"][resource_type]
            valid_resources = []
            
            for resource in resources:
                # Check if the resource file actually exists
                resource_file = self._get_resource_file_path(resource, resource_type, project_path)
                if resource_file and os.path.exists(resource_file):
                    valid_resources.append(resource)
            
            # Update the project data with only valid resources
            project_data["resources"][resource_type] = valid_resources
        
        # Save the cleaned project data
        self.app.project_manager.save_project()
    
    def refresh_parent_item(self, parent_item):
        """Refresh a specific parent item's children"""
        if not parent_item:
            return
        
        data = parent_item.data(0, Qt.UserRole)
        if not data:
            return
        
        # Clear existing children
        parent_item.takeChildren()
        
        if data.get("type") == "resource_type":
            # Refresh the entire resource type
            resource_type = data["resource_type"]
            resources = self._get_resources_from_runtime(resource_type)
            self.add_resources_to_tree(parent_item, resources, resource_type)
        elif data.get("type") == "folder":
            # Refresh just this folder's contents
            resource_type = data["resource_type"]
            folder = data["folder"]
            resources = self._get_resources_from_runtime(resource_type)
            # Filter resources for this specific folder
            folder_resources = [r for r in resources if r.get("parent_folder", "") == folder]
            for resource in sorted(folder_resources, key=lambda x: x.get("name", "")):
                self.add_resource_item(parent_item, resource, resource_type)
    
    def add_resources_to_tree(self, parent_item, resources, resource_type, parent_folder="", folder_expanded_states=None):
        """Add resources to the tree, organizing by folders"""
        if folder_expanded_states is None:
            folder_expanded_states = {}
        
        # Get the actual folder structure from disk
        project_path = self.app.project_manager.get_project_path()
        if not project_path:
            return
        
        resource_folder_map = {
            "sprites": "Sprites",
            "backgrounds": "Backgrounds",
            "textures": "Textures",
            "objects": "Objects",
            "sounds": "Sounds",
            "models": "Models",
            "rooms": "Rooms",
            "shaders": "Shaders",
            "particles": "Particles",
            "scripts": "Scripts"
        }
        
        resource_folder = resource_folder_map.get(resource_type, "Sprites")
        base_path = os.path.join(project_path, "Resources", resource_folder)
        if parent_folder:
            base_path = os.path.join(base_path, parent_folder)
        
        # Recursively scan for all folders and subfolders
        folder_structure = self._scan_folder_structure(base_path)
        
        # Use all resources from runtime (runtime-first approach)
        valid_resources = resources
        
        # Group valid resources by folder
        folder_groups = {}
        for resource in valid_resources:
            folder = resource.get("parent_folder", "")
            if folder not in folder_groups:
                folder_groups[folder] = []
            folder_groups[folder].append(resource)
        
        # Add folders and resources recursively
        self._add_folder_structure(parent_item, folder_structure, folder_groups, resource_type, parent_folder, folder_expanded_states)
    
    def _scan_folder_structure(self, base_path):
        """Recursively scan folder structure"""
        folder_structure = {}
        
        if not os.path.exists(base_path):
            return folder_structure
        
        for item in os.listdir(base_path):
            item_path = os.path.join(base_path, item)
            if os.path.isdir(item_path):
                # Recursively scan subfolders
                subfolders = self._scan_folder_structure(item_path)
                folder_structure[item] = subfolders
        
        return folder_structure
    
    def _add_folder_structure(self, parent_item, folder_structure, folder_groups, resource_type, current_folder_path="", folder_expanded_states=None):
        """Recursively add folder structure to tree"""
        if folder_expanded_states is None:
            folder_expanded_states = {}
        
        # Add resources in current folder
        folder_resources = folder_groups.get(current_folder_path, [])
        for resource in sorted(folder_resources, key=lambda x: x.get("name", "")):
            self.add_resource_item(parent_item, resource, resource_type)
        
        # Add subfolders
        for folder_name, subfolders in sorted(folder_structure.items()):
            # Create folder item
            folder_item = QTreeWidgetItem(parent_item)
            folder_item.setText(0, f"📁 {folder_name}")
            
            # Calculate full folder path (normalize to use forward slashes for consistency)
            if current_folder_path:
                full_folder_path = current_folder_path.replace("\\", "/") + "/" + folder_name
            else:
                full_folder_path = folder_name
            
            folder_item.setData(0, Qt.UserRole, {
                "type": "folder", 
                "resource_type": resource_type, 
                "folder": full_folder_path
            })
            
            # Check if this folder was previously expanded
            # Try multiple key formats for compatibility
            should_expand = False
            if full_folder_path in folder_expanded_states:
                should_expand = folder_expanded_states[full_folder_path]
            elif folder_name in folder_expanded_states:
                should_expand = folder_expanded_states[folder_name]
            elif current_folder_path:
                # Normalize current_folder_path for matching
                normalized_current = current_folder_path.replace("\\", "/")
                alt_key = f"{normalized_current}/{folder_name}"
                if alt_key in folder_expanded_states:
                    should_expand = folder_expanded_states[alt_key]
            
            folder_item.setExpanded(should_expand)
            
            # Recursively add subfolders and their resources
            self._add_folder_structure(folder_item, subfolders, folder_groups, resource_type, full_folder_path, folder_expanded_states)
    
    def _get_resource_file_path(self, resource, resource_type, project_path):
        """Get the actual file path for a resource"""
        if not resource or not project_path:
            return None
        
        resource_folder_map = {
            "sprites": "Sprites",
            "backgrounds": "Backgrounds",
            "textures": "Textures",
            "objects": "Objects",
            "sounds": "Sounds",
            "models": "Models",
            "rooms": "Rooms",
            "shaders": "Shaders",
            "particles": "Particles",
            "scripts": "Scripts"
        }
        
        resource_folder = resource_folder_map.get(resource_type, "Sprites")
        parent_folder = resource.get("parent_folder", "")
        
        # Build the file path
        file_path = os.path.join(project_path, "Resources", resource_folder)
        if parent_folder:
            file_path = os.path.join(file_path, parent_folder)
        
        # Add the resource file name
        resource_name = resource.get("name", "")
        if resource_name:
            file_extension = {
                "sprites": ".sprite",
                "backgrounds": ".background",
                "textures": ".texture",
                "objects": ".object", 
                "sounds": ".sound",
                "rooms": ".room",
                "models": ".model"
            }.get(resource_type, ".sprite")
            
            file_path = os.path.join(file_path, f"{resource_name}{file_extension}")
        elif resource_type == "folders":
            # For folders, just use the parent path
            file_path = os.path.dirname(file_path)
        
        return file_path
    
    def _get_resource_icon(self, resource, resource_type):
        """Get the appropriate icon for a resource"""
        # For sprites, textures, objects, and backgrounds, try to get the first image as thumbnail
        if resource_type in ["sprites", "textures", "objects", "backgrounds"]:
            thumbnail_icon = self._get_sprite_thumbnail(resource, resource_type)
            if thumbnail_icon:
                return thumbnail_icon
        
        # For other resource types or if no thumbnail available, return None
        # The add_resource_item method will handle the fallback to text icons
        return None
    
    def _get_sprite_thumbnail(self, resource, resource_type):
        """Get thumbnail icon for sprite/texture/object/background from first image"""
        try:
            # Get the resource file path
            project_path = self.app.project_manager.get_project_path()
            if not project_path:
                return None
            
            resource_file = self._get_resource_file_path(resource, resource_type, project_path)
            if not resource_file or not os.path.exists(resource_file):
                return None
            
            # Load the resource data
            import json
            with open(resource_file, 'r') as f:
                resource_data = json.load(f)
            
            # For backgrounds, check for image_file or image_path
            if resource_type == "backgrounds":
                image_path = resource_data.get("image_file") or resource_data.get("image_path") or resource_data.get("file")
                if image_path:
                    # Resolve the image path
                    parent_folder = resource.get("parent_folder", "")
                    base_path = os.path.join(project_path, "Resources", "Backgrounds")
                    if parent_folder:
                        base_path = os.path.join(base_path, parent_folder)
                    
                    # Try different path resolution strategies
                    image_full_path = None
                    if os.path.isabs(image_path) and os.path.exists(image_path):
                        image_full_path = image_path
                    elif not image_full_path:
                        test_path = os.path.join(base_path, image_path)
                        if os.path.exists(test_path):
                            image_full_path = test_path
                    elif not image_full_path:
                        image_filename = os.path.basename(image_path)
                        test_path = os.path.join(base_path, image_filename)
                        if os.path.exists(test_path):
                            image_full_path = test_path
                    
                    if image_full_path and os.path.exists(image_full_path):
                        # Load and resize the image for thumbnail
                        from PySide6.QtGui import QPixmap, QIcon, QImage
                        from PySide6.QtCore import QSize
                        
                        image = QImage(image_full_path)
                        if not image.isNull():
                            thumbnail = image.scaled(QSize(24, 24), Qt.KeepAspectRatio, Qt.SmoothTransformation)
                            pixmap = QPixmap.fromImage(thumbnail)
                            icon = QIcon(pixmap)
                            del image
                            del thumbnail
                            del pixmap
                            return icon
                return None
            
            # For objects, check if they have a sprite assigned and use that sprite's first frame
            if resource_type == "objects":
                sprite_name = resource_data.get("sprite", "")
                if sprite_name:
                    # Find the sprite in runtime resources
                    runtime_resources = self.app.project_manager.runtime_resources
                    sprites = runtime_resources.get("sprites", {})
                    for sprite_id, sprite_data in sprites.items():
                        if sprite_data.get("name") == sprite_name:
                            # Get sprite's first frame
                            frames = sprite_data.get("frames", [])
                            if frames:
                                first_frame = frames[0]
                                if isinstance(first_frame, dict):
                                    image_path = first_frame.get("file") or first_frame.get("path")
                                else:
                                    image_path = first_frame
                                
                                if image_path:
                                    # Resolve sprite image path
                                    sprite_parent_folder = sprite_data.get("parent_folder", "")
                                    sprite_base_path = os.path.join(project_path, "Resources", "Sprites")
                                    if sprite_parent_folder:
                                        sprite_base_path = os.path.join(sprite_base_path, sprite_parent_folder)
                                    
                                    sprite_image_path = os.path.join(sprite_base_path, image_path)
                                    if os.path.exists(sprite_image_path):
                                        # Load and resize the image for thumbnail
                                        from PySide6.QtGui import QPixmap, QIcon, QImage
                                        from PySide6.QtCore import QSize
                                        
                                        image = QImage(sprite_image_path)
                                        if not image.isNull():
                                            thumbnail = image.scaled(QSize(24, 24), Qt.KeepAspectRatio, Qt.SmoothTransformation)
                                            pixmap = QPixmap.fromImage(thumbnail)
                                            icon = QIcon(pixmap)
                                            del image
                                            del thumbnail
                                            del pixmap
                                            return icon
                return None
            
            # For sprites and textures, check if resource has frames/images
            frames = resource_data.get("frames", [])
            if not frames:
                return None
            
            # Get the first frame/image
            first_frame = frames[0]
            if isinstance(first_frame, dict):
                image_path = first_frame.get("path") or first_frame.get("file")
            else:
                image_path = first_frame
            
            if not image_path:
                return None
            
            # Resolve the image path relative to the resource folder
            parent_folder = resource.get("parent_folder", "")
            
            # Build the correct path based on resource type
            resource_folder_map = {
                "sprites": "Sprites",
                "textures": "Textures",
                "objects": "Objects",
                "backgrounds": "Backgrounds",
                "sounds": "Sounds",
                "models": "Models",
                "rooms": "Rooms"
            }
            
            resource_folder = resource_folder_map.get(resource_type, "Sprites")
            base_path = os.path.join(project_path, "Resources", resource_folder)
            
            if parent_folder:
                base_path = os.path.join(base_path, parent_folder)
            
            # Try different path resolution strategies
            image_full_path = None
            
            # Strategy 1: If image_path is already absolute and exists
            if os.path.isabs(image_path) and os.path.exists(image_path):
                image_full_path = image_path
            
            # Strategy 2: Try relative to base_path
            elif not image_full_path:
                test_path = os.path.join(base_path, image_path)
                if os.path.exists(test_path):
                    image_full_path = test_path
            
            # Strategy 3: Try with just the filename (basename)
            elif not image_full_path:
                image_filename = os.path.basename(image_path)
                test_path = os.path.join(base_path, image_filename)
                if os.path.exists(test_path):
                    image_full_path = test_path
            
            # Strategy 4: Try relative to project_path (legacy support)
            elif not image_full_path:
                test_path = os.path.join(project_path, image_path)
                if os.path.exists(test_path):
                    image_full_path = test_path
            
            if not image_full_path or not os.path.exists(image_full_path):
                return None
            
            # Load and resize the image for thumbnail
            from PySide6.QtGui import QPixmap, QIcon, QImage
            from PySide6.QtCore import QSize
            
            # Use QImage for better resource management
            image = QImage(image_full_path)
            if image.isNull():
                return None
            
            # Create a small thumbnail (24x24 pixels for better visibility)
            thumbnail = image.scaled(QSize(24, 24), Qt.KeepAspectRatio, Qt.SmoothTransformation)
            
            # Convert QImage to QPixmap for QIcon (QPixmap is better for icons)
            pixmap = QPixmap.fromImage(thumbnail)
            
            # Convert to QIcon
            icon = QIcon(pixmap)
            
            # Explicitly clear references to help with cleanup
            del image
            del thumbnail
            del pixmap
            
            return icon
            
        except Exception as e:
            # If anything fails, return None to use default icon
            import traceback
            from Core.Debug import debug
            debug(f"DEBUG: Failed to load thumbnail for {resource_type} {resource.get('name', 'Unknown')}: {e}")
            traceback.print_exc()
            return None
    
    def add_resource_item(self, parent_item, resource, resource_type):
        """Add a single resource item to the tree"""
        item = QTreeWidgetItem(parent_item)
        
        # Don't load thumbnails synchronously - they'll be loaded in background
        # Just set the text for now, thumbnail will be added later
        resource_name = resource.get("name", "Unknown")
        item.setText(0, f"📄 {resource_name}")
        
        resource_id = resource.get("id", "")
        item.setData(0, Qt.UserRole, {
            "type": "resource",
            "resource_type": resource_type,
            "resource_id": resource_id
        })
        
        # Store reference to resource data and item for thumbnail loading
        item.resource_data = resource
        if resource_id:
            self.thumbnail_items[(resource_type, resource_id)] = item
    
    def _find_resource_item(self, resource_type, resource_id):
        """Find a resource item in the tree by type and ID"""
        if resource_type not in self.resource_items:
            return None
        
        type_item = self.resource_items[resource_type]
        return self._find_resource_item_recursive(type_item, resource_id)
    
    def _find_resource_item_recursive(self, parent_item, resource_id):
        """Recursively search for a resource item"""
        for i in range(parent_item.childCount()):
            child = parent_item.child(i)
            child_data = child.data(0, Qt.UserRole)
            if child_data and child_data.get("type") == "resource":
                if child_data.get("resource_id") == resource_id:
                    return child
            elif child_data and child_data.get("type") == "folder":
                # Search in subfolders
                result = self._find_resource_item_recursive(child, resource_id)
                if result:
                    return result
        return None
    
    def _find_or_create_folder_item(self, parent_item, folder_path, resource_type):
        """Find or create a folder item for the given folder path"""
        if not folder_path:
            return parent_item
        
        # Normalize folder path
        normalized_path = folder_path.replace("\\", "/")
        folder_parts = [p for p in normalized_path.split("/") if p]
        
        if not folder_parts:
            return parent_item
        
        current_item = parent_item
        current_path = ""
        
        for folder_name in folder_parts:
            # Look for existing folder
            found = False
            for i in range(current_item.childCount()):
                child = current_item.child(i)
                child_data = child.data(0, Qt.UserRole)
                if child_data and child_data.get("type") == "folder":
                    child_folder = child_data.get("folder", "").replace("\\", "/")
                    # Build expected path for this level
                    expected_path = f"{current_path}/{folder_name}" if current_path else folder_name
                    if child_folder == expected_path or child_folder.endswith(f"/{folder_name}"):
                        current_item = child
                        current_path = child_folder
                        found = True
                        break
            
            if not found:
                # Create new folder item
                folder_item = QTreeWidgetItem(current_item)
                folder_item.setText(0, f"📁 {folder_name}")
                
                # Calculate full path
                full_path = f"{current_path}/{folder_name}" if current_path else folder_name
                
                folder_item.setData(0, Qt.UserRole, {
                    "type": "folder",
                    "resource_type": resource_type,
                    "folder": full_path
                })
                folder_item.setExpanded(False)  # Don't auto-expand new folders
                current_item = folder_item
                current_path = full_path
        
        return current_item
    
    def add_single_resource(self, resource_type, resource_data):
        """Add a single resource to the tree without refreshing the entire type"""
        if resource_type not in self.resource_items:
            return
        
        type_item = self.resource_items[resource_type]
        folder_path = resource_data.get("parent_folder", "")
        
        # Find or create the folder item
        parent_item = self._find_or_create_folder_item(type_item, folder_path, resource_type)
        
        # Add the resource item
        self.add_resource_item(parent_item, resource_data, resource_type)
        
        # Load thumbnail for this resource only
        project_path = self.app.project_manager.get_project_path()
        resource_id = resource_data.get("id")
        if resource_id and project_path:
            self.thumbnail_loader.add_resource(resource_type, resource_id, resource_data, project_path)
            if not self.thumbnail_loader.isRunning():
                self.thumbnail_loader.start()
    
    def update_single_resource(self, resource_type, resource_data):
        """Update a single resource item without refreshing the entire type"""
        resource_id = resource_data.get("id")
        if not resource_id:
            return
        
        # Find the existing item
        item = self._find_resource_item(resource_type, resource_id)
        if item:
            # Update the item text
            resource_name = resource_data.get("name", "Unknown")
            item.setText(0, f"📄 {resource_name}")
            
            # Update stored resource data
            item.resource_data = resource_data
            
            # Reload thumbnail if it's a thumbnail-capable resource
            if resource_type in ["sprites", "textures", "objects", "backgrounds"]:
                project_path = self.app.project_manager.get_project_path()
                if project_path:
                    # Remove old thumbnail entry and reload
                    key = (resource_type, resource_id)
                    if key in self.thumbnail_items:
                        del self.thumbnail_items[key]
                    self.thumbnail_items[key] = item
                    self.thumbnail_loader.add_resource(resource_type, resource_id, resource_data, project_path)
                    if not self.thumbnail_loader.isRunning():
                        self.thumbnail_loader.start()
    
    def remove_single_resource(self, resource_type, resource_id):
        """Remove a single resource item without refreshing the entire type"""
        item = self._find_resource_item(resource_type, resource_id)
        if item:
            parent = item.parent()
            if parent:
                parent.removeChild(item)
            else:
                # If no parent, it's a direct child of type_item
                type_item = self.resource_items.get(resource_type)
                if type_item:
                    type_item.removeChild(item)
            
            # Remove from thumbnail items
            key = (resource_type, resource_id)
            if key in self.thumbnail_items:
                del self.thumbnail_items[key]
    
    def _start_thumbnail_loading(self, project_path):
        """Start background thumbnail loading for all resources - OPTIMIZED with cache"""
        from Core.Debug import debug
        from Core.ThumbnailCache import ThumbnailCache
        
        # Initialize thumbnail cache
        thumbnail_cache = ThumbnailCache(project_path)
        
        # Collect all resources that need thumbnails
        total_resources = 0
        cached_count = 0
        
        for resource_type in ["sprites", "textures", "objects", "backgrounds"]:
            resources = self._get_resources_from_runtime(resource_type)
            for resource in resources:
                resource_id = resource.get("id")
                if resource_id:
                    # Try to load from cache first (fast path)
                    image_path = self._get_resource_image_path_for_cache(resource_type, resource, project_path)
                    if image_path:
                        cached_icon = thumbnail_cache.get_thumbnail(resource_type, resource_id, image_path)
                        if cached_icon:
                            # Cache hit - apply immediately
                            key = (resource_type, resource_id)
                            if key in self.thumbnail_items:
                                item = self.thumbnail_items[key]
                                if item:
                                    item.setIcon(0, cached_icon)
                                    resource_name = item.resource_data.get("name", "Unknown") if hasattr(item, 'resource_data') else item.text(0).replace("📄 ", "")
                                    item.setText(0, resource_name)
                            cached_count += 1
                            continue
                    
                    # Cache miss - queue for loading
                    self.thumbnail_loader.add_resource(resource_type, resource_id, resource, project_path)
                    total_resources += 1
        
        debug(f"Thumbnail loading: {cached_count} from cache, {total_resources} queued for generation")
        
        # Start the thumbnail loader thread if there's work to do
        if total_resources > 0:
            if not self.thumbnail_loader.isRunning():
                self.thumbnail_loader.start()
                debug("Started thumbnail loader thread")
    
    def _get_resource_image_path_for_cache(self, resource_type, resource_data, project_path):
        """Get image path for a resource (for cache lookup) - simplified version"""
        # This is a simplified helper - full path resolution would be in ThumbnailLoader
        # For now, return None to let ThumbnailLoader handle it
        return None
    
    def on_thumbnail_ready(self, resource_type, resource_id, icon):
        """Handle thumbnail loaded signal - update the tree item"""
        from Core.Debug import debug
        key = (resource_type, resource_id)
        debug(f"Thumbnail ready for {resource_type}/{resource_id}, key in items: {key in self.thumbnail_items}")
        
        if key in self.thumbnail_items:
            item = self.thumbnail_items[key]
            if item:
                # Update the item with the thumbnail icon
                item.setIcon(0, icon)
                # Update text to remove placeholder emoji
                resource_name = item.resource_data.get("name", "Unknown") if hasattr(item, 'resource_data') else item.text(0).replace("📄 ", "")
                item.setText(0, resource_name)
                debug(f"Updated thumbnail for {resource_type}/{resource_id}")
            else:
                debug(f"Item is None for {resource_type}/{resource_id}")
        else:
            debug(f"Key not found in thumbnail_items: {key}, available keys: {list(self.thumbnail_items.keys())[:5]}")
    
    def on_selection_changed(self):
        """Handle selection change"""
        current_item = self.currentItem()
        if not current_item:
            return
        
        data = current_item.data(0, Qt.UserRole)
        if data and data.get("type") == "resource":
            self.resource_selected.emit(data["resource_type"], data["resource_id"])
    
    def on_item_double_clicked(self, item, column):
        """Handle double click on item"""
        data = item.data(0, Qt.UserRole)
        if data and data.get("type") == "resource":
            self.resource_double_clicked.emit(data["resource_type"], data["resource_id"])
    
    def show_context_menu(self, position):
        """Show context menu for right-click"""
        item = self.itemAt(position)
        if not item:
            return
        
        data = item.data(0, Qt.UserRole)
        if not data:
            return
        
        menu = QMenu(self)
        
        if data.get("type") == "resource_type":
            # Resource type context menu
            create_resource_action = menu.addAction(f"Create {data['resource_type'].title()}")
            create_resource_action.triggered.connect(lambda: self.create_resource(data["resource_type"]))
            
            # Quick Create submenu for common workflows
            quick_create_menu = menu.addMenu("Quick Create")
            
            if data["resource_type"] == "sprites":
                quick_create_action = quick_create_menu.addAction("Create Sprite from Image...")
                quick_create_action.triggered.connect(lambda: self.quick_create_sprite_from_image())
            elif data["resource_type"] == "sounds":
                quick_create_action = quick_create_menu.addAction("Create Sound from File...")
                quick_create_action.triggered.connect(lambda: self.quick_create_sound_from_file())
            elif data["resource_type"] == "objects":
                quick_create_action = quick_create_menu.addAction("Create Object from Sprite...")
                quick_create_action.triggered.connect(lambda: self.quick_create_object_from_sprite())
            
            create_folder_action = menu.addAction("Create Folder")
            create_folder_action.triggered.connect(lambda: self.create_folder(data["resource_type"]))
            
            paste_action = menu.addAction("Paste")
            paste_action.triggered.connect(lambda: self.paste_resource(item))
            paste_action.setEnabled(self.has_clipboard_data())
            
        elif data.get("type") == "folder":
            # Folder context menu
            create_resource_action = menu.addAction(f"Create {data['resource_type'].title()}")
            create_resource_action.triggered.connect(lambda: self.create_resource(data["resource_type"], data["folder"]))
            
            # Quick Create submenu for folders too
            quick_create_menu = menu.addMenu("Quick Create")
            
            if data["resource_type"] == "sprites":
                quick_create_action = quick_create_menu.addAction("Create Sprite from Image...")
                quick_create_action.triggered.connect(lambda: self.quick_create_sprite_from_image(data["folder"]))
            elif data["resource_type"] == "sounds":
                quick_create_action = quick_create_menu.addAction("Create Sound from File...")
                quick_create_action.triggered.connect(lambda: self.quick_create_sound_from_file(data["folder"]))
            elif data["resource_type"] == "objects":
                quick_create_action = quick_create_menu.addAction("Create Object from Sprite...")
                quick_create_action.triggered.connect(lambda: self.quick_create_object_from_sprite(data["folder"]))
            
            create_folder_action = menu.addAction("Create Subfolder")
            create_folder_action.triggered.connect(lambda: self.create_folder(data["resource_type"], data["folder"]))
            
            menu.addSeparator()
            
            rename_action = menu.addAction("Rename Folder")
            rename_action.triggered.connect(lambda: self.rename_folder(item))
            
            cut_action = menu.addAction("Cut")
            cut_action.triggered.connect(lambda: self.cut_folder(item))
            
            copy_action = menu.addAction("Copy")
            copy_action.triggered.connect(lambda: self.copy_folder(item))
            
            paste_action = menu.addAction("Paste")
            paste_action.triggered.connect(lambda: self.paste_resource(item))
            paste_action.setEnabled(self.has_clipboard_data())
            
            menu.addSeparator()
            
            delete_action = menu.addAction("Delete Folder")
            delete_action.triggered.connect(lambda: self.delete_folder(item))
            
        elif data.get("type") == "resource":
            # Resource context menu
            open_action = menu.addAction("Open")
            open_action.triggered.connect(lambda: self.open_resource(item))
            
            menu.addSeparator()
            
            # Find References (dependency tracking)
            find_refs_action = menu.addAction("Find References...")
            find_refs_action.triggered.connect(lambda: self.find_resource_references(item))
            
            # View In Explorer
            view_in_explorer_action = menu.addAction("View In Explorer")
            view_in_explorer_action.triggered.connect(lambda: self.view_in_explorer(item))
            
            menu.addSeparator()
            
            rename_action = menu.addAction("Rename")
            rename_action.triggered.connect(lambda: self.rename_resource(item))
            
            cut_action = menu.addAction("Cut")
            cut_action.triggered.connect(lambda: self.cut_resource(item))
            
            copy_action = menu.addAction("Copy")
            copy_action.triggered.connect(lambda: self.copy_resource(item))
            
            paste_action = menu.addAction("Paste")
            paste_action.triggered.connect(lambda: self.paste_resource(item))
            paste_action.setEnabled(self.has_clipboard_data())
            
            menu.addSeparator()
            
            delete_action = menu.addAction("Delete")
            delete_action.triggered.connect(lambda: self.delete_resource(item))
        
        menu.exec(self.mapToGlobal(position))
    
    def create_resource(self, resource_type, parent_folder=""):
        """Create a new resource"""
        name, ok = QInputDialog.getText(self, f"Create {resource_type.title()}", "Name:")
        if not ok or not name:
            return
        
        # Check if name already exists
        existing_resources = self._get_resources_from_runtime(resource_type)
        for resource in existing_resources:
            if (resource.get("name") == name and 
                resource.get("parent_folder", "") == parent_folder):
                QMessageBox.warning(self, "Name Exists", f"A {resource_type} with this name already exists in this folder")
                return
        
        # Create resource
        resource_data = self.app.resource_manager.create_resource(resource_type, name, parent_folder)
        # Signal will be emitted by ResourceManager, which will trigger add_single_resource
    
    def quick_create_sprite_from_image(self, parent_folder=""):
        """Quick create sprite from imported image - simplified, no folder creation."""
        # Open file dialog for image
        file_path, _ = QFileDialog.getOpenFileName(
            self,
            "Select Image File",
            "",
            "Image Files (*.png *.jpg *.jpeg *.bmp *.gif);;All Files (*.*)"
        )
        
        if not file_path:
            return
        
        # Get sprite name from filename
        import os
        base_name = os.path.splitext(os.path.basename(file_path))[0]
        
        # Ask for sprite name
        from PySide6.QtWidgets import QInputDialog
        name, ok = QInputDialog.getText(
            self,
            "Create Sprite from Image",
            "Sprite name:",
            text=base_name
        )
        
        if not ok or not name:
            return
        
        # Check if name already exists
        existing_resources = self._get_resources_from_runtime("sprites")
        for resource in existing_resources:
            if (resource.get("name") == name and 
                resource.get("parent_folder", "") == parent_folder):
                from PySide6.QtWidgets import QMessageBox
                QMessageBox.warning(self, "Name Exists", f"A sprite with this name already exists in this folder")
                return
        
        # Create sprite resource
        resource_data = self.app.resource_manager.create_resource("sprites", name, parent_folder)
        if resource_data:
            try:
                project_path = self.app.project_manager.get_project_path()
                if not project_path:
                    from PySide6.QtWidgets import QMessageBox
                    QMessageBox.warning(self, "Error", "No project is currently open.")
                    return
                
                # Get sprites folder (no subfolder for frames)
                sprites_folder = os.path.join(project_path, "Resources", "Sprites")
                if parent_folder:
                    sprites_folder = os.path.join(sprites_folder, parent_folder)
                
                # Ensure sprites folder exists
                os.makedirs(sprites_folder, exist_ok=True)
                
                # Save frame file directly in Sprites folder (no subfolder)
                from PIL import Image
                import shutil
                
                # Get image dimensions first
                with Image.open(file_path) as img:
                    width = img.width
                    height = img.height
                
                # Save as PNG in Sprites folder directly
                frame_filename = f"{name}_0.png"
                frame_path = os.path.join(sprites_folder, frame_filename)
                
                # Convert and save as PNG (ensures proper format)
                with Image.open(file_path) as img:
                    img_rgba = img.convert("RGBA")
                    img_rgba.save(frame_path, "PNG")
                
                # Update sprite resource with frame reference (just filename, no path)
                resource_file = self._get_resource_file_path(resource_data, "sprites", project_path)
                if resource_file and os.path.exists(resource_file):
                    with open(resource_file, 'r') as f:
                        sprite_data = json.load(f)
                    
                    # Add frame reference (just filename, no subfolder path)
                    sprite_data["frames"] = [{
                        "id": "frame_0",
                        "file": frame_filename,  # Just filename, no subfolder path
                        "duration": 1.0,
                        "tags": []
                    }]
                    
                    # Set dimensions
                    sprite_data["width"] = width
                    sprite_data["height"] = height
                    
                    # Save updated sprite data
                    with open(resource_file, 'w') as f:
                        json.dump(sprite_data, f, indent=2)
                    
                    # Emit update signal to refresh resource tree
                    self.app.resource_manager.resource_updated.emit("sprites", sprite_data)
                    
                    # Signal will trigger update_single_resource, no need to refresh
                    
                    # Automatically open the sprite editor (it will automatically load the image)
                    from PySide6.QtCore import QTimer
                    def open_editor():
                        # Open the sprite editor
                        resource_id = resource_data.get("id")
                        if resource_id:
                            # Find the main window and open the resource
                            main_window = self.parent()
                            while main_window and not hasattr(main_window, 'open_resource'):
                                main_window = main_window.parent()
                            
                            if main_window and hasattr(main_window, 'open_resource'):
                                main_window.open_resource("sprites", resource_id)
                                # The sprite editor automatically loads frames from sprite data
                    
                    QTimer.singleShot(100, open_editor)
                    
            except Exception as e:
                from PySide6.QtWidgets import QMessageBox
                import traceback
                traceback.print_exc()
                QMessageBox.warning(
                    self,
                    "Error",
                    f"Failed to create sprite from image: {str(e)}"
                )
    
    
    def quick_create_sound_from_file(self, parent_folder=""):
        """Quick create sound from imported audio file"""
        # Open file dialog for audio
        file_path, _ = QFileDialog.getOpenFileName(
            self,
            "Select Audio File",
            "",
            "Audio Files (*.wav *.mp3 *.ogg *.flac);;All Files (*.*)"
        )
        
        if not file_path:
            return
        
        # Get sound name from filename
        import os
        base_name = os.path.splitext(os.path.basename(file_path))[0]
        
        # Ask for sound name
        name, ok = QInputDialog.getText(
            self,
            "Create Sound from File",
            "Sound name:",
            text=base_name
        )
        
        if not ok or not name:
            return
        
        # Check if name already exists
        existing_resources = self._get_resources_from_runtime("sounds")
        for resource in existing_resources:
            if (resource.get("name") == name and 
                resource.get("parent_folder", "") == parent_folder):
                QMessageBox.warning(self, "Name Exists", f"A sound with this name already exists in this folder")
                return
        
        # Create sound resource
        resource_data = self.app.resource_manager.create_resource("sounds", name, parent_folder)
        if resource_data:
            # Import the audio file
            try:
                project_path = self.app.project_manager.get_project_path()
                if project_path:
                    # Copy audio to Sounds folder
                    sounds_folder = os.path.join(project_path, "Resources", "Sounds")
                    if parent_folder:
                        sounds_folder = os.path.join(sounds_folder, parent_folder)
                    
                    os.makedirs(sounds_folder, exist_ok=True)
                    
                    # Copy audio file
                    import shutil
                    audio_filename = os.path.basename(file_path)
                    dest_path = os.path.join(sounds_folder, audio_filename)
                    shutil.copy2(file_path, dest_path)
                    
                    # Update sound resource with audio file reference
                    resource_file = self._get_resource_file_path(resource_data, "sounds", project_path)
                    if resource_file and os.path.exists(resource_file):
                        with open(resource_file, 'r') as f:
                            sound_data = json.load(f)
                        
                        # Set audio file reference
                        sound_data["audio_file"] = audio_filename
                        sound_data["original_audio_file"] = file_path
                        
                        # Try to get audio properties if pydub is available
                        try:
                            from pydub import AudioSegment
                            audio = AudioSegment.from_file(file_path)
                            sound_data["duration"] = len(audio) / 1000.0  # Convert to seconds
                            sound_data["sample_rate"] = audio.frame_rate
                            sound_data["channels"] = audio.channels
                            sound_data["bit_depth"] = audio.sample_width * 8
                        except:
                            pass  # Use defaults if pydub not available
                        
                        # Save updated sound data
                        with open(resource_file, 'w') as f:
                            json.dump(sound_data, f, indent=2)
                        
                        # Emit update signal
                        self.app.resource_manager.resource_updated.emit("sounds", sound_data)
                        
                        QMessageBox.information(
                            self,
                            "Success",
                            f"Sound '{name}' created from file successfully!"
                        )
            except Exception as e:
                QMessageBox.warning(
                    self,
                    "Warning",
                    f"Sound created but file import failed: {str(e)}"
                )
            
            # Signal will trigger update_single_resource, no need to refresh
    
    def quick_create_object_from_sprite(self, parent_folder=""):
        """Quick create object from existing sprite"""
        # Get list of sprites
        sprites = self._get_resources_from_runtime("sprites")
        if not sprites:
            QMessageBox.information(
                self,
                "No Sprites",
                "No sprites available. Please create a sprite first."
            )
            return
        
        # Create sprite selection dialog
        sprite_names = [s.get("name", "Unknown") for s in sprites]
        sprite_name, ok = QInputDialog.getItem(
            self,
            "Select Sprite",
            "Choose a sprite for this object:",
            sprite_names,
            0,
            False
        )
        
        if not ok or not sprite_name:
            return
        
        # Find the sprite resource
        selected_sprite = None
        for sprite in sprites:
            if sprite.get("name") == sprite_name:
                selected_sprite = sprite
                break
        
        if not selected_sprite:
            return
        
        # Ask for object name
        name, ok = QInputDialog.getText(
            self,
            "Create Object from Sprite",
            "Object name:",
            text=f"obj_{sprite_name}"
        )
        
        if not ok or not name:
            return
        
        # Check if name already exists
        existing_resources = self._get_resources_from_runtime("objects")
        for resource in existing_resources:
            if (resource.get("name") == name and 
                resource.get("parent_folder", "") == parent_folder):
                QMessageBox.warning(self, "Name Exists", f"An object with this name already exists in this folder")
                return
        
        # Create object resource
        resource_data = self.app.resource_manager.create_resource("objects", name, parent_folder)
        if resource_data:
            # Set sprite reference
            try:
                project_path = self.app.project_manager.get_project_path()
                if project_path:
                    resource_file = self._get_resource_file_path(resource_data, "objects", project_path)
                    if resource_file and os.path.exists(resource_file):
                        with open(resource_file, 'r') as f:
                            object_data = json.load(f)
                        
                        # Set sprite reference
                        object_data["sprite"] = selected_sprite.get("id")
                        
                        # Save updated object data
                        with open(resource_file, 'w') as f:
                            json.dump(object_data, f, indent=2)
                        
                        # Emit update signal
                        self.app.resource_manager.resource_updated.emit("objects", object_data)
                        
                        QMessageBox.information(
                            self,
                            "Success",
                            f"Object '{name}' created with sprite '{sprite_name}' successfully!"
                        )
            except Exception as e:
                QMessageBox.warning(
                    self,
                    "Warning",
                    f"Object created but sprite assignment failed: {str(e)}"
                )
            
            # Signal will trigger update_single_resource, no need to refresh
    
    def find_resource_references(self, item):
        """Find all resources that reference the selected resource"""
        data = item.data(0, Qt.UserRole)
        if not data or data.get("type") != "resource":
            return
        
        resource_type = data["resource_type"]
        resource_id = data["resource_id"]
        resource_name = item.text(0)
        
        # Find references in all resource files
        references = []
        project_path = self.app.project_manager.get_project_path()
        if not project_path:
            QMessageBox.warning(self, "No Project", "No project loaded")
            return
        
        # Scan all resource types for references
        for ref_type in ["sprites", "backgrounds", "objects", "sounds", "models", "rooms", "textures"]:
            resources = self._get_resources_from_runtime(ref_type)
            for resource in resources:
                # Skip the resource itself - don't show self-references
                if (ref_type == resource_type and 
                    resource.get("id") == resource_id):
                    continue
                
                resource_file = self._get_resource_file_path(resource, ref_type, project_path)
                if not resource_file or not os.path.exists(resource_file):
                    continue
                
                try:
                    with open(resource_file, 'r', encoding='utf-8') as f:
                        content = f.read()
                        # More precise check - look for actual references
                        # Skip the initial substring check as it's too permissive
                        if self._check_resource_reference(content, resource_id, resource_name, resource_type, ref_type, resource_file, project_path):
                            references.append({
                                "type": ref_type,
                                "name": resource.get("name", "Unknown"),
                                "id": resource.get("id", "")
                            })
                except:
                    continue
        
        # Display results
        if references:
            ref_text = f"'{resource_name}' is referenced by:\n\n"
            for ref in references:
                ref_text += f"• {ref['type'].title()}: {ref['name']}\n"
            
            QMessageBox.information(self, "Resource References", ref_text)
        else:
            QMessageBox.information(
                self,
                "No References",
                f"'{resource_name}' is not referenced by any other resources."
            )
    
    def _check_resource_reference(self, content, resource_id, resource_name, resource_type, ref_type=None, ref_file=None, project_path=None):
        """Check if content actually references the resource (not just contains the name)"""
        import json
        import re
        
        # Try to parse as JSON first
        try:
            data = json.loads(content)
            # Check common reference fields
            if resource_type == "sprites":
                # Check sprite references in objects, rooms, etc.
                if isinstance(data, dict):
                    # Direct sprite reference
                    if data.get("sprite") == resource_id or data.get("sprite") == resource_name:
                        return True
                    # Check in instances (rooms)
                    for instance in data.get("instances", []):
                        if instance.get("object") and (resource_id in str(instance.get("object")) or resource_name in str(instance.get("object"))):
                            return True
            elif resource_type == "sounds":
                # Check sound references
                if isinstance(data, dict):
                    if data.get("sound") == resource_id or data.get("sound") == resource_name:
                        return True
                    sounds_list = data.get("sounds", [])
                    if isinstance(sounds_list, list):
                        if resource_id in sounds_list or resource_name in sounds_list:
                            return True
            elif resource_type == "backgrounds":
                # Check background references in rooms
                if isinstance(data, dict):
                    for bg in data.get("backgrounds", []):
                        if bg.get("background") == resource_id or bg.get("background") == resource_name:
                            return True
            elif resource_type == "textures":
                # Check texture references
                if isinstance(data, dict):
                    # Direct texture reference
                    if data.get("texture") == resource_id or data.get("texture") == resource_name:
                        return True
                    # Check in models' texture_resources array (if this is a model file)
                    if ref_type == "models":
                        texture_resources = data.get("texture_resources", [])
                        if isinstance(texture_resources, list):
                            if resource_id in texture_resources or resource_name in texture_resources:
                                return True
            elif resource_type == "models":
                # Check model references
                if isinstance(data, dict):
                    # Direct model reference (e.g., in objects)
                    if data.get("model") == resource_id or data.get("model") == resource_name:
                        return True
                    # Check in instances (rooms might reference models through objects)
                    # If this is an object file, check if it references the model
                    if ref_type == "objects":
                        # Objects can reference models directly
                        if data.get("model") == resource_id or data.get("model") == resource_name:
                            return True
        except:
            pass
        
        # No fallback - only match if it's a proper JSON reference
        # The fallback was too permissive and matched false positives
        return False
    
    def open_resource(self, item):
        """Open a resource"""
        data = item.data(0, Qt.UserRole)
        if data and data.get("type") == "resource":
            self.resource_double_clicked.emit(data["resource_type"], data["resource_id"])
    
    def view_in_explorer(self, item):
        """Open the resource file location in Windows Explorer"""
        data = item.data(0, Qt.UserRole)
        if not data or data.get("type") != "resource":
            return
        
        try:
            resource_type = data.get("resource_type")
            resource_id = data.get("resource_id")
            
            # Get the full resource data from runtime resources
            resources = self._get_resources_from_runtime(resource_type)
            resource_data = None
            for resource in resources:
                if resource.get("id") == resource_id:
                    resource_data = resource
                    break
            
            if not resource_data:
                QMessageBox.warning(self, "Resource Not Found", f"Could not find resource data for {resource_type}/{resource_id}")
                return
            
            # Get the resource file path
            if hasattr(self.app, 'resource_manager'):
                resource_file = self.app.resource_manager.get_resource_file_path(resource_type, resource_data)
                if resource_file and os.path.exists(resource_file):
                    # Open the folder containing the file and select the file
                    import subprocess
                    import platform
                    
                    if platform.system() == "Windows":
                        # Use explorer.exe to open folder and select file
                        subprocess.run(['explorer.exe', '/select,', os.path.normpath(resource_file)])
                    elif platform.system() == "Darwin":  # macOS
                        subprocess.run(['open', '-R', resource_file])
                    else:  # Linux
                        subprocess.run(['xdg-open', os.path.dirname(resource_file)])
                else:
                    QMessageBox.warning(self, "File Not Found", f"Resource file not found:\n{resource_file}")
            else:
                QMessageBox.warning(self, "Error", "Resource manager not available")
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to open in Explorer:\n{str(e)}")
            from Core.Debug import debug
            debug(f"Error in view_in_explorer: {e}")
            import traceback
            debug(traceback.format_exc())
    
    def rename_resource(self, item):
        """Rename a resource"""
        data = item.data(0, Qt.UserRole)
        if not data or data.get("type") != "resource":
            return
        
        # Get current name - handle different text formats
        item_text = item.text(0)
        if " " in item_text:
            current_name = item_text.split(" ", 1)[1]  # Remove icon
        else:
            current_name = item_text  # No icon, use full text
        new_name, ok = QInputDialog.getText(self, "Rename Resource", "New name:", text=current_name)
        if not ok or not new_name or new_name == current_name:
            return
        
        # Check if name already exists
        resource_type = data["resource_type"]
        existing_resources = self._get_resources_from_runtime(resource_type)
        for resource in existing_resources:
            if (resource.get("name") == new_name and 
                resource.get("id") != data["resource_id"]):
                QMessageBox.warning(self, "Name Exists", f"A {resource_type} with this name already exists")
                return
        
        # Rename resource
        if self.app.resource_manager.rename_resource(resource_type, data["resource_id"], new_name):
            # Signal will trigger update_single_resource, no need to refresh
            pass
    
    def copy_resource(self, item):
        """Copy a resource"""
        data = item.data(0, Qt.UserRole)
        if data and data.get("type") == "resource":
            # Get the full resource data
            resource_data = self.app.resource_manager.load_resource(data["resource_type"], data["resource_id"])
            if resource_data:
                self.clipboard_manager.copy_item(resource_data, "resource")
    
    def cut_resource(self, item):
        """Cut a resource"""
        data = item.data(0, Qt.UserRole)
        if data and data.get("type") == "resource":
            # Get the full resource data
            resource_data = self.app.resource_manager.load_resource(data["resource_type"], data["resource_id"])
            if resource_data:
                self.clipboard_manager.cut_item(resource_data, "resource")
                item.setBackground(0, QColor(200, 200, 200))  # Visual feedback
    
    def delete_resource(self, item=None):
        """Delete a resource"""
        # Get all selected items
        selected_items = self.selectedItems()
        if not selected_items:
            return
        
        # Filter for resource items only
        resource_items = []
        for selected_item in selected_items:
            try:
                data = selected_item.data(0, Qt.UserRole)
                if data and data.get("type") == "resource":
                    # Validate that we have the required data
                    if "resource_type" in data and "resource_id" in data:
                        resource_items.append((selected_item, data))
            except (RuntimeError, AttributeError, TypeError):
                # Item was deleted or has invalid data, skip it
                continue
        
        if not resource_items:
            return
        
        # Show confirmation dialog
        if len(resource_items) == 1:
            # Get resource name more safely
            item_text = resource_items[0][0].text(0)
            resource_name = item_text
            # Try to extract name after space, but fallback to full text
            if " " in item_text:
                parts = item_text.split(" ", 1)
                if len(parts) > 1:
                    resource_name = parts[1]
            reply = QMessageBox.question(self, "Delete Resource", 
                                       f"Are you sure you want to delete '{resource_name}'?",
                                       QMessageBox.Yes | QMessageBox.No)
        else:
            reply = QMessageBox.question(self, "Delete Resources", 
                                       f"Are you sure you want to delete {len(resource_items)} resources?",
                                       QMessageBox.Yes | QMessageBox.No)
        
        if reply == QMessageBox.Yes:
            success_count = 0
            for item, data in resource_items:
                try:
                    if self.app.resource_manager.delete_resource(data["resource_type"], data["resource_id"]):
                        success_count += 1
                except RuntimeError:
                    # Item was deleted, skip it
                    continue
            
            if success_count > 0:
                # Signals will trigger remove_single_resource for each deleted resource, no need to refresh
                if success_count < len(resource_items):
                    QMessageBox.warning(self, "Delete Warning", f"Only {success_count} of {len(resource_items)} resources were deleted")
    
    def rename_folder(self, item):
        """Rename a folder"""
        data = item.data(0, Qt.UserRole)
        if not data or data.get("type") != "folder":
            return
        
        current_name = item.text(0).split(" ", 1)[1]  # Remove icon
        new_name, ok = QInputDialog.getText(self, "Rename Folder", "New name:", text=current_name)
        if not ok or not new_name or new_name == current_name:
            return
        
        try:
            # Get the folder paths
            project_path = self.app.project_manager.get_project_path()
            if not project_path:
                QMessageBox.critical(self, "Error", "No project loaded")
                return
            
            resource_folder_map = {
                "sprites": "Sprites",
                "backgrounds": "Backgrounds", 
                "objects": "Objects",
                "sounds": "Sounds",
                "rooms": "Rooms",
                "textures": "Textures",
                "models": "Models",
                "shaders": "Shaders",
                "particles": "Particles",
                "scripts": "Scripts"
            }
            
            resource_folder = resource_folder_map.get(data["resource_type"], "Sprites")
            base_path = os.path.join(project_path, "Resources", resource_folder)
            
            old_path = os.path.join(base_path, data["folder"])
            new_path = os.path.join(base_path, new_name)
            
            # Check if new name already exists
            if os.path.exists(new_path):
                QMessageBox.warning(self, "Name Exists", f"A folder with the name '{new_name}' already exists")
                return
            
            # Check if old folder exists
            if not os.path.exists(old_path):
                QMessageBox.warning(self, "Warning", f"Folder '{current_name}' not found on disk")
                return
            
            # Rename the folder on disk
            os.rename(old_path, new_path)
            
            # Update parent_folder in all resources that reference this folder
            resource_type = data["resource_type"]
            resources = self.app.project_manager.get_resources(resource_type)
            
            updated_count = 0
            for resource in resources:
                current_parent = resource.get("parent_folder", "")
                
                # Handle nested folders (e.g., "Parent/Child" -> "Parent/NewChild")
                if current_parent == data["folder"]:
                    # Direct match - simple rename
                    resource["parent_folder"] = new_name
                    updated_count += 1
                elif current_parent.startswith(data["folder"] + "/"):
                    # Nested folder - update the prefix
                    remaining_path = current_parent[len(data["folder"]) + 1:]
                    resource["parent_folder"] = new_name + "/" + remaining_path
                    updated_count += 1
                
                # Save the updated resource
                if resource.get("parent_folder") != current_parent:
                    self.app.resource_manager.save_resource(resource_type, resource)
            
            # Update the project file
            self.app.project_manager.save_project()
            
            QMessageBox.information(self, "Success", 
                f"Folder renamed to '{new_name}' successfully.\n"
                f"Updated {updated_count} resource(s).")
            
            # Refresh the entire tree to show updated folder structure
            self.refresh()
            
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to rename folder: {str(e)}")
    
    def create_folder(self, resource_type, parent_folder=""):
        """Create a new folder"""
        folder_name, ok = QInputDialog.getText(self, "Create Folder", "Folder name:")
        if not ok or not folder_name:
            return
        
        # Get the correct folder name for the resource type
        resource_folder_map = {
            "sprites": "Sprites",
            "backgrounds": "Backgrounds",
            "textures": "Textures",
            "objects": "Objects",
            "sounds": "Sounds",
            "models": "Models",
            "rooms": "Rooms",
            "shaders": "Shaders",
            "particles": "Particles",
            "scripts": "Scripts"
        }
        
        resource_folder = resource_folder_map.get(resource_type, "Sprites")
        
        # Create folder path
        base_path = os.path.join(self.app.project_manager.get_project_path(), "Resources", resource_folder)
        if parent_folder:
            base_path = os.path.join(base_path, parent_folder)
        
        folder_path = os.path.join(base_path, folder_name)
        
        # Check if folder already exists
        if os.path.exists(folder_path):
            QMessageBox.warning(self, "Folder Exists", "A folder with this name already exists")
            return
        
        try:
            os.makedirs(folder_path, exist_ok=True)
            # Refresh just the parent item to show the new folder
            if resource_type in self.resource_items:
                type_item = self.resource_items[resource_type]
                if parent_folder:
                    # Find the parent folder item and refresh it
                    parent_folder_item = self._find_folder_item(type_item, parent_folder)
                    if parent_folder_item:
                        self.refresh_parent_item(parent_folder_item)
                    else:
                        # Folder not found, refresh the type
                        self.refresh_resource_type(resource_type)
                else:
                    # No parent folder, refresh the type
                    self.refresh_resource_type(resource_type)
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to create folder: {str(e)}")
    
    def folder_exists(self, resource_type, folder_name, parent_folder=""):
        """Check if a folder already exists"""
        # This is a simplified check - in a real implementation you'd check the actual filesystem
        return False
    
    def cut_folder(self, item):
        """Cut a folder to clipboard"""
        data = item.data(0, Qt.UserRole)
        if data and data.get("type") == "folder":
            # Store the folder data properly
            folder_data = {
                "type": "folder",
                "resource_type": data["resource_type"],
                "folder": data["folder"]
            }
            self.clipboard_manager.cut_item(folder_data, "folder")
            item.setBackground(0, QColor(200, 200, 200))  # Visual feedback
    
    def copy_folder(self, item):
        """Copy a folder to clipboard"""
        data = item.data(0, Qt.UserRole)
        if data and data.get("type") == "folder":
            # Store the folder data properly
            folder_data = {
                "type": "folder",
                "resource_type": data["resource_type"],
                "folder": data["folder"]
            }
            self.clipboard_manager.copy_item(folder_data, "folder")
    
    def delete_folder(self, item=None):
        """Delete a folder"""
        # Get all selected items
        selected_items = self.selectedItems()
        if not selected_items:
            return
        
        # Filter for folder items only
        folder_items = []
        for selected_item in selected_items:
            try:
                data = selected_item.data(0, Qt.UserRole)
                if data and data.get("type") == "folder":
                    folder_items.append((selected_item, data))
            except RuntimeError:
                # Item was deleted, skip it
                continue
        
        if not folder_items:
            return
        
        # Show confirmation dialog
        if len(folder_items) == 1:
            folder_name = folder_items[0][0].text(0).split(" ", 1)[1]
            reply = QMessageBox.question(self, "Delete Folder", 
                                       f"Are you sure you want to delete folder '{folder_name}' and all its contents?",
                                       QMessageBox.Yes | QMessageBox.No)
        else:
            reply = QMessageBox.question(self, "Delete Folders", 
                                       f"Are you sure you want to delete {len(folder_items)} folders and all their contents?",
                                       QMessageBox.Yes | QMessageBox.No)
        
        if reply == QMessageBox.Yes:
            # Clear all thumbnails/icons from tree items before deletion to release file handles
            # This prevents "file in use" errors
            for i in range(self.topLevelItemCount()):
                top_item = self.topLevelItem(i)
                if top_item:
                    self._clear_item_icons(top_item)
            
            success_count = 0
            for item, data in folder_items:
                try:
                    # Get the folder path
                    project_path = self.app.project_manager.get_project_path()
                    if not project_path:
                        continue
                    
                    resource_folder_map = {
                        "sprites": "Sprites",
                        "backgrounds": "Backgrounds",
                        "textures": "Textures",
                        "objects": "Objects",
                        "sounds": "Sounds",
                        "models": "Models",
                        "rooms": "Rooms"
                    }
                    
                    resource_folder = resource_folder_map.get(data["resource_type"], "Sprites")
                    folder_path = os.path.join(
                        project_path,
                        "Resources",
                        resource_folder,
                        data["folder"]
                    )
                    
                    # Check if folder exists
                    if os.path.exists(folder_path):
                        # Delete the folder and all its contents
                        import shutil
                        shutil.rmtree(folder_path)
                        success_count += 1
                
                except Exception as e:
                    QMessageBox.warning(self, "Delete Warning", f"Failed to delete folder '{data['folder']}': {str(e)}")
            
            if success_count > 0:
                # Refresh affected resource types
                affected_types = set()
                for item, data in folder_items:
                    affected_types.add(data["resource_type"])
                for resource_type in affected_types:
                    self.refresh_resource_type(resource_type)
                if success_count < len(folder_items):
                    QMessageBox.warning(self, "Delete Warning", f"Only {success_count} of {len(folder_items)} folders were deleted")
    
    def _clear_item_icons(self, item):
        """Recursively clear icons from tree items to release file handles"""
        if item:
            # Clear icon to release QPixmap/QImage handle
            item.setIcon(0, QIcon())
            
            # Recursively clear child icons
            for i in range(item.childCount()):
                child = item.child(i)
                if child:
                    self._clear_item_icons(child)
    
    def has_clipboard_data(self):
        """Check if there's data in the clipboard"""
        return self.clipboard_manager.has_data()
    
    def paste_resource(self, item):
        """Paste a resource from clipboard"""
        if not self.clipboard_manager.has_data():
            QMessageBox.information(self, "Paste", "No item in clipboard")
            return
        
        data = item.data(0, Qt.UserRole)
        if not data:
            QMessageBox.warning(self, "Paste", "Invalid target location")
            return
        
        try:
            # Determine target location
            target_data = {
                "type": data.get("type"),
                "resource_type": data.get("resource_type"),
                "folder": data.get("folder", "")
            }
            
            # Perform paste operation
            if self.clipboard_manager.paste_item(target_data, self.app.resource_manager, self.app.project_manager):
                # Signals will trigger add_single_resource or update_single_resource, no need to refresh
                pass
            else:
                QMessageBox.warning(self, "Paste", "Failed to paste item")
        except Exception as e:
            QMessageBox.critical(self, "Paste Error", f"Error pasting item: {str(e)}")
    
    def dragEnterEvent(self, event):
        """Handle drag enter event"""
        if event.source() == self:
            event.accept()
        else:
            event.ignore()
    
    def dropEvent(self, event):
        """Handle drop event"""
        if event.source() != self:
            event.ignore()
            return
        
        # Get source and target items
        source_item = self.currentItem()
        target_item = self.itemAt(event.pos())
        
        if not source_item or not target_item:
            event.ignore()
            return
        
        source_data = source_item.data(0, Qt.UserRole)
        target_data = target_item.data(0, Qt.UserRole)
        
        if not source_data or not target_data:
            event.ignore()
            return
        
        # Handle different drop scenarios
        if (source_data.get("type") == "resource" and 
            target_data.get("type") in ["resource_type", "folder"]):
            # Move resource to folder
            resource_type = source_data["resource_type"]
            resource_id = source_data["resource_id"]
            
            if target_data.get("type") == "folder":
                new_folder = target_data["folder"]
            else:
                new_folder = ""
            
            if self.app.resource_manager.move_resource(resource_type, resource_id, new_folder):
                # Signal will trigger update_single_resource which handles moves, no need to refresh
                event.accept()
            else:
                event.ignore()
        else:
            event.ignore()
    
    def on_resource_updated(self, resource_type, resource_data):
        """Handle resource updated signal - use targeted update"""
        from Core.Debug import debug
        debug(f"DEBUG: ResourceTree received resource_updated signal for {resource_type} {resource_data.get('name', 'NO_NAME')}")
        # Check if parent_folder changed (resource moved)
        resource_id = resource_data.get("id")
        if resource_id:
            existing_item = self._find_resource_item(resource_type, resource_id)
            if existing_item:
                old_data = existing_item.resource_data if hasattr(existing_item, 'resource_data') else {}
                old_folder = old_data.get("parent_folder", "")
                new_folder = resource_data.get("parent_folder", "")
                
                # If folder changed, need to move the item
                if old_folder != new_folder:
                    self._move_resource_item(resource_type, resource_id, old_folder, new_folder)
               
                else:
                    # Just update in place
                    self.update_single_resource(resource_type, resource_data)
            else:
                # Item not found, might be new or moved - use update which will add if missing
                self.update_single_resource(resource_type, resource_data)
    
    def on_resource_created(self, resource_type, resource_data):
        """Handle resource created signal - use targeted update"""
        from Core.Debug import debug
        debug(f"DEBUG: ResourceTree received resource_created signal for {resource_type} {resource_data.get('name', 'NO_NAME')}")
        self.add_single_resource(resource_type, resource_data)
    
    def on_resource_deleted(self, resource_type, resource_id):
        """Handle resource deleted signal - use targeted update"""
        from Core.Debug import debug
        debug(f"DEBUG: ResourceTree received resource_deleted signal for {resource_type} {resource_id}")
        self.remove_single_resource(resource_type, resource_id)
    
    def _move_resource_item(self, resource_type, resource_id, old_folder, new_folder):
        """Move a resource item from one folder to another"""
        item = self._find_resource_item(resource_type, resource_id)
        if not item:
            return
        
        # Get resource data
        resource_data = item.resource_data if hasattr(item, 'resource_data') else {}
        if not resource_data:
            # Try to load from runtime
            runtime_resources = self.app.project_manager.runtime_resources
            resources = runtime_resources.get(resource_type, {})
            resource_data = resources.get(resource_id, {})
        
        if not resource_data:
            return
        
        # Remove from old location
        parent = item.parent()
        if parent:
            parent.removeChild(item)
        else:
            type_item = self.resource_items.get(resource_type)
            if type_item:
                type_item.removeChild(item)
        
        # Remove from thumbnail cache
        key = (resource_type, resource_id)
        if key in self.thumbnail_items:
            del self.thumbnail_items[key]
        
        # Add to new location
        self.add_single_resource(resource_type, resource_data)
    
    def _setup_editor_listeners(self):
        """
        Set up listeners for editor signals so ResourceTree updates in real-time.
        This ensures ResourceTree reflects changes immediately without needing to save project.
        """
        try:
            if hasattr(self.app, "main_window") and hasattr(self.app.main_window, "editor_changed"):
                # When editor changes, disconnect old listeners and connect new ones
                def on_editor_changed(editor):
                    self._on_active_editor_changed(editor)
                
                self.app.main_window.editor_changed.connect(on_editor_changed)
        except Exception:
            pass
    
    def _on_active_editor_changed(self, editor):
        """
        Called when the active editor changes.
        Connect to the editor's signals so we can update tree items in real-time.
        """
        try:
            # Disconnect from any previously active editor
            if hasattr(self, "_current_editor") and self._current_editor:
                try:
                    if hasattr(self._current_editor, "sprite_changed"):
                        self._current_editor.sprite_changed.disconnect(self._on_object_sprite_changed)
                except Exception:
                    pass
            
            # Connect to new editor if it's an ObjectEditor
            self._current_editor = editor
            if editor and hasattr(editor, "sprite_changed"):
                editor.sprite_changed.connect(self._on_object_sprite_changed)
        except Exception:
            pass
    
    def _on_object_sprite_changed(self, object_name, sprite_name):
        """
        Called when an object's sprite is changed.
        Update the ResourceTree item thumbnail immediately.
        """
        try:
            # Find the object item in the tree
            obj_item = self._find_resource_item("object", object_name)
            if obj_item:
                # Reload the thumbnail for this object
                self._refresh_object_thumbnail(obj_item, sprite_name)
        except Exception:
            pass
    
    def _find_resource_item(self, resource_type, resource_name):
        """
        Recursively search tree for a resource item by type and name.
        """
        try:
            def search(parent):
                for i in range(parent.childCount()):
                    child = parent.child(i)
                    if child:
                        try:
                            # Check if this item matches
                            item_data = child.data(0, Qt.UserRole)
                            if isinstance(item_data, dict):
                                if (item_data.get("type") == resource_type and 
                                    item_data.get("name") == resource_name):
                                    return child
                        except Exception:
                            pass
                        
                        # Recursively search children
                        result = search(child)
                        if result:
                            return result
                return None
            
            root = self.invisibleRootItem()
            return search(root)
        except Exception:
            return None
    
    def _refresh_object_thumbnail(self, obj_item, sprite_name):
        """
        Refresh the thumbnail for an object item based on its assigned sprite.
        """
        try:
            # Clear old icon
            obj_item.setIcon(0, QIcon())
            
            if not sprite_name:
                # No sprite, use default paper icon
                default_icon = self._get_default_icon("object")
                if default_icon:
                    obj_item.setIcon(0, default_icon)
                return
            
            # Load sprite thumbnail
            sprite_pixmap = self._load_sprite_thumbnail(sprite_name)
            if sprite_pixmap and not sprite_pixmap.isNull():
                icon = QIcon(sprite_pixmap)
                obj_item.setIcon(0, icon)
            else:
                # Fallback to default icon if sprite load fails
                default_icon = self._get_default_icon("object")
                if default_icon:
                    obj_item.setIcon(0, default_icon)
        except Exception:
            pass
    
    def _load_sprite_thumbnail(self, sprite_name):
        """
        Load sprite thumbnail as QPixmap.
        Handles sprites in nested folders.
        """
        try:
            if not hasattr(self.app, "resource_manager"):
                return None
            
            rm = self.app.resource_manager
            
            # Load sprite resource
            sprite_data = rm.load_resource("sprite", sprite_name)
            if not isinstance(sprite_data, dict):
                return None
            
            frames = sprite_data.get("frames", [])
            if not frames or not frames[0]:
                return None
            
            frame_path = frames[0]
            frame_full_path = Path(frame_path)
            
            # If path is relative, resolve it
            if not frame_full_path.is_absolute():
                if hasattr(self.app, "project_manager"):
                    project_root = self.app.project_manager.current_project_path
                    if project_root:
                        frame_full_path = Path(project_root) / frame_path
            
            # Load pixmap
            if frame_full_path.exists():
                pixmap = QPixmap(str(frame_full_path))
                if not pixmap.isNull():
                    # Scale to tree item height (16px)
                    scaled = pixmap.scaledToHeight(16, Qt.SmoothTransformation)
                    return scaled
        except Exception:
            pass
        
        return None
    
    def _get_default_icon(self, resource_type):
        """Get default icon for resource type"""
        try:
            # Return standard icons or cached defaults
            # This depends on your existing icon implementation
            if resource_type == "object":
                # Paper/document icon for objects with no sprite
                from PySide6.QtWidgets import QStyle, QApplication
                style = QApplication.style()
                return style.standardIcon(QStyle.SP_FileIcon)
        except Exception:
            pass
        return None
