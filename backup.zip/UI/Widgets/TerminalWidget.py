"""
Terminal Widget for PyGenesis IDE
Displays Python debug output and terminal information
"""

import sys
import time
from PySide6.QtWidgets import QTextEdit, QWidget, QVBoxLayout
from PySide6.QtCore import Qt, QTimer, Signal, QObject
from PySide6.QtGui import QFont, QTextCharFormat, QColor, QTextCursor

class TerminalTextStream(QObject):
    """Custom text stream that emits signals for text output"""
    text_written = Signal(str)
    
    def __init__(self, terminal_widget):
        super().__init__()
        self.terminal_widget = terminal_widget
    
    def write(self, text):
        """Write text to terminal widget"""
        if text:
            self.text_written.emit(text)
    
    def flush(self):
        """Flush stream (no-op for signals)"""
        pass
    
    def isatty(self):
        """Return False to indicate this is not a TTY"""
        return False

class TerminalWidget(QWidget):
    """Terminal widget that displays Python output with theme support"""
    
    def __init__(self, app, parent=None):
        super().__init__(parent)
        self.app = app
        self.text_edit = None
        self.original_stdout = sys.stdout
        self.original_stderr = sys.stderr
        self.stdout_stream = None
        self.stderr_stream = None
        self.streams_ready = False
        
        # Deduplication state
        self.last_message = None
        self.last_message_time = 0
        self.duplicate_count = 0
        self.deduplication_window = 0.5  # 500ms window for duplicates
        self.text_buffer = ""  # Buffer for incomplete lines
        
        self.setup_ui()
        self.apply_theme()
        
        # Setup streams after UI is ready, using a timer to ensure Qt is ready
        QTimer.singleShot(100, self.setup_streams)
    
    def setup_ui(self):
        """Setup the terminal UI"""
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        
        # Create text edit for terminal output
        self.text_edit = QTextEdit(self)
        self.text_edit.setReadOnly(True)
        self.text_edit.setFont(self.get_editor_font())
        layout.addWidget(self.text_edit)
    
    def setup_streams(self):
        """Setup custom streams for stdout/stderr"""
        try:
            # Create terminal streams
            self.stdout_stream = TerminalTextStream(self)
            self.stdout_stream.text_written.connect(self.append_text)
            
            self.stderr_stream = TerminalTextStream(self)
            self.stderr_stream.text_written.connect(self.append_error_text)
            
            # Redirect stdout and stderr
            sys.stdout = self.stdout_stream
            sys.stderr = self.stderr_stream
            self.streams_ready = True
        except Exception as e:
            # If stream setup fails, restore original streams
            sys.stdout = self.original_stdout
            sys.stderr = self.original_stderr
            # Use original stdout to report error (avoid circular dependency)
            if self.original_stdout:
                try:
                    self.original_stdout.write(f"Failed to setup terminal streams: {e}\n")
                    self.original_stdout.flush()
                except:
                    pass
    
    def get_editor_font(self):
        """Get editor font from preferences"""
        font_family = self.app.settings.get("Editor_Font_Family", "Consolas")
        font_size = self.app.settings.get("Editor_Font_Size", 10)
        
        font = QFont(font_family, font_size)
        font.setFixedPitch(True)
        return font
    
    def append_text(self, text):
        """Append regular text to terminal with deduplication"""
        if not self.text_edit:
            return
        try:
            # Add to buffer
            self.text_buffer += text
            
            # Process complete lines
            while '\n' in self.text_buffer:
                line, self.text_buffer = self.text_buffer.split('\n', 1)
                self._append_line(line + '\n', is_error=False)
            
            # If buffer is getting too large, flush it
            if len(self.text_buffer) > 1000:
                self._append_line(self.text_buffer, is_error=False)
                self.text_buffer = ""
        except Exception as e:
            # Fallback to original stdout if terminal fails
            if self.original_stdout:
                self.original_stdout.write(text)
                self.original_stdout.flush()
    
    def _append_line(self, line, is_error=False):
        """Append a complete line with deduplication"""
        if not self.text_edit:
            return
        
        current_time = time.time()
        line_stripped = line.strip()
        
        # Skip empty lines for deduplication
        if not line_stripped:
            self.text_edit.moveCursor(QTextCursor.MoveOperation.End)
            if is_error:
                colors = self.app.theme_manager.get_colors()
                error_color = colors.get("error", "#f44336")
                format = QTextCharFormat()
                format.setForeground(QColor(error_color))
                cursor = self.text_edit.textCursor()
                cursor.setCharFormat(format)
                cursor.insertText(line)
            else:
                self.text_edit.insertPlainText(line)
            self.text_edit.moveCursor(QTextCursor.MoveOperation.End)
            return
        
        # Check if this is a duplicate within the time window
        if (line_stripped == self.last_message and 
            current_time - self.last_message_time < self.deduplication_window):
            self.duplicate_count += 1
            
            # Find and update the last line
            cursor = self.text_edit.textCursor()
            cursor.movePosition(QTextCursor.MoveOperation.End)
            
            # Move to start of last line
            cursor.movePosition(QTextCursor.MoveOperation.StartOfBlock)
            cursor.movePosition(QTextCursor.MoveOperation.End, QTextCursor.MoveMode.KeepAnchor)
            
            old_text = cursor.selectedText()
            if old_text and not old_text.endswith(f" (repeated {self.duplicate_count} times)"):
                # Remove old line and add with count
                cursor.removeSelectedText()
                if is_error:
                    colors = self.app.theme_manager.get_colors()
                    error_color = colors.get("error", "#f44336")
                    format = QTextCharFormat()
                    format.setForeground(QColor(error_color))
                    cursor.setCharFormat(format)
                    cursor.insertText(f"{line_stripped} (repeated {self.duplicate_count} times)\n")
                else:
                    cursor.insertText(f"{line_stripped} (repeated {self.duplicate_count} times)\n")
            elif old_text.endswith(f" (repeated {self.duplicate_count - 1} times)"):
                # Update the count
                cursor.removeSelectedText()
                if is_error:
                    colors = self.app.theme_manager.get_colors()
                    error_color = colors.get("error", "#f44336")
                    format = QTextCharFormat()
                    format.setForeground(QColor(error_color))
                    cursor.setCharFormat(format)
                    cursor.insertText(f"{line_stripped} (repeated {self.duplicate_count} times)\n")
                else:
                    cursor.insertText(f"{line_stripped} (repeated {self.duplicate_count} times)\n")
            
            cursor.movePosition(QTextCursor.MoveOperation.End)
            self.text_edit.setTextCursor(cursor)
            return
        
        # New message or time window expired - reset duplicate tracking
        if (line_stripped != self.last_message or 
            current_time - self.last_message_time >= self.deduplication_window):
            self.duplicate_count = 0
            self.last_message = line_stripped
            self.last_message_time = current_time
        
        # Append the line normally
        self.text_edit.moveCursor(QTextCursor.MoveOperation.End)
        if is_error:
            colors = self.app.theme_manager.get_colors()
            error_color = colors.get("error", "#f44336")
            format = QTextCharFormat()
            format.setForeground(QColor(error_color))
            cursor = self.text_edit.textCursor()
            cursor.setCharFormat(format)
            cursor.insertText(line)
            format.setForeground(QColor(colors.get("foreground", "#ffffff")))
            cursor.setCharFormat(format)
        else:
            self.text_edit.insertPlainText(line)
        
        self.text_edit.moveCursor(QTextCursor.MoveOperation.End)
        self.text_edit.ensureCursorVisible()
    
    def append_error_text(self, text):
        """Append error text to terminal with error color and deduplication"""
        if not self.text_edit:
            return
        try:
            # Add to buffer (errors use same buffer as regular text)
            self.text_buffer += text
            
            # Process complete lines
            while '\n' in self.text_buffer:
                line, self.text_buffer = self.text_buffer.split('\n', 1)
                self._append_line(line + '\n', is_error=True)
            
            # If buffer is getting too large, flush it
            if len(self.text_buffer) > 1000:
                self._append_line(self.text_buffer, is_error=True)
                self.text_buffer = ""
        except Exception as e:
            # Fallback to original stderr if terminal fails
            if self.original_stderr:
                self.original_stderr.write(text)
                self.original_stderr.flush()
    
    def apply_theme(self):
        """Apply theme colors and font settings"""
        if not self.text_edit:
            return
        
        try:
            colors = self.app.theme_manager.get_colors()
            
            # Get editor font
            font = self.get_editor_font()
            self.text_edit.setFont(font)
            
            # Apply colors
            background_color = colors.get("editor_background", colors.get("background", "#1e1e1e"))
            text_color = colors.get("editor_text", colors.get("foreground", "#ffffff"))
            
            # Set stylesheet
            self.text_edit.setStyleSheet(f"""
                QTextEdit {{
                    background-color: {background_color};
                    color: {text_color};
                    border: 1px solid {colors.get("border", "#555555")};
                    font-family: '{font.family()}';
                    font-size: {font.pointSize()}pt;
                }}
            """)
            
            # Set text color format for existing text
            # Note: In PySide6, we can't easily format all existing text without selectAll()
            # The stylesheet above will handle colors for future text, so we just ensure
            # the cursor is at the end
            cursor = self.text_edit.textCursor()
            cursor.movePosition(QTextCursor.MoveOperation.End)
            self.text_edit.setTextCursor(cursor)
        except Exception as e:
            # Use original stdout to report error (avoid circular dependency)
            if self.original_stdout:
                try:
                    self.original_stdout.write(f"Error applying theme to terminal: {e}\n")
                    self.original_stdout.flush()
                except:
                    pass
    
    def clear(self):
        """Clear terminal output"""
        if self.text_edit:
            self.text_edit.clear()
    
    def closeEvent(self, event):
        """Restore original stdout/stderr on close"""
        try:
            if self.streams_ready:
                sys.stdout = self.original_stdout
                sys.stderr = self.original_stderr
        except Exception:
            pass
        super().closeEvent(event)

