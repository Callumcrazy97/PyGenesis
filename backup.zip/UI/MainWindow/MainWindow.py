"""
Main Window for Python Game IDE
GameMaker-style interface with resource tree and editors
"""

from PySide6.QtWidgets import (QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, 
                               QSplitter, QTreeWidget, QTreeWidgetItem, QTextEdit,
                               QMenuBar, QMenu, QToolBar, QStatusBar,
                               QMessageBox, QFileDialog, QInputDialog, QTabWidget,
                               QDockWidget, QLabel, QPushButton, QFrame, QProgressDialog, QDialog)
from PySide6.QtCore import Qt, QTimer, QSettings, QCoreApplication, Signal
from PySide6.QtGui import QIcon, QKeySequence, QAction, QPixmap, QPainter, QColor, QFont

import os
import subprocess
import sys
import json
from pathlib import Path

from Core.EditorFactory import EditorFactory
from UI.Widgets.ResourceTree import ResourceTree
from UI.CommonDialogs.PreferencesDialog import PreferencesDialog
from UI.Widgets.TerminalWidget import TerminalWidget
from UI.Widgets.LoadingWidget import LoadingWidget
from Core.Debug import debug

from PySide6.QtCore import QThread, Signal, QMutex, QMutexLocker
import time
import zlib
import numpy as np
from PIL import Image
import mss

# Import screen recorder from Tools
try:
    from Tools.ScreenRecording.screen_recorder import ScreenCaptureThread, GifProcessingThread
except ImportError:
    # Fallback if screen recorder not available
    ScreenCaptureThread = None
    GifProcessingThread = None


class BackgroundScreenRecorder(QThread):
    """Background screen recorder that auto-saves when file size exceeds limit"""
    
    file_saved = Signal(str)  # Emits file path when a file is saved
    recording_stopped = Signal()  # Emits when recording is stopped
    
    def __init__(self, recordings_folder, session_name):
        super().__init__()
        self.recordings_folder = Path(recordings_folder)
        self.session_name = session_name
        self.is_recording = False
        self.is_paused = False
        self.mutex = QMutex()
        
        # Recording settings (defaults)
        self.capture_rate = 8  # fps
        self.target_width = 800
        self.target_height = 600
        self.max_colors = 128
        
        # Current recording state
        self.frames = []  # List of compressed frames
        self.frame_shapes = []  # List of frame shapes
        self.current_file_index = 1  # Start at 1 for _1, _2, _3 suffixes
        
        # File size limit (10MB)
        self.max_file_size = 10 * 1024 * 1024  # 10MB in bytes
        
        # MSS setup
        self.sct = None
        self.monitor = None
        
    def start_recording(self):
        """Start recording"""
        with QMutexLocker(self.mutex):
            self.is_recording = True
            self.is_paused = False
            self.frames.clear()
            self.frame_shapes.clear()
            # Don't reset current_file_index here - it's set by the caller based on existing files
    
    def stop_recording(self):
        """Stop recording"""
        with QMutexLocker(self.mutex):
            self.is_recording = False
    
    def run(self):
        """Main recording loop"""
        # Initialize MSS
        self.sct = mss.mss()
        self.monitor = self.sct.monitors[1]  # Primary monitor
        
        frame_interval = 1.0 / self.capture_rate
        
        while True:
            with QMutexLocker(self.mutex):
                if not self.is_recording:
                    break
                if self.is_paused:
                    continue
            
            start_time = time.time()
            
            # Capture screen
            screenshot = self.sct.grab(self.monitor)
            img_array = np.array(screenshot)
            
            # Convert BGRA to RGB
            if img_array.shape[2] == 4:
                img_array = img_array[:, :, [2, 1, 0]]
            else:
                img_array = img_array[:, :, [2, 1, 0]]
            
            # Resize and compress frame
            original_height, original_width = img_array.shape[:2]
            if original_width > self.target_width or original_height > self.target_height:
                aspect_ratio = original_width / original_height
                if original_width > original_height:
                    new_width = self.target_width
                    new_height = int(self.target_width / aspect_ratio)
                else:
                    new_height = self.target_height
                    new_width = int(self.target_height * aspect_ratio)
                
                img_pil = Image.fromarray(img_array, 'RGB')
                img_pil = img_pil.resize((new_width, new_height), Image.Resampling.LANCZOS)
                img_array = np.array(img_pil)
            
            # Color quantization
            img_pil = Image.fromarray(img_array, 'RGB')
            img_pil = img_pil.quantize(colors=self.max_colors, method=Image.MEDIANCUT)
            img_pil = img_pil.convert('RGB')
            img_array = np.array(img_pil)
            
            # Compress and store frame
            compressed_frame = zlib.compress(img_array.tobytes(), level=6)
            
            should_save = False
            with QMutexLocker(self.mutex):
                if self.is_recording and not self.is_paused:
                    self.frames.append(compressed_frame)
                    self.frame_shapes.append(img_array.shape)
                    
                    # Check file size estimate and save if needed
                    estimated_size = self.estimate_file_size()
                    if estimated_size > self.max_file_size and len(self.frames) > 10:
                        should_save = True
            
            # Save outside the mutex to avoid blocking
            if should_save:
                self.save_current_recording()
            
            # Maintain FPS
            elapsed = time.time() - start_time
            sleep_time = max(0, frame_interval - elapsed)
            time.sleep(sleep_time)
        
        # Save final recording when stopping (only if we have at least 10 frames)
        frames_copy = []
        shapes_copy = []
        file_path = None
        
        with QMutexLocker(self.mutex):
            if self.frames and len(self.frames) >= 10:  # Minimum 10 frames required
                # Generate filename for final save using consistent naming: name_1, name_2, etc.
                filename = f"{self.session_name}_{self.current_file_index}.gif"
                file_path = self.recordings_folder / filename
                
                # Get copies
                frames_copy = self.frames.copy()
                shapes_copy = self.frame_shapes.copy()
                
                # Clear frames immediately to prevent reuse
                self.frames.clear()
                self.frame_shapes.clear()
        
        # Save outside lock if we had frames
        if frames_copy and file_path:
            pil_frames = []
            for compressed_frame, shape in zip(frames_copy, shapes_copy):
                decompressed = zlib.decompress(compressed_frame)
                img_array = np.frombuffer(decompressed, dtype=np.uint8).reshape(shape)
                img = Image.fromarray(img_array, mode='RGB')
                pil_frames.append(img)
            
            # Save GIF
            duration = int(1000 / self.capture_rate)
            if pil_frames:
                pil_frames[0].save(
                    str(file_path),
                    save_all=True,
                    append_images=pil_frames[1:],
                    duration=duration,
                    loop=0,
                    optimize=True,
                    method=6
                )
            
            # Emit signal
            self.file_saved.emit(str(file_path))
        
        # Cleanup
        if self.sct:
            try:
                self.sct.close()
            except:
                pass
        
        self.recording_stopped.emit()
    
    def estimate_file_size(self):
        """Estimate current file size in bytes"""
        # Rough estimate: compressed frames + overhead
        total_compressed = sum(len(f) for f in self.frames)
        # Add overhead for GIF format (~10%)
        return int(total_compressed * 1.1)
    
    def save_current_recording(self):
        """Save current frames to a file (auto-save when file size limit reached)"""
        # Get a copy of frames outside the lock
        frames_copy = []
        shapes_copy = []
        file_path = None
        file_index = None
        
        with QMutexLocker(self.mutex):
            if not self.frames or len(self.frames) < 10:  # Minimum 10 frames required
                return
            
            # Get copies of frames
            frames_copy = self.frames.copy()
            shapes_copy = self.frame_shapes.copy()
            
            # Generate filename using consistent naming: name_1, name_2, etc.
            file_index = self.current_file_index
            filename = f"{self.session_name}_{file_index}.gif"
            file_path = self.recordings_folder / filename
            
            # Clear frames IMMEDIATELY to prevent reuse in next recording
            self.frames.clear()
            self.frame_shapes.clear()
            
            # Increment file index AFTER clearing frames
            self.current_file_index += 1
        
        # Process frames and save (outside lock)
        if frames_copy and file_path:
            pil_frames = []
            for compressed_frame, shape in zip(frames_copy, shapes_copy):
                decompressed = zlib.decompress(compressed_frame)
                img_array = np.frombuffer(decompressed, dtype=np.uint8).reshape(shape)
                img = Image.fromarray(img_array, mode='RGB')
                pil_frames.append(img)
            
            # Save GIF
            duration = int(1000 / self.capture_rate)
            if pil_frames:
                pil_frames[0].save(
                    str(file_path),
                    save_all=True,
                    append_images=pil_frames[1:],
                    duration=duration,
                    loop=0,
                    optimize=True,
                    method=6
                )
            
            # Emit signal
            self.file_saved.emit(str(file_path))


class MainWindow(QMainWindow):
    def __init__(self, app):
        super().__init__()
        self.app = app
        self.current_editor = None
        self.recorder_window = None  # Track recording window (legacy - for UI version)
        self.background_recorder = None  # Background recording thread
        self.is_recording = False  # Recording state
        self.current_recording_file = None  # Current recording file path
        self.setup_ui()
        self.setup_connections()
        self.setup_menus()
        self.setup_toolbar()
        self.setup_status_bar()
        
        # Initialize recording menu state
        self.update_recording_menu()
        
        # Set window properties
        self.setWindowTitle("Python Game IDE - No Project")
        self.setMinimumSize(1200, 800)
        self.resize(1400, 900)
        
        # Load settings
        self.load_settings()
        
        # Apply theme
        self.apply_theme()
    
    def setup_ui(self):
        """Setup the main user interface"""
        # Central widget
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        
        # Main layout
        main_layout = QHBoxLayout(central_widget)
        main_layout.setContentsMargins(0, 0, 0, 0)
        
        # Create main splitter
        main_splitter = QSplitter(Qt.Horizontal)
        main_layout.addWidget(main_splitter)
        
        # Left panel - Resource tree
        self.resource_tree = ResourceTree(self.app)
        resource_dock = QDockWidget("Resources", self)
        resource_dock.setObjectName("Resources")  # Required for saveState/restoreState
        resource_dock.setWidget(self.resource_tree)
        resource_dock.setFeatures(QDockWidget.DockWidgetMovable | QDockWidget.DockWidgetFloatable)
        self.addDockWidget(Qt.LeftDockWidgetArea, resource_dock)
        
        # Center panel - Editor area
        self.editor_tabs = QTabWidget()
        self.editor_tabs.setTabsClosable(True)
        self.editor_tabs.tabCloseRequested.connect(self.close_editor_tab)
        main_splitter.addWidget(self.editor_tabs)
        
        # Right panel - Properties (removed - unused)
        
        # Set splitter proportions (no right panel)
        main_splitter.setSizes([300, 800])
        
        # Bottom panel - Terminal
        self.terminal_widget = TerminalWidget(self.app, self)
        self.terminal_dock = QDockWidget("Terminal", self)
        self.terminal_dock.setObjectName("Terminal")  # Required for saveState/restoreState
        self.terminal_dock.setWidget(self.terminal_widget)
        self.terminal_dock.setFeatures(QDockWidget.DockWidgetMovable | QDockWidget.DockWidgetFloatable)
        
        # Set initial terminal dock size (will be overridden by saved state if available)
        self.addDockWidget(Qt.BottomDockWidgetArea, self.terminal_dock)
        # Set a reasonable default height for terminal (will be restored from state if available)
        self.terminal_dock.setMinimumHeight(100)
    
    def setup_connections(self):
        """Setup signal connections"""
        # Project manager signals
        self.app.project_manager.project_loaded.connect(self.on_project_loaded)
        self.app.project_manager.project_created.connect(self.on_project_created)
        self.app.project_manager.resources_loaded.connect(self.on_resources_loaded)
        
        # Resource manager signals
        self.app.resource_manager.resource_created.connect(self.on_resource_created)
        self.app.resource_manager.resource_updated.connect(self.on_resource_updated)
        self.app.resource_manager.resource_deleted.connect(self.on_resource_deleted)
        
        # Resource tree signals
        # Single click only selects (for shift+click, ctrl+click, etc.)
        # Double click opens the resource editor
        self.resource_tree.resource_double_clicked.connect(self.open_resource)
    
    def setup_menus(self):
        """Setup menu bar"""
        menubar = self.menuBar()
        
        # File menu
        file_menu = menubar.addMenu("&File")
        
        new_project_action = QAction("&New Project", self)
        new_project_action.setShortcut(QKeySequence.New)
        new_project_action.triggered.connect(self.new_project)
        file_menu.addAction(new_project_action)
        
        open_project_action = QAction("&Open Project", self)
        open_project_action.setShortcut(QKeySequence.Open)
        open_project_action.triggered.connect(self.open_project)
        file_menu.addAction(open_project_action)
        
        reload_project_action = QAction("&Reload Project", self)
        reload_project_action.setShortcut(QKeySequence("Ctrl+R"))
        reload_project_action.triggered.connect(self.reload_project)
        file_menu.addAction(reload_project_action)
        
        file_menu.addSeparator()
        
        save_action = QAction("&Save", self)
        save_action.setShortcut(QKeySequence.Save)
        save_action.triggered.connect(self.save_project)
        file_menu.addAction(save_action)
        
        file_menu.addSeparator()
        
        # Backup submenu
        backup_menu = file_menu.addMenu("&Backup")
        
        backup_editor_action = QAction("Back Up &Editor", self)
        backup_editor_action.triggered.connect(self.backup_editor)
        backup_menu.addAction(backup_editor_action)
        
        backup_project_action = QAction("Back Up &Project", self)
        backup_project_action.triggered.connect(self.backup_project)
        backup_menu.addAction(backup_project_action)
        
        backup_menu.addSeparator()
        
        restore_editor_action = QAction("Restore &Editor Backup", self)
        restore_editor_action.triggered.connect(self.restore_editor)
        backup_menu.addAction(restore_editor_action)
        
        restore_project_action = QAction("Restore &Project Backup", self)
        restore_project_action.triggered.connect(self.restore_project)
        backup_menu.addAction(restore_project_action)
        
        file_menu.addSeparator()
        
        run_game_action = QAction("&Run Game", self)
        run_game_action.setShortcut(QKeySequence("F5"))
        run_game_action.triggered.connect(self.run_game)
        file_menu.addAction(run_game_action)
        
        debug_game_action = QAction("&Debug Game", self)
        debug_game_action.setShortcut(QKeySequence("F9"))
        debug_game_action.triggered.connect(self.debug_game)
        file_menu.addAction(debug_game_action)
        
        build_game_action = QAction("&Build Game", self)
        build_game_action.setShortcut(QKeySequence("F6"))
        build_game_action.triggered.connect(self.build_game)
        file_menu.addAction(build_game_action)
        
        file_menu.addSeparator()
        
        exit_action = QAction("E&xit", self)
        exit_action.setShortcut(QKeySequence.Quit)
        exit_action.triggered.connect(self.close)
        file_menu.addAction(exit_action)
        
        # Edit menu
        edit_menu = menubar.addMenu("&Edit")
        
        # Extensions submenu
        extensions_action = QAction("&Extensions...", self)
        extensions_action.triggered.connect(self.open_extensions_manager)
        edit_menu.addAction(extensions_action)
        
        edit_menu.addSeparator()
        
        # Utils submenu
        utils_menu = edit_menu.addMenu("&Utils")
        
        undo_action = QAction("&Undo", self)
        undo_action.setShortcut(QKeySequence.Undo)
        undo_action.setShortcutContext(Qt.WindowShortcut)
        undo_action.triggered.connect(self.undo_action)
        utils_menu.addAction(undo_action)
        
        redo_action = QAction("&Redo", self)
        redo_action.setShortcut(QKeySequence.Redo)
        redo_action.setShortcutContext(Qt.WindowShortcut)
        redo_action.triggered.connect(self.redo_action)
        utils_menu.addAction(redo_action)
        
        utils_menu.addSeparator()
        
        cut_action = QAction("&Cut", self)
        cut_action.setShortcut(QKeySequence.Cut)
        cut_action.setShortcutContext(Qt.WindowShortcut)
        cut_action.triggered.connect(self.cut_action)
        utils_menu.addAction(cut_action)
        
        copy_action = QAction("&Copy", self)
        copy_action.setShortcut(QKeySequence.Copy)
        copy_action.setShortcutContext(Qt.WindowShortcut)
        copy_action.triggered.connect(self.copy_action)
        utils_menu.addAction(copy_action)
        
        paste_action = QAction("&Paste", self)
        paste_action.setShortcut(QKeySequence.Paste)
        paste_action.setShortcutContext(Qt.WindowShortcut)
        paste_action.triggered.connect(self.paste_action)
        utils_menu.addAction(paste_action)
        
        utils_menu.addSeparator()
        
        rename_action = QAction("&Rename", self)
        rename_action.setShortcut(QKeySequence("F2"))
        rename_action.triggered.connect(self.rename_action)
        utils_menu.addAction(rename_action)
        
        utils_menu.addSeparator()
        
        create_folder_action = QAction("Create &Folder", self)
        create_folder_action.triggered.connect(self.create_folder_action)
        utils_menu.addAction(create_folder_action)
        
        create_resource_action = QAction("Create &Resource", self)
        create_resource_action.triggered.connect(self.create_resource_action)
        utils_menu.addAction(create_resource_action)
        
        edit_menu.addSeparator()
        
        preferences_action = QAction("&Preferences", self)
        preferences_action.setShortcut(QKeySequence("Ctrl+,"))
        preferences_action.triggered.connect(self.show_preferences)
        edit_menu.addAction(preferences_action)
        
        # Recordings menu
        recordings_menu = menubar.addMenu("&Recordings")
        
        # Store actions so we can update them dynamically
        self.record_action = QAction("&Start Recording", self)
        self.record_action.setShortcut(QKeySequence("Ctrl+Shift+R"))
        self.record_action.triggered.connect(self.toggle_recording)
        recordings_menu.addAction(self.record_action)
        
        self.compress_action = QAction("&Compress", self)
        self.compress_action.setShortcut(QKeySequence("Ctrl+Shift+C"))
        self.compress_action.triggered.connect(self.compress_recordings_auto)
        recordings_menu.addAction(self.compress_action)
        
        recordings_menu.addSeparator()
        
        view_recordings_action = QAction("&View Recordings", self)
        view_recordings_action.setShortcut(QKeySequence("Ctrl+Shift+V"))
        view_recordings_action.triggered.connect(self.view_recordings)
        recordings_menu.addAction(view_recordings_action)
        
        # Run menu (main menu for quick access)
        run_menu = menubar.addMenu("&Run")
        
        run_action = QAction("&Run Game", self)
        run_action.setShortcut(QKeySequence("F5"))
        run_action.triggered.connect(self.run_game)
        run_menu.addAction(run_action)
        
        debug_action = QAction("&Debug Game", self)
        debug_action.setShortcut(QKeySequence("F9"))
        debug_action.triggered.connect(self.debug_game)
        run_menu.addAction(debug_action)
        
        run_menu.addSeparator()
        
        build_action = QAction("&Build Game", self)
        build_action.setShortcut(QKeySequence("F6"))
        build_action.triggered.connect(self.build_game)
        run_menu.addAction(build_action)
        
        # AI menu
        ai_menu = menubar.addMenu("&AI")
        
        ai_action = QAction("&Open AI Assistant", self)
        ai_action.setShortcut(QKeySequence("Ctrl+Shift+A"))
        ai_action.triggered.connect(self.open_ai_assistant)
        ai_menu.addAction(ai_action)
        
        # Help menu
        help_menu = menubar.addMenu("&Help")
        
        about_action = QAction("&About", self)
        about_action.triggered.connect(self.show_about)
        help_menu.addAction(about_action)
    
    def setup_toolbar(self):
        """Setup toolbar - removed as requested"""
        pass
    
    def setup_status_bar(self):
        """Setup status bar"""
        self.status_bar = QStatusBar()
        self.setStatusBar(self.status_bar)
        self.status_bar.showMessage("Ready")
    
    def load_settings(self):
        """Load window settings"""
        geometry = self.app.settings.get("Window_Geometry")
        if geometry:
            self.restoreGeometry(geometry)
        
        state = self.app.settings.get("Window_State")
        if state:
            self.restoreState(state)
    
    def save_settings(self):
        """Save window settings"""
        self.app.settings.set("Window_Geometry", self.saveGeometry())
        self.app.settings.set("Window_State", self.saveState())
        self.app.settings.sync()
    
    def new_project(self):
        """Create a new project"""
        project_name, ok = QInputDialog.getText(self, "New Project", "Project Name:")
        if not ok or not project_name:
            return
        
        # Get default project location from preferences
        default_location = self.app.settings.get("Default_Project_Path", "")
        if not default_location or not os.path.exists(default_location):
            default_location = os.path.expanduser("~")  # Fallback to user home directory
        
        project_path = QFileDialog.getExistingDirectory(
            self, "Select Project Directory", default_location
        )
        if not project_path:
            return
        
        project_path = os.path.join(project_path, project_name)
        
        if self.app.project_manager.create_project(project_path, project_name):
            # The project_created signal will handle UI updates
            pass
    
    def open_project(self):
        """Open an existing project"""
        # Get default project location from preferences
        default_location = self.app.settings.get("Default_Project_Path", "")
        if not default_location or not os.path.exists(default_location):
            default_location = os.path.expanduser("~")  # Fallback to user home directory
        
        project_file, _ = QFileDialog.getOpenFileName(
            self, "Open Project", default_location, "Python Game Project (*.pgproject)"
        )
        if project_file:
            if self.app.project_manager.load_project(project_file):
                self.resource_tree.refresh()
                project_name = self.app.project_manager.get_project_name()
                self.setWindowTitle(f"Python Game IDE - {project_name}")
                self.status_bar.showMessage(f"Project loaded: {project_name}")
    
    def save_project(self):
        """Save current project"""
        # Save all open editors first to ensure their data is persisted
        for i in range(self.editor_tabs.count()):
            editor = self.editor_tabs.widget(i)
            if hasattr(editor, 'save_resource'):
                try:
                    editor.save_resource()
                except Exception as e:
                    from Core.Debug import debug
                    debug(f"Error saving editor {i}: {e}")
        
        # Update project data from all open editors before saving
        for i in range(self.editor_tabs.count()):
            editor = self.editor_tabs.widget(i)
            if hasattr(editor, 'update_project_data'):
                editor.update_project_data()
        
        if self.app.project_manager.save_project():
            self.status_bar.showMessage("Project saved")
        else:
            self.status_bar.showMessage("Failed to save project")
    
    def run_game(self):
        """Run the current game"""
        if not self.app.project_manager.get_project_path():
            QMessageBox.warning(self, "No Project", "Please open or create a project first")
            return
        
        self.status_bar.showMessage("Running game...")
        # TODO: Implement game running functionality
    
    def open_resource(self, resource_type, resource_id):
        """Open a resource in the appropriate editor"""
        resource = self.app.resource_manager.load_resource(resource_type, resource_id)
        if not resource:
            return
        
        # Check if already open
        for i in range(self.editor_tabs.count()):
            tab_widget = self.editor_tabs.widget(i)
            if hasattr(tab_widget, 'resource_id') and tab_widget.resource_id == resource_id:
                self.editor_tabs.setCurrentIndex(i)
                return
        
        # Determine editor name for loading message
        editor_names = {
            "sprites": "Sprite Editor",
            "rooms": "Room Editor",
            "sounds": "Sound Editor",
            "models": "Model Editor",
            "textures": "Texture Editor",
            "objects": "Object Editor"
        }
        editor_name = editor_names.get(resource_type, "Editor")
        
        # Create loading widget as placeholder
        tab_name = resource.get("name", "Unknown")
        loading_widget = LoadingWidget(f"Loading {editor_name}")
        
        # Add loading widget to tabs first (immediate UI feedback)
        tab_index = self.editor_tabs.addTab(loading_widget, tab_name)
        self.editor_tabs.setCurrentIndex(tab_index)
        
        # Process events to show the loading widget immediately
        QCoreApplication.processEvents()
        
        # Create editor synchronously on main thread (Qt widgets MUST be created on main thread)
        # Editors are preloaded at startup, so instantiation should be fast
        try:
            from Core.EditorFactory import EditorFactory
            editor = EditorFactory.create_editor(resource_type, resource, self.app)
            
            if editor is None:
                raise Exception("EditorFactory returned None")
            
            # Replace loading widget with actual editor
            self.editor_tabs.removeTab(tab_index)
            self.editor_tabs.insertTab(tab_index, editor, tab_name)
            self.editor_tabs.setCurrentIndex(tab_index)
            
            # Store resource info (for backward compatibility)
            resource_id = resource.get("id", "")
            editor.resource_id = resource_id
            editor.resource_type = resource_type
            
            # Clean up loading widget
            loading_widget.deleteLater()
            
        except Exception as e:
            debug(f"Error creating editor: {e}")
            import traceback
            debug(traceback.format_exc())
            self.editor_tabs.removeTab(tab_index)
            from PySide6.QtWidgets import QMessageBox
            QMessageBox.critical(self, "Editor Error", f"Failed to open {editor_name}:\n{str(e)}")
        
        # Connect to resource manager signals to update tab titles
        self.app.resource_manager.resource_updated.connect(self.on_resource_updated)
    
    def close_editor_tab(self, index):
        """Close an editor tab"""
        self.editor_tabs.removeTab(index)
    
    def close_all_editor_tabs(self):
        """Close all open editor tabs"""
        while self.editor_tabs.count() > 0:
            self.editor_tabs.removeTab(0)
    
    def update_window_title(self, project_name):
        """Update window title with dirty state indicator"""
        title = f"Python Game IDE - {project_name}"
        if self.app.project_manager.has_pending_changes():
            title += " *"  # Asterisk indicates unsaved changes
        self.setWindowTitle(title)
    
    def reload_project(self):
        """Reload the current project from disk"""
        if not self.app.project_manager.get_project_path():
            return
        
        current_project_path = self.app.project_manager.get_project_path()
        project_file = os.path.join(current_project_path, f"{self.app.project_manager.get_project_name()}.pgproject")
        
        if os.path.exists(project_file):
            if self.app.project_manager.load_project(project_file):
                project_name = self.app.project_manager.get_project_name()
                self.status_bar.showMessage(f"Project reloaded: {project_name}")
            else:
                self.status_bar.showMessage("Failed to reload project")
        else:
            self.status_bar.showMessage("Project file not found")
    
    def on_project_loaded(self, project_path):
        """Handle project loaded signal"""
        # Close all open editor tabs when switching projects
        self.close_all_editor_tabs()
        
        # Add to recent projects (project_path is the full path to .pgproject file)
        if project_path and os.path.exists(project_path):
            self.app.settings.add_recent_project(project_path)
        
        # Refresh resource tree (resources may be loading asynchronously, so this may show empty initially)
        # The tree will refresh again when resources_loaded is emitted
        self.resource_tree.refresh()
        project_name = self.app.project_manager.get_project_name()
        self.update_window_title(project_name)
        self.status_bar.showMessage(f"Project loaded: {project_name}")
    
    def on_resources_loaded(self):
        """Handle resources loaded signal - refresh tree now that resources are actually loaded"""
        # Refresh resource tree now that all resources have been loaded asynchronously
        self.resource_tree.refresh()
        # Get total resource count
        total = 0
        for resource_type in ["sprites", "backgrounds", "textures", "objects", "sounds", "models", "rooms"]:
            resources = self.app.project_manager.get_runtime_resources(resource_type)
            total += len(resources)
        self.status_bar.showMessage(f"Loaded {total} resources", 3000)  # Show for 3 seconds
    
    def on_project_created(self, project_path):
        """Handle project created signal"""
        # Close all open editor tabs when creating a new project
        self.close_all_editor_tabs()
        
        # Add to recent projects (project_path is the directory, need to find .pgproject file)
        if project_path:
            import glob
            project_files = glob.glob(os.path.join(project_path, "*.pgproject"))
            if project_files:
                # Use the first .pgproject file found
                project_file = project_files[0]
                if os.path.exists(project_file):
                    self.app.settings.add_recent_project(project_file)
        
        self.resource_tree.refresh()
        project_name = self.app.project_manager.get_project_name()
        self.update_window_title(project_name)
        self.status_bar.showMessage(f"Project created: {project_name}")
    
    def on_resource_created(self, resource_type, resource_data):
        """Handle resource created signal"""
        # ResourceTree already handles this via its own connection, so we don't need to do anything here
        # This handler is kept for potential future use (e.g., logging, notifications)
        pass
    
    def on_resource_updated(self, resource_type, resource_data):
        """Handle resource updated signal"""
        # Update only the changed resource without refreshing the entire type
        self.resource_tree.update_single_resource(resource_type, resource_data)
    
    def on_resource_deleted(self, resource_type, resource_id):
        """Handle resource deleted signal"""
        # Remove only the deleted resource without refreshing the entire type
        self.resource_tree.remove_single_resource(resource_type, resource_id)
    
    def show_about(self):
        """Show about dialog"""
        QMessageBox.about(self, "About Python Game IDE", 
                         "Python Game IDE v1.0.0\n\n"
                         "A GameMaker-style IDE for creating Python games")
    
    def _current_editor(self):
        """Return the currently active editor widget, if any."""
        if hasattr(self, "editor_tabs") and self.editor_tabs:
            return self.editor_tabs.currentWidget()
        return None

    def _dispatch_edit_action(self, method_name):
        """Try to dispatch an edit action to the focused editor widget."""
        try:
            from PySide6.QtWidgets import QApplication
        except ImportError:
            return False

        widget = QApplication.focusWidget()
        visited = set()
        while widget and widget not in visited:
            visited.add(widget)
            # Don't call methods on MainWindow itself (prevents infinite recursion)
            if widget is self:
                widget = widget.parent()
                continue
            if hasattr(widget, method_name):
                getattr(widget, method_name)()
                return True
            widget = widget.parent()

        editor = self._current_editor()
        # Don't call methods on MainWindow itself
        if editor and editor is not self and hasattr(editor, method_name):
            getattr(editor, method_name)()
            return True

        return False

    def undo_action(self):
        """Handle undo action"""
        if self._dispatch_edit_action("undo_action"):
            return

        if self.app.undo_redo_manager.can_undo():
            success = self.app.undo_redo_manager.undo()
            if not success:
                QMessageBox.warning(self, "Undo", "Failed to undo operation")
        else:
            QMessageBox.information(self, "Undo", "Nothing to undo")
    
    def redo_action(self):
        """Handle redo action"""
        if self._dispatch_edit_action("redo_action"):
            return

        if self.app.undo_redo_manager.can_redo():
            success = self.app.undo_redo_manager.redo()
            if not success:
                QMessageBox.warning(self, "Redo", "Failed to redo operation")
        else:
            QMessageBox.information(self, "Redo", "Nothing to redo")
    
    def cut_action(self):
        """Handle cut action"""
        if self._dispatch_edit_action("cut_action"):
            return

        current_item = self.resource_tree.currentItem()
        if current_item:
            data = current_item.data(0, Qt.UserRole)
            if data and data.get("type") == "resource":
                self.resource_tree.cut_resource(current_item)
            elif data and data.get("type") == "folder":
                self.resource_tree.cut_folder(current_item)
    
    def copy_action(self):
        """Handle copy action"""
        if self._dispatch_edit_action("copy_action"):
            return

        current_item = self.resource_tree.currentItem()
        if current_item:
            data = current_item.data(0, Qt.UserRole)
            if data and data.get("type") == "resource":
                self.resource_tree.copy_resource(current_item)
            elif data and data.get("type") == "folder":
                self.resource_tree.copy_folder(current_item)
    
    def paste_action(self):
        """Handle paste action"""
        if self._dispatch_edit_action("paste_action"):
            return

        current_item = self.resource_tree.currentItem()
        if current_item:
            self.resource_tree.paste_resource(current_item)
    
    def rename_action(self):
        """Handle rename action"""
        current_item = self.resource_tree.currentItem()
        if current_item:
            data = current_item.data(0, Qt.UserRole)
            if data and data.get("type") == "resource":
                self.resource_tree.rename_resource(current_item)
            elif data and data.get("type") == "folder":
                self.resource_tree.rename_folder(current_item)
    
    def create_folder_action(self):
        """Handle create folder action"""
        current_item = self.resource_tree.currentItem()
        if current_item:
            data = current_item.data(0, Qt.UserRole)
            if data and data.get("type") == "resource_type":
                self.resource_tree.create_folder(data["resource_type"])
            elif data and data.get("type") == "folder":
                self.resource_tree.create_folder(data["resource_type"], data["folder"])
    
    def create_resource_action(self):
        """Handle create resource action"""
        current_item = self.resource_tree.currentItem()
        if current_item:
            data = current_item.data(0, Qt.UserRole)
            if data and data.get("type") == "resource_type":
                self.resource_tree.create_resource(data["resource_type"])
            elif data and data.get("type") == "folder":
                self.resource_tree.create_resource(data["resource_type"], data["folder"])
    
    def run_game(self):
        """Run the current game with script checking"""
        if not self.app.project_manager.get_project_path():
            QMessageBox.warning(self, "No Project", "Please open or create a project first")
            return
        
        # Generate game files first
        from Core.GameGenerator import GameGenerator
        generator = GameGenerator(self.app.project_manager)
        
        self.status_bar.showMessage("Generating game files...")
        self.terminal_widget.append_text("🔧 Generating game files...\n")
        
        if not generator.generate_game():
            QMessageBox.warning(
                self, "Cannot Generate Game",
                "Cannot generate game: At least one room is required.\n"
                "Please create a room in your project."
            )
            return
        
        self.terminal_widget.append_text("✅ Game files generated successfully\n")
        self.terminal_widget.append_text("=" * 50 + "\n\n")
        
        # Check scripts after generation
        if not self.check_all_scripts():
            reply = QMessageBox.question(
                self, "Script Errors",
                "Script validation found errors. Continue anyway?",
                QMessageBox.Yes | QMessageBox.No
            )
            if reply == QMessageBox.No:
                return
        
        # Run the game
        self.status_bar.showMessage("Running game...")
        project_path = Path(self.app.project_manager.get_project_path())
        
        # Find main script (look for main.py or game.py in Scripts folder)
        scripts_folder = project_path / "Scripts"
        main_script = scripts_folder / "main.py"
        
        if not main_script.exists():
            QMessageBox.warning(
                self, "No Main Script",
                "Could not find main.py in Scripts folder.\n"
                "Game generation may have failed."
            )
            return
        
        # Run the script
        try:
            import subprocess
            import sys
            
            # Get Python executable from venv if available
            venv_python = project_path / "venv" / "Scripts" / "python.exe"
            if not venv_python.exists():
                venv_python = project_path / "venv" / "bin" / "python"
            
            python_exe = str(venv_python) if venv_python.exists() else sys.executable
            
            # Run the game
            process = subprocess.Popen(
                [python_exe, str(main_script)],
                cwd=str(project_path),
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True
            )
            
            # Output to terminal
            self.terminal_widget.append_text(f"Running game: {main_script.name}\n")
            self.terminal_widget.append_text(f"Python: {python_exe}\n")
            self.terminal_widget.append_text("=" * 50 + "\n")
            
            # Read output in real-time (simplified - in production, use QThread)
            stdout, stderr = process.communicate()
            if stdout:
                self.terminal_widget.append_text(stdout)
            if stderr:
                self.terminal_widget.append_text(f"ERRORS:\n{stderr}")
            
            if process.returncode == 0:
                self.status_bar.showMessage("Game finished successfully")
                self.terminal_widget.append_text("\n✅ Game finished successfully\n")
            else:
                self.status_bar.showMessage(f"Game exited with code {process.returncode}")
                self.terminal_widget.append_text(f"\n❌ Game exited with code {process.returncode}\n")
                
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to run game: {e}")
            self.status_bar.showMessage("Failed to run game")
    
    def debug_game(self):
        """Debug the current game with script checking"""
        if not self.app.project_manager.get_project_path():
            QMessageBox.warning(self, "No Project", "Please open or create a project first")
            return
        
        # Generate game files first
        from Core.GameGenerator import GameGenerator
        generator = GameGenerator(self.app.project_manager)
        
        self.status_bar.showMessage("Generating game files...")
        self.terminal_widget.append_text("🔧 Generating game files...\n")
        
        if not generator.generate_game():
            QMessageBox.warning(
                self, "Cannot Generate Game",
                "Cannot generate game: At least one room is required.\n"
                "Please create a room in your project."
            )
            return
        
        self.terminal_widget.append_text("✅ Game files generated successfully\n")
        self.terminal_widget.append_text("=" * 50 + "\n\n")
        
        # Check scripts after generation
        if not self.check_all_scripts():
            reply = QMessageBox.question(
                self, "Script Errors",
                "Script validation found errors. Continue anyway?",
                QMessageBox.Yes | QMessageBox.No
            )
            if reply == QMessageBox.No:
                return
        
        # Debug mode - same as run but with debug flags
        self.status_bar.showMessage("Starting game in debug mode...")
        project_path = Path(self.app.project_manager.get_project_path())
        
        # Find main script
        scripts_folder = project_path / "Scripts"
        main_script = scripts_folder / "main.py"
        
        if not main_script.exists():
            QMessageBox.warning(
                self, "No Main Script",
                "Could not find main.py in Scripts folder.\n"
                "Game generation may have failed."
            )
            return
        
        # Run in debug mode (with -u for unbuffered output and -i for interactive)
        try:
            import subprocess
            import sys
            
            venv_python = project_path / "venv" / "Scripts" / "python.exe"
            if not venv_python.exists():
                venv_python = project_path / "venv" / "bin" / "python"
            
            python_exe = str(venv_python) if venv_python.exists() else sys.executable
            
            # Run with debug flags
            process = subprocess.Popen(
                [python_exe, "-u", "-i", str(main_script)],
                cwd=str(project_path),
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True
            )
            
            self.terminal_widget.append_text(f"Debugging game: {main_script.name}\n")
            self.terminal_widget.append_text(f"Python: {python_exe}\n")
            self.terminal_widget.append_text("=" * 50 + "\n")
            
            stdout, stderr = process.communicate()
            if stdout:
                self.terminal_widget.append_text(stdout)
            if stderr:
                self.terminal_widget.append_text(f"ERRORS:\n{stderr}")
            
            if process.returncode == 0:
                self.status_bar.showMessage("Debug session finished")
                self.terminal_widget.append_text("\n✅ Debug session finished\n")
            else:
                self.status_bar.showMessage(f"Debug session exited with code {process.returncode}")
                self.terminal_widget.append_text(f"\n❌ Debug session exited with code {process.returncode}\n")
                
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to debug game: {e}")
            self.status_bar.showMessage("Failed to debug game")
    
    def build_game(self):
        """Build the current game to executable with script checking"""
        if not self.app.project_manager.get_project_path():
            QMessageBox.warning(self, "No Project", "Please open or create a project first")
            return
        
        # Generate game files first
        from Core.GameGenerator import GameGenerator
        generator = GameGenerator(self.app.project_manager)
        
        self.status_bar.showMessage("Generating game files...")
        self.terminal_widget.append_text("🔧 Generating game files...\n")
        
        if not generator.generate_game():
            QMessageBox.warning(
                self, "Cannot Generate Game",
                "Cannot generate game: At least one room is required.\n"
                "Please create a room in your project."
            )
            return
        
        self.terminal_widget.append_text("✅ Game files generated successfully\n")
        self.terminal_widget.append_text("=" * 50 + "\n\n")
        
        # Check scripts after generation
        if not self.check_all_scripts():
            reply = QMessageBox.question(
                self, "Script Errors",
                "Script validation found errors. Continue with build anyway?",
                QMessageBox.Yes | QMessageBox.No
            )
            if reply == QMessageBox.No:
                return
        
        # Build the game
        self.status_bar.showMessage("Building game...")
        QMessageBox.information(
            self, "Build Game",
            "Build functionality will use PyInstaller or similar.\n"
            "This feature is not yet fully implemented."
        )
        self.status_bar.showMessage("Build not yet implemented")
    
    def check_all_scripts(self) -> bool:
        """
        Check all scripts in the project.
        Returns True if all scripts pass, False otherwise.
        """
        project_path = Path(self.app.project_manager.get_project_path())
        if not project_path:
            return False
        
        # Clear terminal
        self.terminal_widget.clear()
        self.terminal_widget.append_text("🔍 Checking all scripts in project...\n")
        self.terminal_widget.append_text("=" * 50 + "\n\n")
        
        # Create script checker
        from Core.Services.script_checker import ScriptChecker
        checker = ScriptChecker(project_path, output_callback=self.terminal_widget.append_text)
        
        # Check all scripts
        result = checker.check_all_scripts()
        
        return result['passed']
    
    def backup_editor(self):
        """Back up the editor (application) to configured backup location"""
        from Tools.BackupManager.BackupManager import BackupManager
        from UI.CommonDialogs.BackupFolderDialog import BackupFolderDialog
        from pathlib import Path
        import os
        
        # Get backup location from settings
        user_home = Path.home()
        default_backup = os.path.join(str(user_home), "PyGenesis", "Backups", "Editor")
        backup_base_path = Path(self.app.settings.get("Editor_Backup_Location", default_backup))
        
        # Get source directory (application directory)
        source_dir = self.app.app_dir
        
        # Show folder selection dialog
        folder_dialog = BackupFolderDialog(source_dir, "editor", self)
        if folder_dialog.exec() != QDialog.Accepted:
            return  # User cancelled
        
        included_folders = folder_dialog.get_included_folders()
        excluded_folders = folder_dialog.get_excluded_folders()
        
        # Create progress dialog
        progress = QProgressDialog("Creating backup...", "Cancel", 0, 0, self)
        progress.setWindowTitle("Backing Up Editor")
        progress.setWindowModality(Qt.WindowModal)
        progress.setMinimumDuration(0)
        progress.show()
        
        # Track progress
        current_progress = {"value": 0, "max": 0, "cancelled": False}
        
        def progress_callback(current, total, current_file, current_folder):
            """Callback for backup progress"""
            if current_progress["max"] != total:
                current_progress["max"] = total
                progress.setMaximum(total)
            current_progress["value"] = current
            progress.setValue(current)
            
            # Update label with current file
            if current_file:
                display_file = os.path.basename(current_file)
                if len(display_file) > 50:
                    display_file = "..." + display_file[-47:]
                progress.setLabelText(f"Backing up: {display_file} ({current}/{total})")
            
            # Check if cancelled
            if progress.wasCanceled():
                current_progress["cancelled"] = True
                return False
            return True
        
        # Create backup manager
        backup_mgr = BackupManager()
        
        # Set folder filters
        backup_mgr.set_folder_filters(included_folders=included_folders, excluded_folders=excluded_folders)
        
        try:
            # Create backup
            zip_path, result = backup_mgr.create_backup(
                source_dir,
                backup_base_path,
                use_version_structure=False,  # Simple structure for editor backups
                progress_callback=progress_callback
            )
            
            progress.close()
            
            if current_progress["cancelled"]:
                QMessageBox.information(self, "Backup Cancelled", "Backup was cancelled.")
                return
            
            if zip_path and result.get("success"):
                size_mb = result["compressed_size"] / (1024 * 1024)
                compression = result.get("compression_ratio", 0)
                msg = f"Backup completed successfully!\n\n"
                msg += f"Location: {zip_path}\n"
                msg += f"Files: {result['files_backed_up']}\n"
                msg += f"Size: {size_mb:.2f} MB\n"
                if compression > 0:
                    msg += f"Compression: {compression:.1f}%"
                QMessageBox.information(self, "Backup Complete", msg)
            else:
                error = result.get("error", "Unknown error")
                QMessageBox.warning(self, "Backup Failed", f"Backup failed: {error}")
        except Exception as e:
            progress.close()
            QMessageBox.critical(self, "Backup Error", f"An error occurred during backup:\n{str(e)}")
    
    def backup_project(self):
        """Back up the currently loaded project"""
        from Tools.BackupManager.BackupManager import BackupManager
        from UI.CommonDialogs.BackupFolderDialog import BackupFolderDialog
        from pathlib import Path
        import os
        
        # Check if project is loaded
        if not self.app.project_manager.project_path:
            QMessageBox.warning(self, "No Project", "Please open a project first.")
            return
        
        # Get backup location from settings
        user_home = Path.home()
        default_backup = os.path.join(str(user_home), "PyGenesis", "Backups", "Projects")
        backup_base_path = Path(self.app.settings.get("Project_Backup_Location", default_backup))
        
        # Get project name for subfolder
        project_name = self.app.project_manager.current_project or "UnknownProject"
        project_backup_path = backup_base_path / project_name
        
        # Get source directory (project directory)
        source_dir = Path(self.app.project_manager.project_path)
        
        # Show resource folder selection dialog first
        from UI.CommonDialogs.ResourceFolderDialog import ResourceFolderDialog
        resource_dialog = ResourceFolderDialog(source_dir, self)
        if resource_dialog.exec() != QDialog.Accepted:
            return  # User cancelled
        
        resource_folders = resource_dialog.get_selected_folders()
        
        # Show folder selection dialog
        folder_dialog = BackupFolderDialog(source_dir, "project", self)
        if folder_dialog.exec() != QDialog.Accepted:
            return  # User cancelled
        
        included_folders = folder_dialog.get_included_folders()
        excluded_folders = folder_dialog.get_excluded_folders()
        
        # Add resource folders to included if user selected them
        if resource_folders:
            included_folders.update(resource_folders)
        
        # Create progress dialog
        progress = QProgressDialog("Creating backup...", "Cancel", 0, 0, self)
        progress.setWindowTitle(f"Backing Up Project: {project_name}")
        progress.setWindowModality(Qt.WindowModal)
        progress.setMinimumDuration(0)
        progress.show()
        
        # Track progress
        current_progress = {"value": 0, "max": 0, "cancelled": False}
        
        def progress_callback(current, total, current_file, current_folder):
            """Callback for backup progress"""
            if current_progress["max"] != total:
                current_progress["max"] = total
                progress.setMaximum(total)
            current_progress["value"] = current
            progress.setValue(current)
            
            # Update label with current file
            if current_file:
                display_file = os.path.basename(current_file)
                if len(display_file) > 50:
                    display_file = "..." + display_file[-47:]
                progress.setLabelText(f"Backing up: {display_file} ({current}/{total})")
            
            # Check if cancelled
            if progress.wasCanceled():
                current_progress["cancelled"] = True
                return False
            return True
        
        # Create backup manager
        backup_mgr = BackupManager()
        
        # Set folder filters
        backup_mgr.set_folder_filters(included_folders=included_folders, excluded_folders=excluded_folders)
        
        try:
            # Create backup
            zip_path, result = backup_mgr.create_backup(
                source_dir,
                project_backup_path,
                use_version_structure=False,  # Simple structure for project backups
                progress_callback=progress_callback
            )
            
            progress.close()
            
            if current_progress["cancelled"]:
                QMessageBox.information(self, "Backup Cancelled", "Backup was cancelled.")
                return
            
            if zip_path and result.get("success"):
                size_mb = result["compressed_size"] / (1024 * 1024)
                compression = result.get("compression_ratio", 0)
                msg = f"Project backup completed successfully!\n\n"
                msg += f"Project: {project_name}\n"
                msg += f"Location: {zip_path}\n"
                msg += f"Files: {result['files_backed_up']}\n"
                msg += f"Size: {size_mb:.2f} MB\n"
                if compression > 0:
                    msg += f"Compression: {compression:.1f}%"
                QMessageBox.information(self, "Backup Complete", msg)
            else:
                error = result.get("error", "Unknown error")
                QMessageBox.warning(self, "Backup Failed", f"Backup failed: {error}")
        except Exception as e:
            progress.close()
            QMessageBox.critical(self, "Backup Error", f"An error occurred during backup:\n{str(e)}")
    
    def restore_editor(self):
        """Restore editor from backup"""
        from Tools.BackupManager.BackupManager import BackupManager
        from UI.CommonDialogs.RestoreDialog import RestoreDialog
        from pathlib import Path
        import os
        
        # Get backup location from settings
        user_home = Path.home()
        default_backup = os.path.join(str(user_home), "PyGenesis", "Backups", "Editor")
        backup_base_path = Path(self.app.settings.get("Editor_Backup_Location", default_backup))
        
        # Show restore dialog
        restore_dialog = RestoreDialog("editor", backup_base_path, self)
        if restore_dialog.exec() != QDialog.Accepted:
            return  # User cancelled
        
        backup = restore_dialog.get_selected_backup()
        if not backup:
            return
        
        # Get restore destination (application directory)
        restore_destination = Path(self.app.app_dir)
        
        # Confirm restore location
        reply = QMessageBox.question(
            self,
            "Confirm Restore Location",
            f"Restore backup to:\n{restore_destination}\n\n"
            "This will restore editor files. Continue?",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No
        )
        
        if reply != QMessageBox.Yes:
            return
        
        # Create progress dialog
        progress = QProgressDialog("Restoring backup...", "Cancel", 0, 0, self)
        progress.setWindowTitle("Restoring Editor Backup")
        progress.setWindowModality(Qt.WindowModal)
        progress.setMinimumDuration(0)
        progress.show()
        
        # Track progress
        current_progress = {"value": 0, "max": 0, "cancelled": False}
        
        def progress_callback(current, total, current_file):
            """Callback for restore progress"""
            if current_progress["max"] != total:
                current_progress["max"] = total
                progress.setMaximum(total)
            current_progress["value"] = current
            progress.setValue(current)
            
            # Update label with current file
            if current_file:
                display_file = os.path.basename(current_file)
                if len(display_file) > 50:
                    display_file = "..." + display_file[-47:]
                progress.setLabelText(f"Restoring: {display_file} ({current}/{total})")
            
            # Check if cancelled
            if progress.wasCanceled():
                current_progress["cancelled"] = True
                return False
            return True
        
        # Create backup manager and restore
        backup_mgr = BackupManager()
        
        try:
            success, result = backup_mgr.restore_backup(
                backup["path"],
                restore_destination,
                progress_callback=progress_callback,
                overwrite_existing=restore_dialog.should_overwrite()
            )
            
            progress.close()
            
            if current_progress["cancelled"]:
                QMessageBox.information(self, "Restore Cancelled", "Restore was cancelled.")
                return
            
            if success:
                msg = f"Restore completed successfully!\n\n"
                msg += f"Files restored: {result['files_restored']}\n"
                if result['files_skipped'] > 0:
                    msg += f"Files skipped: {result['files_skipped']}\n"
                if result['files_failed'] > 0:
                    msg += f"Files failed: {result['files_failed']}\n"
                
                if result.get('errors'):
                    msg += f"\nErrors: {len(result['errors'])}"
                
                reply = QMessageBox.question(
                    self,
                    "Restore Complete",
                    msg + "\n\nEditor files have been restored. Restart the application to apply changes?",
                    QMessageBox.Yes | QMessageBox.No,
                    QMessageBox.Yes
                )
                
                if reply == QMessageBox.Yes:
                    # Restart application using subprocess to handle paths with spaces correctly
                    import sys
                    # Use subprocess to properly handle paths with spaces
                    # subprocess.Popen handles paths with spaces correctly when passed as a list
                    subprocess.Popen([sys.executable] + sys.argv, cwd=os.getcwd(), creationflags=subprocess.CREATE_NEW_CONSOLE if sys.platform == 'win32' else 0)
                    # Close current application
                    QCoreApplication.instance().quit()
            else:
                error = result.get("error", "Unknown error")
                QMessageBox.warning(self, "Restore Failed", f"Restore failed: {error}")
        except Exception as e:
            progress.close()
            QMessageBox.critical(self, "Restore Error", f"An error occurred during restore:\n{str(e)}")
    
    def restore_project(self):
        """Restore project from backup"""
        from Tools.BackupManager.BackupManager import BackupManager
        from UI.CommonDialogs.RestoreDialog import RestoreDialog
        from pathlib import Path
        import os
        
        # Check if project is loaded
        if not self.app.project_manager.project_path:
            QMessageBox.warning(self, "No Project", "Please load a project first.")
            return
        
        # Get backup location from settings
        user_home = Path.home()
        default_backup = os.path.join(str(user_home), "PyGenesis", "Backups", "Projects")
        backup_base_path = Path(self.app.settings.get("Project_Backup_Location", default_backup))
        
        # Get project name for project-specific backup folder
        project_path = Path(self.app.project_manager.project_path)
        project_name = project_path.name
        project_backup_path = backup_base_path / project_name
        
        # Show restore dialog
        restore_dialog = RestoreDialog("project", project_backup_path, self)
        if restore_dialog.exec() != QDialog.Accepted:
            return  # User cancelled
        
        backup = restore_dialog.get_selected_backup()
        if not backup:
            return
        
        # Get restore destination (current project path)
        restore_destination = project_path
        
        # Confirm restore location
        reply = QMessageBox.question(
            self,
            "Confirm Restore Location",
            f"Restore backup to:\n{restore_destination}\n\n"
            "This will restore project files. Continue?",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No
        )
        
        if reply != QMessageBox.Yes:
            return
        
        # Create progress dialog
        progress = QProgressDialog("Restoring backup...", "Cancel", 0, 0, self)
        progress.setWindowTitle("Restoring Project Backup")
        progress.setWindowModality(Qt.WindowModal)
        progress.setMinimumDuration(0)
        progress.show()
        
        # Track progress
        current_progress = {"value": 0, "max": 0, "cancelled": False}
        
        def progress_callback(current, total, current_file):
            """Callback for restore progress"""
            if current_progress["max"] != total:
                current_progress["max"] = total
                progress.setMaximum(total)
            current_progress["value"] = current
            progress.setValue(current)
            
            # Update label with current file
            if current_file:
                display_file = os.path.basename(current_file)
                if len(display_file) > 50:
                    display_file = "..." + display_file[-47:]
                progress.setLabelText(f"Restoring: {display_file} ({current}/{total})")
            
            # Check if cancelled
            if progress.wasCanceled():
                current_progress["cancelled"] = True
                return False
            return True
        
        # Create backup manager and restore
        backup_mgr = BackupManager()
        
        try:
            success, result = backup_mgr.restore_backup(
                backup["path"],
                restore_destination,
                progress_callback=progress_callback,
                overwrite_existing=restore_dialog.should_overwrite()
            )
            
            progress.close()
            
            if current_progress["cancelled"]:
                QMessageBox.information(self, "Restore Cancelled", "Restore was cancelled.")
                return
            
            if success:
                msg = f"Restore completed successfully!\n\n"
                msg += f"Files restored: {result['files_restored']}\n"
                if result['files_skipped'] > 0:
                    msg += f"Files skipped: {result['files_skipped']}\n"
                if result['files_failed'] > 0:
                    msg += f"Files failed: {result['files_failed']}\n"
                
                if result.get('errors'):
                    msg += f"\nErrors: {len(result['errors'])}"
                
                reply = QMessageBox.question(
                    self,
                    "Restore Complete",
                    msg + "\n\nReload the project to see restored files?",
                    QMessageBox.Yes | QMessageBox.No,
                    QMessageBox.Yes
                )
                
                if reply == QMessageBox.Yes:
                    # Reload project without restarting
                    self.app.project_manager.load_project(str(restore_destination))
            else:
                error = result.get("error", "Unknown error")
                QMessageBox.warning(self, "Restore Failed", f"Restore failed: {error}")
        except Exception as e:
            progress.close()
            QMessageBox.critical(self, "Restore Error", f"An error occurred during restore:\n{str(e)}")
    
    def open_extensions_manager(self):
        """Open the Extensions Manager dialog"""
        from UI.CommonDialogs.ExtensionsDialog import ExtensionsDialog
        dialog = ExtensionsDialog(self.app, self)
        dialog.exec()
    
    def open_ai_assistant(self):
        """Open the AI Assistant (Nova) in a separate window"""
        # Check if window already exists and is visible
        if hasattr(self, '_nova_window') and self._nova_window and self._nova_window.isVisible():
            # Window already open, just bring it to front
            self._nova_window.raise_()
            self._nova_window.activateWindow()
            return
        
        # Create Nova widget wrapper
        from Core.AI.PyGenesisAssistant.NovaWidget import NovaWidget
        from PySide6.QtWidgets import QMainWindow, QVBoxLayout, QWidget
        from pathlib import Path
        
        # Create separate window
        nova_window = QMainWindow(self)
        nova_window.setWindowTitle("AI Assistant - Nova")
        nova_window.resize(1120, 760)
        
        # Get project root
        project_path = self.app.project_manager.get_project_path()
        if project_path:
            project_root = Path(project_path) / "resources"
            if not project_root.exists():
                project_root = Path(project_path)
        else:
            project_root = Path(self.app.app_dir)
        
        # Create central widget
        central_widget = QWidget()
        layout = QVBoxLayout(central_widget)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)
        
        # Create Nova widget (without toolbar since it's in its own window)
        nova_widget = NovaWidget(self.app, self, standalone_window=True)
        layout.addWidget(nova_widget)
        
        nova_window.setCentralWidget(central_widget)
        
        # Connect window close to cleanup
        def on_window_close():
            if hasattr(self, '_nova_window'):
                self._nova_window = None
        
        nova_window.destroyed.connect(on_window_close)
        
        # Store reference and show
        self._nova_window = nova_window
        nova_window.show()
        nova_window.raise_()
        nova_window.activateWindow()
    
    def show_preferences(self):
        """Show preferences dialog"""
        dialog = PreferencesDialog(self.app, self)
        dialog.preferences_changed.connect(self.on_preferences_changed)
        dialog.exec()
    
    def on_preferences_changed(self):
        """Handle preferences changes"""
        self.apply_theme()
        # Update terminal theme
        if hasattr(self, 'terminal_widget'):
            self.terminal_widget.apply_theme()
        # Notify all open editors to refresh their themes and settings
        for i in range(self.editor_tabs.count()):
            editor = self.editor_tabs.widget(i)
            if hasattr(editor, 'apply_theme'):
                editor.apply_theme()
            # Reload Model Editor settings if it's a ModelPreviewWindow
            if hasattr(editor, '_load_model_editor_settings'):
                editor._load_model_editor_settings()
    
    def apply_theme(self):
        """Apply current theme to main window"""
        # Apply font size
        ui_font_size = self.app.settings.get("UI_Font_Size", 9)
        font = QFont()
        font.setPointSize(ui_font_size)
        self.setFont(font)
        
        # Apply font to all child widgets
        for widget in self.findChildren(QWidget):
            widget.setFont(font)
        
        # Get custom colors if they exist
        custom_colors = {}
        color_types = ["font_color", "button_color", "menu_color", "background_color", "border_color", "input_color"]
        color_mapping = {
            "font_color": "foreground",
            "button_color": "button_bg", 
            "menu_color": "menu_bar",
            "background_color": "background",
            "border_color": "border",
            "input_color": "input_bg"
        }
        
        for color_type in color_types:
            custom_color = self.app.settings.get(f"Custom_{color_type.title()}", "")
            if custom_color:
                custom_colors[color_mapping[color_type]] = custom_color
                debug(f"Found custom color {color_type} = {custom_color}")
        
        # Apply custom colors globally through theme manager
        if custom_colors:
            self.app.theme_manager.apply_custom_colors(custom_colors)
            # Also apply to this window specifically
            self.setStyleSheet(self.app.theme_manager.generate_custom_stylesheet(
                {**self.app.theme_manager.get_colors(), **custom_colors}
            ))
        else:
            # Apply default theme
            theme_stylesheet = self.app.theme_manager.get_stylesheet("main")
            QCoreApplication.instance().setStyleSheet(theme_stylesheet)
            self.setStyleSheet(theme_stylesheet)
        
        # Apply theme to all dock widgets
        dock_stylesheet = theme_stylesheet if not custom_colors else self.app.theme_manager.generate_custom_stylesheet(
            {**self.app.theme_manager.get_colors(), **custom_colors}
        )
        for dock in self.findChildren(QDockWidget):
            dock.setStyleSheet(dock_stylesheet)
    
    def on_resource_updated(self, resource_type, resource_data):
        """Handle resource updated signal - update tab titles"""
        resource_id = resource_data.get("id")
        new_name = resource_data.get("name", "Unknown")
        
        # Find and update the tab for this resource
        for i in range(self.editor_tabs.count()):
            editor = self.editor_tabs.widget(i)
            if (hasattr(editor, 'resource_id') and 
                hasattr(editor, 'resource_type') and
                editor.resource_id == resource_id and 
                editor.resource_type == resource_type):
                self.editor_tabs.setTabText(i, new_name)
                debug(f"Updated tab title to '{new_name}' for {resource_type} {resource_id}")
                break
    
    def closeEvent(self, event):
        """Handle window close event"""
        # Purge files not in current project before closing
        if hasattr(self.app, 'project_manager') and self.app.project_manager:
            self.app.project_manager.purge_files_not_in_project()
        
        self.save_settings()
        event.accept()
    
    def toggle_recording(self):
        """Toggle recording on/off - fully managed from menu"""
        if not self.app.project_manager.get_project_path():
            QMessageBox.warning(self, "No Project", "Please open or create a project first.")
            return
        
        # Ensure Recordings folder exists
        recordings_folder = self.get_recordings_folder()
        if not recordings_folder.exists():
            recordings_folder.mkdir(parents=True, exist_ok=True)
        
        if self.is_recording:
            # Stop recording
            if self.background_recorder:
                self.background_recorder.stop_recording()
                # Wait for thread to finish (will save automatically if >= 10 frames)
                self.background_recorder.wait(5000)  # Wait up to 5 seconds
                self.background_recorder = None
            
            self.is_recording = False
            self.update_recording_menu()
            self.status_bar.showMessage("Recording stopped", 3000)
        else:
            # Prompt for session name
            session_name, ok = QInputDialog.getText(
                self,
                "Recording Session Name",
                "Enter a name for this recording session:",
                text="recording"
            )
            
            if not ok or not session_name.strip():
                return  # User cancelled or entered empty name
            
            session_name = session_name.strip()
            
            # Find next available file index for this session name
            existing_files = list(recordings_folder.glob(f"{session_name}_*.gif"))
            max_index = 0
            for file in existing_files:
                name = file.stem
                try:
                    # Extract number from name_1, name_2, etc.
                    if "_" in name:
                        index_part = name.split("_")[-1]
                        if index_part.isdigit():
                            max_index = max(max_index, int(index_part))
                except:
                    pass
            
            # Start index will be max_index + 1 (handled by recorder starting at 1)
            # The recorder will use the correct index when saving
            
            # Create background recorder
            self.background_recorder = BackgroundScreenRecorder(
                recordings_folder,
                session_name
            )
            self.background_recorder.file_saved.connect(self.on_recording_file_saved)
            self.background_recorder.recording_stopped.connect(self.on_recording_stopped)
            
            # Set the starting file index based on existing files
            self.background_recorder.current_file_index = max_index + 1
            
            # Start recording
            self.background_recorder.start_recording()
            self.background_recorder.start()
            
            self.is_recording = True
            self.update_recording_menu()
            self.status_bar.showMessage(f"Recording started - Session: {session_name}", 3000)
    
    def on_recording_file_saved(self, file_path):
        """Handle when a recording file is auto-saved"""
        filename = Path(file_path).name
        self.status_bar.showMessage(f"Recording saved: {filename}", 3000)
    
    def on_recording_stopped(self):
        """Handle when recording thread stops"""
        self.is_recording = False
        self.update_recording_menu()
    
    def update_recording_menu(self):
        """Update recording menu based on state"""
        if self.is_recording:
            self.record_action.setText("&Stop Recording")
            self.compress_action.setVisible(False)
        else:
            self.record_action.setText("&Start Recording")
            self.compress_action.setVisible(True)
    
    def compress_recordings_auto(self):
        """Automatically compress all recordings with default settings"""
        if self.is_recording:
            return  # Don't compress while recording
        
        if not self.app.project_manager.get_project_path():
            QMessageBox.warning(self, "No Project", "Please open or create a project first.")
            return
        
        recordings_folder = self.get_recordings_folder()
        if not recordings_folder.exists():
            QMessageBox.information(self, "No Recordings", "No recordings folder found for this project.")
            return
        
        # Get list of GIF files in recordings folder (exclude already compressed ones)
        gif_files = [f for f in recordings_folder.glob("*.gif") if "_compressed" not in f.stem]
        if not gif_files:
            QMessageBox.information(self, "No Recordings", "No GIF files found to compress in recordings folder.")
            return
        
        # Compress each file with defaults (no UI)
        self.status_bar.showMessage("Compressing recordings...", 0)
        
        try:
            # Note: GIF compressor functionality is now integrated into screen_recorder
            # Import from Tools/ScreenRecording (new location)
            try:
                from Tools.ScreenRecording.screen_recorder import GifProcessingThread
                # Use GifProcessingThread for compression if available
                compress_gif = None  # Not needed - using GifProcessingThread instead
            except ImportError:
                # Screen recorder files not yet restored - skip compression
                compress_gif = None
            
            success_count = 0
            total_count = len(gif_files)
            
            for gif_file in gif_files:
                # Skip if already compressed
                if "_compressed" in gif_file.stem:
                    continue
                
                # Generate output filename
                output_file = gif_file.parent / f"{gif_file.stem}_compressed.gif"
                
                # Compress with defaults: 16MB target, 64 colors, 0.8 resize, multi-threaded
                if compress_gif(
                    str(gif_file),
                    str(output_file),
                    target_size_mb=16.0,
                    max_colors=64,
                    resize_factor=0.8,
                    use_multi_threading=True,
                    use_primary_colors=False,
                    verbose=False
                ):
                    success_count += 1
                    # Update status
                    self.status_bar.showMessage(f"Compressed {success_count}/{total_count}: {gif_file.name}", 0)
            
            if success_count > 0:
                self.status_bar.showMessage(f"Compression complete: {success_count} files compressed", 5000)
                QMessageBox.information(self, "Compression Complete", f"Successfully compressed {success_count} of {total_count} recording(s).")
            else:
                self.status_bar.showMessage("Compression failed - no files were compressed", 5000)
                QMessageBox.warning(self, "Compression Failed", "No files were successfully compressed.")
                
        except ImportError as e:
            QMessageBox.critical(self, "Import Error", f"Could not import GIF compressor: {e}")
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Error compressing recordings: {e}")
    
    def view_recordings(self):
        """Open the Recordings folder in Windows Explorer"""
        if not self.app.project_manager.get_project_path():
            QMessageBox.warning(self, "No Project", "Please open or create a project first.")
            return
        
        recordings_folder = self.get_recordings_folder()
        if not recordings_folder.exists():
            recordings_folder.mkdir(parents=True, exist_ok=True)
        
        try:
            # Open folder in Windows Explorer
            if sys.platform == "win32":
                os.startfile(str(recordings_folder))
            else:
                # For other platforms, try to open with default file manager
                subprocess.run(["xdg-open", str(recordings_folder)], check=True)
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Could not open recordings folder: {e}")
    
    def get_recordings_folder(self):
        """Get the Recordings folder path for the current project"""
        project_path = Path(self.app.project_manager.get_project_path())
        return project_path / "Recordings"

# Import required modules
import os
import json
