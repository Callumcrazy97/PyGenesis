"""
Sound Editor for Python Game IDE
GameMaker 8-style sound editor with properties panel and preview box
PGSE "Pigsey" - PyGenesis Sound Editor
"""

from PySide6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLabel, 
                               QPushButton, QSpinBox, QCheckBox, QScrollArea,
                               QFrame, QSplitter, QListWidget, QListWidgetItem,
                               QMessageBox, QFileDialog, QInputDialog, QComboBox, 
                               QSizePolicy, QLineEdit, QGroupBox, QGridLayout,
                               QDialog, QDialogButtonBox, QTabWidget, QTextEdit,
                               QMenu, QMenuBar, QSlider, QProgressBar)
from PySide6.QtCore import Qt, Signal, QSize, QTimer, QThread
from PySide6.QtGui import QPainter, QPen, QBrush, QColor, QPixmap, QFont, QAction

import os
import json
import numpy as np
import wave
import contextlib
import warnings
from typing import Dict, Optional
from Core.EditorInterface import EditorInterface

# Optional audio dependencies - handle gracefully if not installed
try:
    import pygame
    PYGAME_AVAILABLE = True
except ImportError:
    PYGAME_AVAILABLE = False
    print("Warning: pygame not installed. Audio playback will be disabled.")

try:
    from pydub import AudioSegment
    from pydub.utils import which
    PYDUB_AVAILABLE = True
except ImportError:
    PYDUB_AVAILABLE = False
    print("Warning: pydub not installed. Audio file loading will be disabled.")

try:
    import librosa
    LIBROSA_AVAILABLE = True
except ImportError:
    LIBROSA_AVAILABLE = False
    print("Warning: librosa not installed. Waveform generation will be disabled.")

try:
    import mido
    MIDO_AVAILABLE = True
except ImportError:
    MIDO_AVAILABLE = False
    print("Warning: mido not installed. MIDI import will be disabled.")

try:
    from music21 import stream, note, duration, tempo, meter, key, pitch
    MUSIC21_AVAILABLE = True
except ImportError:
    MUSIC21_AVAILABLE = False
    print("Warning: music21 not installed. Advanced MIDI features will be disabled.")

import threading
import time
import tempfile
import uuid

# Suppress repetitive pydub runtime warnings when ffmpeg/ffprobe are unavailable
warnings.filterwarnings(
    "ignore",
    message="Couldn't find ffmpeg or avconv - defaulting to ffmpeg, but may not work",
    category=RuntimeWarning,
    module="pydub.utils"
)
warnings.filterwarnings(
    "ignore",
    message="Couldn't find ffprobe or avprobe - defaulting to ffprobe, but may not work",
    category=RuntimeWarning,
    module="pydub.utils"
)

class WaveformCanvas(QWidget):
    """Custom widget for displaying audio waveforms"""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.waveform_data = None
        self.midi_file = None
        self.is_midi = False
        self.duration = 0
        self.current_position = 0
        
        # Selection state for waveform editing
        self.selection_start = None
        self.selection_end = None
        self.selecting = False
        self.selection_start_pos = None
        
        self.setMinimumHeight(120)
        self.setStyleSheet("""
            WaveformCanvas {
                background-color: #d3d3d3;
                border: 1px solid #555;
            }
        """)
    
    def paintEvent(self, event):
        """Paint the waveform"""
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        
        # Fill background
        painter.fillRect(self.rect(), QColor("#d3d3d3"))
        
        if self.waveform_data is not None and len(self.waveform_data) > 0 and np.max(np.abs(self.waveform_data)) >= 0.0001:
            # Has waveform data (including minimal flat lines for silent tracks)
            self.draw_waveform(painter)
        elif self.is_midi and self.midi_file:
            self.draw_midi_info(painter)
        else:
            self.draw_no_audio(painter)
        
        # Draw selection overlay if active
        if self.selection_start is not None and self.selection_end is not None:
            self.draw_selection_overlay(painter)
        
        # Draw red playback position needle
        self.draw_playback_needle(painter)
        
        painter.end()
    
    def draw_waveform(self, painter):
        """Draw the audio waveform"""
        width = self.width()
        height = self.height()
        center_y = height // 2
        
        # Set blue color for waveform
        painter.setPen(QPen(QColor("#0066cc"), 1))
        painter.setBrush(QBrush(QColor("#0066cc")))
        
        # Draw waveform
        if len(self.waveform_data) > 1:
            points_per_pixel = len(self.waveform_data) / width
            for x in range(width):
                start_idx = int(x * points_per_pixel)
                end_idx = int((x + 1) * points_per_pixel)
                
                if start_idx < len(self.waveform_data):
                    # Get max amplitude in this pixel range
                    segment = self.waveform_data[start_idx:min(end_idx, len(self.waveform_data))]
                    if len(segment) > 0:
                        max_amp = np.max(np.abs(segment))
                        # Convert amplitude to height (0 to center_y)
                        wave_height = int(max_amp * center_y)
                        
                        # Ensure minimum 1 pixel height for visibility (even for silent tracks)
                        if wave_height == 0 and max_amp > 0:
                            wave_height = 1
                        
                        # Draw vertical line from center
                        painter.drawLine(x, center_y - wave_height, x, center_y + wave_height)
    
    def draw_midi_info(self, painter):
        """Draw MIDI information"""
        painter.setPen(QPen(QColor("#333333"), 2))
        painter.setFont(QFont("Arial", 12))
        
        track_count = len(self.midi_file.tracks)
        text = f"MIDI loaded: {track_count} tracks"
        
        # Center the text
        metrics = painter.fontMetrics()
        text_rect = metrics.boundingRect(text)
        x = (self.width() - text_rect.width()) // 2
        y = (self.height() + text_rect.height()) // 2
        
        painter.drawText(x, y, text)
    
    def draw_no_audio(self, painter):
        """Draw no audio message"""
        painter.setPen(QPen(QColor("#666666"), 2))
        painter.setFont(QFont("Arial", 12))
        
        text = "No Audio File Loaded"
        
        # Center the text
        metrics = painter.fontMetrics()
        text_rect = metrics.boundingRect(text)
        x = (self.width() - text_rect.width()) // 2
        y = (self.height() + text_rect.height()) // 2
        
        painter.drawText(x, y, text)
    
    def draw_playback_needle(self, painter):
        """Draw a red vertical line indicating current playback position"""
        if self.duration <= 0:
            return
        
        # Calculate x position based on current_position
        width = self.width()
        height = self.height()
        position_ratio = self.current_position / self.duration if self.duration > 0 else 0
        needle_x = int(position_ratio * width)
        
        # Clamp to valid range
        needle_x = max(0, min(needle_x, width - 1))
        
        # Draw red vertical line
        painter.setPen(QPen(QColor("#FF0000"), 2))
        painter.drawLine(needle_x, 0, needle_x, height)
    
    def update_position(self, position):
        """Update the current playback position and redraw"""
        self.current_position = position
        self.update()  # Trigger repaint
    
    def mousePressEvent(self, event):
        """Handle mouse clicks for seeking or selection"""
        if event.button() == Qt.LeftButton and self.duration > 0:
            click_x = event.x()
            width = self.width()
            position_ratio = click_x / width
            new_position = position_ratio * self.duration
            
            # Check if Shift is held for selection mode
            if event.modifiers() & Qt.ShiftModifier:
                # Start selection
                self.selecting = True
                self.selection_start_pos = click_x
                self.selection_start = new_position
                self.selection_end = new_position
                self.update()
            else:
                # Normal seeking behavior
                # Find SoundPreviewCanvas parent to call seek_to_position
                parent_widget = self.parent()
                while parent_widget:
                    if hasattr(parent_widget, 'seek_to_position'):
                        parent_widget.seek_to_position(new_position)
                        break
                    parent_widget = parent_widget.parent()
                
                # Clear selection on normal click
                self.clear_selection()
    
    def mouseMoveEvent(self, event):
        """Handle mouse movement during selection"""
        if self.selecting and self.duration > 0:
            click_x = event.x()
            width = self.width()
            position_ratio = click_x / width
            new_position = position_ratio * self.duration
            
            # Update selection end
            if self.selection_start_pos is not None:
                self.selection_end = new_position
                # Ensure start < end
                if self.selection_end < self.selection_start:
                    self.selection_start, self.selection_end = self.selection_end, self.selection_start
                self.update()
    
    def mouseReleaseEvent(self, event):
        """Handle mouse release to finalize selection"""
        if event.button() == Qt.LeftButton and self.selecting:
            self.selecting = False
            # Finalize selection
            if abs(self.selection_end - self.selection_start) < 0.01:  # Less than 10ms, clear selection
                self.clear_selection()
            self.update()
    
    def clear_selection(self):
        """Clear the current selection"""
        self.selection_start = None
        self.selection_end = None
        self.selection_start_pos = None
        self.selecting = False
        self.update()
    
    def get_selection(self):
        """Get the current selection range in seconds"""
        if self.selection_start is not None and self.selection_end is not None:
            return (self.selection_start, self.selection_end)
        return None
    
    def draw_selection_overlay(self, painter):
        """Draw selection overlay on waveform"""
        if self.selection_start is None or self.selection_end is None or self.duration <= 0:
            return
        
        width = self.width()
        height = self.height()
        
        # Calculate pixel positions
        start_ratio = self.selection_start / self.duration
        end_ratio = self.selection_end / self.duration
        start_x = int(start_ratio * width)
        end_x = int(end_ratio * width)
        
        # Draw semi-transparent overlay
        overlay_color = QColor(97, 175, 239, 80)  # Blue with transparency
        painter.fillRect(start_x, 0, end_x - start_x, height, overlay_color)
        
        # Draw selection borders
        pen = QPen(QColor(97, 175, 239), 2)
        painter.setPen(pen)
        painter.drawLine(start_x, 0, start_x, height)
        painter.drawLine(end_x, 0, end_x, height)
    
    def update_waveform_data(self, waveform_data, duration):
        """Update waveform data and redraw"""
        self.waveform_data = waveform_data
        self.duration = duration
        self.update()
    
    def update_midi_data(self, midi_file, duration):
        """Update MIDI data and redraw"""
        self.midi_file = midi_file
        self.duration = duration
        self.is_midi = True
        self.update()


class TrackWidget(QWidget):
    """Widget for a single track with controls and waveform"""
    
    def __init__(self, track_name, track_index, parent=None):
        super().__init__(parent)
        self.track_name = track_name
        self.track_index = track_index
        self.waveform_data = None
        self.duration = 0
        
        # Track state
        self.is_muted = False
        self.overall_volume = 1.0
        self.left_enabled = True
        self.right_enabled = True
        self.left_volume = 1.0
        self.right_volume = 1.0
        
        self.setup_ui()
    
    def setup_ui(self):
        """Setup the track UI"""
        layout = QHBoxLayout(self)
        layout.setContentsMargins(5, 5, 5, 5)
        layout.setSpacing(5)
        
        # Left controls column
        controls_layout = QVBoxLayout()
        controls_layout.setSpacing(3)
        
        # Top row: Track name and Mute button
        top_layout = QHBoxLayout()
        self.name_label = QLabel(self.track_name)
        self.name_label.setMinimumWidth(80)
        self.name_label.setStyleSheet("font-weight: bold;")
        top_layout.addWidget(self.name_label)
        
        # Mute button
        self.mute_btn = QPushButton("M")
        self.mute_btn.setCheckable(True)
        self.mute_btn.setChecked(False)
        self.mute_btn.setFixedSize(30, 25)
        self.mute_btn.setToolTip("Mute/Unmute Track")
        self.mute_btn.toggled.connect(self.on_mute_toggled)
        self.mute_btn.setStyleSheet("""
            QPushButton {
                background-color: #666;
                color: white;
                font-weight: bold;
                border: 1px solid #333;
            }
            QPushButton:checked {
                background-color: #F44336;
            }
        """)
        top_layout.addWidget(self.mute_btn)
        controls_layout.addLayout(top_layout)
        
        # Overall Volume slider (horizontal)
        volume_label = QLabel("Vol:")
        volume_label.setMinimumWidth(30)
        controls_layout.addWidget(volume_label)
        
        self.overall_volume_slider = QSlider(Qt.Horizontal)
        self.overall_volume_slider.setMinimum(0)
        self.overall_volume_slider.setMaximum(100)
        self.overall_volume_slider.setValue(100)
        self.overall_volume_slider.setMaximumWidth(100)
        self.overall_volume_slider.valueChanged.connect(self.on_overall_volume_changed)
        self.overall_volume_slider.setToolTip("Overall Track Volume")
        controls_layout.addWidget(self.overall_volume_slider)
        
        # L/R buttons row
        lr_layout = QHBoxLayout()
        
        self.left_btn = QPushButton("L")
        self.left_btn.setCheckable(True)
        self.left_btn.setChecked(True)
        self.left_btn.setFixedSize(30, 25)
        self.left_btn.toggled.connect(self.on_left_toggled)
        self.left_btn.setStyleSheet("""
            QPushButton {
                background-color: #4CAF50;
                color: white;
                font-weight: bold;
                border: 1px solid #333;
            }
            QPushButton:checked {
                background-color: #4CAF50;
            }
            QPushButton:!checked {
                background-color: #555;
            }
        """)
        lr_layout.addWidget(self.left_btn)
        
        self.right_btn = QPushButton("R")
        self.right_btn.setCheckable(True)
        self.right_btn.setChecked(True)
        self.right_btn.setFixedSize(30, 25)
        self.right_btn.toggled.connect(self.on_right_toggled)
        self.right_btn.setStyleSheet("""
            QPushButton {
                background-color: #2196F3;
                color: white;
                font-weight: bold;
                border: 1px solid #333;
            }
            QPushButton:checked {
                background-color: #2196F3;
            }
            QPushButton:!checked {
                background-color: #555;
            }
        """)
        lr_layout.addWidget(self.right_btn)
        
        controls_layout.addLayout(lr_layout)
        
        # L/R Volume sliders
        volumes_layout = QHBoxLayout()
        
        self.left_volume_slider = QSlider(Qt.Vertical)
        self.left_volume_slider.setMinimum(0)
        self.left_volume_slider.setMaximum(100)
        self.left_volume_slider.setValue(100)
        self.left_volume_slider.setMaximumHeight(60)
        self.left_volume_slider.valueChanged.connect(self.on_left_volume_changed)
        self.left_volume_slider.setToolTip("Left Channel Volume")
        volumes_layout.addWidget(self.left_volume_slider)
        
        self.right_volume_slider = QSlider(Qt.Vertical)
        self.right_volume_slider.setMinimum(0)
        self.right_volume_slider.setMaximum(100)
        self.right_volume_slider.setValue(100)
        self.right_volume_slider.setMaximumHeight(60)
        self.right_volume_slider.valueChanged.connect(self.on_right_volume_changed)
        self.right_volume_slider.setToolTip("Right Channel Volume")
        volumes_layout.addWidget(self.right_volume_slider)
        
        controls_layout.addLayout(volumes_layout)
        controls_layout.addStretch()
        
        layout.addLayout(controls_layout)
        
        # Waveform canvas for this track
        self.track_waveform = WaveformCanvas(self)
        self.track_waveform.setMinimumHeight(80)
        self.track_waveform.setMinimumWidth(300)
        layout.addWidget(self.track_waveform, stretch=1)
        
        # Initialize visual state
        self.update_visual_state()
    
    def on_mute_toggled(self, checked):
        """Handle mute button toggle"""
        self.is_muted = checked
        self.update_visual_state()
        # Update playback - mute state changed requires MIDI file recreation
        self.update_playback_volume(mute_state_changed=True)
    
    def on_overall_volume_changed(self, value):
        """Handle overall volume slider change"""
        self.overall_volume = value / 100.0
        self.update_visual_state()
        # Update playback volume - volume only, no file recreation needed
        self.update_playback_volume(mute_state_changed=False)
    
    def on_left_toggled(self, checked):
        """Handle left channel button toggle"""
        self.left_enabled = checked
        # Volume change only (doesn't affect which tracks play for MIDI)
        self.update_playback_volume(mute_state_changed=False)
    
    def on_right_toggled(self, checked):
        """Handle right channel button toggle"""
        self.right_enabled = checked
        # Volume change only (doesn't affect which tracks play for MIDI)
        self.update_playback_volume(mute_state_changed=False)
    
    def on_left_volume_changed(self, value):
        """Handle left volume slider change"""
        self.left_volume = value / 100.0
        # Volume change only
        self.update_playback_volume(mute_state_changed=False)
    
    def on_right_volume_changed(self, value):
        """Handle right volume slider change"""
        self.right_volume = value / 100.0
        # Volume change only
        self.update_playback_volume(mute_state_changed=False)
    
    def update_playback_volume(self, mute_state_changed=False):
        """Simplified: Update channel volume in real-time - no file recreation needed"""
        # Find parent SoundPreviewCanvas
        parent = self.parent()
        while parent and not isinstance(parent, SoundPreviewCanvas):
            parent = parent.parent()
        
        if not parent:
            return
        
        # Sync widget state to simplified tracks dict
        if hasattr(parent, 'tracks') and self.track_index < len(parent.tracks):
            parent.tracks[self.track_index]["muted"] = self.is_muted
            parent.tracks[self.track_index]["volume"] = self.overall_volume
            parent.tracks[self.track_index]["left_enabled"] = self.left_enabled
            parent.tracks[self.track_index]["right_enabled"] = self.right_enabled
            parent.tracks[self.track_index]["left_volume"] = self.left_volume
            parent.tracks[self.track_index]["right_volume"] = self.right_volume
        
        effective_volume = parent.calculate_effective_volume()
        
        # If all tracks muted and currently playing, stop playback
        if effective_volume == 0.0:
            if hasattr(parent, 'is_playing') and parent.is_playing:
                if PYGAME_AVAILABLE:
                    parent.stop_audio_playback()
            return
        
        # Simplified: Update channel volume in real-time for all file types
        if PYGAME_AVAILABLE and hasattr(parent, 'playback_channels'):
            for channel in parent.playback_channels:
                if channel:
                    channel.set_volume(effective_volume)
    
    def update_visual_state(self):
        """Update visual state based on mute and volume"""
        # Check if track should be greyed out (muted or 0 volume)
        should_grey_out = self.is_muted or self.overall_volume == 0
        
        if should_grey_out:
            # Grey out style
            self.setStyleSheet("""
                TrackWidget {
                    background-color: #2a2a2a;
                    color: #888;
                }
            """)
            self.name_label.setStyleSheet("font-weight: bold; color: #888;")
            # Disable controls (visual feedback) - but keep mute button enabled
            self.left_btn.setEnabled(False)
            self.right_btn.setEnabled(False)
            self.left_volume_slider.setEnabled(False)
            self.right_volume_slider.setEnabled(False)
            # Keep overall volume slider enabled so user can unmute
            self.overall_volume_slider.setEnabled(True)
            # Mute button stays enabled so user can unmute
        else:
            # Normal style
            self.setStyleSheet("")
            self.name_label.setStyleSheet("font-weight: bold;")
            # Enable all controls
            self.left_btn.setEnabled(True)
            self.right_btn.setEnabled(True)
            self.left_volume_slider.setEnabled(True)
            self.right_volume_slider.setEnabled(True)
            self.overall_volume_slider.setEnabled(True)
        
        # Update waveform opacity if available
        if self.track_waveform:
            if should_grey_out:
                self.track_waveform.setStyleSheet("""
                    WaveformCanvas {
                        background-color: #d3d3d3;
                        border: 1px solid #555;
                        opacity: 0.4;
                    }
                """)
            else:
                self.track_waveform.setStyleSheet("""
                    WaveformCanvas {
                        background-color: #d3d3d3;
                        border: 1px solid #555;
                    }
                """)
    
    def update_waveform(self, waveform_data, duration):
        """Update the track's waveform"""
        self.waveform_data = waveform_data
        self.duration = duration
        if self.track_waveform:
            self.track_waveform.update_waveform_data(waveform_data, duration)
        # Update visual state after waveform update
        self.update_visual_state()
    
    def get_effective_volume_left(self):
        """Get effective left channel volume considering all controls"""
        if self.is_muted or self.overall_volume == 0:
            return 0.0
        if not self.left_enabled:
            return 0.0
        return self.overall_volume * self.left_volume
    
    def get_effective_volume_right(self):
        """Get effective right channel volume considering all controls"""
        if self.is_muted or self.overall_volume == 0:
            return 0.0
        if not self.right_enabled:
            return 0.0
        return self.overall_volume * self.right_volume


class TrackListView(QWidget):
    """Scrollable list of tracks with horizontal and vertical scrolling"""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.tracks = []
        self.setup_ui()
    
    def setup_ui(self):
        """Setup the track list UI with scrolling"""
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        
        # Create scroll area
        self.scroll_area = QScrollArea()
        self.scroll_area.setWidgetResizable(True)
        self.scroll_area.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        self.scroll_area.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        
        # Create container widget for tracks
        self.tracks_container = QWidget()
        self.tracks_layout = QVBoxLayout(self.tracks_container)
        self.tracks_layout.setContentsMargins(5, 5, 5, 5)
        self.tracks_layout.setSpacing(5)
        self.tracks_layout.addStretch()
        
        self.scroll_area.setWidget(self.tracks_container)
        layout.addWidget(self.scroll_area)
    
    def add_track(self, track_name, track_index):
        """Add a new track to the list"""
        track_widget = TrackWidget(track_name, track_index, self)
        
        # Insert before the stretch
        self.tracks_layout.insertWidget(self.tracks_layout.count() - 1, track_widget)
        self.tracks.append(track_widget)
        
        return track_widget
    
    def clear_tracks(self):
        """Clear all tracks"""
        for track in self.tracks:
            track.deleteLater()
        self.tracks.clear()
        # Keep the stretch at the end
        while self.tracks_layout.count() > 1:
            item = self.tracks_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
    
    def get_track(self, index):
        """Get track widget by index"""
        if 0 <= index < len(self.tracks):
            return self.tracks[index]
        return None


class SoundPreviewCanvas(QWidget):
    """Simplified preview canvas using pygame.mixer.Channel for real-time control"""
    
    def __init__(self, editor):
        super().__init__()
        self.editor = editor
        
        # Simplified: Everything stored as WAV AudioSegment
        self.audio_segment = None  # pydub AudioSegment (converted from any format)
        self.waveform_data = None
        
        # Simplified: Simple list of track dicts instead of TrackWidget classes
        # Format: [{"name": "Track 1", "volume": 1.0, "muted": False, "waveform_data": np.array}, ...]
        self.tracks = []
        
        # Simplified playback state
        self.is_playing = False
        self.is_paused = False
        self.current_position = 0.0
        self.duration = 0.0
        self.loop_enabled = False
        self.playback_start_time = None  # Simple: time.time() when playback started
        self.segment_start_pos = 0.0  # Position where current playback segment started
        self.pause_start_time = None  # When we paused (for calculating pause duration)
        self.updating_progress_bar = False
        
        # Simplified: Use pygame.mixer.Channel for each track
        self.playback_channels = []  # List of pygame.mixer.Channel objects
        
        # Initialize pygame mixer
        if PYGAME_AVAILABLE:
            pygame.mixer.init(frequency=44100, size=-16, channels=2, buffer=512)
            # Reserve channels for playback
            pygame.mixer.set_num_channels(32)
        
        self.setup_ui()
        self.setup_timer()
    
    def setup_ui(self):
        """Setup the preview UI"""
        layout = QVBoxLayout(self)
        layout.setContentsMargins(5, 5, 5, 5)
        
        # Controls layout
        controls_layout = QHBoxLayout()
        
        # Playback controls
        self.play_btn = QPushButton("▶")
        self.play_btn.setFixedSize(30, 30)
        self.play_btn.clicked.connect(self.toggle_playback)
        self.play_btn.setToolTip("Play/Pause")
        controls_layout.addWidget(self.play_btn)
        
        self.stop_btn = QPushButton("⏹")
        self.stop_btn.setFixedSize(30, 30)
        self.stop_btn.clicked.connect(self.stop_audio_playback)
        self.stop_btn.setToolTip("Stop")
        controls_layout.addWidget(self.stop_btn)
        
        # Time display
        self.time_label = QLabel("00:00 / 00:00")
        self.time_label.setMinimumWidth(100)
        controls_layout.addWidget(self.time_label)
        
        # Progress bar
        self.progress_bar = QSlider(Qt.Horizontal)
        self.progress_bar.setMinimum(0)
        self.progress_bar.setMaximum(1000)
        self.progress_bar.valueChanged.connect(self.on_progress_changed)
        self.progress_bar.sliderReleased.connect(self.on_progress_released)
        controls_layout.addWidget(self.progress_bar)
        
        # Loop checkbox
        self.loop_checkbox = QCheckBox("Loop")
        self.loop_checkbox.toggled.connect(self.on_loop_toggled)
        controls_layout.addWidget(self.loop_checkbox)
        
        controls_layout.addStretch()
        layout.addLayout(controls_layout)
        
        # Track list view (replaces single waveform)
        self.track_list_view = TrackListView(self)
        self.track_list_view.setMinimumHeight(200)
        layout.addWidget(self.track_list_view)
        
        # Keep waveform_area for backward compatibility (used in some methods)
        self.waveform_area = None
        
        # Click position indicator
        self.click_position = None
    
    def setup_timer(self):
        """Setup timer for updating playback position"""
        self.update_timer = QTimer()
        self.update_timer.timeout.connect(self.update_playback_position)
        self.update_timer.start(50)  # Update every 50ms
    
    def cleanup_on_close(self):
        """Cleanup when the editor is closed"""
        self.stop_audio_playback()
        self.cleanup_temp_files()
        if self.update_timer:
            self.update_timer.stop()
        if PYGAME_AVAILABLE:
            try:
                pygame.mixer.music.stop()
                pygame.mixer.stop()
            except Exception:
                pass
    
    def seek_to_position(self, position):
        """Seek to a specific position in the audio"""
        if self.duration <= 0:
            return
        
        # Clamp position to valid range
        position = max(0, min(position, self.duration))
        
        # For MIDI files, we need a different approach since we can't segment the audio
        if self.is_midi:
            # Store the target position and restart playback
            self.target_seek_position = position
            self.current_position = position
            self.update_display()
            
            # If currently playing, restart from beginning
            if self.is_playing and not self.is_paused:
                self.restart_midi_playback_from_position(position)
            return
        
        self.current_position = position
        
        # Update display immediately
        self.update_display()
        
        # If currently playing, restart playback from new position
        if self.is_playing and not self.is_paused:
            self.restart_playback_from_position(position)
    
    def load_audio_file(self, file_path):
        """Simplified: Load WAV or MP3 files and convert to AudioSegment"""
        try:
            # Normalize path to handle mixed slashes
            file_path = os.path.normpath(file_path)
            
            if not os.path.exists(file_path):
                print(f"Error: Audio file not found: {file_path}")
                return False
            
            # Only support WAV and MP3 files
            if not file_path.lower().endswith(('.wav', '.mp3')):
                print(f"Unsupported file format. Only WAV and MP3 files are supported.")
                return False
            
            # Load audio file using pydub
            if not PYDUB_AVAILABLE:
                print("pydub not available for audio file loading")
                return False
            
            try:
                # For WAV files, prefer loading without ffmpeg when possible
                if file_path.lower().endswith('.wav'):
                    try:
                        self.audio_segment = AudioSegment.from_wav(file_path)
                        self.duration = len(self.audio_segment) / 1000.0
                    except FileNotFoundError:
                        # from_wav attempted to call ffprobe; fall back to pure wave reader
                        self.audio_segment = self._load_wav_without_ffmpeg(file_path)
                        self.duration = len(self.audio_segment) / 1000.0
                    except Exception as wav_error:
                        self.audio_segment = self._load_wav_without_ffmpeg(file_path)
                        self.duration = len(self.audio_segment) / 1000.0
                else:
                    # For MP3, use from_file() which may require ffmpeg
                    # For now, show an error if ffmpeg isn't available
                    try:
                        self.audio_segment = AudioSegment.from_file(file_path)
                        self.duration = len(self.audio_segment) / 1000.0
                    except Exception as mp3_error:
                        # Check if it's an ffmpeg error
                        if "ffmpeg" in str(mp3_error).lower() or "ffprobe" in str(mp3_error).lower():
                            print(f"MP3 files require ffmpeg. Error: {mp3_error}")
                            # Try using soundfile as fallback if available
                            try:
                                import soundfile as sf
                                data, sample_rate = sf.read(file_path)
                                # Convert to AudioSegment
                                import tempfile
                                with tempfile.NamedTemporaryFile(suffix='.wav', delete=False) as tmp:
                                    temp_wav = tmp.name
                                sf.write(temp_wav, data, sample_rate)
                                self.audio_segment = AudioSegment.from_wav(temp_wav)
                                os.remove(temp_wav)
                                self.duration = len(self.audio_segment) / 1000.0
                            except Exception as sf_error:
                                print(f"Fallback soundfile load also failed: {sf_error}")
                                raise mp3_error
                        else:
                            raise
            except Exception as e:
                import traceback
                print(f"Error loading audio file '{file_path}': {e}")
                print(f"Traceback: {traceback.format_exc()}")
                # Try soundfile as final fallback for WAV files
                if file_path.lower().endswith('.wav'):
                    try:
                        self.audio_segment = self._load_wav_without_ffmpeg(file_path)
                        self.duration = len(self.audio_segment) / 1000.0
                    except Exception as e2:
                        print(f"Fallback soundfile load also failed: {e2}")
                        return False
                else:
                    return False
            
            # Generate waveform data
            self.generate_waveform_from_audio_segment()
            
            # Simplified: Create simple track dict instead of TrackWidget
            # For now, create one track (mono/stereo audio)
            self.tracks = []
            
            # Create a single track for the audio
            track = {
                "name": "Track 1",
                "volume": 1.0,
                "muted": False,
                "waveform_data": self.waveform_data,
                "left_enabled": True,
                "right_enabled": True,
                "left_volume": 1.0,
                "right_volume": 1.0
            }
            self.tracks.append(track)
            
            # Update UI with simplified tracks
            self.update_track_list_ui()
            self.update_display()
            
            return True
                
        except Exception as e:
            print(f"Error loading file: {e}")
            import traceback
            traceback.print_exc()
            return False
    
    def _load_wav_without_ffmpeg(self, file_path):
        """Load a WAV file without relying on ffmpeg/ffprobe by using the wave module."""
        if not PYDUB_AVAILABLE:
            raise RuntimeError("pydub is required to construct AudioSegment instances.")
        
        try:
            with wave.open(file_path, "rb") as wav_file:
                comptype = wav_file.getcomptype()
                if comptype not in ("NONE", "not compressed"):
                    raise wave.Error(f"Compressed WAV '{comptype}' requires ffmpeg or pygame fallback.")
                sample_width = wav_file.getsampwidth()
                frame_rate = wav_file.getframerate()
                channels = wav_file.getnchannels()
                frame_count = wav_file.getnframes()
                raw_audio = wav_file.readframes(frame_count)
        except wave.Error as err:
            if PYGAME_AVAILABLE:
                segment = self._load_wav_via_pygame(file_path)
                if segment is not None:
                    return segment
            raise err
        
        return AudioSegment(
            data=raw_audio,
            sample_width=sample_width,
            frame_rate=frame_rate,
            channels=channels
        )

    def _load_wav_via_pygame(self, file_path):
        """Fallback loader for compressed WAVs using pygame's decoder."""
        if not PYGAME_AVAILABLE:
            return None
        
        try:
            if pygame.mixer.get_init() is None:
                pygame.mixer.init(frequency=44100, size=-16, channels=2, buffer=512)
            
            sound = pygame.mixer.Sound(file_path)
            from pygame import sndarray as pygame_sndarray
            samples = pygame_sndarray.array(sound)
            
            mixer_init = pygame.mixer.get_init()
            if not mixer_init:
                return None
            frame_rate, mixer_format, mixer_channels = mixer_init
            sample_width = abs(mixer_format) // 8 if mixer_format else 2
            
            if samples.ndim == 1 and mixer_channels > 1:
                samples = samples.reshape(-1, mixer_channels)
            
            samples = np.asarray(samples)
            if sample_width == 2:
                samples = samples.astype(np.int16, copy=False)
            elif sample_width == 1:
                samples = samples.astype(np.uint8, copy=False)
            else:
                samples = samples.astype(np.int16, copy=False)
                sample_width = 2
            
            channels = samples.shape[1] if samples.ndim > 1 else 1
            raw_audio = np.ascontiguousarray(samples).tobytes()
            
            return AudioSegment(
                data=raw_audio,
                sample_width=sample_width,
                frame_rate=frame_rate,
                channels=channels
            )
        except Exception as pygame_err:
            print(f"Pygame fallback failed to load '{file_path}': {pygame_err}")
            return None
    
    def generate_waveform_from_audio_segment(self):
        """Simplified: Generate waveform from AudioSegment"""
        try:
            if self.audio_segment is None:
                return False
            
            # Convert AudioSegment to numpy array
            samples = np.array(self.audio_segment.get_array_of_samples())
            
            # Convert to mono if stereo
            if self.audio_segment.channels == 2:
                samples = samples.reshape((-1, 2)).mean(axis=1)
            
            # Downsample for visualization (max 1000 points)
            max_points = 1000
            if len(samples) > max_points:
                step = len(samples) // max_points
                samples = samples[::step]
            
            # Normalize to -1 to 1 range
            if len(samples) > 0:
                max_val = np.max(np.abs(samples))
                if max_val > 0:
                    samples = samples / max_val
                else:
                    samples = np.full(len(samples), 0.01)  # Minimal flat line
            
            self.waveform_data = samples
            return True
            
        except Exception as e:
            print(f"Error generating waveform: {e}")
            # Fallback: create minimal flat line
            duration = self.duration if self.duration > 0 else 1.0
            samples = np.full(1000, 0.01)
            self.waveform_data = samples
            return True
    
    def update_track_list_ui(self):
        """Simplified: Update UI track list from simplified track dicts"""
        # Clear existing tracks
        self.track_list_view.clear_tracks()
        
        # Create TrackWidget instances from simplified track dicts
        # (Keep UI widgets for now, but data comes from dicts)
        for i, track in enumerate(self.tracks):
            track_widget = self.track_list_view.add_track(track["name"], i)
            if track.get("waveform_data") is not None:
                track_widget.update_waveform(track["waveform_data"], self.duration)
            # Sync widget state with dict
            track_widget.is_muted = track.get("muted", False)
            track_widget.overall_volume = track.get("volume", 1.0)
            track_widget.left_enabled = track.get("left_enabled", True)
            track_widget.right_enabled = track.get("right_enabled", True)
            track_widget.left_volume = track.get("left_volume", 1.0)
            track_widget.right_volume = track.get("right_volume", 1.0)
            track_widget.update_visual_state()
    
    def load_midi_file(self, file_path):
        """Load a MIDI file and generate waveform visualization"""
        try:
            if not MIDO_AVAILABLE:
                print("Warning: mido not available, cannot load MIDI file")
                return False
            
            
            # Load MIDI file
            midi_file = mido.MidiFile(file_path)
            self.duration = midi_file.length
            
            
            # Store MIDI file info
            self.midi_file = midi_file
            self.is_midi = True
            
            # Clear existing tracks and populate with MIDI tracks
            self.track_list_view.clear_tracks()
            
            # Generate waveform data for display
            waveform_success = self.generate_waveform_from_audio_file(file_path)
            
            # Create a track for each MIDI track
            for i, track in enumerate(midi_file.tracks):
                track_name = f"Track {i + 1}"
                if hasattr(track, 'name') and track.name:
                    track_name = f"{track_name} - {track.name}"
                
                track_widget = self.track_list_view.add_track(track_name, i)
                
                # Generate unique waveform for this MIDI track based on actual note events
                track_waveform = self.generate_midi_track_waveform(track, midi_file, i)
                if track_waveform is not None and len(track_waveform) > 0:
                    # Ensure waveform is not all zeros
                    if np.max(np.abs(track_waveform)) > 0:
                        track_widget.update_waveform(track_waveform, self.duration)
                    else:
                        # Silent track - create minimal flat line
                        duration = self.duration
                        sample_rate = 1000
                        total_samples = int(duration * sample_rate)
                        max_points = 1000
                        if total_samples > max_points:
                            step = total_samples // max_points
                            silent_waveform = np.full(max_points, 0.01)  # Small but visible
                        else:
                            silent_waveform = np.full(total_samples, 0.01)  # Small but visible
                        track_widget.update_waveform(silent_waveform, self.duration)
                else:
                    # Fallback to minimal flat line waveform (for empty tracks)
                    duration = self.duration
                    sample_rate = 1000
                    total_samples = int(duration * sample_rate)
                    max_points = 1000
                    if total_samples > max_points:
                        step = total_samples // max_points
                        silent_waveform = np.full(max_points, 0.01)  # Small but visible
                    else:
                        silent_waveform = np.full(total_samples, 0.01)  # Small but visible
                    track_widget.update_waveform(silent_waveform, self.duration)
            
            # If no tracks, create a default one
            if len(midi_file.tracks) == 0:
                track_widget = self.track_list_view.add_track("Track 1", 0)
                if self.waveform_data is not None:
                    track_widget.update_waveform(self.waveform_data, self.duration)
            
            # Clear audio data (not needed for native MIDI playback)
            self.audio_data = None
            
            # Update display
            self.update_display()
            
            return True
            
        except Exception as e:
            print(f"ERROR: Failed to load MIDI file {file_path}: {e}")
            return False
    
    def load_audio_file_pydub(self, file_path):
        """Load an audio file using pydub"""
        try:
            if not PYDUB_AVAILABLE:
                print("Warning: pydub not available, cannot load audio file")
                return False
            
            
            # Load audio with pydub
            self.audio_data = AudioSegment.from_file(file_path)
            self.duration = len(self.audio_data) / 1000.0  # Convert to seconds
            
            # Clear existing tracks
            self.track_list_view.clear_tracks()
            
            # Generate waveform data for visualization
            self.generate_waveform_from_audio_file(file_path)
            
            # Create tracks based on channels
            channels = self.audio_data.channels
            if channels == 1:
                # Mono - single track
                track_widget = self.track_list_view.add_track("Track 1", 0)
                if self.waveform_data is not None:
                    track_widget.update_waveform(self.waveform_data, self.duration)
            else:
                # Multi-channel - create a track for each channel or combined
                # For simplicity, show as one track with L/R controls
                track_widget = self.track_list_view.add_track("Track 1", 0)
                if self.waveform_data is not None:
                    track_widget.update_waveform(self.waveform_data, self.duration)
                # Could also create separate tracks per channel in the future
                # for i in range(channels):
                #     track_widget = self.track_list_view.add_track(f"Track {i + 1} (Channel {i + 1})", i)
            
            # Load into pygame for playback if available
            if PYGAME_AVAILABLE:
                pygame.mixer.music.load(file_path)
            else:
                pass
            
            # Clear MIDI-specific data
            self.midi_file = None
            self.is_midi = False
            
            self.update_display()
            return True
            
        except Exception as e:
            print(f"Error loading audio file: {e}")
            return False
    
    def generate_waveform_data(self):
        """Generate waveform visualization data"""
        if not self.audio_data:
            return
        
        
        # Convert to numpy array for processing
        samples = np.array(self.audio_data.get_array_of_samples())
        
        
    def generate_waveform_from_audio_file(self, file_path):
        """Generate waveform data from ANY audio file - universal approach"""
        try:
            
            # Check if it's a MIDI file first
            is_midi = file_path.lower().endswith(('.mid', '.midi'))
            
            if is_midi:
                # For MIDI files, create a synthetic waveform based on duration
                duration = self.duration if hasattr(self, 'duration') else 10.0
                sample_rate = 1000  # 1000 samples per second for visualization
                total_samples = int(duration * sample_rate)
                
                # Create a more interesting synthetic waveform for MIDI
                t = np.linspace(0, duration, total_samples)
                # Create a pattern that looks more like music
                samples = (np.sin(2 * np.pi * 0.5 * t) * 0.3 + 
                          np.sin(2 * np.pi * 1.0 * t) * 0.2 + 
                          np.sin(2 * np.pi * 2.0 * t) * 0.1)
                
                
            else:
                # For actual audio files, try pydub first
                if PYDUB_AVAILABLE:
                    try:
                        audio_segment = AudioSegment.from_file(file_path)
                        
                        # Convert to numpy array for waveform generation
                        samples = np.array(audio_segment.get_array_of_samples())
                        
                        # Convert to mono if stereo
                        if audio_segment.channels == 2:
                            samples = samples.reshape((-1, 2)).mean(axis=1)
                        
                        
                    except Exception as e:
                        if LIBROSA_AVAILABLE:
                            samples, sample_rate = librosa.load(file_path, sr=None)
                        else:
                            raise e
                
                elif LIBROSA_AVAILABLE:
                    samples, sample_rate = librosa.load(file_path, sr=None)
                else:
                    duration = self.duration if hasattr(self, 'duration') else 10.0
                    sample_rate = 1000
                    total_samples = int(duration * sample_rate)
                    t = np.linspace(0, duration, total_samples)
                    samples = np.sin(2 * np.pi * 0.5 * t) * 0.3
            
            # Verify we have valid data
            if len(samples) == 0:
                print("ERROR: No samples generated")
                return False
            
            # Downsample for visualization (max 1000 points)
            max_points = 1000
            if len(samples) > max_points:
                step = len(samples) // max_points
                samples = samples[::step]
            
            
            # Normalize to -1 to 1 range
            if len(samples) > 0:
                max_val = np.max(np.abs(samples))
                if max_val > 0:
                    samples = samples / max_val
                else:
                    print("WARNING: All samples are zero")
                    return False
            
            self.waveform_data = samples
            return True
            
        except Exception as e:
            print(f"ERROR: Failed to generate waveform from {file_path}: {e}")
            # Create a fallback waveform
            duration = self.duration if hasattr(self, 'duration') else 10.0
            sample_rate = 1000
            total_samples = int(duration * sample_rate)
            t = np.linspace(0, duration, total_samples)
            fallback_data = np.sin(2 * np.pi * 0.5 * t) * 0.3
            
            # Downsample
            max_points = 1000
            if len(fallback_data) > max_points:
                step = len(fallback_data) // max_points
                fallback_data = fallback_data[::step]
            
            self.waveform_data = fallback_data
            return True
    
    def generate_midi_track_waveform(self, midi_track, midi_file, track_index):
        """Generate a unique waveform for a specific MIDI track based on actual note events"""
        try:
            if not MIDO_AVAILABLE:
                return None
            
            duration = self.duration
            sample_rate = 1000  # 1000 samples per second for visualization
            total_samples = int(duration * sample_rate)
            waveform = np.zeros(total_samples)
            
            # Extract tempo from MIDI file (default to 500000 = 120 BPM)
            tempo = 500000  # microseconds per quarter note
            # Try to find tempo in first track or track 0
            try:
                if len(midi_file.tracks) > 0:
                    for msg in midi_file.tracks[0]:
                        if msg.type == 'set_tempo':
                            tempo = msg.tempo
                            break
            except:
                pass
            
            # Track active notes: {note_number: (start_time, velocity)}
            active_notes = {}
            current_time = 0.0
            
            # Parse MIDI track events
            for msg in midi_track:
                # Convert ticks to seconds using actual tempo
                current_time += mido.tick2second(msg.time, midi_file.ticks_per_beat, tempo)
                
                if msg.type == 'note_on' and msg.velocity > 0:
                    # Note starts
                    active_notes[msg.note] = (current_time, msg.velocity)
                elif msg.type == 'note_off' or (msg.type == 'note_on' and msg.velocity == 0):
                    # Note ends
                    if msg.note in active_notes:
                        start_time, velocity = active_notes[msg.note]
                        note_duration = current_time - start_time
                        
                        # Calculate frequency from MIDI note number
                        # MIDI note 60 = C4 = 261.63 Hz
                        freq = 440.0 * (2.0 ** ((msg.note - 69) / 12.0))
                        
                        # Add note to waveform
                        start_sample = int(start_time * sample_rate)
                        end_sample = int(current_time * sample_rate)
                        
                        if start_sample < total_samples and end_sample <= total_samples:
                            # Generate note waveform
                            note_samples = end_sample - start_sample
                            if note_samples > 0:
                                t = np.linspace(0, note_duration, note_samples)
                                # Create waveform with envelope (attack, sustain, release)
                                envelope = np.ones(note_samples)
                                # Attack
                                attack_samples = min(int(0.01 * sample_rate), note_samples // 10)
                                if attack_samples > 0:
                                    envelope[:attack_samples] = np.linspace(0, 1, attack_samples)
                                # Release
                                release_samples = min(int(0.05 * sample_rate), note_samples // 5)
                                if release_samples > 0 and note_samples > release_samples:
                                    envelope[-release_samples:] = np.linspace(1, 0, release_samples)
                                
                                # Generate note tone (sine wave with harmonics)
                                note_wave = (np.sin(2 * np.pi * freq * t) * 0.5 +
                                           np.sin(2 * np.pi * freq * 2 * t) * 0.25 +
                                           np.sin(2 * np.pi * freq * 3 * t) * 0.125)
                                
                                # Apply velocity and envelope
                                amplitude = (velocity / 127.0) * envelope
                                note_waveform = note_wave * amplitude
                                
                                # Add to main waveform
                                waveform[start_sample:end_sample] += note_waveform
                        
                        del active_notes[msg.note]
            
            # Normalize waveform
            if len(waveform) > 0:
                max_val = np.max(np.abs(waveform))
                if max_val > 0:
                    waveform = waveform / max_val
                else:
                    # Silent track - create minimal flat line (not zeros) so it displays
                    # Use a small constant value to show it's a silent track (flat line)
                    waveform = np.full(total_samples, 0.01)  # Small but visible
            
            # Downsample for visualization
            max_points = 1000
            if len(waveform) > max_points:
                step = len(waveform) // max_points
                waveform = waveform[::step]
            
            # Ensure we never return all zeros (would show "No Audio File Loaded")
            if np.max(np.abs(waveform)) == 0:
                waveform = np.full(len(waveform), 0.01)  # Small but visible flat line
            
            return waveform
            
        except Exception as e:
            print(f"Error generating MIDI track waveform: {e}")
            return None
    
    def update_display(self):
        """Update the waveform display"""
        
        # Track waveforms are already updated when files are loaded
        # Here we just update the time display and progress bar
        
        # Update time display
        current_time = self.format_time(self.current_position)
        total_time = self.format_time(self.duration)
        self.time_label.setText(f"{current_time} / {total_time}")
        
        # Update progress bar
        self.update_progress_bar()
        
        # Update red playback needle position in all track waveforms
        if hasattr(self, 'track_list_view') and self.track_list_view:
            for track_widget in self.track_list_view.tracks:
                if hasattr(track_widget, 'track_waveform') and track_widget.track_waveform:
                    track_widget.track_waveform.update_position(self.current_position)
    
    def find_references(self):
        """Find all resources that reference this sound"""
        from PySide6.QtWidgets import QMessageBox
        
        if not self._resource_id or not self.app:
            QMessageBox.information(self, "No Resource", "No resource loaded")
            return
        
        # Use the same logic as ResourceTree
        references = self._find_resource_references("sounds", self._resource_id, self._resource_name)
        
        # Display results
        if references:
            ref_text = f"'{self._resource_name}' is referenced by:\n\n"
            for ref in references:
                ref_text += f"• {ref['type'].title()}: {ref['name']}\n"
            
            QMessageBox.information(self, "Resource References", ref_text)
        else:
            QMessageBox.information(
                self,
                "No References",
                f"'{self._resource_name}' is not referenced by any other resources."
            )
        
        # Update display
        self.update_references_display()
    
    def update_references_display(self):
        """Update the 'Used by' label in properties panel"""
        if not hasattr(self, 'used_by_label') or not self._resource_id:
            return
        
        references = self._find_resource_references("sounds", self._resource_id, self._resource_name)
        
        if references:
            # Show first few references
            ref_text = "Used by: "
            ref_names = [f"{ref['type'].title()}: {ref['name']}" for ref in references[:3]]
            ref_text += ", ".join(ref_names)
            if len(references) > 3:
                ref_text += f" (+{len(references) - 3} more)"
            self.used_by_label.setText(ref_text)
        else:
            self.used_by_label.setText("Used by: None")
    
    def _find_resource_references(self, resource_type, resource_id, resource_name):
        """Find all resources that reference the given resource (reused from ResourceTree logic)"""
        import os
        references = []
        project_path = self.app.project_manager.get_project_path()
        if not project_path:
            return references
        
        # Scan all resource types for references
        for ref_type in ["sprites", "backgrounds", "objects", "sounds", "models", "rooms"]:
            # Get resources from runtime
            runtime_resources = self.app.project_manager.get_runtime_resources(ref_type)
            resources = list(runtime_resources.values())
            
            for resource in resources:
                # Skip the resource itself
                if (ref_type == resource_type and 
                    resource.get("id") == resource_id):
                    continue
                
                # Get resource file path
                resource_folder_map = {
                    "sprites": "Sprites",
                    "backgrounds": "Backgrounds",
                    "textures": "Textures",
                    "objects": "Objects",
                    "sounds": "Sounds",
                    "models": "Models",
                    "rooms": "Rooms"
                }
                
                resource_folder = resource_folder_map.get(ref_type, "Sprites")
                parent_folder = resource.get("parent_folder", "")
                
                file_path = os.path.join(project_path, "Resources", resource_folder)
                if parent_folder:
                    file_path = os.path.join(file_path, parent_folder)
                
                resource_name_file = resource.get("name", "")
                if resource_name_file:
                    file_extension = {
                        "sprites": ".sprite",
                        "backgrounds": ".background",
                        "textures": ".texture",
                        "objects": ".object", 
                        "sounds": ".sound",
                        "rooms": ".room",
                        "models": ".model"
                    }.get(ref_type, ".sprite")
                    
                    file_path = os.path.join(file_path, f"{resource_name_file}{file_extension}")
                
                if not file_path or not os.path.exists(file_path):
                    continue
                
                try:
                    with open(file_path, 'r', encoding='utf-8') as f:
                        content = f.read()
                        # Check if resource_id or resource_name appears in the file
                        if resource_id in content or resource_name in content:
                            # More precise check - look for actual references
                            if self._check_resource_reference(content, resource_id, resource_name, resource_type):
                                references.append({
                                    "type": ref_type,
                                    "name": resource.get("name", "Unknown"),
                                    "id": resource.get("id", "")
                                })
                except:
                    continue
        
        return references
    
    def _check_resource_reference(self, content, resource_id, resource_name, resource_type):
        """Check if content actually references the resource (not just contains the name)"""
        import json
        import re
        
        # Try to parse as JSON first
        try:
            data = json.loads(content)
            # Check common reference fields
            if resource_type == "sprites":
                # Check sprite references in objects, rooms, etc.
                if isinstance(data, dict):
                    if data.get("sprite") == resource_id:
                        return True
                    # Check in instances (rooms)
                    for instance in data.get("instances", []):
                        if instance.get("object") and resource_id in str(instance.get("object")):
                            return True
            elif resource_type == "sounds":
                # Check sound references
                if isinstance(data, dict):
                    if data.get("sound") == resource_id or resource_id in str(data.get("sounds", [])):
                        return True
            elif resource_type == "backgrounds":
                # Check background references in rooms
                if isinstance(data, dict):
                    for bg in data.get("backgrounds", []):
                        if bg.get("background") == resource_id:
                            return True
        except:
            pass
        
        # Fallback: check if resource_id appears in a structured way
        patterns = [
            rf'["\']?{re.escape(resource_id)}["\']?',
            rf'["\']?{re.escape(resource_name)}["\']?'
        ]
        
        for pattern in patterns:
            if re.search(pattern, content):
                return True
        
        return False
    
    def mousePressEvent(self, event):
        """Handle mouse clicks on waveform"""
        if event.button() == Qt.LeftButton and self.rect().contains(event.pos()):
            # Calculate click position
            click_x = event.pos().x()
            width = self.width()
            self.click_position = click_x / width
            
            # Set playback position
            if self.duration > 0:
                new_position = self.click_position * self.duration
                self.seek_to_position(new_position)
    
    def seek_to_position(self, position):
        """Seek to a specific position in the audio"""
        if self.duration <= 0:
            return
        
        # Clamp position to valid range
        position = max(0, min(position, self.duration))
        self.current_position = position
        
        # Update display immediately
        self.update_display()
        
        # If currently playing, restart playback from new position using simplified method
        if self.is_playing and not self.is_paused:
            self.start_playback(reset_position=False)  # Simplified: handles seeking via AudioSegment slicing
    
    def restart_playback_from_position(self, position):
        """Legacy method - replaced by simplified start_playback with AudioSegment slicing"""
        self.seek_to_position(position)
    
    def _old_restart_playback_from_position(self, position):
        """Restart playback from a specific position"""
        # For seeking, we need to use pydub to create a segment
        if not hasattr(self, 'audio_file_path') or not self.audio_file_path:
            return
        
        # If we don't have audio_data loaded, we need to reload it for seeking
        if not self.audio_data or not PYDUB_AVAILABLE:
            # Try to reload audio data if we have a file path
            if hasattr(self, 'audio_file_path') and self.audio_file_path and PYDUB_AVAILABLE:
                try:
                    from pydub import AudioSegment
                    self.audio_data = AudioSegment.from_file(self.audio_file_path)
                except Exception as e:
                    print(f"Error reloading audio for seeking: {e}")
                    # Fallback: just start from beginning
                    if PYGAME_AVAILABLE:
                        pygame.mixer.music.stop()
                    self.is_playing = False
                    self.is_paused = False
                    self.stop_playback = True
                    self.play_btn.setText("▶")
                    self.current_position = 0.0
                    self.start_playback(reset_position=False)
                    return
            else:
                # Can't seek without audio data
                if PYGAME_AVAILABLE:
                    pygame.mixer.music.stop()
                self.is_playing = False
                self.is_paused = False
                self.stop_playback = True
                self.play_btn.setText("▶")
                self.current_position = 0.0
                self.start_playback(reset_position=False)
                return
        
        try:
            # Stop current playback
            if PYGAME_AVAILABLE:
                pygame.mixer.music.stop()
            
            # Clean up previous temp file
            if hasattr(self, 'current_temp_file') and self.current_temp_file:
                try:
                    if os.path.exists(self.current_temp_file):
                        os.remove(self.current_temp_file)
                except Exception as e:
                    print(f"Warning: Could not remove previous temp file: {e}")
            
            # Create unique temporary filename
            import uuid
            temp_filename = os.path.join(tempfile.gettempdir(), f"temp_playback_{uuid.uuid4().hex[:8]}.wav")
            
            # Create a segment from the new position
            start_time_ms = int(position * 1000)
            audio_segment = self.audio_data[start_time_ms:]
            
            # Export and play the segment
            audio_segment.export(temp_filename, format="wav")
            if PYGAME_AVAILABLE:
                import time
                pygame.mixer.music.load(temp_filename)
                
                # Apply calculated effective volume (includes track mute/volume states)
                effective_volume = self.calculate_effective_volume()
                pygame.mixer.music.set_volume(effective_volume)
                
                pygame.mixer.music.play()
                
                self.is_playing = True
                self.is_paused = False
                
                # Track segment start position and playback start time
                self.segment_start_position = position
                self.current_position = position
                self.playback_start_time = time.time()
            
            # Store temp filename for cleanup
            self.current_temp_file = temp_filename
            
        except Exception as e:
            print(f"Error restarting playback from position: {e}")
    
    def restart_midi_playback_from_position(self, position):
        """Restart MIDI playback from a specific position (simulated seeking)"""
        import time
        
        try:
            # Stop current playback
            if PYGAME_AVAILABLE:
                pygame.mixer.music.stop()
            
            # Clean up previous temp file if exists
            if hasattr(self, 'current_temp_file') and self.current_temp_file:
                try:
                    if os.path.exists(self.current_temp_file) and self.current_temp_file != self.audio_file_path:
                        os.remove(self.current_temp_file)
                except Exception:
                    pass
                self.current_temp_file = None
            
            # For MIDI files, create filtered file to only play unmuted tracks
            playback_file = self.audio_file_path
            if self.midi_file:
                filtered_file = self._create_filtered_midi_file()
                if filtered_file:
                    playback_file = filtered_file
                    # Store temp file path for cleanup
                    if filtered_file != self.audio_file_path:
                        self.current_temp_file = filtered_file
            
            # For MIDI files, we can't actually seek, but we can simulate it
            # by restarting playback and adjusting the timer
            if PYGAME_AVAILABLE:
                pygame.mixer.music.load(playback_file)
                
                # Apply effective volume (not just base volume)
                effective_volume = self.calculate_effective_volume()
                pygame.mixer.music.set_volume(effective_volume)
                
                pygame.mixer.music.play()
                
                self.is_playing = True
                self.is_paused = False
                self.stop_playback = False
                self.play_btn.setText("⏸")
                
                # Set up a timer to "fast-forward" to the target position
                # This is a simulation - the audio actually starts from beginning
                # but we'll adjust the display to show the seek position
                self.midi_seek_offset = position
                self.midi_seek_start_time = time.time()
                
        except Exception as e:
            print(f"Error restarting MIDI playback from position: {e}")
    
    def toggle_playback(self):
        """Simplified: Toggle play/pause"""
        
        # Check if we have audio loaded
        if self.audio_segment is None:
            return
        
        if self.is_playing:
            if self.is_paused:
                self.resume_playback()
            else:
                self.pause_playback()
        else:
            self.start_playback()
    
    def calculate_effective_volume(self):
        """Calculate effective volume from all track states"""
        # Get base volume from resource settings
        base_volume = self.editor.resource_data.get("volume", 1.0)
        
        # Check if any tracks are active (not muted and volume > 0)
        has_active_tracks = False
        total_track_volume = 0.0
        active_track_count = 0
        
        if hasattr(self, 'track_list_view') and self.track_list_view:
            for track_widget in self.track_list_view.tracks:
                if not track_widget.is_muted and track_widget.overall_volume > 0:
                    has_active_tracks = True
                    active_track_count += 1
                    # Calculate effective track volume (average of L/R effective volumes)
                    left_vol = track_widget.get_effective_volume_left()
                    right_vol = track_widget.get_effective_volume_right()
                    track_vol = (left_vol + right_vol) / 2.0
                    total_track_volume += track_vol
        
        # If no active tracks, return 0 (muted)
        if not has_active_tracks:
            return 0.0
        
        # Average track volumes (to prevent clipping with many tracks)
        avg_track_volume = total_track_volume / active_track_count if active_track_count > 0 else 0.0
        
        # Combine base volume with average track volume
        effective_volume = base_volume * avg_track_volume
        return max(0.0, min(1.0, effective_volume))  # Clamp to 0-1
    
    def start_playback(self, reset_position=None):
        """Simplified: Start playback using pygame.mixer.Channel with real-time control"""
        if self.audio_segment is None or not PYGAME_AVAILABLE:
            return
        
        # Check if any tracks are active
        if not any(not track.get("muted", False) and track.get("volume", 0) > 0 for track in self.tracks):
            self.stop_audio_playback()
            return
        
        # Determine start position
        if reset_position is None:
            should_reset = (self.current_position == 0.0)
        else:
            should_reset = reset_position
        
        start_pos = 0.0 if should_reset else self.current_position
        
        # Use AudioSegment slicing for seeking - no temp files needed
        if start_pos > 0:
            playback_segment = self.audio_segment[int(start_pos * 1000):]  # Convert seconds to ms
        else:
            playback_segment = self.audio_segment
        
        if len(playback_segment) == 0:
            return
        
        try:
            # Stop any existing playback
            self.stop_audio_playback()
            
            # Export segment to bytes for pygame.Sound
            import io
            wav_bytes = io.BytesIO()
            playback_segment.export(wav_bytes, format="wav")
            wav_bytes.seek(0)
            
            # Create pygame.Sound and play on a single channel
            # Volume control adjusts the channel volume in real-time
            sound = pygame.mixer.Sound(wav_bytes)
            
            # Use one channel for playback (volume controlled in real-time)
            channel = pygame.mixer.Channel(0)
            channel.play(sound)
            
            # Calculate and set initial volume
            effective_vol = self.calculate_effective_volume()
            channel.set_volume(effective_vol)
            
            self.playback_channels = [channel]  # Store for pause/stop control
            
            self.is_playing = True
            self.is_paused = False
            # Store the segment start position and playback start time
            # Position will be calculated as: segment_start + elapsed_time
            self.segment_start_pos = start_pos
            self.playback_start_time = time.time()
            self.current_position = start_pos
            self.play_btn.setText("⏸")
            
        except Exception as e:
            print(f"ERROR: Playback failed: {e}")
            import traceback
            traceback.print_exc()
    
    def pause_playback(self):
        """Simplified: Pause playback using channel"""
        import time
        if PYGAME_AVAILABLE and self.playback_channels:
            for channel in self.playback_channels:
                channel.pause()
        self.is_paused = True
        self.pause_start_time = time.time()
        self.play_btn.setText("▶")
    
    def resume_playback(self):
        """Simplified: Resume playback using channel"""
        import time
        if PYGAME_AVAILABLE and self.playback_channels:
            for channel in self.playback_channels:
                channel.unpause()
            # Update volume in case it changed while paused
            effective_volume = self.calculate_effective_volume()
            for channel in self.playback_channels:
                channel.set_volume(effective_volume)
        
        # Adjust playback_start_time to account for pause duration
        if self.pause_start_time is not None and self.playback_start_time is not None:
            pause_duration = time.time() - self.pause_start_time
            self.playback_start_time += pause_duration  # Extend start time by pause duration
        self.pause_start_time = None
        
        self.is_paused = False
        self.play_btn.setText("⏸")
    
    def stop_audio_playback(self):
        """Simplified: Stop playback using channel"""
        if PYGAME_AVAILABLE:
            if self.playback_channels:
                for channel in self.playback_channels:
                    try:
                        channel.stop()
                    except Exception:
                        pass
            try:
                pygame.mixer.music.stop()
            except Exception:
                pass
            try:
                pygame.mixer.stop()
            except Exception:
                pass
        self.playback_channels = []
        self.is_playing = False
        self.is_paused = False
        self.current_position = 0.0
        self.playback_start_time = None
        self.segment_start_pos = 0.0
        self.pause_start_time = None
        self.play_btn.setText("▶")
        self.update_display()
    
    def start_midi_playback(self):
        """Start MIDI playback by converting to audio on-the-fly"""
        
        if not self.midi_file or not MIDO_AVAILABLE:
            return
        
        try:
            
            # Convert MIDI to audio for playback
            temp_audio_path = self._convert_midi_to_audio_for_playback()
            
            if temp_audio_path and os.path.exists(temp_audio_path):
                # Load the converted audio into pygame for playback
                if PYGAME_AVAILABLE:
                    pygame.mixer.music.load(temp_audio_path)
                    pygame.mixer.music.play()
                    
                    self.is_playing = True
                    self.is_paused = False
                    self.play_btn.setText("⏸")
                    
                else:
                    pass
            else:
                pass
                
        except Exception as e:
            print(f"ERROR: MIDI playback failed: {e}")
            import traceback
            traceback.print_exc()
    
    def _get_active_track_indices(self):
        """Get list of track indices that are active (not muted and volume > 0)"""
        active_indices = []
        
        if hasattr(self, 'track_list_view') and self.track_list_view:
            for track_widget in self.track_list_view.tracks:
                if not track_widget.is_muted and track_widget.overall_volume > 0:
                    active_indices.append(track_widget.track_index)
        
        return active_indices
    
    def _create_filtered_midi_file(self):
        """Create a filtered MIDI file with only active (unmuted) tracks"""
        try:
            if not self.midi_file or not MIDO_AVAILABLE:
                return None
            
            # Get active track indices
            active_indices = self._get_active_track_indices()
            
            # If all tracks are active, use original file
            total_tracks = len([t for t in self.track_list_view.tracks if hasattr(t, 'track_index')])
            if len(active_indices) == total_tracks:
                return self.audio_file_path
            
            # If no tracks are active, return None
            if len(active_indices) == 0:
                return None
            
            # Create a new MIDI file with only active tracks
            filtered_midi = mido.MidiFile(ticks_per_beat=self.midi_file.ticks_per_beat)
            
            # Always include first track (often contains tempo/time signature metadata)
            # but filter out note messages if Track 0 is muted
            for i, track in enumerate(self.midi_file.tracks):
                new_track = mido.MidiTrack()
                
                # Track 0: Always include, but filter note messages if muted
                if i == 0:
                    track_widget = None
                    if hasattr(self, 'track_list_view') and self.track_list_view:
                        for tw in self.track_list_view.tracks:
                            if tw.track_index == 0:
                                track_widget = tw
                                break
                    
                    # If Track 0 is muted, only include non-note messages (meta messages)
                    if track_widget and track_widget.is_muted:
                        for msg in track:
                            if msg.type not in ('note_on', 'note_off'):
                                new_track.append(msg)
                    else:
                        # Include all messages from Track 0 if not muted
                        for msg in track:
                            new_track.append(msg)
                    filtered_midi.tracks.append(new_track)
                elif i in active_indices:
                    # Include the entire track if it's active
                    for msg in track:
                        new_track.append(msg)
                    filtered_midi.tracks.append(new_track)
                # Skip muted tracks (except track 0 which we handled above)
            
            # Save filtered MIDI to temporary file
            temp_midi_path = os.path.join(tempfile.gettempdir(), f"midi_filtered_{uuid.uuid4().hex[:8]}.mid")
            filtered_midi.save(temp_midi_path)
            
            return temp_midi_path
            
        except Exception as e:
            print(f"ERROR: Creating filtered MIDI file failed: {e}")
            import traceback
            traceback.print_exc()
            return None
    
    def _convert_midi_to_audio_for_playback(self):
        """Convert MIDI to audio for playback (only processes active tracks)"""
        try:
            if not self.midi_file:
                return None
            
            # Get active track indices
            active_indices = self._get_active_track_indices()
            
            if len(active_indices) == 0:
                return None  # No active tracks
            
            # Create a simple audio synthesis for playback
            sample_rate = 44100
            duration_seconds = self.midi_file.length
            
            # Generate audio data
            t = np.linspace(0, duration_seconds, int(sample_rate * duration_seconds), False)
            audio_data = np.zeros_like(t)
            
            # Parse MIDI events to extract notes (only from active tracks)
            active_notes = {}
            
            for i, track in enumerate(self.midi_file.tracks):
                # Only process active tracks (or first track which may contain meta messages)
                if i not in active_indices and i != 0:
                    continue
                
                track_time = 0
                for msg in track:
                    # Skip note messages from muted tracks (but keep meta messages)
                    if i != 0 and i not in active_indices and msg.type in ('note_on', 'note_off'):
                        continue
                    
                    track_time += msg.time
                    
                    if msg.type == 'note_on' and msg.velocity > 0:
                        # Note on
                        note_freq = 440 * (2 ** ((msg.note - 69) / 12))  # Convert MIDI note to frequency
                        active_notes[msg.note] = {
                            'frequency': note_freq,
                            'start_time': track_time,
                            'velocity': msg.velocity
                        }
                    elif msg.type == 'note_off' or (msg.type == 'note_on' and msg.velocity == 0):
                        # Note off
                        if msg.note in active_notes:
                            note_info = active_notes[msg.note]
                            note_duration = track_time - note_info['start_time']
                            
                            # Generate sine wave for this note
                            note_start_idx = int(note_info['start_time'] * sample_rate)
                            note_end_idx = int((note_info['start_time'] + note_duration) * sample_rate)
                            
                            if note_start_idx < len(t) and note_end_idx <= len(t):
                                note_t = t[note_start_idx:note_end_idx] - note_info['start_time']
                                note_audio = np.sin(2 * np.pi * note_info['frequency'] * note_t)
                                
                                # Apply velocity (volume) and envelope
                                velocity_factor = note_info['velocity'] / 127.0
                                envelope = np.exp(-note_t * 2)  # Simple decay envelope
                                note_audio *= velocity_factor * envelope
                                
                                audio_data[note_start_idx:note_end_idx] += note_audio
                            
                            del active_notes[msg.note]
            
            # Normalize audio
            if np.max(np.abs(audio_data)) > 0:
                audio_data = audio_data / np.max(np.abs(audio_data)) * 0.7
            
            # Convert to 16-bit PCM
            audio_data_16bit = (audio_data * 32767).astype(np.int16)
            
            # Create temporary WAV file
            temp_wav_path = os.path.join(tempfile.gettempdir(), f"midi_playback_{uuid.uuid4().hex[:8]}.wav")
            
            # Save as WAV file
            import wave
            with wave.open(temp_wav_path, 'w') as wav_file:
                wav_file.setnchannels(1)  # Mono
                wav_file.setsampwidth(2)  # 16-bit
                wav_file.setframerate(sample_rate)
                wav_file.writeframes(audio_data_16bit.tobytes())
            
            return temp_wav_path
            
        except Exception as e:
            print(f"ERROR: MIDI to audio conversion failed: {e}")
            return None
    
    def on_loop_toggled(self, checked):
        """Handle loop checkbox toggle"""
        self.loop_enabled = checked
        if PYGAME_AVAILABLE:
            pygame.mixer.music.set_endevent(pygame.USEREVENT if checked else 0)
    
    def update_playback_position(self):
        """Simplified: Update position using simple time.time() - start_time"""
        import time
        
        if self.is_playing and not self.is_paused and PYGAME_AVAILABLE:
            # Check if channel is still playing
            is_busy = any(channel.get_busy() for channel in self.playback_channels if channel)
            
            if is_busy and self.playback_start_time is not None:
                # Simple: segment_start + elapsed time
                elapsed_time = time.time() - self.playback_start_time
                segment_start = getattr(self, 'segment_start_pos', 0.0)
                self.current_position = segment_start + elapsed_time
                
                # Don't exceed duration
                if self.current_position >= self.duration:
                    self.current_position = self.duration
                    # Playback finished
                    if self.loop_enabled:
                        self.current_position = 0.0
                        self.start_playback()
                    else:
                        self.stop_audio_playback()
            elif not is_busy:
                # Channel finished playing
                if self.loop_enabled:
                    self.current_position = 0.0
                    self.start_playback()
                else:
                    self.stop_audio_playback()
        
        self.update_display()
    
    def on_progress_changed(self, value):
        """Handle progress bar changes (visual only during dragging)"""
        if self.updating_progress_bar:
            return  # Don't process programmatic updates
        
        if self.duration > 0:
            new_position = (value / 1000.0) * self.duration
            # Only update visual position, don't seek yet
            self.current_position = new_position
            self.update_display()
    
    def on_progress_released(self):
        """Handle progress bar release (actual seeking)"""
        if self.duration > 0:
            value = self.progress_bar.value()
            new_position = (value / 1000.0) * self.duration
            self.seek_to_position(new_position)
    
    def update_progress_bar(self):
        """Update progress bar position"""
        if self.duration > 0:
            progress = int((self.current_position / self.duration) * 1000)
            self.updating_progress_bar = True
            self.progress_bar.setValue(progress)
            self.updating_progress_bar = False
    
    def cleanup_temp_files(self):
        """Clean up all temporary files"""
        import glob
        try:
            # Clean up temp files in system temp directory
            temp_files = glob.glob(os.path.join(tempfile.gettempdir(), "temp_playback_*.wav"))
            for temp_file in temp_files:
                try:
                    os.remove(temp_file)
                except Exception as e:
                    print(f"Warning: Could not remove temp file {temp_file}: {e}")
            
            # Also clean up any temp files that might be in the project directory (legacy cleanup)
            project_temp_files = glob.glob("temp_playback_*.wav")
            for temp_file in project_temp_files:
                try:
                    os.remove(temp_file)
                except Exception as e:
                    print(f"Warning: Could not remove legacy temp file {temp_file}: {e}")
                    
        except Exception as e:
            print(f"Warning: Error during temp file cleanup: {e}")
    
    def format_time(self, seconds):
        """Format seconds as MM:SS"""
        minutes = int(seconds // 60)
        seconds = int(seconds % 60)
        return f"{minutes:02d}:{seconds:02d}"
    
    def clear_audio(self):
        """Clear loaded audio data"""
        self.stop_audio_playback()
        self.audio_data = None
        self.waveform_data = None
        self.current_position = 0.0
        self.duration = 0.0
        self.click_position = None
        self.update_display()

class SoundEditor(QWidget, EditorInterface):
    """Main Sound Editor - PGSE "Pigsey" - PyGenesis Sound Editor"""
    
    def __init__(self, app, resource_data):
        super().__init__()
        self.app = app
        self.resource_data = resource_data or {}
        self._dirty = False  # Track unsaved changes
        self.audio_file_path = None
        
        # Ensure playback stops if the widget is destroyed without closeEvent firing
        self.destroyed.connect(self._handle_destroyed)
        
        self.setup_ui()
        if resource_data:
            self.open_resource(resource_data)
        self.update_references_display()
        self.apply_theme()
    
    def closeEvent(self, event):
        """Handle editor close event - stop playback and cleanup"""
        self.stop_audio_playback()
        self.cleanup_temp_files()
        if hasattr(self, 'preview_canvas'):
            self.preview_canvas.cleanup_on_close()
        super().closeEvent(event)
    
    def _handle_destroyed(self, *args):
        """Ensure audio playback stops when the tab/widget is destroyed."""
        try:
            self.stop_audio_playback()
        except Exception:
            pass
    
    def setup_ui(self):
        """Setup the main UI"""
        layout = QHBoxLayout(self)
        layout.setContentsMargins(5, 5, 5, 5)
        
        # Create splitter for resizable panels
        splitter = QSplitter(Qt.Horizontal)
        layout.addWidget(splitter)
        
        # Left panel - Properties
        left_panel = self.create_properties_panel()
        splitter.addWidget(left_panel)
        
        # Right panel - Preview
        right_panel = self.create_preview_panel()
        splitter.addWidget(right_panel)
        
        # Set splitter proportions (40% left, 60% right)
        splitter.setSizes([400, 600])
    
    def create_properties_panel(self):
        """Create the properties panel"""
        panel = QFrame()
        panel.setFrameStyle(QFrame.StyledPanel)
        panel.setMaximumWidth(400)
        
        layout = QVBoxLayout(panel)
        layout.setContentsMargins(10, 10, 10, 10)
        
        # Title
        title_label = QLabel("Sound Properties")
        title_label.setStyleSheet("font-size: 14px; font-weight: bold; margin-bottom: 10px;")
        layout.addWidget(title_label)
        
        # Basic Info Group
        info_group = QGroupBox("Basic Information")
        info_layout = QGridLayout(info_group)
        
        # Name
        info_layout.addWidget(QLabel("Name:"), 0, 0)
        self.name_edit = QLineEdit()
        self.name_edit.textChanged.connect(self.on_name_changed)
        info_layout.addWidget(self.name_edit, 0, 1)
        
        # File path (read-only)
        info_layout.addWidget(QLabel("File:"), 1, 0)
        self.file_label = QLabel("No file loaded")
        self.file_label.setWordWrap(True)
        self.file_label.setStyleSheet("color: #888;")
        info_layout.addWidget(self.file_label, 1, 1)
        
        # Load file button
        self.load_file_btn = QPushButton("Load Audio File")
        self.load_file_btn.clicked.connect(self.load_audio_file)
        info_layout.addWidget(self.load_file_btn, 2, 0, 1, 2)
        
        layout.addWidget(info_group)
        
        # Audio Properties Group
        props_group = QGroupBox("Audio Properties")
        props_layout = QGridLayout(props_group)
        
        # Duration (read-only)
        props_layout.addWidget(QLabel("Duration:"), 0, 0)
        self.duration_label = QLabel("00:00")
        props_layout.addWidget(self.duration_label, 0, 1)
        
        # Sample Rate (read-only)
        props_layout.addWidget(QLabel("Sample Rate:"), 1, 0)
        self.sample_rate_label = QLabel("N/A")
        props_layout.addWidget(self.sample_rate_label, 1, 1)
        
        # Bit Depth (read-only)
        props_layout.addWidget(QLabel("Bit Depth:"), 2, 0)
        self.bit_depth_label = QLabel("N/A")
        props_layout.addWidget(self.bit_depth_label, 2, 1)
        
        # Channels (read-only)
        props_layout.addWidget(QLabel("Channels:"), 3, 0)
        self.channels_label = QLabel("N/A")
        props_layout.addWidget(self.channels_label, 3, 1)
        
        layout.addWidget(props_group)
        
        # Sound Settings Group
        settings_group = QGroupBox("Sound Settings")
        settings_layout = QGridLayout(settings_group)
        
        # Volume
        settings_layout.addWidget(QLabel("Volume:"), 0, 0)
        self.volume_slider = QSlider(Qt.Horizontal)
        self.volume_slider.setRange(0, 100)
        self.volume_slider.setValue(100)
        self.volume_slider.valueChanged.connect(self.on_volume_changed)
        settings_layout.addWidget(self.volume_slider, 0, 1)
        
        # Loop
        self.loop_checkbox = QCheckBox("Loop")
        self.loop_checkbox.toggled.connect(self.on_loop_changed)
        settings_layout.addWidget(self.loop_checkbox, 1, 0, 1, 2)
        
        # Preload
        self.preload_checkbox = QCheckBox("Preload")
        self.preload_checkbox.setChecked(True)
        self.preload_checkbox.toggled.connect(self.on_preload_changed)
        settings_layout.addWidget(self.preload_checkbox, 2, 0, 1, 2)
        
        layout.addWidget(settings_group)
        
        # References Group (Used by)
        refs_group = QGroupBox("References")
        refs_layout = QVBoxLayout(refs_group)
        
        self.used_by_label = QLabel("Used by: None")
        self.used_by_label.setWordWrap(True)
        self.used_by_label.setStyleSheet("color: #888; font-size: 11px;")
        refs_layout.addWidget(self.used_by_label)
        
        # Find References button
        find_refs_btn = QPushButton("Find References...")
        find_refs_btn.clicked.connect(self.find_references)
        refs_layout.addWidget(find_refs_btn)
        
        layout.addWidget(refs_group)
        
        # Store reference to app for finding references
        self._resource_id = None
        self._resource_name = None
        
        # Frequency Settings Group
        freq_group = QGroupBox("Frequency Settings")
        freq_layout = QGridLayout(freq_group)
        
        # Frequency dropdown
        freq_layout.addWidget(QLabel("Frequency:"), 0, 0)
        self.frequency_combo = QComboBox()
        self.frequency_combo.addItems([
            "22050 Hz (Low Quality)",
            "44100 Hz (CD Quality)",
            "48000 Hz (Professional)",
            "96000 Hz (High Quality)"
        ])
        self.frequency_combo.setCurrentText("44100 Hz (CD Quality)")
        self.frequency_combo.currentTextChanged.connect(self.on_frequency_changed)
        freq_layout.addWidget(self.frequency_combo, 0, 1)
        
        layout.addWidget(freq_group)
        
        # Editor Buttons Group
        editor_group = QGroupBox("Sound Editors")
        editor_layout = QVBoxLayout(editor_group)
        
        # Sound File Editor button
        self.file_editor_btn = QPushButton("Edit Sound in WaveForge")
        self.file_editor_btn.clicked.connect(self.open_sound_file_editor)
        self.file_editor_btn.setToolTip("Open advanced audio editing (Audacity-style)")
        editor_layout.addWidget(self.file_editor_btn)
        
        # Sound Creator button
        self.creator_btn = QPushButton("Edit Sound in MelodyMaker")
        self.creator_btn.clicked.connect(self.open_sound_creator)
        self.creator_btn.setToolTip("Open music composition studio (GarageBand-style)")
        editor_layout.addWidget(self.creator_btn)
        
        layout.addWidget(editor_group)
        
        layout.addStretch()
        return panel
    
    def create_preview_panel(self):
        """Create the preview panel"""
        panel = QFrame()
        panel.setFrameStyle(QFrame.StyledPanel)
        
        layout = QVBoxLayout(panel)
        layout.setContentsMargins(10, 10, 10, 10)
        
        # Title
        title_label = QLabel("Sound Preview")
        title_label.setStyleSheet("font-size: 14px; font-weight: bold; margin-bottom: 10px;")
        layout.addWidget(title_label)
        
        # Preview canvas
        self.preview_canvas = SoundPreviewCanvas(self)
        layout.addWidget(self.preview_canvas)
        
        return panel
    
    def open_resource(self, resource_data: Dict) -> bool:
        """Load resource data into the editor (EditorInterface implementation)"""
        try:
            self.resource_data = resource_data
            self._dirty = False
            self.load_resource_data()
            return True
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to load resource: {str(e)}")
            return False
    
    def load_resource_data(self):
        """Load resource data into the editor (legacy method)"""
        if not self.resource_data:
            return
        
        
        # Load the complete resource data from the .sound file on disk
        # This ensures we get the audio_file field that's not in the runtime data
        try:
            resource_id = self.resource_data.get("id")
            if resource_id:
                complete_resource_data = self.app.resource_manager.load_resource_from_disk("sounds", resource_id)
                if complete_resource_data:
                    self.resource_data = complete_resource_data
                else:
                    pass
        except Exception as e:
            pass
        
        # Load basic properties
        resource_name = self.resource_data.get("name", "")
        self.name_edit.setText(resource_name)
        
        # Store resource info for reference finding
        self._resource_id = self.resource_data.get("id")
        self._resource_name = resource_name
        
        # Load sound settings
        self.volume_slider.setValue(int(self.resource_data.get("volume", 1.0) * 100))
        self.loop_checkbox.setChecked(self.resource_data.get("loop", False))
        self.preload_checkbox.setChecked(self.resource_data.get("preload", True))
        
        # Load frequency setting
        frequency = self.resource_data.get("frequency", 44100)
        freq_text = f"{frequency} Hz"
        if frequency == 22050:
            freq_text += " (Low Quality)"
        elif frequency == 44100:
            freq_text += " (CD Quality)"
        elif frequency == 48000:
            freq_text += " (Professional)"
        elif frequency == 96000:
            freq_text += " (High Quality)"
        
        # Find matching combo item
        for i in range(self.frequency_combo.count()):
            if freq_text in self.frequency_combo.itemText(i):
                self.frequency_combo.setCurrentIndex(i)
                break
        
        # Load audio file if specified
        audio_file = self.resource_data.get("audio_file")
        if audio_file:
            # Construct the full path to the copied audio file
            sounds_folder = os.path.join(self.app.project_manager.get_project_path(), "Resources", "Sounds")
            audio_file_path = os.path.join(sounds_folder, audio_file)
            self.load_audio_file_from_path(audio_file_path)
        else:
            pass
    
    def load_audio_file(self):
        """Open file dialog to load audio file (WAV, MP3)"""
        file_path, _ = QFileDialog.getOpenFileName(
            self,
            "Load Audio File",
            "",
            "Audio Files (*.wav *.mp3);;All Files (*)"
        )
        
        if file_path:
            self.load_audio_file_from_path(file_path)
    
    def load_audio_file_from_path(self, file_path):
        """Load audio file from specified path (supports WAV, MP3)"""
        if not os.path.exists(file_path):
            QMessageBox.warning(self, "File Not Found", f"Audio file not found: {file_path}")
            return
        
        # Check pydub dependency
        if not PYDUB_AVAILABLE:
            QMessageBox.warning(self, "Dependency Missing", "pydub library is required to load audio files.\nPlease install it with: pip install pydub")
            return
        
        # Check if the file is already in the project's sounds folder
        sounds_folder = os.path.join(self.app.project_manager.get_project_path(), "Resources", "Sounds")
        is_in_project_folder = file_path.startswith(sounds_folder)
        
        
        if not is_in_project_folder:
            # Copy the audio file to the project's sounds folder
            if hasattr(self.app, 'resource_manager'):
                success = self.app.resource_manager._copy_sound_audio_file(self.resource_data, file_path)
                if not success:
                    QMessageBox.warning(self, "Copy Error", "Failed to copy audio file to project folder")
                    return
            else:
                pass
            
            # Use the copied file - prefer original_audio_file if available (full path)
            original_audio_file = self.resource_data.get("original_audio_file")
            if original_audio_file and os.path.exists(original_audio_file):
                # Use the full path from original_audio_file (normalized)
                audio_file_path = os.path.normpath(original_audio_file)
            else:
                # Fall back to constructing path from filename
                copied_filename = self.resource_data.get("audio_file")
                if copied_filename:
                    audio_file_path = os.path.normpath(os.path.join(sounds_folder, copied_filename))
                else:
                    QMessageBox.warning(self, "Copy Error", "Failed to get copied file path")
                    return
        else:
            # File is already in project folder, use it directly (normalize path)
            audio_file_path = os.path.normpath(file_path)
            # Update resource data with just the filename
            self.resource_data["audio_file"] = os.path.basename(file_path)
        
        # Verify file exists before loading
        if not os.path.exists(audio_file_path):
            QMessageBox.warning(self, "File Not Found", f"Audio file not found: {audio_file_path}")
            return
        
        # Load into preview canvas
        load_result = self.preview_canvas.load_audio_file(audio_file_path)
        if load_result:
            self.audio_file_path = audio_file_path
            self.file_label.setText(os.path.basename(audio_file_path))
            
            # Update audio properties
            try:
                audio = AudioSegment.from_file(audio_file_path)
            except Exception as e:
                # Fall back to wave module for simple WAV metadata (no ffmpeg required)
                audio = None
                if audio_file_path.lower().endswith(".wav"):
                    try:
                        metadata = self._read_wav_metadata(audio_file_path)
                        audio_len = metadata["duration"]
                        self.duration_label.setText(self.format_duration(audio_len))
                        self.sample_rate_label.setText(f"{metadata['sample_rate']} Hz")
                        self.bit_depth_label.setText(f"{metadata['bit_depth']} bit")
                        self.channels_label.setText(
                            f"{metadata['channels']} channel{'s' if metadata['channels'] > 1 else ''}"
                        )
                        
                        self.resource_data["duration"] = audio_len
                        self.resource_data["sample_rate"] = metadata["sample_rate"]
                        self.resource_data["bit_depth"] = metadata["bit_depth"]
                        self.resource_data["channels"] = metadata["channels"]
                    except Exception as wav_err:
                        print(f"Error reading audio properties via wave: {wav_err}")
                else:
                    print(f"Error reading audio properties: {e}")
            
            if audio is not None:
                audio_len = len(audio) / 1000.0
                self.duration_label.setText(self.format_duration(audio_len))
                self.sample_rate_label.setText(f"{audio.frame_rate} Hz")
                self.bit_depth_label.setText(f"{audio.sample_width * 8} bit")
                self.channels_label.setText(f"{audio.channels} channel{'s' if audio.channels > 1 else ''}")
                
                self.resource_data["duration"] = audio_len
                self.resource_data["sample_rate"] = audio.frame_rate
                self.resource_data["bit_depth"] = audio.sample_width * 8
                self.resource_data["channels"] = audio.channels
            
            # Update resource data
            # We need to save the .sound file to disk so the purge system knows about it.
            # However, we should not trigger a full project save here.
            try:
                self.app.resource_manager.save_resource_file_only("sounds", self.resource_data)
            except Exception as e:
                import traceback
                traceback.print_exc()
            
            
        else:
            QMessageBox.warning(self, "Load Error", "Failed to load audio file")
    
    def _load_wav_without_ffmpeg(self, file_path):
        """Delegate to preview canvas helper for ffmpeg-free WAV loading."""
        if hasattr(self, "preview_canvas"):
            return self.preview_canvas._load_wav_without_ffmpeg(file_path)
        raise RuntimeError("Preview canvas is not available to load WAV data.")

    def _read_wav_metadata(self, file_path):
        """Read WAV metadata using the standard library (no ffmpeg required)."""
        try:
            with contextlib.closing(wave.open(file_path, "rb")) as wav_file:
                sample_rate = wav_file.getframerate()
                channels = wav_file.getnchannels()
                sample_width = wav_file.getsampwidth()
                frames = wav_file.getnframes()
                duration = frames / float(sample_rate) if sample_rate else 0.0
        except wave.Error:
            if hasattr(self, "preview_canvas"):
                segment = self.preview_canvas._load_wav_without_ffmpeg(file_path)
                if segment is not None:
                    return {
                        "sample_rate": segment.frame_rate,
                        "channels": segment.channels,
                        "bit_depth": segment.sample_width * 8,
                        "duration": len(segment) / 1000.0
                    }
            raise
        
        return {
            "sample_rate": sample_rate,
            "channels": channels,
            "bit_depth": sample_width * 8,
            "duration": duration
        }
    
    def save_resource(self) -> bool:
        """Save the sound resource (EditorInterface implementation)"""
        try:
            # Update runtime data first
            resource_id = self.resource_data.get("id")
            if resource_id and hasattr(self.app, 'project_manager'):
                self.app.project_manager.update_runtime_resource("sounds", resource_id, self.resource_data)
            
            # Save to disk
            result = False
            if hasattr(self.app, 'resource_manager'):
                result = self.app.resource_manager.save_resource("sounds", self.resource_data)
            
            if result:
                self._dirty = False
            return result
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to save resource: {str(e)}")
            return False
    
    def close_editor(self) -> bool:
        """Cleanup and close the editor (EditorInterface implementation)"""
        self.stop_audio_playback()
        self.cleanup_temp_files()
        if hasattr(self, 'preview_canvas'):
            self.preview_canvas.cleanup_on_close()
        return True
    
    def get_editor_widget(self) -> QWidget:
        """Get the main widget for this editor (EditorInterface implementation)"""
        return self
    
    def is_dirty(self) -> bool:
        """Check if the editor has unsaved changes (EditorInterface implementation)"""
        return self._dirty
    
    def get_resource_type(self) -> str:
        """Get the resource type this editor handles (EditorInterface implementation)"""
        return "sounds"
    
    def get_resource_id(self) -> Optional[str]:
        """Get the ID of the currently loaded resource (EditorInterface implementation)"""
        return self.resource_data.get("id") if self.resource_data else None
    
    def get_resource_name(self) -> Optional[str]:
        """Get the name of the currently loaded resource"""
        return self.resource_data.get("name") if self.resource_data else None
    
    def format_duration(self, seconds):
        """Format duration as MM:SS"""
        minutes = int(seconds // 60)
        seconds = int(seconds % 60)
        return f"{minutes:02d}:{seconds:02d}"
    
    def on_name_changed(self, name):
        """Handle name change"""
        if self.resource_data:
            self.resource_data["name"] = name
            self._dirty = True
    
    def on_volume_changed(self, value):
        """Handle volume change"""
        if self.resource_data:
            volume = value / 100.0
            self.resource_data["volume"] = volume
            
            # Apply volume to currently playing audio
            if PYGAME_AVAILABLE and pygame.mixer.music.get_busy():
                pygame.mixer.music.set_volume(volume)
    
    def on_loop_changed(self, checked):
        """Handle loop change"""
        if self.resource_data:
            self.resource_data["loop"] = checked
        self.preview_canvas.loop_enabled = checked
    
    def on_preload_changed(self, checked):
        """Handle preload change"""
        if self.resource_data:
            self.resource_data["preload"] = checked
    
    def on_frequency_changed(self, text):
        """Handle frequency change"""
        if self.resource_data:
            # Extract frequency from text
            freq_str = text.split()[0]
            try:
                frequency = int(freq_str)
                self.resource_data["frequency"] = frequency
                
                # Reinitialize pygame mixer with new frequency
                if PYGAME_AVAILABLE:
                    pygame.mixer.quit()
                    pygame.mixer.init(frequency=frequency, size=-16, channels=2, buffer=512)
                    
                    # If audio is currently playing, restart it with new settings
                    if hasattr(self.preview_canvas, 'is_playing') and self.preview_canvas.is_playing:
                        self.preview_canvas.stop_audio_playback()
                        self.preview_canvas.start_playback()
                        
            except ValueError:
                pass
    
    def open_sound_file_editor(self):
        """Open WaveForge - the Audacity-style sound file editor"""
        try:
            from Editors.SoundEditor.core.WaveForge import WaveForge
            
            # Create WaveForge window
            waveforge = WaveForge(app=self.app, resource=self.resource_data, parent=self)
            waveforge.setWindowTitle(f"WaveForge - {self.resource_data.get('name', 'Untitled')}")
            
            # Load audio file if available
            if self.audio_file_path:
                # Normalize path
                audio_path = os.path.normpath(self.audio_file_path)
                if os.path.exists(audio_path):
                    waveforge.load_audio_file(audio_path)
                else:
                    # Try to find the file using resource data
                    audio_file = self.resource_data.get("audio_file")
                    if audio_file and self.app and self.app.project_manager:
                        project_path = self.app.project_manager.get_project_path()
                        if project_path:
                            sounds_folder = os.path.join(project_path, "Resources", "Sounds")
                            full_path = os.path.normpath(os.path.join(sounds_folder, audio_file))
                            if os.path.exists(full_path):
                                waveforge.load_audio_file(full_path)
                            else:
                                QMessageBox.warning(
                                    self, "File Not Found",
                                    f"Could not find audio file:\n{full_path}\n\n"
                                    f"Please use File → Open in WaveForge to load the file manually."
                                )
                    else:
                        QMessageBox.warning(
                            self, "File Not Found",
                            f"Audio file not found:\n{audio_path}\n\n"
                            f"Please use File → Open in WaveForge to load the file manually."
                        )
            elif hasattr(self, 'preview_canvas') and self.preview_canvas.audio_segment:
                # If audio is loaded in preview but no file path, we can't easily pass it
                # So we'll show a message
                QMessageBox.information(
                    self, "WaveForge",
                    "Please save the audio file first, or use File → Open in WaveForge to load it."
                )
            else:
                # No audio loaded - WaveForge will open empty, user can load manually
                pass
            
            # Show as separate window
            waveforge.show()
            
        except ImportError as e:
            QMessageBox.critical(
                self, "Error",
                f"Failed to import WaveForge: {str(e)}\n\n"
                f"Make sure WaveForge.py is in Editors/Sound/ directory."
            )
        except Exception as e:
            QMessageBox.critical(
                self, "Error",
                f"Failed to open WaveForge: {str(e)}"
            )
    
    def open_sound_creator(self):
        """Open MelodyMaker - the GarageBand-style sound creator"""
        QMessageBox.information(self, "MelodyMaker", "MelodyMaker (GarageBand-style creator) will open here.\n\nThis will be implemented in the next phase.")
    
    def apply_theme(self):
        """Apply theme styling"""
        # This will be integrated with the existing theme system
        pass
    
    def find_references(self):
        """Find all resources that reference this sound"""
        from PySide6.QtWidgets import QMessageBox
        
        if not getattr(self, "_resource_id", None) or not self.app:
            QMessageBox.information(self, "No Resource", "No resource loaded")
            return
        
        references = self._find_resource_references("sounds", self._resource_id, self._resource_name)
        
        if references:
            ref_text = f"'{self._resource_name}' is referenced by:\n\n"
            for ref in references:
                ref_text += f"• {ref['type'].title()}: {ref['name']}\n"
            QMessageBox.information(self, "Resource References", ref_text)
        else:
            QMessageBox.information(
                self,
                "No References",
                f"'{self._resource_name}' is not referenced by any other resources."
            )
        
        self.update_references_display()
    
    def update_references_display(self):
        """Update the 'Used by' label in properties panel"""
        if not hasattr(self, "used_by_label") or not getattr(self, "_resource_id", None):
            return
        
        references = self._find_resource_references("sounds", self._resource_id, self._resource_name)
        
        if references:
            ref_text = "Used by: "
            ref_names = [f"{ref['type'].title()}: {ref['name']}" for ref in references[:3]]
            ref_text += ", ".join(ref_names)
            if len(references) > 3:
                ref_text += f" (+{len(references) - 3} more)"
            self.used_by_label.setText(ref_text)
        else:
            self.used_by_label.setText("Used by: None")
    
    def _find_resource_references(self, resource_type, resource_id, resource_name):
        """Find all resources that reference the given resource"""
        import os
        references = []
        project_path = self.app.project_manager.get_project_path()
        if not project_path:
            return references
        
        for ref_type in ["sprites", "backgrounds", "objects", "sounds", "models", "rooms"]:
            runtime_resources = self.app.project_manager.get_runtime_resources(ref_type)
            resources = list(runtime_resources.values())
            
            for resource in resources:
                if ref_type == resource_type and resource.get("id") == resource_id:
                    continue
                
                resource_folder_map = {
                    "sprites": "Sprites",
                    "backgrounds": "Backgrounds",
                    "textures": "Textures",
                    "objects": "Objects",
                    "sounds": "Sounds",
                    "models": "Models",
                    "rooms": "Rooms"
                }
                
                resource_folder = resource_folder_map.get(ref_type, "Sprites")
                parent_folder = resource.get("parent_folder", "")
                
                file_path = os.path.join(project_path, "Resources", resource_folder)
                if parent_folder:
                    file_path = os.path.join(file_path, parent_folder)
                
                resource_name_file = resource.get("name", "")
                if resource_name_file:
                    file_extension = {
                        "sprites": ".sprite",
                        "backgrounds": ".background",
                        "textures": ".texture",
                        "objects": ".object",
                        "sounds": ".sound",
                        "models": ".model",
                        "rooms": ".room"
                    }
                    file_name = f"{resource_name_file}{file_extension.get(ref_type, '.dat')}"
                    file_path = os.path.join(file_path, file_name)
                else:
                    continue
                
                if not os.path.exists(file_path):
                    continue
                
                try:
                    with open(file_path, "r", encoding="utf-8") as f:
                        data = f.read()
                        if resource_name and resource_name in data:
                            references.append({
                                "type": ref_type,
                                "name": resource_name_file,
                                "path": file_path
                            })
                except Exception:
                    continue
        
        return references
    
    def save_resource(self):
        """Save the sound resource"""
        if hasattr(self.app, 'resource_manager'):
            return self.app.resource_manager.save_resource("sounds", self.resource_data)
        return False
    
