"""
WaveForge - Audacity-style Waveform Editor
Advanced multi-track audio editing with waveform visualization
"""

from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QMenuBar,
    QMenu, QScrollArea, QSplitter, QTabWidget, QGroupBox,
    QSlider, QSpinBox, QDoubleSpinBox, QCheckBox, QComboBox, QMessageBox,
    QFileDialog, QDialog, QDialogButtonBox, QTextEdit, QListWidget,
    QListWidgetItem, QFrame, QSizePolicy
)
from PySide6.QtCore import Qt, Signal, QTimer, QPoint, QRect
from PySide6.QtGui import QPainter, QPen, QBrush, QColor, QFont, QKeySequence, QContextMenuEvent, QAction

import os
import json
import numpy as np
import wave
import tempfile
import copy

# Optional audio dependencies
try:
    from pydub import AudioSegment
    from pydub.utils import which
    PYDUB_AVAILABLE = True
except ImportError:
    PYDUB_AVAILABLE = False
    print("Warning: pydub not installed. Audio file loading will be disabled.")

try:
    import pygame
    PYGAME_AVAILABLE = True
except ImportError:
    PYGAME_AVAILABLE = False
    print("Warning: pygame not installed. Audio playback will be disabled.")


class TimelineWidget(QWidget):
    """Timeline ruler at the top showing time markers"""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.duration = 0.0
        self.current_position = 0.0
        self.zoom_level = 1.0  # 1.0 = full view
        self.pixels_per_second = 100.0  # Base scale
        
        self.setFixedHeight(40)
        self.setStyleSheet("""
            TimelineWidget {
                background-color: #2b2b2b;
                border-bottom: 1px solid #555;
            }
        """)
    
    def paintEvent(self, event):
        """Draw timeline with time markers"""
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        
        width = self.width()
        height = self.height()
        
        # Fill background
        painter.fillRect(self.rect(), QColor("#2b2b2b"))
        
        if self.duration <= 0:
            return
        
        # Calculate visible time range
        visible_duration = self.duration / self.zoom_level
        start_time = max(0, self.current_position - visible_duration / 2)
        end_time = min(self.duration, start_time + visible_duration)
        
        # Draw time markers
        painter.setPen(QPen(QColor("#888"), 1))
        painter.setFont(QFont("Arial", 9))
        
        # Determine marker interval based on zoom
        if visible_duration <= 1:
            interval = 0.1  # 100ms
        elif visible_duration <= 10:
            interval = 1.0  # 1 second
        elif visible_duration <= 60:
            interval = 5.0  # 5 seconds
        else:
            interval = 10.0  # 10 seconds
        
        # Draw markers
        time = start_time
        while time <= end_time:
            x = int((time - start_time) / visible_duration * width)
            if 0 <= x <= width:
                # Draw tick mark
                painter.drawLine(x, height - 15, x, height)
                
                # Draw time label
                time_str = self.format_time(time)
                metrics = painter.fontMetrics()
                text_width = metrics.horizontalAdvance(time_str)
                painter.setPen(QPen(QColor("#aaa"), 1))
                painter.drawText(x - text_width // 2, height - 18, time_str)
            
            time += interval
        
        # Draw current position indicator
        if self.current_position >= start_time and self.current_position <= end_time:
            pos_x = int((self.current_position - start_time) / visible_duration * width)
            painter.setPen(QPen(QColor("#ff0000"), 2))
            painter.drawLine(pos_x, 0, pos_x, height)
    
    def format_time(self, seconds):
        """Format time as MM:SS.mmm"""
        minutes = int(seconds // 60)
        secs = int(seconds % 60)
        millis = int((seconds % 1) * 1000)
        return f"{minutes:02d}:{secs:02d}.{millis:03d}"
    
    def set_duration(self, duration):
        """Set total duration"""
        self.duration = duration
        self.update()
    
    def set_position(self, position):
        """Set current playback position"""
        self.current_position = position
        self.update()
    
    def set_zoom(self, zoom_level):
        """Set zoom level (1.0 = full view, higher = more zoomed in)"""
        self.zoom_level = max(0.1, min(10.0, zoom_level))
        self.update()


class WaveformTrackWidget(QWidget):
    """Single track widget with waveform display"""
    
    selection_changed = Signal(float, float)  # start_time, end_time
    
    def __init__(self, track_name="Track 1", parent=None):
        super().__init__(parent)
        self.track_name = track_name
        self.waveform_data = None  # numpy array
        self.duration = 0.0
        self.current_position = 0.0
        
        # Selection state
        self.selection_start = None
        self.selection_end = None
        self.selecting = False
        self.selection_start_x = None
        
        # Visual settings
        self.waveform_color = QColor("#0066cc")
        self.selection_color = QColor(97, 175, 239, 80)
        self.needle_color = QColor("#ff0000")
        
        self.setMinimumHeight(120)
        self.setStyleSheet("""
            WaveformTrackWidget {
                background-color: #1e1e1e;
                border: 1px solid #444;
            }
        """)
    
    def paintEvent(self, event):
        """Draw waveform, selection, and playback needle"""
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        
        width = self.width()
        height = self.height()
        center_y = height // 2
        
        # Fill background
        painter.fillRect(self.rect(), QColor("#1e1e1e"))
        
        # Draw waveform
        if self.waveform_data is not None and len(self.waveform_data) > 0:
            self.draw_waveform(painter, width, height, center_y)
        
        # Draw selection overlay
        if self.selection_start is not None and self.selection_end is not None:
            self.draw_selection(painter, width, height)
        
        # Draw playback needle
        if self.duration > 0:
            self.draw_needle(painter, width, height)
        
        # Draw track name label
        painter.setPen(QPen(QColor("#888"), 1))
        painter.setFont(QFont("Arial", 10))
        painter.drawText(5, 15, self.track_name)
    
    def draw_waveform(self, painter, width, height, center_y):
        """Draw the audio waveform"""
        painter.setPen(QPen(self.waveform_color, 1))
        painter.setBrush(QBrush(self.waveform_color))
        
        if len(self.waveform_data) > 1:
            points_per_pixel = len(self.waveform_data) / width
            for x in range(width):
                start_idx = int(x * points_per_pixel)
                end_idx = int((x + 1) * points_per_pixel)
                
                if start_idx < len(self.waveform_data):
                    segment = self.waveform_data[start_idx:min(end_idx, len(self.waveform_data))]
                    if len(segment) > 0:
                        max_amp = np.max(np.abs(segment))
                        wave_height = int(max_amp * center_y)
                        if wave_height == 0 and max_amp > 0:
                            wave_height = 1
                        painter.drawLine(x, center_y - wave_height, x, center_y + wave_height)
    
    def draw_selection(self, painter, width, height):
        """Draw selection overlay"""
        if self.duration <= 0:
            return
        
        start_ratio = self.selection_start / self.duration
        end_ratio = self.selection_end / self.duration
        start_x = int(start_ratio * width)
        end_x = int(end_ratio * width)
        
        # Draw semi-transparent overlay
        painter.fillRect(start_x, 0, end_x - start_x, height, self.selection_color)
        
        # Draw selection borders
        pen = QPen(QColor(97, 175, 239), 2)
        painter.setPen(pen)
        painter.drawLine(start_x, 0, start_x, height)
        painter.drawLine(end_x, 0, end_x, height)
    
    def draw_needle(self, painter, width, height):
        """Draw playback position needle"""
        if self.duration <= 0:
            return
        
        position_ratio = self.current_position / self.duration
        needle_x = int(position_ratio * width)
        needle_x = max(0, min(needle_x, width - 1))
        
        painter.setPen(QPen(self.needle_color, 2))
        painter.drawLine(needle_x, 0, needle_x, height)
    
    def mousePressEvent(self, event):
        """Handle mouse clicks for seeking or selection"""
        if event.button() == Qt.LeftButton and self.duration > 0:
            click_x = event.x()
            width = self.width()
            position_ratio = click_x / width
            new_position = position_ratio * self.duration
            
            # Check if Shift is held for selection mode
            if event.modifiers() & Qt.ShiftModifier:
                # Start selection
                self.selecting = True
                self.selection_start_x = click_x
                self.selection_start = new_position
                self.selection_end = new_position
                self.update()
            else:
                # Normal seeking - emit signal to parent
                self.selection_changed.emit(new_position, new_position)
                self.clear_selection()
    
    def mouseMoveEvent(self, event):
        """Handle mouse movement during selection"""
        if self.selecting and self.duration > 0:
            click_x = event.x()
            width = self.width()
            position_ratio = click_x / width
            new_position = position_ratio * self.duration
            
            if self.selection_start_x is not None:
                self.selection_end = new_position
                # Ensure start < end
                if self.selection_end < self.selection_start:
                    self.selection_start, self.selection_end = self.selection_end, self.selection_start
                self.update()
                # Emit selection changed
                self.selection_changed.emit(self.selection_start, self.selection_end)
    
    def mouseReleaseEvent(self, event):
        """Handle mouse release to finalize selection"""
        if event.button() == Qt.LeftButton and self.selecting:
            self.selecting = False
            if abs(self.selection_end - self.selection_start) < 0.01:
                self.clear_selection()
            else:
                self.selection_changed.emit(self.selection_start, self.selection_end)
            self.update()
    
    def contextMenuEvent(self, event):
        """Show context menu"""
        menu = QMenu(self)
        
        cut_action = QAction("Cut", self)
        cut_action.setShortcut(QKeySequence.Cut)
        cut_action.triggered.connect(lambda: self.emit_cut())
        menu.addAction(cut_action)
        
        copy_action = QAction("Copy", self)
        copy_action.setShortcut(QKeySequence.Copy)
        copy_action.triggered.connect(lambda: self.emit_copy())
        menu.addAction(copy_action)
        
        paste_action = QAction("Paste", self)
        paste_action.setShortcut(QKeySequence.Paste)
        paste_action.triggered.connect(lambda: self.emit_paste())
        menu.addAction(paste_action)
        
        delete_action = QAction("Delete", self)
        delete_action.setShortcut(QKeySequence.Delete)
        delete_action.triggered.connect(lambda: self.emit_delete())
        menu.addAction(delete_action)
        
        menu.addSeparator()
        
        select_all_action = QAction("Select All", self)
        select_all_action.setShortcut(QKeySequence.SelectAll)
        select_all_action.triggered.connect(self.select_all)
        menu.addAction(select_all_action)
        
        menu.exec(event.globalPos())
    
    def emit_cut(self):
        """Emit cut signal"""
        if self.has_selection():
            self.parent().cut_selection()
    
    def emit_copy(self):
        """Emit copy signal"""
        if self.has_selection():
            self.parent().copy_selection()
    
    def emit_paste(self):
        """Emit paste signal"""
        self.parent().paste_selection()
    
    def emit_delete(self):
        """Emit delete signal"""
        if self.has_selection():
            self.parent().delete_selection()
    
    def clear_selection(self):
        """Clear selection"""
        self.selection_start = None
        self.selection_end = None
        self.selection_start_x = None
        self.selecting = False
        self.update()
    
    def select_all(self):
        """Select entire track"""
        if self.duration > 0:
            self.selection_start = 0.0
            self.selection_end = self.duration
            self.update()
            self.selection_changed.emit(self.selection_start, self.selection_end)
    
    def has_selection(self):
        """Check if there is a selection"""
        return self.selection_start is not None and self.selection_end is not None
    
    def get_selection(self):
        """Get selection range in seconds"""
        if self.has_selection():
            return (self.selection_start, self.selection_end)
        return None
    
    def update_waveform(self, waveform_data, duration):
        """Update waveform data"""
        self.waveform_data = waveform_data
        self.duration = duration
        self.update()
    
    def set_position(self, position):
        """Set playback position"""
        self.current_position = position
        self.update()


class WaveForge(QWidget):
    """Main WaveForge editor window"""
    
    def __init__(self, app=None, resource=None, parent=None):
        super().__init__(parent)
        self.app = app
        self.resource = resource
        
        # Set window flags to make it a proper window
        if parent is None:
            self.setWindowFlags(Qt.Window)
        else:
            self.setWindowFlags(Qt.Dialog)
        
        self.setMinimumSize(1000, 700)
        
        # Audio data
        self.tracks = []  # List of AudioSegment objects
        self.clipboard = None  # Clipboard for copy/paste
        
        # Playback state
        self.is_playing = False
        self.is_paused = False
        self.current_position = 0.0
        self.playback_channels = []
        
        # UI components
        self.timeline = None
        self.tracks_scroll = None
        self.tracks_widget = None
        
        # Effects
        self.effects_tab = None
        
        self.setup_ui()
        self.setup_menus()
        self.setup_playback()
        
        # Load resource if provided
        if resource:
            self.load_resource(resource)
    
    def setup_ui(self):
        """Setup the main UI"""
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)
        
        # Menu bar
        self.menu_bar = QMenuBar(self)
        layout.addWidget(self.menu_bar)
        
        # Timeline
        self.timeline = TimelineWidget(self)
        layout.addWidget(self.timeline)
        
        # Main splitter
        splitter = QSplitter(Qt.Horizontal, self)
        
        # Tracks area (left side)
        tracks_container = QWidget()
        tracks_layout = QVBoxLayout(tracks_container)
        tracks_layout.setContentsMargins(0, 0, 0, 0)
        
        # Scroll area for tracks
        self.tracks_scroll = QScrollArea()
        self.tracks_scroll.setWidgetResizable(True)
        self.tracks_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        
        self.tracks_widget = QWidget()
        self.tracks_layout = QVBoxLayout(self.tracks_widget)
        self.tracks_layout.setContentsMargins(0, 0, 0, 0)
        self.tracks_layout.setSpacing(2)
        self.tracks_layout.addStretch()
        
        self.tracks_scroll.setWidget(self.tracks_widget)
        tracks_layout.addWidget(self.tracks_scroll)
        
        splitter.addWidget(tracks_container)
        
        # Effects panel (right side)
        self.effects_tab = QTabWidget()
        self.setup_effects_tab()
        splitter.addWidget(self.effects_tab)
        
        splitter.setStretchFactor(0, 3)
        splitter.setStretchFactor(1, 1)
        
        layout.addWidget(splitter)
        
        # Playback controls
        controls_layout = QHBoxLayout()
        
        self.play_btn = QPushButton("▶")
        self.play_btn.setFixedSize(40, 40)
        self.play_btn.clicked.connect(self.toggle_playback)
        controls_layout.addWidget(self.play_btn)
        
        self.stop_btn = QPushButton("⏹")
        self.stop_btn.setFixedSize(40, 40)
        self.stop_btn.clicked.connect(self.stop_playback)
        controls_layout.addWidget(self.stop_btn)
        
        self.time_label = QLabel("00:00.000 / 00:00.000")
        self.time_label.setMinimumWidth(150)
        controls_layout.addWidget(self.time_label)
        
        controls_layout.addStretch()
        
        # Zoom controls
        zoom_label = QLabel("Zoom:")
        controls_layout.addWidget(zoom_label)
        
        self.zoom_slider = QSlider(Qt.Horizontal)
        self.zoom_slider.setMinimum(1)
        self.zoom_slider.setMaximum(100)
        self.zoom_slider.setValue(10)
        self.zoom_slider.valueChanged.connect(self.on_zoom_changed)
        self.zoom_slider.setMaximumWidth(200)
        controls_layout.addWidget(self.zoom_slider)
        
        layout.addLayout(controls_layout)
    
    def setup_menus(self):
        """Setup menu bar"""
        # File menu
        file_menu = self.menu_bar.addMenu("&File")
        
        open_action = QAction("&Open...", self)
        open_action.setShortcut(QKeySequence.Open)
        open_action.triggered.connect(self.open_file)
        file_menu.addAction(open_action)
        
        import_action = QAction("&Import Audio...", self)
        import_action.triggered.connect(self.import_audio)
        file_menu.addAction(import_action)
        
        file_menu.addSeparator()
        
        save_action = QAction("&Save", self)
        save_action.setShortcut(QKeySequence.Save)
        save_action.triggered.connect(self.save_file)
        file_menu.addAction(save_action)
        
        save_as_action = QAction("Save &As...", self)
        save_as_action.setShortcut(QKeySequence.SaveAs)
        save_as_action.triggered.connect(self.save_as_file)
        file_menu.addAction(save_as_action)
        
        # Edit menu
        edit_menu = self.menu_bar.addMenu("&Edit")
        
        undo_action = QAction("&Undo", self)
        undo_action.setShortcut(QKeySequence.Undo)
        undo_action.triggered.connect(self.undo_action)
        edit_menu.addAction(undo_action)
        
        redo_action = QAction("&Redo", self)
        redo_action.setShortcut(QKeySequence.Redo)
        redo_action.triggered.connect(self.redo_action)
        edit_menu.addAction(redo_action)
        
        edit_menu.addSeparator()
        
        cut_action = QAction("Cu&t", self)
        cut_action.setShortcut(QKeySequence.Cut)
        cut_action.triggered.connect(self.cut_selection)
        edit_menu.addAction(cut_action)
        
        copy_action = QAction("&Copy", self)
        copy_action.setShortcut(QKeySequence.Copy)
        copy_action.triggered.connect(self.copy_selection)
        edit_menu.addAction(copy_action)
        
        paste_action = QAction("&Paste", self)
        paste_action.setShortcut(QKeySequence.Paste)
        paste_action.triggered.connect(self.paste_selection)
        edit_menu.addAction(paste_action)
        
        delete_action = QAction("&Delete", self)
        delete_action.setShortcut(QKeySequence.Delete)
        delete_action.triggered.connect(self.delete_selection)
        edit_menu.addAction(delete_action)
        
        edit_menu.addSeparator()
        
        select_all_action = QAction("Select &All", self)
        select_all_action.setShortcut(QKeySequence.SelectAll)
        select_all_action.triggered.connect(self.select_all)
        edit_menu.addAction(select_all_action)
        
        # Effects menu
        effects_menu = self.menu_bar.addMenu("&Effects")
        self.setup_effects_menu(effects_menu)
    
    def setup_effects_menu(self, menu):
        """Setup effects menu"""
        # Fades
        fade_in_action = QAction("Fade &In", self)
        fade_in_action.triggered.connect(lambda: self.apply_fade_in())
        menu.addAction(fade_in_action)
        
        fade_out_action = QAction("Fade &Out", self)
        fade_out_action.triggered.connect(lambda: self.apply_fade_out())
        menu.addAction(fade_out_action)
        
        menu.addSeparator()
        
        # Volume
        normalize_action = QAction("&Normalize", self)
        normalize_action.triggered.connect(lambda: self.apply_normalize())
        menu.addAction(normalize_action)
        
        amplify_action = QAction("&Amplify...", self)
        amplify_action.triggered.connect(self.show_amplify_dialog)
        menu.addAction(amplify_action)
        
        menu.addSeparator()
        
        # Time
        reverse_action = QAction("&Reverse", self)
        reverse_action.triggered.connect(lambda: self.apply_reverse())
        menu.addAction(reverse_action)
    
    def setup_effects_tab(self):
        """Setup effects tab widget"""
        # Fades category
        fades_group = QGroupBox("Fades")
        fades_layout = QVBoxLayout()
        
        fade_in_btn = QPushButton("Fade In")
        fade_in_btn.clicked.connect(lambda: self.apply_fade_in())
        fades_layout.addWidget(fade_in_btn)
        
        fade_out_btn = QPushButton("Fade Out")
        fade_out_btn.clicked.connect(lambda: self.apply_fade_out())
        fades_layout.addWidget(fade_out_btn)
        
        fades_group.setLayout(fades_layout)
        
        # Volume category
        volume_group = QGroupBox("Volume")
        volume_layout = QVBoxLayout()
        
        normalize_btn = QPushButton("Normalize")
        normalize_btn.clicked.connect(lambda: self.apply_normalize())
        volume_layout.addWidget(normalize_btn)
        
        amplify_btn = QPushButton("Amplify...")
        amplify_btn.clicked.connect(self.show_amplify_dialog)
        volume_layout.addWidget(amplify_btn)
        
        volume_group.setLayout(volume_layout)
        
        # Time category
        time_group = QGroupBox("Time")
        time_layout = QVBoxLayout()
        
        reverse_btn = QPushButton("Reverse")
        reverse_btn.clicked.connect(lambda: self.apply_reverse())
        time_layout.addWidget(reverse_btn)
        
        time_group.setLayout(time_layout)
        
        # Create scroll area for effects
        effects_scroll = QScrollArea()
        effects_widget = QWidget()
        effects_layout = QVBoxLayout(effects_widget)
        effects_layout.addWidget(fades_group)
        effects_layout.addWidget(volume_group)
        effects_layout.addWidget(time_group)
        effects_layout.addStretch()
        
        effects_scroll.setWidget(effects_widget)
        effects_scroll.setWidgetResizable(True)
        
        self.effects_tab.addTab(effects_scroll, "Effects")
    
    def setup_playback(self):
        """Setup playback timer"""
        self.playback_timer = QTimer()
        self.playback_timer.timeout.connect(self.update_playback_position)
        self.playback_timer.start(50)  # Update every 50ms
        
        if PYGAME_AVAILABLE:
            pygame.mixer.init(frequency=44100, size=-16, channels=2, buffer=512)
            pygame.mixer.set_num_channels(32)
    
    def add_track(self, audio_segment, track_name=None):
        """Add a new track"""
        if not PYDUB_AVAILABLE:
            QMessageBox.warning(self, "Error", "pydub is required for audio editing")
            return
        
        if track_name is None:
            track_name = f"Track {len(self.tracks) + 1}"
        
        # Store audio segment
        self.tracks.append({
            "name": track_name,
            "audio": audio_segment,
            "waveform": None,
            "duration": len(audio_segment) / 1000.0
        })
        
        # Generate waveform
        self.generate_waveform(len(self.tracks) - 1)
        
        # Create track widget
        track_widget = WaveformTrackWidget(track_name, self)
        track_widget.selection_changed.connect(lambda s, e: self.on_selection_changed(s, e))
        
        # Store reference to track widget
        track["widget"] = track_widget
        
        # Insert before stretch
        self.tracks_layout.insertWidget(self.tracks_layout.count() - 1, track_widget)
        
        # Update timeline
        max_duration = max(t["duration"] for t in self.tracks) if self.tracks else 0
        self.timeline.set_duration(max_duration)
    
    def generate_waveform(self, track_index):
        """Generate waveform data for a track"""
        if track_index >= len(self.tracks):
            return
        
        track = self.tracks[track_index]
        audio = track["audio"]
        
        # Convert to numpy array
        samples = np.array(audio.get_array_of_samples())
        
        # Handle stereo
        if audio.channels == 2:
            samples = samples.reshape(-1, 2)
            samples = np.mean(samples, axis=1)  # Convert to mono for display
        
        # Normalize to [-1, 1]
        if audio.sample_width == 1:
            samples = samples.astype(np.float32) / 128.0 - 1.0
        elif audio.sample_width == 2:
            samples = samples.astype(np.float32) / 32768.0
        elif audio.sample_width == 4:
            samples = samples.astype(np.float32) / 2147483648.0
        else:
            samples = samples.astype(np.float32) / 32768.0
        
        # Downsample for display (max 10000 points)
        target_points = min(10000, len(samples))
        if len(samples) > target_points:
            indices = np.linspace(0, len(samples) - 1, target_points, dtype=int)
            samples = samples[indices]
        
        track["waveform"] = samples
        
        # Update widget
        widget = track.get("widget")
        if widget:
            widget.update_waveform(samples, track["duration"])
    
    def on_selection_changed(self, start_time, end_time):
        """Handle selection change from track widget"""
        # Store selection for active track
        # All tracks can have independent selections, but we'll sync for now
        pass
    
    def get_active_track(self):
        """Get the currently active track index"""
        # For now, return first track (can be enhanced with focus tracking)
        # In the future, track which widget has focus
        return 0 if self.tracks else None
    
    def get_active_track_widget(self):
        """Get the active track widget"""
        track_idx = self.get_active_track()
        if track_idx is not None and track_idx < len(self.tracks):
            return self.tracks[track_idx].get("widget")
        return None
    
    def get_selection(self):
        """Get current selection from active track"""
        widget = self.get_active_track_widget()
        if widget:
            return widget.get_selection()
        return None
    
    def cut_selection(self):
        """Cut selected audio"""
        selection = self.get_selection()
        if not selection:
            return
        
        self.copy_selection()
        self.delete_selection()
    
    def copy_selection(self):
        """Copy selected audio to clipboard"""
        selection = self.get_selection()
        if not selection:
            return
        
        track_idx = self.get_active_track()
        if track_idx is None:
            return
        
        track = self.tracks[track_idx]
        start_ms = int(selection[0] * 1000)
        end_ms = int(selection[1] * 1000)
        
        # Extract segment
        segment = track["audio"][start_ms:end_ms]
        self.clipboard = segment
    
    def paste_selection(self):
        """Paste audio from clipboard"""
        if self.clipboard is None:
            return
        
        track_idx = self.get_active_track()
        if track_idx is None:
            return
        
        track = self.tracks[track_idx]
        current_pos = self.current_position
        
        # Insert at current position
        start_ms = int(current_pos * 1000)
        before = track["audio"][:start_ms]
        after = track["audio"][start_ms:]
        
        track["audio"] = before + self.clipboard + after
        track["duration"] = len(track["audio"]) / 1000.0
        
        # Regenerate waveform
        self.generate_waveform(track_idx)
    
    def delete_selection(self):
        """Delete selected audio"""
        selection = self.get_selection()
        if not selection:
            return
        
        track_idx = self.get_active_track()
        if track_idx is None:
            return
        
        track = self.tracks[track_idx]
        start_ms = int(selection[0] * 1000)
        end_ms = int(selection[1] * 1000)
        
        # Remove segment
        before = track["audio"][:start_ms]
        after = track["audio"][end_ms:]
        track["audio"] = before + after
        track["duration"] = len(track["audio"]) / 1000.0
        
        # Regenerate waveform
        self.generate_waveform(track_idx)
        
        # Clear selection
        widget = self.get_active_track_widget()
        if widget:
            widget.clear_selection()
    
    def select_all(self):
        """Select all audio in active track"""
        widget = self.get_active_track_widget()
        if widget:
            widget.select_all()
    
    def apply_fade_in(self):
        """Apply fade in effect"""
        selection = self.get_selection()
        track_idx = self.get_active_track()
        if track_idx is None:
            return
        
        track = self.tracks[track_idx]
        
        if selection:
            start_ms = int(selection[0] * 1000)
            end_ms = int(selection[1] * 1000)
            duration_ms = end_ms - start_ms
            segment = track["audio"][start_ms:end_ms]
            faded = segment.fade_in(duration_ms)
            track["audio"] = track["audio"][:start_ms] + faded + track["audio"][end_ms:]
        else:
            # Apply to entire track
            track["audio"] = track["audio"].fade_in(len(track["audio"]))
        
        self.generate_waveform(track_idx)
    
    def apply_fade_out(self):
        """Apply fade out effect"""
        selection = self.get_selection()
        track_idx = self.get_active_track()
        if track_idx is None:
            return
        
        track = self.tracks[track_idx]
        
        if selection:
            start_ms = int(selection[0] * 1000)
            end_ms = int(selection[1] * 1000)
            duration_ms = end_ms - start_ms
            segment = track["audio"][start_ms:end_ms]
            faded = segment.fade_out(duration_ms)
            track["audio"] = track["audio"][:start_ms] + faded + track["audio"][end_ms:]
        else:
            # Apply to entire track
            track["audio"] = track["audio"].fade_out(len(track["audio"]))
        
        self.generate_waveform(track_idx)
    
    def apply_normalize(self):
        """Normalize audio"""
        track_idx = self.get_active_track()
        if track_idx is None:
            return
        
        track = self.tracks[track_idx]
        track["audio"] = track["audio"].normalize()
        self.generate_waveform(track_idx)
    
    def show_amplify_dialog(self):
        """Show amplify dialog"""
        dialog = QDialog(self)
        dialog.setWindowTitle("Amplify")
        layout = QVBoxLayout(dialog)
        
        label = QLabel("Amplification (dB):")
        layout.addWidget(label)
        
        spinbox = QDoubleSpinBox()
        spinbox.setRange(-60, 60)
        spinbox.setValue(0)
        spinbox.setSuffix(" dB")
        layout.addWidget(spinbox)
        
        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.accepted.connect(dialog.accept)
        buttons.rejected.connect(dialog.reject)
        layout.addWidget(buttons)
        
        if dialog.exec():
            self.apply_amplify(spinbox.value())
    
    def apply_amplify(self, db_change):
        """Apply amplification"""
        track_idx = self.get_active_track()
        if track_idx is None:
            return
        
        track = self.tracks[track_idx]
        track["audio"] = track["audio"] + db_change
        self.generate_waveform(track_idx)
    
    def apply_reverse(self):
        """Reverse audio"""
        selection = self.get_selection()
        track_idx = self.get_active_track()
        if track_idx is None:
            return
        
        track = self.tracks[track_idx]
        
        if selection:
            start_ms = int(selection[0] * 1000)
            end_ms = int(selection[1] * 1000)
            segment = track["audio"][start_ms:end_ms]
            reversed_seg = segment.reverse()
            track["audio"] = track["audio"][:start_ms] + reversed_seg + track["audio"][end_ms:]
        else:
            track["audio"] = track["audio"].reverse()
        
        self.generate_waveform(track_idx)
    
    def toggle_playback(self):
        """Toggle playback"""
        if not self.tracks:
            return
        
        if self.is_playing:
            if self.is_paused:
                self.resume_playback()
            else:
                self.pause_playback()
        else:
            self.start_playback()
    
    def start_playback(self):
        """Start playback"""
        if not PYGAME_AVAILABLE or not self.tracks:
            return
        
        # Export first track to temp file and play
        track = self.tracks[0]
        temp_file = tempfile.NamedTemporaryFile(suffix='.wav', delete=False)
        track["audio"].export(temp_file.name, format="wav")
        
        pygame.mixer.music.load(temp_file.name)
        pygame.mixer.music.play(start=self.current_position)
        
        self.is_playing = True
        self.is_paused = False
        self.play_btn.setText("⏸")
    
    def pause_playback(self):
        """Pause playback"""
        if PYGAME_AVAILABLE:
            pygame.mixer.music.pause()
        self.is_paused = True
        self.play_btn.setText("▶")
    
    def resume_playback(self):
        """Resume playback"""
        if PYGAME_AVAILABLE:
            pygame.mixer.music.unpause()
        self.is_paused = False
        self.play_btn.setText("⏸")
    
    def stop_playback(self):
        """Stop playback"""
        if PYGAME_AVAILABLE:
            pygame.mixer.music.stop()
        self.is_playing = False
        self.is_paused = False
        self.current_position = 0.0
        self.play_btn.setText("▶")
        self.update_display()
    
    def update_playback_position(self):
        """Update playback position"""
        if PYGAME_AVAILABLE and self.is_playing and not self.is_paused:
            # Get position from pygame (approximate)
            if pygame.mixer.music.get_busy():
                # Update position (this is approximate)
                self.current_position += 0.05  # 50ms increments
                if self.current_position >= self.tracks[0]["duration"]:
                    self.stop_playback()
        
        self.update_display()
    
    def update_display(self):
        """Update all displays"""
        # Update timeline
        self.timeline.set_position(self.current_position)
        
        # Update track widgets
        for track in self.tracks:
            widget = track.get("widget")
            if widget:
                widget.set_position(self.current_position)
        
        # Update time label
        duration = self.tracks[0]["duration"] if self.tracks else 0
        time_str = f"{self.format_time(self.current_position)} / {self.format_time(duration)}"
        self.time_label.setText(time_str)
    
    def format_time(self, seconds):
        """Format time as MM:SS.mmm"""
        minutes = int(seconds // 60)
        secs = int(seconds % 60)
        millis = int((seconds % 1) * 1000)
        return f"{minutes:02d}:{secs:02d}.{millis:03d}"
    
    def on_zoom_changed(self, value):
        """Handle zoom change"""
        zoom_level = value / 10.0
        self.timeline.set_zoom(zoom_level)
        # TODO: Update track zoom
    
    def open_file(self):
        """Open audio file"""
        if not PYDUB_AVAILABLE:
            QMessageBox.warning(self, "Error", "pydub is required for audio file loading")
            return
        
        file_path, _ = QFileDialog.getOpenFileName(
            self, "Open Audio File", "",
            "Audio Files (*.wav *.mp3 *.ogg *.flac);;All Files (*)"
        )
        
        if file_path:
            self.load_audio_file(file_path)
    
    def import_audio(self):
        """Import audio as new track"""
        if not PYDUB_AVAILABLE:
            QMessageBox.warning(self, "Error", "pydub is required for audio file loading")
            return
        
        file_path, _ = QFileDialog.getOpenFileName(
            self, "Import Audio File", "",
            "Audio Files (*.wav *.mp3 *.ogg *.flac);;All Files (*)"
        )
        
        if file_path:
            try:
                audio = AudioSegment.from_file(file_path)
                track_name = os.path.basename(file_path)
                self.add_track(audio, track_name)
            except Exception as e:
                QMessageBox.critical(self, "Error", f"Failed to load audio file: {str(e)}")
    
    def load_audio_file(self, file_path):
        """Load audio file"""
        if not PYDUB_AVAILABLE:
            QMessageBox.warning(self, "Error", "pydub is required for audio file loading")
            return
        
        # Normalize and verify path
        if not file_path:
            QMessageBox.warning(self, "Error", "No file path provided")
            return
        
        file_path = os.path.normpath(file_path)
        
        if not os.path.exists(file_path):
            QMessageBox.warning(
                self, "File Not Found",
                f"Audio file not found:\n{file_path}\n\n"
                f"Please check that the file exists and try again."
            )
            return
        
        try:
            # Clear existing tracks
            self.tracks.clear()
            track_widgets = self.tracks_widget.findChildren(WaveformTrackWidget)
            for widget in track_widgets:
                widget.deleteLater()
            
            # Load new audio
            audio = AudioSegment.from_file(file_path)
            track_name = os.path.basename(file_path)
            self.add_track(audio, track_name)
        except Exception as e:
            QMessageBox.critical(
                self, "Error",
                f"Failed to load audio file:\n{file_path}\n\n"
                f"Error: {str(e)}"
            )
    
    def load_resource(self, resource):
        """Load resource data"""
        if not resource:
            return
        
        # Try to load audio file from resource
        audio_file = resource.get("audio_file")
        if audio_file:
            # Try original_audio_file first (full path)
            original_audio_file = resource.get("original_audio_file")
            if original_audio_file and os.path.exists(original_audio_file):
                self.load_audio_file(original_audio_file)
                return
            
            # Construct full path from project
            if self.app and self.app.project_manager:
                project_path = self.app.project_manager.get_project_path()
                if project_path:
                    sounds_folder = os.path.join(project_path, "Resources", "Sounds")
                    full_path = os.path.normpath(os.path.join(sounds_folder, audio_file))
                    if os.path.exists(full_path):
                        self.load_audio_file(full_path)
                        return
        
        # Don't show warning if we're being called from SoundEditor (it will handle loading)
        # Only show warning if called directly
        pass
    
    def save_file(self):
        """Save current project"""
        # TODO: Implement save functionality
        QMessageBox.information(self, "Info", "Save functionality coming soon")
    
    def save_as_file(self):
        """Save as new file"""
        if not self.tracks:
            return
        
        file_path, _ = QFileDialog.getSaveFileName(
            self, "Save Audio File", "",
            "WAV Files (*.wav);;MP3 Files (*.mp3);;All Files (*)"
        )
        
        if file_path:
            try:
                # Export first track (or mix all tracks)
                if len(self.tracks) == 1:
                    self.tracks[0]["audio"].export(file_path)
                else:
                    # Mix all tracks
                    mixed = self.tracks[0]["audio"]
                    for track in self.tracks[1:]:
                        mixed = mixed.overlay(track["audio"])
                    mixed.export(file_path)
                
                QMessageBox.information(self, "Success", "File saved successfully")
            except Exception as e:
                QMessageBox.critical(self, "Error", f"Failed to save file: {str(e)}")
    
    def undo_action(self):
        """Undo last action"""
        # TODO: Implement undo
        pass
    
    def redo_action(self):
        """Redo last action"""
        # TODO: Implement redo
        pass
    
    def keyPressEvent(self, event):
        """Handle keyboard shortcuts"""
        if event.matches(QKeySequence.Cut):
            self.cut_selection()
        elif event.matches(QKeySequence.Copy):
            self.copy_selection()
        elif event.matches(QKeySequence.Paste):
            self.paste_selection()
        elif event.matches(QKeySequence.Delete):
            self.delete_selection()
        elif event.matches(QKeySequence.SelectAll):
            self.select_all()
        else:
            super().keyPressEvent(event)
    
    def closeEvent(self, event):
        """Cleanup on close"""
        self.stop_playback()
        if PYGAME_AVAILABLE:
            try:
                pygame.mixer.music.stop()
                pygame.mixer.stop()
            except Exception:
                pass
        event.accept()

