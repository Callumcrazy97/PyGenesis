# Editors/CodeEditor/PGSLCodeEditor.py

from PySide6.QtWidgets import (
    QPlainTextEdit, QListWidget, QListWidgetItem, QApplication
)
from PySide6.QtGui import (
    QSyntaxHighlighter, QTextCharFormat, QColor, QFont, QTextCursor
)
from PySide6.QtCore import Qt, QTimer, QRect

import re


# ======================================================================
# 1. PGSL Command List (static for editor; dynamic loading added later)
# ======================================================================
PGSL_COMMANDS = [
    # Runtime
    "Run", "Debug_Run", "Build", "Validate", "game_end",
    "game_save", "game_load", "window_set_size", "window_set_title",
    "game_set_speed", "room_set_speed",

    # Variables
    "Variable_set", "Variable_get", "Variable_exists",
    "Wait", "clamp", "point_direction", "point_distance", "random_range",

    # Instance / Objects
    "create_instance", "instance_destroy", "instance_find",
    "instance_find_id", "instance_find_nearest", "instance_find_furthest",
    "instance_exists", "instance_get_count", "place_free",
    "instance_set_active",

    # 3D Movement
    "Move3D_direction", "Move3D_stop", "Move3D_add_force", "Move3D_towards",

    # Drawing
    "Draw_Self_2D", "Draw_Sprite_2D", "Draw_Text_2D",
    "Draw_Model_3D", "Draw_Model_Instanced", "Draw_2D", "Draw_Self_3D",
    "sprite_set_alpha", "sprite_set_2d_size", "sprite_set_color_tint",
    "model_set_3d_scale",

    # HUD / GUI
    "Draw_HUD", "Draw_HUD_Text", "Draw_Bar",

    # Atlases
    "sprite_make_atlas", "sprite_use_atlas", "sprite_use_atlas_tile",
    "sprite_get_width", "sprite_get_height", "sprite_get_frames",

    # Camera
    "Camera2D_set_position", "Camera2D_follow", "Camera2D_shake",
    "Camera3D_set_position", "Camera3D_set_target", "Camera3D_follow",
    "Camera3D_shake", "Viewport_create", "Viewport_set_camera",
    "Viewport_activate",

    # Audio
    "sound_play", "sound_stop", "sound_stop_all",
    "sound_pause_all", "sound_resume_all", "sound_is_active",

    # Input
    "key_check", "key_pressed", "key_released",
    "mouse_position", "mouse_delta",
    "Input_bind", "Input_check",

    # Networking
    "net_host", "net_connect", "net_close",
    "net_send_all", "net_send_to", "net_get",
    "net_sync_position", "net_sync_rotation", "net_sync_variable",
    "net_register_event", "net_my_id", "net_peers",

    # Shaders
    "shader_use", "shader_remove", "shader_set_uniform",
    "shader_set_uniform_vec3", "shader_set_uniform_color",
    "shader_use_object", "shader_set_uniform_object",

    # Compute
    "compute_shader_load", "compute_set_uniform",
    "compute_buffer_create", "compute_buffer_write",
    "compute_buffer_read", "compute_shader_run",

    # Particles
    "particle_system_create", "particle_system_emit",
    "particle_system_set_uniform", "particle_set_color",
    "particle_set_color_range", "particle_set_emissive",

    # Voxel / Chunk
    "bake_mesh_from_map", "chunk_set_active",
    "chunk_set_position", "chunk_destroy",
]


# ======================================================================
# 2. Syntax Highlighter
# ======================================================================
class PGSLHighlighter(QSyntaxHighlighter):

    def __init__(self, parent=None):
        super().__init__(parent)

        self.keyword_format = QTextCharFormat()
        self.keyword_format.setForeground(QColor("#55aaff"))
        self.keyword_format.setFontWeight(QFont.Bold)

        self.number_format = QTextCharFormat()
        self.number_format.setForeground(QColor("#ffaa55"))

        self.comment_format = QTextCharFormat()
        self.comment_format.setForeground(QColor("#666666"))
        self.comment_format.setFontItalic(True)

        self.func_call_format = QTextCharFormat()
        self.func_call_format.setForeground(QColor("#00ddff"))

        self.keywords = PGSL_COMMANDS

    def highlightBlock(self, text):

        # Function calls
        for kw in self.keywords:
            pattern = r"\b" + re.escape(kw) + r"\s*\("
            for match in re.finditer(pattern, text):
                start = match.start()
                length = match.end() - match.start()
                self.setFormat(start, length, self.func_call_format)

        # Numbers
        for match in re.finditer(r"\b\d+(\.\d+)?\b", text):
            self.setFormat(match.start(), match.end() - match.start(), self.number_format)

        # Comments
        comment_index = text.find("//")
        if comment_index >= 0:
            self.setFormat(comment_index, len(text) - comment_index, self.comment_format)


# ======================================================================
# 3. Autocomplete Popup
# ======================================================================
class AutocompletePopup(QListWidget):

    def __init__(self, editor):
        super().__init__(editor)
        self.editor = editor
        self.setWindowFlags(Qt.Popup)
        self.setFocusPolicy(Qt.NoFocus)
        self.setMouseTracking(True)
        self.setStyleSheet("""
            QListWidget {
                background: #222;
                border: 1px solid #444;
                color: white;
            }
            QListWidget::item {
                padding: 2px 6px;
            }
            QListWidget::item:selected {
                background: #444;
            }
        """)

    def show_suggestions(self, suggestions, position):
        self.clear()
        for s in suggestions:
            self.addItem(QListWidgetItem(s))
        if not suggestions:
            self.hide()
            return
        rect = self.editor.cursorRect()
        popup_pos = self.editor.mapToGlobal(rect.bottomLeft())
        self.setGeometry(popup_pos.x(), popup_pos.y(), 260, 180)
        self.show()

    def accept_current(self):
        item = self.currentItem()
        if not item:
            return
        word = item.text()
        self.editor.insert_completion(word)


# ======================================================================
# 4. PGSL Code Editor
# ======================================================================
class PGSLCodeEditor(QPlainTextEdit):

    def __init__(self):
        super().__init__()

        self.setTabStopDistance(4 * self.fontMetrics().horizontalAdvance(' '))
        self.setStyleSheet("background:#111;color:white;font-family:Consolas;font-size:12pt;")

        self.highlighter = PGSLHighlighter(self.document())

        # Autocomplete
        self.autocomplete = AutocompletePopup(self)
        self.autocomplete_timer = QTimer()
        self.autocomplete_timer.setSingleShot(True)
        self.autocomplete_timer.timeout.connect(self.update_autocomplete)

        self.setLineWrapMode(QPlainTextEdit.NoWrap)

    # ----------------------------------------------------------
    # Auto-Indent Logic
    # ----------------------------------------------------------
    def keyPressEvent(self, event):

        key = event.key()

        # Up/Down pass to autocomplete
        if self.autocomplete.isVisible():
            if key == Qt.Key_Down:
                self.autocomplete.setCurrentRow(
                    min(self.autocomplete.currentRow() + 1, self.autocomplete.count() - 1)
                )
                return
            elif key == Qt.Key_Up:
                self.autocomplete.setCurrentRow(
                    max(self.autocomplete.currentRow() - 1, 0)
                )
                return
            elif key == Qt.Key_Return:
                self.autocomplete.accept_current()
                self.autocomplete.hide()
                return

        # Auto indent
        if key == Qt.Key_Return:
            cursor = self.textCursor()
            text = cursor.block().text()

            indent = len(text) - len(text.lstrip(" "))
            new_indent = indent

            if text.strip().endswith(":"):
                new_indent += 4

            super().keyPressEvent(event)
            cursor.insertText(" " * new_indent)
            return

        # Trigger autocomplete after text changes
        super().keyPressEvent(event)

        if event.text().isalnum() or event.text() == "_":
            self.autocomplete_timer.start(120)
        else:
            self.autocomplete.hide()

    # ----------------------------------------------------------
    # Autocomplete main logic
    # ----------------------------------------------------------
    def update_autocomplete(self):
        cursor = self.textCursor()
        cursor.select(QTextCursor.WordUnderCursor)
        word = cursor.selectedText()

        if not word:
            self.autocomplete.hide()
            return

        suggestions = [cmd for cmd in PGSL_COMMANDS if cmd.lower().startswith(word.lower())]

        self.autocomplete.show_suggestions(suggestions, self.cursorRect())

    def insert_completion(self, completion: str):
        cursor = self.textCursor()
        cursor.select(QTextCursor.WordUnderCursor)
        cursor.insertText(completion)
        self.setTextCursor(cursor)
