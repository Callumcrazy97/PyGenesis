"""
Script Editor for PyGenesis
Uses UnifiedCodeEditor for code editing functionality.
"""

from PySide6.QtWidgets import QWidget, QVBoxLayout, QLabel, QMessageBox
from PySide6.QtCore import Qt, Signal
from typing import Dict, Optional

from Core.EditorInterface import EditorInterface
from Core.Code.Unified import UnifiedCodeEditor, EditorContext


class ScriptEditor(QWidget, EditorInterface):
    """
    Script Editor for .script resources.
    
    Uses UnifiedCodeEditor for all code editing functionality.
    Implements EditorInterface for consistent lifecycle management.
    """
    
    def __init__(self, app, resource_data: Dict):
        super().__init__()
        self.app = app
        self.resource_data = resource_data
        self._dirty = False
        
        # Resource info
        self.resource_id = resource_data.get("id", "")
        self.resource_name = resource_data.get("name", "Untitled Script")
        self.resource_type = "scripts"
        
        # Build UI
        self._build_ui()
        
        # Load resource
        self.open_resource(resource_data)
    
    def _build_ui(self):
        """Build the Script Editor UI"""
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        
        # Title/Header (optional - can be removed if not needed)
        header = QLabel(f"Script: {self.resource_name}")
        header.setStyleSheet("background: #2b2b3d; color: white; padding: 5px; font-weight: bold;")
        layout.addWidget(header)
        
        # Unified Code Editor
        self.code_editor = UnifiedCodeEditor(
            self.app,
            context=EditorContext.SCRIPT,
            parent=self
        )
        
        # Connect signals
        self.code_editor.code_changed.connect(self._on_code_changed)
        self.code_editor.validation_complete.connect(self._on_validation_complete)
        
        layout.addWidget(self.code_editor)
    
    def _on_code_changed(self):
        """Handle code changes"""
        self._dirty = True
    
    def _on_validation_complete(self, is_valid: bool, errors: list, warnings: list):
        """Handle validation completion"""
        # Validation results are already displayed in UnifiedCodeEditor's diagnostics panel
        pass
    
    # EditorInterface implementation
    def open_resource(self, resource_data: Dict) -> bool:
        """
        Load a script resource into the editor.
        
        Args:
            resource_data: Dictionary containing script resource data
            
        Returns:
            True if resource loaded successfully, False otherwise
        """
        try:
            self.resource_data = resource_data
            self.resource_id = resource_data.get("id", "")
            self.resource_name = resource_data.get("name", "Untitled Script")
            
            # Load script code
            script_code = resource_data.get("code", "")
            if script_code:
                self.code_editor.set_code(script_code, suppress_signals=True)
            
            self._dirty = False
            return True
            
        except Exception as e:
            QMessageBox.critical(
                self,
                "Error Loading Script",
                f"Failed to load script resource:\n{str(e)}"
            )
            return False
    
    def save_resource(self) -> bool:
        """
        Save the current script code to the resource.
        
        Returns:
            True if save successful, False otherwise
        """
        try:
            # Get code from editor
            code = self.code_editor.get_code()
            
            # Update resource data
            self.resource_data["code"] = code
            
            # Save via resource manager (this saves to disk automatically)
            if hasattr(self.app, 'resource_manager'):
                # Update the full resource data to ensure all fields are preserved
                self.resource_data["code"] = code
                success = self.app.resource_manager.save_resource(
                    self.resource_type,
                    self.resource_data
                )
                
                if success:
                    self._dirty = False
                    return True
                else:
                    QMessageBox.warning(
                        self,
                        "Save Failed",
                        "Failed to save script resource."
                    )
                    return False
            else:
                QMessageBox.warning(
                    self,
                    "Save Failed",
                    "Resource manager not available."
                )
                return False
                
        except Exception as e:
            QMessageBox.critical(
                self,
                "Error Saving Script",
                f"Failed to save script resource:\n{str(e)}"
            )
            return False
    
    def close_editor(self) -> bool:
        """
        Close the editor, prompting for unsaved changes if needed.
        
        Returns:
            True if editor can be closed, False if user cancelled
        """
        if self._dirty:
            reply = QMessageBox.question(
                self,
                "Unsaved Changes",
                "This script has unsaved changes. Do you want to save before closing?",
                QMessageBox.Save | QMessageBox.Discard | QMessageBox.Cancel,
                QMessageBox.Save
            )
            
            if reply == QMessageBox.Save:
                if not self.save_resource():
                    return False  # User cancelled save
            elif reply == QMessageBox.Cancel:
                return False  # User cancelled close
        
        return True
    
    def get_editor_widget(self) -> QWidget:
        """
        Get the main widget for this editor.
        
        Returns:
            This widget (self)
        """
        return self
    
    def is_dirty(self) -> bool:
        """
        Check if there are unsaved changes.
        
        Returns:
            True if there are unsaved changes, False otherwise
        """
        return self._dirty
    
    def get_resource_type(self) -> str:
        """
        Get the resource type this editor handles.
        
        Returns:
            "scripts"
        """
        return "scripts"
    
    def get_resource_id(self) -> Optional[str]:
        """
        Get the ID of the currently loaded resource.
        
        Returns:
            Resource ID string, or None if no resource loaded
        """
        return self.resource_id if self.resource_id else None
    
    def get_resource_name(self) -> Optional[str]:
        """
        Get the name of the currently loaded resource.
        
        Returns:
            Resource name string, or None if no resource loaded
        """
        return self.resource_name if self.resource_name else None

