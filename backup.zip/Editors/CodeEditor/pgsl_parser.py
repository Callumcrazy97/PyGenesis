"""
PGSL Parser - Converts PGSL code into executable Python.
This parser is intentionally simple and rule-based.
The goal: take PGSL v1.0 syntax and map it into valid Python 3 code.

Location:
Core/Code/PGSL/pgsl_parser.py
"""

import re

class PGSLParser:

    def __init__(self):
        # Map PGSL functions to python equivalents
        self.command_map = {
            # Runtime
            "Run": "pgsl_run",
            "Debug_Run": "pgsl_debug_run",
            "Build": "pgsl_build",
            "Validate": "pgsl_validate",
            "game_end": "pgsl_game_end",
            "game_save": "pgsl_game_save",
            "game_load": "pgsl_game_load",
            "window_set_size": "pgsl_window_set_size",
            "window_set_title": "pgsl_window_set_title",
            "game_set_speed": "pgsl_game_set_speed",
            "room_set_speed": "pgsl_room_set_speed",

            # Variables & Math
            "Variable_set": "pgsl_variable_set",
            "Variable_get": "pgsl_variable_get",
            "Variable_exists": "pgsl_variable_exists",
            "Wait": "pgsl_wait",
            "clamp": "pgsl_clamp",
            "point_direction": "pgsl_point_direction",
            "point_distance": "pgsl_point_distance",
            "random_range": "pgsl_random_range",

            # Instances
            "create_instance": "pgsl_create_instance",
            "instance_destroy": "pgsl_instance_destroy",
            "instance_find": "pgsl_instance_find",
            "instance_find_id": "pgsl_instance_find_id",
            "instance_find_nearest": "pgsl_instance_find_nearest",
            "instance_find_furthest": "pgsl_instance_find_furthest",
            "instance_exists": "pgsl_instance_exists",
            "instance_get_count": "pgsl_instance_get_count",
            "place_free": "pgsl_place_free",
            "instance_set_active": "pgsl_instance_set_active",

            # 3D Movement
            "Move3D_direction": "pgsl_move3d_direction",
            "Move3D_stop": "pgsl_move3d_stop",
            "Move3D_add_force": "pgsl_move3d_add_force",
            "Move3D_towards": "pgsl_move3d_towards",

            # Drawing
            "Draw_Self_2D": "pgsl_draw_self_2d",
            "Draw_Sprite_2D": "pgsl_draw_sprite_2d",
            "Draw_Text_2D": "pgsl_draw_text_2d",
            "Draw_Model_3D": "pgsl_draw_model_3d",
            "Draw_Model_Instanced": "pgsl_draw_model_instanced",
            "Draw_2D": "pgsl_draw_2d",
            "Draw_Self_3D": "pgsl_draw_self_3d",
            "sprite_set_alpha": "pgsl_sprite_set_alpha",
            "sprite_set_2d_size": "pgsl_sprite_set_2d_size",
            "sprite_set_color_tint": "pgsl_sprite_set_color_tint",
            "model_set_3d_scale": "pgsl_model_set_3d_scale",

            # HUD
            "Draw_HUD": "pgsl_draw_hud",
            "Draw_HUD_Text": "pgsl_draw_hud_text",
            "Draw_Bar": "pgsl_draw_bar",

            # Atlases
            "sprite_make_atlas": "pgsl_sprite_make_atlas",
            "sprite_use_atlas": "pgsl_sprite_use_atlas",
            "sprite_use_atlas_tile": "pgsl_sprite_use_atlas_tile",
            "sprite_get_width": "pgsl_sprite_get_width",
            "sprite_get_height": "pgsl_sprite_get_height",
            "sprite_get_frames": "pgsl_sprite_get_frames",

            # Camera & Viewports
            "Camera2D_set_position": "pgsl_camera2d_set_position",
            "Camera2D_follow": "pgsl_camera2d_follow",
            "Camera2D_shake": "pgsl_camera2d_shake",
            "Camera3D_set_position": "pgsl_camera3d_set_position",
            "Camera3D_set_target": "pgsl_camera3d_set_target",
            "Camera3D_follow": "pgsl_camera3d_follow",
            "Camera3D_shake": "pgsl_camera3d_shake",
            "Viewport_create": "pgsl_viewport_create",
            "Viewport_set_camera": "pgsl_viewport_set_camera",
            "Viewport_activate": "pgsl_viewport_activate",

            # Audio
            "sound_play": "pgsl_sound_play",
            "sound_stop": "pgsl_sound_stop",
            "sound_stop_all": "pgsl_sound_stop_all",
            "sound_pause_all": "pgsl_sound_pause_all",
            "sound_resume_all": "pgsl_sound_resume_all",
            "sound_is_active": "pgsl_sound_is_active",

            # Input
            "key_check": "pgsl_key_check",
            "key_pressed": "pgsl_key_pressed",
            "key_released": "pgsl_key_released",
            "mouse_position": "pgsl_mouse_position",
            "mouse_delta": "pgsl_mouse_delta",
            "Input_bind": "pgsl_input_bind",
            "Input_check": "pgsl_input_check",

            # Networking
            "net_host": "pgsl_net_host",
            "net_connect": "pgsl_net_connect",
            "net_close": "pgsl_net_close",
            "net_send_all": "pgsl_net_send_all",
            "net_send_to": "pgsl_net_send_to",
            "net_get": "pgsl_net_get",
            "net_sync_position": "pgsl_net_sync_position",
            "net_sync_rotation": "pgsl_net_sync_rotation",
            "net_sync_variable": "pgsl_net_sync_variable",
            "net_register_event": "pgsl_net_register_event",
            "net_my_id": "pgsl_net_my_id",
            "net_peers": "pgsl_net_peers",

            # Shaders
            "shader_use": "pgsl_shader_use",
            "shader_remove": "pgsl_shader_remove",
            "shader_set_uniform": "pgsl_shader_set_uniform",
            "shader_set_uniform_vec3": "pgsl_shader_set_uniform_vec3",
            "shader_set_uniform_color": "pgsl_shader_set_uniform_color",
            "shader_use_object": "pgsl_shader_use_object",
            "shader_set_uniform_object": "pgsl_shader_set_uniform_object",

            # Compute
            "compute_shader_load": "pgsl_compute_shader_load",
            "compute_set_uniform": "pgsl_compute_set_uniform",
            "compute_buffer_create": "pgsl_compute_buffer_create",
            "compute_buffer_write": "pgsl_compute_buffer_write",
            "compute_buffer_read": "pgsl_compute_buffer_read",
            "compute_shader_run": "pgsl_compute_shader_run",

            # Particles
            "particle_system_create": "pgsl_particle_system_create",
            "particle_system_emit": "pgsl_particle_system_emit",
            "particle_system_set_uniform": "pgsl_particle_system_set_uniform",
            "particle_set_color": "pgsl_particle_set_color",
            "particle_set_color_range": "pgsl_particle_set_color_range",
            "particle_set_emissive": "pgsl_particle_set_emissive",

            # Voxel
            "bake_mesh_from_map": "pgsl_bake_mesh_from_map",
            "chunk_set_active": "pgsl_chunk_set_active",
            "chunk_set_position": "pgsl_chunk_set_position",
            "chunk_destroy": "pgsl_chunk_destroy",
        }

    # ------------------------------------------------------------------
    # Parsing / Transpiling
    # ------------------------------------------------------------------
    def parse(self, pgsl_code: str) -> str:
        """
        Parse PGSL code into Python.
        """

        python_lines = []
        indent_level = 0

        for line in pgsl_code.split("\n"):

            stripped = line.strip()

            if not stripped:
                python_lines.append("")
                continue

            # Comments
            if stripped.startswith("//"):
                python_lines.append(f"# {stripped[2:].strip()}")
                continue

            # Dedent if necessary
            if stripped.startswith("}"):
                indent_level = max(0, indent_level - 1)
                continue

            # Process command calls
            line = self._convert_line(stripped)

            # Add indentation
            python_lines.append("    " * indent_level + line)

            # If ends with ':', block start
            if stripped.endswith(":"):
                indent_level += 1

        return "\n".join(python_lines)

    # ------------------------------------------------------------------
    def _convert_line(self, line: str) -> str:
        """
        Convert a single PGSL line to Python.
        """

        # Assignment
        if "=" in line and not line.startswith(("==", "!=")):
            return line

        # Replace PGSL commands
        for pgsl_cmd, py_cmd in self.command_map.items():
            pattern = r"\b" + re.escape(pgsl_cmd) + r"\b"
            if re.search(pattern, line):
                line = re.sub(pattern, py_cmd, line)

        return line
