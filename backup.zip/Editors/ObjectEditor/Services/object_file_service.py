"""
Object File Service
Handles file I/O for Object resources
"""

from pathlib import Path
from typing import Optional, Dict
import json
from Editors.ObjectEditor.Core.object_model import ObjectModel


class ObjectFileService:
    """Service for reading and writing Object files"""
    
    def __init__(self, project_path: Path):
        self.project_path = project_path
        self.objects_folder = project_path / "Resources" / "Objects"
    
    def get_object_file_path(self, object_name: str, parent_folder: str = "") -> Path:
        """Get the path to an object's .object file"""
        if parent_folder:
            folder_path = self.objects_folder / parent_folder
        else:
            folder_path = self.objects_folder
        
        folder_path.mkdir(parents=True, exist_ok=True)
        return folder_path / f"{object_name}.object"
    
    def get_event_file_path(self, object_name: str, event_id: str, parent_folder: str = "") -> Path:
        """Get the path to an event's .pgsl file"""
        if parent_folder:
            folder_path = self.objects_folder / parent_folder
        else:
            folder_path = self.objects_folder
        
        folder_path.mkdir(parents=True, exist_ok=True)
        filename = f"{object_name}_{event_id}.pgsl"
        return folder_path / filename
    
    def load_object(self, object_file_path: Path) -> Optional[ObjectModel]:
        """Load an object from a .object file"""
        try:
            if not object_file_path.exists():
                return None
            
            with open(object_file_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            
            return ObjectModel.from_dict(data)
        except Exception as e:
            from Core.Debug import debug
            debug(f"Failed to load object from {object_file_path}: {e}")
            return None
    
    def save_object(self, object_model: ObjectModel) -> bool:
        """Save an object to a .object file"""
        try:
            object_model.update_modified()
            object_file_path = self.get_object_file_path(
                object_model.name,
                object_model.parent_folder
            )
            
            object_file_path.parent.mkdir(parents=True, exist_ok=True)
            
            with open(object_file_path, 'w', encoding='utf-8') as f:
                json.dump(object_model.to_dict(), f, indent=2, ensure_ascii=False)
            
            return True
        except Exception as e:
            from Core.Debug import debug
            debug(f"Failed to save object to {object_file_path}: {e}")
            return False
    
    def load_event_code(self, event_file_path: Path) -> str:
        """Load event code from a .pgsl file"""
        try:
            if event_file_path.exists():
                return event_file_path.read_text(encoding='utf-8')
            return ""
        except Exception as e:
            from Core.Debug import debug
            debug(f"Failed to load event code from {event_file_path}: {e}")
            return ""
    
    def save_event_code(self, event_file_path: Path, code: str) -> bool:
        """Save event code to a .pgsl file"""
        try:
            event_file_path.parent.mkdir(parents=True, exist_ok=True)
            event_file_path.write_text(code, encoding='utf-8')
            return True
        except Exception as e:
            from Core.Debug import debug
            debug(f"Failed to save event code to {event_file_path}: {e}")
            return False

