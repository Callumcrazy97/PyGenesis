"""
Object Validation Service
Validates Object code and structure
"""

from typing import List, Dict, Tuple, Optional
from Core.CodeSystem.parser import PGSLParser, ParseError
from Core.CodeSystem.syntax import SyntaxValidator


class ObjectValidationService:
    """Service for validating Object code"""
    
    def __init__(self):
        self.validator = SyntaxValidator()
    
    def validate_event_code(self, code: str, event_id: str = "") -> Tuple[bool, List[Dict], List[Dict]]:
        """
        Validate event code
        
        Returns:
            (is_valid, errors, warnings)
        """
        return self.validator.validate(code)
    
    def validate_selected_code(self, code: str, start_line: int, end_line: int) -> Tuple[bool, List[Dict], List[Dict]]:
        """Validate a selection of code"""
        lines = code.split('\n')
        selected_lines = lines[start_line:end_line + 1]
        selected_code = '\n'.join(selected_lines)
        return self.validator.validate(selected_code)
    
    def validate_all_events(self, events: Dict[str, str], file_service) -> Dict[str, Tuple[bool, List[Dict], List[Dict]]]:
        """
        Validate all events for an object
        
        Args:
            events: Dict mapping event_id to .pgsl filename
            file_service: ObjectFileService instance for loading code
        
        Returns:
            Dict mapping event_id to (is_valid, errors, warnings)
        """
        results = {}
        
        for event_id, filename in events.items():
            if not filename:
                continue
            
            # Load code from file
            # Note: We need object_name and parent_folder to construct path
            # This is a limitation - we might need to pass object_model
            code = ""  # Would need object_model to load properly
            is_valid, errors, warnings = self.validator.validate(code)
            results[event_id] = (is_valid, errors, warnings)
        
        return results
    
    def parse_code(self, code: str) -> Optional[object]:
        """Parse code into AST (returns None if parse fails)"""
        try:
            parser = PGSLParser(code)
            return parser.parse()
        except ParseError:
            return None
        except Exception:
            return None

