# ======================================================================
#  object_editor_ui.py
#  Generic frameless UI container for the Object Editor.
# ======================================================================

from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QSplitter, QLabel, QFrame
)
from PySide6.QtCore import Qt


class ObjectEditorUI(QWidget):
    """
    Lightweight UI container that defines the base visual layout:
        ┌──────────────────────────────────────────────────────────┐
        │  Menu Bar (in parent)                                    │
        ├──────────────────────────────────────────────────────────┤
        │ [Left Panel] | [Middle Panel] | [Right Dockable Editor] │
        └──────────────────────────────────────────────────────────┘
    """

    def __init__(self, parent=None):
        super().__init__(parent)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)

        # ------------------------------------------------------------------
        #   Main Horizontal Splitter
        # ------------------------------------------------------------------
        self.main_splitter = QSplitter(Qt.Horizontal)
        self.main_splitter.setChildrenCollapsible(False)
        layout.addWidget(self.main_splitter)

        # ------------------------------------------------------------------
        #   Placeholders (actual widgets injected by ObjectEditor)
        # ------------------------------------------------------------------

        # Left placeholder
        self.left_placeholder = self._make_placeholder("Left Panel")
        self.main_splitter.addWidget(self.left_placeholder)

        # Middle placeholder
        self.middle_placeholder = self._make_placeholder("Event Tree")
        self.main_splitter.addWidget(self.middle_placeholder)

        # Right placeholder
        self.right_placeholder = self._make_placeholder("Code Editor")
        self.main_splitter.addWidget(self.right_placeholder)

        # Default sizes (approx)
        self.main_splitter.setSizes([280, 240, 700])

    # ----------------------------------------------------------------------
    # Utilities
    # ----------------------------------------------------------------------

    def _make_placeholder(self, text: str) -> QWidget:
        """Creates a labelled placeholder frame."""
        frame = QFrame()
        frame.setFrameShape(QFrame.StyledPanel)

        layout = QHBoxLayout(frame)
        layout.setAlignment(Qt.AlignCenter)

        label = QLabel(text)
        label.setStyleSheet("color: #888; font-size: 12px;")
        layout.addWidget(label)

        return frame
