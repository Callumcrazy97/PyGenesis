"""
Object Editor Menu Bar
Menu bar for the Object Editor with File and Validation commands.
"""

from PySide6.QtWidgets import QMenuBar, QMenu
from PySide6.QtGui import QAction, QKeySequence
from PySide6.QtCore import Qt


class ObjectEditorMenu(QMenuBar):
    """
    Menu bar for Object Editor.
    Provides File operations and Validation commands.
    """
    
    def __init__(self, parent=None):
        super().__init__(parent)
        # Make menu bar thin
        self.setMaximumHeight(25)
        self.setMinimumHeight(25)
        self._create_menus()
    
    def _create_menus(self):
        """Create all menus and actions"""
        
        # File Menu
        file_menu = self.addMenu("File")
        
        self.action_save = QAction("Save", self)
        self.action_save.setShortcut(QKeySequence.StandardKey.Save)
        self.action_save.setStatusTip("Save the object")
        file_menu.addAction(self.action_save)
        
        self.action_save_as = QAction("Save As...", self)
        self.action_save_as.setShortcut(QKeySequence.StandardKey.SaveAs)
        self.action_save_as.setStatusTip("Save the object with a new name")
        file_menu.addAction(self.action_save_as)
        
        file_menu.addSeparator()
        
        # Validation Menu
        validation_menu = self.addMenu("Validation")
        
        self.action_validate_event = QAction("Validate Event", self)
        self.action_validate_event.setStatusTip("Validate the current event code")
        validation_menu.addAction(self.action_validate_event)
        
        self.action_validate_object = QAction("Validate Object", self)
        self.action_validate_object.setStatusTip("Validate all events in the object")
        validation_menu.addAction(self.action_validate_object)
        
        self.action_validate_highlighted = QAction("Validate Highlighted", self)
        self.action_validate_highlighted.setStatusTip("Validate only the selected code")
        validation_menu.addAction(self.action_validate_highlighted)
        
        # View Menu
        view_menu = self.addMenu("View")
        
        self.action_fullscreen = QAction("Fullscreen", self)
        self.action_fullscreen.setShortcut(QKeySequence("F11"))
        self.action_fullscreen.setStatusTip("Toggle fullscreen code editor mode")
        view_menu.addAction(self.action_fullscreen)
        
        self.action_restore = QAction("Restore", self)
        self.action_restore.setShortcut(QKeySequence("F11"))
        self.action_restore.setStatusTip("Restore normal view")
        self.action_restore.setVisible(False)  # Hidden initially
        view_menu.addAction(self.action_restore)

