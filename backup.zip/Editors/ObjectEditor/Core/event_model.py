"""
Event Model
Data model for Object events
"""

from typing import Optional
from dataclasses import dataclass


@dataclass
class EventModel:
    """Data model for an Object event"""
    
    event_id: str
    event_label: str
    category: str
    code_file: str  # .pgsl filename
    code: Optional[str] = None  # In-memory code (loaded from file)
    
    def __repr__(self):
        return f"EventModel(id={self.event_id}, label={self.event_label}, category={self.category})"

