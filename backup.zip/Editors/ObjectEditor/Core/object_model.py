"""
Object Model
Data model for Object resources
"""

from typing import Dict, Optional, List
from dataclasses import dataclass, field
from datetime import datetime


@dataclass
class ObjectModel:
    """Data model for an Object resource"""
    
    id: str
    name: str
    type: str = "objects"
    parent_folder: str = ""
    created: str = ""
    modified: str = ""
    
    # Object properties
    sprite: str = ""  # Sprite name (not ID)
    sprite_id: Optional[str] = None  # Sprite ID for internal use
    solid: bool = False
    persistent: bool = False
    depth: int = 0
    parent: str = ""  # Parent object name
    
    # Events - dict mapping event_id to .pgsl filename
    events: Dict[str, str] = field(default_factory=dict)
    
    def to_dict(self) -> Dict:
        """Convert model to dictionary for JSON serialization"""
        return {
            "id": self.id,
            "name": self.name,
            "type": self.type,
            "parent_folder": self.parent_folder,
            "created": self.created or datetime.now().isoformat(),
            "modified": self.modified or datetime.now().isoformat(),
            "sprite": self.sprite,
            "solid": self.solid,
            "persistent": self.persistent,
            "depth": self.depth,
            "parent": self.parent,
            "events": self.events
        }
    
    @classmethod
    def from_dict(cls, data: Dict) -> 'ObjectModel':
        """Create model from dictionary"""
        return cls(
            id=data.get("id", ""),
            name=data.get("name", ""),
            type=data.get("type", "objects"),
            parent_folder=data.get("parent_folder", ""),
            created=data.get("created", ""),
            modified=data.get("modified", ""),
            sprite=data.get("sprite", ""),
            solid=data.get("solid", False),
            persistent=data.get("persistent", False),
            depth=data.get("depth", 0),
            parent=data.get("parent", ""),
            events=data.get("events", {})
        )
    
    def update_modified(self):
        """Update the modified timestamp"""
        self.modified = datetime.now().isoformat()

