# ======================================================================
#  object_events_panel.py
#  Middle panel for the Object Editor.
#
#  Responsibilities:
#    - Display added events grouped by category.
#    - Allow user to add new events via a dialog.
#    - Allow selection of an event to load its code.
#    - Emit clean Qt signals for the controller.
#
#  NOTE:
#    This panel NEVER stores the event code itself. It only displays
#    event metadata and emits signals.
# ======================================================================

from __future__ import annotations

from typing import Dict, List, Optional

from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QColor, QFont
from PySide6.QtWidgets import (
    QWidget,
    QVBoxLayout,
    QHBoxLayout,
    QTreeWidget,
    QTreeWidgetItem,
    QGroupBox,
    QPushButton,
    QLabel,
    QListWidget,
    QListWidgetItem,
    QDialog,
)


# ----------------------------------------------------------------------
# Standardized Event Definitions
# ----------------------------------------------------------------------
DEFAULT_EVENT_CATEGORIES = [
    {
        "name": "Create",
        "events": [
            {"id": "create", "label": "Create"},
            {"id": "room_start", "label": "Room Start"},
            {"id": "game_start", "label": "Game Start"},
        ],
    },
    {
        "name": "Step",
        "events": [
            {"id": "start_step", "label": "Start Step"},
            {"id": "step", "label": "Step"},
            {"id": "end_step", "label": "End Step"},
        ],
    },
    {
        "name": "Draw",
        "events": [
            {"id": "draw", "label": "Draw"},
            {"id": "draw_begin", "label": "Draw Begin"},
            {"id": "draw_end", "label": "Draw End"},
        ],
    },
    {
        "name": "Alarm",
        "events": [
            {"id": f"alarm_{i}", "label": f"Alarm {i}"} for i in range(10)
        ],
    },
    {
        "name": "User Defined",
        "events": [
            {"id": f"user_event_{i}", "label": f"User Event {i}"} for i in range(10)
        ],
    },
    {
        "name": "End",
        "events": [
            {"id": "room_end", "label": "Room End"},
            {"id": "game_end", "label": "Game End"},
            {"id": "destroy", "label": "Destroy"},
        ],
    },
]


class ObjectEventsPanel(QWidget):
    """
    Middle panel for displaying & managing events in the object.
    
    Layout:
      [ Events Group ]
        - Tree of event categories + events actually added
        - "Add Event..." button at bottom
    """

    # ------------------------------------------------------------------
    # Signals
    # ------------------------------------------------------------------
    eventSelected = Signal(str)        # event_id
    eventAdded = Signal(str)           # event_id
    eventRequested = Signal(str)       # double-click or explicit selection

    def __init__(
        self,
        parent: Optional[QWidget] = None,
        event_categories: Optional[List[Dict]] = None,
    ):
        super().__init__(parent)

        self.event_categories = event_categories or DEFAULT_EVENT_CATEGORIES

        # Currently selected event id
        self.current_event_id: Optional[str] = None

        self._build_ui()

    # ------------------------------------------------------------------
    # UI Construction
    # ------------------------------------------------------------------

    def _build_ui(self) -> None:
        layout = QVBoxLayout(self)
        layout.setContentsMargins(6, 6, 6, 6)
        layout.setSpacing(6)

        group = QGroupBox("Events")
        g_layout = QVBoxLayout(group)
        g_layout.setContentsMargins(6, 6, 6, 6)
        g_layout.setSpacing(6)

        # Tree of events
        self.tree = QTreeWidget()
        self.tree.setHeaderHidden(True)
        self.tree.itemClicked.connect(self._on_tree_item_clicked)
        g_layout.addWidget(self.tree)

        layout.addWidget(group)

        # "Add Event" button
        self.add_button = QPushButton("Add Event…")
        self.add_button.clicked.connect(self._show_add_event_dialog)
        layout.addWidget(self.add_button)

        layout.addStretch()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def set_events(self, event_dict: Dict[str, str]) -> None:
        """
        Populate the tree with events already present in the object.
        
        event_dict: { event_id: code_string }
        """
        self.tree.clear()

        # Group events by category
        events_by_cat = {}
        for cat in self.event_categories:
            cat_name = cat["name"]
            events_by_cat[cat_name] = []

            for ev in cat["events"]:
                ev_id = ev["id"]
                if ev_id in event_dict:
                    events_by_cat[cat_name].append(ev)

        # Populate tree
        for cat in self.event_categories:
            cat_name = cat["name"]
            cat_events = events_by_cat.get(cat_name, [])
            if not cat_events:
                continue

            cat_item = QTreeWidgetItem(self.tree, [cat_name])
            cat_item.setFlags(cat_item.flags() & ~Qt.ItemIsSelectable)
            cat_item.setExpanded(True)

            for ev in cat_events:
                item = QTreeWidgetItem(cat_item, [ev["label"]])
                item.setData(0, Qt.UserRole, ev["id"])

        self.tree.expandAll()

    def select_event(self, event_id: str) -> None:
        """Highlight a specific event in the tree programmatically."""
        self.current_event_id = event_id
        root_count = self.tree.topLevelItemCount()

        for i in range(root_count):
            cat_item = self.tree.topLevelItem(i)
            for j in range(cat_item.childCount()):
                ev_item = cat_item.child(j)
                if ev_item.data(0, Qt.UserRole) == event_id:
                    self.tree.setCurrentItem(ev_item)
                    self._highlight_selected(ev_item)
                    return

    # ------------------------------------------------------------------
    # Dialog for adding events
    # ------------------------------------------------------------------

    def _show_add_event_dialog(self) -> None:
        dialog = QDialog(self)
        dialog.setWindowTitle("Add Event")
        dialog.setMinimumSize(300, 450)

        layout = QVBoxLayout(dialog)
        layout.setSpacing(6)

        label = QLabel("Select an event to add:")
        layout.addWidget(label)

        list_widget = QListWidget()
        layout.addWidget(list_widget)

        # Add categories + events
        for cat in self.event_categories:
            # Category header (not selectable)
            cat_item = QListWidgetItem(cat["name"])
            f = cat_item.font()
            f.setBold(True)
            cat_item.setFont(f)
            cat_item.setFlags(Qt.NoItemFlags)
            list_widget.addItem(cat_item)

            # Events
            for ev in cat["events"]:
                ev_label = f"  {ev['label']}"
                ev_item = QListWidgetItem(ev_label)
                ev_item.setData(Qt.UserRole, ev["id"])
                list_widget.addItem(ev_item)

        # Buttons
        btn_row = QHBoxLayout()
        add_btn = QPushButton("Add")
        cancel_btn = QPushButton("Cancel")

        add_btn.clicked.connect(dialog.accept)
        cancel_btn.clicked.connect(dialog.reject)

        btn_row.addWidget(add_btn)
        btn_row.addWidget(cancel_btn)
        layout.addLayout(btn_row)

        if dialog.exec() == QDialog.Accepted:
            item = list_widget.currentItem()
            if item:
                event_id = item.data(Qt.UserRole)
                if event_id:
                    self.eventAdded.emit(event_id)

    # ------------------------------------------------------------------
    # Event Handlers
    # ------------------------------------------------------------------

    def _on_tree_item_clicked(self, item: QTreeWidgetItem, col: int) -> None:
        event_id = item.data(0, Qt.UserRole)
        if not event_id:
            return  # Category clicked

        self.current_event_id = event_id
        self._highlight_selected(item)
        self.eventSelected.emit(event_id)

    def _highlight_selected(self, item: QTreeWidgetItem) -> None:
        """Visual highlight of selected event."""
        # Reset all backgrounds
        root_count = self.tree.topLevelItemCount()
        for i in range(root_count):
            cat_item = self.tree.topLevelItem(i)
            cat_item.setBackground(0, QColor())
            for j in range(cat_item.childCount()):
                ev_item = cat_item.child(j)
                ev_item.setBackground(0, QColor())

        # Highlight selected
        item.setBackground(0, QColor(50, 80, 150))
