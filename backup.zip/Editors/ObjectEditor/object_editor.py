# ======================================================================
#  Object Editor (Main Controller)
#  object_editor.py
#  This file orchestrates all UI modules for the Object Editor.
# ======================================================================

from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QSplitter, QMessageBox, 
    QTabBar, QHBoxLayout, QFrame, QMainWindow, QStackedWidget
)
from PySide6.QtCore import Qt, Signal, QObject
from PySide6.QtGui import QPixmap

from Core.EditorInterface import EditorInterface
# Import UI components
from .UI.properties_panel import ObjectPropertiesPanel
from .UI.events_panel import ObjectEventsPanel
from .UI.code_editor_widget import CodeEditorDock
from .UI.object_editor_menu import ObjectEditorMenu

from pathlib import Path
import json


class ObjectEditor(QWidget, EditorInterface):
    """
    Main Object Editor Controller.
    Connects:
        - Properties panel
        - Event tree
        - Code editor
        - Menu bar commands
    Handles:
        - Load / Save object
        - Switching events
        - Validation
    """

    # Signals (optional for external use)
    saved = Signal()
    closed = Signal()
    # Signal: emitted when sprite is changed
    sprite_changed = Signal(str, str)  # (object_name, sprite_name)
    
    def __init__(self, app, resource_data):
        super().__init__()
        self.app = app

        # Ensure valid dict structure
        self.resource_data = (
            resource_data if isinstance(resource_data, dict)
            else self._create_default_resource(resource_data)
        )

        self.current_event_id = None
        self._dirty = False
        
        # Ensure events dict exists
        if "events" not in self.resource_data:
            self.resource_data["events"] = {}

        self._build_ui()
        self._load_object_into_panels()

        # Cache for the sprite preview widget
        self._sprite_preview_widget = None

    # ------------------------------------------------------------------
    #  UI Setup
    # ------------------------------------------------------------------

    def _build_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(2, 2, 2, 2)

        # Top Menu Bar (thin)
        self.menu_bar = ObjectEditorMenu(self)
        layout.addWidget(self.menu_bar, 0)  # No stretch
        
        # Event tabs bar (for fullscreen mode) - initially hidden
        self.event_tabs_frame = QFrame(self)
        self.event_tabs_frame.setVisible(False)
        self.event_tabs_frame.setMaximumHeight(30)
        tabs_layout = QHBoxLayout(self.event_tabs_frame)
        tabs_layout.setContentsMargins(4, 2, 4, 2)
        tabs_layout.setSpacing(2)
        
        self.event_tabs = QTabBar(self.event_tabs_frame)
        self.event_tabs.setExpanding(False)
        self.event_tabs.setTabsClosable(False)
        self.event_tabs.currentChanged.connect(self._on_tab_changed)
        tabs_layout.addWidget(self.event_tabs)
        tabs_layout.addStretch()
        
        layout.addWidget(self.event_tabs_frame, 0)  # No stretch

        # Main Splitter
        self.main_splitter = QSplitter(Qt.Horizontal)
        layout.addWidget(self.main_splitter)

        # --------------------------------------------------------------
        # Left Panel (Properties)
        # --------------------------------------------------------------
        self.properties_panel = ObjectPropertiesPanel(self)
        self.main_splitter.addWidget(self.properties_panel)

        # --------------------------------------------------------------
        # Middle Panel (Event Tree)
        # --------------------------------------------------------------
        self.events_panel = ObjectEventsPanel(self, app=self.app)
        self.main_splitter.addWidget(self.events_panel)

        # --------------------------------------------------------------
        # Right Panel (Dockable Code Editor)
        # --------------------------------------------------------------
        self.code_editor = CodeEditorDock(self, self.app)
        self.main_splitter.addWidget(self.code_editor)

        # Split sizing
        self.main_splitter.setSizes([200, 180, 800])
        
        # Fullscreen state
        self._is_fullscreen = False
        self._fullscreen_window = None
        self._fullscreen_tabs = None

        # --------------------------------------------------------------
        # Connect Signals
        # --------------------------------------------------------------
        self._connect_menu_actions()
        self._connect_panel_signals()
        self._connect_sprite_signals()

    # ------------------------------------------------------------------
    #  Loading / Saving
    # ------------------------------------------------------------------

    def _load_object_into_panels(self):
        """Push object data into UI panels."""
        # Load properties
        name = self.resource_data.get("name", "")
        solid = self.resource_data.get("solid", False)
        depth = self.resource_data.get("depth", 0)
        persistent = self.resource_data.get("persistent", False)
        parent = self.resource_data.get("parent", "")
        sprite = self.resource_data.get("sprite", "")
        
        # Get sprite ID - check both ID and name fields
        sprite_id = None
        if hasattr(self.app, 'project_manager'):
            runtime_resources = self.app.project_manager.runtime_resources
            sprites = runtime_resources.get("sprites", {})
            
            # First, check if sprite field is already an ID
            if sprite:
                if sprite in sprites:
                    sprite_id = sprite  # It's already an ID
                else:
                    # Try to find by name
                    for sid, sdata in sprites.items():
                        if sdata.get("name") == sprite:
                            sprite_id = sid
                            break
        
        # If sprite name exists but sprite_id not found, log a warning
        if sprite and not sprite_id:
            from Core.Debug import debug
            debug(f"Warning: Sprite '{sprite}' not found in runtime resources for object '{name}'")
        
        # Pass sprite_id to panel (it will handle None and try to find by name)
        self.properties_panel.set_object_data(name, solid, depth, persistent, parent, sprite_id)
        
        # If we have a sprite name but no sprite_id, try to set it by name as a fallback
        if sprite and not sprite_id:
            # The panel's _set_sprite will handle the lookup by name
            self.properties_panel._set_sprite(None, sprite)
        
        # Load events
        events = self.resource_data.get("events", {})
        self.events_panel.set_events(events)
        
        # Load parent list
        self._populate_parent_list()
        
        # Load children list
        self._populate_children_list()
        
        self.code_editor.clear_editor()

        # If first event exists, load it
        if events:
            first_event = next(iter(events.keys()))
            self._switch_to_event(first_event)

        # Load sprite into preview box
        # Note: Sprite preview is handled by properties_panel, not ObjectEditor
        # These methods are stubs for compatibility
        self._setup_sprite_preview_widget()
        self._update_sprite_preview()

    def save_object(self, save_as=False):
        """Save object using project resource manager."""
        self._save_current_event_code()
        
        # Save properties from panel
        name = self.properties_panel.name_edit.text()
        solid = self.properties_panel.solid_checkbox.isChecked()
        depth = self.properties_panel.depth_spin.value()
        persistent = self.properties_panel.persistent_checkbox.isChecked()
        parent = self.properties_panel.parent_combo.currentText()
        sprite_id = self.properties_panel.current_sprite_id
        
        self.resource_data["name"] = name
        self.resource_data["solid"] = solid
        self.resource_data["depth"] = depth
        self.resource_data["persistent"] = persistent
        self.resource_data["parent"] = parent if parent != "(none)" else ""
        
        # Get sprite name from ID
        if sprite_id and hasattr(self.app, 'project_manager'):
            runtime_resources = self.app.project_manager.runtime_resources
            sprites = runtime_resources.get("sprites", {})
            sprite_data = sprites.get(sprite_id)
            if sprite_data:
                self.resource_data["sprite"] = sprite_data.get("name", "")
            else:
                self.resource_data["sprite"] = ""
        else:
            self.resource_data["sprite"] = ""

        rm = self.app.resource_manager

        success = rm.save_resource(
            "objects",
            self.resource_data,
            None if not save_as else "ask"
        )

        if success:
            self._dirty = False
            self.saved.emit()
        return success
    
    def save_resource(self):
        """Save the object (EditorInterface method - no parameters)"""
        return self.save_object(save_as=False)

    # ------------------------------------------------------------------
    #  Event Handling
    # ------------------------------------------------------------------

    def _switch_to_event(self, event_id):
        """Load event code into the editor from .pgsl file."""
        self._save_current_event_code()

        self.current_event_id = event_id
        
        # Load code from .pgsl file
        code = ""
        event_ref = self.resource_data.get("events", {}).get(event_id, "")
        
        if event_ref:
            # event_ref is now a filename (e.g., "Object2_Create.pgsl")
            if event_ref.endswith(".pgsl"):
                # New format: filename reference
                pgsl_file_path = self._get_event_pgsl_file_path(event_id)
                # Override filename if event_ref is different (for renamed objects)
                if event_ref != pgsl_file_path.name:
                    pgsl_file_path = pgsl_file_path.parent / event_ref
                
                if pgsl_file_path.exists():
                    try:
                        code = pgsl_file_path.read_text(encoding='utf-8')
                    except Exception as e:
                        from Core.Debug import debug
                        debug(f"Failed to load event code from {pgsl_file_path}: {e}")
                else:
                    # File doesn't exist yet - create empty file
                    try:
                        pgsl_file_path.parent.mkdir(parents=True, exist_ok=True)
                        pgsl_file_path.write_text("", encoding='utf-8')
                        code = ""
                    except Exception as e:
                        from Core.Debug import debug
                        debug(f"Failed to create event file {pgsl_file_path}: {e}")
            else:
                # Legacy format: inline code (migrate to .pgsl file)
                code = event_ref
                # Migrate: save to .pgsl file and update reference
                pgsl_file_path = self._get_event_pgsl_file_path(event_id)
                try:
                    pgsl_file_path.parent.mkdir(parents=True, exist_ok=True)
                    pgsl_file_path.write_text(code, encoding='utf-8')
                    # Update reference to filename
                    self.resource_data["events"][event_id] = pgsl_file_path.name
                    self._dirty = True
                except Exception as e:
                    from Core.Debug import debug
                    debug(f"Failed to migrate event code to {pgsl_file_path}: {e}")
        
        # Suppress signals when loading code to prevent recursion
        self.code_editor.set_code(code, suppress_signals=True)

        # Get event label for header
        event_label = self._get_event_label(event_id)
        self.code_editor.set_event_context(event_id, event_label)

        # Tell events panel to highlight correct node
        self.events_panel.select_event(event_id)
        
        # Update tab selection if in fullscreen (don't rebuild tabs, just select)
        if hasattr(self, '_is_fullscreen') and self._is_fullscreen:
            # Update regular event tabs (if they exist)
            if hasattr(self, 'event_tabs') and self.event_tabs:
                events = self.resource_data.get("events", {})
                event_list = list(events.keys())
                if event_id in event_list:
                    tab_index = event_list.index(event_id)
                    # Only update if index is valid and different
                    if 0 <= tab_index < self.event_tabs.count():
                        current_tab = self.event_tabs.currentIndex()
                        if current_tab != tab_index:
                            self.event_tabs.blockSignals(True)
                            self.event_tabs.setCurrentIndex(tab_index)
                            self.event_tabs.blockSignals(False)
            
            # Update fullscreen tabs (if they exist)
            if hasattr(self, '_fullscreen_tabs') and self._fullscreen_tabs:
                events = self.resource_data.get("events", {})
                event_list = list(events.keys())
                if event_id in event_list:
                    tab_index = event_list.index(event_id)
                    # Only update if index is valid and different
                    if 0 <= tab_index < self._fullscreen_tabs.count():
                        current_tab = self._fullscreen_tabs.currentIndex()
                        if current_tab != tab_index:
                            self._fullscreen_tabs.blockSignals(True)
                            self._fullscreen_tabs.setCurrentIndex(tab_index)
                            self._fullscreen_tabs.blockSignals(False)

    def add_or_open_event(self, event_id):
        """Add event if missing, then open it."""
        # Ensure events dict exists
        if "events" not in self.resource_data:
            self.resource_data["events"] = {}
        
        if event_id not in self.resource_data["events"]:
            # Create .pgsl file reference (filename only)
            pgsl_file_path = self._get_event_pgsl_file_path(event_id)
            # Create empty .pgsl file
            try:
                pgsl_file_path.parent.mkdir(parents=True, exist_ok=True)
                pgsl_file_path.write_text("", encoding='utf-8')
                # Store filename reference in object file
                self.resource_data["events"][event_id] = pgsl_file_path.name
            except Exception as e:
                from Core.Debug import debug
                debug(f"Failed to create event file {pgsl_file_path}: {e}")
                # Fallback: use empty string (will be migrated on next save)
                self.resource_data["events"][event_id] = ""
            self._dirty = True

        # Refresh events panel
        events = self.resource_data.get("events", {})
        self.events_panel.set_events(events)
        
        # Update tabs if in fullscreen (rebuild tabs when event is added)
        if hasattr(self, '_is_fullscreen') and self._is_fullscreen:
            if hasattr(self, '_fullscreen_tabs') and self._fullscreen_tabs:
                self._update_fullscreen_tabs()
            else:
                self._update_event_tabs()
        
        self._switch_to_event(event_id)

    def _get_event_pgsl_file_path(self, event_id: str) -> Path:
        """Get the file path for an event's .pgsl file"""
        object_name = self.resource_data.get("name", "Object")
        # Format: ObjectName_Event.pgsl (e.g., "Object2_Create.pgsl")
        event_label = self._get_event_label(event_id)
        # Use event_id for filename (more reliable than label)
        filename = f"{object_name}_{event_id}.pgsl"
        
        project_path = Path(self.app.project_manager.get_project_path())
        parent_folder = self.resource_data.get("parent_folder", "")
        
        if parent_folder:
            objects_folder = project_path / "Resources" / "Objects" / parent_folder
        else:
            objects_folder = project_path / "Resources" / "Objects"
        
        objects_folder.mkdir(parents=True, exist_ok=True)
        return objects_folder / filename
    
    def _save_current_event_code(self):
        """Save code from editor to .pgsl file and update object file reference."""
        if not self.current_event_id:
            return

        code = self.code_editor.get_code()
        
        # Save code to .pgsl file
        pgsl_file_path = self._get_event_pgsl_file_path(self.current_event_id)
        try:
            pgsl_file_path.parent.mkdir(parents=True, exist_ok=True)
            pgsl_file_path.write_text(code, encoding='utf-8')
        except Exception as e:
            from Core.Debug import debug_critical
            debug_critical(f"Failed to save event code to {pgsl_file_path}: {e}")
            return
        
        # Update object file to reference the .pgsl file (just filename, not full path)
        pgsl_filename = pgsl_file_path.name
        if "events" not in self.resource_data:
            self.resource_data["events"] = {}
        self.resource_data["events"][self.current_event_id] = pgsl_filename
        self._dirty = True

    # ------------------------------------------------------------------
    #  Validation
    # ------------------------------------------------------------------

    def validate_event(self):
        """Validate only the current event."""
        if not self.current_event_id:
            QMessageBox.information(self, "No Event", "Select an event to validate.")
            return

        self._save_current_event_code()
        
        # Get code from editor (already loaded from .pgsl file)
        code = self.code_editor.get_code()

        if not code.strip():
            QMessageBox.information(self, "Empty", "Event contains no code.")
            return

        # Use code editor's validator
        result = self.code_editor._validate_code_string(code)

        if result["passed"]:
            QMessageBox.information(self, "OK", "Event validated successfully.")
        else:
            QMessageBox.warning(
                self, "Errors",
                f"Event has {len(result['errors'])} errors.\nSee terminal."
            )

    def validate_object(self):
        """Run validation on every event."""
        self._save_current_event_code()

        events = self.resource_data.get("events", {})
        if not events:
            QMessageBox.information(self, "No Events", "Object contains no events.")
            return

        # Load all event codes from .pgsl files for validation
        event_codes = {}
        for event_id, event_ref in events.items():
            if event_ref.endswith(".pgsl"):
                # Load from .pgsl file
                pgsl_file_path = self._get_event_pgsl_file_path(event_id)
                if event_ref != pgsl_file_path.name:
                    pgsl_file_path = pgsl_file_path.parent / event_ref
                
                if pgsl_file_path.exists():
                    try:
                        code = pgsl_file_path.read_text(encoding='utf-8')
                        event_codes[event_id] = code
                    except Exception as e:
                        from Core.Debug import debug
                        debug(f"Failed to load event code from {pgsl_file_path}: {e}")
                        event_codes[event_id] = ""
                else:
                    event_codes[event_id] = ""
            else:
                # Legacy format: inline code
                event_codes[event_id] = event_ref

        # Use code editor's multi-block validation
        self.code_editor.check_multiple_code_blocks(event_codes, "Object")

        # Validation handled by check_multiple_code_blocks

    # ------------------------------------------------------------------
    #  Menu Action Wiring
    # ------------------------------------------------------------------

    def _connect_menu_actions(self):
        m = self.menu_bar

        m.action_save.triggered.connect(lambda: self.save_object(save_as=False))
        m.action_save_as.triggered.connect(lambda: self.save_object(save_as=True))

        m.action_validate_event.triggered.connect(self.validate_event)
        m.action_validate_object.triggered.connect(self.validate_object)
        m.action_validate_highlighted.triggered.connect(
            self.code_editor.validate_highlighted
        )
        
        # View menu
        m.action_fullscreen.triggered.connect(self._toggle_fullscreen)
        m.action_restore.triggered.connect(self._toggle_fullscreen)
        
        # Connect code editor Maximize/Dock signals
        self.code_editor.maximizeRequested.connect(self._on_code_editor_maximize)
        self.code_editor.dockRequested.connect(self._on_code_editor_dock)

    def _connect_panel_signals(self):
        """Connect UI components to controller."""
        p = self.properties_panel
        e = self.events_panel

        p.nameChanged.connect(self._on_name_changed)
        p.nameEnterPressed.connect(self._on_name_enter_pressed)
        p.solidChanged.connect(self._on_property_changed)
        p.depthChanged.connect(self._on_property_changed)
        p.persistentChanged.connect(self._on_property_changed)
        p.parentChanged.connect(self._on_property_changed)
        p.spriteChanged.connect(self._on_sprite_changed)
        p.eventsButtonClicked.connect(self._on_events_button_clicked)
        p.testCodeRequested.connect(self.validate_object)
        p.childSelected.connect(self._on_child_selected)

        e.eventSelected.connect(self._switch_to_event)
        e.eventAdded.connect(self.add_or_open_event)

        self.code_editor.code_changed.connect(self._on_code_edited)

    def _connect_sprite_signals(self):
        """
        Connect sprite selection/change signals from the properties panel to editor handlers.
        Defensive: try several common signal names and handlers, do nothing if none are present.
        """
        try:
            if not hasattr(self, "properties_panel") or self.properties_panel is None:
                return
            p = self.properties_panel

            # Common signal names to attempt (new and legacy)
            # Prefer connecting to the panel's explicit signal if available.
            try:
                if hasattr(p, "spriteChanged"):
                    p.spriteChanged.connect(self._on_sprite_changed)
                    return
            except Exception:
                pass

            try:
                if hasattr(p, "sprite_selected"):
                    # Some panels emit sprite_selected(sprite_name)
                    p.sprite_selected.connect(self._on_sprite_changed_from_panel)
                    return
            except Exception:
                pass

            try:
                if hasattr(p, "sprite_selected_signal"):
                    p.sprite_selected_signal.connect(self._on_sprite_changed_from_panel)
                    return
            except Exception:
                pass

            # As a last fallback, try a generic change signal that some panels expose
            try:
                if hasattr(p, "changed"):
                    p.changed.connect(lambda: self._update_sprite_preview())
            except Exception:
                pass
        except Exception:
            # Don't let connection failures block UI creation
            pass

    # ------------------------------------------------------------------
    #  Signals Handlers
    # ------------------------------------------------------------------

    def _on_name_changed(self, name: str):
        self.resource_data["name"] = name
        self._dirty = True
    
    def _on_name_enter_pressed(self, name: str):
        """Handle Enter key press on name field - rename if different"""
        original_name = self.resource_data.get("name", "")
        if name != original_name and name.strip():
            # Save the object with new name
            self.save_object()
            # Update resource tree
            if hasattr(self.app, 'main_window') and hasattr(self.app.main_window, 'resource_tree'):
                self.app.main_window.resource_tree.update_single_resource("objects", self.resource_data)
    
    def _on_property_changed(self):
        self._dirty = True

    def _on_sprite_changed(self, sprite_name):
        """Compatibility wrapper: called by panels (spriteChanged)."""
        # Prefer the explicit panel handler if present
        try:
            if hasattr(self, "_on_sprite_changed_from_panel"):
                return self._on_sprite_changed_from_panel(sprite_name)
        except Exception:
            pass
        # Fallback: mimic previous behaviour
        try:
            self.resource_data["sprite"] = sprite_name if sprite_name else ""
            self._update_sprite_preview()
            try:
                object_name = self.resource_data.get("name", "")
                self.sprite_changed.emit(object_name, sprite_name)
            except Exception:
                pass
            self._dirty = True
        except Exception:
            pass

    def _on_events_button_clicked(self):
        """Focus or open the events panel (safe no-op if panel missing)."""
        try:
            if hasattr(self, "events_panel") and self.events_panel is not None:
                try:
                    # Try to bring the panel to front / focus
                    if hasattr(self.events_panel, "show"):
                        self.events_panel.show()
                    self.events_panel.setFocus()
                except Exception:
                    pass
            else:
                # Fallback: notify user
                try:
                    QMessageBox.information(self, "Events", "Events panel is not available.")
                except Exception:
                    pass
        except Exception:
            pass

    def _on_child_selected(self, child_name):
        """
        Handle child selection from properties panel.
        Attempt to select it in ResourceTree or open its editor.
        """
        try:
            if not child_name:
                return

            # Try ResourceTree select API
            try:
                mw = getattr(self.app, "main_window", None)
                if mw and hasattr(mw, "resource_tree"):
                    rt = mw.resource_tree
                    # Preferred API
                    if hasattr(rt, "select_resource"):
                        try:
                            rt.select_resource("objects", child_name)
                            return
                        except Exception:
                            pass

                    # Fallback: search tree and set current item
                    root = rt.invisibleRootItem()
                    def recurse_find(parent):
                        for i in range(parent.childCount()):
                            it = parent.child(i)
                            try:
                                data = it.data(0, Qt.UserRole)
                                if isinstance(data, dict) and data.get("type") in ("object", "objects") and data.get("name") == child_name:
                                    rt.setCurrentItem(it)
                                    return True
                            except Exception:
                                pass
                            if recurse_find(it):
                                return True
                        return False
                    recurse_find(root)
                    return
            except Exception:
                pass

            # As a last resort, try to open the resource directly using main window helpers
            try:
                mw = getattr(self.app, "main_window", None)
                if mw and hasattr(mw, "open_resource"):
                    try:
                        mw.open_resource("objects", child_name)
                        return
                    except Exception:
                        pass
            except Exception:
                pass
        except Exception:
            pass

    def _on_code_edited(self):
        """Mark editor dirty when code changes and enable save UI if available."""
        try:
            self._dirty = True
            # If the menu bar exposes a helper to enable save UI, try it
            try:
                if hasattr(self, "menu_bar") and hasattr(self.menu_bar, "set_save_enabled"):
                    self.menu_bar.set_save_enabled(True)
            except Exception:
                pass
        except Exception:
            pass

    # ------------------------------------------------------------------
    #  Closing
    # ------------------------------------------------------------------

    def closeEvent(self, event):
        """Intercept closing to warn about unsaved edits."""
        if self._dirty:
            reply = QMessageBox.question(
                self,
                "Unsaved Changes",
                "You have unsaved changes. Save before closing?",
                QMessageBox.Save | QMessageBox.Discard | QMessageBox.Cancel
            )

            if reply == QMessageBox.Save:
                if not self.save_object():
                    event.ignore()
                    return
            elif reply == QMessageBox.Cancel:
                event.ignore()
                return

        self.closed.emit()
        event.accept()

    # ------------------------------------------------------------------
    #  Helpers
    # ------------------------------------------------------------------

    def _create_default_resource(self, rid):
        return {
            "id": str(rid or ""),
            "name": "",
            "sprite": "",
            "solid": False,
            "depth": 0,
            "persistent": False,
            "parent": "",
            "events": {},
            "frames": []
        }
    
    # ------------------------------------------------------------------
    #  Fullscreen Mode
    # ------------------------------------------------------------------
    
    def _toggle_fullscreen(self):
        """Toggle fullscreen code editor mode - creates a separate fullscreen window"""
        self._is_fullscreen = not self._is_fullscreen
        
        if self._is_fullscreen:
            # Create a separate fullscreen window for code editor
            if not hasattr(self, '_fullscreen_window') or self._fullscreen_window is None:
                self._create_fullscreen_window()
            
            self._fullscreen_window.showFullScreen()
            
            # Update menu
            self.menu_bar.action_fullscreen.setVisible(False)
            self.menu_bar.action_restore.setVisible(True)
        else:
            # Close fullscreen window
            if hasattr(self, '_fullscreen_window') and self._fullscreen_window:
                self._fullscreen_window.close()
                self._fullscreen_window = None
            
            # Update menu
            self.menu_bar.action_fullscreen.setVisible(True)
            self.menu_bar.action_restore.setVisible(False)
    
    def _create_fullscreen_window(self):
        """Create a separate fullscreen window with menu and code editor"""
        from PySide6.QtWidgets import QMainWindow
        
        # Create a new main window for fullscreen
        self._fullscreen_window = QMainWindow(self.window())
        self._fullscreen_window.setWindowTitle("Code Editor - Fullscreen")
        
        # Create central widget with layout
        central_widget = QWidget()
        layout = QVBoxLayout(central_widget)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)
        
        # Add menu bar (copy from main editor)
        fullscreen_menu = ObjectEditorMenu(self._fullscreen_window)
        self._fullscreen_window.setMenuBar(fullscreen_menu)
        
        # Connect menu actions
        fullscreen_menu.action_save.triggered.connect(lambda: self.save_object(save_as=False))
        fullscreen_menu.action_save_as.triggered.connect(lambda: self.save_object(save_as=True))
        fullscreen_menu.action_validate_event.triggered.connect(self.validate_event)
        fullscreen_menu.action_validate_object.triggered.connect(self.validate_object)
        fullscreen_menu.action_validate_highlighted.triggered.connect(
            self.code_editor.validate_highlighted
        )
        fullscreen_menu.action_fullscreen.triggered.connect(self._toggle_fullscreen)
        fullscreen_menu.action_restore.triggered.connect(self._toggle_fullscreen)
        fullscreen_menu.action_fullscreen.setVisible(False)
        fullscreen_menu.action_restore.setVisible(True)
        
        # Add event tabs
        tabs_frame = QFrame()
        tabs_frame.setMaximumHeight(30)
        tabs_layout = QHBoxLayout(tabs_frame)
        tabs_layout.setContentsMargins(4, 2, 4, 2)
        tabs_layout.setSpacing(2)
        
        fullscreen_tabs = QTabBar()
        fullscreen_tabs.setExpanding(False)
        fullscreen_tabs.setTabsClosable(False)
        fullscreen_tabs.currentChanged.connect(self._on_fullscreen_tab_changed)
        tabs_layout.addWidget(fullscreen_tabs)
        tabs_layout.addStretch()
        
        # Store reference to fullscreen tabs
        self._fullscreen_tabs = fullscreen_tabs
        
        layout.addWidget(tabs_frame)
        
        # Add code editor (reparent it)
        self.code_editor.setParent(central_widget)
        layout.addWidget(self.code_editor)
        
        self._fullscreen_window.setCentralWidget(central_widget)
        
        # Update tabs
        self._update_fullscreen_tabs()
        
        # Handle window close
        self._fullscreen_window.closeEvent = lambda event: self._on_fullscreen_close(event)
    
    def _update_fullscreen_tabs(self):
        """Update tabs in fullscreen window"""
        if not hasattr(self, '_fullscreen_tabs') or not self._fullscreen_tabs:
            return
        
        # Remove all existing tabs
        while self._fullscreen_tabs.count() > 0:
            self._fullscreen_tabs.removeTab(0)
        
        events = self.resource_data.get("events", {})
        if not events:
            return
        
        # Get event labels
        # Try new UI structure first, fallback to old location
        try:
            from .UI.events_panel import DEFAULT_EVENT_CATEGORIES
        except ImportError:
            from .object_events_panel import DEFAULT_EVENT_CATEGORIES
        event_labels = {}
        for category in DEFAULT_EVENT_CATEGORIES:
            for event in category['events']:
                event_labels[event['id']] = event['label']
        
        # Add tabs for each event
        for event_id in events.keys():
            label = event_labels.get(event_id, event_id)
            self._fullscreen_tabs.addTab(label)
        
        # Select current event tab
        if self.current_event_id and self.current_event_id in events:
            event_list = list(events.keys())
            tab_index = event_list.index(self.current_event_id)
            self._fullscreen_tabs.blockSignals(True)
            self._fullscreen_tabs.setCurrentIndex(tab_index)
            self._fullscreen_tabs.blockSignals(False)
    
    def _on_fullscreen_tab_changed(self, index: int):
        """Handle tab change in fullscreen window"""
        # Block signals to prevent recursion when we update the tab in _switch_to_event
        if hasattr(self, '_fullscreen_tabs') and self._fullscreen_tabs:
            # Temporarily block to prevent recursion
            was_blocked = self._fullscreen_tabs.signalsBlocked()
            if not was_blocked:
                self._fullscreen_tabs.blockSignals(True)
        
        try:
            events = self.resource_data.get("events", {})
            if not events:
                return
            
            event_list = list(events.keys())
            if 0 <= index < len(event_list):
                event_id = event_list[index]
                # Don't update tabs here - _switch_to_event will handle it
                self._switch_to_event(event_id)
        finally:
            # Restore signal blocking state
            if hasattr(self, '_fullscreen_tabs') and self._fullscreen_tabs and not was_blocked:
                self._fullscreen_tabs.blockSignals(False)
    
    def _on_fullscreen_close(self, event):
        """Handle fullscreen window close"""
        # Exit fullscreen mode
        self._is_fullscreen = False
        # Reparent code editor back to main editor
        self.code_editor.setParent(self)
        self.main_splitter.addWidget(self.code_editor)
        # Update menu
        self.menu_bar.action_fullscreen.setVisible(True)
        self.menu_bar.action_restore.setVisible(False)
        event.accept()
    
    def _update_event_tabs(self):
        """Update the event tabs bar with current events"""
        if not hasattr(self, 'event_tabs'):
            return
        
        # Remove all existing tabs
        while self.event_tabs.count() > 0:
            self.event_tabs.removeTab(0)
        
        events = self.resource_data.get("events", {})
        if not events:
            return
        
        # Get event labels
        # Try new UI structure first, fallback to old location
        try:
            from .UI.events_panel import DEFAULT_EVENT_CATEGORIES
        except ImportError:
            from .object_events_panel import DEFAULT_EVENT_CATEGORIES
        event_labels = {}
        for category in DEFAULT_EVENT_CATEGORIES:
            for event in category['events']:
                event_labels[event['id']] = event['label']
        
        # Add tabs for each event
        for event_id in events.keys():
            label = event_labels.get(event_id, event_id)
            self.event_tabs.addTab(label)
        
        # Select current event tab (block signals to prevent recursion)
        if self.current_event_id and self.current_event_id in events:
            event_list = list(events.keys())
            tab_index = event_list.index(self.current_event_id)
            self.event_tabs.blockSignals(True)
            self.event_tabs.setCurrentIndex(tab_index)
            self.event_tabs.blockSignals(False)
    
    def _on_tab_changed(self, index: int):
        """Handle tab change in fullscreen mode"""
        if not hasattr(self, '_is_fullscreen') or not self._is_fullscreen:
            return
        
        events = self.resource_data.get("events", {})
        if not events:
            return
        
        event_list = list(events.keys())
        if 0 <= index < len(event_list):
            event_id = event_list[index]
            self._switch_to_event(event_id)

    # ------------------------------------------------------------------
    #  Terminal Output
    # ------------------------------------------------------------------

    def _print_terminal(self, msg):
        if hasattr(self.app.main_window, "terminal_widget"):
            self.app.main_window.terminal_widget.append_text(msg)
        else:
            print(msg)
    
    def _on_code_editor_maximize(self):
        """Handle code editor maximize request"""
        try:
            # Toggle maximized state of code editor
            if hasattr(self, "code_editor") and self.code_editor:
                if hasattr(self, "main_splitter") and self.main_splitter:
                    # Get current sizes (3 panels: properties, events, code_editor)
                    sizes = self.main_splitter.sizes()
                    if len(sizes) >= 3:
                        # Check if code editor (index 2) is already maximized
                        if sizes[2] > 0 and sizes[0] > 0 and sizes[1] > 0:
                            # Not maximized - store current sizes and maximize code editor
                            self._pre_maximize_sizes = sizes.copy()
                            # Hide properties and events panels, show only code editor
                            self.main_splitter.setSizes([0, 0, 1])
                            self.code_editor.set_maximized(True)
                        else:
                            # Already maximized - restore previous sizes
                            if hasattr(self, "_pre_maximize_sizes"):
                                self.main_splitter.setSizes(self._pre_maximize_sizes)
                            else:
                                # Default sizes
                                self.main_splitter.setSizes([200, 180, 800])
                            self.code_editor.set_maximized(False)
        except Exception:
            pass
    
    def _on_code_editor_dock(self):
        """Handle code editor dock request (restore to normal layout)"""
        try:
            # Restore code editor to docked state if it was maximized
            if hasattr(self, "main_splitter") and self.main_splitter:
                # Restore to previous sizes or default
                if hasattr(self, "_pre_maximize_sizes"):
                    self.main_splitter.setSizes(self._pre_maximize_sizes)
                else:
                    # Default sizes: properties, events, code_editor
                    self.main_splitter.setSizes([200, 180, 800])
                self.code_editor.set_maximized(False)
                self.code_editor.set_docked(True)
        except Exception:
            pass

    def _populate_parent_list(self):
        """
        Build and provide a parent-object name list to the properties panel.
        Defensive: tries multiple APIs (runtime_resources, resource_manager.list_resources, etc.)
        and handles both set_parent_list(parent_names) and set_parent_list(parent_names, selected).
        """
        try:
            names = []
            # Try runtime_resources first (common fast path)
            try:
                if hasattr(self.app, "project_manager") and getattr(self.app.project_manager, "runtime_resources", None) is not None:
                    rt = self.app.project_manager.runtime_resources
                    objs = rt.get("objects", {}) if isinstance(rt, dict) else {}
                    if isinstance(objs, dict):
                        for oid, odata in objs.items():
                            # odata may be dict with 'name' or string
                            if isinstance(odata, dict):
                                n = odata.get("name") or odata.get("id") or oid
                            else:
                                n = str(odata)
                            if n:
                                names.append(str(n))
            except Exception:
                pass

            # Try resource_manager APIs as fallback
            try:
                if hasattr(self.app, "resource_manager") and self.app.resource_manager is not None:
                    rm = self.app.resource_manager
                    # Common API: list_resources(type) -> iterable
                    if hasattr(rm, "list_resources"):
                        try:
                            for r in rm.list_resources("objects"):
                                if isinstance(r, dict):
                                    n = r.get("name") or r.get("id")
                                else:
                                    n = getattr(r, "name", None) or str(r)
                                if n:
                                    names.append(str(n))
                        except Exception:
                            pass
                    # Another fallback API names
                    elif hasattr(rm, "get_resources_by_type"):
                        try:
                            for r in rm.get_resources_by_type("objects"):
                                if isinstance(r, dict):
                                    n = r.get("name") or r.get("id")
                                else:
                                    n = getattr(r, "name", None) or str(r)
                                if n:
                                    names.append(str(n))
                        except Exception:
                            pass
                    # Generic resources dict
                    elif hasattr(rm, "resources"):
                        try:
                            res = rm.resources
                            if isinstance(res, dict):
                                for k, v in res.items():
                                    try:
                                        if isinstance(v, dict) and v.get("type") in ("object", "objects"):
                                            names.append(str(v.get("name", k)))
                                    except Exception:
                                        continue
                        except Exception:
                            pass
            except Exception:
                pass

            # Clean up names: dedupe and sort, but keep user's current parent if present
            cleaned = []
            seen = set()
            for n in names:
                if not n:
                    continue
                if n in seen:
                    continue
                seen.add(n)
                cleaned.append(n)
            cleaned.sort(key=lambda s: s.lower())

            selected_parent = self.resource_data.get("parent", "") or ""

            # Call panel method - try two-arg then single-arg, handle TypeError gracefully
            try:
                if hasattr(self.properties_panel, "set_parent_list"):
                    try:
                        # Prefer two-arg if supported
                        self.properties_panel.set_parent_list(cleaned, selected_parent)
                    except TypeError:
                        # Fallback to single-arg signature
                        self.properties_panel.set_parent_list(cleaned)
                else:
                    # If panel lacks API, store pending state for later
                    self._pending_parent_list = {"names": cleaned, "selected": selected_parent}
            except Exception:
                # As last resort, store pending state
                self._pending_parent_list = {"names": cleaned, "selected": selected_parent}

        except Exception:
            # Don't crash editor on parent-populate errors
            try:
                from Core.Debug import debug
                debug("Warning: _populate_parent_list failed (non-fatal).")
            except Exception:
                pass

    def _populate_children_list(self):
        """
        Build and provide a list of child objects for this object to the properties panel.
        Defensive: tries runtime_resources and resource_manager APIs, handles different panel method names,
        and stores pending state if the panel cannot be updated right now.
        """
        try:
            children = []
            current_name = self.resource_data.get("name", "")

            # Fast path: runtime_resources from project_manager
            try:
                if hasattr(self.app, "project_manager") and getattr(self.app.project_manager, "runtime_resources", None) is not None:
                    rt = self.app.project_manager.runtime_resources
                    objs = rt.get("objects", {}) if isinstance(rt, dict) else {}
                    if isinstance(objs, dict):
                        for oid, odata in objs.items():
                            try:
                                if isinstance(odata, dict):
                                    parent = odata.get("parent", "") or ""
                                    name = odata.get("name") or oid
                                else:
                                    # legacy: item may be string or simple structure
                                    parent = ""
                                    name = str(odata)
                                if parent == current_name and name:
                                    children.append(str(name))
                            except Exception:
                                continue
            except Exception:
                pass

            # Fallback: resource_manager APIs
            try:
                if hasattr(self.app, "resource_manager") and self.app.resource_manager is not None:
                    rm = self.app.resource_manager
                    # Common API: list_resources("objects")
                    if hasattr(rm, "list_resources"):
                        try:
                            for r in rm.list_resources("objects"):
                                try:
                                    if isinstance(r, dict):
                                        parent = r.get("parent", "") or ""
                                        name = r.get("name") or r.get("id")
                                    else:
                                        parent = getattr(r, "parent", "") or ""
                                        name = getattr(r, "name", None) or str(r)
                                    if parent == current_name and name:
                                        children.append(str(name))
                                except Exception:
                                    continue
                        except Exception:
                            pass
                    elif hasattr(rm, "get_resources_by_type"):
                        try:
                            for r in rm.get_resources_by_type("objects"):
                                try:
                                    if isinstance(r, dict):
                                        parent = r.get("parent", "") or ""
                                        name = r.get("name") or r.get("id")
                                    else:
                                        parent = getattr(r, "parent", "") or ""
                                        name = getattr(r, "name", None) or str(r)
                                    if parent == current_name and name:
                                        children.append(str(name))
                                except Exception:
                                    continue
                        except Exception:
                            pass
            except Exception:
                pass

            # Clean: dedupe & sort
            unique = sorted(set([c for c in children if c]))

            # Try panel API: common method names
            try:
                panel = getattr(self, "properties_panel", None)
                if panel is not None:
                    # Try set_children_list(names, selected?) or set_children(names)
                    if hasattr(panel, "set_children_list"):
                        try:
                            panel.set_children_list(unique)
                        except TypeError:
                            # maybe signature (names, selected)
                            try:
                                panel.set_children_list(unique, "")
                            except Exception:
                                pass
                    elif hasattr(panel, "set_children"):
                        try:
                            panel.set_children(unique)
                        except Exception:
                            pass
                    else:
                        # store pending if no API present
                        self._pending_children_list = {"names": unique}
                else:
                    self._pending_children_list = {"names": unique}
            except Exception:
                # final fallback: store pending
                self._pending_children_list = {"names": unique}
        except Exception:
            try:
                from Core.Debug import debug
                debug("Warning: _populate_children_list failed (non-fatal).")
            except Exception:
                pass

    def _get_event_label(self, event_id: str) -> str:
        """
        Return a human-friendly label for a given event id.
        Tries new UI location first, falls back to legacy module.
        Returns the event_id itself if no label is known.
        """
        try:
            # Try new UI structure first
            try:
                from .UI.events_panel import DEFAULT_EVENT_CATEGORIES
            except Exception:
                from .object_events_panel import DEFAULT_EVENT_CATEGORIES  # legacy fallback

            # Build map of id -> label
            event_map = {}
            for category in DEFAULT_EVENT_CATEGORIES:
                for ev in category.get("events", []):
                    try:
                        eid = ev.get("id")
                        label = ev.get("label", eid)
                        if eid:
                            event_map[eid] = label
                    except Exception:
                        continue

            # Handle collision events (dynamic, not in DEFAULT_EVENT_CATEGORIES)
            if event_id.startswith("collision_"):
                # Look up object name from object_id
                object_id = event_id.replace("collision_", "", 1)
                if hasattr(self, 'app') and self.app and hasattr(self.app, 'project_manager'):
                    runtime_resources = self.app.project_manager.runtime_resources
                    objects = runtime_resources.get("objects", {})
                    object_data = objects.get(object_id)
                    if object_data:
                        object_name = object_data.get("name", "Unknown")
                        return f"Collision with {object_name}"
                # Fallback: use object_id if name not found
                return f"Collision with {object_id}"
            
            # Return found label or fallback
            return event_map.get(event_id, event_id)
        except Exception:
            # Final fallback mapping for common events
            common = {
                "create": "Create",
                "step": "Step",
                "draw": "Draw",
                "destroy": "Destroy",
                "collision": "Collision",
                "alarm": "Alarm",
            }
            return common.get(event_id, event_id)
    
    def _setup_sprite_preview_widget(self):
        """
        Setup sprite preview widget.
        Note: Sprite preview is actually handled by properties_panel,
        so this is a stub for compatibility.
        """
        # Sprite preview is handled by properties_panel.sprite_preview
        # This method exists for API compatibility
        pass
    
    def _update_sprite_preview(self):
        """
        Update sprite preview display.
        Note: Sprite preview is actually handled by properties_panel,
        so this delegates to the panel if available.
        """
        # Try to update via properties panel if available
        try:
            if hasattr(self, 'properties_panel') and self.properties_panel:
                # The properties panel handles its own sprite preview updates
                # via _set_sprite() method, so we don't need to do anything here
                pass
        except Exception:
            pass
