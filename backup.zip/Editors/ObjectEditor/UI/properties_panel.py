"""
Properties Panel for Object Editor
Left-hand properties panel - GameMaker Studio style
Moved to UI/ folder as part of modular restructure
"""

from __future__ import annotations

from typing import Dict, List, Optional
from pathlib import Path

from PySide6.QtCore import Qt, Signal, QSize
from PySide6.QtGui import QFont, QPixmap, QIcon
from PySide6.QtWidgets import (
    QWidget,
    QVBoxLayout,
    QHBoxLayout,
    QFormLayout,
    QLabel,
    QLineEdit,
    QCheckBox,
    QSpinBox,
    QComboBox,
    QPushButton,
    QGroupBox,
    QFileDialog,
    QDialog,
    QTreeWidget,
    QTreeWidgetItem,
    QSizePolicy,
    QTabWidget,
)


class SpriteBrowserDialog(QDialog):
    """Dialog for browsing and selecting sprites"""
    
    def __init__(self, app, parent=None):
        super().__init__(parent)
        self.app = app
        self.selected_sprite_id = None
        self.selected_sprite_name = None
        
        self.setWindowTitle("Select Sprite")
        self.setMinimumSize(500, 600)
        
        layout = QVBoxLayout(self)
        
        # Instructions
        label = QLabel("Browse and select a sprite:")
        layout.addWidget(label)
        
        # Sprite tree with thumbnails
        self.sprite_tree = QTreeWidget()
        self.sprite_tree.setHeaderHidden(True)
        self.sprite_tree.itemDoubleClicked.connect(self._on_sprite_selected)
        self.sprite_tree.itemClicked.connect(self._on_sprite_clicked)
        layout.addWidget(self.sprite_tree)
        
        # Buttons
        button_layout = QHBoxLayout()
        self.select_button = QPushButton("Select")
        self.select_button.clicked.connect(self.accept)
        self.select_button.setEnabled(False)
        cancel_button = QPushButton("Cancel")
        cancel_button.clicked.connect(self.reject)
        
        button_layout.addWidget(self.select_button)
        button_layout.addStretch()
        button_layout.addWidget(cancel_button)
        layout.addLayout(button_layout)
        
        self._populate_sprite_tree()
    
    def _populate_sprite_tree(self):
        """Populate sprite tree with thumbnails"""
        self.sprite_tree.clear()
        
        if not hasattr(self.app, 'project_manager'):
            return
        
        runtime_resources = self.app.project_manager.runtime_resources
        sprites = runtime_resources.get("sprites", {})
        project_path = Path(self.app.project_manager.get_project_path())
        
        # Build sprite structure by folder
        sprite_structure = {"_root": []}
        
        for sprite_id, sprite_data in sprites.items():
            parent_folder = sprite_data.get("parent_folder", "")
            sprite_name = sprite_data.get("name", "Unknown")
            
            if parent_folder:
                if parent_folder not in sprite_structure:
                    sprite_structure[parent_folder] = []
                sprite_structure[parent_folder].append({
                    "id": sprite_id,
                    "name": sprite_name,
                    "data": sprite_data
                })
            else:
                sprite_structure["_root"].append({
                    "id": sprite_id,
                    "name": sprite_name,
                    "data": sprite_data
                })
        
        # Add root sprites
        for spr in sprite_structure.get("_root", []):
            item = QTreeWidgetItem(self.sprite_tree, [spr["name"]])
            item.setData(0, Qt.UserRole, spr["id"])
            item.setData(0, Qt.UserRole + 1, spr["name"])
            self._set_sprite_icon(item, spr["data"], project_path)
        
        # Add folder sprites
        for folder_name, sprites_list in sprite_structure.items():
            if folder_name == "_root":
                continue
            
            folder_item = QTreeWidgetItem(self.sprite_tree, [folder_name])
            folder_item.setFlags(folder_item.flags() & ~Qt.ItemIsSelectable)
            
            for spr in sprites_list:
                child = QTreeWidgetItem(folder_item, [spr["name"]])
                child.setData(0, Qt.UserRole, spr["id"])
                child.setData(0, Qt.UserRole + 1, spr["name"])
                self._set_sprite_icon(child, spr["data"], project_path)
            
            folder_item.setExpanded(True)
        
        self.sprite_tree.expandAll()
    
    def _set_sprite_icon(self, item, sprite_data, project_path):
        """Set icon for sprite item"""
        try:
            # Get sprite's first frame
            frames = sprite_data.get("frames", [])
            if frames:
                first_frame = frames[0] if isinstance(frames[0], dict) else frames[0]
                
                if isinstance(first_frame, dict):
                    frame_file = first_frame.get("file", "")
                else:
                    frame_file = first_frame
                
                if frame_file:
                    parent_folder = sprite_data.get("parent_folder", "")
                    if parent_folder:
                        sprite_folder = project_path / "Resources" / "Sprites" / parent_folder
                    else:
                        sprite_folder = project_path / "Resources" / "Sprites"
                    
                    frame_path = sprite_folder / frame_file
                    if frame_path.exists():
                        pixmap = QPixmap(str(frame_path))
                        if not pixmap.isNull():
                            # Scale to 24x24 thumbnail
                            scaled = pixmap.scaled(24, 24, Qt.KeepAspectRatio, Qt.SmoothTransformation)
                            item.setIcon(0, QIcon(scaled))
        except Exception as e:
            pass  # Ignore errors loading thumbnails
    
    def _on_sprite_clicked(self, item, column):
        """Handle sprite click"""
        sprite_id = item.data(0, Qt.UserRole)
        if sprite_id:
            self.selected_sprite_id = sprite_id
            self.selected_sprite_name = item.data(0, Qt.UserRole + 1)
            self.select_button.setEnabled(True)
    
    def _on_sprite_selected(self, item, column):
        """Handle sprite double-click"""
        self._on_sprite_clicked(item, column)
        if self.selected_sprite_id:
            self.accept()


class ObjectPropertiesPanel(QWidget):
    """
    Left-hand panel for object properties.
    Redesigned to match GameMaker Studio layout - compact and efficient.
    """

    # Signals
    nameChanged = Signal(str)
    nameEnterPressed = Signal(str)  # Emits when Enter is pressed on name field
    spriteChanged = Signal(str)  # Emits sprite ID
    solidChanged = Signal(bool)
    depthChanged = Signal(int)
    persistentChanged = Signal(bool)
    parentChanged = Signal(str)
    eventsButtonClicked = Signal()
    testCodeRequested = Signal()  # Emits when "Test Objects' Code" is clicked
    childSelected = Signal(str)  # Emits when a child object is selected

    def __init__(self, parent: Optional[QWidget] = None):
        super().__init__(parent)
        self._suppress_signals = False
        self.current_sprite_id = None
        self.current_sprite_name = None
        
        self._build_ui()

    def _build_ui(self) -> None:
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(8, 8, 8, 8)
        main_layout.setSpacing(8)

        # --------------------------------------------------------------
        # Object Properties (compact form like GMS)
        # --------------------------------------------------------------
        props_group = QGroupBox("Object Properties")
        props_layout = QFormLayout(props_group)
        props_layout.setLabelAlignment(Qt.AlignRight)
        props_layout.setContentsMargins(8, 8, 8, 8)
        props_layout.setSpacing(6)

        # Name
        self.name_edit = QLineEdit()
        self.name_edit.setPlaceholderText("Object name")
        self.name_edit.textChanged.connect(self._on_name_changed)
        self.name_edit.returnPressed.connect(self._on_name_enter_pressed)
        self._original_name = ""  # Track original name for rename check
        props_layout.addRow("Name:", self.name_edit)

        # Sprite (button with thumbnail)
        sprite_layout = QHBoxLayout()
        sprite_layout.addWidget(QLabel("Sprite:"))
        
        # Use QLabel for sprite preview (better for displaying images)
        self.sprite_preview = QLabel()
        self.sprite_preview.setMinimumSize(64, 64)
        self.sprite_preview.setMaximumSize(64, 64)
        self.sprite_preview.setAlignment(Qt.AlignCenter)
        self.sprite_preview.setStyleSheet("""
            QLabel {
                background-color: #202030;
                border: 1px solid #404060;
                border-radius: 4px;
            }
        """)
        self.sprite_preview.setText("(none)")
        self.sprite_preview.setScaledContents(False)  # We'll scale manually
        
        # Create a clickable button wrapper
        self.sprite_button = QPushButton()
        self.sprite_button.setMinimumSize(64, 64)
        self.sprite_button.setMaximumSize(64, 64)
        sprite_button_layout = QVBoxLayout()
        sprite_button_layout.setContentsMargins(0, 0, 0, 0)
        sprite_button_layout.addWidget(self.sprite_preview)
        self.sprite_button.setLayout(sprite_button_layout)
        self.sprite_button.setStyleSheet("""
            QPushButton {
                background-color: transparent;
                border: none;
                padding: 0px;
            }
            QPushButton:hover {
                border: 1px solid #606080;
                border-radius: 4px;
            }
            QPushButton:pressed {
                border: 1px solid #8080a0;
                border-radius: 4px;
            }
        """)
        self.sprite_button.clicked.connect(self._browse_sprite)
        sprite_layout.addWidget(self.sprite_button)
        
        self.sprite_label = QLabel("(none)")
        self.sprite_label.setStyleSheet("color: #aaaaaa;")
        sprite_layout.addWidget(self.sprite_label)
        sprite_layout.addStretch()
        
        props_layout.addRow("Sprite:", sprite_layout)

        # Solid and Persistent (side by side)
        checkboxes_layout = QHBoxLayout()
        self.solid_checkbox = QCheckBox("Solid")
        self.solid_checkbox.stateChanged.connect(self._on_solid_changed)
        checkboxes_layout.addWidget(self.solid_checkbox)
        
        self.persistent_checkbox = QCheckBox("Persistent")
        self.persistent_checkbox.stateChanged.connect(self._on_persistent_changed)
        checkboxes_layout.addWidget(self.persistent_checkbox)
        checkboxes_layout.addStretch()
        
        props_layout.addRow("", checkboxes_layout)

        # Depth
        self.depth_spin = QSpinBox()
        self.depth_spin.setRange(-1_000_000, 1_000_000)
        self.depth_spin.setValue(0)
        self.depth_spin.valueChanged.connect(self._on_depth_changed)
        props_layout.addRow("Depth:", self.depth_spin)

        main_layout.addWidget(props_group)
        
        # Tab widget for Parent/Child
        self.tab_widget = QTabWidget()
        
        # Parent/Child tab
        parent_child_widget = QWidget()
        parent_child_layout = QVBoxLayout(parent_child_widget)
        parent_child_layout.setContentsMargins(8, 8, 8, 8)
        
        # Parent section
        parent_group = QGroupBox("Parent")
        parent_group_layout = QVBoxLayout(parent_group)
        parent_group_layout.setContentsMargins(8, 8, 8, 8)
        
        self.parent_combo = QComboBox()
        self.parent_combo.setEditable(False)
        self.parent_combo.currentTextChanged.connect(self._on_parent_changed)
        parent_group_layout.addWidget(self.parent_combo)
        parent_child_layout.addWidget(parent_group)
        
        # Children section
        children_group = QGroupBox("Children")
        children_group_layout = QVBoxLayout(children_group)
        children_group_layout.setContentsMargins(8, 8, 8, 8)
        
        self.children_list = QTreeWidget()
        self.children_list.setHeaderHidden(True)
        self.children_list.itemClicked.connect(self._on_child_clicked)
        children_group_layout.addWidget(self.children_list)
        parent_child_layout.addWidget(children_group)
        
        parent_child_layout.addStretch()
        self.tab_widget.addTab(parent_child_widget, "Parent/Child")
        
        main_layout.addWidget(self.tab_widget)
        
        # Test Objects' Code button at bottom
        self.test_code_button = QPushButton("Test Objects' Code")
        self.test_code_button.setToolTip("Check all events in the object for issues")
        self.test_code_button.clicked.connect(self._on_test_code_clicked)
        main_layout.addWidget(self.test_code_button)
        
        main_layout.addStretch()

    def _browse_sprite(self):
        """Open sprite browser dialog"""
        # Get app from parent ObjectEditor
        app = None
        parent = self.parent()
        while parent:
            if hasattr(parent, 'app'):
                app = parent.app
                break
            parent = parent.parent()
        
        dialog = SpriteBrowserDialog(app, self)
        if dialog.exec() == QDialog.Accepted:
            sprite_id = dialog.selected_sprite_id
            sprite_name = dialog.selected_sprite_name
            if sprite_id:
                self._set_sprite(sprite_id, sprite_name)
                self.spriteChanged.emit(sprite_id)

    def _set_sprite(self, sprite_id: str = None, sprite_name: str = None):
        """Set the sprite and update thumbnail"""
        self.current_sprite_id = sprite_id
        self.current_sprite_name = sprite_name
        
        # Update label
        self.sprite_label.setText(sprite_name or "(none)")
        
        # Load and set thumbnail
        # Get app from parent ObjectEditor
        app = None
        parent = self.parent()
        while parent:
            if hasattr(parent, 'app'):
                app = parent.app
                break
            parent = parent.parent()
        
        if sprite_id and app:
            if hasattr(app, 'project_manager'):
                runtime_resources = app.project_manager.runtime_resources
                sprites = runtime_resources.get("sprites", {})
                sprite_data = sprites.get(sprite_id)
                
                if sprite_data:
                    project_path = Path(app.project_manager.get_project_path())
                    frames = sprite_data.get("frames", [])
                    
                    if frames:
                        first_frame = frames[0] if isinstance(frames[0], dict) else frames[0]
                        
                        if isinstance(first_frame, dict):
                            frame_file = first_frame.get("file", "")
                        else:
                            frame_file = first_frame
                        
                        if frame_file:
                            parent_folder = sprite_data.get("parent_folder", "")
                            if parent_folder:
                                sprite_folder = project_path / "Resources" / "Sprites" / parent_folder
                            else:
                                sprite_folder = project_path / "Resources" / "Sprites"
                            
                            frame_path = sprite_folder / frame_file
                            if frame_path.exists():
                                pixmap = QPixmap(str(frame_path))
                                if not pixmap.isNull():
                                    # Scale to 64x64 for preview label (maintaining aspect ratio)
                                    scaled = pixmap.scaled(64, 64, Qt.KeepAspectRatio, Qt.SmoothTransformation)
                                    # Set pixmap directly on the label
                                    self.sprite_preview.setPixmap(scaled)
                                    self.sprite_preview.setText("")  # Clear text
                                    # Update sprite name if not already set
                                    if not sprite_name:
                                        self.sprite_label.setText(sprite_data.get("name", "(none)"))
                                    else:
                                        self.sprite_label.setText(sprite_name)
                                    from Core.Debug import debug
                                    debug(f"Sprite preview set for sprite_id={sprite_id}, sprite_name={sprite_name}, frame_path={frame_path}")
                                    return
                                else:
                                    from Core.Debug import debug
                                    debug(f"Failed to load pixmap from {frame_path}")
                            else:
                                from Core.Debug import debug
                                debug(f"Sprite frame path does not exist: {frame_path}")
        
        # If we have sprite_name but no sprite_id, try to find it
        if sprite_name and not sprite_id and app:
            if hasattr(app, 'project_manager'):
                runtime_resources = app.project_manager.runtime_resources
                sprites = runtime_resources.get("sprites", {})
                for sid, sdata in sprites.items():
                    if sdata.get("name") == sprite_name:
                        # Found it! Recursively call with the found sprite_id
                        self._set_sprite(sid, sprite_name)
                        return
        
        # No sprite or failed to load
        self.sprite_preview.clear()
        self.sprite_preview.setText("(none)")
        self.sprite_label.setText("(none)")

    def set_object_data(
        self,
        name: str,
        solid: bool,
        depth: int,
        persistent: bool,
        parent_name: str,
        sprite_id: Optional[str] = None,
    ) -> None:
        """Populate the panel from an object resource"""
        self._suppress_signals = True
        try:
            self._original_name = name or ""
            self.name_edit.setText(self._original_name)
            self.solid_checkbox.setChecked(bool(solid))
            self.depth_spin.setValue(int(depth))
            self.persistent_checkbox.setChecked(bool(persistent))

            # Set parent
            idx = self.parent_combo.findText(parent_name)
            if idx >= 0:
                self.parent_combo.setCurrentIndex(idx)
            else:
                none_idx = self.parent_combo.findText("(none)")
                if none_idx >= 0:
                    self.parent_combo.setCurrentIndex(none_idx)
            
            # Set sprite if provided
            if sprite_id:
                # Get app from parent ObjectEditor
                app = None
                parent = self.parent()
                while parent:
                    if hasattr(parent, 'app'):
                        app = parent.app
                        break
                    parent = parent.parent()
                
                # Get sprite name
                if app and hasattr(app, 'project_manager'):
                    runtime_resources = app.project_manager.runtime_resources
                    sprites = runtime_resources.get("sprites", {})
                    sprite_data = sprites.get(sprite_id)
                    if sprite_data:
                        sprite_name = sprite_data.get("name", "Unknown")
                        self._set_sprite(sprite_id, sprite_name)
                    else:
                        # Sprite ID not found, try to find by name from resource_data
                        # This can happen if the sprite was deleted or not loaded yet
                        self._set_sprite(None, None)
            else:
                # No sprite_id provided, clear the preview
                self._set_sprite(None, None)
        finally:
            self._suppress_signals = False

    def set_parent_list(self, parents: List[str]) -> None:
        """Populate the parent combo box"""
        self._suppress_signals = True
        try:
            self.parent_combo.clear()
            if "(none)" not in parents:
                self.parent_combo.addItem("(none)")
            for p in parents:
                if p and p != "(none)":
                    self.parent_combo.addItem(p)
        finally:
            self._suppress_signals = False

    def _on_name_changed(self, text: str) -> None:
        if self._suppress_signals:
            return
        self.nameChanged.emit(text)
    
    def _on_name_enter_pressed(self) -> None:
        """Handle Enter key press on name field"""
        current_name = self.name_edit.text()
        if current_name != self._original_name:
            self.nameEnterPressed.emit(current_name)
        self.name_edit.clearFocus()  # Remove focus after rename

    def _on_solid_changed(self, state: int) -> None:
        if self._suppress_signals:
            return
        self.solidChanged.emit(state == Qt.Checked)

    def _on_depth_changed(self, value: int) -> None:
        if self._suppress_signals:
            return
        self.depthChanged.emit(value)

    def _on_persistent_changed(self, state: int) -> None:
        if self._suppress_signals:
            return
        self.persistentChanged.emit(state == Qt.Checked)

    def _on_parent_changed(self, text: str) -> None:
        if self._suppress_signals:
            return
        parent_name = text if text != "(none)" else ""
        self.parentChanged.emit(parent_name)
    
    def _on_test_code_clicked(self):
        """Handle Test Objects' Code button click"""
        self.testCodeRequested.emit()
    
    def _on_child_clicked(self, item, column):
        """Handle child object click"""
        child_name = item.text(0)
        self.childSelected.emit(child_name)
    
    def set_children(self, child_names: List[str]):
        """Set the list of child objects"""
        self.children_list.clear()
        for name in sorted(child_names):
            item = QTreeWidgetItem(self.children_list, [name])
