"""
Events Panel for Object Editor
Middle panel for event navigation - GameMaker Studio style
Moved to UI/ folder as part of modular restructure
"""

from __future__ import annotations

from typing import Dict, List, Optional

from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QColor, QFont, QIcon
from PySide6.QtWidgets import (
    QWidget,
    QVBoxLayout,
    QHBoxLayout,
    QTreeWidget,
    QTreeWidgetItem,
    QGroupBox,
    QPushButton,
    QLabel,
    QListWidget,
    QListWidgetItem,
    QDialog,
)
from pathlib import Path


# ----------------------------------------------------------------------
# Standardized Event Definitions
# ----------------------------------------------------------------------
DEFAULT_EVENT_CATEGORIES = [
    {
        "name": "Create",
        "events": [
            {"id": "create", "label": "Create"},
            {"id": "room_start", "label": "Room Start"},
            {"id": "game_start", "label": "Game Start"},
        ],
    },
    {
        "name": "Step",
        "events": [
            {"id": "start_step", "label": "Start Step"},
            {"id": "step", "label": "Step"},
            {"id": "end_step", "label": "End Step"},
        ],
    },
    {
        "name": "Draw",
        "events": [
            {"id": "draw", "label": "Draw"},
            {"id": "draw_begin", "label": "Draw Begin"},
            {"id": "draw_end", "label": "Draw End"},
        ],
    },
    {
        "name": "Collision",
        "events": [],  # Collision events are created dynamically when an object is selected
    },
    {
        "name": "Alarm",
        "events": [
            {"id": f"alarm_{i}", "label": f"Alarm {i}"} for i in range(10)
        ],
    },
    {
        "name": "User Defined",
        "events": [
            {"id": f"user_event_{i}", "label": f"User Event {i}"} for i in range(10)
        ],
    },
    {
        "name": "End",
        "events": [
            {"id": "room_end", "label": "Room End"},
            {"id": "game_end", "label": "Game End"},
            {"id": "destroy", "label": "Destroy"},
        ],
    },
]


class ObjectEventsPanel(QWidget):
    """
    Middle panel for displaying & managing events in the object.
    
    Layout:
      [ Events Group ]
        - Tree of event categories + events actually added
        - "Add Event..." button at bottom
    """

    # ------------------------------------------------------------------
    # Signals
    # ------------------------------------------------------------------
    eventSelected = Signal(str)        # event_id
    eventAdded = Signal(str)           # event_id
    eventRequested = Signal(str)       # double-click or explicit selection

    def __init__(
        self,
        parent: Optional[QWidget] = None,
        event_categories: Optional[List[Dict]] = None,
        app=None,
    ):
        super().__init__(parent)

        self.event_categories = event_categories or DEFAULT_EVENT_CATEGORIES
        self.app = app
        # Try to get app from parent if not provided
        if not self.app and parent:
            if hasattr(parent, 'app'):
                self.app = parent.app

        # Currently selected event id
        self.current_event_id: Optional[str] = None

        self._build_ui()

    # ------------------------------------------------------------------
    # UI Construction
    # ------------------------------------------------------------------

    def _build_ui(self) -> None:
        layout = QVBoxLayout(self)
        layout.setContentsMargins(6, 6, 6, 6)
        layout.setSpacing(6)

        group = QGroupBox("Events")
        g_layout = QVBoxLayout(group)
        g_layout.setContentsMargins(6, 6, 6, 6)
        g_layout.setSpacing(6)

        # Tree of events
        self.tree = QTreeWidget()
        self.tree.setHeaderHidden(True)
        self.tree.itemClicked.connect(self._on_tree_item_clicked)
        self.tree.itemDoubleClicked.connect(self._on_tree_item_double_clicked)
        g_layout.addWidget(self.tree)

        layout.addWidget(group)
        
        # Add stretch before button to push it to bottom
        layout.addStretch()

        # "Add Event" button at bottom
        self.add_button = QPushButton("Add Event…")
        self.add_button.clicked.connect(self._show_add_event_dialog)
        layout.addWidget(self.add_button)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def set_events(self, event_dict: Dict[str, str]) -> None:
        """
        Populate the tree with events already present in the object.
        
        event_dict: { event_id: code_string }
        """
        self.tree.clear()

        # Group events by category
        events_by_cat = {}
        for cat in self.event_categories:
            cat_name = cat["name"]
            events_by_cat[cat_name] = []

            for ev in cat["events"]:
                ev_id = ev["id"]
                if ev_id in event_dict:
                    events_by_cat[cat_name].append(ev)

        # Handle collision events (dynamic, not in DEFAULT_EVENT_CATEGORIES)
        collision_events = []
        for ev_id in event_dict.keys():
            if ev_id.startswith("collision_"):
                collision_events.append(ev_id)
        
        if collision_events:
            events_by_cat["Collision"] = events_by_cat.get("Collision", []) + [
                {"id": ev_id, "label": self._get_collision_event_label(ev_id)}
                for ev_id in collision_events
            ]

        # Populate tree
        for cat in self.event_categories:
            cat_name = cat["name"]
            cat_events = events_by_cat.get(cat_name, [])
            if not cat_events:
                continue

            cat_item = QTreeWidgetItem(self.tree, [cat_name])
            cat_item.setFlags(cat_item.flags() & ~Qt.ItemIsSelectable)
            cat_item.setExpanded(True)

            for ev in cat_events:
                item = QTreeWidgetItem(cat_item, [ev["label"]])
                item.setData(0, Qt.UserRole, ev["id"])

        self.tree.expandAll()
    
    def _get_collision_event_label(self, event_id: str) -> str:
        """Get label for a collision event by looking up the object name"""
        # event_id format: collision_{object_id}
        if not event_id.startswith("collision_"):
            return event_id
        
        object_id = event_id.replace("collision_", "", 1)
        
        # Try to get object name from project manager
        if self.app and hasattr(self.app, 'project_manager'):
            runtime_resources = self.app.project_manager.runtime_resources
            objects = runtime_resources.get("objects", {})
            object_data = objects.get(object_id)
            if object_data:
                object_name = object_data.get("name", "Unknown")
                return f"Collision with {object_name}"
        
        # Fallback: use object_id if name not found
        return f"Collision with {object_id}"

    def select_event(self, event_id: str) -> None:
        """Highlight a specific event in the tree programmatically."""
        self.current_event_id = event_id
        root_count = self.tree.topLevelItemCount()

        for i in range(root_count):
            cat_item = self.tree.topLevelItem(i)
            for j in range(cat_item.childCount()):
                ev_item = cat_item.child(j)
                if ev_item.data(0, Qt.UserRole) == event_id:
                    self.tree.setCurrentItem(ev_item)
                    self._highlight_selected(ev_item)
                    return

    # ------------------------------------------------------------------
    # Dialog for adding events
    # ------------------------------------------------------------------

    def _show_add_event_dialog(self) -> None:
        dialog = QDialog(self)
        dialog.setWindowTitle("Add Event")
        dialog.setMinimumSize(300, 450)

        layout = QVBoxLayout(dialog)
        layout.setSpacing(6)

        label = QLabel("Select an event to add:")
        layout.addWidget(label)

        list_widget = QListWidget()
        layout.addWidget(list_widget)

        # Add categories + events
        for cat in self.event_categories:
            cat_name = cat["name"]
            # Category header (not selectable)
            cat_item = QListWidgetItem(cat_name)
            f = cat_item.font()
            f.setBold(True)
            cat_item.setFont(f)
            cat_item.setFlags(Qt.NoItemFlags)
            list_widget.addItem(cat_item)

            # Special handling for Collision category
            if cat_name == "Collision":
                # Add a placeholder item that will trigger object selection
                collision_item = QListWidgetItem("  Collision...")
                collision_item.setData(Qt.UserRole, "__collision__")
                list_widget.addItem(collision_item)
            else:
                # Regular events
                for ev in cat["events"]:
                    ev_label = f"  {ev['label']}"
                    ev_item = QListWidgetItem(ev_label)
                    ev_item.setData(Qt.UserRole, ev["id"])
                    list_widget.addItem(ev_item)

        # Buttons
        btn_row = QHBoxLayout()
        add_btn = QPushButton("Add")
        cancel_btn = QPushButton("Cancel")

        add_btn.clicked.connect(dialog.accept)
        cancel_btn.clicked.connect(dialog.reject)

        btn_row.addWidget(add_btn)
        btn_row.addWidget(cancel_btn)
        layout.addLayout(btn_row)

        if dialog.exec() == QDialog.Accepted:
            item = list_widget.currentItem()
            if item:
                event_id = item.data(Qt.UserRole)
                if event_id == "__collision__":
                    # Show object browser dialog
                    self._show_collision_object_dialog()
                elif event_id:
                    self.eventAdded.emit(event_id)
    
    def _show_collision_object_dialog(self) -> None:
        """Show dialog to select an object for collision event"""
        if not self.app or not hasattr(self.app, 'project_manager'):
            return
        
        # Get current object ID to exclude it from selection
        current_object_id = None
        if hasattr(self.parent(), 'resource_data'):
            current_object_id = self.parent().resource_data.get("id")
        
        dialog = ObjectBrowserDialog(self.app, self, exclude_object_id=current_object_id)
        if dialog.exec() == QDialog.Accepted:
            selected_object_id = dialog.selected_object_id
            selected_object_name = dialog.selected_object_name
            
            if selected_object_id:
                # Create collision event ID based on object ID
                # Format: collision_{object_id}
                # The label will be generated dynamically as "Collision with {object_name}"
                event_id = f"collision_{selected_object_id}"
                self.eventAdded.emit(event_id)

    # ------------------------------------------------------------------
    # Event Handlers
    # ------------------------------------------------------------------

    def _on_tree_item_clicked(self, item: QTreeWidgetItem, col: int) -> None:
        event_id = item.data(0, Qt.UserRole)
        if not event_id:
            return  # Category clicked

        self.current_event_id = event_id
        self._highlight_selected(item)
        self.eventSelected.emit(event_id)
    
    def _on_tree_item_double_clicked(self, item: QTreeWidgetItem, col: int) -> None:
        """Handle double-click on event item"""
        event_id = item.data(0, Qt.UserRole)
        if event_id:
            self.eventRequested.emit(event_id)

    def _highlight_selected(self, item: QTreeWidgetItem) -> None:
        """Visual highlight of selected event."""
        # Reset all backgrounds
        root_count = self.tree.topLevelItemCount()
        for i in range(root_count):
            cat_item = self.tree.topLevelItem(i)
            cat_item.setBackground(0, QColor())
            for j in range(cat_item.childCount()):
                ev_item = cat_item.child(j)
                ev_item.setBackground(0, QColor())

        # Highlight selected
        item.setBackground(0, QColor(50, 80, 150))


class ObjectBrowserDialog(QDialog):
    """Dialog for browsing and selecting objects for collision events"""
    
    def __init__(self, app, parent=None, exclude_object_id=None):
        super().__init__(parent)
        self.app = app
        self.exclude_object_id = exclude_object_id  # Object to exclude (can't collide with self)
        self.selected_object_id = None
        self.selected_object_name = None
        
        self.setWindowTitle("Select Object for Collision")
        self.setMinimumSize(500, 600)
        
        layout = QVBoxLayout(self)
        
        # Instructions
        label = QLabel("Browse and select an object for collision event:")
        layout.addWidget(label)
        
        # Object tree
        self.object_tree = QTreeWidget()
        self.object_tree.setHeaderHidden(True)
        self.object_tree.itemDoubleClicked.connect(self._on_object_selected)
        self.object_tree.itemClicked.connect(self._on_object_clicked)
        layout.addWidget(self.object_tree)
        
        # Buttons
        button_layout = QHBoxLayout()
        self.select_button = QPushButton("Select")
        self.select_button.clicked.connect(self.accept)
        self.select_button.setEnabled(False)
        cancel_button = QPushButton("Cancel")
        cancel_button.clicked.connect(self.reject)
        
        button_layout.addWidget(self.select_button)
        button_layout.addStretch()
        button_layout.addWidget(cancel_button)
        layout.addLayout(button_layout)
        
        self._populate_object_tree()
    
    def _populate_object_tree(self):
        """Populate object tree with objects from project"""
        self.object_tree.clear()
        
        if not hasattr(self.app, 'project_manager'):
            return
        
        runtime_resources = self.app.project_manager.runtime_resources
        objects = runtime_resources.get("objects", {})
        
        # Build object structure by folder
        object_structure = {"_root": []}
        
        for object_id, object_data in objects.items():
            # Exclude the current object (can't collide with self)
            if object_id == self.exclude_object_id:
                continue
            
            parent_folder = object_data.get("parent_folder", "")
            object_name = object_data.get("name", "Unknown")
            
            if parent_folder:
                if parent_folder not in object_structure:
                    object_structure[parent_folder] = []
                object_structure[parent_folder].append({
                    "id": object_id,
                    "name": object_name,
                    "data": object_data
                })
            else:
                object_structure["_root"].append({
                    "id": object_id,
                    "name": object_name,
                    "data": object_data
                })
        
        # Add root objects
        for obj in object_structure.get("_root", []):
            item = QTreeWidgetItem(self.object_tree, [obj["name"]])
            item.setData(0, Qt.UserRole, obj["id"])
            item.setData(0, Qt.UserRole + 1, obj["name"])
            item.setIcon(0, QIcon())  # Can add object icon here if available
        
        # Add folder objects
        for folder_name, objects_list in object_structure.items():
            if folder_name == "_root":
                continue
            
            folder_item = QTreeWidgetItem(self.object_tree, [folder_name])
            folder_item.setFlags(folder_item.flags() & ~Qt.ItemIsSelectable)
            
            for obj in objects_list:
                child = QTreeWidgetItem(folder_item, [obj["name"]])
                child.setData(0, Qt.UserRole, obj["id"])
                child.setData(0, Qt.UserRole + 1, obj["name"])
                child.setIcon(0, QIcon())  # Can add object icon here if available
            
            folder_item.setExpanded(True)
        
        self.object_tree.expandAll()
    
    def _on_object_clicked(self, item, column):
        """Handle object click"""
        object_id = item.data(0, Qt.UserRole)
        if object_id:
            self.selected_object_id = object_id
            self.selected_object_name = item.data(0, Qt.UserRole + 1)
            self.select_button.setEnabled(True)
    
    def _on_object_selected(self, item, column):
        """Handle object double-click"""
        self._on_object_clicked(item, column)
        if self.selected_object_id:
            self.accept()
