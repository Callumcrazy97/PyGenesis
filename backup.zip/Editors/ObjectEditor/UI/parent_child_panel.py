"""
Parent/Child Panel for Object Editor
Shows parent object and child objects
"""

from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QComboBox,
    QPushButton, QGroupBox, QListWidget, QListWidgetItem
)
from PySide6.QtCore import Qt, Signal
from typing import List, Optional, Dict


class ParentChildPanel(QWidget):
    """Panel for managing parent/child object relationships"""
    
    # Signals
    parentChanged = Signal(str)  # Emits parent object name
    childSelected = Signal(str)  # Emits child object name when clicked
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.current_object_name = ""
        self._build_ui()
    
    def _build_ui(self):
        """Build the parent/child panel UI"""
        layout = QVBoxLayout(self)
        layout.setContentsMargins(8, 8, 8, 8)
        layout.setSpacing(8)
        
        # Parent section
        parent_group = QGroupBox("Parent")
        parent_layout = QVBoxLayout(parent_group)
        parent_layout.setContentsMargins(8, 8, 8, 8)
        
        self.parent_combo = QComboBox()
        self.parent_combo.setEditable(False)
        self.parent_combo.currentTextChanged.connect(self._on_parent_changed)
        parent_layout.addWidget(self.parent_combo)
        
        layout.addWidget(parent_group)
        
        # Children section
        children_group = QGroupBox("Children")
        children_layout = QVBoxLayout(children_group)
        children_layout.setContentsMargins(8, 8, 8, 8)
        
        self.children_list = QListWidget()
        self.children_list.itemClicked.connect(self._on_child_clicked)
        children_layout.addWidget(self.children_list)
        
        layout.addWidget(children_group)
        
        layout.addStretch()
    
    def set_object_name(self, object_name: str):
        """Set the current object name"""
        self.current_object_name = object_name
    
    def set_parent_list(self, parent_names: List[str], current_parent: str = ""):
        """Set the list of available parent objects"""
        self.parent_combo.clear()
        self.parent_combo.addItem("(none)")
        
        for name in sorted(parent_names):
            self.parent_combo.addItem(name)
        
        # Set current parent
        if current_parent:
            index = self.parent_combo.findText(current_parent)
            if index >= 0:
                self.parent_combo.setCurrentIndex(index)
            else:
                self.parent_combo.setCurrentIndex(0)
        else:
            self.parent_combo.setCurrentIndex(0)
    
    def set_children(self, child_names: List[str]):
        """Set the list of child objects"""
        self.children_list.clear()
        
        for name in sorted(child_names):
            item = QListWidgetItem(name)
            self.children_list.addItem(item)
    
    def _on_parent_changed(self, text: str):
        """Handle parent selection change"""
        parent_name = text if text != "(none)" else ""
        self.parentChanged.emit(parent_name)
    
    def _on_child_clicked(self, item: QListWidgetItem):
        """Handle child object click"""
        child_name = item.text()
        self.childSelected.emit(child_name)

