"""
Code Editor Widget for Object Editor
Code editor with Maximize/Dock functionality
Uses UnifiedCodeEditor for code editing functionality
"""

from PySide6.QtWidgets import QFrame, QLabel, QVBoxLayout, QHBoxLayout, QPushButton, QWidget
from PySide6.QtCore import Qt, Signal
import ast

from Core.Code.Unified import UnifiedCodeEditor, EditorContext


class CodeEditorDock(QWidget):
    """
    Code editor for Object Editor events.
    Wraps UnifiedCodeEditor with event-specific header and Maximize/Dock functionality.
    """
    
    # Signals (maintain compatibility with ObjectEditor)
    code_changed = Signal()
    maximizeRequested = Signal()
    dockRequested = Signal()
    
    def __init__(self, parent_editor, app):
        super().__init__(parent_editor)
        
        # Store references
        self.parent_editor = parent_editor
        self.app = app
        self._is_maximized = False
        self._is_docked = True
        
        # Current event context
        self.current_event_id = None
        self.current_event_label = None
        
        # Build UI
        self._build_ui()
        
        # Forward UnifiedCodeEditor signals
        self._unified_editor.code_changed.connect(self._on_code_changed)
    
    def _build_ui(self):
        """Build the UI with event header and UnifiedCodeEditor"""
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)
        
        # Event header frame
        self.event_header_frame = QFrame()
        self.event_header_frame.setFrameShape(QFrame.StyledPanel)
        self.event_header_frame.setStyleSheet(
            "QFrame { background-color: #2b2b3d; border: 1px solid #3d3d5c; padding: 5px; }"
        )
        event_header_layout = QHBoxLayout(self.event_header_frame)
        event_header_layout.setContentsMargins(10, 5, 10, 5)
        event_header_layout.setSpacing(10)
        
        self.event_header_label = QLabel("No event selected")
        self.event_header_label.setStyleSheet("color: #ffffff; font-weight: bold; font-size: 12px;")
        event_header_layout.addWidget(self.event_header_label)
        
        event_header_layout.addStretch()
        
        # Fullscreen/Dock toggle button (single button)
        self.fullscreen_button = QPushButton("Fullscreen")
        self.fullscreen_button.setToolTip("Toggle fullscreen mode (Fullscreen when docked, Dock when fullscreen)")
        self.fullscreen_button.clicked.connect(self._on_fullscreen_toggle)
        self.fullscreen_button.setMaximumWidth(100)
        event_header_layout.addWidget(self.fullscreen_button)
        
        layout.addWidget(self.event_header_frame)
        
        # UnifiedCodeEditor
        self._unified_editor = UnifiedCodeEditor(
            self.app,
            context=EditorContext.OBJECT_EVENT,
            parent=self
        )
        layout.addWidget(self._unified_editor)
    
    def _on_fullscreen_toggle(self):
        """Handle fullscreen/dock toggle button click"""
        if self._is_maximized:
            # Currently fullscreen, so dock it
            self.dockRequested.emit()
        else:
            # Currently docked, so go fullscreen
            self.maximizeRequested.emit()
    
    def _on_code_changed(self):
        """Forward code_changed signal"""
        self.code_changed.emit()
    
    def set_maximized(self, maximized: bool):
        """Set maximized state"""
        self._is_maximized = maximized
        if maximized:
            self.fullscreen_button.setText("Dock")
            self.fullscreen_button.setToolTip("Dock code editor back to panel")
        else:
            self.fullscreen_button.setText("Fullscreen")
            self.fullscreen_button.setToolTip("Maximize code editor to fullscreen")
    
    def set_docked(self, docked: bool):
        """Set docked state"""
        self._is_docked = docked
        # Button text is managed by set_maximized, but we update state here
        if not docked:
            # Undocked means fullscreen
            self._is_maximized = True
            self.fullscreen_button.setText("Dock")
            self.fullscreen_button.setToolTip("Dock code editor back to panel")
        else:
            # Docked means not fullscreen
            self._is_maximized = False
            self.fullscreen_button.setText("Fullscreen")
            self.fullscreen_button.setToolTip("Maximize code editor to fullscreen")
    
    def set_event_context(self, event_id: str, event_label: str):
        """Set the current event context for the header"""
        self.current_event_id = event_id
        self.current_event_label = event_label
        if self.event_header_label:
            self.event_header_label.setText(f"Event: {event_label}")
    
    def clear_event_context(self):
        """Clear the event context"""
        self.current_event_id = None
        self.current_event_label = None
        if self.event_header_label:
            self.event_header_label.setText("No event selected")
    
    # ------------------------------------------------------------------
    # Forward UnifiedCodeEditor API methods
    # ------------------------------------------------------------------
    
    def set_code(self, code: str, suppress_signals: bool = False):
        """Set the code content"""
        self._unified_editor.set_code(code, suppress_signals=suppress_signals)
    
    def get_code(self) -> str:
        """Get the current code content"""
        return self._unified_editor.get_code()
    
    def clear_editor(self):
        """Clear the editor"""
        self._unified_editor.set_code("", suppress_signals=True)
        self._unified_editor.clear_diagnostics()
    
    def get_selected_code(self) -> str:
        """Get the currently selected/highlighted code"""
        return self._unified_editor.get_selected_code()
    
    def check_selected_code(self):
        """Validate highlighted code (called from menu)"""
        self._unified_editor.check_selected_code()
    
    def check_full_code(self):
        """Validate the entire code"""
        self._unified_editor.check_full_code()
    
    def validate_highlighted(self):
        """Validate highlighted code (called from menu) - alias for check_selected_code"""
        self.check_selected_code()
    
    def validate_current_event(self):
        """Validate the current event code"""
        if not self.current_event_id:
            from PySide6.QtWidgets import QMessageBox
            QMessageBox.information(self, "No Event", "No event selected.")
            return
        self.check_full_code()
    
    def check_multiple_code_blocks(self, code_blocks: dict, context: str = "Object"):
        """Check multiple code blocks (for validating all events) and output to terminal"""
        # Output header to terminal
        self._output_to_terminal(f"\n{'='*60}\n")
        self._output_to_terminal(f"Checking {context} code blocks...\n")
        self._output_to_terminal(f"{'='*60}\n")
        
        # Extract variables from all events (especially Create event)
        # Variables defined in Create event should be available in all other events
        all_predefined_variables = set()
        for block_name, code in code_blocks.items():
            if code and code.strip():
                # Extract variables from this event
                variables = self._extract_variables_from_code(code)
                all_predefined_variables.update(variables)
        
        errors_found = []
        warnings_found = []
        checked_blocks = 0
        
        for block_name, code in code_blocks.items():
            if code and code.strip():
                checked_blocks += 1
                self._output_to_terminal(f"\n📄 {block_name}:\n")
                
                # Detect mode for this code block
                detected_mode = self._unified_editor._detect_code_mode(code)
                
                # Get predefined variables (exclude variables defined in current block)
                current_block_variables = self._extract_variables_from_code(code)
                predefined_vars = all_predefined_variables - current_block_variables
                
                # Validate this code block with predefined variables from other events
                is_valid, errors, warnings = self._unified_editor.validator.validate(
                    code,
                    detected_mode,
                    context=f"{context}: {block_name}",
                    editor_context=self._unified_editor.context,
                    predefined_variables=list(predefined_vars) if predefined_vars else None
                )
                
                if not is_valid:
                    self._output_to_terminal(f"❌ {len(errors)} error(s):\n")
                    for err in errors:
                        self._output_to_terminal(f"  Line {err.line}: {err.message}\n")
                    errors_found.extend([f"{block_name}: {err.message}" for err in errors])
                elif warnings:
                    self._output_to_terminal(f"⚠️ {len(warnings)} warning(s):\n")
                    for warn in warnings:
                        self._output_to_terminal(f"  Line {warn.line}: {warn.message}\n")
                    warnings_found.extend([f"{block_name}: {warn.message}" for warn in warnings])
                else:
                    self._output_to_terminal(f"✅ Code check passed\n")
        
        # Summary
        self._output_to_terminal(f"\n{'='*60}\n")
        if errors_found:
            self._output_to_terminal(f"❌ Validation failed: {len(errors_found)} error(s) across {checked_blocks} event(s)\n")
        elif warnings_found:
            self._output_to_terminal(f"✅ Validation passed with {len(warnings_found)} warning(s) across {checked_blocks} event(s)\n")
        else:
            self._output_to_terminal(f"✅ All {checked_blocks} event(s) validated successfully\n")
        self._output_to_terminal(f"{'='*60}\n")
    
    def _extract_variables_from_code(self, code: str) -> set:
        """Extract variable names from code (top-level assignments)"""
        variables = set()
        if not code or not code.strip():
            return variables
        
        try:
            # Try to parse as Python (works for both PGSL and Python)
            tree = ast.parse(code)
            for node in ast.walk(tree):
                # Extract variable assignments
                if isinstance(node, ast.Assign):
                    for target in node.targets:
                        if isinstance(target, ast.Name):
                            variables.add(target.id)
                elif isinstance(node, (ast.AnnAssign, ast.AugAssign)):
                    if isinstance(node.target, ast.Name):
                        variables.add(node.target.id)
        except (SyntaxError, ValueError):
            # If parsing fails, return empty set (might be PGSL or invalid code)
            pass
        
        return variables
    
    def _output_to_terminal(self, message: str):
        """Output message to terminal widget"""
        if hasattr(self.app, 'main_window') and hasattr(self.app.main_window, 'terminal_widget'):
            self.app.main_window.terminal_widget.append_text(message)
        else:
            print(message, end='')
    
    def _validate_code_string(self, code: str) -> dict:
        """Validate a code string (legacy method for ObjectEditor compatibility)"""
        is_valid, errors, warnings = self._unified_editor.validator.validate(
            code,
            self._unified_editor._detect_code_mode(code),
            context=self._unified_editor.context.value
        )
        
        return {
            "passed": is_valid,
            "errors": [err.to_dict() for err in errors],
            "warnings": [warn.to_dict() for warn in warnings]
        }
    
    # ------------------------------------------------------------------
    # Properties for compatibility
    # ------------------------------------------------------------------
    
    @property
    def validator(self):
        """Access to validator (for compatibility)"""
        return self._unified_editor.validator
