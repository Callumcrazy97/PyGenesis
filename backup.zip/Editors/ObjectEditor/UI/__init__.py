"""
Object Editor UI
All UI components for the Object Editor
"""

from .properties_panel import ObjectPropertiesPanel
from .events_panel import ObjectEventsPanel, DEFAULT_EVENT_CATEGORIES
from .code_editor_widget import CodeEditorDock
from .parent_child_panel import ParentChildPanel
from .object_editor_menu import ObjectEditorMenu

__all__ = [
    'ObjectPropertiesPanel',
    'ObjectEventsPanel',
    'CodeEditorDock',
    'ParentChildPanel',
    'ObjectEditorMenu',
    'DEFAULT_EVENT_CATEGORIES'
]

