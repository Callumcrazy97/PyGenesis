import pygame
from pygame.locals import *
from OpenGL.GL import *
from OpenGL.GLU import *
import numpy as np
import math
import os
from tkinter import Tk, filedialog

class Camera:
    def __init__(self):
        self.pos = np.array([0.0, 2.0, 5.0], dtype=np.float32)
        self.front = np.array([0.0, 0.0, -1.0], dtype=np.float32)
        self.up = np.array([0.0, 1.0, 0.0], dtype=np.float32)
        self.yaw = -90.0
        self.pitch = 0.0
        self.speed = 0.1
        self.sensitivity = 0.1
        
    def process_mouse(self, xoffset, yoffset):
        xoffset *= self.sensitivity
        yoffset *= self.sensitivity
        
        self.yaw += xoffset
        self.pitch += yoffset
        
        if self.pitch > 89.0:
            self.pitch = 89.0
        if self.pitch < -89.0:
            self.pitch = -89.0
            
        self.update_vectors()
    
    def update_vectors(self):
        front = np.array([
            math.cos(math.radians(self.yaw)) * math.cos(math.radians(self.pitch)),
            math.sin(math.radians(self.pitch)),
            math.sin(math.radians(self.yaw)) * math.cos(math.radians(self.pitch))
        ], dtype=np.float32)
        self.front = front / np.linalg.norm(front)
        
    def get_view_matrix(self):
        center = self.pos + self.front
        glLoadIdentity()
        gluLookAt(self.pos[0], self.pos[1], self.pos[2],
                  center[0], center[1], center[2],
                  self.up[0], self.up[1], self.up[2])

class Model:
    def __init__(self, filepath=None):
        self.vertices = None
        self.normals = None
        self.indices = None
        self.vbo_vertices = None
        self.vbo_normals = None
        self.ibo = None
        
        if filepath:
            self.load_model(filepath)
    
    def load_obj(self, filepath):
        """Load OBJ file format"""
        vertices = []
        normals = []
        faces = []
        
        with open(filepath, 'r') as f:
            for line in f:
                if line.startswith('v '):
                    # Vertex
                    parts = line.strip().split()
                    vertices.append([float(parts[1]), float(parts[2]), float(parts[3])])
                elif line.startswith('vn '):
                    # Normal
                    parts = line.strip().split()
                    normals.append([float(parts[1]), float(parts[2]), float(parts[3])])
                elif line.startswith('f '):
                    # Face
                    parts = line.strip().split()[1:]
                    face_vertices = []
                    for part in parts:
                        # Handle formats: v, v/vt, v/vt/vn, v//vn
                        indices = part.split('/')
                        v_idx = int(indices[0]) - 1  # OBJ is 1-indexed
                        face_vertices.append(v_idx)
                    
                    # Triangulate faces (assumes convex polygons)
                    for i in range(1, len(face_vertices) - 1):
                        faces.append([face_vertices[0], face_vertices[i], face_vertices[i + 1]])
        
        if not vertices:
            raise ValueError("No vertices found in OBJ file")
        
        # Convert to numpy arrays
        vertices = np.array(vertices, dtype=np.float32)
        faces = np.array(faces, dtype=np.uint32)
        
        # Flatten vertices for OpenGL
        self.indices = faces.flatten()
        self.vertices = vertices
        
        # Calculate normals if not provided
        if not normals:
            self.calculate_normals()
        else:
            normals = np.array(normals, dtype=np.float32)
            self.normals = normals
    
    def load_glb(self, filepath):
        """Load GLB file format using pygltflib"""
        try:
            from pygltflib import GLTF2
        except ImportError:
            raise ImportError("pygltflib required for GLB support. Install with: pip install pygltflib")
        
        gltf = GLTF2().load(filepath)
        
        # Get the first mesh
        if not gltf.meshes:
            raise ValueError("No meshes found in GLB file")
        
        mesh = gltf.meshes[0]
        primitive = mesh.primitives[0]
        
        # Get accessor for positions
        pos_accessor = gltf.accessors[primitive.attributes.POSITION]
        pos_bufferview = gltf.bufferViews[pos_accessor.bufferView]
        pos_buffer = gltf.buffers[pos_bufferview.buffer]
        pos_data = gltf.get_data_from_buffer_uri(pos_buffer.uri)
        
        # Extract vertex data
        vertices = np.frombuffer(
            pos_data[pos_bufferview.byteOffset:pos_bufferview.byteOffset + pos_bufferview.byteLength],
            dtype=np.float32
        ).reshape(-1, 3)
        
        self.vertices = vertices
        
        # Get indices if available
        if primitive.indices is not None:
            idx_accessor = gltf.accessors[primitive.indices]
            idx_bufferview = gltf.bufferViews[idx_accessor.bufferView]
            idx_buffer = gltf.buffers[idx_bufferview.buffer]
            idx_data = gltf.get_data_from_buffer_uri(idx_buffer.uri)
            
            # Determine index type
            if idx_accessor.componentType == 5123:  # UNSIGNED_SHORT
                dtype = np.uint16
            elif idx_accessor.componentType == 5125:  # UNSIGNED_INT
                dtype = np.uint32
            else:
                dtype = np.uint32
            
            indices = np.frombuffer(
                idx_data[idx_bufferview.byteOffset:idx_bufferview.byteOffset + idx_bufferview.byteLength],
                dtype=dtype
            )
            self.indices = indices.astype(np.uint32)
        else:
            # No indices, create sequential indices
            self.indices = np.arange(len(vertices), dtype=np.uint32)
        
        # Get normals if available
        if hasattr(primitive.attributes, 'NORMAL') and primitive.attributes.NORMAL is not None:
            norm_accessor = gltf.accessors[primitive.attributes.NORMAL]
            norm_bufferview = gltf.bufferViews[norm_accessor.bufferView]
            norm_buffer = gltf.buffers[norm_bufferview.buffer]
            norm_data = gltf.get_data_from_buffer_uri(norm_buffer.uri)
            
            normals = np.frombuffer(
                norm_data[norm_bufferview.byteOffset:norm_bufferview.byteOffset + norm_bufferview.byteLength],
                dtype=np.float32
            ).reshape(-1, 3)
            self.normals = normals
        else:
            self.calculate_normals()
    
    def calculate_normals(self):
        """Calculate vertex normals from faces"""
        normals = np.zeros((len(self.vertices), 3), dtype=np.float32)
        
        # Calculate face normals and accumulate to vertices
        for i in range(0, len(self.indices), 3):
            i0, i1, i2 = self.indices[i], self.indices[i+1], self.indices[i+2]
            v0, v1, v2 = self.vertices[i0], self.vertices[i1], self.vertices[i2]
            
            # Calculate face normal
            edge1 = v1 - v0
            edge2 = v2 - v0
            normal = np.cross(edge1, edge2)
            
            # Accumulate to vertex normals
            normals[i0] += normal
            normals[i1] += normal
            normals[i2] += normal
        
        # Normalize
        norms = np.linalg.norm(normals, axis=1, keepdims=True)
        norms[norms == 0] = 1  # Avoid division by zero
        self.normals = normals / norms
    
    def load_model(self, filepath):
        """Load model based on file extension"""
        ext = os.path.splitext(filepath)[1].lower()
        
        print(f"Loading model: {filepath}")
        
        if ext == '.obj':
            self.load_obj(filepath)
        elif ext == '.glb' or ext == '.gltf':
            self.load_glb(filepath)
        else:
            raise ValueError(f"Unsupported file format: {ext}")
        
        # Center and scale model
        self.center_and_scale()
        
        print(f"Loaded {len(self.vertices)} vertices, {len(self.indices)//3} triangles")
        
        # Setup OpenGL buffers
        self.setup_buffers()
    
    def center_and_scale(self):
        """Center model at origin and scale to unit size"""
        if self.vertices is None or len(self.vertices) == 0:
            return
        
        # Center
        center = np.mean(self.vertices, axis=0)
        self.vertices -= center
        
        # Scale to fit in unit cube
        max_extent = np.max(np.abs(self.vertices))
        if max_extent > 0:
            self.vertices /= max_extent
    
    def setup_buffers(self):
        """Setup OpenGL VBOs"""
        # Vertex buffer
        self.vbo_vertices = glGenBuffers(1)
        glBindBuffer(GL_ARRAY_BUFFER, self.vbo_vertices)
        glBufferData(GL_ARRAY_BUFFER, self.vertices.nbytes, self.vertices, GL_STATIC_DRAW)
        
        # Normal buffer
        if self.normals is not None:
            self.vbo_normals = glGenBuffers(1)
            glBindBuffer(GL_ARRAY_BUFFER, self.vbo_normals)
            glBufferData(GL_ARRAY_BUFFER, self.normals.nbytes, self.normals, GL_STATIC_DRAW)
        
        # Index buffer
        self.ibo = glGenBuffers(1)
        glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, self.ibo)
        glBufferData(GL_ELEMENT_ARRAY_BUFFER, self.indices.nbytes, self.indices, GL_STATIC_DRAW)
    
    def render(self):
        if self.vertices is None:
            return
        
        glEnableClientState(GL_VERTEX_ARRAY)
        if self.normals is not None:
            glEnableClientState(GL_NORMAL_ARRAY)
        
        glBindBuffer(GL_ARRAY_BUFFER, self.vbo_vertices)
        glVertexPointer(3, GL_FLOAT, 0, None)
        
        if self.normals is not None and self.vbo_normals is not None:
            glBindBuffer(GL_ARRAY_BUFFER, self.vbo_normals)
            glNormalPointer(GL_FLOAT, 0, None)
        
        glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, self.ibo)
        glDrawElements(GL_TRIANGLES, len(self.indices), GL_UNSIGNED_INT, None)
        
        glDisableClientState(GL_VERTEX_ARRAY)
        if self.normals is not None:
            glDisableClientState(GL_NORMAL_ARRAY)
    
    def cleanup(self):
        """Clean up OpenGL buffers"""
        if self.vbo_vertices:
            glDeleteBuffers(1, [self.vbo_vertices])
        if self.vbo_normals:
            glDeleteBuffers(1, [self.vbo_normals])
        if self.ibo:
            glDeleteBuffers(1, [self.ibo])

class Viewer:
    def __init__(self):
        pygame.init()
        self.width = 1280
        self.height = 720
        self.screen = pygame.display.set_mode((self.width, self.height), DOUBLEBUF | OPENGL)
        pygame.display.set_caption("3D Model Viewer - No Model Loaded")
        
        self.camera = Camera()
        self.model = None
        self.tool = "Select"
        self.mouse_pressed = False
        self.culling_enabled = True
        
        # OpenGL settings
        glEnable(GL_DEPTH_TEST)
        glDepthFunc(GL_LESS)
        
        # Enable face culling for performance
        glEnable(GL_CULL_FACE)
        glCullFace(GL_BACK)
        glFrontFace(GL_CCW)  # Counter-clockwise is front
        
        # Enable lighting
        glEnable(GL_LIGHTING)
        glEnable(GL_LIGHT0)
        glEnable(GL_COLOR_MATERIAL)
        glColorMaterial(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE)
        
        # Light properties
        glLightfv(GL_LIGHT0, GL_POSITION, [5.0, 5.0, 5.0, 1.0])
        glLightfv(GL_LIGHT0, GL_AMBIENT, [0.3, 0.3, 0.3, 1.0])
        glLightfv(GL_LIGHT0, GL_DIFFUSE, [0.7, 0.7, 0.7, 1.0])
        
        # Material properties
        glMaterialfv(GL_FRONT, GL_AMBIENT, [0.2, 0.2, 0.2, 1.0])
        glMaterialfv(GL_FRONT, GL_DIFFUSE, [0.8, 0.8, 0.8, 1.0])
        glMaterialfv(GL_FRONT, GL_SPECULAR, [1.0, 1.0, 1.0, 1.0])
        glMaterialf(GL_FRONT, GL_SHININESS, 50.0)
        
        # Background color
        glClearColor(0.1, 0.1, 0.1, 1.0)
        
        # Setup perspective
        glMatrixMode(GL_PROJECTION)
        gluPerspective(45, (self.width / self.height), 0.1, 100.0)
        glMatrixMode(GL_MODELVIEW)
        
        # Grid
        self.grid_display_list = self.create_grid()
        
        self.clock = pygame.time.Clock()
        self.running = True
        
        # Hide tkinter root window
        self.tk_root = Tk()
        self.tk_root.withdraw()
    
    def create_grid(self):
        """Create a grid display list"""
        display_list = glGenLists(1)
        glNewList(display_list, GL_COMPILE)
        
        glDisable(GL_LIGHTING)
        glColor3f(0.3, 0.3, 0.3)
        glBegin(GL_LINES)
        
        grid_size = 10
        grid_spacing = 1.0
        
        for i in range(-grid_size, grid_size + 1):
            # Lines parallel to X axis
            glVertex3f(-grid_size * grid_spacing, 0, i * grid_spacing)
            glVertex3f(grid_size * grid_spacing, 0, i * grid_spacing)
            
            # Lines parallel to Z axis
            glVertex3f(i * grid_spacing, 0, -grid_size * grid_spacing)
            glVertex3f(i * grid_spacing, 0, grid_size * grid_spacing)
        
        glEnd()
        glEnable(GL_LIGHTING)
        
        glEndList()
        return display_list
    
    def import_model(self):
        """Open file dialog to import a model"""
        filetypes = [
            ("3D Models", "*.obj *.glb *.gltf"),
            ("OBJ files", "*.obj"),
            ("GLB files", "*.glb"),
            ("GLTF files", "*.gltf"),
            ("All files", "*.*")
        ]
        
        filepath = filedialog.askopenfilename(
            title="Import 3D Model",
            filetypes=filetypes
        )
        
        if filepath:
            try:
                # Clean up old model
                if self.model:
                    self.model.cleanup()
                
                # Load new model
                self.model = Model(filepath)
                filename = os.path.basename(filepath)
                pygame.display.set_caption(f"3D Model Viewer - {filename}")
                print(f"Successfully loaded: {filename}")
            except Exception as e:
                print(f"Error loading model: {e}")
                import traceback
                traceback.print_exc()
    
    def handle_events(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.running = False
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 2:  # Middle mouse button
                    self.mouse_pressed = True
                    pygame.mouse.get_rel()
                elif event.button == 1:  # Left click
                    print(f"Using tool: {self.tool}")
                elif event.button == 4:  # Scroll up (zoom in)
                    self.camera.pos += self.camera.front * 0.5
                elif event.button == 5:  # Scroll down (zoom out)
                    self.camera.pos -= self.camera.front * 0.5
            elif event.type == pygame.MOUSEBUTTONUP:
                if event.button == 2:
                    self.mouse_pressed = False
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_1:
                    self.tool = "Select"
                    print("Tool: Select")
                elif event.key == pygame.K_2:
                    self.tool = "Draw"
                    print("Tool: Draw")
                elif event.key == pygame.K_c:
                    self.culling_enabled = not self.culling_enabled
                    if self.culling_enabled:
                        glEnable(GL_CULL_FACE)
                        print("Face culling: ON")
                    else:
                        glDisable(GL_CULL_FACE)
                        print("Face culling: OFF")
                elif event.key == pygame.K_i or (event.key == pygame.K_o and pygame.key.get_mods() & KMOD_CTRL):
                    self.import_model()
                elif event.key == pygame.K_ESCAPE:
                    self.running = False
    
    def handle_input(self):
        keys = pygame.key.get_pressed()
        
        velocity = self.camera.speed
        if keys[K_LSHIFT]:
            velocity *= 2
            
        if keys[K_w]:
            self.camera.pos += self.camera.front * velocity
        if keys[K_s]:
            self.camera.pos -= self.camera.front * velocity
        if keys[K_a]:
            right = np.cross(self.camera.front, self.camera.up)
            right = right / np.linalg.norm(right)
            self.camera.pos -= right * velocity
        if keys[K_d]:
            right = np.cross(self.camera.front, self.camera.up)
            right = right / np.linalg.norm(right)
            self.camera.pos += right * velocity
        if keys[K_SPACE]:
            self.camera.pos += self.camera.up * velocity
        if keys[K_LCTRL]:
            self.camera.pos -= self.camera.up * velocity
            
        if self.mouse_pressed:
            mouse_rel = pygame.mouse.get_rel()
            if mouse_rel[0] != 0 or mouse_rel[1] != 0:
                self.camera.process_mouse(mouse_rel[0], -mouse_rel[1])
    
    def render(self):
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
        
        # Reset modelview matrix
        glMatrixMode(GL_MODELVIEW)
        glLoadIdentity()
        
        # Apply camera view
        self.camera.get_view_matrix()
        
        # Draw grid
        glCallList(self.grid_display_list)
        
        # Draw model if loaded
        if self.model:
            self.model.render()
        
        pygame.display.flip()
    
    def run(self):
        print("\n=== 3D Model Viewer ===")
        print("\nControls:")
        print("  I or Ctrl+O - Import model")
        print("  WASD - Move camera")
        print("  Space - Move up")
        print("  Ctrl - Move down")
        print("  Shift - Move faster")
        print("  Middle Mouse - Look around (hold and drag)")
        print("  Left Click - Use selected tool")
        print("  Scroll - Zoom in/out")
        print("  1 - Select tool")
        print("  2 - Draw tool")
        print("  C - Toggle face culling")
        print("  ESC - Quit")
        print("\nPress I to import a 3D model...")
        
        while self.running:
            self.handle_events()
            self.handle_input()
            self.render()
            self.clock.tick(60)
        
        # Cleanup
        if self.model:
            self.model.cleanup()
        self.tk_root.destroy()
        pygame.quit()

if __name__ == "__main__":
    try:
        viewer = Viewer()
        viewer.run()
    except Exception as e:
        print(f"Error: {e}")
        import traceback
        traceback.print_exc()
