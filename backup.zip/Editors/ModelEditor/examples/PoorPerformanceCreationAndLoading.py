"""
3D Model Viewer and Editor - SketchUp-like Application
A single-file 3D modeling application with real-time editing capabilities.
"""

import sys
import math
import json
from typing import List, Optional, Tuple
from enum import Enum
from dataclasses import dataclass, asdict
from collections import deque

from PySide6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QPushButton, QLabel, QListWidget, QGroupBox, QSlider, QDoubleSpinBox,
    QCheckBox, QSplitter, QMenuBar, QMenu, QStatusBar, QFrame, QColorDialog
)
from PySide6.QtCore import Qt, QTimer, Signal, QPoint
from PySide6.QtGui import QColor, QAction, QKeySequence
from PySide6.QtOpenGLWidgets import QOpenGLWidget
from OpenGL.GL import *
from OpenGL.GLU import *
import numpy as np
try:
    from OpenGL.arrays import vbo
    HAS_VBO = True
except Exception:
    HAS_VBO = False
try:
    import moderngl as mgl
    HAS_MGL = True
except Exception:
    HAS_MGL = False


class PrimitiveType(Enum):
    CUBE = "cube"
    SPHERE = "sphere"
    CYLINDER = "cylinder"
    PLANE = "plane"


@dataclass
class Face:
    """Represents a 3D face/polygon"""
    vertices: List['Vector3']
    id: int = 0
    color: Tuple[float, float, float] = (0.8, 0.8, 0.8)  # Default gray
    material: Optional[str] = None
    
    def to_dict(self):
        return {
            'vertices': [asdict(v) for v in self.vertices],
            'id': self.id,
            'color': self.color,
            'material': self.material
        }
    
    @classmethod
    def from_dict(cls, data):
        return cls(
            vertices=[Vector3(**v) for v in data['vertices']],
            id=data.get('id', 0),
            color=tuple(data.get('color', (0.8, 0.8, 0.8))),
            material=data.get('material')
        )

@dataclass
class Edge:
    """Represents a 3D edge/line"""
    start: 'Vector3'
    end: 'Vector3'
    id: int = 0
    color: Tuple[float, float, float] = (0.0, 1.0, 1.0)  # Default cyan
    
    def to_dict(self):
        return {
            'start': asdict(self.start),
            'end': asdict(self.end),
            'id': self.id,
            'color': self.color
        }
    
    @classmethod
    def from_dict(cls, data):
        return cls(
            start=Vector3(**data['start']),
            end=Vector3(**data['end']),
            id=data.get('id', 0),
            color=tuple(data.get('color', (0.0, 1.0, 1.0)))
        )


class ToolMode(Enum):
    SELECT = "select"
    MOVE = "move"
    ROTATE = "rotate"
    SCALE = "scale"
    CREATE = "create"
    DRAW = "draw"
    PAN = "pan"
    ORBIT = "orbit"


@dataclass
class Vector3:
    x: float = 0.0
    y: float = 0.0
    z: float = 0.0
    
    def __add__(self, other):
        return Vector3(self.x + other.x, self.y + other.y, self.z + other.z)
    
    def __sub__(self, other):
        return Vector3(self.x - other.x, self.y - other.y, self.z - other.z)
    
    def __mul__(self, scalar):
        return Vector3(self.x * scalar, self.y * scalar, self.z * scalar)
    
    def dot(self, other):
        return self.x * other.x + self.y * other.y + self.z * other.z
    
    def cross(self, other):
        return Vector3(
            self.y * other.z - self.z * other.y,
            self.z * other.x - self.x * other.z,
            self.x * other.y - self.y * other.x
        )
    
    def length(self):
        return math.sqrt(self.x**2 + self.y**2 + self.z**2)
    
    def normalize(self):
        l = self.length()
        if l > 0:
            return Vector3(self.x / l, self.y / l, self.z / l)
        return Vector3(0, 0, 0)


@dataclass
class Transform:
    position: Vector3 = None
    rotation: Vector3 = None  # Euler angles in degrees
    scale: Vector3 = None
    
    def __post_init__(self):
        if self.position is None:
            self.position = Vector3()
        if self.rotation is None:
            self.rotation = Vector3()
        if self.scale is None:
            self.scale = Vector3(1.0, 1.0, 1.0)
    
    def to_dict(self):
        return {
            'position': asdict(self.position),
            'rotation': asdict(self.rotation),
            'scale': asdict(self.scale)
        }
    
    @classmethod
    def from_dict(cls, data):
        return cls(
            position=Vector3(**data['position']),
            rotation=Vector3(**data['rotation']),
            scale=Vector3(**data['scale'])
        )


@dataclass
class Primitive:
    id: int
    type: PrimitiveType
    transform: Transform
    color: Tuple[float, float, float] = (0.8, 0.8, 0.8)
    selected: bool = False
    
    def to_dict(self):
        return {
            'id': self.id,
            'type': self.type.value,
            'transform': self.transform.to_dict(),
            'color': self.color,
            'selected': self.selected
        }
    
    @classmethod
    def from_dict(cls, data):
        return cls(
            id=data['id'],
            type=PrimitiveType(data['type']),
            transform=Transform.from_dict(data['transform']),
            color=tuple(data['color']),
            selected=data.get('selected', False)
        )


class Camera:
    def __init__(self):
        # Free camera mode: position and rotation (pitch/yaw)
        self.position = Vector3(0, 5, 20)
        self.pitch = 20.0  # Vertical rotation (degrees)
        self.yaw = 0.0  # Horizontal rotation (degrees)
        self.fov = 45.0
        self.near = 0.1
        self.far = 1000.0
    
    def get_forward(self) -> Vector3:
        """Get forward vector from camera rotation"""
        pitch_rad = math.radians(self.pitch)
        yaw_rad = math.radians(self.yaw)
        return Vector3(
            math.cos(pitch_rad) * math.sin(yaw_rad),
            math.sin(pitch_rad),
            math.cos(pitch_rad) * math.cos(yaw_rad)
        )
    
    def get_right(self) -> Vector3:
        """Get right vector from camera rotation"""
        yaw_rad = math.radians(self.yaw)
        return Vector3(
            math.sin(yaw_rad - math.pi/2),
            0,
            math.cos(yaw_rad - math.pi/2)
        )
    
    def get_up(self) -> Vector3:
        """Get up vector"""
        return Vector3(0, 1, 0)
    
    def set_projection(self, width, height):
        """Set up projection matrix"""
        glMatrixMode(GL_PROJECTION)
        glLoadIdentity()
        aspect = width / height if height > 0 else 1.0
        gluPerspective(self.fov, aspect, self.near, self.far)
    
    def set_view(self):
        """Set up view matrix using free camera"""
        glMatrixMode(GL_MODELVIEW)
        glLoadIdentity()
        
        forward = self.get_forward()
        target = self.position + forward
        up = self.get_up()
        
        gluLookAt(
            self.position.x, self.position.y, self.position.z,
            target.x, target.y, target.z,
            up.x, up.y, up.z
        )


class OpenGLWidget(QOpenGLWidget):
    """OpenGL widget for 3D rendering"""
    
    sceneChanged = Signal()  # Signal emitted when scene changes
    selectionChanged = Signal()  # Signal emitted when selection changes
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumSize(800, 600)
        self.camera = Camera()
        self.edges: List[Edge] = []  # Store edges/lines instead of primitives
        self.faces: List[Face] = []  # Store detected faces
        self.next_id = 0
        
        self.tool_mode = ToolMode.SELECT
        self.selected_edges: set = set()  # Selected edge IDs
        self.selected_faces: set = set()  # Selected face IDs
        
        # Drawing state
        self.draw_start_point: Optional[Vector3] = None
        
        # Mouse interaction
        self.last_mouse_pos = QPoint()
        self.is_rotating = False
        self.is_panning = False
        self.is_zooming = False
        
        # Grid snapping
        self.grid_snap = True
        self.grid_size = 1.0
        self.show_grid = True
        self.show_edges = True
        self.fast_mode = True  # Use VBOs when available
        self.use_moderngl = True and HAS_MGL
        
        # Axis constraints
        self.x_constraint = False
        self.y_constraint = False
        self.z_constraint = False
        
        # Undo/Redo
        self.undo_stack: deque = deque(maxlen=100)
        self.redo_stack: deque = deque(maxlen=100)
        
        # 3D cursor
        self.cursor_3d = Vector3(0, 0, 0)
        self.cursor_depth = 10.0  # Distance along ray for 3D cursor positioning
        
        # Inference system (SketchUp-style)
        self.inference_point: Optional[Vector3] = None  # Last clicked point for inference
        self.locked_axis: Optional[str] = None  # 'x', 'y', 'z', or None
        self.show_inference = True
        self.previous_cursor_3d = Vector3(0, 0, 0)  # Fallback for edge cases
        
        # Selection manipulation
        self.is_manipulating = False
        self.manipulation_start = None
        self.selected_primitive = None
        
        # Primitive creation
        self.creation_primitive_type = PrimitiveType.CUBE
        
        # WASD movement controls
        self.move_keys = {
            Qt.Key_W: False,
            Qt.Key_A: False,
            Qt.Key_S: False,
            Qt.Key_D: False,
            Qt.Key_Space: False,
        }
        self.is_shift_pressed = False  # Track Shift separately for movement down
        self.move_speed = 5.0  # Units per second
        
        # Movement timer
        self.move_timer = QTimer()
        self.move_timer.timeout.connect(self._update_movement)
        self.move_timer.start(16)  # ~60 FPS
        
        # Middle click tracking
        self.middle_click_time = None
        self.middle_click_pos = None
        
        self.setMouseTracking(True)
        self.setFocusPolicy(Qt.StrongFocus)

        # --------- Cached GL display lists for performance ---------
        self._edge_list_id = 0
        self._face_list_id = 0
        self._grid_list_id = 0
        self._geometry_dirty = True  # Rebuild lists when geometry changes

        # --------- VBO buffers (fast path) ---------
        self._tri_vbo = None
        self._nrm_vbo = None
        self._line_vbo = None
        self._tri_count = 0
        self._line_vertex_count = 0

        # ModernGL resources
        self._mgl_ctx = None
        self._mgl_prog = None
        self._mgl_vao = None
        self._mgl_pos = None
        self._mgl_nrm = None
        self._mgl_tri_count = 0
    
    def initializeGL(self):
        """Initialize OpenGL or ModernGL"""
        if self.use_moderngl and HAS_MGL:
            # ModernGL grabs the active context created by Qt
            self._mgl_ctx = mgl.create_context()
            self._mgl_ctx.enable(mgl.DEPTH_TEST | mgl.CULL_FACE)
            self._build_mgl_program()
        else:
            glEnable(GL_DEPTH_TEST)
            glEnable(GL_LIGHTING)
            glEnable(GL_LIGHT0)
            glEnable(GL_COLOR_MATERIAL)
            glColorMaterial(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE)
            
            # Keep culling enabled for floor/sky, we'll disable it only for user faces
            glEnable(GL_CULL_FACE)
            glCullFace(GL_BACK)  # Cull back faces (default)
            
            # Set up lighting
            glLightfv(GL_LIGHT0, GL_POSITION, [5.0, 10.0, 5.0, 1.0])
            glLightfv(GL_LIGHT0, GL_AMBIENT, [0.3, 0.3, 0.3, 1.0])
            glLightfv(GL_LIGHT0, GL_DIFFUSE, [0.8, 0.8, 0.8, 1.0])
            glLightfv(GL_LIGHT0, GL_SPECULAR, [1.0, 1.0, 1.0, 1.0])
            
            glClearColor(0.4, 0.5, 0.55, 1.0)  # Light blue-gray sky (matches drawn sky)

        # Build grid once as a display list for performance
        if not self.use_moderngl and self._grid_list_id == 0:
            self._grid_list_id = glGenLists(1)
            glNewList(self._grid_list_id, GL_COMPILE)
            self._compile_grid()
            glEndList()
    
    def resizeGL(self, width, height):
        """Handle window resize"""
        if self.use_moderngl and HAS_MGL:
            # ModernGL viewport set in paintGL
            pass
        else:
            glViewport(0, 0, width, height)
            self.camera.set_projection(width, height)
    
    def paintGL(self):
        """Render the scene"""
        if self.use_moderngl and HAS_MGL:
            self._mgl_ctx.clear(0.4, 0.5, 0.55, 1.0, depth=1.0)
            width, height = self.width(), self.height()
            self._mgl_ctx.viewport = (0, 0, width, height)
        else:
            glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
        
        # Clear to sky color first
        glClearColor(0.4, 0.5, 0.55, 1.0)  # Light blue-gray sky
        
        if not self.use_moderngl or not HAS_MGL:
            self.camera.set_view()
        
        # Draw infinite sky FIRST (background)
        if not self.use_moderngl:
            self._draw_sky()
        
        # Draw infinite green floor
        if not self.use_moderngl:
            self._draw_floor()
        
        # Draw grid
        if self.show_grid:
            self._draw_grid()
        
        # Draw axes
        self._draw_axes()
        
        # Draw filled faces for closed polygons
        if (not self.use_moderngl and self.fast_mode and HAS_VBO):
            # Rebuild GPU buffers if needed
            if self._geometry_dirty:
                self._rebuild_gpu_buffers()
                self._geometry_dirty = False
            self._draw_vbo_faces()
        elif not self.use_moderngl:
            self._draw_faces()
        else:
            # ModernGL path
            if self._geometry_dirty:
                self._rebuild_mgl_buffers()
                self._geometry_dirty = False
            self._draw_mgl()
        
        # Draw edges/lines
        # If geometry was modified, rebuild edge list now
        if self._geometry_dirty:
            if self._edge_list_id != 0:
                # Rebuild edge list display list
                glNewList(self._edge_list_id, GL_COMPILE)
                self._compile_edges()
                glEndList()
            if self._face_list_id != 0:
                # Faces rebuilt in _draw_faces already using COMPILE_AND_EXECUTE
                pass
            self._geometry_dirty = False
        if self.show_edges and not self.use_moderngl:
            if self.fast_mode and HAS_VBO:
                # Build line VBO together with triangles
                self._draw_vbo_edges()
            else:
                self._draw_edges()
        
        # Draw 3D cursor
        self._draw_3d_cursor()
        
        # Draw temporary line while drawing
        if self.draw_start_point:
            self._draw_temp_line()
    
    def _draw_floor(self):
        """Draw infinite green floor"""
        if self.use_moderngl and HAS_MGL:
            # Optional: draw a simple plane in ModernGL later
            return
        glDisable(GL_LIGHTING)
        glDisable(GL_CULL_FACE)  # Ensure floor is visible from both sides
        glBegin(GL_QUADS)
        glColor3f(0.5, 0.9, 0.5)  # Bright green
        size = 1000.0
        glVertex3f(-size, 0, -size)
        glVertex3f(size, 0, -size)
        glVertex3f(size, 0, size)
        glVertex3f(-size, 0, size)
        glEnd()
        glEnable(GL_CULL_FACE)
        glEnable(GL_LIGHTING)
    
    def _draw_sky(self):
        """Draw infinite sky"""
        if self.use_moderngl and HAS_MGL:
            # Clear color acts as sky in ModernGL path
            return
        glDisable(GL_LIGHTING)  # Ensure sky is not affected by lighting
        glDisable(GL_CULL_FACE)  # Ensure sky is visible from both sides
        glDisable(GL_DEPTH_TEST)  # Sky should always be in background
        glBegin(GL_QUADS)
        glColor3f(0.4, 0.5, 0.55)
        size = 1000.0
        height = 500.0
        glVertex3f(-size, height, -size)
        glVertex3f(size, height, -size)
        glVertex3f(size, height, size)
        glVertex3f(-size, height, size)
        glEnd()
        glEnable(GL_DEPTH_TEST)
        glEnable(GL_CULL_FACE)
        glEnable(GL_LIGHTING)
    
    def _draw_grid(self):
        """Draw grid on the floor"""
        # Call precompiled grid list for performance
        glDisable(GL_LIGHTING)
        glCallList(self._grid_list_id)
        glEnable(GL_LIGHTING)

    def _compile_grid(self):
        """Compile the static grid into the current display list"""
        glColor3f(0.5, 0.5, 0.5)
        glLineWidth(1.0)
        grid_size = 50
        spacing = 5.0
        glBegin(GL_LINES)
        for i in range(-grid_size, grid_size + 1):
            offset = i * spacing
            # Lines along X axis
            glVertex3f(-grid_size * spacing, 0.01, offset)
            glVertex3f(grid_size * spacing, 0.01, offset)
            # Lines along Z axis
            glVertex3f(offset, 0.01, -grid_size * spacing)
            glVertex3f(offset, 0.01, grid_size * spacing)
        glEnd()
    
    def _draw_axes(self):
        """Draw XYZ axes"""
        glDisable(GL_LIGHTING)
        glLineWidth(3.0)
        
        glBegin(GL_LINES)
        # X axis - Red
        glColor3f(1.0, 0.0, 0.0)
        glVertex3f(0, 0, 0)
        glVertex3f(10, 0, 0)
        # Y axis - Green
        glColor3f(0.0, 1.0, 0.0)
        glVertex3f(0, 0, 0)
        glVertex3f(0, 10, 0)
        # Z axis - Blue
        glColor3f(0.0, 0.0, 1.0)
        glVertex3f(0, 0, 0)
        glVertex3f(0, 0, 10)
        glEnd()
        glEnable(GL_LIGHTING)
    
    def _find_closed_loops(self) -> List[List[Vector3]]:
        """
        Find closed loops/polygons from edges.
        Returns a list of vertex lists representing closed polygons.
        Improved algorithm for better reliability.
        """
        if not self.edges or len(self.edges) < 3:
            return []
        
        def vertex_key(v):
            # For grid-snapped values, round to nearest grid position
            if self.grid_snap:
                return (
                    round(v.x / self.grid_size) * self.grid_size,
                    round(v.y / self.grid_size) * self.grid_size,
                    round(v.z / self.grid_size) * self.grid_size
                )
            else:
                # Otherwise use a reasonable epsilon for floating point comparison
                epsilon = 0.001
                return (
                    round(v.x / epsilon) * epsilon,
                    round(v.y / epsilon) * epsilon,
                    round(v.z / epsilon) * epsilon
                )
        
        # Build adjacency information
        vertex_to_edges = {}  # vertex_key -> list of edge indices
        edge_connections = {}  # edge_index -> (start_key, end_key, start_vertex, end_vertex)
        
        for i, edge in enumerate(self.edges):
            start_key = vertex_key(edge.start)
            end_key = vertex_key(edge.end)
            
            # Store edge information
            edge_connections[i] = (start_key, end_key, edge.start, edge.end)
            
            # Build adjacency lists
            if start_key not in vertex_to_edges:
                vertex_to_edges[start_key] = []
            if end_key not in vertex_to_edges:
                vertex_to_edges[end_key] = []
            
            vertex_to_edges[start_key].append(i)
            vertex_to_edges[end_key].append(i)
        
        # Find all closed loops using DFS
        found_loops = []
        used_edges_global = set()
        
        # Start from each edge
        for start_edge_idx in range(len(self.edges)):
            if start_edge_idx in used_edges_global:
                continue
                
            start_key, end_key, start_v, end_v = edge_connections[start_edge_idx]
            
            # Try both directions
            for direction in [(start_key, end_key, start_v, end_v), (end_key, start_key, end_v, start_v)]:
                origin_key, current_key, origin_v, current_v = direction
                
                path = [origin_v, current_v]
                path_keys = [origin_key, current_key]
                used_edges = {start_edge_idx}
                
                # Try to complete the loop
                loop_found = False
                max_edges = len(self.edges)
                
                while len(used_edges) < max_edges:
                    # Find next edge from current vertex
                    next_edge_idx = None
                    next_key = None
                    next_vertex = None
                    
                    for edge_idx in vertex_to_edges.get(current_key, []):
                        if edge_idx in used_edges:
                            continue
                            
                        e_start_key, e_end_key, e_start_v, e_end_v = edge_connections[edge_idx]
                        
                        if e_start_key == current_key:
                            # Can we close the loop?
                            if e_end_key == origin_key and len(path) >= 3:
                                # Found a closed loop!
                                found_loops.append(path.copy())
                                used_edges_global.update(used_edges)
                                used_edges_global.add(edge_idx)
                                loop_found = True
                                break
                            # Continue the path
                            elif e_end_key not in path_keys[1:-1]:  # Avoid self-intersection except at origin
                                next_edge_idx = edge_idx
                                next_key = e_end_key
                                next_vertex = e_end_v
                                break
                        elif e_end_key == current_key:
                            # Can we close the loop?
                            if e_start_key == origin_key and len(path) >= 3:
                                # Found a closed loop!
                                found_loops.append(path.copy())
                                used_edges_global.update(used_edges)
                                used_edges_global.add(edge_idx)
                                loop_found = True
                                break
                            # Continue the path
                            elif e_start_key not in path_keys[1:-1]:  # Avoid self-intersection except at origin
                                next_edge_idx = edge_idx
                                next_key = e_start_key
                                next_vertex = e_start_v
                                break
                    
                    if loop_found:
                        break
                        
                    if next_edge_idx is None:
                        # Dead end
                        break
                    
                    # Continue path
                    path.append(next_vertex)
                    path_keys.append(next_key)
                    used_edges.add(next_edge_idx)
                    current_key = next_key
                    current_v = next_vertex
                
                if loop_found:
                    break
        
        return found_loops
    
    def _calculate_face_normal(self, vertices: List[Vector3]) -> Vector3:
        """Calculate normal vector for a face (for proper lighting)"""
        if len(vertices) < 3:
            return Vector3(0, 1, 0)
        
        # Use first three vertices to calculate normal
        v1 = vertices[1] - vertices[0]
        v2 = vertices[2] - vertices[0]
        normal = v1.cross(v2)
        return normal.normalize()
    
    def _ensure_consistent_winding(self, vertices: List[Vector3]) -> List[Vector3]:
        """
        Ensure vertices are in counter-clockwise order when viewed from the front.
        Uses the normal to determine correct winding order.
        Improved to handle coplanar faces properly.
        """
        if len(vertices) < 3:
            return vertices
        
        # Calculate normal from first three vertices
        v1 = vertices[1] - vertices[0]
        v2 = vertices[2] - vertices[0]
        normal = v1.cross(v2)
        
        # If normal is zero or very small, try different vertices
        if normal.length() < 1e-6:
            # Try next set of vertices
            if len(vertices) >= 4:
                v1 = vertices[2] - vertices[0]
                v2 = vertices[3] - vertices[0]
                normal = v1.cross(v2)
        
        # If still zero, return as-is (degenerate face)
        if normal.length() < 1e-6:
            return vertices
        
        normal = normal.normalize()
        
        # Calculate centroid
        centroid = Vector3(0, 0, 0)
        for v in vertices:
            centroid = centroid + v
        centroid = centroid * (1.0 / len(vertices))
        
        # Calculate signed area using the normal
        # For proper winding, we want the area to be positive when viewed from the front
        total_area = 0.0
        for i in range(len(vertices)):
            v1 = vertices[i] - centroid
            v2 = vertices[(i + 1) % len(vertices)] - centroid
            cross = v1.cross(v2)
            total_area += cross.dot(normal)
        
        # If area is negative, vertices are clockwise - reverse them
        if total_area < 0:
            return list(reversed(vertices))
        
        return vertices
    
    def _triangulate_polygon(self, vertices: List[Vector3]) -> List[Tuple[Vector3, Vector3, Vector3]]:
        """
        Triangulate a polygon ensuring consistent winding order.
        Returns list of triangles (each triangle is a tuple of 3 vertices).
        All triangles will have consistent counter-clockwise winding when viewed from the front.
        """
        if len(vertices) < 3:
            return []
        
        # Ensure consistent winding BEFORE triangulation
        vertices = self._ensure_consistent_winding(vertices)
        
        # For simple polygons (quads, triangles), use simple triangulation
        if len(vertices) == 3:
            return [(vertices[0], vertices[1], vertices[2])]
        elif len(vertices) == 4:
            # Quad: split into two triangles with consistent winding
            # Both triangles must follow the same CCW order
            # Triangle 1: v0 -> v1 -> v2
            # Triangle 2: v0 -> v2 -> v3
            # This ensures both triangles share edge v0-v2 and maintain CCW winding
            return [
                (vertices[0], vertices[1], vertices[2]),
                (vertices[0], vertices[2], vertices[3])
            ]
        else:
            # Fan triangulation for polygons with more vertices
            # All triangles share first vertex, maintaining consistent CCW winding
            triangles = []
            for i in range(1, len(vertices) - 1):
                triangles.append((
                    vertices[0],
                    vertices[i],
                    vertices[i + 1]
                ))
            
            return triangles
    
    def _detect_faces(self):
        """Detect and store faces from closed loops - improved for 3D shapes"""
        loops = self._find_closed_loops()
        self.faces.clear()
        
        # If no loops found, return early
        if not loops:
            return
        
        # Remove duplicate loops and ensure proper orientation
        unique_loops = []
        for loop in loops:
            if len(loop) < 3:
                continue
            
            # Ensure consistent winding order first
            loop = self._ensure_consistent_winding(loop)
            
            # Calculate face normal to determine which side is "outward"
            normal = self._calculate_face_normal(loop)
            
            # For each face, check if we already have a face with the same vertices
            # We'll check by comparing vertices (allowing for rotation)
            is_duplicate = False
            for existing_loop in unique_loops:
                if len(existing_loop) != len(loop):
                    continue
                
                # Check if all vertices match (allowing for rotation)
                matched_all = True
                for v in loop:
                    found_match = False
                    for ev in existing_loop:
                        if (v - ev).length() < 1e-5:
                            found_match = True
                            break
                    if not found_match:
                        matched_all = False
                        break
                
                if matched_all:
                    # Check if normals point in opposite directions (same face, different side)
                    existing_normal = self._calculate_face_normal(existing_loop)
                    dot_product = normal.dot(existing_normal)
                    if dot_product < -0.5:  # Opposite normals (same face, other side)
                        # This is the same face from the other side - skip it
                        is_duplicate = True
                        break
                    elif dot_product > 0.5:  # Same normal direction
                        # Same face, same side - definitely duplicate
                        is_duplicate = True
                        break
                    # If dot product is between -0.5 and 0.5, they're different faces
            
            if not is_duplicate:
                unique_loops.append(loop)
        
        face_id = 0
        for loop in unique_loops:
            # Create new face with proper winding
            # Default color is a light blue-gray
            face = Face(vertices=loop, id=face_id, color=(0.7, 0.8, 0.85))
            self.faces.append(face)
            face_id += 1
        
        # Emit signal if faces were created
        if self.faces:
            self.sceneChanged.emit()
        # mark geometry cache dirty (faces changed)
        self._geometry_dirty = True
    
    def _draw_faces(self):
        """Draw filled faces for closed polygons"""
        # Regenerate faces if needed
        if not self.faces:
            self._detect_faces()
        
        if not self.faces:
            return
        
        glEnable(GL_LIGHTING)
        # Disable blending for opaque faces
        glDisable(GL_BLEND)
        glColorMaterial(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE)
        # With triangulated faces and consistent winding we can enable culling
        # for much better performance
        glEnable(GL_CULL_FACE)

        # Use display list for faces if available and not dirty
        if not self._geometry_dirty and self._face_list_id != 0:
            glCallList(self._face_list_id)
            return
        
        # Rebuild list when geometry changed
        if self._face_list_id == 0:
            self._face_list_id = glGenLists(1)
        glNewList(self._face_list_id, GL_COMPILE_AND_EXECUTE)
        
        # Draw each face
        for face in self.faces:
            if len(face.vertices) < 3:
                continue
            
            # Ensure consistent winding order (fresh calculation)
            loop = self._ensure_consistent_winding(face.vertices.copy())
            
            # Triangulate the polygon - this returns triangles with consistent winding
            triangles = self._triangulate_polygon(loop)
            
            # Use face color
            face_color = face.color
            is_selected = face.id in self.selected_faces
            
            # Draw each triangle with proper normal
            for triangle in triangles:
                # Calculate triangle-specific normal for better lighting
                # Ensure normal points outward (consistent with winding)
                tri_normal = self._calculate_face_normal(list(triangle))
                
                glBegin(GL_TRIANGLES)
                # Set normal - ensures consistent lighting
                glNormal3f(tri_normal.x, tri_normal.y, tri_normal.z)
                
                # Set color
                if is_selected:
                    glColor4f(1.0, 0.9, 0.3, 1.0)  # Bright yellow when selected (opaque)
                else:
                    glColor4f(face_color[0], face_color[1], face_color[2], 1.0)  # Fully opaque
                
                # Draw triangle vertices in consistent CCW order
                # This order matches the winding we ensured in triangulation
                glVertex3f(triangle[0].x, triangle[0].y, triangle[0].z)
                glVertex3f(triangle[1].x, triangle[1].y, triangle[1].z)
                glVertex3f(triangle[2].x, triangle[2].y, triangle[2].z)
                
                glEnd()
        
        glEnable(GL_CULL_FACE)
        glEndList()
    
    def _draw_edges(self):
        """Draw all edges/lines"""
        glDisable(GL_LIGHTING)
        # For large meshes, use display lists and a single pass
        large_mesh = len(self.edges) > 800
        
        if not large_mesh and (self._geometry_dirty or self._edge_list_id == 0):
            # Build/refresh edge list
            if self._edge_list_id == 0:
                self._edge_list_id = glGenLists(1)
            glNewList(self._edge_list_id, GL_COMPILE)
            self._compile_edges()
            glEndList()
        
        if not large_mesh and self._edge_list_id != 0:
            glCallList(self._edge_list_id)
        else:
            # Fallback immediate mode for extremely large meshes (one pass)
            glLineWidth(2.0)
            glBegin(GL_LINES)
            for edge in self.edges:
                if edge.id in self.selected_edges:
                    glColor3f(1.0, 0.8, 0.0)
                else:
                    if hasattr(edge, 'color'):
                        glColor3f(*edge.color)
                    else:
                        glColor3f(0.0, 1.0, 1.0)
                glVertex3f(edge.start.x, max(edge.start.y, 0.005), edge.start.z)
                glVertex3f(edge.end.x, max(edge.end.y, 0.005), edge.end.z)
            glEnd()
        glEnable(GL_LIGHTING)

    def _compile_edges(self):
        """Compile current edges into the current display list"""
        # Outline pass
        glLineWidth(5.0)
        glColor3f(0.1, 0.1, 0.1)
        glBegin(GL_LINES)
        for edge in self.edges:
            glVertex3f(edge.start.x, max(edge.start.y, 0.005), edge.start.z)
            glVertex3f(edge.end.x, max(edge.end.y, 0.005), edge.end.z)
        glEnd()
        # Color pass
        glLineWidth(3.0)
        glBegin(GL_LINES)
        for edge in self.edges:
            if edge.id in self.selected_edges:
                glColor3f(1.0, 0.8, 0.0)
            else:
                if hasattr(edge, 'color'):
                    glColor3f(*edge.color)
                else:
                    glColor3f(0.0, 1.0, 1.0)
            glVertex3f(edge.start.x, max(edge.start.y, 0.01), edge.start.z)
            glVertex3f(edge.end.x, max(edge.end.y, 0.01), edge.end.z)
        glEnd()

    # -------------------- VBO rendering (fast path) --------------------
    def _rebuild_gpu_buffers(self):
        """Build VBOs for triangles and edges from current faces/edges."""
        if not HAS_VBO:
            return
        # Build triangle arrays from faces (triangulate)
        tri_positions = []
        tri_normals = []
        for face in self.faces:
            if len(face.vertices) < 3:
                continue
            loop = self._ensure_consistent_winding(face.vertices.copy())
            triangles = self._triangulate_polygon(loop)
            for tri in triangles:
                n = self._calculate_face_normal(list(tri))
                for v in tri:
                    tri_positions.extend([v.x, v.y, v.z])
                    tri_normals.extend([n.x, n.y, n.z])
        
        if tri_positions:
            pos_arr = np.array(tri_positions, dtype=np.float32)
            nrm_arr = np.array(tri_normals, dtype=np.float32)
            self._tri_count = len(tri_positions) // 3
            if self._tri_vbo is None:
                self._tri_vbo = vbo.VBO(pos_arr)
                self._nrm_vbo = vbo.VBO(nrm_arr)
            else:
                self._tri_vbo.set_array(pos_arr)
                self._nrm_vbo.set_array(nrm_arr)
        else:
            self._tri_count = 0
        
        # Build edge array
        line_positions = []
        for edge in self.edges:
            line_positions.extend([edge.start.x, edge.start.y, edge.start.z])
            line_positions.extend([edge.end.x, edge.end.y, edge.end.z])
        if line_positions:
            line_arr = np.array(line_positions, dtype=np.float32)
            self._line_vertex_count = len(line_positions) // 3
            if self._line_vbo is None:
                self._line_vbo = vbo.VBO(line_arr)
            else:
                self._line_vbo.set_array(line_arr)
        else:
            self._line_vertex_count = 0

    def _draw_vbo_faces(self):
        if not HAS_VBO or self._tri_count == 0:
            return
        glEnable(GL_LIGHTING)
        glEnable(GL_CULL_FACE)
        glColor3f(0.7, 0.8, 0.85)
        self._tri_vbo.bind()
        glEnableClientState(GL_VERTEX_ARRAY)
        glVertexPointer(3, GL_FLOAT, 0, self._tri_vbo)
        self._nrm_vbo.bind()
        glEnableClientState(GL_NORMAL_ARRAY)
        glNormalPointer(GL_FLOAT, 0, self._nrm_vbo)
        glDrawArrays(GL_TRIANGLES, 0, self._tri_count)
        glDisableClientState(GL_NORMAL_ARRAY)
        self._nrm_vbo.unbind()
        glDisableClientState(GL_VERTEX_ARRAY)
        self._tri_vbo.unbind()

    def _draw_vbo_edges(self):
        if not HAS_VBO or self._line_vertex_count == 0:
            return
        glDisable(GL_LIGHTING)
        glLineWidth(2.0)
        glColor3f(0.0, 1.0, 1.0)
        self._line_vbo.bind()
        glEnableClientState(GL_VERTEX_ARRAY)
        glVertexPointer(3, GL_FLOAT, 0, self._line_vbo)
        glDrawArrays(GL_LINES, 0, self._line_vertex_count)
        glDisableClientState(GL_VERTEX_ARRAY)
        self._line_vbo.unbind()
        glEnable(GL_LIGHTING)
    
    def _draw_temp_line(self):
        """Draw temporary line preview while drawing with inference lines"""
        if not self.draw_start_point:
            return
        
        glDisable(GL_LIGHTING)
        glDisable(GL_DEPTH_TEST)  # Ensure preview line is always visible
        
        # Check if we're about to close a loop
        closing_loop = False
        if self.inference_point and len(self.edges) >= 2:
            dist_to_start = (self.cursor_3d - self.inference_point).length()
            if dist_to_start < self.grid_size * 0.5:
                closing_loop = True
        
        # Draw main preview line (thicker and brighter)
        glLineWidth(5.0 if closing_loop else 4.0)
        if closing_loop:
            glColor3f(0.0, 1.0, 0.0)  # Green when closing loop
        else:
            glColor3f(1.0, 1.0, 0.0)  # Bright yellow for visibility
        
        glBegin(GL_LINES)
        glVertex3f(self.draw_start_point.x, self.draw_start_point.y, self.draw_start_point.z)
        if closing_loop:
            # Snap to inference point visually
            glVertex3f(self.inference_point.x, self.inference_point.y, self.inference_point.z)
        else:
            glVertex3f(self.cursor_3d.x, self.cursor_3d.y, self.cursor_3d.z)
        glEnd()
        
        # Draw inference lines (SketchUp-style)
        if self.show_inference:
            glLineWidth(2.0)
            
            # If axis is locked, only show the locked axis line
            if self.locked_axis == 'x':
                glColor3f(1.0, 0.3, 0.3)  # Bright red
                glBegin(GL_LINES)
                glVertex3f(self.draw_start_point.x, self.draw_start_point.y, self.draw_start_point.z)
                glVertex3f(self.cursor_3d.x, self.draw_start_point.y, self.draw_start_point.z)
                glEnd()
            elif self.locked_axis == 'y':
                glColor3f(0.3, 1.0, 0.3)  # Bright green
                glBegin(GL_LINES)
                glVertex3f(self.draw_start_point.x, self.draw_start_point.y, self.draw_start_point.z)
                glVertex3f(self.draw_start_point.x, self.cursor_3d.y, self.draw_start_point.z)
                glEnd()
            elif self.locked_axis == 'z':
                glColor3f(0.3, 0.3, 1.0)  # Bright blue
                glBegin(GL_LINES)
                glVertex3f(self.draw_start_point.x, self.draw_start_point.y, self.draw_start_point.z)
                glVertex3f(self.draw_start_point.x, self.draw_start_point.y, self.cursor_3d.z)
                glEnd()
            else:
                # No axis locked - show all inference lines
                glLineWidth(1.5)
                # X axis inference (red)
                glColor3f(1.0, 0.0, 0.0)
                glBegin(GL_LINES)
                glVertex3f(self.draw_start_point.x, self.draw_start_point.y, self.draw_start_point.z)
                glVertex3f(self.cursor_3d.x, self.draw_start_point.y, self.draw_start_point.z)
                glEnd()
                
                # Y axis inference (green)
                glColor3f(0.0, 1.0, 0.0)
                glBegin(GL_LINES)
                glVertex3f(self.draw_start_point.x, self.draw_start_point.y, self.draw_start_point.z)
                glVertex3f(self.draw_start_point.x, self.cursor_3d.y, self.draw_start_point.z)
                glEnd()
                
                # Z axis inference (blue)
                glColor3f(0.0, 0.0, 1.0)
                glBegin(GL_LINES)
                glVertex3f(self.draw_start_point.x, self.draw_start_point.y, self.draw_start_point.z)
                glVertex3f(self.draw_start_point.x, self.draw_start_point.y, self.cursor_3d.z)
                glEnd()
        
        glEnable(GL_DEPTH_TEST)
        glEnable(GL_LIGHTING)
    
    def _draw_primitive(self, primitive: Primitive):
        """Draw a 3D primitive"""
        glPushMatrix()
        
        # Apply transform
        glTranslatef(primitive.transform.position.x,
                     primitive.transform.position.y,
                     primitive.transform.position.z)
        glRotatef(primitive.transform.rotation.x, 1, 0, 0)
        glRotatef(primitive.transform.rotation.y, 0, 1, 0)
        glRotatef(primitive.transform.rotation.z, 0, 0, 1)
        glScalef(primitive.transform.scale.x,
                 primitive.transform.scale.y,
                 primitive.transform.scale.z)
        
        # Set color
        if primitive.selected:
            glColor3f(1.0, 0.8, 0.0)  # Yellow when selected
        else:
            glColor3f(*primitive.color)
        
        # Draw based on type
        if primitive.type == PrimitiveType.CUBE:
            self._draw_cube()
        elif primitive.type == PrimitiveType.SPHERE:
            self._draw_sphere()
        elif primitive.type == PrimitiveType.CYLINDER:
            self._draw_cylinder()
        elif primitive.type == PrimitiveType.PLANE:
            self._draw_plane()
        
        glPopMatrix()
    
    def _draw_cube(self):
        """Draw a cube"""
        size = 1.0
        s = size / 2
        
        glBegin(GL_QUADS)
        # Front
        glNormal3f(0, 0, 1)
        glVertex3f(-s, -s, s)
        glVertex3f(s, -s, s)
        glVertex3f(s, s, s)
        glVertex3f(-s, s, s)
        # Back
        glNormal3f(0, 0, -1)
        glVertex3f(-s, -s, -s)
        glVertex3f(-s, s, -s)
        glVertex3f(s, s, -s)
        glVertex3f(s, -s, -s)
        # Top
        glNormal3f(0, 1, 0)
        glVertex3f(-s, s, -s)
        glVertex3f(-s, s, s)
        glVertex3f(s, s, s)
        glVertex3f(s, s, -s)
        # Bottom
        glNormal3f(0, -1, 0)
        glVertex3f(-s, -s, -s)
        glVertex3f(s, -s, -s)
        glVertex3f(s, -s, s)
        glVertex3f(-s, -s, s)
        # Right
        glNormal3f(1, 0, 0)
        glVertex3f(s, -s, -s)
        glVertex3f(s, s, -s)
        glVertex3f(s, s, s)
        glVertex3f(s, -s, s)
        # Left
        glNormal3f(-1, 0, 0)
        glVertex3f(-s, -s, -s)
        glVertex3f(-s, -s, s)
        glVertex3f(-s, s, s)
        glVertex3f(-s, s, -s)
        glEnd()
    
    def _draw_sphere(self, radius=1.0, slices=20, stacks=20):
        """Draw a sphere"""
        import math
        for i in range(stacks):
            lat1 = math.pi * (-0.5 + i / stacks)
            lat2 = math.pi * (-0.5 + (i + 1) / stacks)
            
            glBegin(GL_QUAD_STRIP)
            for j in range(slices + 1):
                lng = 2 * math.pi * j / slices
                x1 = math.cos(lat1) * math.cos(lng)
                y1 = math.sin(lat1)
                z1 = math.cos(lat1) * math.sin(lng)
                x2 = math.cos(lat2) * math.cos(lng)
                y2 = math.sin(lat2)
                z2 = math.cos(lat2) * math.sin(lng)
                
                glNormal3f(x1, y1, z1)
                glVertex3f(radius * x1, radius * y1, radius * z1)
                glNormal3f(x2, y2, z2)
                glVertex3f(radius * x2, radius * y2, radius * z2)
            glEnd()
    
    def _draw_cylinder(self, radius=1.0, height=2.0, slices=20):
        """Draw a cylinder"""
        import math
        glBegin(GL_QUAD_STRIP)
        for i in range(slices + 1):
            angle = 2 * math.pi * i / slices
            x = math.cos(angle)
            z = math.sin(angle)
            glNormal3f(x, 0, z)
            glVertex3f(radius * x, height / 2, radius * z)
            glVertex3f(radius * x, -height / 2, radius * z)
        glEnd()
        
        # Top cap
        glBegin(GL_TRIANGLE_FAN)
        glNormal3f(0, 1, 0)
        glVertex3f(0, height / 2, 0)
        for i in range(slices + 1):
            angle = 2 * math.pi * i / slices
            glVertex3f(radius * math.cos(angle), height / 2, radius * math.sin(angle))
        glEnd()
        
        # Bottom cap
        glBegin(GL_TRIANGLE_FAN)
        glNormal3f(0, -1, 0)
        glVertex3f(0, -height / 2, 0)
        for i in range(slices + 1):
            angle = 2 * math.pi * i / slices
            glVertex3f(radius * math.cos(angle), -height / 2, radius * math.sin(angle))
        glEnd()
    
    def _draw_plane(self):
        """Draw a plane"""
        size = 1.0
        s = size / 2
        
        glBegin(GL_QUADS)
        glNormal3f(0, 1, 0)
        glVertex3f(-s, 0, -s)
        glVertex3f(s, 0, -s)
        glVertex3f(s, 0, s)
        glVertex3f(-s, 0, s)
        glEnd()
    
    def _draw_selection_handles(self):
        """Draw selection handles for selected objects"""
        glDisable(GL_LIGHTING)
        glLineWidth(2.0)
        
        for prim_id in self.selected_primitives:
            primitive = next((p for p in self.primitives if p.id == prim_id), None)
            if primitive:
                pos = primitive.transform.position
                size = max(primitive.transform.scale.x,
                          primitive.transform.scale.y,
                          primitive.transform.scale.z) * 1.5
                
                glPushMatrix()
                glTranslatef(pos.x, pos.y, pos.z)
                
                # Draw bounding box
                glColor3f(1.0, 1.0, 1.0)
                glBegin(GL_LINE_LOOP)
                glVertex3f(-size, -size, -size)
                glVertex3f(size, -size, -size)
                glVertex3f(size, size, -size)
                glVertex3f(-size, size, -size)
                glEnd()
                
                glBegin(GL_LINE_LOOP)
                glVertex3f(-size, -size, size)
                glVertex3f(size, -size, size)
                glVertex3f(size, size, size)
                glVertex3f(-size, size, size)
                glEnd()
                
                glBegin(GL_LINES)
                glVertex3f(-size, -size, -size)
                glVertex3f(-size, -size, size)
                glVertex3f(size, -size, -size)
                glVertex3f(size, -size, size)
                glVertex3f(size, size, -size)
                glVertex3f(size, size, size)
                glVertex3f(-size, size, -size)
                glVertex3f(-size, size, size)
                glEnd()
                
                glPopMatrix()
        
        glEnable(GL_LIGHTING)
    
    def _draw_3d_cursor(self):
        """Draw 3D cursor indicator with snapping feedback"""
        glDisable(GL_LIGHTING)
        glDisable(GL_DEPTH_TEST)  # Always visible
        
        # Check if we're snapping to something
        snap_point = self._snap_to_geometry(self.cursor_3d, snap_distance=self.grid_size * 2)
        is_snapping = snap_point is not None
        
        # Draw snap indicator if snapping
        if is_snapping:
            glPushMatrix()
            glTranslatef(snap_point.x, snap_point.y, snap_point.z)
            
            # Draw a circle/dot at snap point
            glPointSize(10.0)
            glColor3f(0.0, 1.0, 0.0)  # Green for snap
            glBegin(GL_POINTS)
            glVertex3f(0, 0, 0)
            glEnd()
            
            # Draw snap circle
            glLineWidth(3.0)
            glBegin(GL_LINE_LOOP)
            import math
            for i in range(16):
                angle = 2.0 * math.pi * i / 16
                glVertex3f(0.3 * math.cos(angle), 0.3 * math.sin(angle), 0)
            glEnd()
            
            glPopMatrix()
        
        # Draw cursor crosshair
        glLineWidth(2.0)
        if is_snapping:
            glColor3f(0.0, 1.0, 0.0)  # Green when snapping
        else:
            glColor3f(1.0, 1.0, 0.0)  # Yellow normally
        
        size = 0.5
        glPushMatrix()
        glTranslatef(self.cursor_3d.x, self.cursor_3d.y, self.cursor_3d.z)
        
        glBegin(GL_LINES)
        glVertex3f(-size, 0, 0)
        glVertex3f(size, 0, 0)
        glVertex3f(0, -size, 0)
        glVertex3f(0, size, 0)
        glVertex3f(0, 0, -size)
        glVertex3f(0, 0, size)
        glEnd()
        
        glPopMatrix()
        glEnable(GL_DEPTH_TEST)
        glEnable(GL_LIGHTING)
    
    def _snap_to_grid(self, value: float) -> float:
        """Snap a value to the grid"""
        if self.grid_snap:
            return round(value / self.grid_size) * self.grid_size
        return value
    
    def _apply_axis_constraints(self, delta: Vector3) -> Vector3:
        """Apply axis constraints to movement"""
        if self.x_constraint:
            delta.y = 0
            delta.z = 0
        if self.y_constraint:
            delta.x = 0
            delta.z = 0
        if self.z_constraint:
            delta.x = 0
            delta.y = 0
        return delta
    
    def _get_mouse_ray(self, x: int, y: int) -> Tuple[Vector3, Vector3]:
        """Get ray from camera through mouse position"""
        width = self.width()
        height = self.height()
        
        if width == 0 or height == 0:
            return None, None
        
        # Normalize to [-1, 1] range
        nx = (2.0 * x) / width - 1.0
        ny = 1.0 - (2.0 * y) / height  # Flip Y
        
        # Calculate ray from camera through screen point
        forward = self.camera.get_forward()
        right = self.camera.get_right()
        up = self.camera.get_up()
        
        # Calculate FOV and aspect ratio
        fov_rad = math.radians(self.camera.fov)
        aspect = width / height if height > 0 else 1.0
        fov_factor = math.tan(fov_rad / 2.0)
        
        # Calculate ray direction in world space
        ray_dir = forward + right * (nx * fov_factor * aspect) + up * (ny * fov_factor)
        ray_dir = ray_dir.normalize()
        
        return self.camera.position, ray_dir
    
    def _intersect_ray_plane(self, ray_origin: Vector3, ray_dir: Vector3, 
                             plane_point: Vector3, plane_normal: Vector3, 
                             epsilon: float = 1e-6) -> Optional[Tuple[float, float]]:
        """
        Intersect ray with plane, return (t, parallel_factor) tuple.
        parallel_factor: 0 = perpendicular, 1 = parallel (higher = more parallel)
        Returns None if ray is too parallel or intersection is behind camera.
        """
        denom = ray_dir.dot(plane_normal)
        parallel_factor = abs(denom)
        
        if parallel_factor < epsilon:
            return None  # Ray is nearly parallel to plane
        
        to_plane = plane_point - ray_origin
        t = to_plane.dot(plane_normal) / denom
        
        if t >= 0:
            return (t, parallel_factor)
        return None
    
    def _closest_point_on_line_segment(self, point: Vector3, line_start: Vector3, line_end: Vector3) -> Vector3:
        """Find closest point on line segment to a given point"""
        line_dir = line_end - line_start
        line_len_sq = line_dir.length() ** 2
        
        if line_len_sq < 1e-10:
            return line_start  # Degenerate line segment
        
        t = (point - line_start).dot(line_dir) / line_len_sq
        t = max(0.0, min(1.0, t))  # Clamp to segment
        
        return line_start + line_dir * t
    
    def _intersect_line_segments(self, p1: Vector3, p2: Vector3, p3: Vector3, p4: Vector3) -> Optional[Vector3]:
        """Find intersection point of two line segments (if they intersect)"""
        # Line 1: p1 -> p2, Line 2: p3 -> p4
        d1 = p2 - p1
        d2 = p4 - p3
        d3 = p1 - p3
        
        # Check if lines are parallel
        cross = d1.cross(d2)
        cross_len_sq = cross.length() ** 2
        
        if cross_len_sq < 1e-10:
            return None  # Lines are parallel
        
        # Calculate intersection parameters
        t1 = d3.cross(d2).dot(cross) / cross_len_sq
        t2 = d3.cross(d1).dot(cross) / cross_len_sq
        
        # Check if intersection is within both segments
        if 0.0 <= t1 <= 1.0 and 0.0 <= t2 <= 1.0:
            return p1 + d1 * t1
        
        return None
    
    def _snap_to_geometry(self, point: Vector3, snap_distance: float = 2.0) -> Optional[Vector3]:
        """Snap to nearest vertex, edge endpoint, or point on line"""
        if not self.edges:
            return None
        
        nearest = None
        min_dist = snap_distance
        
        # Special handling for inference point (starting point when drawing)
        if self.inference_point and self.draw_start_point:
            dist = (point - self.inference_point).length()
            if dist < min_dist * 1.5:  # Slightly larger snap radius for closing loops
                min_dist = dist
                nearest = self.inference_point
        
        # Check all edge endpoints (vertices) - higher priority
        for edge in self.edges:
            for vertex in [edge.start, edge.end]:
                dist = (point - vertex).length()
                if dist < min_dist:
                    min_dist = dist
                    nearest = vertex
        
        # Check closest point on each edge segment (only if not already snapped to vertex)
        if nearest is None:
            for edge in self.edges:
                closest_on_edge = self._closest_point_on_line_segment(point, edge.start, edge.end)
                dist = (point - closest_on_edge).length()
                if dist < min_dist:
                    min_dist = dist
                    nearest = closest_on_edge
        
        return nearest
    
    def _find_line_intersections(self, ray_origin: Vector3, ray_dir: Vector3, 
                                  snap_distance: float = 2.0) -> Optional[Vector3]:
        """Find intersection of mouse ray with existing edges"""
        if not self.edges:
            return None
        
        nearest = None
        min_dist = snap_distance
        
        # Intersect ray with each edge
        for edge in self.edges:
            edge_dir = edge.end - edge.start
            edge_len = edge_dir.length()
            
            if edge_len < 1e-10:
                continue
            
            edge_dir_norm = edge_dir.normalize()
            
            # Find intersection of ray with line containing edge
            # Ray: ray_origin + t * ray_dir
            # Edge line: edge.start + s * edge_dir_norm
            
            # Check if ray and edge line are parallel
            cross = ray_dir.cross(edge_dir_norm)
            cross_len_sq = cross.length() ** 2
            
            if cross_len_sq < 1e-10:
                continue  # Parallel lines
            
            # Calculate intersection
            to_start = edge.start - ray_origin
            t = to_start.cross(edge_dir_norm).dot(cross) / cross_len_sq
            
            if t < 0:
                continue  # Intersection behind camera
            
            # Check if intersection is within edge segment
            intersection_point = ray_origin + ray_dir * t
            closest_on_edge = self._closest_point_on_line_segment(intersection_point, edge.start, edge.end)
            dist = (intersection_point - closest_on_edge).length()
            
            if dist < min_dist:
                min_dist = dist
                nearest = closest_on_edge
        
        return nearest
    
    def _screen_to_world_inference(self, x: int, y: int) -> Optional[Vector3]:
        """
        SketchUp-style inference: find closest intersection point with multiple candidates
        and fallback handling for edge cases.
        """
        ray_origin, ray_dir = self._get_mouse_ray(x, y)
        if ray_origin is None or ray_dir is None:
            return self.previous_cursor_3d  # Fallback to previous position
        
        candidates = []
        
        # 1. Intersect with floor plane (Y=0, XZ plane)
        floor_result = self._intersect_ray_plane(ray_origin, ray_dir, Vector3(0, 0, 0), Vector3(0, 1, 0))
        if floor_result is not None:
            t_floor, parallel_factor = floor_result
            point = ray_origin + ray_dir * t_floor
            priority = 1.0 / (parallel_factor + 1e-6)  # Higher priority for less parallel
            candidates.append((t_floor, point, priority, 'floor'))
        
        # 2. If drawing, intersect with planes through the start point
        if self.draw_start_point:
            start = self.draw_start_point
            
            # Horizontal plane through start point (parallel to XZ, constant Y)
            horizontal_result = self._intersect_ray_plane(ray_origin, ray_dir, start, Vector3(0, 1, 0))
            if horizontal_result is not None:
                t_horizontal, parallel_factor = horizontal_result
                point = ray_origin + ray_dir * t_horizontal
                # Higher priority if not locked to Y axis
                priority = 1.5 / (parallel_factor + 1e-6) if self.locked_axis != 'y' else 0.5 / (parallel_factor + 1e-6)
                candidates.append((t_horizontal, point, priority, 'horizontal'))
            
            # Vertical plane parallel to YZ through start (constant X)
            vertical_x_result = self._intersect_ray_plane(ray_origin, ray_dir, start, Vector3(1, 0, 0))
            if vertical_x_result is not None:
                t_vertical_x, parallel_factor = vertical_x_result
                point = ray_origin + ray_dir * t_vertical_x
                # Higher priority if locked to X axis
                priority = 2.0 / (parallel_factor + 1e-6) if self.locked_axis == 'x' else 1.0 / (parallel_factor + 1e-6)
                candidates.append((t_vertical_x, point, priority, 'vertical_x'))
            
            # Vertical plane parallel to XY through start (constant Z)
            vertical_z_result = self._intersect_ray_plane(ray_origin, ray_dir, start, Vector3(0, 0, 1))
            if vertical_z_result is not None:
                t_vertical_z, parallel_factor = vertical_z_result
                point = ray_origin + ray_dir * t_vertical_z
                # Higher priority if locked to Z axis
                priority = 2.0 / (parallel_factor + 1e-6) if self.locked_axis == 'z' else 1.0 / (parallel_factor + 1e-6)
                candidates.append((t_vertical_z, point, priority, 'vertical_z'))
        
        # 3. Apply axis locks before picking candidate
        if self.draw_start_point and self.locked_axis:
            start = self.draw_start_point
            # Project candidates onto locked axis
            for i, (t, point, priority, plane_type) in enumerate(candidates):
                if self.locked_axis == 'x':
                    point = Vector3(point.x, start.y, start.z)
                elif self.locked_axis == 'y':
                    point = Vector3(start.x, point.y, start.z)
                elif self.locked_axis == 'z':
                    point = Vector3(start.x, start.y, point.z)
                candidates[i] = (t, point, priority * 3.0, plane_type)  # Boost priority for locked axis
        
        # 4. Filter candidates: reject if too parallel (unless it's the only option)
        valid_candidates = [c for c in candidates if c[2] > 0.01]  # parallel_factor check
        if not valid_candidates:
            valid_candidates = candidates  # Use all candidates if none are valid
        
        # 5. Sort by priority (descending), then by distance (ascending)
        valid_candidates.sort(key=lambda x: (-x[2], x[0]))  # Higher priority first, then closer
        
        # 6. Pick best candidate
        if valid_candidates:
            best_t, best_point, best_priority, plane_type = valid_candidates[0]
            
            # Try to snap to line intersections first (highest priority)
            line_intersection = self._find_line_intersections(ray_origin, ray_dir)
            if line_intersection:
                snapped = line_intersection
                if self.grid_snap:
                    snapped = Vector3(
                        self._snap_to_grid(snapped.x),
                        self._snap_to_grid(snapped.y),
                        self._snap_to_grid(snapped.z)
                    )
                self.previous_cursor_3d = snapped
                return snapped
            
            # Snap to geometry (vertices and points on lines) if close
            snapped = self._snap_to_geometry(best_point)
            if snapped:
                if self.grid_snap:
                    snapped = Vector3(
                        self._snap_to_grid(snapped.x),
                        self._snap_to_grid(snapped.y),
                        self._snap_to_grid(snapped.z)
                    )
                self.previous_cursor_3d = snapped
                return snapped
            
            # Apply grid snapping if enabled
            if self.grid_snap:
                best_point = Vector3(
                    self._snap_to_grid(best_point.x),
                    self._snap_to_grid(best_point.y),
                    self._snap_to_grid(best_point.z)
                )
            
            self.previous_cursor_3d = best_point  # Update fallback
            return best_point
        
        # 7. Fallback: use previous cursor position or project along ray
        if self.previous_cursor_3d and self.previous_cursor_3d != Vector3(0, 0, 0):
            # Project previous point onto ray
            to_prev = self.previous_cursor_3d - ray_origin
            t_proj = to_prev.dot(ray_dir)
            if t_proj > 0:
                fallback_point = ray_origin + ray_dir * t_proj
                if self.grid_snap:
                    fallback_point = Vector3(
                        self._snap_to_grid(fallback_point.x),
                        self._snap_to_grid(fallback_point.y),
                        self._snap_to_grid(fallback_point.z)
                    )
                return fallback_point
        
        # Final fallback: return previous position
        return self.previous_cursor_3d if self.previous_cursor_3d else Vector3(0, 0, 0)
    
    def _screen_to_world(self, x: int, y: int) -> Optional[Vector3]:
        """Convert screen coordinates to world coordinates using inference system"""
        # Use inference system to find best intersection
        return self._screen_to_world_inference(x, y)
    
    def _intersect_ray_face(self, ray_origin: Vector3, ray_dir: Vector3, face: Face) -> Optional[float]:
        """Check if ray intersects face"""
        if len(face.vertices) < 3:
            return None
        
        # Get face normal
        normal = self._calculate_face_normal(face.vertices)
        
        # Ray-plane intersection
        plane_point = face.vertices[0]
        denom = ray_dir.dot(normal)
        
        if abs(denom) < 1e-6:
            return None  # Ray parallel to plane
        
        t = (plane_point - ray_origin).dot(normal) / denom
        
        if t < 0:
            return None  # Behind camera
        
        # Check if intersection point is inside face (using triangulation)
        intersection_point = ray_origin + ray_dir * t
        triangles = self._triangulate_polygon(face.vertices)
        
        for triangle in triangles:
            # Check if point is inside triangle using barycentric coordinates
            v0 = triangle[0]
            v1 = triangle[1]
            v2 = triangle[2]
            
            v0v1 = v1 - v0
            v0v2 = v2 - v0
            v0p = intersection_point - v0
            
            dot00 = v0v2.dot(v0v2)
            dot01 = v0v2.dot(v0v1)
            dot02 = v0v2.dot(v0p)
            dot11 = v0v1.dot(v0v1)
            dot12 = v0v1.dot(v0p)
            
            inv_denom = 1 / (dot00 * dot11 - dot01 * dot01)
            u = (dot11 * dot02 - dot01 * dot12) * inv_denom
            v = (dot00 * dot12 - dot01 * dot02) * inv_denom
            
            if u >= 0 and v >= 0 and u + v <= 1:
                return t
        
        return None
    
    def _get_ray_from_screen(self, x: int, y: int) -> Tuple[Vector3, Vector3]:
        """Get ray from camera through screen point"""
        viewport = glGetIntegerv(GL_VIEWPORT)
        width = viewport[2]
        height = viewport[3]
        
        nx = (2.0 * x) / width - 1.0
        ny = 1.0 - (2.0 * y) / height
        
        mvmatrix = glGetDoublev(GL_MODELVIEW_MATRIX)
        projmatrix = glGetDoublev(GL_PROJECTION_MATRIX)
        
        near = gluUnProject(nx, ny, 0.0, mvmatrix, projmatrix, viewport)
        far = gluUnProject(nx, ny, 1.0, mvmatrix, projmatrix, viewport)
        
        if near and far:
            origin = Vector3(near[0], near[1], near[2])
            direction = Vector3(far[0] - near[0], far[1] - near[1], far[2] - near[2])
            direction = direction.normalize()
            return origin, direction
        return Vector3(), Vector3(0, 0, -1)
    
    def _intersect_ray_primitive(self, origin: Vector3, direction: Vector3, primitive: Primitive) -> Optional[float]:
        """Check if ray intersects primitive (simple AABB for now)"""
        # Simple AABB intersection
        size = max(primitive.transform.scale.x,
                  primitive.transform.scale.y,
                  primitive.transform.scale.z) * 1.0
        center = primitive.transform.position
        
        # Ray-AABB intersection
        tmin = -float('inf')
        tmax = float('inf')
        
        for i in range(3):
            axis = [direction.x, direction.y, direction.z][i]
            pos = [origin.x, origin.y, origin.z][i]
            center_pos = [center.x, center.y, center.z][i]
            
            if abs(axis) < 1e-6:
                if pos < center_pos - size or pos > center_pos + size:
                    return None
            else:
                ood = 1.0 / axis
                t1 = (center_pos - size - pos) * ood
                t2 = (center_pos + size - pos) * ood
                if t1 > t2:
                    t1, t2 = t2, t1
                tmin = max(tmin, t1)
                tmax = min(tmax, t2)
        
        if tmin <= tmax and tmax >= 0:
            return max(0, tmin)
        return None
    
    def mousePressEvent(self, event):
        """Handle mouse press"""
        self.last_mouse_pos = event.position().toPoint()
        
        if event.button() == Qt.LeftButton:
            # Left click: Use selected tool
            if self.tool_mode == ToolMode.SELECT:
                # Try to select face or edge
                pos = event.position().toPoint()
                ray_origin, ray_dir = self._get_mouse_ray(int(pos.x()), int(pos.y()))
                
                if ray_origin and ray_dir:
                    # First try to select face
                    closest_face = None
                    min_t = float('inf')
                    
                    for face in self.faces:
                        t = self._intersect_ray_face(ray_origin, ray_dir, face)
                        if t is not None and t < min_t:
                            min_t = t
                            closest_face = face
                    
                    if closest_face:
                        # Select face
                        if event.modifiers() & Qt.ControlModifier:
                            # Add to selection
                            if closest_face.id in self.selected_faces:
                                self.selected_faces.remove(closest_face.id)
                            else:
                                self.selected_faces.add(closest_face.id)
                        else:
                            # Replace selection
                            self.selected_faces = {closest_face.id}
                            self.selected_edges.clear()
                        self.selectionChanged.emit()
                        self.update()
                    else:
                        # Try to select edge
                        closest_edge = None
                        min_t = float('inf')
                        
                        for edge in self.edges:
                            edge_dir = edge.end - edge.start
                            edge_len = edge_dir.length()
                            if edge_len < 1e-10:
                                continue
                            
                            edge_dir_norm = edge_dir.normalize()
                            cross = ray_dir.cross(edge_dir_norm)
                            cross_len_sq = cross.length() ** 2
                            
                            if cross_len_sq < 1e-10:
                                continue
                            
                            to_start = edge.start - ray_origin
                            t = to_start.cross(edge_dir_norm).dot(cross) / cross_len_sq
                            
                            if t >= 0:
                                intersection_point = ray_origin + ray_dir * t
                                closest_on_edge = self._closest_point_on_line_segment(intersection_point, edge.start, edge.end)
                                dist = (intersection_point - closest_on_edge).length()
                                
                                if dist < 0.5 and t < min_t:
                                    min_t = t
                                    closest_edge = edge
                        
                        if closest_edge:
                            if event.modifiers() & Qt.ControlModifier:
                                if closest_edge.id in self.selected_edges:
                                    self.selected_edges.remove(closest_edge.id)
                                else:
                                    self.selected_edges.add(closest_edge.id)
                            else:
                                self.selected_edges = {closest_edge.id}
                                self.selected_faces.clear()
                            self.selectionChanged.emit()
                            self.update()
                        else:
                            # Deselect all
                            self.selected_edges.clear()
                            self.selected_faces.clear()
                            self.selectionChanged.emit()
                            self.update()
            elif self.tool_mode == ToolMode.MOVE and self.selected_edges:
                # Move selected edges (simplified - would need proper edge picking)
                pass
            elif self.tool_mode == ToolMode.PAN:
                self.is_panning = True
            elif self.tool_mode == ToolMode.ORBIT:
                self.is_rotating = True
            elif self.tool_mode == ToolMode.DRAW:
                # Draw tool: create edges/lines
                pos = self.cursor_3d
                if pos:
                    if self.grid_snap:
                        pos = Vector3(
                            self._snap_to_grid(pos.x),
                            self._snap_to_grid(pos.y),
                            self._snap_to_grid(pos.z)
                        )
                    
                    if self.draw_start_point is None:
                        # First point: start drawing
                        self.draw_start_point = pos
                        self.inference_point = pos  # Store for inference
                    else:
                        # Check if we should auto-close to starting point
                        start_distance = (pos - self.inference_point).length() if self.inference_point else float('inf')
                        
                        # Auto-close if very close to start (within snap distance)
                        # More generous snap distance for closing loops
                        auto_close_distance = self.grid_size if self.grid_snap else 0.5
                        if start_distance < auto_close_distance and self.inference_point:
                            # Close to starting point - snap to it
                            pos = self.inference_point
                        
                        # Second point: create edge
                        # Don't create if clicking the same point
                        if (self.draw_start_point - pos).length() > 1e-6:
                            edge = Edge(
                                start=self.draw_start_point,
                                end=pos,
                                id=self.next_id
                            )
                            self.next_id += 1
                            self.edges.append(edge)
                            self._save_state()
                            self._detect_faces()  # Regenerate faces
                            self._geometry_dirty = True
                            self.sceneChanged.emit()
                            
                            # Check if we closed a loop
                            if pos == self.inference_point and len(self.edges) >= 3:
                                # Loop closed - stop drawing
                                self.draw_start_point = None
                                self.inference_point = None
                                self.locked_axis = None
                            else:
                                # Keep start point for continuous drawing
                                self.draw_start_point = pos
                self.update()
            else:
                # Not drawing - clear draw state
                self.draw_start_point = None
                self.locked_axis = None
                self.inference_point = None
        
        elif event.button() == Qt.RightButton:
            # Right click: Show information menu for edges (simplified)
            pass
        
        elif event.button() == Qt.MiddleButton:
            # Middle click: Select edge (or start orbit)
            # Track for double click detection
            current_time = event.timestamp()
            if self.middle_click_time and (current_time - self.middle_click_time) < 500:
                # Double click detected - move camera to position
                if self.middle_click_pos:
                    world_pos = self._screen_to_world(
                        int(self.middle_click_pos.x()),
                        int(self.middle_click_pos.y())
                    )
                    if world_pos:
                        # Move camera to position (keep same height)
                        self.camera.position = Vector3(world_pos.x, self.camera.position.y, world_pos.z)
                        self.update()
                self.middle_click_time = None
            else:
                # First click - start tracking
                self.middle_click_time = current_time
                self.middle_click_pos = event.position().toPoint()
                
                # If orbit tool is selected, start orbiting
                if self.tool_mode == ToolMode.ORBIT:
                    self.is_rotating = True
                else:
                    # Normal middle click: orbit anyway
                    self.is_rotating = True
        
        self.update()
    
    def mouseMoveEvent(self, event):
        """Handle mouse move"""
        current_pos = event.position().toPoint()
        dx = current_pos.x() - self.last_mouse_pos.x()
        dy = current_pos.y() - self.last_mouse_pos.y()
        
        # Update 3D cursor position using inference system
        # (Grid snapping and axis locking are now handled inside _screen_to_world_inference)
        world_pos = self._screen_to_world(current_pos.x(), current_pos.y())
        if world_pos:
            self.cursor_3d = world_pos
            
            # If drawing, update the preview immediately
            if self.draw_start_point is not None:
                self.update()
        
        if self.is_rotating:
            # Orbit camera (rotate pitch/yaw)
            self.camera.yaw -= dx * 0.5  # Fixed: inverted yaw
            self.camera.pitch -= dy * 0.5
            self.camera.pitch = max(-89.0, min(89.0, self.camera.pitch))
            self.update()
        
        elif self.is_panning:
            # Pan camera (move perpendicular to view)
            pan_speed = 0.01
            right = self.camera.get_right()
            up = self.camera.get_up()
            
            self.camera.position = self.camera.position + right * (dx * pan_speed)
            self.camera.position = self.camera.position + up * (-dy * pan_speed)
            self.update()
        
        elif event.buttons() & Qt.MiddleButton and self.tool_mode == ToolMode.ORBIT:
            # Orbit camera when middle mouse held with orbit tool
            self.camera.yaw -= dx * 0.5  # Fixed: inverted yaw
            self.camera.pitch -= dy * 0.5
            self.camera.pitch = max(-89.0, min(89.0, self.camera.pitch))
            self.update()
        
        elif self.is_zooming:
            # Zoom camera (move forward/backward)
            zoom_factor = dy * 0.01
            forward = self.camera.get_forward()
            self.camera.position = self.camera.position + forward * (-zoom_factor)
            self.update()
        
        elif self.is_manipulating and self.tool_mode == ToolMode.MOVE:
            # Move selected edges (simplified)
            pass
        
        self.last_mouse_pos = current_pos
    
    def mouseReleaseEvent(self, event):
        """Handle mouse release"""
        if self.is_manipulating:
            # Save state for undo
            self._save_state()
        
        self.is_rotating = False
        self.is_panning = False
        self.is_zooming = False
        self.is_manipulating = False
        self.update()
    
    def _show_object_info_menu(self, pos: QPoint, primitive: Primitive):
        """Show context menu with object information"""
        from PySide6.QtWidgets import QMenu
        
        menu = QMenu(self)
        
        # Add object info
        info_text = f"Type: {primitive.type.value.capitalize()}\n"
        info_text += f"ID: {primitive.id}\n"
        info_text += f"Position: ({primitive.transform.position.x:.2f}, "
        info_text += f"{primitive.transform.position.y:.2f}, "
        info_text += f"{primitive.transform.position.z:.2f})\n"
        info_text += f"Rotation: ({primitive.transform.rotation.x:.2f}, "
        info_text += f"{primitive.transform.rotation.y:.2f}, "
        info_text += f"{primitive.transform.rotation.z:.2f})\n"
        info_text += f"Scale: ({primitive.transform.scale.x:.2f}, "
        info_text += f"{primitive.transform.scale.y:.2f}, "
        info_text += f"{primitive.transform.scale.z:.2f})"
        
        info_action = menu.addAction(info_text)
        info_action.setEnabled(False)
        menu.addSeparator()
        
        # Add selection option
        select_action = menu.addAction("Select")
        select_action.triggered.connect(lambda: self._select_primitive(primitive))
        
        menu.addSeparator()
        
        # Add delete option
        delete_action = menu.addAction("Delete")
        delete_action.triggered.connect(lambda: self._delete_primitive(primitive))
        
        menu.exec(pos)
    
    def _select_primitive(self, primitive: Primitive):
        """Select a primitive"""
        for p in self.primitives:
            p.selected = False
        self.selected_primitives.clear()
        self.selected_primitives.add(primitive.id)
        primitive.selected = True
        self.selected_primitive = primitive
        self.selectionChanged.emit()
        self.update()
    
    def _delete_primitive(self, primitive: Primitive):
        """Delete a primitive"""
        self._save_state()
        self.primitives = [p for p in self.primitives if p.id != primitive.id]
        if primitive.id in self.selected_primitives:
            self.selected_primitives.remove(primitive.id)
        self.sceneChanged.emit()
        self.update()
    
    def wheelEvent(self, event):
        """Handle mouse wheel for zooming (move forward/backward)"""
        delta = event.angleDelta().y()
        
        if self.draw_start_point is not None:
            # When drawing: cycle through inference planes or adjust depth
            # For now, just move camera forward/backward to change perspective
            zoom_factor = delta * 0.01
            forward = self.camera.get_forward()
            self.camera.position = self.camera.position + forward * zoom_factor
            self.update()
        else:
            # Normal mode: move camera forward/backward
            zoom_factor = delta * 0.01
            forward = self.camera.get_forward()
            self.camera.position = self.camera.position + forward * zoom_factor
            self.update()
    
    def _update_movement(self):
        """Update camera position based on WASD keys using free camera"""
        if not any(self.move_keys.values()) and not self.is_shift_pressed:
            return
        
        delta_time = 0.016  # ~60 FPS
        move_delta = self.move_speed * delta_time
        
        # Get camera vectors
        forward = self.camera.get_forward()
        right = self.camera.get_right()
        up = self.camera.get_up()
        
        # Calculate movement
        movement = Vector3()
        if self.move_keys[Qt.Key_W]:
            movement = movement + forward * move_delta
        if self.move_keys[Qt.Key_S]:
            movement = movement + forward * (-move_delta)
        if self.move_keys[Qt.Key_A]:
            movement = movement + right * (-move_delta)
        if self.move_keys[Qt.Key_D]:
            movement = movement + right * move_delta
        if self.move_keys[Qt.Key_Space]:
            movement = movement + up * move_delta
        if self.is_shift_pressed:
            movement = movement + up * (-move_delta)
        
        # Apply movement to camera position
        self.camera.position = self.camera.position + movement
        self.update()
    
    def _create_edge(self, start: Vector3, end: Vector3):
        """Create an edge/line"""
        edge = Edge(
            start=start,
            end=end,
            id=self.next_id
        )
        self.next_id += 1
        self.edges.append(edge)
        self._save_state()
        self.sceneChanged.emit()
        self.update()
    
    def _save_state(self):
        """Save current state for undo"""
        state = {
            'edges': [edge.to_dict() for edge in self.edges],
            'faces': [face.to_dict() for face in self.faces]
        }
        self.undo_stack.append(json.dumps(state))
        self.redo_stack.clear()  # Clear redo when new action is performed
    
    def undo(self):
        """Undo last action"""
        if self.undo_stack:
            # Save current state to redo
            current_state = {
                'edges': [edge.to_dict() for edge in self.edges],
                'faces': [face.to_dict() for face in self.faces]
            }
            self.redo_stack.append(json.dumps(current_state))
            
            # Restore previous state
            state_json = self.undo_stack.pop()
            state = json.loads(state_json)
            
            # Handle old format (just edges array) and new format
            if isinstance(state, list):
                # Old format - just edges
                self.edges = [Edge.from_dict(e) for e in state]
                self.faces = []
            else:
                # New format with edges and faces
                self.edges = [Edge.from_dict(e) for e in state.get('edges', [])]
                self.faces = [Face.from_dict(f) for f in state.get('faces', [])]
            
            # Update selection
            self.selected_edges = set()
            self.selected_faces = set()
            
            # Regenerate faces if not in saved state
            if not self.faces and self.edges:
                self._detect_faces()
            
            self.sceneChanged.emit()
            self.update()
    
    def redo(self):
        """Redo last undone action"""
        if self.redo_stack:
            # Save current state to undo
            current_state = {
                'edges': [edge.to_dict() for edge in self.edges],
                'faces': [face.to_dict() for face in self.faces]
            }
            self.undo_stack.append(json.dumps(current_state))
            
            # Restore next state
            state_json = self.redo_stack.pop()
            state = json.loads(state_json)
            
            # Handle old format (just edges array) and new format
            if isinstance(state, list):
                # Old format - just edges
                self.edges = [Edge.from_dict(e) for e in state]
                self.faces = []
            else:
                # New format with edges and faces
                self.edges = [Edge.from_dict(e) for e in state.get('edges', [])]
                self.faces = [Face.from_dict(f) for f in state.get('faces', [])]
            
            # Update selection
            self.selected_edges = set()
            self.selected_faces = set()
            
            # Regenerate faces if not in saved state
            if not self.faces and self.edges:
                self._detect_faces()
            
            self.sceneChanged.emit()
            self.update()
    
    def delete_selected(self):
        """Delete selected edges"""
        if self.selected_edges:
            self._save_state()
            self.edges = [e for e in self.edges if e.id not in self.selected_edges]
            self._detect_faces()  # Regenerate faces after deletion
            self.selected_edges.clear()
            self._geometry_dirty = True
            self.sceneChanged.emit()
            self.update()
    
    def keyPressEvent(self, event):
        """Handle key presses"""
        key = event.key()
        
        # Arrow keys for axis locking (SketchUp-style)
        if self.draw_start_point is not None:
            if key == Qt.Key_Up:
                self.locked_axis = 'y'
                self.update()
                return
            elif key == Qt.Key_Down:
                self.locked_axis = None
                self.update()
                return
            elif key == Qt.Key_Left:
                self.locked_axis = 'z'
                self.update()
                return
            elif key == Qt.Key_Right:
                self.locked_axis = 'x'
                self.update()
                return
        
        # Shift key handling
        if key == Qt.Key_Shift:
            self.is_shift_pressed = True
            return
        
        # WASD movement
        if key in self.move_keys:
            self.move_keys[key] = True
            return
        
        # Other keys
        if key == Qt.Key_Delete or key == Qt.Key_Backspace:
            self.delete_selected()
        elif key == Qt.Key_Z and event.modifiers() & Qt.ControlModifier:
            if event.modifiers() & Qt.ShiftModifier:
                self.redo()
            else:
                self.undo()
        elif key == Qt.Key_Escape:
                # Cancel drawing
                if self.draw_start_point is not None:
                    self.draw_start_point = None
                    self.locked_axis = None
                    self.inference_point = None
                    self.update()
        else:
            super().keyPressEvent(event)
    
    def keyReleaseEvent(self, event):
        """Handle key releases"""
        key = event.key()
        
        # Shift key handling
        if key == Qt.Key_Shift:
            self.is_shift_pressed = False
            return
        
        # WASD movement
        if key in self.move_keys:
            self.move_keys[key] = False
        
        super().keyReleaseEvent(event)


class MainWindow(QMainWindow):
    """Main application window"""
    
    def __init__(self):
        super().__init__()
        self.setWindowTitle("3D Model Viewer and Editor")
        self.setGeometry(100, 100, 1400, 900)
        
        # Set dark theme
        self.setStyleSheet("""
            QMainWindow {
                background-color: #2b2b2b;
                color: #ffffff;
            }
            QWidget {
                background-color: #2b2b2b;
                color: #ffffff;
            }
            QPushButton {
                background-color: #3c3c3c;
                border: 1px solid #555555;
                padding: 5px;
                border-radius: 3px;
            }
            QPushButton:hover {
                background-color: #4c4c4c;
            }
            QPushButton:pressed {
                background-color: #2c2c2c;
            }
            QGroupBox {
                border: 1px solid #555555;
                border-radius: 5px;
                margin-top: 10px;
                padding-top: 10px;
            }
            QGroupBox::title {
                subcontrol-origin: margin;
                left: 10px;
                padding: 0 5px;
            }
            QListWidget {
                border: 1px solid #555555;
                background-color: #1e1e1e;
            }
            QDoubleSpinBox, QSpinBox {
                background-color: #1e1e1e;
                border: 1px solid #555555;
                padding: 3px;
            }
            QCheckBox {
                spacing: 5px;
            }
            QLabel {
                color: #ffffff;
            }
        """)
        
        # Create central widget and layout
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        main_layout = QHBoxLayout(central_widget)
        main_layout.setContentsMargins(0, 0, 0, 0)
        
        # Create splitter for resizable panels
        splitter = QSplitter(Qt.Horizontal)
        main_layout.addWidget(splitter)
        
        # Left panel - Tools
        left_panel = self._create_left_panel()
        splitter.addWidget(left_panel)
        
        # Middle - 3D Canvas
        self.gl_widget = OpenGLWidget()
        splitter.addWidget(self.gl_widget)
        splitter.setStretchFactor(1, 1)
        
        # Connect signals
        self.gl_widget.sceneChanged.connect(self._update_component_list)
        self.gl_widget.selectionChanged.connect(self._on_selection_changed)
        
        # Right panel - Properties/Info
        right_panel = self._create_right_panel()
        splitter.addWidget(right_panel)
        
        # Set splitter sizes
        splitter.setSizes([250, 900, 300])
        
        # Create menu bar
        self._create_menu_bar()
        
        # Create status bar
        self.status_bar = QStatusBar()
        self.setStatusBar(self.status_bar)
        self.status_bar.showMessage("Ready")
        
        # Update status bar with cursor position
        self.update_timer = QTimer()
        self.update_timer.timeout.connect(self._update_status_bar)
        self.update_timer.start(50)  # Update every 50ms
    
    def _create_menu_bar(self):
        """Create menu bar"""
        menubar = self.menuBar()
        
        # File menu
        file_menu = menubar.addMenu("File")
        new_action = QAction("New", self)
        new_action.setShortcut(QKeySequence.New)
        file_menu.addAction(new_action)
        
        open_action = QAction("Open", self)
        open_action.setShortcut(QKeySequence.Open)
        file_menu.addAction(open_action)

        # Load external model (OBJ/GLB/GLTF)
        load_model_action = QAction("Load Model...", self)
        load_model_action.setShortcut("Ctrl+L")
        load_model_action.triggered.connect(self._load_model)
        file_menu.addAction(load_model_action)
        
        save_action = QAction("Save", self)
        save_action.setShortcut(QKeySequence.Save)
        file_menu.addAction(save_action)
        
        file_menu.addSeparator()
        
        exit_action = QAction("Exit", self)
        exit_action.setShortcut(QKeySequence.Quit)
        exit_action.triggered.connect(self.close)
        file_menu.addAction(exit_action)
        
        # Edit menu
        edit_menu = menubar.addMenu("Edit")
        undo_action = QAction("Undo", self)
        undo_action.setShortcut(QKeySequence.Undo)
        undo_action.triggered.connect(self.gl_widget.undo)
        edit_menu.addAction(undo_action)
        
        redo_action = QAction("Redo", self)
        redo_action.setShortcut(QKeySequence.Redo)
        redo_action.triggered.connect(self.gl_widget.redo)
        edit_menu.addAction(redo_action)
        
        edit_menu.addSeparator()
        
        delete_action = QAction("Delete", self)
        delete_action.setShortcut(QKeySequence.Delete)
        delete_action.triggered.connect(self.gl_widget.delete_selected)
        edit_menu.addAction(delete_action)
        
        # View menu
        view_menu = menubar.addMenu("View")
        reset_view_action = QAction("Reset Camera", self)
        reset_view_action.triggered.connect(self._reset_camera)
        view_menu.addAction(reset_view_action)
        
        # Help menu
        help_menu = menubar.addMenu("Help")
        shortcuts_action = QAction("Keyboard Shortcuts", self)
        shortcuts_action.triggered.connect(self._show_shortcuts)
        help_menu.addAction(shortcuts_action)
    
    def _create_left_panel(self):
        """Create left tool panel"""
        panel = QWidget()
        layout = QVBoxLayout(panel)
        layout.setContentsMargins(10, 10, 10, 10)
        
        # Tools group
        tools_group = QGroupBox("Tools")
        tools_layout = QVBoxLayout()
        
        # Tool buttons
        self.select_btn = QPushButton("Select")
        self.select_btn.setCheckable(True)
        self.select_btn.setChecked(True)
        self.select_btn.clicked.connect(lambda: self._set_tool_mode(ToolMode.SELECT))
        tools_layout.addWidget(self.select_btn)
        
        self.draw_btn = QPushButton("Draw")
        self.draw_btn.setCheckable(True)
        self.draw_btn.clicked.connect(lambda: self._set_tool_mode(ToolMode.DRAW))
        tools_layout.addWidget(self.draw_btn)
        
        self.move_btn = QPushButton("Move")
        self.move_btn.setCheckable(True)
        self.move_btn.clicked.connect(lambda: self._set_tool_mode(ToolMode.MOVE))
        tools_layout.addWidget(self.move_btn)
        
        self.rotate_btn = QPushButton("Rotate")
        self.rotate_btn.setCheckable(True)
        self.rotate_btn.clicked.connect(lambda: self._set_tool_mode(ToolMode.ROTATE))
        tools_layout.addWidget(self.rotate_btn)
        
        self.scale_btn = QPushButton("Scale")
        self.scale_btn.setCheckable(True)
        self.scale_btn.clicked.connect(lambda: self._set_tool_mode(ToolMode.SCALE))
        tools_layout.addWidget(self.scale_btn)
        
        tools_layout.addWidget(QWidget())  # Spacer
        
        self.pan_btn = QPushButton("Pan")
        self.pan_btn.setCheckable(True)
        self.pan_btn.clicked.connect(lambda: self._set_tool_mode(ToolMode.PAN))
        tools_layout.addWidget(self.pan_btn)
        
        self.orbit_btn = QPushButton("Orbit")
        self.orbit_btn.setCheckable(True)
        self.orbit_btn.clicked.connect(lambda: self._set_tool_mode(ToolMode.ORBIT))
        tools_layout.addWidget(self.orbit_btn)
        
        tools_group.setLayout(tools_layout)
        layout.addWidget(tools_group)
        
        # Primitives group
        primitives_group = QGroupBox("Primitives")
        primitives_layout = QVBoxLayout()
        
        self.cube_btn = QPushButton("Cube")
        self.cube_btn.clicked.connect(lambda: self._create_primitive(PrimitiveType.CUBE))
        primitives_layout.addWidget(self.cube_btn)
        
        self.sphere_btn = QPushButton("Sphere")
        self.sphere_btn.clicked.connect(lambda: self._create_primitive(PrimitiveType.SPHERE))
        primitives_layout.addWidget(self.sphere_btn)
        
        self.cylinder_btn = QPushButton("Cylinder")
        self.cylinder_btn.clicked.connect(lambda: self._create_primitive(PrimitiveType.CYLINDER))
        primitives_layout.addWidget(self.cylinder_btn)
        
        self.plane_btn = QPushButton("Plane")
        self.plane_btn.clicked.connect(lambda: self._create_primitive(PrimitiveType.PLANE))
        primitives_layout.addWidget(self.plane_btn)
        
        primitives_group.setLayout(primitives_layout)
        layout.addWidget(primitives_group)
        
        # Options group
        options_group = QGroupBox("Options")
        options_layout = QVBoxLayout()
        
        self.grid_snap_check = QCheckBox("Grid Snap")
        self.grid_snap_check.setChecked(True)
        self.grid_snap_check.stateChanged.connect(
            lambda state: setattr(self.gl_widget, 'grid_snap', state == Qt.Checked)
        )
        options_layout.addWidget(self.grid_snap_check)
        
        self.show_grid_check = QCheckBox("Show Grid")
        self.show_grid_check.setChecked(True)
        self.show_grid_check.stateChanged.connect(
            lambda state: setattr(self.gl_widget, 'show_grid', state == Qt.Checked)
        )
        options_layout.addWidget(self.show_grid_check)

        # Toggle edges visibility (useful for heavy models)
        self.show_edges_check = QCheckBox("Show Edges")
        self.show_edges_check.setChecked(True)
        self.show_edges_check.stateChanged.connect(
            lambda state: setattr(self.gl_widget, 'show_edges', state == Qt.Checked)
        )
        options_layout.addWidget(self.show_edges_check)

        # Fast mode toggle
        self.fast_mode_check = QCheckBox("Fast Mode (VBO)")
        self.fast_mode_check.setChecked(True)
        self.fast_mode_check.stateChanged.connect(
            lambda state: setattr(self.gl_widget, 'fast_mode', state == Qt.Checked)
        )
        options_layout.addWidget(self.fast_mode_check)

        # ModernGL toggle (requires restart of GL resources)
        if HAS_MGL:
            self.mgl_check = QCheckBox("Use ModernGL Renderer")
            self.mgl_check.setChecked(True)
            def _toggle_mgl(state):
                self.gl_widget.use_moderngl = state == Qt.Checked
                # Force rebuild
                self.gl_widget._geometry_dirty = True
            self.mgl_check.stateChanged.connect(_toggle_mgl)
            options_layout.addWidget(self.mgl_check)
        
        grid_size_label = QLabel("Grid Size:")
        options_layout.addWidget(grid_size_label)
        self.grid_size_spin = QDoubleSpinBox()
        self.grid_size_spin.setRange(0.1, 10.0)
        self.grid_size_spin.setValue(1.0)
        self.grid_size_spin.setSingleStep(0.1)
        self.grid_size_spin.valueChanged.connect(
            lambda value: setattr(self.gl_widget, 'grid_size', value)
        )
        options_layout.addWidget(self.grid_size_spin)
        
        # Axis constraints
        constraints_label = QLabel("Constraints:")
        options_layout.addWidget(constraints_label)
        
        self.x_constraint_check = QCheckBox("X Axis")
        self.x_constraint_check.stateChanged.connect(
            lambda state: setattr(self.gl_widget, 'x_constraint', state == Qt.Checked)
        )
        options_layout.addWidget(self.x_constraint_check)
        
        self.y_constraint_check = QCheckBox("Y Axis")
        self.y_constraint_check.stateChanged.connect(
            lambda state: setattr(self.gl_widget, 'y_constraint', state == Qt.Checked)
        )
        options_layout.addWidget(self.y_constraint_check)
        
        self.z_constraint_check = QCheckBox("Z Axis")
        self.z_constraint_check.stateChanged.connect(
            lambda state: setattr(self.gl_widget, 'z_constraint', state == Qt.Checked)
        )
        options_layout.addWidget(self.z_constraint_check)
        
        options_group.setLayout(options_layout)
        layout.addWidget(options_group)
        
        layout.addStretch()
        
        return panel
    
    def _create_right_panel(self):
        """Create right properties panel"""
        panel = QWidget()
        layout = QVBoxLayout(panel)
        layout.setContentsMargins(10, 10, 10, 10)
        
        # Component info group
        info_group = QGroupBox("Component Info")
        info_layout = QVBoxLayout()
        
        self.component_list = QListWidget()
        self.component_list.itemSelectionChanged.connect(self._on_component_selected)
        info_layout.addWidget(self.component_list)
        
        info_group.setLayout(info_layout)
        layout.addWidget(info_group)
        
        # Properties group
        properties_group = QGroupBox("Properties")
        properties_layout = QVBoxLayout()
        
        # Position
        pos_label = QLabel("Position:")
        properties_layout.addWidget(pos_label)
        
        pos_layout = QHBoxLayout()
        self.pos_x_spin = QDoubleSpinBox()
        self.pos_x_spin.setRange(-1000.0, 1000.0)
        self.pos_x_spin.valueChanged.connect(self._update_selected_position)
        pos_layout.addWidget(QLabel("X:"))
        pos_layout.addWidget(self.pos_x_spin)
        
        self.pos_y_spin = QDoubleSpinBox()
        self.pos_y_spin.setRange(-1000.0, 1000.0)
        self.pos_y_spin.valueChanged.connect(self._update_selected_position)
        pos_layout.addWidget(QLabel("Y:"))
        pos_layout.addWidget(self.pos_y_spin)
        
        self.pos_z_spin = QDoubleSpinBox()
        self.pos_z_spin.setRange(-1000.0, 1000.0)
        self.pos_z_spin.valueChanged.connect(self._update_selected_position)
        pos_layout.addWidget(QLabel("Z:"))
        pos_layout.addWidget(self.pos_z_spin)
        
        properties_layout.addLayout(pos_layout)
        
        # Rotation
        rot_label = QLabel("Rotation:")
        properties_layout.addWidget(rot_label)
        
        rot_layout = QHBoxLayout()
        self.rot_x_spin = QDoubleSpinBox()
        self.rot_x_spin.setRange(-360.0, 360.0)
        self.rot_x_spin.valueChanged.connect(self._update_selected_rotation)
        rot_layout.addWidget(QLabel("X:"))
        rot_layout.addWidget(self.rot_x_spin)
        
        self.rot_y_spin = QDoubleSpinBox()
        self.rot_y_spin.setRange(-360.0, 360.0)
        self.rot_y_spin.valueChanged.connect(self._update_selected_rotation)
        rot_layout.addWidget(QLabel("Y:"))
        rot_layout.addWidget(self.rot_y_spin)
        
        self.rot_z_spin = QDoubleSpinBox()
        self.rot_z_spin.setRange(-360.0, 360.0)
        self.rot_z_spin.valueChanged.connect(self._update_selected_rotation)
        rot_layout.addWidget(QLabel("Z:"))
        rot_layout.addWidget(self.rot_z_spin)
        
        properties_layout.addLayout(rot_layout)
        
        # Scale
        scale_label = QLabel("Scale:")
        properties_layout.addWidget(scale_label)
        
        scale_layout = QHBoxLayout()
        self.scale_x_spin = QDoubleSpinBox()
        self.scale_x_spin.setRange(0.1, 100.0)
        self.scale_x_spin.setValue(1.0)
        self.scale_x_spin.valueChanged.connect(self._update_selected_scale)
        scale_layout.addWidget(QLabel("X:"))
        scale_layout.addWidget(self.scale_x_spin)
        
        self.scale_y_spin = QDoubleSpinBox()
        self.scale_y_spin.setRange(0.1, 100.0)
        self.scale_y_spin.setValue(1.0)
        self.scale_y_spin.valueChanged.connect(self._update_selected_scale)
        scale_layout.addWidget(QLabel("Y:"))
        scale_layout.addWidget(self.scale_y_spin)
        
        self.scale_z_spin = QDoubleSpinBox()
        self.scale_z_spin.setRange(0.1, 100.0)
        self.scale_z_spin.setValue(1.0)
        self.scale_z_spin.valueChanged.connect(self._update_selected_scale)
        scale_layout.addWidget(QLabel("Z:"))
        scale_layout.addWidget(self.scale_z_spin)
        
        properties_layout.addLayout(scale_layout)
        
        properties_group.setLayout(properties_layout)
        layout.addWidget(properties_group)
        
        # Textures group (placeholder)
        textures_group = QGroupBox("Textures")
        textures_layout = QVBoxLayout()
        textures_layout.addWidget(QLabel("Texture system\ncoming soon..."))
        textures_group.setLayout(textures_layout)
        layout.addWidget(textures_group)
        
        # Color/Material group
        color_group = QGroupBox("Color/Material")
        color_layout = QVBoxLayout()
        
        # Color preview button
        self.color_button = QPushButton("Set Color")
        self.color_button.clicked.connect(self._select_color)
        color_layout.addWidget(self.color_button)
        
        color_group.setLayout(color_layout)
        layout.addWidget(color_group)
        
        layout.addStretch()
        
        return panel
    
    def _set_tool_mode(self, mode: ToolMode):
        """Set the current tool mode"""
        self.gl_widget.tool_mode = mode
        
        # Clear drawing state when switching away from DRAW mode
        if mode != ToolMode.DRAW:
            self.gl_widget.draw_start_point = None
            self.gl_widget.locked_axis = None
            self.gl_widget.inference_point = None
        
        # Update button states
        self.select_btn.setChecked(mode == ToolMode.SELECT)
        self.draw_btn.setChecked(mode == ToolMode.DRAW)
        self.move_btn.setChecked(mode == ToolMode.MOVE)
        self.rotate_btn.setChecked(mode == ToolMode.ROTATE)
        self.scale_btn.setChecked(mode == ToolMode.SCALE)
        self.pan_btn.setChecked(mode == ToolMode.PAN)
        self.orbit_btn.setChecked(mode == ToolMode.ORBIT)
        
        self.gl_widget.update()
    
    def _create_primitive(self, primitive_type: PrimitiveType):
        """Create a primitive at the 3D cursor - Deprecated, using edges now"""
        # Just switch to draw mode
        self.gl_widget.tool_mode = ToolMode.DRAW
        self._set_tool_mode(ToolMode.DRAW)
    
    def _select_color(self):
        """Open color picker and apply to selected faces/edges"""
        # Get current color from selection
        current_color = QColor(128, 128, 128)
        
        if len(self.gl_widget.selected_faces) == 1:
            face_id = next(iter(self.gl_widget.selected_faces))
            face = next((f for f in self.gl_widget.faces if f.id == face_id), None)
            if face:
                current_color = QColor(
                    int(face.color[0] * 255),
                    int(face.color[1] * 255),
                    int(face.color[2] * 255)
                )
        elif len(self.gl_widget.selected_edges) == 1:
            edge_id = next(iter(self.gl_widget.selected_edges))
            edge = next((e for e in self.gl_widget.edges if e.id == edge_id), None)
            if edge and hasattr(edge, 'color'):
                current_color = QColor(
                    int(edge.color[0] * 255),
                    int(edge.color[1] * 255),
                    int(edge.color[2] * 255)
                )
        
        # Open color dialog
        color = QColorDialog.getColor(current_color, self, "Select Color")
        if color.isValid():
            rgb = (color.red() / 255.0, color.green() / 255.0, color.blue() / 255.0)
            
            # Apply to selected faces
            for face_id in self.gl_widget.selected_faces:
                face = next((f for f in self.gl_widget.faces if f.id == face_id), None)
                if face:
                    face.color = rgb
            
            # Apply to selected edges
            for edge_id in self.gl_widget.selected_edges:
                edge = next((e for e in self.gl_widget.edges if e.id == edge_id), None)
                if edge:
                    edge.color = rgb
            
            # Save state first
            self.gl_widget._save_state()
            # Regenerate faces to update display
            self.gl_widget._detect_faces()
            self.gl_widget.sceneChanged.emit()
            self._update_component_list()  # Update component list
            self.gl_widget.update()
    
    def _update_component_list(self):
        """Update the component list"""
        self.component_list.clear()
        
        # Add edges
        for edge in self.gl_widget.edges:
            item_text = f"Edge #{edge.id}"
            self.component_list.addItem(item_text)
        
        # Add faces
        for face in self.gl_widget.faces:
            item_text = f"Face #{face.id}"
            self.component_list.addItem(item_text)
    
    def _on_component_selected(self):
        """Handle component list selection"""
        selected_items = self.component_list.selectedItems()
        if selected_items:
            item_text = selected_items[0].text()
            # Extract ID from text
            try:
                # Temporarily disconnect the signal to avoid infinite loop
                self.gl_widget.selectionChanged.disconnect(self._on_selection_changed)
                
                if "Edge #" in item_text:
                    edge_id = int(item_text.split('#')[1])
                    # Select in 3D view
                    self.gl_widget.selected_edges = {edge_id}
                    self.gl_widget.selected_faces.clear()
                elif "Face #" in item_text:
                    face_id = int(item_text.split('#')[1])
                    # Select in 3D view
                    self.gl_widget.selected_faces = {face_id}
                    self.gl_widget.selected_edges.clear()
                
                # Reconnect the signal
                self.gl_widget.selectionChanged.connect(self._on_selection_changed)
                
                # Update properties panel manually
                self._update_properties_panel()
                self.gl_widget.update()
            except Exception as e:
                print(f"Selection error: {e}")
                # Ensure signal is reconnected even on error
                try:
                    self.gl_widget.selectionChanged.connect(self._on_selection_changed)
                except:
                    pass
    
    def _on_selection_changed(self):
        """Handle selection changes from 3D view"""
        # Temporarily disconnect list selection signal to avoid infinite loop
        self.component_list.itemSelectionChanged.disconnect(self._on_component_selected)
        
        # Update component list selection
        self.component_list.clearSelection()
        
        # Select edges
        for edge_id in self.gl_widget.selected_edges:
            for i in range(self.component_list.count()):
                item = self.component_list.item(i)
                if item and f"Edge #{edge_id}" in item.text():
                    item.setSelected(True)
                    break
        
        # Select faces
        for face_id in self.gl_widget.selected_faces:
            for i in range(self.component_list.count()):
                item = self.component_list.item(i)
                if item and f"Face #{face_id}" in item.text():
                    item.setSelected(True)
                    break
        
        # Reconnect the signal
        self.component_list.itemSelectionChanged.connect(self._on_component_selected)
        
        # Update properties panel
        self._update_properties_panel()
    
    def _update_properties_panel(self):
        """Update the properties panel based on current selection"""
        if len(self.gl_widget.selected_faces) == 1:
            face_id = next(iter(self.gl_widget.selected_faces))
            face = next((f for f in self.gl_widget.faces if f.id == face_id), None)
            if face:
                # Show face properties (currently just clearing)
                self._clear_properties()
        elif len(self.gl_widget.selected_edges) == 1:
            edge_id = next(iter(self.gl_widget.selected_edges))
            edge = next((e for e in self.gl_widget.edges if e.id == edge_id), None)
            if edge:
                self._update_properties(edge)
            else:
                self._clear_properties()
        else:
            self._clear_properties()
    
    def _clear_properties(self):
        """Clear the properties panel"""
        self.pos_x_spin.blockSignals(True)
        self.pos_y_spin.blockSignals(True)
        self.pos_z_spin.blockSignals(True)
        self.rot_x_spin.blockSignals(True)
        self.rot_y_spin.blockSignals(True)
        self.rot_z_spin.blockSignals(True)
        self.scale_x_spin.blockSignals(True)
        self.scale_y_spin.blockSignals(True)
        self.scale_z_spin.blockSignals(True)
        
        self.pos_x_spin.setValue(0)
        self.pos_y_spin.setValue(0)
        self.pos_z_spin.setValue(0)
        self.rot_x_spin.setValue(0)
        self.rot_y_spin.setValue(0)
        self.rot_z_spin.setValue(0)
        self.scale_x_spin.setValue(1.0)
        self.scale_y_spin.setValue(1.0)
        self.scale_z_spin.setValue(1.0)
        
        self.pos_x_spin.blockSignals(False)
        self.pos_y_spin.blockSignals(False)
        self.pos_z_spin.blockSignals(False)
        self.rot_x_spin.blockSignals(False)
        self.rot_y_spin.blockSignals(False)
        self.rot_z_spin.blockSignals(False)
        self.scale_x_spin.blockSignals(False)
        self.scale_y_spin.blockSignals(False)
        self.scale_z_spin.blockSignals(False)
    
    def _update_properties(self, edge: Edge):
        """Update property controls with edge values"""
        # Block signals to avoid recursive updates
        self.pos_x_spin.blockSignals(True)
        self.pos_y_spin.blockSignals(True)
        self.pos_z_spin.blockSignals(True)
        
        # Show start point position
        self.pos_x_spin.setValue(edge.start.x)
        self.pos_y_spin.setValue(edge.start.y)
        self.pos_z_spin.setValue(edge.start.z)
        
        self.pos_x_spin.blockSignals(False)
        self.pos_y_spin.blockSignals(False)
        self.pos_z_spin.blockSignals(False)
    
    def _update_selected_position(self):
        """Update position of selected edge (not applicable for edges)"""
        pass
    
    def _update_selected_rotation(self):
        """Update rotation of selected edge (not applicable for edges)"""
        pass
    
    def _update_selected_scale(self):
        """Update scale of selected edge (not applicable for edges)"""
        pass
    
    def _update_status_bar(self):
        """Update status bar with cursor position"""
        cursor = self.gl_widget.cursor_3d
        selected_count = len(self.gl_widget.selected_edges)
        mode = self.gl_widget.tool_mode.value.capitalize()
        
                # Check if snapping
        snap_info = ""
        if hasattr(self.gl_widget, '_snap_to_geometry'):
            snap_point = self.gl_widget._snap_to_geometry(cursor, self.gl_widget.grid_size * 2)
            if snap_point:
                snap_info = " [SNAP]"
        
        # Check if locked to axis
        axis_info = ""
        if self.gl_widget.locked_axis:
            axis_info = f" [AXIS: {self.gl_widget.locked_axis.upper()}]"
        
        status_text = f"Cursor: X={cursor.x:.2f}, Y={cursor.y:.2f}, Z={cursor.z:.2f}{snap_info}{axis_info} | "
        status_text += f"Mode: {mode} | Selected: {len(self.gl_widget.selected_edges)} edges, {len(self.gl_widget.selected_faces)} faces"
        
        self.status_bar.showMessage(status_text)

    def _load_model(self):
        """Open a model file (.obj, .glb, .gltf) and import as edges.
        Imported geometry is translated so its minimum X/Y/Z sits at (0,0,0).
        """
        from PySide6.QtWidgets import QFileDialog, QMessageBox
        import os
        
        filters = "Model Files (*.obj *.glb *.gltf);;Wavefront OBJ (*.obj);;glTF Binary (*.glb);;glTF JSON (*.gltf);;All Files (*.*)"
        path, _ = QFileDialog.getOpenFileName(self, "Load Model", "", filters)
        if not path:
            return
        
        ext = os.path.splitext(path)[1].lower()
        try:
            if ext == ".obj":
                edges, faces = self._import_obj(path)
            elif ext in (".glb", ".gltf"):
                try:
                    edges, faces = self._import_gltf(path)
                except Exception as gltf_err:
                    QMessageBox.warning(self, "GLTF Import",
                        f"glTF import requires 'trimesh' and 'numpy'.\nError: {gltf_err}")
                    return
            else:
                QMessageBox.warning(self, "Unsupported Format", f"Unsupported file type: {ext}")
                return
        except Exception as e:
            QMessageBox.critical(self, "Import Error", f"Failed to import model.\n{e}")
            return
        
        # Place at origin and add to scene
        if edges or faces:
            # Re-id edges sequentially following existing
            base_id = self.gl_widget.next_id
            for i, e in enumerate(edges):
                e.id = base_id + i
            self.gl_widget.next_id = base_id + len(edges)
            
            self.gl_widget._save_state()
            self.gl_widget.edges.extend(edges)
            # Add faces directly from import for reliability/perf
            start_face_id = len(self.gl_widget.faces)
            for i, verts in enumerate(faces):
                self.gl_widget.faces.append(Face(vertices=verts, id=start_face_id + i, color=(0.7, 0.8, 0.85)))
            # No need to detect faces; we imported them
            # mark geometry cache dirty
            self.gl_widget._geometry_dirty = True
            self.gl_widget.sceneChanged.emit()
            self._update_component_list()
            self.gl_widget.update()
        else:
            QMessageBox.information(self, "Load Model", "No geometry found in file.")

    # --------------------
    # Importers
    # --------------------
    def _import_obj(self, path: str) -> Tuple[List[Edge], List[List[Vector3]]]:
        """Parse a Wavefront OBJ file into edges and faces (as vertex lists).
        Faces are not triangulated here; we keep polygon loops and let our renderer handle.
        """
        vertices: List[Vector3] = []
        faces: List[List[int]] = []
        
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                parts = line.split()
                tag = parts[0].lower()
                if tag == "v" and len(parts) >= 4:
                    x, y, z = float(parts[1]), float(parts[2]), float(parts[3])
                    vertices.append(Vector3(x, y, z))
                elif tag == "f" and len(parts) >= 4:
                    # Faces can be like 'f v1 v2 v3' or 'f v1/... v2/... v3/...'
                    idxs = []
                    for p in parts[1:]:
                        v_idx = p.split("/")[0]
                        if v_idx:
                            idx = int(v_idx)
                            if idx < 0:  # negative indices
                                idx = len(vertices) + 1 + idx
                            idxs.append(idx - 1)  # OBJ is 1-based
                    if len(idxs) >= 3:
                        faces.append(idxs)
        
        if not vertices or not faces:
            return [], []
        
        # Translate so min x,y,z = 0,0,0 (anchor at corner on ground)
        min_x = min(v.x for v in vertices)
        min_y = min(v.y for v in vertices)
        min_z = min(v.z for v in vertices)
        offset = Vector3(-min_x, -min_y, -min_z)
        vertices = [Vector3(v.x + offset.x, v.y + offset.y, v.z + offset.z) for v in vertices]
        
        # Weld vertices (merge near-duplicates) to avoid tiny gaps
        epsilon = 1e-5
        key_map = {}
        welded_vertices: List[Vector3] = []
        index_remap = {}
        
        def key_for(v: Vector3):
            return (round(v.x/epsilon)*epsilon, round(v.y/epsilon)*epsilon, round(v.z/epsilon)*epsilon)
        
        for i, v in enumerate(vertices):
            k = key_for(v)
            if k in key_map:
                index_remap[i] = key_map[k]
            else:
                key_map[k] = len(welded_vertices)
                index_remap[i] = key_map[k]
                welded_vertices.append(v)
        
        # Remap face indices to welded vertices
        faces = [[index_remap[idx] for idx in face] for face in faces]
        vertices = welded_vertices
        
        # Build unique edges from faces and collect face vertices
        edge_keys = set()
        edges: List[Edge] = []
        face_vertices: List[List[Vector3]] = []
        
        def add_edge(a: Vector3, b: Vector3):
            key = tuple(sorted(((round(a.x,6), round(a.y,6), round(a.z,6)),
                                (round(b.x,6), round(b.y,6), round(b.z,6)))))
            if key in edge_keys:
                return
            edge_keys.add(key)
            edges.append(Edge(start=a, end=b))
        
        for face in faces:
            # Connect perimeter edges
            loop = []
            for i in range(len(face)):
                a = vertices[face[i]]
                b = vertices[face[(i+1) % len(face)]]
                add_edge(a, b)
                loop.append(a)
            if len(loop) >= 3:
                face_vertices.append(loop)
        
        return edges, face_vertices
    
    def _import_gltf(self, path: str) -> Tuple[List[Edge], List[List[Vector3]]]:
        """Import a .glb/.gltf using trimesh if available, convert to edges and faces.
        Places model so min(x,y,z) = 0.
        """
        try:
            import trimesh  # type: ignore
        except Exception as e:
            raise RuntimeError("trimesh is required for GLB/GLTF import") from e
        
        scene_or_mesh = trimesh.load(path, force='scene')
        if isinstance(scene_or_mesh, trimesh.Scene):
            # Combine into a single mesh
            mesh = trimesh.util.concatenate(tuple(m for m in scene_or_mesh.dump().geometry.values()))
        else:
            mesh = scene_or_mesh
        
        if mesh is None or mesh.vertices is None or len(mesh.vertices) == 0:
            return [], []
        
        # Convert to Vector3 list
        verts = [Vector3(float(v[0]), float(v[1]), float(v[2])) for v in mesh.vertices]
        
        # Translate so min corner at origin
        min_x = min(v.x for v in verts)
        min_y = min(v.y for v in verts)
        min_z = min(v.z for v in verts)
        offset = Vector3(-min_x, -min_y, -min_z)
        verts = [Vector3(v.x + offset.x, v.y + offset.y, v.z + offset.z) for v in verts]
        
        # Build edges from faces
        edges: List[Edge] = []
        face_vertices: List[List[Vector3]] = []
        edge_keys = set()
        
        def add_edge(a: Vector3, b: Vector3):
            key = tuple(sorted(((round(a.x,6), round(a.y,6), round(a.z,6)),
                                (round(b.x,6), round(b.y,6), round(b.z,6)))))
            if key in edge_keys:
                return
            edge_keys.add(key)
            edges.append(Edge(start=a, end=b))
        
        # Trimesh faces are triangles
        if hasattr(mesh, 'faces') and mesh.faces is not None:
            for tri in mesh.faces:
                a, b, c = tri
                add_edge(verts[a], verts[b])
                add_edge(verts[b], verts[c])
                add_edge(verts[c], verts[a])
                face_vertices.append([verts[a], verts[b], verts[c]])
        
        return edges, face_vertices
    
    def _reset_camera(self):
        """Reset camera to default position"""
        self.gl_widget.camera.position = Vector3(0, 5, 20)
        self.gl_widget.camera.pitch = 20.0
        self.gl_widget.camera.yaw = 0.0
        self.gl_widget.update()
    
    def _show_shortcuts(self):
        """Show keyboard shortcuts dialog"""
        from PySide6.QtWidgets import QMessageBox
        
        shortcuts_text = """
<b>Drawing:</b>
• Click to place points and create edges
• Edges automatically form faces when closed
• Green preview line = about to close a loop
• ESC = Cancel current drawing

<b>Navigation:</b>
• WASD = Move camera
• Space = Move up
• Shift = Move down  
• Middle Mouse = Orbit camera
• Mouse Wheel = Zoom in/out

<b>Axis Constraints (while drawing):</b>
• Right Arrow = Lock to X axis (red)
• Up Arrow = Lock to Y axis (green)
• Left Arrow = Lock to Z axis (blue)
• Down Arrow = Unlock axis

<b>Selection:</b>
• Left Click = Select edge/face
• Ctrl+Click = Add to selection
• Delete = Delete selected

<b>General:</b>
• Ctrl+Z = Undo
• Ctrl+Shift+Z = Redo
        """
        
        msg = QMessageBox(self)
        msg.setWindowTitle("Keyboard Shortcuts")
        msg.setTextFormat(Qt.RichText)
        msg.setText(shortcuts_text)
        msg.exec()

    # -------------------- ModernGL helpers --------------------
    def _build_mgl_program(self):
        if not (self._mgl_ctx and HAS_MGL):
            return
        vs = """
        #version 330
        in vec3 in_pos;
        in vec3 in_nrm;
        uniform mat4 m_proj;
        uniform mat4 m_view;
        out vec3 v_nrm;
        void main() {
            v_nrm = mat3(m_view) * in_nrm;
            gl_Position = m_proj * m_view * vec4(in_pos, 1.0);
        }
        """
        fs = """
        #version 330
        in vec3 v_nrm;
        out vec4 f_color;
        void main() {
            vec3 n = normalize(v_nrm);
            float l = dot(n, normalize(vec3(0.4, 0.8, 0.4)))*0.5+0.5;
            f_color = vec4(vec3(0.7,0.8,0.85)*l, 1.0);
        }
        """
        self._mgl_prog = self._mgl_ctx.program(vertex_shader=vs, fragment_shader=fs)

    def _proj_matrix(self, fov_deg: float, aspect: float, near: float, far: float) -> np.ndarray:
        f = 1.0/np.tan(np.radians(fov_deg)/2.0)
        nf = 1.0/(near - far)
        return np.array([
            [f/aspect, 0, 0, 0],
            [0, f, 0, 0],
            [0, 0, (far+near)*nf, -1],
            [0, 0, (2*far*near)*nf, 0]
        ], dtype=np.float32)

    def _view_matrix(self) -> np.ndarray:
        forward = self.gl_widget.camera.get_forward() if hasattr(self,'gl_widget') else self.camera.get_forward()
        right = self.gl_widget.camera.get_right() if hasattr(self,'gl_widget') else self.camera.get_right()
        up = self.gl_widget.camera.get_up() if hasattr(self,'gl_widget') else self.camera.get_up()
        pos = self.gl_widget.camera.position if hasattr(self,'gl_widget') else self.camera.position
        R = np.array([
            [ right.x,  up.x, -forward.x, 0],
            [ right.y,  up.y, -forward.y, 0],
            [ right.z,  up.z, -forward.z, 0],
            [     0.0,   0.0,        0.0, 1]
        ], dtype=np.float32)
        T = np.array([
            [1,0,0,0],
            [0,1,0,0],
            [0,0,1,0],
            [-pos.x, -pos.y, -pos.z, 1]
        ], dtype=np.float32)
        return T @ R

    def _rebuild_mgl_buffers(self):
        if not (self._mgl_ctx and self._mgl_prog):
            return
        # Faces source depends on whether we're in MainWindow or OpenGLWidget
        faces = self.gl_widget.faces if hasattr(self,'gl_widget') else self.faces
        tris = []
        nrms = []
        for face in faces:
            if len(face.vertices) < 3:
                continue
            loop = self.gl_widget._ensure_consistent_winding(face.vertices.copy()) if hasattr(self,'gl_widget') else self._ensure_consistent_winding(face.vertices.copy())
            triangles = (self.gl_widget._triangulate_polygon(loop) if hasattr(self,'gl_widget') else self._triangulate_polygon(loop))
            for tri in triangles:
                n = (self.gl_widget._calculate_face_normal(list(tri)) if hasattr(self,'gl_widget') else self._calculate_face_normal(list(tri)))
                for v in tri:
                    tris.extend([v.x, v.y, v.z])
                    nrms.extend([n.x, n.y, n.z])
        if not tris:
            self._mgl_vao = None
            self._mgl_tri_count = 0
            return
        pos = np.array(tris, dtype=np.float32)
        nrm = np.array(nrms, dtype=np.float32)
        self._mgl_pos = self._mgl_ctx.buffer(pos.tobytes())
        self._mgl_nrm = self._mgl_ctx.buffer(nrm.tobytes())
        self._mgl_vao = self._mgl_ctx.vertex_array(
            self._mgl_prog,
            [(self._mgl_pos, '3f', 'in_pos'), (self._mgl_nrm, '3f', 'in_nrm')]
        )
        self._mgl_tri_count = len(tris)//3

    def _draw_mgl(self):
        if not (self._mgl_ctx and self._mgl_vao and self._mgl_prog):
            return
        width, height = (self.gl_widget.width(), self.gl_widget.height()) if hasattr(self,'gl_widget') else (self.width(), self.height())
        aspect = width/height if height>0 else 1.0
        cam = self.gl_widget.camera if hasattr(self,'gl_widget') else self.camera
        proj = self._proj_matrix(cam.fov, aspect, cam.near, cam.far)
        view = self._view_matrix()
        self._mgl_prog['m_proj'].write(proj.tobytes())
        self._mgl_prog['m_view'].write(view.tobytes())
        self._mgl_vao.render(mode=mgl.TRIANGLES)


def main(initial_edges=None):
    """Main entry point"""
    app = QApplication(sys.argv)
    window = MainWindow()
    if initial_edges:
        window.gl_widget.edges = initial_edges
        window.gl_widget.next_id = max([e.id for e in initial_edges], default=-1) + 1
        # Force face detection on initial load
        window.gl_widget._detect_faces()
        window.gl_widget.update()
        window._update_component_list()
    window.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
if __name__ == "__main__":
    main()