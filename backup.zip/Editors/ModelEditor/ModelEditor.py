from PySide6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QFileDialog, QApplication, QStatusBar,
    QMenuBar, QMenu, QMessageBox, QPushButton, QLabel, QHBoxLayout, QCheckBox, QComboBox,
    QColorDialog, QGroupBox, QGridLayout, QSplitter, QFrame, QLineEdit, QScrollArea, QDoubleSpinBox, QInputDialog,
    QDialog, QDialogButtonBox, QListWidget, QListWidgetItem
)
from PySide6.QtCore import Qt, QPoint, QTimer
from PySide6.QtGui import QKeySequence, QColor, QAction, QImage, QPainter, QFont, QPen, QPixmap, QIcon
from PySide6.QtOpenGLWidgets import QOpenGLWidget
from OpenGL.GL import *
from OpenGL.GLU import *
import struct
import numpy as np
import sys
import os
import shutil
import importlib.util
import math
from PIL import Image
from Core.Debug import debug
from typing import Dict, Optional
from Core.EditorInterface import EditorInterface


class UnifiedMaterial:
    """Unified material schema that all importers normalize into.
    
    This provides a consistent structure regardless of source format (OBJ, DAE, GLB).
    """
    def __init__(self, name=""):
        self.name = name
        # Color properties (RGBA, 0.0-1.0)
        self.diffuse_color = [0.8, 0.8, 0.8, 1.0]
        self.ambient_color = [0.2, 0.2, 0.2, 1.0]
        self.specular_color = [0.0, 0.0, 0.0, 1.0]
        self.emissive_color = [0.0, 0.0, 0.0, 1.0]
        
        # Texture maps (file paths)
        self.diffuse_map = None
        self.normal_map = None
        self.specular_map = None
        self.roughness_map = None
        self.metallic_map = None
        self.emissive_map = None
        self.occlusion_map = None
        
        # Material properties
        self.shininess = 0.0  # 0.0-128.0
        self.roughness = 0.5   # 0.0-1.0
        self.metallic = 0.0    # 0.0-1.0
        self.alpha_mode = "OPAQUE"  # OPAQUE, MASK, BLEND
        self.alpha_cutoff = 0.5  # For MASK mode
        
    def to_dict(self):
        """Convert to dictionary format (for compatibility with existing material system)"""
        return {
            'diffuse': self.diffuse_color[:3],
            'ambient': self.ambient_color[:3],
            'specular': self.specular_color[:3],
            'shininess': self.shininess,
            'texture': self.diffuse_map  # Primary texture for compatibility
        }
    
    def from_dict(self, data):
        """Load from dictionary format (for compatibility)"""
        if 'diffuse' in data:
            self.diffuse_color = data['diffuse'][:3] + [1.0] if len(data['diffuse']) == 3 else data['diffuse']
        if 'ambient' in data:
            self.ambient_color = data['ambient'][:3] + [1.0] if len(data['ambient']) == 3 else data['ambient']
        if 'specular' in data:
            self.specular_color = data['specular'][:3] + [1.0] if len(data['specular']) == 3 else data['specular']
        if 'shininess' in data:
            self.shininess = data['shininess']
        if 'texture' in data:
            self.diffuse_map = data['texture']


class MaterialResolver:
    """Resolves and normalizes materials from various formats into UnifiedMaterial structure.
    
    Provides directory-aware texture matching and automatic material assignment.
    """
    def __init__(self, model_directory=""):
        self.model_directory = model_directory
        self.texture_extensions = ['.png', '.jpg', '.jpeg', '.tga', '.bmp', '.dds', '.tif', '.tiff']
    
    def resolve_material_from_obj_mtl(self, mtl_data, material_name):
        """Resolve material from OBJ MTL format"""
        mat = UnifiedMaterial(name=material_name)
        
        if 'diffuse' in mtl_data:
            mat.diffuse_color = mtl_data['diffuse'][:3] + [1.0] if len(mtl_data['diffuse']) == 3 else mtl_data['diffuse']
        if 'ambient' in mtl_data:
            mat.ambient_color = mtl_data['ambient'][:3] + [1.0] if len(mtl_data['ambient']) == 3 else mtl_data['ambient']
        if 'specular' in mtl_data:
            mat.specular_color = mtl_data['specular'][:3] + [1.0] if len(mtl_data['specular']) == 3 else mtl_data['specular']
        if 'shininess' in mtl_data:
            mat.shininess = mtl_data['shininess']
        
        # Resolve texture paths
        texture_path = mtl_data.get('texture')
        if texture_path:
            resolved = self._resolve_texture_path(texture_path)
            if resolved:
                mat.diffuse_map = resolved
        
        return mat
    
    def resolve_material_from_dae(self, collada_material, collada_effect):
        """Resolve material from DAE/Collada format"""
        mat = UnifiedMaterial(name=collada_material.name if hasattr(collada_material, 'name') else str(collada_material))
        
        if collada_effect:
            # Extract colors and properties from effect
            if hasattr(collada_effect, 'diffuse'):
                # Handle different DAE diffuse types
                if hasattr(collada_effect.diffuse, 'color'):
                    mat.diffuse_color = list(collada_effect.diffuse.color[:4])
                elif hasattr(collada_effect.diffuse, 'texture'):
                    # Texture reference - resolve path
                    texture_ref = collada_effect.diffuse.texture
                    if hasattr(texture_ref, 'image'):
                        img_path = texture_ref.image.path if hasattr(texture_ref.image, 'path') else None
                        if img_path:
                            resolved = self._resolve_texture_path(img_path)
                            if resolved:
                                mat.diffuse_map = resolved
            
            if hasattr(collada_effect, 'ambient'):
                if hasattr(collada_effect.ambient, 'color'):
                    mat.ambient_color = list(collada_effect.ambient.color[:4])
            
            if hasattr(collada_effect, 'specular'):
                if hasattr(collada_effect.specular, 'color'):
                    mat.specular_color = list(collada_effect.specular.color[:4])
                if hasattr(collada_effect.specular, 'float'):
                    mat.shininess = float(collada_effect.specular.float.value) if hasattr(collada_effect.specular.float, 'value') else 0.0
        
        return mat
    
    def resolve_material_from_gltf(self, gltf_material):
        """Resolve material from GLTF format"""
        mat = UnifiedMaterial(name=gltf_material.name if hasattr(gltf_material, 'name') else "GLTF_Material")
        
        # GLTF uses PBR (physically based rendering) properties
        if hasattr(gltf_material, 'pbrMetallicRoughness'):
            pbr = gltf_material.pbrMetallicRoughness
            if hasattr(pbr, 'baseColorFactor'):
                mat.diffuse_color = list(pbr.baseColorFactor[:4])
            if hasattr(pbr, 'baseColorTexture'):
                # Resolve base color texture (diffuse)
                tex_info = pbr.baseColorTexture
                if hasattr(tex_info, 'index'):
                    # Would need to resolve through texture index -> image -> URI
                    pass  # Handled separately in texture extraction
            if hasattr(pbr, 'metallicFactor'):
                mat.metallic = float(pbr.metallicFactor)
            if hasattr(pbr, 'roughnessFactor'):
                mat.roughness = float(pbr.roughnessFactor)
        
        # Convert roughness to shininess for compatibility
        mat.shininess = (1.0 - mat.roughness) * 128.0
        
        return mat
    
    def _resolve_texture_path(self, texture_path):
        """Resolve texture path by checking multiple locations.
        
        Returns absolute path if found, None otherwise.
        """
        if not texture_path:
            return None
        
        # If already absolute and exists, use it
        if os.path.isabs(texture_path) and os.path.exists(texture_path):
            return texture_path
        
        # Try relative to model directory
        if self.model_directory:
            # Try direct path
            full_path = os.path.join(self.model_directory, texture_path)
            if os.path.exists(full_path):
                return os.path.abspath(full_path)
            
            # Try with just filename
            tex_basename = os.path.basename(texture_path)
            full_path = os.path.join(self.model_directory, tex_basename)
            if os.path.exists(full_path):
                return os.path.abspath(full_path)
        
        # Try original path if absolute
        if os.path.isabs(texture_path) and os.path.exists(texture_path):
            return texture_path
        
        return None
    
    def find_textures_in_directory(self, material_name=None):
        """Scan model directory for texture images matching material or model name.
        
        Returns list of found texture paths.
        """
        if not self.model_directory or not os.path.exists(self.model_directory):
            return []
        
        found_textures = []
        search_names = []
        
        if material_name:
            search_names.append(material_name.lower())
            # Also try without common suffixes
            for suffix in ['_material', '_mat', '.material', '.mat']:
                if material_name.lower().endswith(suffix):
                    search_names.append(material_name.lower()[:-len(suffix)])
        
        # Scan directory for texture files
        for filename in os.listdir(self.model_directory):
            if not any(filename.lower().endswith(ext) for ext in self.texture_extensions):
                continue
            
            filename_lower = filename.lower()
            filename_no_ext = os.path.splitext(filename_lower)[0]
            
            # Check if matches any search name
            if search_names:
                for search_name in search_names:
                    if search_name in filename_lower or filename_no_ext == search_name:
                        full_path = os.path.join(self.model_directory, filename)
                        if full_path not in found_textures:
                            found_textures.append(os.path.abspath(full_path))
                        break
            else:
                # No specific name - collect all textures
                full_path = os.path.join(self.model_directory, filename)
                if full_path not in found_textures:
                    found_textures.append(os.path.abspath(full_path))
        
        return found_textures
    
    def auto_assign_textures(self, materials):
        """Automatically assign textures to materials that don't have them.
        
        Uses directory scanning and name matching.
        """
        for mat in materials:
            if not mat.diffuse_map:
                # Try to find matching texture
                found = self.find_textures_in_directory(mat.name)
                if found:
                    mat.diffuse_map = found[0]  # Use first match
                    from Core.Debug import debug
                    debug(f" Auto-assigned texture '{os.path.basename(found[0])}' to material '{mat.name}'")


class Vector3:
    def __init__(self, x=0.0, y=0.0, z=0.0):
        self.x = float(x)
        self.y = float(y)
        self.z = float(z)

    def __add__(self, other):
        return Vector3(self.x + other.x, self.y + other.y, self.z + other.z)

    def __sub__(self, other):
        return Vector3(self.x - other.x, self.y - other.y, self.z - other.z)

    def __mul__(self, s: float):
        return Vector3(self.x * s, self.y * s, self.z * s)

    def length(self):
        return float(np.sqrt(self.x * self.x + self.y * self.y + self.z * self.z))
    
    def length_squared(self):
        """Get the squared length of the vector (faster, no sqrt)"""
        return float(self.x * self.x + self.y * self.y + self.z * self.z)

    def normalize(self):
        l = self.length()
        if l <= 1e-8:
            return Vector3(0.0, 0.0, 0.0)
        return Vector3(self.x / l, self.y / l, self.z / l)
    
    def dot(self, other):
        """Dot product with another Vector3"""
        return float(self.x * other.x + self.y * other.y + self.z * other.z)


class AnimationClip:
    """Represents an animation clip with keyframe data for bone/node transformations.
    
    Stores transformation curves (position, rotation, scale) for skeletal or node-based animations.
    """
    def __init__(self, name: str, duration: float = 1.0, frame_rate: float = 30.0):
        self.name = name
        self.duration = duration  # Duration in seconds
        self.frame_rate = frame_rate  # Frames per second
        self.frame_count = max(1, int(duration * frame_rate))
        
        # Keyframe data: {node_name: {"position": [(time, x, y, z), ...], "rotation": [(time, qx, qy, qz, qw), ...], "scale": [(time, x, y, z), ...]}}
        self.keyframes = {}  # {node_name: {"position": list, "rotation": list, "scale": list}}
        
        # Channel information (for GLTF/DAE compatibility)
        self.channels = []  # List of channel descriptors
    
    def add_keyframe(self, node_name: str, time: float, position=None, rotation=None, scale=None):
        """Add a keyframe for a specific node/bone.
        
        Args:
            node_name: Name of the node/bone
            time: Time in seconds
            position: (x, y, z) tuple or None
            rotation: (x, y, z, w) quaternion or None
            scale: (x, y, z) tuple or None
        """
        if node_name not in self.keyframes:
            self.keyframes[node_name] = {"position": [], "rotation": [], "scale": []}
        
        if position is not None:
            self.keyframes[node_name]["position"].append((time, *position))
        
        if rotation is not None:
            # Normalize quaternion
            r = rotation[:4] if len(rotation) >= 4 else (0, 0, 0, 1)
            r_len = math.sqrt(sum(x*x for x in r))
            if r_len > 1e-8:
                r = tuple(x / r_len for x in r)
            else:
                r = (0, 0, 0, 1)
            self.keyframes[node_name]["rotation"].append((time, *r))
        
        if scale is not None:
            self.keyframes[node_name]["scale"].append((time, *scale))
    
    def evaluate(self, node_name: str, time: float):
        """Evaluate the transform for a node at a specific time.
        
        Args:
            node_name: Name of the node/bone
            time: Time in seconds (clamped to duration)
            
        Returns:
            dict with "position", "rotation", "scale" keys, or None if node not found
        """
        if node_name not in self.keyframes:
            return None
        
        # Clamp time to duration
        # Ensure both are floats
        try:
            time = float(time)
            duration = float(self.duration)
        except (ValueError, TypeError):
            time = 0.0
            duration = 1.0
        time = max(0.0, min(time, duration))
        
        node_data = self.keyframes[node_name]
        result = {"position": None, "rotation": None, "scale": None}
        
        # Interpolate position
        if node_data["position"]:
            result["position"] = self._interpolate_vector(node_data["position"], time)
        
        # Interpolate rotation (quaternion slerp)
        if node_data["rotation"]:
            result["rotation"] = self._interpolate_quaternion(node_data["rotation"], time)
        
        # Interpolate scale
        if node_data["scale"]:
            result["scale"] = self._interpolate_vector(node_data["scale"], time)
        
        return result
    
    def _interpolate_vector(self, keyframes, time):
        """Linear interpolation for vector keyframes"""
        if not keyframes:
            return None
        if len(keyframes) == 1:
            return keyframes[0][1:4]  # Return (x, y, z)
        
        # Sort by time
        sorted_kfs = sorted(keyframes, key=lambda kf: kf[0])
        
        # Before first keyframe
        if time <= sorted_kfs[0][0]:
            return sorted_kfs[0][1:4]
        
        # After last keyframe
        if time >= sorted_kfs[-1][0]:
            return sorted_kfs[-1][1:4]
        
        # Find two keyframes to interpolate between
        for i in range(len(sorted_kfs) - 1):
            t0, x0, y0, z0 = sorted_kfs[i]
            t1, x1, y1, z1 = sorted_kfs[i + 1]
            
            if t0 <= time <= t1:
                alpha = (time - t0) / (t1 - t0) if t1 > t0 else 0.0
                return (
                    x0 + (x1 - x0) * alpha,
                    y0 + (y1 - y0) * alpha,
                    z0 + (z1 - z0) * alpha
                )
        
        return sorted_kfs[-1][1:4]
    
    def _interpolate_quaternion(self, keyframes, time):
        """Spherical linear interpolation (SLERP) for quaternion keyframes"""
        if not keyframes:
            return None
        if len(keyframes) == 1:
            return keyframes[0][1:5]  # Return (x, y, z, w)
        
        sorted_kfs = sorted(keyframes, key=lambda kf: kf[0])
        
        if time <= sorted_kfs[0][0]:
            return sorted_kfs[0][1:5]
        
        if time >= sorted_kfs[-1][0]:
            return sorted_kfs[-1][1:5]
        
        for i in range(len(sorted_kfs) - 1):
            t0, x0, y0, z0, w0 = sorted_kfs[i]
            t1, x1, y1, z1, w1 = sorted_kfs[i + 1]
            
            if t0 <= time <= t1:
                alpha = (time - t0) / (t1 - t0) if t1 > t0 else 0.0
                return self._slerp((x0, y0, z0, w0), (x1, y1, z1, w1), alpha)
        
        return sorted_kfs[-1][1:5]
    
    def _slerp(self, q1, q2, t):
        """Spherical linear interpolation between two quaternions"""
        x1, y1, z1, w1 = q1
        x2, y2, z2, w2 = q2
        
        # Dot product
        dot = x1*x2 + y1*y2 + z1*z2 + w1*w2
        
        # If dot < 0, negate one quaternion to take the shorter path
        if dot < 0:
            x2, y2, z2, w2 = -x2, -y2, -z2, -w2
            dot = -dot
        
        # If quaternions are very close, use linear interpolation
        if dot > 0.9995:
            x = x1 + t * (x2 - x1)
            y = y1 + t * (y2 - y1)
            z = z1 + t * (z2 - z1)
            w = w1 + t * (w2 - w1)
            # Normalize
            len_q = math.sqrt(x*x + y*y + z*z + w*w)
            if len_q > 1e-8:
                return (x/len_q, y/len_q, z/len_q, w/len_q)
            return (x1, y1, z1, w1)
        
        # SLERP
        theta = math.acos(dot)
        sin_theta = math.sin(theta)
        w0 = math.sin((1.0 - t) * theta) / sin_theta
        w1 = math.sin(t * theta) / sin_theta
        
        x = w0 * x1 + w1 * x2
        y = w0 * y1 + w1 * y2
        z = w0 * z1 + w1 * z2
        w = w0 * w1 + w1 * w2
        
        return (x, y, z, w)
    
    def get_node_names(self):
        """Get list of all node names in this animation"""
        return list(self.keyframes.keys())


class LightEntity:
    """Base class for light entities (directional, point, spot)"""
    def __init__(self, light_type="directional", name="Light"):
        self.type = light_type  # "directional", "point", "spot"
        self.name = name
        self.enabled = True
        self.position = Vector3(0, 5, 10)  # For point/spot lights
        self.direction = Vector3(0, -1, 0)  # For directional/spot lights
        self.color = [1.0, 1.0, 1.0, 1.0]  # RGBA
        self.intensity = 1.0
        
        # Spot light specific
        self.spot_cutoff = 30.0  # Degrees
        self.spot_exponent = 1.0  # Falloff
        
        # Point light specific
        self.attenuation_constant = 1.0
        self.attenuation_linear = 0.09
        self.attenuation_quadratic = 0.032
    
    def get_gl_position(self):
        """Get OpenGL position array (x, y, z, w) where w=0 for directional"""
        if self.type == "directional":
            return [self.direction.x, self.direction.y, self.direction.z, 0.0]
        else:
            return [self.position.x, self.position.y, self.position.z, 1.0]
    
    def get_gl_color(self):
        """Get OpenGL color array with intensity"""
        return [c * self.intensity for c in self.color[:3]] + [self.color[3]]


class Camera:
    def __init__(self):
        self.position = Vector3(0, 5, 20)
        self.pitch = 20.0
        self.yaw = 0.0
        self.fov = 45.0
        self.near = 0.1
        self.far = 1000.0  # Will be updated dynamically based on model size

    def get_forward(self) -> Vector3:
        pitch_rad = np.radians(self.pitch)
        yaw_rad = np.radians(self.yaw)
        return Vector3(
            np.cos(pitch_rad) * np.sin(yaw_rad),
            np.sin(pitch_rad),
            np.cos(pitch_rad) * np.cos(yaw_rad)
        )

    def get_right(self) -> Vector3:
        yaw_rad = np.radians(self.yaw)
        return Vector3(
            np.sin(yaw_rad - np.pi / 2.0),
            0.0,
            np.cos(yaw_rad - np.pi / 2.0)
        )

    def get_up(self) -> Vector3:
        return Vector3(0.0, 1.0, 0.0)


class ManageTexturesDialog(QDialog):
    """Dialog for managing texture enable/disable state with thumbnails."""
    def __init__(self, parent, gl_widget):
        super().__init__(parent)
        self.gl_widget = gl_widget
        self.setWindowTitle("Manage Textures")
        self.setMinimumSize(600, 500)
        
        layout = QVBoxLayout(self)
        
        # Instructions
        info_label = QLabel("Click a texture to toggle enabled/disabled state.\nGreen outline = Enabled, Red outline = Disabled")
        info_label.setWordWrap(True)
        layout.addWidget(info_label)
        
        # Texture list with thumbnails
        self.texture_list = QListWidget()
        self.texture_list.setViewMode(QListWidget.IconMode)
        self.texture_list.setIconSize(QPixmap(128, 128).size())
        self.texture_list.setResizeMode(QListWidget.Adjust)
        layout.addWidget(self.texture_list)
        
        # Populate texture list
        self._populate_textures()
        
        # Connect click event
        self.texture_list.itemClicked.connect(self._toggle_texture)
        
        # Enable context menu for right-click
        self.texture_list.setContextMenuPolicy(Qt.CustomContextMenu)
        self.texture_list.customContextMenuRequested.connect(self._show_context_menu)
        
        # Connect hover events for highlighting
        self.texture_list.itemEntered.connect(self._on_texture_hover)
        # Track mouse movement for better hover detection
        self.texture_list.setMouseTracking(True)
        
        # Buttons
        button_box = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        button_box.accepted.connect(self.accept)
        button_box.rejected.connect(self.reject)
        layout.addWidget(button_box)
    
    def _populate_textures(self):
        """Populate the texture list with thumbnails."""
        self.texture_items = {}
        
        # Get all textures
        all_textures = []
        for mat_name, texture_id in self.gl_widget.textures.items():
            mat = self.gl_widget.materials.get(mat_name, {})
            texture_path = mat.get("texture")
            if texture_path:
                # Determine if enabled or disabled
                texture_name = os.path.basename(texture_path)
                is_enabled = texture_name not in self.gl_widget.disabled_textures
                if texture_name not in self.gl_widget.enabled_textures and is_enabled:
                    # If not in either list, default to enabled
                    if not self.gl_widget.enabled_textures:
                        is_enabled = True
                
                all_textures.append((texture_path, texture_name, mat_name, is_enabled))
        
        # Create list items with thumbnails
        for texture_path, texture_name, mat_name, is_enabled in all_textures:
            item = QListWidgetItem(texture_name)
            
            # Load thumbnail
            try:
                if os.path.exists(texture_path):
                    img = Image.open(texture_path)
                    # Resize to thumbnail
                    img.thumbnail((128, 128), Image.Resampling.LANCZOS)
                    
                    # Convert PIL image to QImage properly
                    # Use RGBA format for better color support
                    if img.mode != 'RGBA':
                        img = img.convert('RGBA')
                    width, height = img.size
                    img_bytes = img.tobytes('raw', 'RGBA')
                    qimg = QImage(img_bytes, width, height, QImage.Format_RGBA8888)
                    # QImage needs the data to be copied since PIL bytes might be freed
                    qimg = qimg.copy()
                    pixmap = QPixmap.fromImage(qimg)
                else:
                    # Create placeholder
                    pixmap = QPixmap(128, 128)
                    pixmap.fill(QColor(100, 100, 100))
            except Exception as e:
                from Core.Debug import debug
                debug(f" Failed to load thumbnail for {texture_path}: {e}")
                # Create placeholder
                pixmap = QPixmap(128, 128)
                pixmap.fill(QColor(100, 100, 100))
            
            # Apply outline color based on enabled state
            if is_enabled:
                # Green outline for enabled
                painter = QPainter(pixmap)
                painter.setPen(QPen(QColor(0, 255, 0), 4))
                painter.drawRect(0, 0, pixmap.width() - 1, pixmap.height() - 1)
                painter.end()
            else:
                # Red outline and greyed out for disabled
                # First grey out
                grey_pixmap = pixmap.toImage()
                for x in range(grey_pixmap.width()):
                    for y in range(grey_pixmap.height()):
                        color = grey_pixmap.pixelColor(x, y)
                        grey = int(color.red() * 0.3 + color.green() * 0.59 + color.blue() * 0.11)
                        grey_pixmap.setPixelColor(x, y, QColor(grey, grey, grey))
                pixmap = QPixmap.fromImage(grey_pixmap)
                # Then add red outline
                painter = QPainter(pixmap)
                painter.setPen(QPen(QColor(255, 0, 0), 4))
                painter.drawRect(0, 0, pixmap.width() - 1, pixmap.height() - 1)
                painter.end()
            
            item.setIcon(QIcon(pixmap))
            item.setData(Qt.UserRole, (texture_path, texture_name, mat_name, is_enabled))
            self.texture_list.addItem(item)
            self.texture_items[texture_name] = item
    
    def _on_texture_hover(self, item):
        """Handle hover over texture in list - highlight on model."""
        if item is None:
            return
        
        try:
            texture_path, texture_name, mat_name, is_enabled = item.data(Qt.UserRole)
            
            # Set hovered material on GL widget
            if self.gl_widget:
                self.gl_widget.hovered_material = mat_name
                self.gl_widget.update()
        except:
            pass
    
    def _check_hover_item(self):
        """Check current hover item (called by timer)."""
        # Check if mouse is still over an item
        # This helps when itemEntered doesn't fire reliably
        pass
    
    def leaveEvent(self, event):
        """Handle mouse leaving the dialog - clear highlight."""
        if self.gl_widget:
            self.gl_widget.hovered_material = None
            self.gl_widget.update()
        super().leaveEvent(event)
    
    def closeEvent(self, event):
        """Clear hover highlight when dialog closes."""
        if self.gl_widget:
            self.gl_widget.hovered_material = None
            self.gl_widget.update()
        super().closeEvent(event)
    
    def _show_context_menu(self, position):
        """Show context menu on right-click."""
        item = self.texture_list.itemAt(position)
        if item is None:
            return
        
        menu = QMenu(self)
        edit_action = QAction("Edit Texture", self)
        edit_action.triggered.connect(lambda: self._edit_texture(item))
        menu.addAction(edit_action)
        
        assign_action = QAction("Assign Texture...", self)
        assign_action.triggered.connect(lambda: self._assign_texture(item))
        menu.addAction(assign_action)
        
        menu.exec_(self.texture_list.mapToGlobal(position))
    
    def _edit_texture(self, item):
        """Open texture in Texture Editor."""
        texture_path, texture_name, mat_name, is_enabled = item.data(Qt.UserRole)
        
        # Get the ModelEditor parent to access app
        model_editor = self.parent()
        if not hasattr(model_editor, 'app') or not model_editor.app:
            QMessageBox.warning(self, "Error", "Cannot access application context")
            return
        
        try:
            # Get main window to open texture editor
            main_window = model_editor.app.main_window if hasattr(model_editor.app, 'main_window') else None
            if not main_window:
                QMessageBox.warning(self, "Error", "Cannot access main window to open Texture Editor")
                return
            
            # Find texture resource - get model name for texture folder
            model_name = None
            if hasattr(model_editor, 'resource_data') and model_editor.resource_data:
                model_name = model_editor.resource_data.get("name")
            
            if not model_name:
                QMessageBox.warning(self, "Error", "Cannot determine model name for texture")
                return
            
            # Look for existing texture resource by name pattern
            # Texture resource name is ModelName_TextureBaseName
            texture_base_name = os.path.splitext(texture_name)[0]
            expected_resource_name = f"{model_name}_{texture_base_name}"
            
            texture_id = None
            all_textures = model_editor.app.resource_manager.project_manager.get_resources("textures")
            for tex in all_textures:
                if tex.get("name") == expected_resource_name:
                    texture_id = tex.get("id")
                    break
            
            # If not found, check if texture file exists and create resource
            if not texture_id:
                # Try to find the texture file in Textures/ModelName/
                textures_folder = os.path.join(
                    model_editor.app.project_manager.get_project_path(),
                    "Resources", "Textures", model_name
                )
                
                # Check if texture file exists (try both original name and ModelName_OriginalName)
                possible_texture_files = [
                    texture_name,  # Original filename
                    f"{model_name}_{texture_name}",  # Prefixed filename
                ]
                
                texture_file_found = None
                for tex_file in possible_texture_files:
                    tex_path = os.path.join(textures_folder, tex_file)
                    if os.path.exists(tex_path):
                        texture_file_found = tex_file
                        break
                
                if texture_file_found:
                    # Create texture resource
                    texture_resource = model_editor.app.resource_manager.create_resource(
                        "textures", 
                        expected_resource_name,
                        model_name  # parent_folder
                    )
                    if texture_resource:
                        # Set up frames array
                        texture_resource["frames"] = [
                            {
                                "id": "frame_0",
                                "file": texture_file_found,  # Relative to Textures/ModelName/
                                "duration": 0.0
                            }
                        ]
                        
                        # Get image dimensions
                        try:
                            from PIL import Image
                            img = Image.open(os.path.join(textures_folder, texture_file_found))
                            texture_resource["width"] = img.width
                            texture_resource["height"] = img.height
                        except Exception:
                            texture_resource["width"] = 256
                            texture_resource["height"] = 256
                        
                        texture_resource["format"] = os.path.splitext(texture_file_found)[1].lstrip('.').lower()
                        texture_resource["animated"] = False
                        
                        model_editor.app.resource_manager.save_resource("textures", texture_resource)
                        texture_id = texture_resource.get("id")
                        from Core.Debug import debug
                        debug(f" Created texture resource '{expected_resource_name}' for editing.")
                else:
                    QMessageBox.warning(
                        self, 
                        "Error", 
                        f"Texture file not found.\n\n"
                        f"Looking for: {texture_name}\n"
                        f"In folder: {textures_folder}\n\n"
                        f"Please ensure the texture file exists in the Textures/{model_name}/ folder."
                    )
                    return
            
            if texture_id:
                # Open texture in Texture Editor
                main_window.open_resource("textures", texture_id)
            else:
                QMessageBox.warning(self, "Error", "Failed to find or create texture resource")
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to open texture editor: {e}")
            import traceback
            traceback.print_exc()
    
    def _assign_texture(self, item):
        """Assign a new texture file to this texture slot."""
        texture_path, texture_name, mat_name, is_enabled = item.data(Qt.UserRole)
        
        # Get model editor to access app and resource data
        model_editor = self.parent()
        if not hasattr(model_editor, 'app') or not model_editor.app:
            QMessageBox.warning(self, "Error", "Cannot access application context")
            return
        
        # Get model name for texture folder
        model_name = None
        if hasattr(model_editor, 'resource_data') and model_editor.resource_data:
            model_name = model_editor.resource_data.get("name")
        
        if not model_name:
            QMessageBox.warning(self, "Error", "Cannot determine model name for texture")
            return
        
        # Open file dialog to select new texture
        new_path, _ = QFileDialog.getOpenFileName(
            self, 
            "Assign Texture",
            os.path.dirname(texture_path) if texture_path else "",
            "Image Files (*.png *.jpg *.jpeg *.bmp *.tga *.dds);;All Files (*)"
        )
        
        if new_path:
            try:
                # Copy texture to Resources\Textures\ModelName\ folder
                textures_folder = os.path.join(
                    model_editor.app.project_manager.get_project_path(),
                    "Resources", "Textures", model_name
                )
                os.makedirs(textures_folder, exist_ok=True)
                
                # Generate new filename (preserve extension)
                new_filename = os.path.basename(new_path)
                dest_path = os.path.join(textures_folder, new_filename)
                
                # Copy file
                import shutil
                shutil.copy2(new_path, dest_path)
                
                # Update the texture path in material
                self.gl_widget.materials[mat_name]['texture'] = dest_path
                
                # Update texture in textures dict
                if mat_name in self.gl_widget.textures:
                    self.gl_widget.textures[mat_name] = dest_path
                
                # Reload texture
                self.gl_widget.load_textures_from_files([dest_path])
                
                # Update resource data if available
                if hasattr(model_editor, 'resource_data') and model_editor.resource_data:
                    texture_files = model_editor.resource_data.get("texture_files", [])
                    if new_filename not in texture_files:
                        texture_files.append(new_filename)
                    model_editor.resource_data["texture_files"] = texture_files
                    
                    # Save resource
                    try:
                        model_editor.app.resource_manager.save_resource_file_only("models", model_editor.resource_data)
                    except Exception as e:
                        from Core.Debug import debug
                        debug(f" Failed to save resource data: {e}")
                
                # Update preview
                self._update_preview()
                # Repopulate to show new thumbnail
                self.texture_list.clear()
                self._populate_textures()
                
                QMessageBox.information(self, "Success", f"Texture assigned: {new_filename}")
            except Exception as e:
                QMessageBox.critical(self, "Error", f"Failed to assign texture: {e}")
                import traceback
                traceback.print_exc()
    
    def _toggle_texture(self, item):
        """Toggle the enabled/disabled state of a texture."""
        texture_path, texture_name, mat_name, is_enabled = item.data(Qt.UserRole)
        
        # Toggle state
        new_enabled = not is_enabled
        
        # Update item data
        item.setData(Qt.UserRole, (texture_path, texture_name, mat_name, new_enabled))
        
        # Update icon
        try:
            if os.path.exists(texture_path):
                img = Image.open(texture_path)
                img.thumbnail((128, 128), Image.Resampling.LANCZOS)
                
                if img.mode != 'RGB':
                    img = img.convert('RGB')
                img_bytes = img.tobytes()
                qimg = QImage(img_bytes, img.width, img.height, QImage.Format_RGB888)
                pixmap = QPixmap.fromImage(qimg)
            else:
                pixmap = QPixmap(128, 128)
                pixmap.fill(QColor(100, 100, 100))
        except Exception:
            pixmap = QPixmap(128, 128)
            pixmap.fill(QColor(100, 100, 100))
        
        # Apply outline
        if new_enabled:
            painter = QPainter(pixmap)
            painter.setPen(QPen(QColor(0, 255, 0), 4))
            painter.drawRect(0, 0, pixmap.width() - 1, pixmap.height() - 1)
            painter.end()
        else:
            grey_pixmap = pixmap.toImage()
            for x in range(grey_pixmap.width()):
                for y in range(grey_pixmap.height()):
                    color = grey_pixmap.pixelColor(x, y)
                    grey = int(color.red() * 0.3 + color.green() * 0.59 + color.blue() * 0.11)
                    grey_pixmap.setPixelColor(x, y, QColor(grey, grey, grey))
            pixmap = QPixmap.fromImage(grey_pixmap)
            painter = QPainter(pixmap)
            painter.setPen(QPen(QColor(255, 0, 0), 4))
            painter.drawRect(0, 0, pixmap.width() - 1, pixmap.height() - 1)
            painter.end()
        
        item.setIcon(QIcon(pixmap))
        
        # Update preview immediately
        self._update_preview()
    
    def _update_preview(self):
        """Update the preview by refreshing enabled/disabled lists."""
        enabled = []
        disabled = []
        
        for i in range(self.texture_list.count()):
            item = self.texture_list.item(i)
            texture_path, texture_name, mat_name, is_enabled = item.data(Qt.UserRole)
            if is_enabled:
                enabled.append(texture_name)
            else:
                disabled.append(texture_name)
        
        self.gl_widget.enabled_textures = enabled
        self.gl_widget.disabled_textures = disabled
        self.gl_widget.update()
    
    def get_enabled_textures(self):
        """Get list of enabled texture names."""
        enabled = []
        for i in range(self.texture_list.count()):
            item = self.texture_list.item(i)
            _, texture_name, _, is_enabled = item.data(Qt.UserRole)
            if is_enabled:
                enabled.append(texture_name)
        return enabled
    
    def get_disabled_textures(self):
        """Get list of disabled texture names."""
        disabled = []
        for i in range(self.texture_list.count()):
            item = self.texture_list.item(i)
            _, texture_name, _, is_enabled = item.data(Qt.UserRole)
            if not is_enabled:
                disabled.append(texture_name)
        return disabled


class ModelPreviewGLWidget(QOpenGLWidget):
    """Lightweight 3D viewer: import + view (orbit, pan, zoom)."""
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumSize(800, 600)
        self.app = None  # Will be set by parent ModelPreviewWindow
        self.camera = Camera()
        self.vertices = None
        self.indices = None
        self.normals = None
        self.tex_coords = None  # Texture coordinates (UVs)
        self.vertex_colors = None  # Vertex colors (for baked textures)
        self.textures = {}  # Dictionary mapping material names to OpenGL texture IDs
        self.materials = {}  # Dictionary mapping material names to material properties
        self.face_materials = []  # Material index per face
        self.enabled_textures = []  # List of enabled texture names/paths
        self.disabled_textures = []  # List of disabled texture names/paths
        self.blended_textures = {}  # Dictionary mapping material names to (base_texture_id, blend_texture_id) for texture blending
        self.last_mouse_pos = QPoint()
        self.is_rotating = False
        self.is_panning = False
        self.selected_material = None  # Material selected by clicking
        self.hovered_material = None  # Material hovered over (from ManageTexturesDialog)
        self.move_timer = QTimer(self)
        self.move_timer.timeout.connect(self._tick)
        self.move_timer.start(16)
        self.keys = {Qt.Key_W: False, Qt.Key_A: False, Qt.Key_S: False, Qt.Key_D: False}
        # Use ClickFocus instead of StrongFocus to prevent focus grabbing on creation
        # StrongFocus causes the widget to grab focus when it becomes visible, which
        # makes the main window appear to disappear when opening model files
        self.setFocusPolicy(Qt.ClickFocus)
        
        # Smooth movement/camera settings
        self.smooth_movement = False
        self.smooth_camera = False
        self.smooth_factor = 0.15  # Interpolation factor (0.0 = instant, 1.0 = very slow)
        # Initialize target values to match current camera
        self.target_position = Vector3(self.camera.position.x, self.camera.position.y, self.camera.position.z)
        self.target_yaw = self.camera.yaw
        self.target_pitch = self.camera.pitch
        # Model bounding box and environment limits
        self.model_min = None
        self.model_max = None
        self.model_center = None
        self.model_size = None
        self.env_size = None  # 10x model size
        self.env_min = None
        self.env_max = None
        # Lighting settings
        self.model_lit = True  # Model fully lit (uniform lighting)
        self.external_light_enabled = False  # External directional light (legacy - kept for compatibility)
        self.light_color = QColor(255, 255, 255)  # White light (legacy)
        self.light_position_mode = "top"  # top, bottom, left, right, middle (legacy)
        
        # New light entity system
        self.lights = []  # List of LightEntity objects
        self._initialize_default_lights()
        self.lighting_style = "Default"  # Default, Toon Ramp, Low Poly
        self.toon_ramp_texture = None  # Texture for toon ramp shading
        self.internal_light_brightness = 1.0  # Brightness multiplier for internal lighting
        self.external_light_brightness = 5.0  # Brightness multiplier for external lighting (default higher)
        
        # View settings
        self.show_grid = True
        self.show_background = True
        self.show_skyline = False
        
        # Background/Floor and Skyline colors/textures
        self.background_color = QColor(26, 26, 26)  # Dark gray default (#1a1a1a)
        self.floor_color = QColor(26, 26, 26)  # Same as background (#1a1a1a)
        self.background_texture_path = ""  # Single texture for both background and floor
        self.floor_texture_path = ""  # Will be set to same as background_texture_path
        self.background_texture_id = None
        self.floor_texture_id = None
        
        self.skyline_color = QColor(135, 206, 235)  # Sky blue default (#87ceeb)
        self.skyline_texture_path = ""
        self.skyline_texture_id = None
        self.skyline_texture_mode = "Stretch"  # Stretch, Repeat (1x1), Repeat (2x2), etc.
        self.skyline_texture_scale_x = 1.0
        self.skyline_texture_scale_y = 1.0
        
        self.background_texture_mode = "Stretch"  # Stretch, Repeat (1x1), Repeat (2x2), etc.
        self.background_texture_scale_x = 1.0
        self.background_texture_scale_y = 1.0

    def initializeGL(self):
        glEnable(GL_DEPTH_TEST)
        glEnable(GL_CULL_FACE)
        glCullFace(GL_BACK)
        glClearColor(0.1, 0.1, 0.12, 1.0)
        glEnable(GL_LIGHTING)
        glEnable(GL_LIGHT0)
        # Create toon ramp texture
        self._create_toon_ramp_texture()
        # Default lighting will be set in paintGL based on settings
    
    def _initialize_default_lights(self):
        """Initialize default light entities"""
        # Create a default directional light (matching legacy external light behavior)
        default_light = LightEntity(light_type="directional", name="Main Light")
        default_light.direction = Vector3(0, -1, -1).normalize()
        default_light.color = [1.0, 1.0, 1.0, 1.0]
        default_light.intensity = 1.0
        self.lights.append(default_light)
    
    def _create_toon_ramp_texture(self):
        """Create a 1D texture for toon/cel shading ramp"""
        # Create discrete color bands for cel shading
        width = 256
        ramp_data = []
        
        # Define discrete bands: dark, mid, light
        bands = [
            (0.0, 0.2),    # Dark shadow band (0-20% of texture)
            (0.2, 0.5),    # Mid-tone band (20-50%)
            (0.5, 0.8),    # Light band (50-80%)
            (0.8, 1.0),    # Highlight band (80-100%)
        ]
        
        for i in range(width):
            pos = i / float(width)
            # Find which band we're in
            if pos < bands[0][1]:
                value = 0.2  # Dark
            elif pos < bands[1][1]:
                value = 0.5  # Mid
            elif pos < bands[2][1]:
                value = 0.75  # Light
            else:
                value = 1.0  # Highlight
            
            # Create grayscale color
            ramp_data.extend([int(value * 255)] * 4)  # RGBA
        
        texture_data = struct.pack('B' * len(ramp_data), *ramp_data)
        
        # Generate and bind texture
        self.toon_ramp_texture = glGenTextures(1)
        glBindTexture(GL_TEXTURE_1D, self.toon_ramp_texture)
        glTexParameteri(GL_TEXTURE_1D, GL_TEXTURE_MIN_FILTER, GL_NEAREST)
        glTexParameteri(GL_TEXTURE_1D, GL_TEXTURE_MAG_FILTER, GL_NEAREST)
        glTexParameteri(GL_TEXTURE_1D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE)
        glTexImage1D(GL_TEXTURE_1D, 0, GL_RGBA, width, 0, GL_RGBA, GL_UNSIGNED_BYTE, texture_data)

    def resizeGL(self, w, h):
        glViewport(0, 0, max(1, w), max(1, h))
        glMatrixMode(GL_PROJECTION)
        glLoadIdentity()
        aspect = (w / h) if h > 0 else 1.0
        # Ensure far plane is at least large enough (recalculate if model loaded)
        if self.model_size is not None:
            max_env_size = np.max(self.env_size) if self.env_size is not None else 1000.0
            effective_far = max(self.camera.far, max_env_size * 2.0)
        else:
            effective_far = self.camera.far
        gluPerspective(self.camera.fov, aspect, self.camera.near, effective_far)
        glMatrixMode(GL_MODELVIEW)

    def paintGL(self):
        # Clear with background color
        bg_color = self.background_color
        glClearColor(bg_color.redF(), bg_color.greenF(), bg_color.blueF(), 1.0)
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
        glMatrixMode(GL_MODELVIEW)
        glLoadIdentity()

        fwd = self.camera.get_forward()
        center = self.camera.position + fwd
        up = self.camera.get_up()
        gluLookAt(self.camera.position.x, self.camera.position.y, self.camera.position.z,
                  center.x, center.y, center.z,
                  up.x, up.y, up.z)

        # Draw skyline (if enabled) - drawn first as background
        if self.show_skyline:
            self._draw_skyline()

        # Draw floor/background (if enabled)
        if self.show_background:
            self._draw_floor()

        # Setup lighting based on settings
        self._setup_lighting()

        # Draw grid (if enabled)
        if self.show_grid:
            self._draw_grid()
        
        self._draw_model()
    
    def _setup_lighting(self):
        """Setup lighting based on current settings"""
        # Only print debug occasionally to avoid spam (every 60 frames ~= 1 second at 60fps)
        if not hasattr(self, '_debug_frame_count'):
            self._debug_frame_count = 0
        self._debug_frame_count += 1
        if self._debug_frame_count % 60 == 0:  # Print once per second
            from Core.Debug import debug
            debug(f"DEBUG _setup_lighting (frame {self._debug_frame_count}): model_lit={self.model_lit}, external_light_enabled={self.external_light_enabled}")
        if self.model_lit:
            if self.external_light_enabled:
                if self._debug_frame_count % 60 == 0:  # Only print once per second
                    debug(f" Entering external light setup code path")
                # External light enabled - disable color material so material properties control lighting
                glDisable(GL_COLOR_MATERIAL)
                
                # Set material properties based on lighting style
                if self.lighting_style == "Toon Ramp":
                    # Toon Ramp: High contrast cel-shading effect
                    # Disable texture for now (would need shaders for proper toon ramp)
                    if self.toon_ramp_texture is not None:
                        glDisable(GL_TEXTURE_1D)
                        glDisable(GL_TEXTURE_GEN_S)
                    glShadeModel(GL_SMOOTH)  # CRITICAL: Ensure smooth shading for Toon Ramp
                    # Use high contrast material settings to approximate cel shading
                    glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT, [0.15, 0.15, 0.15, 1.0])  # Very low ambient
                    glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE, [0.85, 0.85, 0.85, 1.0])  # High diffuse for contrast
                    glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, [0.6, 0.6, 0.6, 1.0])  # Higher specular for sharp highlights
                    glMaterialf(GL_FRONT_AND_BACK, GL_SHININESS, 8.0)  # Very low shininess for broader, sharper highlights
                elif self.lighting_style == "Wireframe":
                    # Wireframe: Show only edges
                    glPolygonMode(GL_FRONT_AND_BACK, GL_LINE)
                    glShadeModel(GL_SMOOTH)
                    glLineWidth(1.5)  # Slightly thicker lines for visibility
                    glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT, [0.3, 0.3, 0.3, 1.0])
                    glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE, [0.9, 0.9, 0.9, 1.0])
                    glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, [0.0, 0.0, 0.0, 1.0])
                    glMaterialf(GL_FRONT_AND_BACK, GL_SHININESS, 0.0)
                elif self.lighting_style == "Fresnel":
                    # Fresnel/Rim Light: Edge glow effect using multiple lights
                    glShadeModel(GL_SMOOTH)
                    glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT, [0.1, 0.1, 0.1, 1.0])
                    glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE, [0.7, 0.7, 0.7, 1.0])
                    glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, [0.4, 0.4, 0.4, 1.0])
                    glMaterialf(GL_FRONT_AND_BACK, GL_SHININESS, 64.0)
                    # Enable additional light for rim effect (will be set up separately)
                    glEnable(GL_LIGHT1)
                elif self.lighting_style == "Unlit":
                    # Unlit: Flat color without lighting calculation
                    # Note: Lighting will be disabled in _draw_model for this style
                    glPolygonMode(GL_FRONT_AND_BACK, GL_FILL)
                    glShadeModel(GL_SMOOTH)
                    glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE, [1.0, 1.0, 1.0, 1.0])
                    glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, [0.0, 0.0, 0.0, 1.0])
                    # Disable external lighting for Unlit
                    glDisable(GL_LIGHT1)
                elif self.lighting_style == "Low Poly":
                    # Low Poly: Flat shading (no interpolation)
                    # Disable texture for low poly
                    if self.toon_ramp_texture is not None:
                        glDisable(GL_TEXTURE_1D)
                        glDisable(GL_TEXTURE_GEN_S)
                    glPolygonMode(GL_FRONT_AND_BACK, GL_FILL)  # Reset to fill mode
                    glShadeModel(GL_FLAT)  # Flat shading between vertices
                    glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT, [0.2, 0.2, 0.2, 1.0])
                    glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE, [0.8, 0.8, 0.8, 1.0])
                    glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, [0.2, 0.2, 0.2, 1.0])  # Low specular
                    glMaterialf(GL_FRONT_AND_BACK, GL_SHININESS, 20.0)
                else:  # Default
                    # Disable texture for default lighting
                    if self.toon_ramp_texture is not None:
                        glDisable(GL_TEXTURE_1D)
                        glDisable(GL_TEXTURE_GEN_S)
                    glPolygonMode(GL_FRONT_AND_BACK, GL_FILL)  # Reset to fill mode
                    glShadeModel(GL_SMOOTH)  # Smooth shading
                    # Apply external light brightness multiplier to material properties
                    # Don't clamp to 1.0 - allow brighter materials
                    brightness = self.external_light_brightness
                    # Ensure brightness is a float
                    try:
                        brightness = float(brightness)
                    except (ValueError, TypeError):
                        brightness = 1.0
                    # Use more aggressive scaling for brightness > 1.0
                    if brightness > 1.0:
                        ambient_mult = 0.6 + (brightness - 1.0) * 1.2  # Extra boost beyond 1.0
                        specular_mult = 0.7 + (brightness - 1.0) * 1.5  # Extra boost beyond 1.0
                    else:
                        ambient_mult = 0.6 * brightness
                        specular_mult = 0.7 * brightness
                    glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT, [ambient_mult, ambient_mult, ambient_mult, 1.0])
                    glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE, [1.0, 1.0, 1.0, 1.0])  # Full diffuse - will be tinted by light
                    glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, [specular_mult, specular_mult, specular_mult, 1.0])
                    glMaterialf(GL_FRONT_AND_BACK, GL_SHININESS, 32.0)
                
                # Setup light entities (new system) or fall back to legacy
                active_lights = [l for l in self.lights if l.enabled] if self.lights else []
                
                if active_lights:
                    # Use new light entity system
                    for i, light in enumerate(active_lights[:8]):  # OpenGL supports up to 8 lights
                        light_id = GL_LIGHT0 + i
                        glEnable(light_id)
                        
                        light_pos = light.get_gl_position()
                        light_color = light.get_gl_color()
                        
                        glLightfv(light_id, GL_POSITION, light_pos)
                        glLightfv(light_id, GL_AMBIENT, [0.1, 0.1, 0.1, 1.0])
                        glLightfv(light_id, GL_DIFFUSE, light_color)
                        glLightfv(light_id, GL_SPECULAR, light_color)
                        
                        # Spot light specific
                        if light.type == "spot":
                            glLightf(light_id, GL_SPOT_CUTOFF, light.spot_cutoff)
                            glLightf(light_id, GL_SPOT_EXPONENT, light.spot_exponent)
                            glLightfv(light_id, GL_SPOT_DIRECTION, [light.direction.x, light.direction.y, light.direction.z])
                        
                        # Point light attenuation
                        if light.type in ("point", "spot"):
                            glLightf(light_id, GL_CONSTANT_ATTENUATION, light.attenuation_constant)
                            glLightf(light_id, GL_LINEAR_ATTENUATION, light.attenuation_linear)
                            glLightf(light_id, GL_QUADRATIC_ATTENUATION, light.attenuation_quadratic)
                else:
                    # Legacy system fallback
                    glEnable(GL_LIGHT0)
                    
                    # Calculate light position based on mode
                    light_pos = self._get_light_position()
                    # Get base light color
                    base_light_color = [self.light_color.redF(), self.light_color.greenF(), self.light_color.blueF(), 1.0]
                    # Adjust for toon ramp style
                    if self.lighting_style == "Toon Ramp":
                        # Boost intensity for sharper transitions
                        light_color_rgb = [min(1.0, c * 1.2) for c in base_light_color[:3]] + [1.0]
                    else:
                        light_color_rgb = base_light_color
                    
                    glLightfv(GL_LIGHT0, GL_POSITION, light_pos)
                    if self.lighting_style == "Toon Ramp":
                        glLightfv(GL_LIGHT0, GL_AMBIENT, [0.15, 0.15, 0.15, 1.0])  # Very low ambient for sharp shadows
                        glLightfv(GL_LIGHT0, GL_DIFFUSE, light_color_rgb)  # Colored light
                        glLightfv(GL_LIGHT0, GL_SPECULAR, [1.0, 1.0, 1.0, 1.0])  # Full specular for sharp highlights
                    elif self.lighting_style == "Fresnel":
                        # Main light for Fresnel
                        glLightfv(GL_LIGHT0, GL_AMBIENT, [0.1, 0.1, 0.1, 1.0])
                        glLightfv(GL_LIGHT0, GL_DIFFUSE, light_color_rgb)
                        glLightfv(GL_LIGHT0, GL_SPECULAR, [0.9, 0.9, 0.9, 1.0])
                        # Rim light (LIGHT1) - positioned opposite to camera for edge glow
                        # This is a simplified Fresnel effect
                        rim_pos = [-light_pos[0] * 0.5, -light_pos[1] * 0.5, -light_pos[2] * 0.5, 0.0]  # Opposite direction
                        glLightfv(GL_LIGHT1, GL_POSITION, rim_pos)
                        rim_color = [0.3, 0.3, 0.5, 1.0]  # Slight blue tint for rim
                        glLightfv(GL_LIGHT1, GL_AMBIENT, [0.0, 0.0, 0.0, 1.0])
                        glLightfv(GL_LIGHT1, GL_DIFFUSE, rim_color)
                        glLightfv(GL_LIGHT1, GL_SPECULAR, [0.5, 0.5, 0.7, 1.0])
                        glLightf(GL_LIGHT1, GL_CONSTANT_ATTENUATION, 1.0)
                        glLightf(GL_LIGHT1, GL_LINEAR_ATTENUATION, 0.0)
                        glLightf(GL_LIGHT1, GL_QUADRATIC_ATTENUATION, 0.0)
                    else:
                        # Apply external light brightness multiplier
                        brightness = self.external_light_brightness
                        # Ensure brightness is a float
                        try:
                            brightness = float(brightness)
                        except (ValueError, TypeError):
                            brightness = 1.0
                        # Much brighter external light - significantly increase ambient and diffuse
                        # Don't clamp to 1.0 - OpenGL can handle values > 1.0 for brighter lighting
                        # Use more aggressive scaling for brightness > 1.0
                        if brightness > 1.0:
                            ambient_mult = 0.8 + (brightness - 1.0) * 1.5  # Extra boost beyond 1.0
                            diffuse_mult = 2.0 + (brightness - 1.0) * 3.0  # Extra boost beyond 1.0
                        else:
                            ambient_mult = 0.8 * brightness
                            diffuse_mult = 2.0 * brightness
                        
                        ambient_base = ambient_mult
                        glLightfv(GL_LIGHT0, GL_AMBIENT, [ambient_base, ambient_base, ambient_base, 1.0])
                        # Boost diffuse intensity significantly with brightness multiplier
                        boosted_diffuse = [c * diffuse_mult for c in light_color_rgb[:3]] + [1.0]
                        glLightfv(GL_LIGHT0, GL_DIFFUSE, boosted_diffuse)  # Much brighter colored light - creates shading
                        glLightfv(GL_LIGHT0, GL_SPECULAR, [1.0, 1.0, 1.0, 1.0])  # Full specular for highlights
                        # Disable LIGHT1 if not using Fresnel
                        glDisable(GL_LIGHT1)
                glLightf(GL_LIGHT0, GL_CONSTANT_ATTENUATION, 1.0)
                glLightf(GL_LIGHT0, GL_LINEAR_ATTENUATION, 0.0)
                glLightf(GL_LIGHT0, GL_QUADRATIC_ATTENUATION, 0.0)
            else:
                # No external light - use color material for uniform lighting
                # Apply internal light brightness multiplier
                brightness = self.internal_light_brightness
                # Ensure brightness is a float
                try:
                    brightness = float(brightness)
                except (ValueError, TypeError):
                    brightness = 1.0
                glEnable(GL_COLOR_MATERIAL)
                glColorMaterial(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE)
                
                # Set base color with brightness multiplier
                base_color = [min(1.0, 0.7 * brightness), min(1.0, 0.8 * brightness), min(1.0, 0.85 * brightness)]
                glColor3f(base_color[0], base_color[1], base_color[2])
                
                # Set shading model and polygon mode based on lighting style
                if self.lighting_style == "Low Poly":
                    glPolygonMode(GL_FRONT_AND_BACK, GL_FILL)
                    glShadeModel(GL_FLAT)
                elif self.lighting_style == "Wireframe":
                    glPolygonMode(GL_FRONT_AND_BACK, GL_LINE)
                    glShadeModel(GL_SMOOTH)
                elif self.lighting_style == "Unlit":
                    glPolygonMode(GL_FRONT_AND_BACK, GL_FILL)
                    glShadeModel(GL_SMOOTH)
                else:
                    glPolygonMode(GL_FRONT_AND_BACK, GL_FILL)
                    glShadeModel(GL_SMOOTH)
                
                # Set material properties for uniform ambient lighting
                glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT, [1.0, 1.0, 1.0, 1.0])  # Full ambient
                glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE, [1.0, 1.0, 1.0, 1.0])
                glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, [0.0, 0.0, 0.0, 1.0])
                
                glEnable(GL_LIGHT0)
                glLightfv(GL_LIGHT0, GL_POSITION, [0.0, 0.0, 1.0, 0.0])  # Directional light (w=0) pointing down Z
                glLightfv(GL_LIGHT0, GL_AMBIENT, [1.0, 1.0, 1.0, 1.0])  # Full ambient (uniform)
                glLightfv(GL_LIGHT0, GL_DIFFUSE, [0.0, 0.0, 0.0, 1.0])  # No directional
                glLightfv(GL_LIGHT0, GL_SPECULAR, [0.0, 0.0, 0.0, 1.0])
        else:
            # Model not lit - disable lighting and color material
            glDisable(GL_COLOR_MATERIAL)
            glDisable(GL_LIGHT0)
    
    def _get_light_position(self):
        """Calculate light position based on mode and model position"""
        if self.model_center is None or self.model_size is None:
            # Default position if model not loaded
            if self.light_position_mode == "top":
                return [0.0, 10.0, 0.0, 1.0]
            elif self.light_position_mode == "bottom":
                return [0.0, -10.0, 0.0, 1.0]
            elif self.light_position_mode == "left":
                return [-10.0, 0.0, 0.0, 1.0]
            elif self.light_position_mode == "right":
                return [10.0, 0.0, 0.0, 1.0]
            else:  # middle
                return [0.0, 0.0, 0.0, 1.0]
        
        model_height = self.model_max[1] if self.model_max is not None else 1.0
        model_width = self.model_size[0] if self.model_size is not None else 1.0
        model_depth = self.model_size[2] if self.model_size is not None else 1.0
        center_x = self.model_center[0] if self.model_center is not None else 0.0
        center_y = self.model_center[1] if self.model_center is not None else 0.0
        center_z = self.model_center[2] if self.model_center is not None else 0.0
        
        # Distance from model based on size - closer for brighter lighting
        distance = max(model_width, model_depth, model_height) * 1.5
        
        # Debug: Print distance calculation
        max_dimension = max(model_width, model_depth, model_height)
        from Core.Debug import debug
        debug(f"  DEBUG LIGHT DISTANCE: max_dimension={max_dimension:.2f}, distance={distance:.2f}")
        
        if self.light_position_mode == "top":
            pos = [center_x, center_y + model_height + distance, center_z, 1.0]
            debug(f"  DEBUG: Top light - model_height={model_height:.2f}, final_y={pos[1]:.2f}")
            return pos
        elif self.light_position_mode == "bottom":
            pos = [center_x, center_y - distance, center_z, 1.0]
            debug(f"  DEBUG: Bottom light - model_y={center_y:.2f}, final_y={pos[1]:.2f}")
            return pos
        elif self.light_position_mode == "left":
            pos = [center_x - distance, center_y + model_height * 0.5, center_z, 1.0]
            debug(f"  DEBUG: Left light - model_x={center_x:.2f}, final_x={pos[0]:.2f}")
            return pos
        elif self.light_position_mode == "right":
            pos = [center_x + distance, center_y + model_height * 0.5, center_z, 1.0]
            debug(f"  DEBUG: Right light - model_x={center_x:.2f}, final_x={pos[0]:.2f}")
            return pos
        else:  # middle
            pos = [center_x, center_y + model_height * 0.5, center_z, 1.0]
            debug(f"  DEBUG: Middle light - at model center height")
            return pos

    def _draw_grid(self):
        glDisable(GL_LIGHTING)
        glLineWidth(1.0)
        glColor3f(0.25, 0.25, 0.28)
        glBegin(GL_LINES)
        
        # Draw grid within environment boundaries
        if self.env_min is not None and self.env_max is not None:
            # Grid extends across X and Z axes, at Y=0 (ground level)
            x_min = self.env_min[0]
            x_max = self.env_max[0]
            z_min = self.env_min[2]
            z_max = self.env_max[2]
            
            # Use adaptive step size based on environment size
            env_extent = max(self.env_size[0] if self.env_size is not None else 10.0,
                           self.env_size[2] if self.env_size is not None else 10.0)
            step = max(0.5, env_extent / 20.0)  # About 20 grid lines
            
            # Draw X-axis lines (parallel to Z-axis)
            z = z_min
            while z <= z_max:
                glVertex3f(x_min, 0.0, z)
                glVertex3f(x_max, 0.0, z)
                z += step
            
            # Draw Z-axis lines (parallel to X-axis)
            x = x_min
            while x <= x_max:
                glVertex3f(x, 0.0, z_min)
                glVertex3f(x, 0.0, z_max)
                x += step
        else:
            # Fallback to default grid if environment not calculated yet
            size = 50
            step = 1.0
            x = -size
            while x <= size:
                glVertex3f(x, 0.0, -size)
                glVertex3f(x, 0.0, size)
                x += step
            z = -size
            while z <= size:
                glVertex3f(-size, 0.0, z)
                glVertex3f(size, 0.0, z)
                z += step
        
        glEnd()
        glEnable(GL_LIGHTING)
    
    def _load_texture_if_needed(self, texture_path, texture_id_attr):
        """Load texture from path if needed and return texture ID"""
        if not texture_path or not os.path.exists(texture_path):
            if texture_path:
                debug(f"Texture file not found: {texture_path}")
            return None
        
        # Check if already loaded with the same path
        current_id = getattr(self, texture_id_attr, None)
        cached_path_attr = f"{texture_id_attr}_path"
        cached_path = getattr(self, cached_path_attr, None)
        
        # If we have a cached texture ID and the path matches, reuse it
        if current_id is not None and cached_path == texture_path:
            return current_id
        
        # Path changed or no cached texture - need to reload
        # Clear old texture if path changed
        if current_id is not None and cached_path != texture_path:
            debug(f"Texture path changed from {cached_path} to {texture_path}, reloading...")
            glDeleteTextures([current_id])
            setattr(self, texture_id_attr, None)
        
        try:
            from PIL import Image
            img = Image.open(texture_path)
            img = img.convert('RGBA')
            img_data = img.tobytes('raw', 'RGBA')
            
            # Generate texture ID
            texture_id = glGenTextures(1)
            glBindTexture(GL_TEXTURE_2D, texture_id)
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR)
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR)
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT)
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT)
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, img.width, img.height, 0, GL_RGBA, GL_UNSIGNED_BYTE, img_data)
            
            # Store texture ID and path for cache checking
            setattr(self, texture_id_attr, texture_id)
            setattr(self, cached_path_attr, texture_path)
            return texture_id
        except Exception as e:
            debug(f"Error loading texture {texture_path}: {e}")
            return None
    
    def _draw_skyline(self):
        """Draw skyline (skybox) as background - covers all sides"""
        # Disable depth write so skyline doesn't occlude model
        glDepthMask(GL_FALSE)
        glDisable(GL_LIGHTING)
        glDisable(GL_CULL_FACE)
        
        # Determine skyline size - use environment or default, make it very large
        if self.env_min is not None and self.env_max is not None and self.env_size is not None:
            env_extent = max(self.env_size[0], self.env_size[1], self.env_size[2])
            skyline_size = max(env_extent * 3.0, 1000.0)  # Large enough to always be in background
        else:
            skyline_size = 1000.0
        
        # Position skyline at camera level or above
        # Use a reasonable height - center it around the model or camera
        if self.model_center is not None:
            sky_y_center = self.model_center[1] + skyline_size * 0.3  # Above model
        else:
            sky_y_center = 200.0
        
        sky_bottom = sky_y_center - skyline_size * 0.5
        sky_top = sky_y_center + skyline_size * 0.5
        
        # Try to load skyline texture
        skyline_texture_id = None
        if self.skyline_texture_path:
            debug(f"Attempting to load skyline texture from: {self.skyline_texture_path}")
            skyline_texture_id = self._load_texture_if_needed(self.skyline_texture_path, 'skyline_texture_id')
            if skyline_texture_id:
                debug(f"Successfully loaded skyline texture ID: {skyline_texture_id}")
            else:
                debug(f"Failed to load skyline texture (texture_id is None)")
        else:
            debug("No skyline texture path set, using color")
        
        if skyline_texture_id:
            glEnable(GL_TEXTURE_2D)
            glBindTexture(GL_TEXTURE_2D, skyline_texture_id)
        else:
            glDisable(GL_TEXTURE_2D)
            # Use color
            color = self.skyline_color
            glColor4f(color.redF(), color.greenF(), color.blueF(), 1.0)
        
        half_size = skyline_size * 0.5
        
        # Calculate texture coordinates based on mode
        if skyline_texture_id:
            mode = getattr(self, 'skyline_texture_mode', 'Stretch')
            scale_x = getattr(self, 'skyline_texture_scale_x', 1.0)
            scale_y = getattr(self, 'skyline_texture_scale_y', 1.0)
            
            if mode == "Stretch":
                # Stretch to fill each face
                tex_u_max = 1.0
                tex_v_max = 1.0
            elif mode.startswith("Repeat"):
                # Extract repeat count from mode name or use custom scale
                if mode == "Repeat (1x1)":
                    repeat_x, repeat_y = 1.0, 1.0
                elif mode == "Repeat (2x2)":
                    repeat_x, repeat_y = 2.0, 2.0
                elif mode == "Repeat (4x4)":
                    repeat_x, repeat_y = 4.0, 4.0
                elif mode == "Repeat (8x8)":
                    repeat_x, repeat_y = 8.0, 8.0
                else:  # Custom
                    repeat_x = scale_x
                    repeat_y = scale_y
                
                # For skybox, repeat based on face size
                face_size = skyline_size
                tex_u_max = repeat_x
                tex_v_max = repeat_y
            else:
                tex_u_max = 1.0
                tex_v_max = 1.0
        else:
            tex_u_max = 1.0
            tex_v_max = 1.0
        
        # Draw full skybox (6 faces) - positioned far from origin to always be in background
        glBegin(GL_QUADS)
        
        # Top face (sky)
        if skyline_texture_id:
            glTexCoord2f(0.0, 0.0)
        glVertex3f(-half_size, sky_top, -half_size)
        if skyline_texture_id:
            glTexCoord2f(tex_u_max, 0.0)
        glVertex3f(half_size, sky_top, -half_size)
        if skyline_texture_id:
            glTexCoord2f(tex_u_max, tex_v_max)
        glVertex3f(half_size, sky_top, half_size)
        if skyline_texture_id:
            glTexCoord2f(0.0, tex_v_max)
        glVertex3f(-half_size, sky_top, half_size)
        
        # Bottom face (below horizon - should not be visible normally)
        if skyline_texture_id:
            glTexCoord2f(0.0, 0.0)
        glVertex3f(-half_size, sky_bottom, half_size)
        if skyline_texture_id:
            glTexCoord2f(tex_u_max, 0.0)
        glVertex3f(half_size, sky_bottom, half_size)
        if skyline_texture_id:
            glTexCoord2f(tex_u_max, tex_v_max)
        glVertex3f(half_size, sky_bottom, -half_size)
        if skyline_texture_id:
            glTexCoord2f(0.0, tex_v_max)
        glVertex3f(-half_size, sky_bottom, -half_size)
        
        # Front face (positive Z)
        if skyline_texture_id:
            glTexCoord2f(0.0, 0.0)
        glVertex3f(-half_size, sky_bottom, half_size)
        if skyline_texture_id:
            glTexCoord2f(tex_u_max, 0.0)
        glVertex3f(half_size, sky_bottom, half_size)
        if skyline_texture_id:
            glTexCoord2f(tex_u_max, tex_v_max)
        glVertex3f(half_size, sky_top, half_size)
        if skyline_texture_id:
            glTexCoord2f(0.0, tex_v_max)
        glVertex3f(-half_size, sky_top, half_size)
        
        # Back face (negative Z)
        if skyline_texture_id:
            glTexCoord2f(0.0, 0.0)
        glVertex3f(half_size, sky_bottom, -half_size)
        if skyline_texture_id:
            glTexCoord2f(tex_u_max, 0.0)
        glVertex3f(-half_size, sky_bottom, -half_size)
        if skyline_texture_id:
            glTexCoord2f(tex_u_max, tex_v_max)
        glVertex3f(-half_size, sky_top, -half_size)
        if skyline_texture_id:
            glTexCoord2f(0.0, tex_v_max)
        glVertex3f(half_size, sky_top, -half_size)
        
        # Left face (negative X)
        if skyline_texture_id:
            glTexCoord2f(0.0, 0.0)
        glVertex3f(-half_size, sky_bottom, -half_size)
        if skyline_texture_id:
            glTexCoord2f(tex_u_max, 0.0)
        glVertex3f(-half_size, sky_bottom, half_size)
        if skyline_texture_id:
            glTexCoord2f(tex_u_max, tex_v_max)
        glVertex3f(-half_size, sky_top, half_size)
        if skyline_texture_id:
            glTexCoord2f(0.0, tex_v_max)
        glVertex3f(-half_size, sky_top, -half_size)
        
        # Right face (positive X)
        if skyline_texture_id:
            glTexCoord2f(0.0, 0.0)
        glVertex3f(half_size, sky_bottom, half_size)
        if skyline_texture_id:
            glTexCoord2f(tex_u_max, 0.0)
        glVertex3f(half_size, sky_bottom, -half_size)
        if skyline_texture_id:
            glTexCoord2f(tex_u_max, tex_v_max)
        glVertex3f(half_size, sky_top, -half_size)
        if skyline_texture_id:
            glTexCoord2f(0.0, tex_v_max)
        glVertex3f(half_size, sky_top, half_size)
        
        glEnd()
        
        if skyline_texture_id:
            glDisable(GL_TEXTURE_2D)
        
        glDepthMask(GL_TRUE)
        glEnable(GL_LIGHTING)
        glEnable(GL_CULL_FACE)
    
    def _draw_floor(self):
        """Draw floor/background plane"""
        glDisable(GL_LIGHTING)
        glDisable(GL_CULL_FACE)
        
        # Determine floor position - should be at ground level (Y=0 or just below model bottom)
        if self.model_min is not None:
            # Position floor just below the lowest point of the model
            y_pos = self.model_min[1] - 0.1
        elif self.env_min is not None:
            # Fallback to env_min if model_min not available
            y_pos = min(self.env_min[1] - 0.1, 0.0)  # Don't go too far down
        else:
            y_pos = -0.1  # Default ground level
        
        # Determine floor bounds - make it large enough to extend beyond view
        if self.env_min is not None and self.env_max is not None and self.env_size is not None:
            # Use environment bounds but extend further
            env_extent = max(self.env_size[0], self.env_size[2])  # X and Z extent
            floor_size = max(env_extent * 2.0, 500.0)  # At least 500 units, or 2x env size
            x_min = -floor_size
            x_max = floor_size
            z_min = -floor_size
            z_max = floor_size
        else:
            # Default floor
            floor_size = 500.0
            x_min = -floor_size
            x_max = floor_size
            z_min = -floor_size
            z_max = floor_size
        
        # Try to load floor texture (uses same texture as background)
        floor_texture_id = None
        texture_path = self.floor_texture_path if self.floor_texture_path else self.background_texture_path
        
        debug(f"_draw_floor: floor_texture_path={self.floor_texture_path}, background_texture_path={self.background_texture_path}, using={texture_path}")
        
        # Only try to load texture if a path is set (not empty/"None (use color)")
        has_texture_path = bool(texture_path and texture_path.strip())
        if texture_path and texture_path.strip():
            debug(f"Attempting to load floor texture from: {texture_path}")
            floor_texture_id = self._load_texture_if_needed(texture_path, 'floor_texture_id')
            if floor_texture_id:
                debug(f"Successfully loaded floor texture ID: {floor_texture_id}")
                # Also store as background_texture_id for consistency
                if not hasattr(self, 'background_texture_id') or self.background_texture_id is None:
                    self.background_texture_id = floor_texture_id
            elif has_texture_path:
                # Texture path was set but loading failed - log debug message
                debug(f"Failed to load floor texture from: {texture_path}")
        else:
            debug("No texture path set for floor, using color")
            # No texture path - clear any existing texture IDs
            if hasattr(self, 'floor_texture_id') and self.floor_texture_id:
                glDeleteTextures([self.floor_texture_id])
                self.floor_texture_id = None
            if hasattr(self, 'background_texture_id') and self.background_texture_id:
                glDeleteTextures([self.background_texture_id])
                self.background_texture_id = None
        
        # Use texture if we successfully loaded one, otherwise use color
        if floor_texture_id:
            glEnable(GL_TEXTURE_2D)
            glBindTexture(GL_TEXTURE_2D, floor_texture_id)
            # Reset color to white when using texture (textures use their own colors)
            glColor4f(1.0, 1.0, 1.0, 1.0)
        else:
            glDisable(GL_TEXTURE_2D)
            # Use color only if no texture path was set (i.e., "None (use color)" was selected)
            # OR if texture loading failed (fallback to color)
            color = self.floor_color
            glColor4f(color.redF(), color.greenF(), color.blueF(), 1.0)
        
        # Calculate texture coordinates based on mode
        if floor_texture_id:
            mode = getattr(self, 'background_texture_mode', 'Stretch')
            scale_x = getattr(self, 'background_texture_scale_x', 1.0)
            scale_y = getattr(self, 'background_texture_scale_y', 1.0)
            
            if mode == "Stretch":
                # Stretch to fill - single texture covers entire floor
                tex_u_max = 1.0
                tex_v_max = 1.0
            elif mode.startswith("Repeat"):
                # Extract repeat count from mode name or use custom scale
                if mode == "Repeat (1x1)":
                    repeat_x, repeat_y = 1.0, 1.0
                elif mode == "Repeat (2x2)":
                    repeat_x, repeat_y = 2.0, 2.0
                elif mode == "Repeat (4x4)":
                    repeat_x, repeat_y = 4.0, 4.0
                elif mode == "Repeat (8x8)":
                    repeat_x, repeat_y = 8.0, 8.0
                else:  # Custom
                    repeat_x = scale_x
                    repeat_y = scale_y
                
                # Use repeat count directly as texture coordinate max
                # This will tile the texture 'repeat_count' times in each direction
                tex_u_max = repeat_x
                tex_v_max = repeat_y
            else:
                tex_u_max = 1.0
                tex_v_max = 1.0
        else:
            tex_u_max = 1.0
            tex_v_max = 1.0
        
        # Draw floor quad
        glBegin(GL_QUADS)
        
        if floor_texture_id:
            glTexCoord2f(0.0, 0.0)
        glVertex3f(x_min, y_pos, z_min)
        if floor_texture_id:
            glTexCoord2f(tex_u_max, 0.0)
        glVertex3f(x_max, y_pos, z_min)
        if floor_texture_id:
            glTexCoord2f(tex_u_max, tex_v_max)
        glVertex3f(x_max, y_pos, z_max)
        if floor_texture_id:
            glTexCoord2f(0.0, tex_v_max)
        glVertex3f(x_min, y_pos, z_max)
        
        glEnd()
        
        if floor_texture_id:
            glDisable(GL_TEXTURE_2D)
        
        # Ensure depth test is enabled so grid draws correctly on top of floor
        glEnable(GL_DEPTH_TEST)
        glEnable(GL_LIGHTING)
        glEnable(GL_CULL_FACE)

    def _draw_model(self):
        if self.vertices is None or self.indices is None:
            return
        
        # Enable texturing if we have textures
        has_textures = len(self.textures) > 0 and self.tex_coords is not None
        
        if has_textures:
            glEnable(GL_TEXTURE_2D)
            glEnableClientState(GL_TEXTURE_COORD_ARRAY)
        else:
            glDisable(GL_TEXTURE_2D)
            glDisableClientState(GL_TEXTURE_COORD_ARRAY)
        
        # Handle Unlit style - disable lighting for this style
        if self.lighting_style == "Unlit":
            glDisable(GL_LIGHTING)
            glColor3f(0.7, 0.8, 0.85)  # Model base color
        elif self.model_lit and not self.external_light_enabled:
            # Uniform lighting mode - use color material
            glColor3f(0.7, 0.8, 0.85)  # Model base color
            glEnable(GL_LIGHTING)  # Ensure lighting is enabled
        else:
            glEnable(GL_LIGHTING)  # Ensure lighting is enabled
            # When external light is on, don't set color - let material properties control it
        
        # Enable and set up vertex array
        glEnableClientState(GL_VERTEX_ARRAY)
        glVertexPointer(3, GL_FLOAT, 0, self.vertices)
        
        # Enable and set up normal array
        if self.normals is not None:
            glEnableClientState(GL_NORMAL_ARRAY)
            glNormalPointer(GL_FLOAT, 0, self.normals)
        else:
            glDisableClientState(GL_NORMAL_ARRAY)
        
        # Enable and set up texture coordinate array
        if has_textures:
            # Ensure texture coordinates are contiguous float32
            self.tex_coords = np.ascontiguousarray(self.tex_coords, dtype=np.float32)
            glEnableClientState(GL_TEXTURE_COORD_ARRAY)
            glTexCoordPointer(2, GL_FLOAT, 0, self.tex_coords)
            
            # Enable multi-texturing for blended textures (eyes)
            # Check if any materials use texture blending
            if self.blended_textures:
                glClientActiveTexture(GL_TEXTURE1)
                glEnableClientState(GL_TEXTURE_COORD_ARRAY)
                glTexCoordPointer(2, GL_FLOAT, 0, self.tex_coords)
                glClientActiveTexture(GL_TEXTURE0)
        else:
            glDisableClientState(GL_TEXTURE_COORD_ARRAY)
        
        # Enable texturing
        glEnable(GL_TEXTURE_2D)
        
        # Set shading mode based on lighting style
        if self.lighting_style == "Low Poly":
            # Use flat shading for true low-poly look (no interpolation)
            glShadeModel(GL_FLAT)
            # Add subtle ambient fill to prevent overly dark faces
            glLightModelfv(GL_LIGHT_MODEL_AMBIENT, [0.3, 0.3, 0.3, 1.0])  # Ambient fill
        else:
            # Smooth shading for all other modes
            glShadeModel(GL_SMOOTH)
            # Reset to default ambient for smooth modes
            glLightModelfv(GL_LIGHT_MODEL_AMBIENT, [0.2, 0.2, 0.2, 1.0])
        
        # Draw with materials/textures if available
        if has_textures and len(self.face_materials) > 0:
            # Draw faces grouped by material
            current_mat = None
            current_texture = None
            batch_start = 0
            
            for face_idx, mat_name in enumerate(self.face_materials):
                if mat_name != current_mat:
                    # Draw previous batch if any
                    if batch_start < face_idx:
                        num_faces = face_idx - batch_start
                        num_indices = num_faces * 3
                        offset = batch_start * 3
                        # Create a view into the indices array for this batch
                        
                        batch_indices = np.array(
                            self.indices[offset:offset + num_indices], 
                            dtype=np.uint32
                        )
                        
                        # Check if this material batch should be highlighted
                        is_highlighted = (current_mat == self.selected_material) or (current_mat == self.hovered_material)
                        if is_highlighted:
                            # Draw highlight overlay after normal rendering
                            # (We'll draw it after the normal batch)
                            pass
                        
                        glDrawElements(GL_TRIANGLES, num_indices, GL_UNSIGNED_INT, batch_indices)
                        
                        # Draw highlight overlay if this material is highlighted
                        if is_highlighted:
                            # Temporarily disable lighting and use bright color for highlight
                            glDisable(GL_LIGHTING)
                            glDisable(GL_TEXTURE_2D)
                            glColor3f(1.0, 1.0, 0.0)  # Yellow highlight
                            # Draw highlight with wireframe overlay
                            glPolygonMode(GL_FRONT_AND_BACK, GL_LINE)
                            glLineWidth(3.0)
                            glDepthFunc(GL_LEQUAL)  # Draw on top
                            glDrawElements(GL_TRIANGLES, num_indices, GL_UNSIGNED_INT, batch_indices)
                            # Restore settings
                            glDepthFunc(GL_LESS)
                            glPolygonMode(GL_FRONT_AND_BACK, GL_FILL)
                            glLineWidth(1.0)
                            glEnable(GL_LIGHTING)
                            if has_textures:
                                glEnable(GL_TEXTURE_2D)
                    
                    # Switch to new material
                    current_mat = mat_name
                    
                    # Check if this material should be rendered
                    # Pupil materials are only skipped if they have NO faces assigned AND are used for blending
                    # If a pupil material has faces, it must be rendered (it's a separate part of the model)
                    if mat_name and mat_name in self.textures:
                        mat = self.materials.get(mat_name, {})
                        texture_path = mat.get("texture")
                        if texture_path:
                            texture_name = os.path.basename(texture_path)
                            
                            # Count how many faces use this material
                            face_count = sum(1 for fm in self.face_materials if fm == mat_name)
                            
                            # Check if this is a pupil material that might be used for blending
                            is_pupil_used_in_blending = False
                            if 'pupil' in texture_name.lower():
                                # Check if any other material uses this pupil texture for blending
                                for blended_mat, (base_tex, blend_tex) in self.blended_textures.items():
                                    if blend_tex == self.textures[mat_name]:
                                        is_pupil_used_in_blending = True
                                        break
                            
                            # Only skip pupil materials if they have NO faces AND are used for blending
                            # If they have faces, they need to be rendered (separate geometry)
                            if is_pupil_used_in_blending and face_count == 0:
                                # This is a pupil material used only for blending with no faces - skip rendering
                                from Core.Debug import debug
                                debug(f" Skipping pupil material '{mat_name}' (used for blending, no faces)")
                                current_texture = None
                            elif texture_name in self.disabled_textures:
                                # Texture is disabled - don't bind it, but keep texturing enabled for next material
                                current_texture = None
                            else:
                                # Texture is enabled (either in enabled_textures or not in disabled_textures)
                                current_texture = self.textures[mat_name]
                                # Re-enable texturing if it was disabled by previous material
                                glEnable(GL_TEXTURE_2D)
                        else:
                            current_texture = self.textures[mat_name]
                            # Re-enable texturing if it was disabled by previous material
                            glEnable(GL_TEXTURE_2D)
                        
                        # Only bind texture if it's enabled
                        if current_texture is not None:
                            # Check if this material needs texture blending (for eye animation)
                            if mat_name in self.blended_textures:
                                base_tex_id, blend_tex_id = self.blended_textures[mat_name]
                                
                                # Validate that both texture IDs are valid before attempting blending
                                # If either is None or invalid, fall back to standard single texture rendering
                                if base_tex_id is not None and blend_tex_id is not None:
                                    # Enable multi-texturing with blending
                                    # Texture unit 0: base eye texture
                                    glActiveTexture(GL_TEXTURE0)
                                    glEnable(GL_TEXTURE_2D)
                                    glBindTexture(GL_TEXTURE_2D, base_tex_id)
                                    glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE)
                                    
                                    # Texture unit 1: pupil texture (blended using alpha)
                                    glActiveTexture(GL_TEXTURE1)
                                    glEnable(GL_TEXTURE_2D)
                                    glBindTexture(GL_TEXTURE_2D, blend_tex_id)
                                    
                                    # Set up texture combiner to blend pupil over eye using alpha
                                    # In texture unit 1, we blend the pupil over the result from texture unit 0
                                    # GL_PREVIOUS refers to the output from texture unit 0 (the eye texture)
                                    glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_COMBINE)
                                    
                                    # RGB: Blend pupil over eye using alpha
                                    # When pupil alpha is 1 (fully opaque), show only pupil
                                    # When pupil alpha is 0 (transparent), show only eye
                                    # This ensures the pupil fully replaces the eye where it should be opaque
                                    glTexEnvf(GL_TEXTURE_ENV, GL_COMBINE_RGB, GL_INTERPOLATE)
                                    glTexEnvf(GL_TEXTURE_ENV, GL_SOURCE0_RGB, GL_TEXTURE1)  # Pupil texture (foreground)
                                    glTexEnvf(GL_TEXTURE_ENV, GL_OPERAND0_RGB, GL_SRC_COLOR)
                                    glTexEnvf(GL_TEXTURE_ENV, GL_SOURCE1_RGB, GL_PREVIOUS)  # Eye texture from unit 0 (background)
                                    glTexEnvf(GL_TEXTURE_ENV, GL_OPERAND1_RGB, GL_SRC_COLOR)
                                    glTexEnvf(GL_TEXTURE_ENV, GL_SOURCE2_RGB, GL_TEXTURE1)  # Use alpha from pupil for blend factor
                                    glTexEnvf(GL_TEXTURE_ENV, GL_OPERAND2_RGB, GL_SRC_ALPHA)
                                    
                                    # Also set texture unit 1 to use GL_CLAMP_TO_EDGE to prevent border artifacts
                                    glActiveTexture(GL_TEXTURE1)
                                    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE)
                                    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE)
                                    glActiveTexture(GL_TEXTURE0)
                                    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE)
                                    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE)
                                    
                                    # Alpha: Use maximum of eye and pupil alpha (preserve transparency)
                                    glTexEnvf(GL_TEXTURE_ENV, GL_COMBINE_ALPHA, GL_INTERPOLATE)
                                    glTexEnvf(GL_TEXTURE_ENV, GL_SOURCE0_ALPHA, GL_TEXTURE1)  # Pupil alpha
                                    glTexEnvf(GL_TEXTURE_ENV, GL_OPERAND0_ALPHA, GL_SRC_ALPHA)
                                    glTexEnvf(GL_TEXTURE_ENV, GL_SOURCE1_ALPHA, GL_PREVIOUS)  # Eye alpha from unit 0
                                    glTexEnvf(GL_TEXTURE_ENV, GL_OPERAND1_ALPHA, GL_SRC_ALPHA)
                                    glTexEnvf(GL_TEXTURE_ENV, GL_SOURCE2_ALPHA, GL_TEXTURE1)  # Use pupil alpha for blend
                                    glTexEnvf(GL_TEXTURE_ENV, GL_OPERAND2_ALPHA, GL_SRC_ALPHA)
                                    
                                    # Switch back to texture unit 0 for subsequent operations
                                    glActiveTexture(GL_TEXTURE0)
                                else:
                                    # Blending setup is invalid - fall back to standard single texture
                                    from Core.Debug import debug
                                    debug(f" WARNING - Invalid blending setup for '{mat_name}', falling back to single texture")
                                    # Disable texture unit 1 if it was previously enabled
                                    glActiveTexture(GL_TEXTURE1)
                                    glDisable(GL_TEXTURE_2D)
                                    glActiveTexture(GL_TEXTURE0)
                                    glEnable(GL_TEXTURE_2D)
                                    glBindTexture(GL_TEXTURE_2D, current_texture)
                            else:
                                # Standard single texture
                                glEnable(GL_TEXTURE_2D)  # Ensure texturing is enabled
                                glBindTexture(GL_TEXTURE_2D, current_texture)
                                # Disable texture unit 1 if it was previously enabled
                                glActiveTexture(GL_TEXTURE1)
                                glDisable(GL_TEXTURE_2D)
                                glActiveTexture(GL_TEXTURE0)
                        else:
                            # Texture disabled or missing - use material color instead
                            # Unbind texture and use material diffuse color
                            glBindTexture(GL_TEXTURE_2D, 0)
                            glDisable(GL_TEXTURE_2D)  # Disable texturing for this material
                            # Reset color to white (let material properties control color)
                            glColor3f(1.0, 1.0, 1.0)
                        
                        # Apply material properties - boost them for external light
                        if mat_name in self.materials:
                            mat = self.materials[mat_name]
                            if self.external_light_enabled:
                                # Boost material properties for external light with brightness multiplier
                                # Don't clamp to 1.0 - allow brighter materials for better visibility
                                brightness = self.external_light_brightness
                                # Ensure brightness is a float
                                try:
                                    brightness = float(brightness)
                                except (ValueError, TypeError):
                                    brightness = 1.0
                                # Scale ambient and diffuse up significantly - use exponential scaling for brightness > 1.0
                                if brightness > 1.0:
                                    # More aggressive scaling for values above 1.0
                                    scale_factor = 1.5 + (brightness - 1.0) * 2.0  # Extra boost beyond 1.0
                                else:
                                    scale_factor = 1.5 * brightness
                                ambient = [c * scale_factor for c in mat['ambient']] + [1.0]
                                diffuse = [c * scale_factor for c in mat['diffuse']] + [1.0]
                                specular = [c * scale_factor for c in mat['specular']] + [1.0]
                            else:
                                ambient = mat['ambient'] + [1.0]
                                diffuse = mat['diffuse'] + [1.0]
                                specular = mat['specular'] + [1.0]
                            
                            # For Low Poly mode, reduce specular to prevent visible creases
                            if self.lighting_style == "Low Poly":
                                # Reduce specular contribution (multiply by 0.3 to make it subtle)
                                specular = [c * 0.3 for c in specular[:3]] + [specular[3]]
                                # Slightly increase diffuse to even out lighting
                                diffuse = [min(1.0, c * 1.1) for c in diffuse[:3]] + [diffuse[3]]
                            
                            glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT, ambient)
                            glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE, diffuse)
                            glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, specular)
                            # Clamp shininess to valid OpenGL range (0-128)
                            shininess = max(0.0, min(128.0, mat.get('shininess', 0.0)))
                            # For Low Poly, reduce shininess to minimize specular highlights
                            if self.lighting_style == "Low Poly":
                                shininess = shininess * 0.5  # Reduce shininess
                            glMaterialf(GL_FRONT_AND_BACK, GL_SHININESS, shininess)
                    else:
                        # No texture for this material - unbind texture but keep texturing enabled for next material
                        glActiveTexture(GL_TEXTURE1)
                        glDisable(GL_TEXTURE_2D)
                        glActiveTexture(GL_TEXTURE0)
                        glBindTexture(GL_TEXTURE_2D, 0)
                        glDisable(GL_TEXTURE_2D)  # Disable texturing for this material
                        # Reset color to white to let material properties control appearance
                        glColor3f(1.0, 1.0, 1.0)
                        current_texture = None
                    
                    batch_start = face_idx
            
            # Draw final batch
            if batch_start < len(self.face_materials):
                num_faces = len(self.face_materials) - batch_start
                num_indices = num_faces * 3
                offset = batch_start * 3
                batch_indices = np.array(
                    self.indices[offset:offset + num_indices], 
                    dtype=np.uint32
                )
                
                # Check if final material should be highlighted
                if batch_start < len(self.face_materials):
                    final_mat = self.face_materials[batch_start]
                    is_highlighted = (final_mat == self.selected_material) or (final_mat == self.hovered_material)
                else:
                    is_highlighted = False
                
                glDrawElements(GL_TRIANGLES, num_indices, GL_UNSIGNED_INT, batch_indices)
                
                # Draw highlight overlay for final batch if highlighted
                if is_highlighted:
                    glDisable(GL_LIGHTING)
                    glDisable(GL_TEXTURE_2D)
                    glColor3f(1.0, 1.0, 0.0)  # Yellow highlight
                    glPolygonMode(GL_FRONT_AND_BACK, GL_LINE)
                    glLineWidth(3.0)
                    glDepthFunc(GL_LEQUAL)
                    glDrawElements(GL_TRIANGLES, num_indices, GL_UNSIGNED_INT, batch_indices)
                    glDepthFunc(GL_LESS)
                    glPolygonMode(GL_FRONT_AND_BACK, GL_FILL)
                    glLineWidth(1.0)
                    glEnable(GL_LIGHTING)
                    if has_textures:
                        glEnable(GL_TEXTURE_2D)
            
            # Clean up multi-texturing state
            glActiveTexture(GL_TEXTURE1)
            glDisable(GL_TEXTURE_2D)
            glActiveTexture(GL_TEXTURE0)
        else:
            # Draw all at once (no materials)
            glDrawElements(GL_TRIANGLES, len(self.indices), GL_UNSIGNED_INT, self.indices)
        
        if self.normals is not None:
            glDisableClientState(GL_NORMAL_ARRAY)
        if has_textures:
            glDisableClientState(GL_TEXTURE_COORD_ARRAY)
        glDisableClientState(GL_VERTEX_ARRAY)
        
        # Reset line width if wireframe was used
        if self.lighting_style == "Wireframe":
            glLineWidth(1.0)  # Reset to default

    def keyPressEvent(self, event):
        if event.key() in self.keys:
            self.keys[event.key()] = True
        elif event.key() == Qt.Key_Plus or event.key() == Qt.Key_Equal:
            self.camera.fov = max(10.0, self.camera.fov - 2.0)
            self.resizeGL(self.width(), self.height())
        elif event.key() == Qt.Key_Minus:
            self.camera.fov = min(120.0, self.camera.fov + 2.0)
            self.resizeGL(self.width(), self.height())
        else:
            super().keyPressEvent(event)

    def keyReleaseEvent(self, event):
        if event.key() in self.keys:
            self.keys[event.key()] = False
        else:
            super().keyReleaseEvent(event)

    def mousePressEvent(self, event):
        self.last_mouse_pos = event.position().toPoint()
        if event.button() == Qt.LeftButton:
            # Perform picking on left click
            self._pick_material(event.position().toPoint())
        elif event.button() == Qt.MiddleButton:
            self.is_rotating = True
        elif event.button() == Qt.RightButton:
            self.is_panning = True

    def mouseMoveEvent(self, event):
        pos = event.position().toPoint()
        dx = pos.x() - self.last_mouse_pos.x()
        dy = pos.y() - self.last_mouse_pos.y()
        if self.is_rotating:
            if self.smooth_camera:
                # Update target rotation for smooth interpolation
                self.target_yaw -= dx * 0.3
                self.target_pitch -= dy * 0.3
                self.target_pitch = max(-89.0, min(89.0, self.target_pitch))
            else:
                # Instant rotation
                self.camera.yaw -= dx * 0.3
                self.camera.pitch -= dy * 0.3
                self.camera.pitch = max(-89.0, min(89.0, self.camera.pitch))
            self.update()
        elif self.is_panning:
            right = self.camera.get_right()
            up = self.camera.get_up()
            speed_mult = self._get_speed_multiplier()
            pan_speed = 0.02 * speed_mult
            new_pos = self.camera.position + right * (-dx * pan_speed) + up * (dy * pan_speed)
            # Clamp camera position to environment boundaries
            if self.smooth_movement:
                self.target_position = self._clamp_camera_position(new_pos)
            else:
                self.camera.position = self._clamp_camera_position(new_pos)
            self.update()
        self.last_mouse_pos = pos

    def mouseReleaseEvent(self, event):
        self.is_rotating = False
        self.is_panning = False
    
    def _pick_material(self, mouse_pos):
        """Pick material at mouse position using ray casting.
        
        Args:
            mouse_pos: QPoint with screen coordinates
        """
        # Clear previous selection if clicking outside model
        if self.vertices is None or self.indices is None or len(self.face_materials) == 0:
            self.selected_material = None
            self.update()
            return
        
        # Get viewport dimensions
        viewport = glGetIntegerv(GL_VIEWPORT)
        width = viewport[2]
        height = viewport[3]
        
        # Convert Qt coordinates (top-left origin) to OpenGL coordinates (bottom-left origin)
        gl_y = height - mouse_pos.y()
        
        # Read depth buffer at mouse position
        # Make context current for reading pixels
        self.makeCurrent()
        # Note: glReadBuffer is not needed for depth buffer reads in QOpenGLWidget
        
        # Read depth - glReadPixels returns numpy array or bytes
        try:
            depth_data = glReadPixels(int(mouse_pos.x()), int(gl_y), 1, 1, GL_DEPTH_COMPONENT, GL_FLOAT)
            
            # Handle different return formats
            if depth_data is None:
                return
            
            # Convert to float
            if isinstance(depth_data, np.ndarray):
                z_near = float(depth_data.flat[0])
            elif isinstance(depth_data, (list, tuple)):
                z_near = float(depth_data[0] if depth_data else 1.0)
            else:
                # Try to extract from bytes or other formats
                import struct
                if isinstance(depth_data, bytes):
                    z_near = struct.unpack('f', depth_data[:4])[0]
                else:
                    z_near = float(depth_data)
            
            if z_near >= 1.0 or z_near < 0.0:  # No geometry at this pixel (far plane or invalid)
                return
        except Exception as e:
            from Core.Debug import debug
            debug(f" Error reading depth buffer: {e}")
            return
        
        # Unproject to get 3D coordinates
        # Get modelview and projection matrices
        try:
            modelview = glGetDoublev(GL_MODELVIEW_MATRIX)
            projection = glGetDoublev(GL_PROJECTION_MATRIX)
        except:
            return
        
        # Unproject near and far points to create ray
        try:
            near_point = gluUnProject(mouse_pos.x(), gl_y, z_near, modelview, projection, viewport)
            far_point = gluUnProject(mouse_pos.x(), gl_y, 0.99, modelview, projection, viewport)
        except:
            # Fallback to simpler picking using color-based selection buffer
            # For now, just use a simpler approach - check all triangles
            return self._pick_material_simple(mouse_pos)
        
        if not near_point or not far_point:
            return
        
        # Convert to numpy arrays
        ray_origin = np.array(near_point[:3], dtype=np.float32)
        ray_dir = np.array(far_point[:3], dtype=np.float32) - ray_origin
        ray_dir = ray_dir / np.linalg.norm(ray_dir)  # Normalize
        
        # Find closest intersection with any triangle
        closest_dist = float('inf')
        closest_face_idx = -1
        
        num_faces = len(self.indices) // 3
        for face_idx in range(min(num_faces, len(self.face_materials))):
            # Get triangle vertices
            idx_base = face_idx * 3
            v0_idx = self.indices[idx_base]
            v1_idx = self.indices[idx_base + 1]
            v2_idx = self.indices[idx_base + 2]
            
            if v0_idx >= len(self.vertices) or v1_idx >= len(self.vertices) or v2_idx >= len(self.vertices):
                continue
            
            v0 = np.array(self.vertices[v0_idx], dtype=np.float32)
            v1 = np.array(self.vertices[v1_idx], dtype=np.float32)
            v2 = np.array(self.vertices[v2_idx], dtype=np.float32)
            
            # Ray-triangle intersection test (Möller–Trumbore algorithm)
            epsilon = 0.0000001
            edge1 = v1 - v0
            edge2 = v2 - v0
            h = np.cross(ray_dir, edge2)
            a = np.dot(edge1, h)
            
            if abs(a) < epsilon:
                continue  # Ray is parallel to triangle
            
            f = 1.0 / a
            s = ray_origin - v0
            u = f * np.dot(s, h)
            
            if u < 0.0 or u > 1.0:
                continue
            
            q = np.cross(s, edge1)
            v = f * np.dot(ray_dir, q)
            
            if v < 0.0 or u + v > 1.0:
                continue
            
            t = f * np.dot(edge2, q)
            if t > epsilon and t < closest_dist:
                closest_dist = t
                closest_face_idx = face_idx
        
        # If we found an intersection, get the material
        if closest_face_idx >= 0 and closest_face_idx < len(self.face_materials):
            clicked_material = self.face_materials[closest_face_idx]
            self.selected_material = clicked_material
            self.update()  # Refresh display
            
            # Show context menu with texture information
            self._show_texture_info_menu(clicked_material, mouse_pos)
    
    def _show_texture_info_menu(self, material_name, mouse_pos):
        """Show context menu with texture information for clicked material."""
        if not material_name or material_name not in self.materials:
            return
        
        mat = self.materials[material_name]
        texture_path = mat.get("texture")
        texture_name = os.path.basename(texture_path) if texture_path else "None"
        
        # Get texture information
        face_count = sum(1 for fm in self.face_materials if fm == material_name)
        is_enabled = True
        if texture_name:
            is_enabled = texture_name not in self.disabled_textures
        
        # Create menu
        menu = QMenu(self)
        menu.setTitle("Texture Information")
        
        # Texture name
        name_action = menu.addAction(f"Texture Name: {texture_name}")
        name_action.setEnabled(False)  # Non-clickable info
        
        menu.addSeparator()
        
        # Material name
        mat_action = menu.addAction(f"Material: {material_name}")
        mat_action.setEnabled(False)
        
        # Face count
        face_action = menu.addAction(f"Face Count: {face_count}")
        face_action.setEnabled(False)
        
        # Status
        status_text = "Enabled" if is_enabled else "Disabled"
        status_action = menu.addAction(f"Status: {status_text}")
        status_action.setEnabled(False)
        
        # Texture size (if available)
        if texture_path and os.path.exists(texture_path):
            try:
                img = Image.open(texture_path)
                width, height = img.size
                size_action = menu.addAction(f"Texture Size: {width}x{height} pixels")
                size_action.setEnabled(False)
                img.close()
            except:
                pass
        
        menu.addSeparator()
        
        # Texture path (if available)
        if texture_path and os.path.exists(texture_path):
            path_action = menu.addAction(f"Path: {os.path.dirname(texture_path)}")
            path_action.setEnabled(False)
            
            menu.addSeparator()
            
            # Edit texture option
            edit_action = menu.addAction("Edit Texture...")
            edit_action.triggered.connect(lambda: self._edit_texture_from_context(material_name, texture_path))
        else:
            no_file_action = menu.addAction("Texture file not found")
            no_file_action.setEnabled(False)
        
        # Show menu
        global_pos = self.mapToGlobal(mouse_pos)
        menu.exec(global_pos)
    
    def _edit_texture_from_context(self, material_name, texture_path):
        """Open texture in Texture Editor from context menu."""
        # Find parent ModelPreviewWindow to access app
        parent = self.parent()
        while parent:
            if hasattr(parent, 'app') and parent.app:
                # Get model name
                model_name = None
                if hasattr(parent, 'resource_data') and parent.resource_data:
                    model_name = parent.resource_data.get("name")
                
                if model_name:
                    # Find or create texture resource
                    texture_base_name = os.path.splitext(os.path.basename(texture_path))[0]
                    expected_resource_name = f"{model_name}_{texture_base_name}"
                    
                    texture_id = None
                    all_textures = parent.app.resource_manager.project_manager.get_resources("textures")
                    for tex in all_textures:
                        if tex.get("name") == expected_resource_name:
                            texture_id = tex.get("id")
                            break
                    
                    if texture_id and hasattr(parent.app, 'main_window'):
                        parent.app.main_window.open_resource("textures", texture_id)
                break
            parent = parent.parent()
    
    def _pick_material_simple(self, mouse_pos):
        """Simplified picking using color-based selection buffer.
        
        This is a fallback if gluUnProject fails.
        """
        if self.vertices is None or self.indices is None or len(self.face_materials) == 0:
            return
        
        # For now, use a simple approach: render with unique colors per material
        # and read the pixel color to identify the material
        self.makeCurrent()
        
        # Render to selection buffer (off-screen)
        # For simplicity, we'll use the depth buffer we already read
        # and iterate through materials to find which one is at the clicked position
        viewport = glGetIntegerv(GL_VIEWPORT)
        gl_y = viewport[3] - mouse_pos.y()
        
        # Read pixel color from selection render (we'll need to render with material IDs as colors)
        # For now, use a simpler approach: iterate through all faces and check distance from ray
        # Use the clicked pixel's depth to get approximate world position
        
        # Simple heuristic: find material used by faces near the clicked pixel
        # This is less accurate but more reliable
        clicked_material = None
        
        # Try to identify material by checking which materials have faces
        # at similar depth to what we read
        # For simplicity, just pick the first material with many faces
        if self.face_materials:
            # Count faces per material and pick the most common one
            material_counts = {}
            for mat in self.face_materials:
                material_counts[mat] = material_counts.get(mat, 0) + 1
            
            if material_counts:
                clicked_material = max(material_counts.items(), key=lambda x: x[1])[0]
        
        if clicked_material:
            self.selected_material = clicked_material
            self.update()
            self._show_texture_info_menu(clicked_material, mouse_pos)

    def wheelEvent(self, event):
        delta = event.angleDelta().y()
        forward = self.camera.get_forward()
        speed_mult = self._get_speed_multiplier()
        zoom_speed = 0.01 * speed_mult
        new_pos = self.camera.position + forward * (delta * zoom_speed)
        # Clamp camera position to environment boundaries
        if self.smooth_movement:
            self.target_position = self._clamp_camera_position(new_pos)
        else:
            self.camera.position = self._clamp_camera_position(new_pos)
        self.update()

    def _tick(self):
        moved = False
        speed_mult = self._get_speed_multiplier()
        base_speed = 0.2
        speed = base_speed * speed_mult
        forward = self.camera.get_forward()
        right = self.camera.get_right()
        new_pos = self.camera.position
        if self.keys[Qt.Key_W]:
            new_pos = new_pos + forward * speed
            moved = True
        if self.keys[Qt.Key_S]:
            new_pos = new_pos + forward * (-speed)
            moved = True
        if self.keys[Qt.Key_A]:
            new_pos = new_pos + right * (-speed)
            moved = True
        if self.keys[Qt.Key_D]:
            new_pos = new_pos + right * speed
            moved = True
        if moved:
            # Clamp camera position to environment boundaries
            if self.smooth_movement:
                self.target_position = self._clamp_camera_position(new_pos)
            else:
                self.camera.position = self._clamp_camera_position(new_pos)
        
        # Apply smooth interpolation for movement
        if self.smooth_movement:
            # Interpolate position
            delta_x = self.target_position.x - self.camera.position.x
            delta_y = self.target_position.y - self.camera.position.y
            delta_z = self.target_position.z - self.camera.position.z
            delta_length = math.sqrt(delta_x * delta_x + delta_y * delta_y + delta_z * delta_z)
            
            if delta_length > 0.001:
                self.camera.position.x += delta_x * self.smooth_factor
                self.camera.position.y += delta_y * self.smooth_factor
                self.camera.position.z += delta_z * self.smooth_factor
                self.update()
            elif delta_length > 0.0001:
                # Snap to target when very close (to prevent jittering)
                self.camera.position = Vector3(
                    self.target_position.x,
                    self.target_position.y,
                    self.target_position.z
                )
                self.update()
        
        # Apply smooth interpolation for camera rotation
        if self.smooth_camera:
            # Interpolate yaw (handle wrapping around 360/-360)
            delta_yaw = self.target_yaw - self.camera.yaw
            # Normalize to -180 to 180 range
            while delta_yaw > 180:
                delta_yaw -= 360
            while delta_yaw < -180:
                delta_yaw += 360
            self.camera.yaw += delta_yaw * self.smooth_factor
            
            # Interpolate pitch
            delta_pitch = self.target_pitch - self.camera.pitch
            self.camera.pitch += delta_pitch * self.smooth_factor
            self.camera.pitch = max(-89.0, min(89.0, self.camera.pitch))
            
            # Check if we've rotated enough to warrant an update
            if abs(delta_yaw) > 0.1 or abs(delta_pitch) > 0.1:
                self.update()
        
        # If movement happened and smooth is off, update immediately
        if moved and not self.smooth_movement:
            self.update()

    def _obj_index_to_zero_based(self, raw_index, list_length):
        """Convert OBJ index (can be 1-based or negative) to 0-based index for python lists."""
        if raw_index is None:
            return -1
        # OBJ negative indices are relative to end: -1 means last element
        if raw_index < 0:
            return list_length + raw_index  # Python supports negative but we want explicit
        # OBJ positive indices start at 1
        return raw_index - 1
    
    def import_model(self, path: str):
        """Unified model import function - single entry point for all formats.
        
        Detects file type and dispatches to appropriate loader.
        Uses Material Resolver for consistent material handling.
        
        Args:
            path: Path to model file (OBJ, DAE, GLB, GLTF)
            
        Returns:
            bool: True if successful, False otherwise
            
        Raises:
            RuntimeError: If file type is unsupported or loading fails
        """
        if not os.path.exists(path):
            raise RuntimeError(f"Model file not found: {path}")
        
        # Get file extension
        ext = os.path.splitext(path)[1].lower().lstrip('.')
        
        # Dispatch to appropriate loader
        try:
            if ext == 'obj':
                self.load_obj(path)
                return True
            elif ext in ('glb', 'gltf'):
                self.load_gltf(path)
                return True
            elif ext == 'dae':
                self.load_dae(path)
                return True
            elif ext == 'g3d':
                self.load_g3d(path)
                return True
            elif ext == 'model':
                self.load_json_model(path)
                return True
            else:
                raise RuntimeError(f"Unsupported file format: .{ext}\nSupported formats: .obj, .dae, .glb, .gltf, .g3d, .Model")
        except Exception as e:
            # Re-raise with context
            error_msg = f"Failed to load {ext.upper()} file '{os.path.basename(path)}': {str(e)}"
            from Core.Debug import debug
            debug(f" {error_msg}")
            raise RuntimeError(error_msg) from e
    
    def load_obj(self, path: str):
        # Clean up previous textures
        self._cleanup_textures()
        
        vertices = []
        tex_coords_list = []
        faces = []
        current_material = None
        
        # Get model directory for texture loading
        model_dir = os.path.dirname(os.path.abspath(path))
        
        # Initialize Material Resolver for this model
        resolver = MaterialResolver(model_directory=model_dir)
        
        # Store path for MTL resolution later
        self._current_obj_path = path
        
        # First pass: Parse OBJ file
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                
                if line.startswith("v "):
                    # Vertex position
                    parts = line.split()
                    vertices.append([float(parts[1]), float(parts[2]), float(parts[3])])
                elif line.startswith("vt "):
                    # Texture coordinate
                    parts = line.split()
                    tex_coords_list.append([float(parts[1]), float(parts[2])])
                elif line.startswith("mtllib "):
                    # Material library file
                    mtl_filename = line.split()[1]
                    # Handle spaces in filename
                    if len(line.split()) > 2:
                        mtl_filename = " ".join(line.split()[1:])
                    
                    from Core.Debug import debug
                    debug(f" Found mtllib reference: {mtl_filename}")
                    
                    # Try same directory as OBJ first (project folder if imported)
                    mtl_path = os.path.join(model_dir, mtl_filename)
                    
                    # If not found, try original source directory (if different)
                    if not os.path.exists(mtl_path):
                        # Fallback: try to find MTL in various locations
                        alt_paths = [
                            os.path.join(os.path.dirname(os.path.abspath(path)), mtl_filename),
                        ]
                        for alt_path in alt_paths:
                            if os.path.exists(alt_path):
                                mtl_path = alt_path
                                from Core.Debug import debug
                                debug(f" Found MTL at alternate path: {alt_path}")
                                break
                    
                    if os.path.exists(mtl_path):
                        from Core.Debug import debug
                        debug(f" Loading material library: {mtl_path}")
                        # Use the same directory as the MTL file for texture lookup
                        mtl_dir = os.path.dirname(os.path.abspath(mtl_path))
                        self._load_mtl(mtl_path, mtl_dir)
                    else:
                        from Core.Debug import debug
                        debug(f" WARNING - MTL file not found: {mtl_filename}")
                        debug(f"   Tried path: {mtl_path}")
                        debug(f"   Model dir: {model_dir}")
                        # Try to find alternative MTL files in the directory
                        selected_mtl = self._find_and_select_mtl_file(model_dir, mtl_filename)
                        if selected_mtl:
                            mtl_dir = os.path.dirname(os.path.abspath(selected_mtl))
                            self._load_mtl(selected_mtl, mtl_dir)
                        else:
                            from Core.Debug import debug
                            debug(f" No MTL file selected, model will load without materials")
                elif line.startswith("usemtl "):
                    # Material assignment
                    current_material = line.split()[1]
                elif line.startswith("f "):
                    # Face (can include vertex/texture/normal indices)
                    # Format: f v1/vt1/vn1 v2/vt2/vn2 v3/vt3/vn3 or f v1/vt1 v2/vt2 v3/vt3
                    parts = line.split()[1:]
                    face_vertex_data = []  # Store (v_raw, vt_raw, vn_raw) tuples (raw OBJ indices)
                    
                    for p in parts:
                        indices = p.split("/")
                        # Parse raw indices (can be negative, 1-based)
                        v_raw = int(indices[0]) if indices[0] else None
                        vt_raw = int(indices[1]) if len(indices) > 1 and indices[1] else None
                        vn_raw = int(indices[2]) if len(indices) > 2 and indices[2] else None
                        face_vertex_data.append((v_raw, vt_raw, vn_raw))
                    
                    if len(face_vertex_data) >= 3:
                        # Triangulate face - preserve vertex/texture coordinate pairs
                        for i in range(1, len(face_vertex_data) - 1):
                            face_data = {
                                'vertex_data': [
                                    face_vertex_data[0],
                                    face_vertex_data[i],
                                    face_vertex_data[i + 1]
                                ],
                                'material': current_material
                            }
                            faces.append(face_data)
        
        if not vertices or not faces:
            raise RuntimeError("OBJ contains no geometry")
        
        # Build arrays with correct vertex/texture coordinate mapping
        # OBJ files can have separate indexing for vertices and texture coordinates
        # We need to create a mapping that preserves the (vertex, texcoord) pairs
        
        # Build unique vertex/texcoord combinations
        vertex_map = {}  # Maps (v_idx, vt_idx) -> new_vertex_index
        new_vertices = []
        new_tex_coords = []
        new_indices = []
        self.face_materials = []
        
        vertex_counter = 0
        
        for face in faces:
            face_indices = []
            for v_raw, vt_raw, vn_raw in face['vertex_data']:
                # Convert OBJ indices (1-based, can be negative) to 0-based Python indices
                v_idx = self._obj_index_to_zero_based(v_raw, len(vertices))
                vt_idx = self._obj_index_to_zero_based(vt_raw, len(tex_coords_list)) if vt_raw is not None else -1
                vn_idx = self._obj_index_to_zero_based(vn_raw, len(vertices)) if vn_raw is not None else -1
                
                # Canonical key: use -1 for missing texcoord (never None)
                vt_idx_key = vt_idx if (isinstance(vt_idx, int) and vt_idx >= 0) else -1
                key = (v_idx, vt_idx_key)
                
                if key not in vertex_map:
                    # Create new vertex
                    vertex_map[key] = vertex_counter
                    
                    # Add vertex position (safe bounds check)
                    if 0 <= v_idx < len(vertices):
                        new_vertices.append(vertices[v_idx])
                    else:
                        new_vertices.append([0.0, 0.0, 0.0])
                    
                    # Add texture coordinate; flip V to convert from image top-left to OpenGL bottom-left
                    if vt_idx_key >= 0 and 0 <= vt_idx_key < len(tex_coords_list):
                        u, v = tex_coords_list[vt_idx_key]
                        # Flip V coordinate to match OpenGL convention (bottom-left origin)
                        new_tex_coords.append([u, 1.0 - v])
                    else:
                        new_tex_coords.append([0.0, 0.0])  # safe placeholder
                    
                    vertex_counter += 1
                
                face_indices.append(vertex_map[key])
            
            # Triangulate (faces are already triangles, but handle quad+)
            if len(face_indices) >= 3:
                for i in range(1, len(face_indices) - 1):
                    new_indices.extend([face_indices[0], face_indices[i], face_indices[i + 1]])
                    self.face_materials.append(face.get('material'))
        
        # Ensure arrays are contiguous float32/uint32 before OpenGL use
        self.vertices = np.ascontiguousarray(np.array(new_vertices, dtype=np.float32), dtype=np.float32)
        self.indices = np.ascontiguousarray(np.array(new_indices, dtype=np.uint32), dtype=np.uint32)
        
        if new_tex_coords:
            self.tex_coords = np.ascontiguousarray(np.array(new_tex_coords, dtype=np.float32), dtype=np.float32)
            from Core.Debug import debug
            debug(f" Created {len(new_tex_coords)} texture coordinates for {len(new_vertices)} vertices")
        else:
            self.tex_coords = None
            debug(f" No texture coordinates found in model")
        
        # Robustness check: ensure face_materials count matches triangle count
        num_faces = len(self.indices) // 3
        if len(self.face_materials) != num_faces:
            debug(f"DEBUG WARNING: face_materials ({len(self.face_materials)}) != num_faces ({num_faces})")
            # Pad or trim to match
            default_mat = list(self.materials.keys())[0] if self.materials else None
            while len(self.face_materials) < num_faces:
                self.face_materials.append(default_mat)
            if len(self.face_materials) > num_faces:
                self.face_materials = self.face_materials[:num_faces]
            debug(f" Corrected face_materials count to {len(self.face_materials)}")
        
        # Debug: Check for materials referenced in face_materials but not in materials dict
        missing_materials = set(self.face_materials) - set(self.materials.keys())
        missing_materials.discard(None)  # None is valid (no material assigned)
        if missing_materials:
            debug(f"DEBUG WARNING: Faces reference {len(missing_materials)} materials that don't exist:")
            for mat in missing_materials:
                count = sum(1 for fm in self.face_materials if fm == mat)
                debug(f"  - '{mat}': {count} faces")
                # Create a default material for missing ones
                if mat not in self.materials:
                    self.materials[mat] = {
                        'diffuse': [0.8, 0.8, 0.8],
                        'ambient': [0.2, 0.2, 0.2],
                        'specular': [0.0, 0.0, 0.0],
                        'shininess': 0.0,
                        'texture': None
                    }
                    debug(f"    Created default material for '{mat}'")
        
        # Debug: Print material/face statistics
        debug(f" OBJ Loading Summary:")
        debug(f"  - Vertices: {len(new_vertices)}")
        debug(f"  - Indices: {len(new_indices)} (triangles: {len(new_indices) // 3})")
        debug(f"  - Face materials: {len(self.face_materials)}")
        debug(f"  - Materials defined: {len(self.materials)}")
        if self.materials:
            debug(f"  - Material names: {list(self.materials.keys())}")
            for mat_name, mat_data in self.materials.items():
                tex_file = mat_data.get('texture', 'None')
                debug(f"    - {mat_name}: texture = {tex_file}")
        
        # Extra debugging: print first few vertex/texcoord pairs
        debug(f" First 6 vertex/texcoord pairs:")
        for i in range(min(6, len(new_vertices))):
            uv = new_tex_coords[i] if i < len(new_tex_coords) else None
            debug(f"  V{i}: pos={new_vertices[i]} uv={uv}")
        if len(self.indices) >= 18:
            debug(f" First 18 indices: {self.indices[:18]}")
        
        # Don't auto-load textures - user will click "Load Textures" button
        # Store model directory for later texture loading
        self.model_dir = model_dir
        
        self.normals = self._calculate_normals()
        # Apply scale from resource data if available (for future use)
        scale = getattr(self, '_resource_scale', None)
        self._center_and_scale(scale_factor=scale)
        self.update()
    
    def _load_mtl(self, mtl_path: str, model_dir: str):
        """Load material library (.mtl) file.
        
        Handles both legacy PNG references and new .Texture file references.
        """
        current_material = None
        
        with open(mtl_path, "r", encoding="utf-8", errors="ignore") as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                
                if line.startswith("newmtl "):
                    current_material = line.split()[1]
                    if current_material not in self.materials:
                        self.materials[current_material] = {
                            'diffuse': [0.8, 0.8, 0.8],
                            'ambient': [0.2, 0.2, 0.2],
                            'specular': [0.0, 0.0, 0.0],
                            'shininess': 0.0,
                            'texture': None
                        }
                elif current_material:
                    if line.startswith("map_Kd ") or line.startswith("map_diffuse "):
                        # Diffuse texture map - can be PNG file or .Texture file
                        tex_filename = line.split()[1]
                        # Handle spaces in filename
                        if len(line.split()) > 2:
                            tex_filename = " ".join(line.split()[1:])
                        
                        # MTL references can be:
                        # 1. Direct PNG paths (Textures/ModelName/texture.png) - after import
                        # 2. Relative PNG paths (texture.png) - original or legacy
                        # 3. .Texture files (optional - for advanced features)
                        
                        # Try to resolve texture path
                        tex_resolved = None
                        
                        # Check if it's an absolute path or Textures/ reference
                        if tex_filename.startswith('Textures') or 'Textures' in tex_filename:
                            # This is an organized path - resolve relative to project
                            # Format: Textures\ModelName\texture.png
                            tex_path_normalized = tex_filename.replace('\\', os.path.sep).replace('/', os.path.sep)
                            # Try relative to project Resources folder
                            # Try to get app from parent (ModelPreviewWindow)
                            app = self.app  # Now stored directly in GL widget
                            
                            if app and hasattr(app, 'project_manager'):
                                textures_base = os.path.join(
                                    app.project_manager.get_project_path(),
                                    "Resources", "Textures"
                                )
                                if tex_path_normalized.startswith('Textures'):
                                    tex_path_normalized = tex_path_normalized[len('Textures'):].lstrip(os.path.sep)
                                tex_resolved = os.path.join(textures_base, tex_path_normalized)
                                if not os.path.exists(tex_resolved):
                                    tex_resolved = None
                            else:
                                # No app context, try relative to model directory
                                tex_resolved = None
                        elif os.path.isabs(tex_filename):
                            tex_resolved = tex_filename if os.path.exists(tex_filename) else None
                        else:
                            # Relative path - try multiple locations
                            tex_paths = [
                                os.path.join(model_dir, tex_filename),
                                os.path.join(os.path.dirname(mtl_path), tex_filename)
                            ]
                            # Also try in Textures folder if we have app context
                            if self.app and hasattr(self.app, 'project_manager'):
                                textures_base = os.path.join(
                                    app.project_manager.get_project_path(),
                                    "Resources", "Textures"
                                )
                                # Try ModelName/texture.png pattern
                                model_name_from_path = os.path.basename(model_dir)
                                if model_name_from_path:
                                    tex_paths.append(os.path.join(textures_base, model_name_from_path, tex_filename))
                                # Also try just the texture filename directly in Textures/ModelName/
                                if tex_filename:
                                    tex_paths.append(os.path.join(textures_base, model_name_from_path, os.path.basename(tex_filename)))
                            
                            for tex_path in tex_paths:
                                if os.path.exists(tex_path):
                                    tex_resolved = tex_path
                                    break
                        
                        if tex_resolved:
                            self.materials[current_material]['texture'] = tex_resolved
                            from Core.Debug import debug
                            debug(f" Material '{current_material}' resolved texture: {tex_filename} -> {tex_resolved}")
                        else:
                            # Store as-is - might be resolved later or might be missing
                            self.materials[current_material]['texture'] = tex_filename
                            debug(f" Material '{current_material}' uses texture: {tex_filename} (path resolution deferred)")
                    elif line.startswith("Kd ") or line.startswith("diffuse "):
                        # Diffuse color
                        parts = line.split()
                        if len(parts) >= 4:
                            self.materials[current_material]['diffuse'] = [
                                float(parts[1]), float(parts[2]), float(parts[3])
                            ]
                    elif line.startswith("Ka "):
                        # Ambient color
                        parts = line.split()
                        if len(parts) >= 4:
                            self.materials[current_material]['ambient'] = [
                                float(parts[1]), float(parts[2]), float(parts[3])
                            ]
                    elif line.startswith("Ks "):
                        # Specular color
                        parts = line.split()
                        if len(parts) >= 4:
                            self.materials[current_material]['specular'] = [
                                float(parts[1]), float(parts[2]), float(parts[3])
                            ]
                    elif line.startswith("Ns ") or line.startswith("shininess "):
                        # Shininess - clamp to valid OpenGL range (0-128)
                        # MTL files sometimes use different ranges, so normalize
                        shininess_val = float(line.split()[1])
                        # MTL files can use 0-1000 range or other ranges, normalize to 0-128
                        # If it's already in reasonable range, use it; otherwise clamp
                        if shininess_val < 0:
                            shininess_val = 0.0
                        elif shininess_val > 128:
                            # Scale down if in common range (0-1000), otherwise clamp
                            if shininess_val <= 1000:
                                shininess_val = (shininess_val / 1000.0) * 128.0
                            else:
                                shininess_val = 128.0
                        self.materials[current_material]['shininess'] = shininess_val
    
    def _find_and_select_mtl_file(self, search_dir: str, referenced_mtl: str):
        """Find and prompt user to select MTL file when referenced MTL is not found.
        
        Args:
            search_dir: Directory to search for MTL files
            referenced_mtl: The MTL filename referenced in the OBJ file (for context)
            
        Returns:
            Selected MTL file path, or None if user cancels or no MTL files found
        """
        if not os.path.exists(search_dir):
            from Core.Debug import debug
            debug(f" Search directory does not exist: {search_dir}")
            return None
        
        # Find all .mtl files in the directory
        mtl_files = []
        for filename in os.listdir(search_dir):
            if filename.lower().endswith('.mtl'):
                mtl_path = os.path.join(search_dir, filename)
                if os.path.isfile(mtl_path):
                    mtl_files.append((filename, mtl_path))
        
        if not mtl_files:
            from Core.Debug import debug
            debug(f" No MTL files found in directory: {search_dir}")
            return None
        
        # If only one MTL file found, use it automatically
        if len(mtl_files) == 1:
            selected_mtl = mtl_files[0][1]
            from Core.Debug import debug
            debug(f" Auto-selected single MTL file: {selected_mtl}")
            return selected_mtl
        
        # Multiple MTL files - ask user to select
        debug(f" Found {len(mtl_files)} MTL files in directory")
        
        # Get parent widget for dialog (try to find ModelPreviewWindow)
        parent = None
        widget = self
        while widget is not None:
            if hasattr(widget, 'parent') and widget.parent() is not None:
                widget = widget.parent()
                if hasattr(widget, 'window') and widget.window():
                    parent = widget.window()
                    break
            else:
                break
        
        # Build list of options (show just filenames for user)
        mtl_names = [filename for filename, _ in mtl_files]
        
        # Show selection dialog
        selected_name, ok = QInputDialog.getItem(
            parent,
            "Select Material File",
            f"The OBJ file references '{referenced_mtl}' which was not found.\n\n"
            f"Found {len(mtl_files)} MTL file(s) in the directory.\n"
            "Please select which one to use:",
            mtl_names,
            0,  # Default to first item
            False  # Not editable
        )
        
        if ok and selected_name:
            # Find the selected file path
            for filename, mtl_path in mtl_files:
                if filename == selected_name:
                    from Core.Debug import debug
                    debug(f" User selected MTL file: {mtl_path}")
                    return mtl_path
        
        debug(f" User cancelled MTL selection")
        return None
    
    def load_textures_from_files(self, texture_paths):
        """Load texture files and automatically apply them to materials.
        
        Supports both:
        - Direct PNG/image file paths (backwards compatibility)
        - .Texture file paths (new format - extracts PNG paths from frames)
        
        Args:
            texture_paths: List of paths to texture image files or .Texture files
        """
        if not texture_paths:
            return
        
        from Core.Debug import debug
        debug(f" Loading {len(texture_paths)} texture files")
        
        # Handle both PNG files and optional .Texture files
        # .Texture files are for metadata/management, but PNG files are primary
        final_texture_paths = []
        for tex_path in texture_paths:
            if tex_path.lower().endswith('.texture'):
                # Optional .Texture file - extract PNG paths from frames
                expanded_paths = self._load_texture_file_frames(tex_path)
                if expanded_paths:
                    final_texture_paths.extend(expanded_paths)
                    debug(f" Expanded .Texture file '{tex_path}' to {len(expanded_paths)} frame(s)")
                else:
                    debug(f" Warning - .Texture file '{tex_path}' has no frames")
            else:
                # Direct PNG/image path (primary method)
                final_texture_paths.append(tex_path)
        
        if not final_texture_paths:
            debug(f" No texture paths to load")
            return
        
        # Update texture_paths to use final paths
        texture_paths = final_texture_paths
        debug(f" Loading {len(texture_paths)} texture image file(s)")
        
        # First, try to match textures to materials by filename
        for tex_path in texture_paths:
            tex_filename = os.path.basename(tex_path)
            tex_name_no_ext = os.path.splitext(tex_filename)[0]
            
            debug(f" Processing texture: {tex_filename}")
            
            # Try to match to material by name
            matched_material = None
            matching_materials = []  # Track all materials that use this texture
            
            # Strategy 1: Exact filename match with material's texture field
            # Find ALL materials that use this texture (some textures are shared)
            # This matches textures to materials that were already defined in the MTL file
            for mat_name in self.materials.keys():
                mat_tex = self.materials[mat_name].get('texture', '')
                if mat_tex:
                    # Compare both full path and basename
                    mat_tex_basename = os.path.basename(mat_tex)
                    mat_tex_name_no_ext = os.path.splitext(mat_tex_basename)[0]
                    tex_name_no_ext_without_suffix = tex_name_no_ext
                    
                    # Normalize paths for comparison (handle both / and \)
                    mat_tex_normalized = mat_tex.replace('\\', os.path.sep).replace('/', os.path.sep)
                    tex_path_normalized = tex_path.replace('\\', os.path.sep).replace('/', os.path.sep)
                    
                    # Check if paths match (full path comparison)
                    if os.path.normpath(mat_tex_normalized) == os.path.normpath(tex_path_normalized):
                        matching_materials.append(mat_name)
                        debug(f" Matched texture '{tex_filename}' to material '{mat_name}' (full path match)")
                        continue
                    
                    # Handle cases where texture file was renamed with _1, _2 suffixes
                    # but MTL still references original name (e.g., "texture.png" vs "texture_1.png")
                    if tex_name_no_ext.endswith('_1') or tex_name_no_ext.endswith('_2'):
                        # Try matching without the suffix
                        tex_base_name = tex_name_no_ext.rsplit('_', 1)[0]
                        if mat_tex_name_no_ext.lower() == tex_base_name.lower():
                            matching_materials.append(mat_name)
                            debug(f" Matched texture '{tex_filename}' (with suffix) to material '{mat_name}' (original texture: {mat_tex_basename})")
                            continue
                    
                    # Exact filename match
                    if tex_filename == mat_tex or tex_filename == mat_tex_basename:
                        matching_materials.append(mat_name)
                    # Case-insensitive comparison
                    elif tex_filename.lower() == mat_tex.lower() or tex_filename.lower() == mat_tex_basename.lower():
                        matching_materials.append(mat_name)
                    # Match by name without extension
                    elif tex_name_no_ext.lower() == mat_tex_name_no_ext.lower():
                        matching_materials.append(mat_name)
                    # Match by basename of full path (in case mat_tex is a full path)
                    elif os.path.basename(mat_tex_normalized).lower() == tex_filename.lower():
                        matching_materials.append(mat_name)
            
            # Strategy 1b: Material name matches texture name (common pattern)
            # This helps match materials from MTL files that are named after textures
            for mat_name in self.materials.keys():
                mat_name_no_ext = os.path.splitext(mat_name)[0]
                if tex_name_no_ext.lower() == mat_name.lower() or tex_name_no_ext.lower() == mat_name_no_ext.lower():
                    if mat_name not in matching_materials:
                        matching_materials.append(mat_name)
                        debug(f" Matched texture '{tex_filename}' to material '{mat_name}' (name match with existing material)")
            
            # If multiple materials share this texture, we need to load it for all of them
            if matching_materials:
                # Use the first matching material as the primary (for fallback logic)
                matched_material = matching_materials[0]
                debug(f" Matched texture '{tex_filename}' to {len(matching_materials)} material(s): {matching_materials}")
            else:
                matched_material = None
            
            # Strategy 2: Filename (without extension) matches material name
            if not matched_material:
                for mat_name in self.materials.keys():
                    if tex_name_no_ext.lower() == mat_name.lower():
                        matched_material = mat_name
                        debug(f" Matched texture '{tex_filename}' to material '{mat_name}' (name match)")
                        break
            
            # Strategy 3: If texture name contains material name or vice versa
            if not matched_material:
                for mat_name in self.materials.keys():
                    if mat_name.lower() in tex_name_no_ext.lower() or tex_name_no_ext.lower() in mat_name.lower():
                        matched_material = mat_name
                        debug(f" Matched texture '{tex_filename}' to material '{mat_name}' (partial match)")
                        break
            
            # Strategy 4: If only one material exists, use it (even if no texture reference)
            if not matched_material and len(self.materials) == 1:
                matched_material = list(self.materials.keys())[0]
                debug(f" Matched texture '{tex_filename}' to only material '{matched_material}' (single material fallback)")
            
            # Strategy 4b: If only one texture and one material, assign it
            if not matched_material and len(texture_paths) == 1 and len(self.materials) == 1:
                matched_material = list(self.materials.keys())[0]
                debug(f" Matched texture '{tex_filename}' to only material '{matched_material}' (single texture/material fallback)")
            
            # Strategy 5: Create a new material if no match found
            if not matched_material:
                # Create material name from texture filename
                new_mat_name = tex_name_no_ext
                if new_mat_name not in self.materials:
                    self.materials[new_mat_name] = {
                        'diffuse': [0.8, 0.8, 0.8],
                        'ambient': [0.2, 0.2, 0.2],
                        'specular': [0.0, 0.0, 0.0],
                        'shininess': 0.0,
                        'texture': tex_filename
                    }
                    debug(f" Created new material '{new_mat_name}' for texture '{tex_filename}'")
                matched_material = new_mat_name
            
            # Load the texture
            texture_id = self._load_texture_image(tex_path)
            if texture_id:
                # Assign this texture to all matching materials (some textures are shared across materials)
                if matching_materials:
                    for mat_name in matching_materials:
                        self.textures[mat_name] = texture_id
                        self.materials[mat_name]['texture'] = tex_filename
                        # Debug: Check if this material is used by any faces
                        face_count = sum(1 for fm in self.face_materials if fm == mat_name)
                        debug(f"   Assigned texture '{tex_filename}' to material '{mat_name}' ({face_count} faces)")
                elif matched_material:
                    # Fallback: assign to the matched material (from other strategies)
                    self.textures[matched_material] = texture_id
                    self.materials[matched_material]['texture'] = tex_filename
                    face_count = sum(1 for fm in self.face_materials if fm == matched_material)
                    debug(f"   Assigned texture '{tex_filename}' to material '{matched_material}' ({face_count} faces)")
                
                debug(f" Successfully loaded texture '{tex_filename}' (OpenGL ID: {texture_id})")
                
                # Add to enabled_textures by default (if not already in disabled list)
                if tex_filename not in self.disabled_textures:
                    if tex_filename not in self.enabled_textures:
                        self.enabled_textures.append(tex_filename)
            else:
                debug(f" WARNING - Failed to load texture: {tex_path}")
        
        # If we have materials but no face materials assigned, assign materials to faces
        if self.materials:
            num_faces = len(self.indices) // 3
            if len(self.face_materials) == 0:
                # No material assignments in OBJ - assign first material to all faces
                debug(f" No material assignments found in OBJ, assigning default material to all faces")
                default_mat = list(self.materials.keys())[0]
                self.face_materials = [default_mat] * num_faces
            elif len(self.face_materials) < num_faces:
                # Some faces missing materials - pad with first material
                debug(f" Some faces missing materials, padding with default")
                default_mat = list(self.materials.keys())[0]
                while len(self.face_materials) < num_faces:
                    self.face_materials.append(default_mat)
        
        # If we loaded textures but have no materials yet, create a default material for all faces
        if self.textures and not self.materials:
            debug(f" Textures loaded but no materials - creating default material")
            default_mat = "default"
            self.materials[default_mat] = {
                'diffuse': [0.8, 0.8, 0.8],
                'ambient': [0.2, 0.2, 0.2],
                'specular': [0.0, 0.0, 0.0],
                'shininess': 0.0,
                'texture': None
            }
            # Assign first loaded texture to default material
            if self.textures:
                first_texture_key = list(self.textures.keys())[0]
                self.textures[default_mat] = self.textures[first_texture_key]
                if first_texture_key != default_mat:
                    del self.textures[first_texture_key]
            
            # Assign to all faces
            num_faces = len(self.indices) // 3 if self.indices is not None else 0
            if num_faces > 0:
                self.face_materials = [default_mat] * num_faces
        
        # After loading textures, ensure ALL materials that reference a texture get that texture
        # This handles cases where multiple materials share textures (e.g., Material.004 and Material.006 both use pupil.png)
        for mat_name, mat_data in self.materials.items():
            if mat_name not in self.textures:
                mat_tex = mat_data.get('texture')
                if mat_tex:
                    # Find if another material with the same texture has a loaded texture
                    mat_tex_basename = os.path.basename(mat_tex)
                    for other_mat_name, other_tex_id in self.textures.items():
                        other_mat_tex = self.materials[other_mat_name].get('texture', '')
                        if other_mat_tex and (os.path.basename(other_mat_tex) == mat_tex_basename or other_mat_tex == mat_tex):
                            # Share the texture ID with this material
                            self.textures[mat_name] = other_tex_id
                            debug(f" Shared texture from '{other_mat_name}' to '{mat_name}' (both use '{mat_tex_basename}')")
                            break
        
        # CRITICAL FIX: If face_materials contains None or values that don't match any material,
        # assign them to the first available material (likely created from textures)
        num_faces = len(self.indices) // 3 if self.indices is not None else 0
        if num_faces > 0 and self.materials:
            # Check if any face_materials are None or don't match existing materials
            needs_fix = False
            for i, mat_name in enumerate(self.face_materials):
                if mat_name is None or mat_name not in self.materials:
                    needs_fix = True
                    break
            
            if needs_fix or len(self.face_materials) == 0:
                # Assign all faces to the first available material
                default_mat = list(self.materials.keys())[0]
                debug(f" Fixing face material assignments - assigning {num_faces} faces to material '{default_mat}'")
                self.face_materials = [default_mat] * num_faces
            elif len(self.face_materials) < num_faces:
                # Pad missing faces
                default_mat = list(self.materials.keys())[0]
                debug(f" Padding {num_faces - len(self.face_materials)} missing face materials with '{default_mat}'")
                while len(self.face_materials) < num_faces:
                    self.face_materials.append(default_mat)
        
        debug(f" Texture loading complete - {len(self.textures)} textures loaded for {len(self.materials)} materials")
        if self.textures:
            debug(f"  Loaded textures: {list(self.textures.keys())}")
            for mat_name, tex_id in self.textures.items():
                mat = self.materials.get(mat_name, {})
                tex_file = mat.get('texture', 'unknown')
                face_count = sum(1 for fm in self.face_materials if fm == mat_name) if hasattr(self, 'face_materials') else 0
                debug(f"    Material '{mat_name}': texture='{tex_file}', OpenGL ID={tex_id}, faces={face_count}")
        else:
            debug(f"  WARNING: No textures were loaded! Check texture paths and file existence.")
            if texture_paths:
                debug(f"  Attempted to load {len(texture_paths)} texture(s) but none succeeded.")
                for tex_path in texture_paths:
                    exists = os.path.exists(tex_path) if tex_path else False
                    debug(f"    {tex_path}: exists={exists}")
        debug(f" Face materials assigned: {len(self.face_materials)} faces")
        
        # Auto-detect and set up eye texture blending
        # Enable for models that have both eye and pupil textures
        # This handles Link/Mario style models where pupil is separate texture
        eye_materials_found = False
        pupil_textures_found = False
        for mat_name in self.materials.keys():
            mat_tex = self.materials[mat_name].get('texture', '')
            if mat_tex:
                mat_tex_lower = mat_tex.lower()
                mat_name_lower = mat_name.lower()
                
                # Skip eyebrows and pupils when checking for eyes
                if 'eyebrow' in mat_tex_lower or 'eyebrow' in mat_name_lower:
                    continue  # Skip eyebrows
                if 'pupil' in mat_tex_lower or 'pupil' in mat_name_lower:
                    # This is a pupil texture - mark it as found
                    pupil_textures_found = True
                    continue  # Skip pupils
                
                # Check for eye materials (must contain 'eye' but not eyebrow/pupil which we already excluded)
                if 'eye' in mat_tex_lower or 'eye' in mat_name_lower:
                    eye_materials_found = True
        
        if eye_materials_found and pupil_textures_found:
            debug(f" Detected eye + pupil textures, enabling eye blending")
            self._setup_eye_texture_blending()
        else:
            debug(f" No eye/pupil pattern detected, skipping eye blending")
        
        # Debug: Show which materials have textures
        debug(f" Materials with textures:")
        for mat_name in self.materials.keys():
            has_tex = mat_name in self.textures
            tex_file = self.materials[mat_name].get('texture', 'None')
            face_count = sum(1 for fm in self.face_materials if fm == mat_name)
            is_blended = mat_name in self.blended_textures
            debug(f"  - {mat_name}: texture={tex_file}, has_texture={has_tex}, faces={face_count}, blended={is_blended}")
        
        # Debug: Show face material distribution (first 20 and last 10)
        debug(f" Face material assignments (showing first 20 and unique materials):")
        unique_materials = {}
        for i, mat in enumerate(self.face_materials[:20]):
            if mat not in unique_materials:
                unique_materials[mat] = []
            unique_materials[mat].append(i)
        for mat, indices in unique_materials.items():
            debug(f"  - Material '{mat}': faces {indices[:10]}{'...' if len(indices) > 10 else ''}")
        
        # Count faces per material
        mat_face_counts = {}
        for mat in self.face_materials:
            mat_face_counts[mat] = mat_face_counts.get(mat, 0) + 1
        debug(f" Face counts per material:")
        for mat, count in sorted(mat_face_counts.items(), key=lambda x: x[1], reverse=True):
            has_tex = mat in self.textures if mat else False
            tex_file = self.materials.get(mat, {}).get('texture', 'None') if mat and mat in self.materials else 'N/A'
            debug(f"  - '{mat}': {count} faces, texture={tex_file}, has_texture={has_tex}")
    
    def _setup_eye_texture_blending(self):
        """Auto-detect eye materials and set up texture blending for animation textures.
        
        This implements the SSBU method for Wind Waker Link's eyes:
        - Finds materials containing 'eye' in the name
        - Looks for corresponding 'pupil' texture
        - Sets up blending using alpha channel of one texture
        """
        self.blended_textures = {}
        
        # Find all eye materials (by texture name or material name)
        eye_materials = []
        pupil_texture_id = None
        pupil_mat_name = None
        
        # First, find materials that use eye textures (but not pupil or eyebrow)
        # Must explicitly check for 'eyebrow' FIRST, then check for 'eye' (but not 'eyebrow')
        for mat_name in self.materials.keys():
            mat_tex = self.materials[mat_name].get('texture', '')
            if mat_tex:
                mat_tex_lower = mat_tex.lower()
                mat_name_lower = mat_name.lower()
                
                # Skip if this is an eyebrow or pupil material
                if 'eyebrow' in mat_tex_lower or 'eyebrow' in mat_name_lower:
                    continue  # Skip eyebrows
                if 'pupil' in mat_tex_lower or 'pupil' in mat_name_lower:
                    continue  # Skip pupils
                
                # Now check if this is an eye material (must contain 'eye' but we already excluded eyebrows/pupils)
                if 'eye' in mat_tex_lower or 'eye' in mat_name_lower:
                    eye_materials.append(mat_name)
                    debug(f" Found eye material: '{mat_name}' with texture '{mat_tex}'")
        
        # Find pupil texture - look for materials with 'pupil' in texture name
        for mat_name, tex_id in self.textures.items():
            mat_tex = self.materials.get(mat_name, {}).get('texture', '')
            if mat_tex and 'pupil' in mat_tex.lower():
                pupil_texture_id = tex_id
                pupil_mat_name = mat_name
                debug(f" Found pupil texture '{mat_tex}' (ID: {tex_id}) for blending")
                break
        
        if not eye_materials:
            debug(f" No eye materials found for texture blending")
            return
        
        if not pupil_texture_id:
            debug(f" No pupil texture found for eye blending")
            return
        
        # For each eye material, find its base eye texture and set up blending
        for eye_mat in eye_materials:
            # Find the base eye texture (prefer eye1, but use any eye texture)
            eye_texture_id = None
            eye_tex_name = None
            
            # Try to find eye1 first
            for mat_name, tex_id in self.textures.items():
                mat_tex = self.materials.get(mat_name, {}).get('texture', '')
                if mat_name == eye_mat and mat_name in self.textures:
                    eye_texture_id = self.textures[eye_mat]
                    eye_tex_name = mat_tex
                    break
            
            # If this eye material doesn't have its own texture, look for a shared eye texture
            if not eye_texture_id:
                for mat_name, tex_id in self.textures.items():
                    mat_tex = self.materials.get(mat_name, {}).get('texture', '')
                    if mat_tex:
                        mat_tex_lower = mat_tex.lower()
                        # Must contain 'eye' but NOT 'eyebrow' and NOT 'pupil'
                        if 'eye' in mat_tex_lower and 'eyebrow' not in mat_tex_lower and 'pupil' not in mat_tex_lower:
                            eye_texture_id = tex_id
                            eye_tex_name = mat_tex
                            break  # Use first eye texture found
            
            if eye_texture_id and pupil_texture_id:
                # Validate that texture IDs are actually in the textures dict (safety check)
                if eye_mat in self.textures and eye_texture_id == self.textures[eye_mat]:
                    self.blended_textures[eye_mat] = (eye_texture_id, pupil_texture_id)
                    debug(f" Set up texture blending for '{eye_mat}': base='{eye_tex_name}' (ID: {eye_texture_id}), blend=pupil (ID: {pupil_texture_id})")
                else:
                    debug(f" WARNING - Eye material '{eye_mat}' texture ID mismatch, skipping blending")
            else:
                if not eye_texture_id:
                    debug(f" WARNING - Eye material '{eye_mat}' has no eye texture to blend")
                if not pupil_texture_id:
                    debug(f" WARNING - No pupil texture found for eye blending")
    
    def _load_texture_image(self, image_path: str):
        """Load an image file and create an OpenGL texture"""
        from Core.Debug import debug
        
        # Check if OpenGL context is valid before attempting any OpenGL operations
        if not self.isValid():
            debug(f" OpenGL context not valid, cannot load texture: {image_path}")
            return None
        
        # Make context current before any OpenGL operations
        if not self.makeCurrent():
            debug(f" Failed to make OpenGL context current, cannot load texture: {image_path}")
            return None
        
        try:
            # Load image using PIL
            img = Image.open(image_path)
            
            # Option: Flip image vertically to match OpenGL coordinate system
            # (Alternative to flipping V coordinates - comment out if using V flip instead)
            # img = img.transpose(Image.FLIP_TOP_BOTTOM)
            
            # Convert to RGBA if needed
            if img.mode != 'RGBA':
                if img.mode == 'RGB':
                    img = img.convert('RGBA')
                else:
                    img = img.convert('RGBA')
            
            # Get image data
            img_data = np.array(img, dtype=np.uint8)
            width, height = img.size
            
            # Create OpenGL texture
            texture_id = glGenTextures(1)
            glBindTexture(GL_TEXTURE_2D, texture_id)
            
            # Set texture parameters
            # Use GL_NEAREST for textures with transparency to avoid border artifacts
            # This prevents filtering from sampling transparent edge pixels
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR)
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR)
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE)  # Prevent edge wrapping artifacts
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE)  # Prevent edge wrapping artifacts
            
            # Upload texture data
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, img_data)
            
            debug(f" Created OpenGL texture {texture_id} from {image_path} ({width}x{height})")
            return texture_id
            
        except Exception as e:
            debug(f" ERROR loading texture {image_path}: {e}")
            import traceback
            traceback.print_exc()
            return None
        finally:
            # Always done with context when done
            self.doneCurrent()
    
    def _cleanup_textures(self):
        """Clean up OpenGL textures and reset OpenGL state when loading a new model"""
        # Check if OpenGL context is valid before attempting any OpenGL operations
        if not self.isValid():
            from Core.Debug import debug
            debug(" OpenGL context not valid, skipping texture cleanup")
            # Clear texture references even if context is invalid
            self.textures.clear()
            self.materials.clear()
            self.face_materials.clear()
            self.tex_coords = None
            self.blended_textures.clear()
            return
        
        # Make context current before any OpenGL operations
        if not self.makeCurrent():
            from Core.Debug import debug
            debug(" Failed to make OpenGL context current, skipping texture cleanup")
            # Clear texture references even if context can't be made current
            self.textures.clear()
            self.materials.clear()
            self.face_materials.clear()
            self.tex_coords = None
            self.blended_textures.clear()
            return
        
        try:
            if self.textures:
                texture_ids = list(self.textures.values())
                if texture_ids:
                    glDeleteTextures(len(texture_ids), texture_ids)
            self.textures.clear()
            self.materials.clear()
            self.face_materials.clear()
            self.tex_coords = None
            self.blended_textures.clear()
            
            # Reset OpenGL state to prevent issues when switching between models
            # This is critical when loading OBJ after DAE (or vice versa)
            
            # Reset face culling
            glEnable(GL_CULL_FACE)
            glCullFace(GL_BACK)
            glFrontFace(GL_CCW)  # Counter-clockwise is standard
            
            # Reset depth testing
            glEnable(GL_DEPTH_TEST)
            glDepthFunc(GL_LESS)
            
            # Reset blending
            glDisable(GL_BLEND)
            
            # Clear any bound textures
            glBindTexture(GL_TEXTURE_2D, 0)
            glActiveTexture(GL_TEXTURE0)
            
            from Core.Debug import debug
            debug(" OpenGL state reset after model cleanup")
        except Exception as e:
            from Core.Debug import debug
            debug(f" Error during texture cleanup: {e}")
            # Clear texture references even if OpenGL operations fail
            self.textures.clear()
            self.materials.clear()
            self.face_materials.clear()
            self.tex_coords = None
            self.blended_textures.clear()
        finally:
            # Always done with context when done
            self.doneCurrent()

    def load_gltf(self, path: str):
        """Load GLTF/GLB model"""
        try:
            import trimesh  # type: ignore
        except ImportError:
            raise RuntimeError("GLB/GLTF import requires 'trimesh' package. Please install it with: pip install trimesh")
        except Exception as e:
            raise RuntimeError(f"GLB/GLTF import requires 'trimesh': {str(e)}") from e
        
        scene_or_mesh = trimesh.load(path, force='scene')
        
        # Handle different return types from trimesh.load()
        if isinstance(scene_or_mesh, list):
            # trimesh.load() returned a list of meshes - concatenate them
            debug(f" GLB/GLTF returned list with {len(scene_or_mesh)} items")
            if len(scene_or_mesh) == 0:
                raise RuntimeError("GLB/GLTF file contains no mesh data")
            
            # Filter out any None or invalid mesh objects
            valid_meshes = [m for m in scene_or_mesh if m is not None and hasattr(m, 'vertices') and m.vertices is not None and len(m.vertices) > 0]
            
            if len(valid_meshes) == 0:
                raise RuntimeError("GLB/GLTF file contains meshes but they have no vertex data")
            elif len(valid_meshes) == 1:
                mesh = valid_meshes[0]
            else:
                # Multiple meshes - concatenate them
                debug(f" Concatenating {len(valid_meshes)} meshes from GLB/GLTF")
                mesh = trimesh.util.concatenate(valid_meshes)
            
            # Try to extract animations even from list (if it's a GLB file)
            if path.lower().endswith('.glb'):
                # GLB files may contain animations - try to extract them
                try:
                    import json
                    with open(path, 'rb') as f:
                        # GLB format: 12-byte header + JSON chunk + binary chunk
                        header = f.read(12)
                        if len(header) >= 12:
                            # Read JSON chunk length
                            json_length = int.from_bytes(header[8:12], byteorder='little')
                            json_data = f.read(json_length)
                            gltf_data = json.loads(json_data.decode('utf-8'))
                            self._parse_gltf_animations(gltf_data, path)
                            if self.animations:
                                debug(f" Extracted {len(self.animations)} animation(s) from GLB file")
                except Exception as e:
                    debug(f" Could not extract animations from GLB: {e}")
            
            if not self.animations:
                self.animations = {}
            scene_for_textures = None  # No scene to extract textures from
        elif isinstance(scene_or_mesh, trimesh.Scene):
            # It's a Scene - extract geometry
            mesh = None
            try:
                # Try dump().geometry first
                dumped = scene_or_mesh.dump()
                if hasattr(dumped, 'geometry') and dumped.geometry:
                    geometry_dict = dumped.geometry
                    valid_meshes = [m for m in geometry_dict.values() if m is not None and hasattr(m, 'vertices') and m.vertices is not None and len(m.vertices) > 0]
                    if valid_meshes:
                        mesh = trimesh.util.concatenate(tuple(valid_meshes))
            except (AttributeError, TypeError) as e:
                debug(f" dump().geometry method failed: {e}")
            
            # Fallback: try geometry directly
            if mesh is None:
                try:
                    if hasattr(scene_or_mesh, 'geometry'):
                        geometry_dict = scene_or_mesh.geometry
                        # geometry could be a dict or IndexedList
                        if isinstance(geometry_dict, dict):
                            valid_meshes = [m for m in geometry_dict.values() if m is not None and hasattr(m, 'vertices') and m.vertices is not None and len(m.vertices) > 0]
                        else:
                            # IndexedList or similar - iterate directly
                            valid_meshes = [m for m in geometry_dict if m is not None and hasattr(m, 'vertices') and m.vertices is not None and len(m.vertices) > 0]
                        
                        if valid_meshes:
                            mesh = trimesh.util.concatenate(tuple(valid_meshes))
                except (AttributeError, TypeError) as e:
                    debug(f" geometry method failed: {e}")
            
            if mesh is None:
                raise RuntimeError("GLB/GLTF file contains a scene but no extractable geometry")
            
            # Try to extract animations from scene
            self._extract_animations_from_scene(scene_or_mesh, path)
            scene_for_textures = scene_or_mesh  # Pass scene for texture extraction
        else:
            # It's a single mesh
            mesh = scene_or_mesh
            # No animations in simple mesh
            self.animations = {}
            scene_for_textures = None
        if mesh is None or mesh.vertices is None or len(mesh.vertices) == 0:
            raise RuntimeError("No mesh data in GLTF")
        self.vertices = np.array(mesh.vertices, dtype=np.float32)
        if hasattr(mesh, 'faces') and mesh.faces is not None:
            self.indices = np.array(mesh.faces, dtype=np.uint32).flatten()
        else:
            self.indices = np.arange(len(self.vertices), dtype=np.uint32)
        # Try to get normals from mesh, or calculate them
        if hasattr(mesh, 'vertex_normals') and mesh.vertex_normals is not None and len(mesh.vertex_normals) > 0:
            self.normals = np.array(mesh.vertex_normals, dtype=np.float32)
        else:
            self.normals = self._calculate_normals()
        # Clean up previous state before loading new model
        self._cleanup_textures()
        
        # Extract textures and materials from GLTF/GLB file
        # GLB files embed textures as binary data, GLTF can have embedded or external textures
        try:
            # Only try to extract textures if we have a scene, or if mesh has visual/material data
            if scene_for_textures is not None:
                self._extract_gltf_textures(path, scene_for_textures)
            elif hasattr(mesh, 'visual') and mesh.visual and hasattr(mesh.visual, 'material'):
                # Mesh has visual material - try to extract texture from it
                self._extract_gltf_textures(path, mesh)
            elif isinstance(scene_or_mesh, list):
                # List of meshes - pass list to extract textures from each
                self._extract_gltf_textures(path, scene_or_mesh)
        except Exception as e:
            from Core.Debug import debug
            debug(f" Could not extract textures from GLTF/GLB file: {e}")
            import traceback
            traceback.print_exc()
        
        # Assign face materials for GLB/GLTF
        num_faces = len(self.indices) // 3 if self.indices is not None else 0
        if num_faces > 0:
            if len(self.face_materials) == 0:
                # No face materials assigned - assign based on available materials
                if self.materials:
                    # If we have multiple materials, assign them based on mesh order (for list) or geometry order (for scene)
                    if isinstance(scene_or_mesh, list) and len(scene_or_mesh) > 1:
                        # Multiple meshes - assign materials in order
                        face_idx = 0
                        self.face_materials = []
                        for i, sub_mesh in enumerate(scene_or_mesh):
                            if hasattr(sub_mesh, 'faces') and sub_mesh.faces is not None:
                                sub_face_count = len(sub_mesh.faces)
                                # Try to find material for this mesh
                                mat_name = f"GLTF_Material_{i}" if f"GLTF_Material_{i}" in self.materials else list(self.materials.keys())[i % len(self.materials)]
                                self.face_materials.extend([mat_name] * sub_face_count)
                                debug(f" Assigned {sub_face_count} faces from mesh {i} to material '{mat_name}'")
                    else:
                        # Single mesh or scene - assign first available material
                        default_mat = list(self.materials.keys())[0]
                        self.face_materials = [default_mat] * num_faces
                        debug(f" Assigned all {num_faces} faces to material '{default_mat}'")
                else:
                    # No materials - create default
                    default_mat = "GLTF_Material_Default"
                    self.materials[default_mat] = {
                        'diffuse': [0.8, 0.8, 0.8],
                        'ambient': [0.2, 0.2, 0.2],
                        'specular': [0.0, 0.0, 0.0],
                        'shininess': 0.0,
                        'texture': None
                    }
                    self.face_materials = [default_mat] * num_faces
                    debug(f" Created default material and assigned to all {num_faces} faces")
            elif len(self.face_materials) != num_faces:
                # Fix mismatch
                debug(f"DEBUG WARNING: face_materials ({len(self.face_materials)}) != num_faces ({num_faces})")
                default_mat = list(self.materials.keys())[0] if self.materials else None
                while len(self.face_materials) < num_faces:
                    self.face_materials.append(default_mat)
                if len(self.face_materials) > num_faces:
                    self.face_materials = self.face_materials[:num_faces]
                debug(f" Corrected face_materials count to {len(self.face_materials)}")
        
        # Apply scale from resource data if available (for future use)
        scale = getattr(self, '_resource_scale', None)
        self._center_and_scale(scale_factor=scale)
        self.update()
    
    def load_dae(self, path: str):
        """Load DAE (Collada) model"""
        try:
            import trimesh  # type: ignore
        except ImportError:
            raise RuntimeError("DAE import requires 'trimesh' package. Please install it with: pip install trimesh")
        except Exception as e:
            raise RuntimeError(f"DAE import requires 'trimesh': {str(e)}") from e
        
        # Check for pycollada explicitly - trimesh requires it for DAE files
        # Note: pip installs as 'pycollada' but imports as 'collada'
        # Clear import cache to ensure we can find newly installed packages
        importlib.invalidate_caches()
        
        try:
            # Try importing as 'collada' (actual module name)
            import collada  # type: ignore
            # Verify it's actually usable by checking for main module
            if not hasattr(collada, 'Collada'):
                raise ImportError("collada module is missing required components")
        except ImportError as e:
            import_error_msg = str(e)
            from Core.Debug import debug
            debug(f" collada import failed: {import_error_msg}")
            debug(f" Python executable: {sys.executable}")
            debug(f" Python path: {sys.path[:3]}...")  # Show first 3 entries
            
            # Generic error message
            raise RuntimeError(
                "DAE import requires 'pycollada' package (imports as 'collada').\n"
                f"Please install it with: pip install pycollada\n"
                f"Python executable: {sys.executable}\n"
                f"Error: {import_error_msg}"
            )
        
        try:
            scene_or_mesh = trimesh.load(path, force='scene')
            debug(f" trimesh.load() returned type: {type(scene_or_mesh)}")
            if isinstance(scene_or_mesh, list):
                debug(f" List contains {len(scene_or_mesh)} items")
                for i, item in enumerate(scene_or_mesh):
                    debug(f"   Item {i}: {type(item)}, vertices: {len(item.vertices) if hasattr(item, 'vertices') and item.vertices is not None else 0}")
            elif isinstance(scene_or_mesh, trimesh.Scene):
                debug(f" Scene geometry count: {len(scene_or_mesh.geometry) if hasattr(scene_or_mesh, 'geometry') else 'unknown'}")
            elif hasattr(scene_or_mesh, 'vertices'):
                debug(f" Mesh vertices: {len(scene_or_mesh.vertices) if scene_or_mesh.vertices is not None else 0}")
        except Exception as e:
            error_msg = str(e)
            # Check if the error mentions pycollada or collada
            if 'pycollada' in error_msg.lower() or 'collada' in error_msg.lower():
                raise RuntimeError(f"DAE loading failed - pycollada may not be properly installed: {error_msg}\nTry: pip install --upgrade pycollada")
            else:
                raise RuntimeError(f"Failed to load DAE file: {error_msg}") from e
        
        # Handle different return types from trimesh.load()
        if isinstance(scene_or_mesh, trimesh.Scene):
            # It's a Scene - extract geometry
            mesh = None
            
            # Try multiple methods to extract geometry from Scene
            # Method 1: Try dump().geometry
            try:
                if hasattr(scene_or_mesh, 'dump'):
                    dumped = scene_or_mesh.dump()
                    if hasattr(dumped, 'geometry') and dumped.geometry:
                        geometry_dict = dumped.geometry
                        valid_meshes = [m for m in geometry_dict.values() if m is not None and hasattr(m, 'vertices') and m.vertices is not None and len(m.vertices) > 0]
                        if valid_meshes:
                            mesh = trimesh.util.concatenate(tuple(valid_meshes))
            except (AttributeError, TypeError) as e:
                debug(f" Method 1 (dump().geometry) failed: {e}")
            
            # Method 2: Try geometry directly
            if mesh is None:
                try:
                    if hasattr(scene_or_mesh, 'geometry'):
                        geometry_dict = scene_or_mesh.geometry
                        # geometry could be a dict or IndexedList
                        if isinstance(geometry_dict, dict):
                            valid_meshes = [m for m in geometry_dict.values() if m is not None and hasattr(m, 'vertices') and m.vertices is not None and len(m.vertices) > 0]
                        else:
                            # IndexedList or similar - iterate directly
                            valid_meshes = [m for m in geometry_dict if m is not None and hasattr(m, 'vertices') and m.vertices is not None and len(m.vertices) > 0]
                        
                        if valid_meshes:
                            mesh = trimesh.util.concatenate(tuple(valid_meshes))
                except (AttributeError, TypeError) as e:
                    debug(f" Method 2 (geometry) failed: {e}")
            
            # Method 3: Try accessing nodes and their meshes
            if mesh is None:
                try:
                    if hasattr(scene_or_mesh, 'scene') and hasattr(scene_or_mesh.scene, 'nodes'):
                        valid_meshes = []
                        for node in scene_or_mesh.scene.nodes:
                            if hasattr(node, 'meshes'):
                                for mesh_name in node.meshes:
                                    if mesh_name in scene_or_mesh.geometry:
                                        m = scene_or_mesh.geometry[mesh_name]
                                        if m is not None and hasattr(m, 'vertices') and m.vertices is not None and len(m.vertices) > 0:
                                            valid_meshes.append(m)
                        if valid_meshes:
                            mesh = trimesh.util.concatenate(tuple(valid_meshes))
                except (AttributeError, TypeError) as e:
                    debug(f" Method 3 (nodes) failed: {e}")
            
            if mesh is None:
                raise RuntimeError(
                    "DAE file contains a scene but no extractable geometry.\n\n"
                    "This DAE file may be:\n"
                    "- A material/texture definition file (no mesh data)\n"
                    "- An animation file (references other files)\n"
                    "- A reference file\n\n"
                    "Try loading:\n"
                    "- The OBJ file instead (usually contains the actual mesh)\n"
                    "- A different DAE file with mesh data"
                )
            
            # Try to extract animations from scene (GLTF/GLB)
            self._extract_animations_from_scene(scene_or_mesh, path)
            
            # Also try to extract animations directly from DAE file using collada library
            # (This handles embedded DAE animations that trimesh might not extract)
            if path.lower().endswith('.dae'):
                self._extract_dae_animations(path)
        elif isinstance(scene_or_mesh, list):
            # trimesh.load() returned a list of meshes - concatenate them
            if len(scene_or_mesh) == 0:
                raise RuntimeError(
                    "DAE file contains no mesh data.\n\n"
                    "This DAE file may be a material/texture definition file or a reference file.\n"
                    "Try loading a different DAE file (e.g., the one with 'baked' in the name)."
                )
            
            # Filter out any None or invalid mesh objects
            valid_meshes = [m for m in scene_or_mesh if m is not None and hasattr(m, 'vertices') and m.vertices is not None and len(m.vertices) > 0]
            
            if len(valid_meshes) == 0:
                raise RuntimeError(
                    "DAE file contains meshes but they have no vertex data.\n\n"
                    "This DAE file may be incomplete or corrupted.\n"
                    "Try loading a different DAE file from the model set."
                )
            elif len(valid_meshes) == 1:
                mesh = valid_meshes[0]
            else:
                # Multiple meshes - concatenate them
                debug(f" Concatenating {len(valid_meshes)} meshes")
                mesh = trimesh.util.concatenate(valid_meshes)
            # No animations in simple mesh list
            self.animations = {}
        elif isinstance(scene_or_mesh, trimesh.Trimesh):
            # It's a single mesh
            mesh = scene_or_mesh
            # No animations in simple mesh
            self.animations = {}
        else:
            raise RuntimeError(
                f"Unexpected return type from trimesh.load(): {type(scene_or_mesh)}\n\n"
                "This DAE file may not be a valid mesh file.\n"
                "Try loading a different DAE file (e.g., the one with 'baked' in the name)."
            )
        
        if mesh is None:
            raise RuntimeError(
                "No mesh data in DAE file.\n\n"
                "This DAE file may be a material/texture definition file or a reference file.\n"
                "Try loading the DAE file with 'baked' in the name, or one of the OBJ files instead."
            )
        
        if mesh.vertices is None or len(mesh.vertices) == 0:
            raise RuntimeError(
                "DAE file contains a mesh but it has no vertices.\n\n"
                "This DAE file may be incomplete or corrupted.\n"
                "Try loading:\n"
                "- The DAE file with 'baked' in the name (usually contains the full model)\n"
                "- One of the OBJ files instead"
            )
        self.vertices = np.array(mesh.vertices, dtype=np.float32)
        if hasattr(mesh, 'faces') and mesh.faces is not None:
            self.indices = np.array(mesh.faces, dtype=np.uint32).flatten()
        else:
            self.indices = np.arange(len(self.vertices), dtype=np.uint32)
        # Try to get normals from mesh, or calculate them
        if hasattr(mesh, 'vertex_normals') and mesh.vertex_normals is not None and len(mesh.vertex_normals) > 0:
            self.normals = np.array(mesh.vertex_normals, dtype=np.float32)
        else:
            self.normals = self._calculate_normals()
        
        # Check for vertex colors (baked textures) - "baked" DAE files often store colors here
        if hasattr(mesh, 'visual') and mesh.visual:
            visual = mesh.visual
            # Check for vertex colors
            if hasattr(visual, 'vertex_colors') and visual.vertex_colors is not None:
                debug(f" Found vertex colors (baked textures) in DAE file")
                # Store vertex colors for potential use (we could use these instead of textures)
                try:
                    self.vertex_colors = np.array(visual.vertex_colors, dtype=np.float32)
                    debug(f" Loaded {len(self.vertex_colors)} vertex colors")
                except Exception as e:
                    debug(f" Could not extract vertex colors: {e}")
                    self.vertex_colors = None
            else:
                self.vertex_colors = None
        else:
            self.vertex_colors = None
        
        # Clean up previous state before loading new model
        self._cleanup_textures()
        
        # Get model directory for Material Resolver
        model_dir = os.path.dirname(os.path.abspath(path))
        resolver = MaterialResolver(model_directory=model_dir)
        
        # Extract textures from DAE file using collada directly
        # (trimesh doesn't extract textures from DAE files)
        try:
            self._extract_dae_textures(path, resolver)
        except Exception as e:
            debug(f" Could not extract textures from DAE file: {e}")
            import traceback
            traceback.print_exc()
        
        # Assign face materials - needed for materials to be applied during rendering
        num_faces = len(self.indices) // 3
        if num_faces > 0:
            # Use the first/default material found, or create one if none exist
            if not self.materials:
                default_mat = "DAE_Material_Default"
                self.materials[default_mat] = {
                    'diffuse': [0.8, 0.8, 0.8],
                    'ambient': [0.2, 0.2, 0.2],
                    'specular': [0.0, 0.0, 0.0],
                    'shininess': 0.0,
                    'texture': None
                }
            
            # Assign materials to faces
            if len(self.face_materials) == 0:
                # Assign default material to all faces
                default_mat = list(self.materials.keys())[0] if self.materials else "DAE_Material_Default"
                self.face_materials = [default_mat] * num_faces
                debug(f" Assigned material '{default_mat}' to {num_faces} faces")
            elif len(self.face_materials) != num_faces:
                # Fix mismatch - pad with default material
                default_mat = list(self.materials.keys())[0] if self.materials else "DAE_Material_Default"
                while len(self.face_materials) < num_faces:
                    self.face_materials.append(default_mat)
                self.face_materials = self.face_materials[:num_faces]
        
        # Apply scale from resource data if available
        scale = getattr(self, '_resource_scale', None)
        self._center_and_scale(scale_factor=scale)
        self.update()
    
    def _extract_gltf_textures(self, gltf_path: str, scene_or_mesh):
        """Extract textures and materials from GLTF/GLB file.
        
        GLB files embed textures as binary data within the file.
        GLTF files can have embedded (base64) or external texture references.
        trimesh can extract visual materials and textures from GLTF/GLB.
        """
        try:
            import trimesh  # type: ignore
        except ImportError:
            debug(f" Cannot extract GLTF textures - trimesh module not available")
            return
        
        try:
            gltf_dir = os.path.dirname(os.path.abspath(gltf_path))
            debug(f" Extracting textures from GLTF/GLB file: {gltf_path}")
            debug(f" GLTF directory: {gltf_dir}")
            
            texture_files_found = []
            
            # Handle different input types
            if isinstance(scene_or_mesh, list):
                # List of meshes - extract textures from each mesh
                debug(f" Processing {len(scene_or_mesh)} meshes for textures")
                for i, mesh in enumerate(scene_or_mesh):
                    if hasattr(mesh, 'visual') and mesh.visual:
                        # Extract texture from mesh visual
                        visual = mesh.visual
                        if hasattr(visual, 'material') and visual.material:
                            material = visual.material
                            
                            # Check for embedded PIL Image - save it to temp file and load it
                            if hasattr(material, 'image') and material.image is not None:
                                try:
                                    from PIL import Image
                                    import tempfile
                                    
                                    # material.image could be PIL Image or numpy array
                                    if hasattr(material.image, 'save'):
                                        # PIL Image - save to temp file
                                        temp_file = tempfile.NamedTemporaryFile(delete=False, suffix='.png', dir=gltf_dir)
                                        material.image.save(temp_file.name)
                                        temp_file.close()
                                        texture_files_found.append(temp_file.name)
                                        debug(f" Extracted embedded texture from mesh {i}: {temp_file.name}")
                                        
                                        # Create material for this mesh
                                        mat_name = f"GLTF_Material_{i}"
                                        if mat_name not in self.materials:
                                            self.materials[mat_name] = {
                                                'diffuse': [0.8, 0.8, 0.8],
                                                'ambient': [0.2, 0.2, 0.2],
                                                'specular': [0.0, 0.0, 0.0],
                                                'shininess': 0.0,
                                                'texture': temp_file.name
                                            }
                                    elif hasattr(material.image, 'shape'):
                                        # Numpy array - convert to PIL and save
                                        img_array = material.image
                                        if len(img_array.shape) == 3:
                                            pil_img = Image.fromarray(img_array.astype(np.uint8))
                                            temp_file = tempfile.NamedTemporaryFile(delete=False, suffix='.png', dir=gltf_dir)
                                            pil_img.save(temp_file.name)
                                            temp_file.close()
                                            texture_files_found.append(temp_file.name)
                                            debug(f" Extracted embedded texture (numpy array) from mesh {i}: {temp_file.name}")
                                            
                                            mat_name = f"GLTF_Material_{i}"
                                            if mat_name not in self.materials:
                                                self.materials[mat_name] = {
                                                    'diffuse': [0.8, 0.8, 0.8],
                                                    'ambient': [0.2, 0.2, 0.2],
                                                    'specular': [0.0, 0.0, 0.0],
                                                    'shininess': 0.0,
                                                    'texture': temp_file.name
                                                }
                                except Exception as e:
                                    debug(f" Error extracting embedded texture from mesh {i}: {e}")
                                    import traceback
                                    traceback.print_exc()
                            
                            # Also check for baseColorTexture (trimesh PBR material)
                            if hasattr(material, 'baseColorTexture') and material.baseColorTexture:
                                try:
                                    if hasattr(material.baseColorTexture, 'image'):
                                        tex_img = material.baseColorTexture.image
                                        if hasattr(tex_img, 'save'):
                                            from PIL import Image
                                            import tempfile
                                            temp_file = tempfile.NamedTemporaryFile(delete=False, suffix='.png', dir=gltf_dir)
                                            tex_img.save(temp_file.name)
                                            temp_file.close()
                                            texture_files_found.append(temp_file.name)
                                            debug(f" Extracted baseColorTexture from mesh {i}: {temp_file.name}")
                                            
                                            mat_name = f"GLTF_Material_{i}"
                                            if mat_name not in self.materials:
                                                self.materials[mat_name] = {
                                                    'diffuse': [0.8, 0.8, 0.8],
                                                    'ambient': [0.2, 0.2, 0.2],
                                                    'specular': [0.0, 0.0, 0.0],
                                                    'shininess': 0.0,
                                                    'texture': temp_file.name
                                                }
                                except Exception as e:
                                    debug(f" Error extracting baseColorTexture from mesh {i}: {e}")
            elif isinstance(scene_or_mesh, trimesh.Scene):
                for geometry_name, geometry in scene_or_mesh.geometry.items():
                    debug(f" Processing geometry: {geometry_name}")
                    
                    # Check if geometry has visual material
                    if hasattr(geometry, 'visual') and geometry.visual:
                        visual = geometry.visual
                        
                        # Check for material
                        if hasattr(visual, 'material') and visual.material:
                            material = visual.material
                            debug(f" Found material for {geometry_name}")
                            
                            # Check for embedded texture image (trimesh stores this in material.image)
                            if hasattr(material, 'image') and material.image is not None:
                                # material.image is a PIL Image or numpy array (embedded texture)
                                try:
                                    from PIL import Image
                                    import tempfile
                                    
                                    # Save embedded PIL Image to temp file
                                    if hasattr(material.image, 'save'):
                                        temp_file = tempfile.NamedTemporaryFile(delete=False, suffix='.png', dir=gltf_dir)
                                        material.image.save(temp_file.name)
                                        temp_file.close()
                                        texture_files_found.append(temp_file.name)
                                        debug(f" Extracted embedded texture from {geometry_name}: {temp_file.name}")
                                        
                                        # Update material with texture path
                                        if geometry_name not in self.materials:
                                            self.materials[geometry_name] = {
                                                'diffuse': [0.8, 0.8, 0.8],
                                                'ambient': [0.2, 0.2, 0.2],
                                                'specular': [0.0, 0.0, 0.0],
                                                'shininess': 0.0,
                                                'texture': temp_file.name
                                            }
                                        else:
                                            self.materials[geometry_name]['texture'] = temp_file.name
                                    elif hasattr(material.image, 'shape'):
                                        # Numpy array - convert to PIL and save
                                        img_array = material.image
                                        if len(img_array.shape) == 3:
                                            pil_img = Image.fromarray(img_array.astype(np.uint8))
                                            temp_file = tempfile.NamedTemporaryFile(delete=False, suffix='.png', dir=gltf_dir)
                                            pil_img.save(temp_file.name)
                                            temp_file.close()
                                            texture_files_found.append(temp_file.name)
                                            debug(f" Extracted embedded texture (numpy) from {geometry_name}: {temp_file.name}")
                                            
                                            if geometry_name not in self.materials:
                                                self.materials[geometry_name] = {
                                                    'diffuse': [0.8, 0.8, 0.8],
                                                    'ambient': [0.2, 0.2, 0.2],
                                                    'specular': [0.0, 0.0, 0.0],
                                                    'shininess': 0.0,
                                                    'texture': temp_file.name
                                                }
                                            else:
                                                self.materials[geometry_name]['texture'] = temp_file.name
                                    
                                    # Also check for external texture references
                                    if hasattr(material, 'main') and hasattr(material.main, 'image'):
                                        # GLTF texture reference
                                        img_ref = material.main.image
                                        if isinstance(img_ref, str):
                                            # External texture path
                                            if not os.path.isabs(img_ref):
                                                full_path = os.path.join(gltf_dir, img_ref)
                                            else:
                                                full_path = img_ref
                                            if os.path.exists(full_path) and full_path not in texture_files_found:
                                                texture_files_found.append(full_path)
                                                debug(f" Found external texture: {full_path}")
                                except Exception as e:
                                    debug(f" Error accessing material image: {e}")
                                    import traceback
                                    traceback.print_exc()
                            
                            # Check for baseColorTexture or other texture properties
                            if hasattr(material, 'baseColorTexture') and material.baseColorTexture:
                                # This might be an embedded texture (PIL Image) or external path
                                try:
                                    # Try as embedded image first
                                    if hasattr(material.baseColorTexture, 'image'):
                                        tex_img = material.baseColorTexture.image
                                        if hasattr(tex_img, 'save'):
                                            from PIL import Image
                                            import tempfile
                                            temp_file = tempfile.NamedTemporaryFile(delete=False, suffix='.png', dir=gltf_dir)
                                            tex_img.save(temp_file.name)
                                            temp_file.close()
                                            texture_files_found.append(temp_file.name)
                                            debug(f" Extracted baseColorTexture (embedded) from {geometry_name}: {temp_file.name}")
                                            
                                            if geometry_name not in self.materials:
                                                self.materials[geometry_name] = {
                                                    'diffuse': [0.8, 0.8, 0.8],
                                                    'ambient': [0.2, 0.2, 0.2],
                                                    'specular': [0.0, 0.0, 0.0],
                                                    'shininess': 0.0,
                                                    'texture': temp_file.name
                                                }
                                            else:
                                                self.materials[geometry_name]['texture'] = temp_file.name
                                    # Try as external path
                                    elif hasattr(material.baseColorTexture, 'path'):
                                        tex_path = material.baseColorTexture.path
                                        if not os.path.isabs(tex_path):
                                            full_path = os.path.join(gltf_dir, tex_path)
                                        else:
                                            full_path = tex_path
                                        if os.path.exists(full_path) and full_path not in texture_files_found:
                                            texture_files_found.append(full_path)
                                            debug(f" Found baseColorTexture (external): {full_path}")
                                except Exception as e:
                                    debug(f" Error extracting baseColorTexture: {e}")
            
            # If we found textures, load them
            if texture_files_found:
                debug(f" Found {len(texture_files_found)} texture file(s) in GLTF/GLB")
                
                # Create default material if none exist and we have textures
                if not self.materials and texture_files_found:
                    default_mat = "GLTF_Material"
                    self.materials[default_mat] = {
                        'diffuse': [0.8, 0.8, 0.8],
                        'ambient': [0.2, 0.2, 0.2],
                        'specular': [0.0, 0.0, 0.0],
                        'shininess': 0.0,
                        'texture': texture_files_found[0]
                    }
                
                # Load the textures
                self.load_textures_from_files(texture_files_found)
            else:
                debug(f" No texture files found in GLTF/GLB (may have embedded textures that weren't extracted)")
                
                # Create default material if none exist
                if not self.materials:
                    default_mat = "GLTF_Material_Default"
                    self.materials[default_mat] = {
                        'diffuse': [0.8, 0.8, 0.8],
                        'ambient': [0.2, 0.2, 0.2],
                        'specular': [0.0, 0.0, 0.0],
                        'shininess': 0.0,
                        'texture': None
                    }
            
            # Store GLTF directory for texture loading
            self.model_dir = gltf_dir
            
        except Exception as e:
            debug(f" Error extracting textures from GLTF/GLB: {e}")
            import traceback
            traceback.print_exc()
    
    def _extract_dae_textures(self, dae_path: str, resolver: MaterialResolver = None):
        """Extract texture paths and materials from DAE file using collada library.
        
        DAE files have materials and textures embedded in the XML, which trimesh doesn't extract.
        We need to parse the DAE file directly using collada to get texture information.
        
        Args:
            dae_path: Path to DAE file
            resolver: MaterialResolver instance for unified material handling
        """
        if resolver is None:
            dae_dir = os.path.dirname(os.path.abspath(dae_path))
            resolver = MaterialResolver(model_directory=dae_dir)
        try:
            import collada  # type: ignore
        except ImportError:
            debug(f" Cannot extract DAE textures - collada module not available")
            return
        
        try:
            # Load DAE file using collada
            collada_scene = collada.Collada(dae_path)
            dae_dir = os.path.dirname(os.path.abspath(dae_path))
            
            debug(f" Extracting textures from DAE file: {dae_path}")
            debug(f" DAE directory: {dae_dir}")
            
            # Statistics tracking
            textures_referenced = set()  # All texture paths referenced in DAE
            textures_imported = []  # Textures successfully found and loaded
            textures_failed = []  # Textures referenced but not found
            
            # Step 1: Extract all image references from <library_images>
            image_id_to_path = {}
            if hasattr(collada_scene, 'images'):
                # collada_scene.images is an IndexedList, not a dict
                # Iterate over it directly
                for image in collada_scene.images:
                    image_id = image.id if hasattr(image, 'id') else None
                    if not image_id:
                        continue
                    image_path = None
                    
                    # Try different ways collada stores image paths
                    if hasattr(image, 'path'):
                        image_path = image.path
                    elif hasattr(image, 'init_from'):
                        if isinstance(image.init_from, str):
                            image_path = image.init_from
                        elif hasattr(image.init_from, 'value'):
                            image_path = image.init_from.value
                        elif hasattr(image.init_from, 'text'):
                            image_path = image.init_from.text
                    
                    if image_path:
                        # Resolve relative paths
                        if not os.path.isabs(image_path):
                            # Try multiple path resolution strategies
                            candidates = [
                                os.path.join(dae_dir, image_path),
                                os.path.join(dae_dir, os.path.basename(image_path)),
                            ]
                            # Also try with different separators
                            if '\\' in image_path:
                                candidates.append(os.path.join(dae_dir, image_path.replace('\\', '/')))
                            elif '/' in image_path:
                                candidates.append(os.path.join(dae_dir, image_path.replace('/', '\\')))
                        else:
                            candidates = [image_path]
                        
                        found = False
                        for candidate in candidates:
                            candidate = os.path.normpath(candidate)
                            if os.path.exists(candidate):
                                image_id_to_path[image_id] = candidate
                                textures_referenced.add(candidate)
                                debug(f" Found image '{image_id}': {candidate}")
                                found = True
                                break
                        
                        if not found:
                            textures_referenced.add(image_path)  # Still count as referenced
                            textures_failed.append(image_path)
                            debug(f" Image '{image_id}' path not found: {image_path}")
            
            # Step 2: Extract texture references from effects
            effect_textures = {}  # effect_id -> list of texture paths
            # collada_scene.effects is also an IndexedList
            for effect in collada_scene.effects:
                effect_id = effect.id if hasattr(effect, 'id') else None
                if not effect_id:
                    continue
                effect_textures[effect_id] = []
                
                # Check profile_COMMON (most common effect profile)
                if hasattr(effect, 'profile_COMMON'):
                    profile = effect.profile_COMMON
                    
                    # Check various texture maps: diffuse, ambient, specular, bump, etc.
                    texture_types = ['diffuse', 'ambient', 'specular', 'emission', 'bump', 'normal']
                    for tex_type in texture_types:
                        if hasattr(profile, tex_type):
                            tex_attr = getattr(profile, tex_type)
                            
                            # Check for texture element
                            if hasattr(tex_attr, 'texture'):
                                tex_ref = tex_attr.texture
                                
                                # Get sampler and surface references
                                sampler_ref = None
                                if hasattr(tex_ref, 'sampler'):
                                    sampler_ref = tex_ref.sampler
                                elif hasattr(tex_ref, 'texcoord'):
                                    # Sometimes sampler is embedded in texture element
                                    pass
                                
                                # Find the surface from the sampler
                                if sampler_ref and hasattr(profile, 'newparam'):
                                    for param in profile.newparam:
                                        param_sid = getattr(param, 'sid', None) or getattr(param, 'id', None)
                                        if param_sid == sampler_ref:
                                            # Get surface reference
                                            surface_ref = None
                                            if hasattr(param, 'surface'):
                                                surface_ref = param.surface
                                            elif hasattr(param, 'sampler2D') and hasattr(param.sampler2D, 'source'):
                                                surface_ref = param.sampler2D.source
                                            
                                            # Find the image from the surface
                                            if surface_ref:
                                                for surf_param in profile.newparam:
                                                    surf_sid = getattr(surf_param, 'sid', None) or getattr(surf_param, 'id', None)
                                                    if surf_sid == surface_ref:
                                                        # Get image reference
                                                        image_ref = None
                                                        if hasattr(surf_param, 'init_from'):
                                                            if isinstance(surf_param.init_from, str):
                                                                image_ref = surf_param.init_from
                                                            elif hasattr(surf_param.init_from, 'value'):
                                                                image_ref = surf_param.init_from.value
                                                            elif hasattr(surf_param.init_from, 'text'):
                                                                image_ref = surf_param.init_from.text
                                                        
                                                        if image_ref and image_ref in image_id_to_path:
                                                            tex_path = image_id_to_path[image_ref]
                                                            if tex_path not in effect_textures[effect_id]:
                                                                effect_textures[effect_id].append(tex_path)
                                                                textures_referenced.add(tex_path)
                                                                debug(f" Found {tex_type} texture in effect '{effect_id}': {tex_path}")
            
            # Step 3: Map materials to textures via effects
            material_to_textures = {}
            # collada_scene.materials is also an IndexedList
            for material in collada_scene.materials:
                material_id = material.id if hasattr(material, 'id') else None
                if not material_id:
                    continue
                material_to_textures[material_id] = []
                
                # Get the effect referenced by this material
                effect_id = None
                if hasattr(material, 'effect'):
                    if hasattr(material.effect, 'idref'):
                        effect_id = material.effect.idref
                    elif isinstance(material.effect, str):
                        effect_id = material.effect
                
                if effect_id and effect_id in effect_textures:
                    material_to_textures[material_id] = effect_textures[effect_id]
            
            # Also check materials (which reference effects) - already done above, but keep for logging
            material_names = {}
            for material in collada_scene.materials:
                material_id = material.id if hasattr(material, 'id') else None
                if material_id:
                    material_names[material_id] = material.name if hasattr(material, 'name') and material.name else material_id
                    debug(f" Found material: {material_id} ({material.name if hasattr(material, 'name') and material.name else 'unnamed'})")
            
            # Check for "baked" textures - these might be stored as vertex colors or material colors
            # "Baked" DAE files often have pre-computed lighting/textures stored in vertex colors
            has_baked_colors = False
            try:
                # Check if the mesh has vertex colors (trimesh might extract these)
                if hasattr(self, 'vertices') and self.vertices is not None:
                    # Try to get vertex colors from trimesh mesh (if it was loaded separately)
                    # This will be checked after mesh loading
                    debug(f" Checking for baked vertex colors after mesh load")
                    has_baked_colors = True  # Flag to check later
            except:
                pass
            
            # Step 4: Convert to unified materials and assign textures
            unified_materials = []
            for material_id, material in collada_scene.materials.items():
                effect_id = material.effect.idref if hasattr(material.effect, 'idref') else None
                effect = collada_scene.effects.get(effect_id) if effect_id else None
                
                unified_mat = resolver.resolve_material_from_dae(material, effect)
                
                # Assign textures found for this material
                if material_id in material_to_textures and material_to_textures[material_id]:
                    # Use first texture found (typically diffuse)
                    unified_mat.diffuse_map = material_to_textures[material_id][0]
                    if os.path.exists(unified_mat.diffuse_map):
                        if unified_mat.diffuse_map not in textures_imported:
                            textures_imported.append(unified_mat.diffuse_map)
                    debug(f" Assigned texture to material '{unified_mat.name}': {unified_mat.diffuse_map}")
                
                unified_materials.append(unified_mat)
            
            # Auto-assign any remaining textures from directory scanning
            resolver.auto_assign_textures(unified_materials)
            
            # Collect any newly assigned textures
            for unified_mat in unified_materials:
                if unified_mat.diffuse_map and unified_mat.diffuse_map not in textures_imported:
                    # Check if file exists
                    if os.path.exists(unified_mat.diffuse_map):
                        textures_imported.append(unified_mat.diffuse_map)
                    else:
                        if unified_mat.diffuse_map not in textures_failed:
                            textures_failed.append(unified_mat.diffuse_map)
            
            # Convert unified materials back to dict format
            self.materials = {}
            for unified_mat in unified_materials:
                self.materials[unified_mat.name] = unified_mat.to_dict()
                if unified_mat.diffuse_map:
                    self.materials[unified_mat.name]['texture'] = unified_mat.diffuse_map
            
            # Print statistics
            debug(f" DAE Texture Statistics:")
            print(f"  {len(textures_referenced)} textures referenced in DAE")
            print(f"  {len(textures_imported)} textures imported")
            print(f"  {len(textures_failed)} textures failed (not found)")
            
            if textures_failed:
                debug(f" Failed texture paths:")
                for failed_path in textures_failed[:10]:  # Show first 10
                    print(f"    - {failed_path}")
            
            # Load the textures
            if textures_imported:
                debug(f" Loading {len(textures_imported)} texture file(s)...")
                self.load_textures_from_files(textures_imported)
                
                # Ensure materials are assigned to faces
                num_faces = len(self.indices) // 3 if self.indices is not None else 0
                if num_faces > 0 and self.materials:
                    if len(self.face_materials) == 0 or len(self.face_materials) != num_faces:
                        default_mat = list(self.materials.keys())[0]
                        self.face_materials = [default_mat] * num_faces
                        debug(f" Assigned material '{default_mat}' to {num_faces} faces")
            else:
                debug(f" No texture files found/imported from DAE file")
                # Create default material if none exist
                if not self.materials:
                    default_mat = "DAE_Material_Default"
                    self.materials[default_mat] = {
                        'diffuse': [0.8, 0.8, 0.8],
                        'ambient': [0.2, 0.2, 0.2],
                        'specular': [0.0, 0.0, 0.0],
                        'shininess': 0.0,
                        'texture': None
                    }
                    debug(f" Created default untextured material '{default_mat}'")
            
            # Store DAE directory for texture loading
            self.model_dir = dae_dir
            
        except Exception as e:
            debug(f" Error extracting textures from DAE: {e}")
            import traceback
            traceback.print_exc()
    
    def load_g3d(self, path: str):
        """Load G3D (LibGDX) model file.
        
        G3D is a binary format used by LibGDX game framework.
        Supports meshes, animations, bones, and textures.
        
        Args:
            path: Path to the G3D file
        """
        # Clean up previous textures
        self._cleanup_textures()
        
        if not os.path.exists(path):
            raise RuntimeError(f"G3D file not found: {path}")
        
        try:
            with open(path, 'rb') as f:
                # G3D file structure:
                # Header: 4 bytes (version/magic)
                # Chunks: Each chunk has type (4 bytes), size (4 bytes), data
                
                # Read header
                magic = f.read(4)
                if len(magic) < 4:
                    raise RuntimeError("Invalid G3D file: file too short")
                
                # Check if it's a valid G3D file (magic can vary, but typically starts with version)
                # LibGDX G3D files usually have version 1 or 2
                version = int.from_bytes(magic, byteorder='little', signed=False)
                if version > 10:  # Sanity check - version should be small
                    # Might be big-endian or different format
                    version = int.from_bytes(magic, byteorder='big', signed=False)
                
                debug(f" Loading G3D file version: {version}")
                
                # Initialize data structures
                vertices_list = []
                indices_list = []
                normals_list = []
                tex_coords_list = []
                bone_indices_list = []
                bone_weights_list = []
                self.animations = {}
                textures_paths = []
                self.materials = {}
                self.face_materials = []
                
                # Parse chunks
                chunk_count = 0
                while True:
                    # Read chunk header
                    chunk_type_bytes = f.read(4)
                    if len(chunk_type_bytes) < 4:
                        break
                    
                    chunk_size_bytes = f.read(4)
                    if len(chunk_size_bytes) < 4:
                        break
                    
                    chunk_type = int.from_bytes(chunk_type_bytes, byteorder='little', signed=False)
                    chunk_size = int.from_bytes(chunk_size_bytes, byteorder='little', signed=False)
                    
                    chunk_data = f.read(chunk_size)
                    if len(chunk_data) < chunk_size:
                        break
                    
                    chunk_count += 1
                    
                    # Parse chunk based on type
                    # G3D chunk types (simplified - LibGDX uses specific IDs):
                    # 1 = MESH, 2 = ANIMATION, 3 = TEXTURE, 4 = MATERIAL, 5 = SKELETON
                    
                    if chunk_type == 1:  # MESH chunk
                        vertices, indices, normals, tex_coords, bone_indices, bone_weights = self._parse_g3d_mesh_chunk(chunk_data)
                        vertices_list.extend(vertices)
                        indices_list.extend(indices)
                        normals_list.extend(normals)
                        tex_coords_list.extend(tex_coords)
                        if bone_indices:
                            bone_indices_list.extend(bone_indices)
                        if bone_weights:
                            bone_weights_list.extend(bone_weights)
                    
                    elif chunk_type == 2:  # ANIMATION chunk
                        animations = self._parse_g3d_animation_chunk(chunk_data)
                        self.animations.update(animations)
                    
                    elif chunk_type == 3:  # TEXTURE chunk
                        texture_paths = self._parse_g3d_texture_chunk(chunk_data, path)
                        textures_paths.extend(texture_paths)
                    
                    elif chunk_type == 4:  # MATERIAL chunk
                        materials = self._parse_g3d_material_chunk(chunk_data)
                        self.materials.update(materials)
                    
                    elif chunk_type == 5:  # SKELETON chunk
                        skeleton_data = self._parse_g3d_skeleton_chunk(chunk_data)
                        # Store skeleton for bone-based animations
                        if not hasattr(self, 'skeleton'):
                            self.skeleton = skeleton_data
                    
                    # Unknown chunk type - skip
                
                debug(f" Parsed {chunk_count} chunks from G3D file")
                
                # Convert lists to numpy arrays
                if vertices_list:
                    self.vertices = np.array(vertices_list, dtype=np.float32)
                else:
                    raise RuntimeError("G3D file contains no vertex data")
                
                if indices_list:
                    # Adjust indices if we're concatenating multiple meshes
                    offset = 0
                    adjusted_indices = []
                    for idx in indices_list:
                        adjusted_indices.append(idx + offset)
                    self.indices = np.array(adjusted_indices, dtype=np.uint32)
                else:
                    # Generate indices if missing
                    self.indices = np.arange(len(self.vertices), dtype=np.uint32)
                
                if normals_list:
                    self.normals = np.array(normals_list, dtype=np.float32)
                else:
                    self.normals = self._calculate_normals()
                
                if tex_coords_list:
                    self.tex_coords = np.array(tex_coords_list, dtype=np.float32)
                
                # Load textures
                if textures_paths:
                    debug(f" Loading {len(textures_paths)} texture(s) from G3D")
                    self.load_textures_from_files(textures_paths)
                
                # Create default material if none exist
                if not self.materials:
                    default_mat = "G3D_Material_Default"
                    self.materials[default_mat] = {
                        'diffuse': [0.8, 0.8, 0.8],
                        'ambient': [0.2, 0.2, 0.2],
                        'specular': [0.0, 0.0, 0.0],
                        'shininess': 0.0,
                        'texture': None
                    }
                    # Assign to all faces
                    num_faces = len(self.indices) // 3 if self.indices is not None else 0
                    self.face_materials = [default_mat] * num_faces
                
                # Update animation combo
                if hasattr(self, '_update_animation_combo'):
                    self._update_animation_combo()
                
                debug(f" G3D loaded: {len(self.vertices)} vertices, {len(self.indices)//3} triangles")
                if self.animations:
                    debug(f" G3D animations found: {list(self.animations.keys())}")
        
        except Exception as e:
            error_msg = str(e)
            debug(f" Error loading G3D file: {error_msg}")
            import traceback
            traceback.print_exc()
            raise RuntimeError(f"Failed to load G3D file: {error_msg}") from e
    
    def _parse_g3d_mesh_chunk(self, chunk_data: bytes):
        """Parse a G3D mesh chunk.
        
        Returns:
            tuple: (vertices, indices, normals, tex_coords, bone_indices, bone_weights)
        """
        import struct
        
        vertices = []
        indices = []
        normals = []
        tex_coords = []
        bone_indices = []
        bone_weights = []
        
        offset = 0
        
        try:
            # Read mesh header (simplified - actual format may vary)
            if len(chunk_data) < 16:
                return vertices, indices, normals, tex_coords, bone_indices, bone_weights
            
            # Assume format: num_vertices (4), num_indices (4), has_normals (1), has_texcoords (1), has_bones (1), padding
            num_vertices = struct.unpack_from('<I', chunk_data, offset)[0]
            offset += 4
            num_indices = struct.unpack_from('<I', chunk_data, offset)[0]
            offset += 4
            has_normals = struct.unpack_from('B', chunk_data, offset)[0] if offset < len(chunk_data) else 0
            offset += 1
            has_texcoords = struct.unpack_from('B', chunk_data, offset)[0] if offset < len(chunk_data) else 0
            offset += 1
            has_bones = struct.unpack_from('B', chunk_data, offset)[0] if offset < len(chunk_data) else 0
            offset += 1
            offset += 3  # Padding to align
            
            # Read vertices (x, y, z)
            for i in range(num_vertices):
                if offset + 12 <= len(chunk_data):
                    x, y, z = struct.unpack_from('<fff', chunk_data, offset)
                    vertices.append([x, y, z])
                    offset += 12
                else:
                    break
            
            # Read normals (if present)
            if has_normals:
                for i in range(num_vertices):
                    if offset + 12 <= len(chunk_data):
                        nx, ny, nz = struct.unpack_from('<fff', chunk_data, offset)
                        normals.append([nx, ny, nz])
                        offset += 12
                    else:
                        break
            
            # Read texture coordinates (if present)
            if has_texcoords:
                for i in range(num_vertices):
                    if offset + 8 <= len(chunk_data):
                        u, v = struct.unpack_from('<ff', chunk_data, offset)
                        tex_coords.append([u, v])
                        offset += 8
                    else:
                        break
            
            # Read bone indices and weights (if present)
            if has_bones:
                for i in range(num_vertices):
                    if offset + 16 <= len(chunk_data):
                        # 4 bone indices (unsigned shorts)
                        bi0, bi1, bi2, bi3 = struct.unpack_from('<HHHH', chunk_data, offset)
                        bone_indices.append([bi0, bi1, bi2, bi3])
                        offset += 8
                        # 4 bone weights (floats)
                        bw0, bw1, bw2, bw3 = struct.unpack_from('<ffff', chunk_data, offset)
                        bone_weights.append([bw0, bw1, bw2, bw3])
                        offset += 8
                    else:
                        break
            
            # Read indices (triangles)
            for i in range(num_indices):
                if offset + 4 <= len(chunk_data):
                    idx = struct.unpack_from('<I', chunk_data, offset)[0]
                    indices.append(idx)
                    offset += 4
                else:
                    break
        
        except Exception as e:
            debug(f" Error parsing G3D mesh chunk: {e}")
            import traceback
            traceback.print_exc()
        
        return vertices, indices, normals, tex_coords, bone_indices, bone_weights
    
    def _parse_g3d_animation_chunk(self, chunk_data: bytes):
        """Parse a G3D animation chunk.
        
        Returns:
            dict: {animation_name: AnimationClip}
        """
        import struct
        
        animations = {}
        offset = 0
        
        try:
            # Read animation header
            if len(chunk_data) < 16:
                return animations
            
            # Format: num_animations (4), animation_name_length (4), name (variable), ...
            num_animations = struct.unpack_from('<I', chunk_data, offset)[0]
            offset += 4
            
            for anim_idx in range(num_animations):
                if offset + 8 > len(chunk_data):
                    break
                
                # Read animation name
                name_len = struct.unpack_from('<I', chunk_data, offset)[0]
                offset += 4
                
                if offset + name_len > len(chunk_data):
                    break
                
                anim_name = chunk_data[offset:offset+name_len].decode('utf-8', errors='ignore')
                offset += name_len
                
                # Read duration and frame rate
                if offset + 8 > len(chunk_data):
                    break
                
                duration = struct.unpack_from('<f', chunk_data, offset)[0]
                offset += 4
                frame_rate = struct.unpack_from('<f', chunk_data, offset)[0]
                offset += 4
                
                # Create AnimationClip
                clip = AnimationClip(name=anim_name, duration=duration, frame_rate=frame_rate)
                
                # Read number of nodes/bones
                if offset + 4 > len(chunk_data):
                    animations[anim_name] = clip
                    continue
                
                num_nodes = struct.unpack_from('<I', chunk_data, offset)[0]
                offset += 4
                
                # Read keyframes for each node
                for node_idx in range(num_nodes):
                    if offset + 4 > len(chunk_data):
                        break
                    
                    # Read node name
                    node_name_len = struct.unpack_from('<I', chunk_data, offset)[0]
                    offset += 4
                    
                    if offset + node_name_len > len(chunk_data):
                        break
                    
                    node_name = chunk_data[offset:offset+node_name_len].decode('utf-8', errors='ignore')
                    offset += node_name_len
                    
                    # Read number of keyframes
                    if offset + 4 > len(chunk_data):
                        break
                    
                    num_keyframes = struct.unpack_from('<I', chunk_data, offset)[0]
                    offset += 4
                    
                    # Read keyframes
                    for kf_idx in range(num_keyframes):
                        if offset + 40 > len(chunk_data):  # time(4) + pos(12) + rot(16) + scale(12) = 44, but check 40
                            break
                        
                        time = struct.unpack_from('<f', chunk_data, offset)[0]
                        offset += 4
                        
                        # Position (x, y, z)
                        px, py, pz = struct.unpack_from('<fff', chunk_data, offset)
                        offset += 12
                        
                        # Rotation (quaternion x, y, z, w)
                        qx, qy, qz, qw = struct.unpack_from('<ffff', chunk_data, offset)
                        offset += 16
                        
                        # Scale (x, y, z)
                        sx, sy, sz = struct.unpack_from('<fff', chunk_data, offset)
                        offset += 12
                        
                        clip.add_keyframe(node_name, time, position=(px, py, pz), rotation=(qx, qy, qz, qw), scale=(sx, sy, sz))
                
                animations[anim_name] = clip
                debug(f" Parsed G3D animation '{anim_name}': {clip.frame_count} frames, {duration:.2f}s")
        
        except Exception as e:
            debug(f" Error parsing G3D animation chunk: {e}")
            import traceback
            traceback.print_exc()
        
        return animations
    
    def _parse_g3d_texture_chunk(self, chunk_data: bytes, g3d_path: str):
        """Parse a G3D texture chunk.
        
        Args:
            chunk_data: Chunk binary data
            g3d_path: Path to the G3D file (for resolving relative texture paths)
            
        Returns:
            list: List of texture file paths
        """
        import struct
        
        texture_paths = []
        offset = 0
        g3d_dir = os.path.dirname(os.path.abspath(g3d_path))
        
        try:
            # Read number of textures
            if len(chunk_data) < 4:
                return texture_paths
            
            num_textures = struct.unpack_from('<I', chunk_data, offset)[0]
            offset += 4
            
            for tex_idx in range(num_textures):
                if offset + 4 > len(chunk_data):
                    break
                
                # Read texture path length
                path_len = struct.unpack_from('<I', chunk_data, offset)[0]
                offset += 4
                
                if offset + path_len > len(chunk_data):
                    break
                
                # Read texture path
                texture_path = chunk_data[offset:offset+path_len].decode('utf-8', errors='ignore')
                offset += path_len
                
                # Resolve relative paths
                if not os.path.isabs(texture_path):
                    # Try relative to G3D file
                    full_path = os.path.join(g3d_dir, texture_path)
                    if os.path.exists(full_path):
                        texture_paths.append(full_path)
                    else:
                        # Try just the filename
                        filename = os.path.basename(texture_path)
                        alt_path = os.path.join(g3d_dir, filename)
                        if os.path.exists(alt_path):
                            texture_paths.append(alt_path)
                        else:
                            texture_paths.append(texture_path)  # Add anyway, might be resolved later
                else:
                    if os.path.exists(texture_path):
                        texture_paths.append(texture_path)
            
            debug(f" Found {len(texture_paths)} texture reference(s) in G3D")
        
        except Exception as e:
            debug(f" Error parsing G3D texture chunk: {e}")
            import traceback
            traceback.print_exc()
        
        return texture_paths
    
    def _parse_g3d_material_chunk(self, chunk_data: bytes):
        """Parse a G3D material chunk.
        
        Returns:
            dict: {material_name: material_dict}
        """
        import struct
        
        materials = {}
        offset = 0
        
        try:
            # Read number of materials
            if len(chunk_data) < 4:
                return materials
            
            num_materials = struct.unpack_from('<I', chunk_data, offset)[0]
            offset += 4
            
            for mat_idx in range(num_materials):
                if offset + 4 > len(chunk_data):
                    break
                
                # Read material name
                name_len = struct.unpack_from('<I', chunk_data, offset)[0]
                offset += 4
                
                if offset + name_len > len(chunk_data):
                    break
                
                mat_name = chunk_data[offset:offset+name_len].decode('utf-8', errors='ignore')
                offset += name_len
                
                # Read material properties (diffuse, ambient, specular, shininess)
                if offset + 48 > len(chunk_data):
                    materials[mat_name] = {
                        'diffuse': [0.8, 0.8, 0.8],
                        'ambient': [0.2, 0.2, 0.2],
                        'specular': [0.0, 0.0, 0.0],
                        'shininess': 0.0,
                        'texture': None
                    }
                    continue
                
                # Diffuse (RGB)
                dr, dg, db = struct.unpack_from('<fff', chunk_data, offset)
                offset += 12
                
                # Ambient (RGB)
                ar, ag, ab = struct.unpack_from('<fff', chunk_data, offset)
                offset += 12
                
                # Specular (RGB)
                sr, sg, sb = struct.unpack_from('<fff', chunk_data, offset)
                offset += 12
                
                # Shininess
                shininess = struct.unpack_from('<f', chunk_data, offset)[0]
                offset += 4
                
                materials[mat_name] = {
                    'diffuse': [dr, dg, db],
                    'ambient': [ar, ag, ab],
                    'specular': [sr, sg, sb],
                    'shininess': shininess,
                    'texture': None  # Texture reference handled separately
                }
        
        except Exception as e:
            debug(f" Error parsing G3D material chunk: {e}")
            import traceback
            traceback.print_exc()
        
        return materials
    
    def _parse_g3d_skeleton_chunk(self, chunk_data: bytes):
        """Parse a G3D skeleton chunk.
        
        Returns:
            dict: Skeleton data (bones, hierarchy)
        """
        import struct
        
        skeleton = {
            'bones': [],
            'hierarchy': {}
        }
        offset = 0
        
        try:
            # Read number of bones
            if len(chunk_data) < 4:
                return skeleton
            
            num_bones = struct.unpack_from('<I', chunk_data, offset)[0]
            offset += 4
            
            for bone_idx in range(num_bones):
                if offset + 4 > len(chunk_data):
                    break
                
                # Read bone name
                name_len = struct.unpack_from('<I', chunk_data, offset)[0]
                offset += 4
                
                if offset + name_len > len(chunk_data):
                    break
                
                bone_name = chunk_data[offset:offset+name_len].decode('utf-8', errors='ignore')
                offset += name_len
                
                # Read parent index
                if offset + 4 > len(chunk_data):
                    break
                
                parent_idx = struct.unpack_from('<i', chunk_data, offset)[0]  # Signed int
                offset += 4
                
                # Read bone transform (position, rotation, scale)
                if offset + 64 > len(chunk_data):
                    skeleton['bones'].append({
                        'name': bone_name,
                        'parent': parent_idx,
                        'transform': None
                    })
                    continue
                
                # Position (x, y, z)
                px, py, pz = struct.unpack_from('<fff', chunk_data, offset)
                offset += 12
                
                # Rotation (quaternion x, y, z, w)
                qx, qy, qz, qw = struct.unpack_from('<ffff', chunk_data, offset)
                offset += 16
                
                # Scale (x, y, z)
                sx, sy, sz = struct.unpack_from('<fff', chunk_data, offset)
                offset += 12
                
                skeleton['bones'].append({
                    'name': bone_name,
                    'parent': parent_idx,
                    'transform': {
                        'position': (px, py, pz),
                        'rotation': (qx, qy, qz, qw),
                        'scale': (sx, sy, sz)
                    }
                })
            
            debug(f" Parsed G3D skeleton with {len(skeleton['bones'])} bone(s)")
        
        except Exception as e:
            debug(f" Error parsing G3D skeleton chunk: {e}")
            import traceback
            traceback.print_exc()
        
        return skeleton
    
    def load_json_model(self, path: str):
        """Load a PyGenesis JSON Model file (.Model format).
        
        Args:
            path: Path to the .Model file
        """
        # Clean up previous textures
        self._cleanup_textures()
        
        if not os.path.exists(path):
            raise RuntimeError(f"Model file not found: {path}")
        
        try:
            import json
            
            with open(path, 'r', encoding='utf-8') as f:
                model_data = json.load(f)
            
            # Check version
            version = model_data.get("version", "1.0")
            if version != "1.0":
                print(f"WARNING: Model file version {version} may not be fully compatible")
            
            # Load metadata
            metadata = model_data.get("metadata", {})
            debug(f" Loading PyGenesis Model: {metadata.get('name', 'Unknown')}")
            debug(f" Original format: {metadata.get('original_format', 'unknown')}")
            
            # Load geometry
            geometry = model_data.get("geometry", {})
            vertices = geometry.get("vertices", [])
            indices = geometry.get("indices", [])
            normals = geometry.get("normals", [])
            tex_coords = geometry.get("tex_coords", [])
            face_materials = geometry.get("face_materials", [])
            
            if not vertices:
                raise RuntimeError("Model file contains no vertex data")
            
            # Convert to numpy arrays
            self.vertices = np.array(vertices, dtype=np.float32)
            self.indices = np.array(indices, dtype=np.uint32) if indices else np.arange(len(vertices), dtype=np.uint32)
            self.normals = np.array(normals, dtype=np.float32) if normals else self._calculate_normals()
            if tex_coords:
                self.tex_coords = np.array(tex_coords, dtype=np.float32)
            
            # Load materials
            materials = model_data.get("materials", {})
            self.materials = {}
            for mat_name, mat_data in materials.items():
                self.materials[mat_name] = {
                    'diffuse': mat_data.get("diffuse", [0.8, 0.8, 0.8]),
                    'ambient': mat_data.get("ambient", [0.2, 0.2, 0.2]),
                    'specular': mat_data.get("specular", [0.0, 0.0, 0.0]),
                    'shininess': mat_data.get("shininess", 0.0),
                    'texture': mat_data.get("texture")
                }
            
            # Load textures
            textures = model_data.get("textures", {})
            if textures:
                model_dir = os.path.dirname(os.path.abspath(path))
                texture_paths = []
                for mat_name, tex_data in textures.items():
                    tex_path = tex_data.get("path", "")
                    if tex_path:
                        # Resolve relative path
                        if not os.path.isabs(tex_path):
                            full_path = os.path.join(model_dir, tex_path)
                        else:
                            full_path = tex_path
                        
                        if os.path.exists(full_path):
                            texture_paths.append(full_path)
                            # Update material texture reference
                            if mat_name in self.materials:
                                self.materials[mat_name]['texture'] = full_path
                
                if texture_paths:
                    debug(f" Loading {len(texture_paths)} texture(s) from JSON model")
                    self.load_textures_from_files(texture_paths)
            
            # Load enabled/disabled texture lists
            self.enabled_textures = model_data.get("enabled_textures", [])
            self.disabled_textures = model_data.get("disabled_textures", [])
            
            # If lists are empty, initialize all textures as enabled by default
            if not self.enabled_textures and not self.disabled_textures:
                # All textures enabled by default
                for mat_name, mat_data in self.materials.items():
                    texture_path = mat_data.get("texture")
                    if texture_path:
                        texture_name = os.path.basename(texture_path)
                        if texture_name not in self.enabled_textures:
                            self.enabled_textures.append(texture_name)
            
            # Load face materials
            if face_materials:
                self.face_materials = face_materials
            else:
                # Assign default material to all faces
                if self.materials:
                    default_mat = list(self.materials.keys())[0]
                    num_faces = len(self.indices) // 3 if self.indices is not None else 0
                    self.face_materials = [default_mat] * num_faces
            
            # Load animations
            animations_data = model_data.get("animations", {})
            self.animations = {}
            for anim_name, anim_data in animations_data.items():
                duration = float(anim_data.get("duration", 1.0))
                frame_rate = float(anim_data.get("frame_rate", 30.0))
                
                clip = AnimationClip(name=anim_name, duration=duration, frame_rate=frame_rate)
                
                # Load keyframes
                keyframes = anim_data.get("keyframes", {})
                for node_name, node_keyframes in keyframes.items():
                    positions = node_keyframes.get("position", [])
                    rotations = node_keyframes.get("rotation", [])
                    scales = node_keyframes.get("scale", [])
                    
                    # Add keyframes to clip
                    for kf in positions:
                        if len(kf) >= 4:  # [time, x, y, z]
                            clip.add_keyframe(node_name, float(kf[0]), position=(kf[1], kf[2], kf[3]))
                    
                    for kf in rotations:
                        if len(kf) >= 5:  # [time, qx, qy, qz, qw]
                            clip.add_keyframe(node_name, float(kf[0]), rotation=(kf[1], kf[2], kf[3], kf[4]))
                    
                    for kf in scales:
                        if len(kf) >= 4:  # [time, x, y, z]
                            clip.add_keyframe(node_name, float(kf[0]), scale=(kf[1], kf[2], kf[3]))
                
                self.animations[anim_name] = clip
                debug(f" Loaded animation '{anim_name}': {clip.frame_count} frames, {duration:.2f}s")
            
            # Load skeleton if available
            skeleton = model_data.get("skeleton")
            if skeleton:
                self.skeleton = skeleton
            
            # Apply scale if specified
            scale = metadata.get("scale", 1.0)
            if scale != 1.0:
                self.vertices = self.vertices * float(scale)
                self._resource_scale = float(scale)
            
            # Store model directory
            self.model_dir = os.path.dirname(os.path.abspath(path))
            
            debug(f" JSON Model loaded: {len(self.vertices)} vertices, {len(self.indices)//3} triangles")
            if self.animations:
                debug(f" Loaded {len(self.animations)} animation(s)")
        
        except Exception as e:
            error_msg = str(e)
            debug(f" Error loading JSON model: {error_msg}")
            import traceback
            traceback.print_exc()
            raise RuntimeError(f"Failed to load JSON Model file: {error_msg}") from e
    
    def _extract_dae_animations(self, dae_path: str):
        """Extract animations from a DAE (Collada) file using the collada library.
        
        This function parses the DAE XML to find:
        - <animation> elements (embedded animations)
        - References to external animation files
        - Animation clips and their keyframes
        
        Args:
            dae_path: Path to the DAE file
        """
        if not os.path.exists(dae_path):
            return
        
        try:
            import collada  # type: ignore
        except ImportError:
            debug(f" Cannot extract DAE animations - collada library not available")
            return
        
        try:
            collada_scene = collada.Collada(dae_path)
            
            # Check for animations in the DAE file
            animations_found = []
            external_animation_refs = []
            
            # Method 1: Check collada_scene.animations (if available)
            if hasattr(collada_scene, 'animations'):
                # animations is typically an IndexedList
                for anim in collada_scene.animations:
                    try:
                        anim_id = anim.id if hasattr(anim, 'id') else None
                        if anim_id:
                            animations_found.append((anim_id, anim))
                            debug(f" Found animation in DAE: {anim_id}")
                    except Exception as e:
                        debug(f" Error processing animation: {e}")
            
            # Method 2: Check for <animation_clip> elements (animation library)
            if hasattr(collada_scene, 'scene') and hasattr(collada_scene.scene, 'animation_clips'):
                for clip_id, clip in collada_scene.scene.animation_clips.items():
                    debug(f" Found animation clip: {clip_id}")
                    # Create AnimationClip from this
                    clip_name = clip.name if hasattr(clip, 'name') and clip.name else clip_id
                    duration = 1.0  # Default, will be updated from keyframes
                    frame_rate = 30.0  # Default
                    
                    anim_clip = AnimationClip(name=clip_name, duration=duration, frame_rate=frame_rate)
                    
                    # Parse clip instance references
                    if hasattr(clip, 'children'):
                        for child in clip.children:
                            if hasattr(child, 'animation'):
                                anim_ref = child.animation
                                # Find the actual animation data
                                if anim_ref in collada_scene.animations:
                                    anim_data = collada_scene.animations[anim_ref]
                                    # Parse animation channels
                                    self._parse_collada_animation(anim_data, anim_clip)
                    
                    if anim_clip.get_node_names():  # Only add if has keyframes
                        self.animations[clip_name] = anim_clip
                        debug(f" Created animation clip '{clip_name}' from DAE")
            
            # Method 3: Parse <animation> elements directly from XML
            # This is more complex and requires XML parsing
            try:
                import xml.etree.ElementTree as ET
                tree = ET.parse(dae_path)
                root = tree.getroot()
                
                # Find all <animation> elements
                ns = {'collada': 'http://www.collada.org/2005/11/COLLADASchema'}
                animations = root.findall('.//collada:animation', ns)
                
                if animations:
                    debug(f" Found {len(animations)} <animation> elements in DAE XML")
                    for anim_elem in animations:
                        anim_id = anim_elem.get('id') or anim_elem.get('name', f"Animation_{len(self.animations)}")
                        
                        # Check for references to external files
                        # Some DAE files reference external animation files
                        source_elem = anim_elem.find('.//collada:source', ns)
                        if source_elem is not None:
                            # Check for URI references to external files
                            for uri_elem in source_elem.findall('.//collada:ref', ns):
                                uri = uri_elem.text
                                if uri and uri.startswith('file://') or uri.endswith(('.dae', '.xml', '.anim')):
                                    external_path = os.path.join(os.path.dirname(dae_path), os.path.basename(uri))
                                    if os.path.exists(external_path):
                                        external_animation_refs.append(external_path)
                                        debug(f" Found external animation reference: {external_path}")
                        else:
                            # Embedded animation - try to parse
                            # This is complex and would require parsing animation channels
                            # For now, we create a placeholder
                            if anim_id not in self.animations:
                                clip = AnimationClip(name=anim_id, duration=1.0, frame_rate=30.0)
                                # Try to extract basic timing info
                                time_elem = anim_elem.find('.//collada:float_array', ns)
                                if time_elem is not None and time_elem.text:
                                    try:
                                        times = [float(t) for t in time_elem.text.split()]
                                        if times:
                                            clip.duration = max(times)
                                    except:
                                        pass
                                self.animations[anim_id] = clip
                                debug(f" Created animation '{anim_id}' from DAE XML")
                
                # Check for <library_animation_clips> references to external files
                library_clips = root.find('.//collada:library_animation_clips', ns)
                if library_clips is not None:
                    for clip_elem in library_clips.findall('.//collada:animation_clip', ns):
                        instance_anim_elem = clip_elem.find('.//collada:instance_animation', ns)
                        if instance_anim_elem is not None:
                            url = instance_anim_elem.get('url')
                            if url and (url.startswith('../') or url.startswith('./')):
                                external_path = os.path.join(os.path.dirname(dae_path), url.lstrip('.././'))
                                if os.path.exists(external_path):
                                    external_animation_refs.append(external_path)
                                    debug(f" Found external animation clip reference: {external_path}")
            
            except Exception as e:
                debug(f" Error parsing DAE XML for animations: {e}")
                import traceback
                traceback.print_exc()
            
            # Store external animation references for later loading
            if external_animation_refs:
                if not hasattr(self, '_external_animation_refs'):
                    self._external_animation_refs = []
                self._external_animation_refs.extend(external_animation_refs)
                debug(f" Found {len(external_animation_refs)} external animation file references")
            
        except Exception as e:
            debug(f" Error extracting DAE animations: {e}")
            import traceback
            traceback.print_exc()
    
    def _parse_collada_animation(self, anim_data, anim_clip: AnimationClip):
        """Parse a Collada animation object and populate an AnimationClip.
        
        Args:
            anim_data: Collada animation object
            anim_clip: AnimationClip to populate
        """
        try:
            # This is a simplified parser - full implementation would parse
            # all animation channels, samplers, and accessors
            # For now, we create placeholder keyframes
            if hasattr(anim_data, 'children'):
                for child in anim_data.children:
                    if hasattr(child, 'id'):
                        node_name = child.id
                        # Add a default keyframe (full implementation would parse channels)
                        anim_clip.add_keyframe(node_name, 0.0, position=(0, 0, 0), rotation=(0, 0, 0, 1), scale=(1, 1, 1))
        except Exception as e:
            debug(f" Error parsing Collada animation: {e}")
    
    def _scan_for_external_animation_files(self, model_path: str):
        """Scan for external animation files referenced in the model file.
        
        Args:
            model_path: Path to the model file (DAE, GLTF, etc.)
            
        Returns:
            list: List of paths to external animation files found
        """
        external_files = []
        if not os.path.exists(model_path):
            return external_files
        
        model_dir = os.path.dirname(model_path)
        model_ext = os.path.splitext(model_path)[1].lower()
        
        try:
            # For DAE files, check XML for external references
            if model_ext == '.dae':
                import xml.etree.ElementTree as ET
                tree = ET.parse(model_path)
                root = tree.getroot()
                ns = {'collada': 'http://www.collada.org/2005/11/COLLADASchema'}
                
                # Check for <include> or <instance_animation> with external URLs
                for elem in root.iter():
                    tag = elem.tag.split('}')[-1] if '}' in elem.tag else elem.tag
                    
                    # Check for URL attributes pointing to external files
                    url = elem.get('url') or elem.get('source') or elem.get('href')
                    if url:
                        # Clean up the URL
                        url = url.lstrip('#').lstrip('../').lstrip('./')
                        if url.endswith(('.dae', '.xml', '.anim', '.gltf', '.glb')):
                            external_path = os.path.join(model_dir, url)
                            if os.path.exists(external_path):
                                external_files.append(external_path)
                                debug(f" Found external animation reference in DAE: {external_path}")
            
            # For GLTF files, check JSON for external references
            elif model_ext == '.gltf':
                import json
                with open(model_path, 'r', encoding='utf-8') as f:
                    gltf_data = json.load(f)
                
                # Check animations array for external references
                if 'animations' in gltf_data:
                    for anim in gltf_data['animations']:
                        # Check if channels reference external files
                        if 'channels' in anim:
                            for channel in anim['channels']:
                                if 'extensions' in channel:
                                    ext = channel['extensions']
                                    # Some extensions reference external files
                                    for ext_name, ext_data in ext.items():
                                        if isinstance(ext_data, dict) and 'uri' in ext_data:
                                            uri = ext_data['uri']
                                            external_path = os.path.join(model_dir, uri)
                                            if os.path.exists(external_path):
                                                external_files.append(external_path)
                                                debug(f" Found external animation reference in GLTF: {external_path}")
                
                # Check for external buffer references (might contain animation data)
                if 'buffers' in gltf_data:
                    for buffer in gltf_data['buffers']:
                        if 'uri' in buffer and not buffer['uri'].startswith('data:'):
                            uri = buffer['uri']
                            external_path = os.path.join(model_dir, uri)
                            if os.path.exists(external_path) and uri.endswith(('.bin', '.anim')):
                                external_files.append(external_path)
                                debug(f" Found external buffer reference in GLTF: {external_path}")
        
        except Exception as e:
            debug(f"Error scanning for external animation files: {e}")
            import traceback
            traceback.print_exc()
        
        return external_files
    
    def _extract_animations_from_scene(self, scene, path: str):
        """Extract animations from a trimesh Scene and create AnimationClip objects"""
        self.animations = {}
        
        # Scan for external animation files first
        external_files = self._scan_for_external_animation_files(path)
        if external_files:
            for ext_file in external_files:
                # Try to load animations from external file
                ext_ext = os.path.splitext(ext_file)[1].lower()
                if ext_ext == '.dae':
                    self._extract_dae_animations(ext_file)
                elif ext_ext in ['.gltf', '.glb']:
                    # Load GLTF animation from external file
                    try:
                        if ext_ext == '.gltf':
                            import json
                            with open(ext_file, 'r', encoding='utf-8') as f:
                                gltf_data = json.load(f)
                                self._parse_gltf_animations(gltf_data, ext_file)
                    except Exception as e:
                        debug(f"Could not load animations from external file {ext_file}: {e}")
        
        # Try to access GLTF/GLB animations if available
        try:
            # For GLTF/GLB files, try to parse animation data
            # Note: trimesh's GLTF support may be limited, so we try multiple approaches
            gltf_data = None
            
            # Approach 1: Check if scene has embedded GLTF data
            if hasattr(scene, 'metadata') and isinstance(scene.metadata, dict):
                gltf_data = scene.metadata.get('gltf')
            
            # Approach 2: Try to load GLTF file directly if it's a GLTF (not GLB)
            if not gltf_data and path.lower().endswith('.gltf'):
                try:
                    import json
                    with open(path, 'r', encoding='utf-8') as f:
                        gltf_data = json.load(f)
                except Exception:
                    pass
            
            # Approach 3: For GLB files, try to extract JSON chunk
            if not gltf_data and path.lower().endswith('.glb'):
                try:
                    import json
                    with open(path, 'rb') as f:
                        # GLB format: 12-byte header + JSON chunk + binary chunk
                        header = f.read(12)
                        if len(header) >= 12:
                            # Read JSON chunk length
                            json_length = int.from_bytes(header[8:12], byteorder='little')
                            json_data = f.read(json_length)
                            gltf_data = json.loads(json_data.decode('utf-8'))
                except Exception:
                    pass
            
            # Parse GLTF animations
            if gltf_data and isinstance(gltf_data, dict):
                self._parse_gltf_animations(gltf_data, path)
            
            # Fallback: Check trimesh scene attributes
            if not self.animations and hasattr(scene, 'scene') and hasattr(scene.scene, 'animations'):
                # GLTF animations (alternative path)
                for i, anim in enumerate(scene.scene.animations or []):
                    anim_name = getattr(anim, 'name', None) or f"Animation_{i+1}"
                    # Create basic AnimationClip (placeholder for now)
                    clip = AnimationClip(name=anim_name, duration=1.0, frame_rate=30.0)
                    self.animations[anim_name] = clip
                    
        except Exception as e:
            debug(f"Could not extract animations: {e}")
            import traceback
            traceback.print_exc()
        
        # If no animations found, set empty dict
        if not self.animations:
            self.animations = {}
    
    def _parse_gltf_animations(self, gltf_data: dict, gltf_path: str):
        """Parse GLTF animation data from JSON structure.
        
        Args:
            gltf_data: Parsed GLTF JSON data
            gltf_path: Path to the GLTF file (for resolving external references)
        """
        if not isinstance(gltf_data, dict):
            return
        
        animations_list = gltf_data.get('animations', [])
        if not animations_list:
            return
        
        gltf_dir = os.path.dirname(gltf_path)
        
        # Parse accessors for keyframe data
        accessors = gltf_data.get('accessors', [])
        buffer_views = gltf_data.get('bufferViews', [])
        buffers = gltf_data.get('buffers', [])
        
        for i, anim_data in enumerate(animations_list):
            anim_name = anim_data.get('name', f"Animation_{i+1}")
            channels = anim_data.get('channels', [])
            samplers = anim_data.get('samplers', [])
            
            # Create AnimationClip
            clip = AnimationClip(name=anim_name, duration=1.0, frame_rate=30.0)
            
            max_time = 0.0
            
            # Parse channels and samplers
            for channel in channels:
                sampler_idx = channel.get('sampler')
                target = channel.get('target', {})
                node_name = target.get('node', 'Root')
                path_type = target.get('path')  # "translation", "rotation", "scale"
                
                if sampler_idx is not None and sampler_idx < len(samplers):
                    sampler = samplers[sampler_idx]
                    input_accessor_idx = sampler.get('input')  # Time keyframes
                    output_accessor_idx = sampler.get('output')  # Value keyframes
                    
                    # Parse keyframe data from accessors
                    times = []
                    values = []
                    
                    # Get time keyframes
                    if input_accessor_idx is not None and input_accessor_idx < len(accessors):
                        input_accessor = accessors[input_accessor_idx]
                        times = self._parse_gltf_accessor(input_accessor, buffer_views, buffers, gltf_dir)
                    
                    # Get value keyframes
                    if output_accessor_idx is not None and output_accessor_idx < len(accessors):
                        output_accessor = accessors[output_accessor_idx]
                        values = self._parse_gltf_accessor(output_accessor, buffer_views, buffers, gltf_dir)
                    
                    # Add keyframes to clip
                    if times and values:
                        for t_idx, time in enumerate(times):
                            if time > max_time:
                                max_time = time
                            
                            if path_type == 'translation' and len(values) > t_idx * 3 + 2:
                                x, y, z = values[t_idx * 3], values[t_idx * 3 + 1], values[t_idx * 3 + 2]
                                clip.add_keyframe(node_name, float(time), position=(x, y, z))
                            elif path_type == 'rotation' and len(values) > t_idx * 4 + 3:
                                x, y, z, w = values[t_idx * 4], values[t_idx * 4 + 1], values[t_idx * 4 + 2], values[t_idx * 4 + 3]
                                clip.add_keyframe(node_name, float(time), rotation=(x, y, z, w))
                            elif path_type == 'scale' and len(values) > t_idx * 3 + 2:
                                x, y, z = values[t_idx * 3], values[t_idx * 3 + 1], values[t_idx * 3 + 2]
                                clip.add_keyframe(node_name, float(time), scale=(x, y, z))
            
            # Update duration
            if max_time > 0:
                clip.duration = float(max_time)
            
            if clip.get_node_names():  # Only add if has keyframes
                self.animations[anim_name] = clip
                debug(f"Extracted GLTF animation '{anim_name}' ({clip.frame_count} frames, {clip.duration:.2f}s)")
    
    def _parse_gltf_accessor(self, accessor: dict, buffer_views: list, buffers: list, gltf_dir: str) -> list:
        """Parse a GLTF accessor to extract float data.
        
        Args:
            accessor: Accessor object from GLTF JSON
            buffer_views: List of buffer view objects
            buffers: List of buffer objects
            gltf_dir: Directory containing the GLTF file (for external buffer resolution)
            
        Returns:
            list: List of float values
        """
        try:
            buffer_view_idx = accessor.get('bufferView')
            if buffer_view_idx is None or buffer_view_idx >= len(buffer_views):
                return []
            
            buffer_view = buffer_views[buffer_view_idx]
            buffer_idx = buffer_view.get('buffer')
            if buffer_idx is None or buffer_idx >= len(buffers):
                return []
            
            buffer_obj = buffers[buffer_idx]
            byte_offset = buffer_view.get('byteOffset', 0) + accessor.get('byteOffset', 0)
            count = accessor.get('count', 0)
            component_type = accessor.get('componentType', 5126)  # Default: FLOAT
            type_str = accessor.get('type', 'SCALAR')
            
            # Determine stride
            type_sizes = {'SCALAR': 1, 'VEC2': 2, 'VEC3': 3, 'VEC4': 4, 'MAT2': 4, 'MAT3': 9, 'MAT4': 16}
            num_components = type_sizes.get(type_str, 1)
            
            # Read buffer data
            if 'uri' in buffer_obj:
                uri = buffer_obj['uri']
                if uri.startswith('data:'):
                    # Base64 encoded data
                    import base64
                    header, data = uri.split(',', 1)
                    buffer_data = base64.b64decode(data)
                else:
                    # External file
                    buffer_path = os.path.join(gltf_dir, uri)
                    if os.path.exists(buffer_path):
                        with open(buffer_path, 'rb') as f:
                            buffer_data = f.read()
                    else:
                        return []
            else:
                # Embedded in GLB file (would need different handling)
                return []
            
            # Extract float values
            import struct
            values = []
            stride = num_components * 4  # Assuming float (4 bytes)
            
            for i in range(count):
                offset = byte_offset + i * stride
                if offset + stride <= len(buffer_data):
                    if component_type == 5126:  # FLOAT
                        for j in range(num_components):
                            val = struct.unpack_from('<f', buffer_data, offset + j * 4)[0]
                            values.append(val)
                    elif component_type == 5120:  # BYTE
                        val = struct.unpack_from('b', buffer_data, offset)[0]
                        values.append(float(val))
                    # Add more component types as needed
            
            return values
        
        except Exception as e:
            debug(f"Error parsing GLTF accessor: {e}")
            return []
    
    def _evaluate_animation_pose(self):
        """Evaluate the current animation pose and update transform matrices.
        
        This method evaluates the active animation at the current time and updates
        the animation_registry with transform matrices for each animated node/bone.
        For skeletal animations, these transforms would be applied to bone hierarchies.
        For simpler models, this serves as a placeholder for future bone support.
        """
        if not self.current_animation or self.current_animation not in self.animations:
            return
        
        anim_clip = self.animations[self.current_animation]
        if not isinstance(anim_clip, AnimationClip):
            return
        
        # Evaluate transforms for each node in the animation
        current_time = getattr(self, 'current_animation_time', 0.0)
        # Ensure it's a float
        try:
            current_time = float(current_time)
        except (ValueError, TypeError):
            current_time = 0.0
        
        for node_name in anim_clip.get_node_names():
            transform = anim_clip.evaluate(node_name, current_time)
            if transform:
                # Store transform in registry (for future bone system integration)
                # For now, this is a placeholder - actual bone application would happen in rendering
                self.animation_registry[node_name] = transform
        
        # TODO: Apply transforms to actual mesh vertices/bones during rendering
        # This would require:
        # 1. Bone hierarchy/joint structure from model
        # 2. Vertex skinning weights
        # 3. Matrix palette for GPU skinning or CPU vertex transformation
    
    def _calculate_normals(self):
        """Calculate vertex normals from faces (smooth shading)"""
        if self.vertices is None or self.indices is None or len(self.vertices) == 0:
            return None
        
        # Initialize normals array
        normals = np.zeros_like(self.vertices)
        
        # Calculate face normals and accumulate to vertices
        for i in range(0, len(self.indices), 3):
            if i + 2 >= len(self.indices):
                break
            idx0 = self.indices[i]
            idx1 = self.indices[i + 1]
            idx2 = self.indices[i + 2]
            
            if idx0 < len(self.vertices) and idx1 < len(self.vertices) and idx2 < len(self.vertices):
                v0 = self.vertices[idx0]
                v1 = self.vertices[idx1]
                v2 = self.vertices[idx2]
                
                # Calculate face normal
                edge1 = v1 - v0
                edge2 = v2 - v0
                normal = np.cross(edge1, edge2)
                length = np.linalg.norm(normal)
                if length > 1e-6:
                    normal = normal / length
                    
                    # Accumulate to vertices (smooth shading)
                    normals[idx0] += normal
                    normals[idx1] += normal
                    normals[idx2] += normal
        
        # Normalize accumulated normals
        lengths = np.linalg.norm(normals, axis=1, keepdims=True)
        lengths[lengths < 1e-6] = 1.0  # Avoid division by zero
        normals = normals / lengths
        
        return normals.astype(np.float32)
    
    def _calculate_face_normals(self):
        """Calculate face normals for flat/low poly shading"""
        if self.vertices is None or self.indices is None or len(self.vertices) == 0:
            return None
        
        # For flat shading, we need one normal per face (triangle)
        # We'll create expanded arrays with duplicated vertices and face normals
        num_triangles = len(self.indices) // 3
        normals = np.zeros((num_triangles * 3, 3), dtype=np.float32)
        
        for i in range(0, len(self.indices), 3):
            if i + 2 >= len(self.indices):
                break
            idx0 = self.indices[i]
            idx1 = self.indices[i + 1]
            idx2 = self.indices[i + 2]
            
            if idx0 < len(self.vertices) and idx1 < len(self.vertices) and idx2 < len(self.vertices):
                v0 = self.vertices[idx0]
                v1 = self.vertices[idx1]
                v2 = self.vertices[idx2]
                
                # Calculate face normal
                edge1 = v1 - v0
                edge2 = v2 - v0
                normal = np.cross(edge1, edge2)
                length = np.linalg.norm(normal)
                if length > 1e-6:
                    normal = normal / length
                else:
                    normal = np.array([0.0, 1.0, 0.0])  # Default up if degenerate
                
                # Assign same normal to all three vertices of this triangle
                triangle_idx = i // 3
                normals[triangle_idx * 3] = normal
                normals[triangle_idx * 3 + 1] = normal
                normals[triangle_idx * 3 + 2] = normal
        
        return normals
    
    def _recalculate_normals_for_style(self):
        """Recalculate normals based on current lighting style"""
        if self.vertices is None or self.indices is None:
            return
        
        # STEP 1: If we have stored original vertices (from Low Poly), restore them first
        # This ensures we always work from the base geometry
        if hasattr(self, '_original_vertices'):
            debug(f"Restoring original vertices (leaving Low Poly mode)")
            self.vertices = self._original_vertices.copy()
            if hasattr(self, '_original_indices'):
                self.indices = self._original_indices.copy()
            # Clean up the stored originals
            delattr(self, '_original_vertices')
            if hasattr(self, '_original_indices'):
                delattr(self, '_original_indices')
        
        # STEP 2: Apply the new style
        if self.lighting_style == "Low Poly":
            # For low poly, we need to expand vertices and use face normals
            # Store original indices/vertices BEFORE expanding
            debug(f"Storing original vertices for Low Poly mode")
            self._original_indices = self.indices.copy()
            self._original_vertices = self.vertices.copy()
            
            # Expand vertices: each triangle gets its own 3 vertices
            num_triangles = len(self._original_indices) // 3
            expanded_vertices = np.zeros((num_triangles * 3, 3), dtype=np.float32)
            expanded_indices = np.zeros(num_triangles * 3, dtype=np.uint32)
            
            for i in range(0, len(self._original_indices), 3):
                if i + 2 >= len(self._original_indices):
                    break
                idx0 = self._original_indices[i]
                idx1 = self._original_indices[i + 1]
                idx2 = self._original_indices[i + 2]
                
                triangle_idx = i // 3
                expanded_vertices[triangle_idx * 3] = self._original_vertices[idx0]
                expanded_vertices[triangle_idx * 3 + 1] = self._original_vertices[idx1]
                expanded_vertices[triangle_idx * 3 + 2] = self._original_vertices[idx2]
                expanded_indices[triangle_idx * 3] = triangle_idx * 3
                expanded_indices[triangle_idx * 3 + 1] = triangle_idx * 3 + 1
                expanded_indices[triangle_idx * 3 + 2] = triangle_idx * 3 + 2
            
            self.vertices = expanded_vertices
            self.indices = expanded_indices
            self.normals = self._calculate_face_normals()
            debug(f"Expanded to {len(self.vertices)} vertices for Low Poly")
        else:
            # Smooth shading modes (Default, Toon Ramp)
            # We're already using original vertices (restored above if needed)
            # Just recalculate smooth normals
            self.normals = self._calculate_normals()
            debug(f"Using smooth normals for {self.lighting_style} style with {len(self.vertices)} vertices")
    
    def _get_speed_multiplier(self):
        """Calculate movement speed multiplier based on model size
        
        For large models, use a more conservative scaling to prevent
        overly fast navigation. This makes the preview more usable.
        """
        if self.model_size is None:
            return 1.0  # Default if model not loaded
        
        # Use the largest dimension of the model as reference
        model_extent = np.max(self.model_size)
        
        if model_extent < 200:
            # Small models: proportional speed
            multiplier = max(0.1, model_extent)
        elif model_extent < 1000:
            # Medium models: moderate scaling
            multiplier = 200.0 + (model_extent - 200) * 0.5
        else:
            # Large models: conservative scaling to keep navigation manageable
            # Cap the multiplier so very large models don't become uncontrollable
            multiplier = 600.0 + (model_extent - 1000) * 0.3
            # Cap at reasonable maximum to prevent extreme speeds
            multiplier = min(multiplier, 2000.0)
        
        return multiplier
    
    def _clamp_camera_position(self, pos):
        """Clamp camera position to environment boundaries (10x model size)"""
        if self.env_min is None or self.env_max is None:
            return pos
        
        clamped_x = max(self.env_min[0], min(self.env_max[0], pos.x))
        clamped_y = max(self.env_min[1], min(self.env_max[1], pos.y))
        clamped_z = max(self.env_min[2], min(self.env_max[2], pos.z))
        
        return Vector3(clamped_x, clamped_y, clamped_z)
    
    def _clamp_camera_position_outside_model(self, pos):
        """Clamp camera position to environment bounds while ensuring it stays outside model bounds"""
        if (self.env_min is None or self.env_max is None or 
            not hasattr(self, 'model_min') or not hasattr(self, 'model_max') or
            self.model_min is None or self.model_max is None):
            return pos
        
        # First clamp to environment
        clamped_x = max(self.env_min[0], min(self.env_max[0], pos.x))
        clamped_y = max(self.env_min[1], min(self.env_max[1], pos.y))
        clamped_z = max(self.env_min[2], min(self.env_max[2], pos.z))
        
        result = Vector3(clamped_x, clamped_y, clamped_z)
        
        # Check if clamped position is inside model - if so, push it out along the direction from model center
        if (self.model_min[0] <= result.x <= self.model_max[0] and
            self.model_min[1] <= result.y <= self.model_max[1] and
            self.model_min[2] <= result.z <= self.model_max[2]):
            # Camera got clamped inside model - push it outside
            # Calculate direction from model center to camera
            dir_to_cam = np.array([result.x - self.model_center[0], 
                                  result.y - self.model_center[1], 
                                  result.z - self.model_center[2]])
            dir_length = np.linalg.norm(dir_to_cam)
            if dir_length > 0.0001:
                dir_to_cam = dir_to_cam / dir_length  # Normalize
            else:
                # Default direction if too close to center
                dir_to_cam = np.array([0.577, 0.577, 0.577])  # Normalized diagonal
            
            # Find the closest point on model bounding box in this direction
            # and place camera just outside it
            model_half_size = (self.model_max - self.model_min) / 2.0
            push_distance = np.max(model_half_size) * 1.5  # Push 1.5x the largest half-dimension
            
            # Position outside model along this direction
            result = Vector3(
                self.model_center[0] + dir_to_cam[0] * push_distance,
                self.model_center[1] + dir_to_cam[1] * push_distance,
                self.model_center[2] + dir_to_cam[2] * push_distance
            )
            
            # Re-clamp to environment (but at least we're outside model now)
            result.x = max(self.env_min[0], min(self.env_max[0], result.x))
            result.y = max(self.env_min[1], min(self.env_max[1], result.y))
            result.z = max(self.env_min[2], min(self.env_max[2], result.z))
        
        return result
    
    def _center_and_scale(self, scale_factor=None):
        """Position model with bottom at 0,0,0 and calculate bounding box
        
        Args:
            scale_factor: Optional scale factor to apply. If None, preserves original size.
                          Only extremely large models (>1000 units) will be normalized.
        """
        if self.vertices is None or len(self.vertices) == 0:
            return
        
        # Maximum model size before normalization (in units)
        # Models larger than this will be normalized to preserve relative proportions
        # Increased to 10000 to preserve large models like Diamond Steppe Island
        # This prevents performance issues while preserving significant detail for most models
        MAX_MODEL_SIZE = 10000.0
        
        # Calculate bounding box of original model
        min_vals = np.min(self.vertices, axis=0)
        max_vals = np.max(self.vertices, axis=0)
        
        # Calculate model size (extent in each dimension)
        size = max_vals - min_vals
        model_extent = np.max(size)  # Largest dimension
        
        # DEBUG: Show original model size BEFORE any transformations
        debug(f"Model size BEFORE normalization:")
        debug(f"  Bounding box min: [{min_vals[0]:.2f}, {min_vals[1]:.2f}, {min_vals[2]:.2f}]")
        debug(f"  Bounding box max: [{max_vals[0]:.2f}, {max_vals[1]:.2f}, {max_vals[2]:.2f}]")
        debug(f"  Model size (X, Y, Z): [{size[0]:.2f}, {size[1]:.2f}, {size[2]:.2f}]")
        debug(f"  Model extent (largest dimension): {model_extent:.2f} units")
        
        # Store original vertices for preview scale feature (before any transformations)
        # This stores the vertices as loaded from file, before any scaling/centering
        if not hasattr(self, '_original_vertices') or self._original_vertices is None:
            self._original_vertices = self.vertices.copy()
        
        # Apply optional scale factor (but preserve relative sizes by default)
        if scale_factor is not None and scale_factor != 1.0:
            self.vertices = self.vertices * scale_factor
            min_vals = min_vals * scale_factor
            max_vals = max_vals * scale_factor
            size = size * scale_factor
            model_extent = model_extent * scale_factor
        
        # Normalize models larger than MAX_MODEL_SIZE (2000 units)
        # This ensures models are at least 50% of original size for models up to 4000 units
        # Models larger than 4000 will be smaller but still maintain significant detail
        if model_extent > MAX_MODEL_SIZE:
            debug(f"Model is very large (extent={model_extent:.2f}), normalizing to {MAX_MODEL_SIZE}")
            normalization_factor = MAX_MODEL_SIZE / model_extent
            percent_preserved = (normalization_factor * 100.0)
            debug(f"Normalization factor: {normalization_factor:.4f} ({percent_preserved:.1f}% of original size)")
            self.vertices = self.vertices * normalization_factor
            min_vals = min_vals * normalization_factor
            max_vals = max_vals * normalization_factor
            size = size * normalization_factor
            model_extent = MAX_MODEL_SIZE
            debug(f"Model size AFTER normalization:")
            debug(f"  Bounding box min: [{min_vals[0]:.2f}, {min_vals[1]:.2f}, {min_vals[2]:.2f}]")
            debug(f"  Bounding box max: [{max_vals[0]:.2f}, {max_vals[1]:.2f}, {max_vals[2]:.2f}]")
            debug(f"  Model size (X, Y, Z): [{size[0]:.2f}, {size[1]:.2f}, {size[2]:.2f}]")
            debug(f"  Model extent (largest dimension): {model_extent:.2f} units")
        else:
            debug(f"Model size preserved - extent={model_extent:.2f} (within {MAX_MODEL_SIZE} limit)")
            debug(f"Model size AFTER (no normalization):")
            debug(f"  Bounding box min: [{min_vals[0]:.2f}, {min_vals[1]:.2f}, {min_vals[2]:.2f}]")
            debug(f"  Bounding box max: [{max_vals[0]:.2f}, {max_vals[1]:.2f}, {max_vals[2]:.2f}]")
            debug(f"  Model size (X, Y, Z): [{size[0]:.2f}, {size[1]:.2f}, {size[2]:.2f}]")
            debug(f"  Model extent (largest dimension): {model_extent:.2f} units")
        
        # Shift model so bottom is at Y=0
        # min_vals[1] is the lowest Y coordinate
        y_offset = -min_vals[1]
        self.vertices[:, 1] = self.vertices[:, 1] + y_offset
        
        # Update min_vals after Y translation for bounding box calculation
        min_vals[1] = 0.0
        
        # Recalculate bounding box after transformation
        self.model_min = np.min(self.vertices, axis=0)
        self.model_max = np.max(self.vertices, axis=0)
        self.model_size = self.model_max - self.model_min
        self.model_center = (self.model_min + self.model_max) / 2.0
        
        # Apply preview scale if set (after all other transformations)
        preview_scale = getattr(self, '_preview_scale', 1.0)
        if preview_scale != 1.0 and hasattr(self, '_original_vertices') and self._original_vertices is not None:
            # Restore to original vertices first, then reapply all transformations except preview scale
            # For simplicity, just apply preview scale to current vertices around model center
            scale_center = self.model_center.copy()
            self.vertices = (self.vertices - scale_center) * preview_scale + scale_center
            # Recalculate bounding box after preview scale
            self.model_min = np.min(self.vertices, axis=0)
            self.model_max = np.max(self.vertices, axis=0)
            self.model_size = self.model_max - self.model_min
            self.model_center = (self.model_min + self.model_max) / 2.0
            
            # Recalculate environment size based on scaled model
            self.env_size = self.model_size * 10.0
            env_half_size = self.env_size / 2.0
            self.env_min = self.model_center - env_half_size
            self.env_max = self.model_center + env_half_size
        else:
            # Calculate environment size (10x model size) if preview scale not applied
            self.env_size = self.model_size * 10.0
        
        # Set environment boundaries centered on model
        # Environment extends from -env_size/2 to +env_size/2 around model center
        env_half_size = self.env_size / 2.0
        self.env_min = self.model_center - env_half_size
        self.env_max = self.model_center + env_half_size
        
        # Ensure environment includes origin and model
        self.env_min = np.minimum(self.env_min, np.array([-self.env_size[0]/2, 0.0, -self.env_size[2]/2]))
        self.env_max = np.maximum(self.env_max, np.array([self.env_size[0]/2, self.env_size[1], self.env_size[2]/2]))
        
        # Update camera frustum based on model size
        # Far plane needs to be much larger than the environment for large models
        max_env_size = np.max(self.env_size)
        self.camera.far = max(1000.0, max_env_size * 2.0)  # At least 2x environment size
        debug(f"Camera far plane set to {self.camera.far:.2f} for model size {max_env_size:.2f}")
        
        # Position camera to view model nicely - ensure it's OUTSIDE model bounds
        # Calculate model bounding sphere radius (half the diagonal of bounding box)
        model_half_diagonal = np.sqrt(np.sum((self.model_size / 2.0) ** 2))
        
        # Use a consistent distance multiplier that works well for all model sizes
        # For large models, use a smaller multiplier so they appear properly sized
        max_model_dim = np.max(self.model_size)
        
        if max_model_dim < 200:
            # Very small models: use standard distance
            safe_distance = model_half_diagonal * 3.0
        elif max_model_dim < 1000:
            # Medium models: use proportional distance
            safe_distance = model_half_diagonal * 2.5
        else:
            # Large models (>1000 units): use a much smaller multiplier so they fill the viewport
            # This ensures large models like Diamond Steppe Island appear at proper scale
            # Position camera much closer - just outside model bounds with minimal padding
            if max_model_dim > 4000:
                # Very large models (>4000 units): position very close to show full scale
                safe_distance = model_half_diagonal * 1.2
            else:
                # Large but not huge models: use slightly more distance
                safe_distance = model_half_diagonal * 1.3
        
        # Position camera at an angle (diagonal up and back) to view model
        # This ensures we're definitely outside the model's bounding box
        angle_horizontal = np.radians(45.0)  # 45 degrees horizontally
        angle_vertical = np.radians(25.0)   # 25 degrees up from horizontal
        
        # Calculate offset from model center
        offset_x = safe_distance * np.cos(angle_vertical) * np.cos(angle_horizontal)
        offset_y = safe_distance * np.sin(angle_vertical)  # Up
        offset_z = safe_distance * np.cos(angle_vertical) * np.sin(angle_horizontal)
        
        # Position camera outside model bounds
        camera_pos = Vector3(
            self.model_center[0] + offset_x,
            self.model_center[1] + offset_y,
            self.model_center[2] + offset_z
        )
        
        # Verify camera is outside model bounds, if not, push it further
        if (self.model_min[0] <= camera_pos.x <= self.model_max[0] and
            self.model_min[1] <= camera_pos.y <= self.model_max[1] and
            self.model_min[2] <= camera_pos.z <= self.model_max[2]):
            # Camera is inside model - push it further away
            debug(f"Camera was inside model bounds, pushing further out")
            safe_distance = model_half_diagonal * 3.0  # Increase distance
            offset_x = safe_distance * np.cos(angle_vertical) * np.cos(angle_horizontal)
            offset_y = safe_distance * np.sin(angle_vertical)
            offset_z = safe_distance * np.cos(angle_vertical) * np.sin(angle_horizontal)
            camera_pos = Vector3(
                self.model_center[0] + offset_x,
                self.model_center[1] + offset_y,
                self.model_center[2] + offset_z
            )
        
        # Clamp to environment bounds if needed (but keep outside model)
        camera_pos = self._clamp_camera_position_outside_model(camera_pos)
        
        self.camera.position = camera_pos
        
        # Set camera to look at model center
        self.camera.yaw = 0.0
        self.camera.pitch = -15.0  # Look down slightly (less steep angle)
        
        debug(f"Camera positioned at [{self.camera.position.x:.2f}, {self.camera.position.y:.2f}, {self.camera.position.z:.2f}]")
        debug(f"Model center: [{self.model_center[0]:.2f}, {self.model_center[1]:.2f}, {self.model_center[2]:.2f}]")
        debug(f"Model bounds: min=[{self.model_min[0]:.2f}, {self.model_min[1]:.2f}, {self.model_min[2]:.2f}], max=[{self.model_max[0]:.2f}, {self.model_max[1]:.2f}, {self.model_max[2]:.2f}]")
        debug(f"Camera distance from center: {safe_distance:.2f}, Model half-diagonal: {model_half_diagonal:.2f}")
        
        # Recalculate normals after transformation
        if self.indices is not None:
            self.normals = self._calculate_normals()


class Edge:
    """Represents a 3D edge/line for editing"""
    def __init__(self, start=None, end=None, id=0):
        self.start = start if start else Vector3()
        self.end = end if end else Vector3()
        self.id = id


class Face:
    """Represents a 3D face/polygon for editing"""
    def __init__(self, vertices=None, id=0, color=(0.7, 0.8, 0.85)):
        self.vertices = vertices if vertices else []
        self.id = id
        self.color = color


class ToolMode:
    """Tool modes for editing"""
    SELECT = "select"
    DRAW = "draw"
    MOVE = "move"
    ROTATE = "rotate"
    SCALE = "scale"
    ORBIT = "orbit"
    PAN = "pan"


class ModelEditGLWidget(ModelPreviewGLWidget):
    """Advanced 3D model editor with drawing, editing, and texture capabilities
    
    Combines the performance of ModelPreviewGLWidget with editing features
    from sketchup-like applications (drawing edges, face detection, etc.)
    """
    def __init__(self, parent=None):
        # Initialize parent (ModelPreviewGLWidget) but skip its specific setup
        QOpenGLWidget.__init__(self, parent)
        self.setMinimumSize(800, 600)
        self.camera = Camera()
        
        # ORIGINAL MESH - preserved for rendering, NEVER modified by drawing/editing
        self._original_vertices = None
        self._original_indices = None
        self._original_normals = None
        self._original_tex_coords = None
        self._original_face_materials = []
        
        # Current rendering mesh (points to original unless explicitly modified)
        self.vertices = None
        self.indices = None
        self.normals = None
        self.tex_coords = None
        self.face_materials = []
        
        # Material and texture data
        self.textures = {}
        self.materials = {}
        self.blended_textures = {}
        self.model_dir = None  # Directory for texture path resolution
        
        # Animation data
        self.animations = {}  # Dictionary of {animation_name: AnimationClip}
        self.current_animation = None
        self.current_animation_time = 0.0  # Time in seconds (replaces frame-based)
        self.animation_speed = 1.0  # Playback speed multiplier
        self.animation_loop = True  # Whether to loop animation
        self.is_playing_animation = False
        self.animation_timer = None
        self.animation_registry = {}  # Node/bone name -> transform matrices (for pose evaluation)
        
        # Light gizmos (for visualization)
        self.show_light_gizmos = True
        
        # EDIT GEOMETRY LAYER - separate geometry created by drawing/editing
        self._edit_vertices = []  # New vertices created by drawing
        self._edit_indices = []   # New indices for edit geometry
        self._edit_normals = None
        self._edit_tex_coords = None
        self._edit_faces = []     # Face objects for edit geometry
        
        # Editing-specific data structures (for selection/highlighting)
        self.edges = []  # List of Edge objects (for original mesh selection)
        self._edit_edges = []  # List of Edge objects (for edit geometry)
        self.faces = []  # List of Face objects (for original mesh - detection only)
        self.next_id = 0
        
        # CRITICAL: Flag to prevent geometry rebuild during editing
        # Only set to True when explicitly exporting or creating new geometry
        self._allow_geometry_rebuild = False
        
        # Tool and selection state
        self.tool_mode = ToolMode.SELECT
        self.selected_edges = set()
        self.selected_faces = set()
        self.selected_vertices = set()
        self.hovered_edge = None
        self.hovered_face = None
        self.hovered_vertex = None
        self.edit_mode = False  # Track if we're in edit mode (for coordinate display)
        
        # Selection state persistence
        self._last_hover_update_time = 0
        
        # Clipboard for copy/paste
        self.clipboard_edges = []
        self.clipboard_faces = []
        self.clipboard_vertices = []
        self.clipboard_vertex_data = []
        
        # Transform state (for move/rotate/scale operations)
        self.transform_start_pos = None
        self.transform_center = None
        self.is_transforming = False
        self.transform_start_mouse = None
        self.transform_initial_positions = {}  # Store initial vertex positions before transform
        self.transform_constraint_axis = None  # X, Y, or Z axis constraint
        self.transform_snap_grid = False
        
        # Undo/Redo system
        self.undo_stack = []
        self.redo_stack = []
        self.max_undo_levels = 50
    
    def push_undo(self):
        """Push current state onto undo stack"""
        state = {
            'vertices': self.vertices.copy() if self.vertices is not None else None,
            'indices': self.indices.copy() if self.indices is not None else None,
            'normals': self.normals.copy() if self.normals is not None else None,
            'tex_coords': self.tex_coords.copy() if self.tex_coords is not None else None,
            'selected_edges': list(self.selected_edges),
            'selected_faces': list(self.selected_faces),
            'selected_vertices': list(self.selected_vertices),
        }
        self.undo_stack.append(state)
        # Limit undo stack size
        if len(self.undo_stack) > self.max_undo_levels:
            self.undo_stack.pop(0)
        # Clear redo stack when new action is done
        self.redo_stack.clear()
    
    def undo(self):
        """Undo last action"""
        if not self.undo_stack:
            return
        
        # Push current state to redo stack
        current_state = {
            'vertices': self.vertices.copy() if self.vertices is not None else None,
            'indices': self.indices.copy() if self.indices is not None else None,
            'normals': self.normals.copy() if self.normals is not None else None,
            'tex_coords': self.tex_coords.copy() if self.tex_coords is not None else None,
            'selected_edges': list(self.selected_edges),
            'selected_faces': list(self.selected_faces),
            'selected_vertices': list(self.selected_vertices),
        }
        self.redo_stack.append(current_state)
        
        # Restore previous state
        state = self.undo_stack.pop()
        if state['vertices'] is not None:
            self.vertices = state['vertices'].copy()
        if state['indices'] is not None:
            self.indices = state['indices'].copy()
        if state['normals'] is not None:
            self.normals = state['normals'].copy()
        if state['tex_coords'] is not None:
            self.tex_coords = state['tex_coords'].copy()
        self.selected_edges = set(state['selected_edges'])
        self.selected_faces = set(state['selected_faces'])
        self.selected_vertices = set(state['selected_vertices'])
    
    def redo(self):
        """Redo last undone action"""
        if not self.redo_stack:
            return
        
        # Push current state to undo stack
        current_state = {
            'vertices': self.vertices.copy() if self.vertices is not None else None,
            'indices': self.indices.copy() if self.indices is not None else None,
            'normals': self.normals.copy() if self.normals is not None else None,
            'tex_coords': self.tex_coords.copy() if self.tex_coords is not None else None,
            'selected_edges': list(self.selected_edges),
            'selected_faces': list(self.selected_faces),
            'selected_vertices': list(self.selected_vertices),
        }
        self.undo_stack.append(current_state)
        
        # Restore next state
        state = self.redo_stack.pop()
        if state['vertices'] is not None:
            self.vertices = state['vertices'].copy()
        if state['indices'] is not None:
            self.indices = state['indices'].copy()
        if state['normals'] is not None:
            self.normals = state['normals'].copy()
        if state['tex_coords'] is not None:
            self.tex_coords = state['tex_coords'].copy()
        self.selected_edges = set(state['selected_edges'])
        self.selected_faces = set(state['selected_faces'])
        self.selected_vertices = set(state['selected_vertices'])
    
    def _delete_vertices(self, vertex_indices):
        """Delete vertices and update indices"""
        if self.vertices is None or self.indices is None:
            return
        
        # Create sorted list of indices to delete
        indices_to_delete = sorted(set(vertex_indices), reverse=True)
        
        # Remove vertices
        for idx in indices_to_delete:
            if idx < len(self.vertices):
                self.vertices = np.delete(self.vertices, idx, axis=0)
                # Update all indices greater than deleted index
                self.indices = np.where(self.indices > idx, self.indices - 1, self.indices)
        
        # Drawing state
        self.draw_start_point = None
        self.cursor_3d = Vector3(0, 0, 0)
        self.previous_cursor_3d = Vector3(0, 0, 0)
        
        # Inference system (for drawing)
        self.inference_point = None
        self.locked_axis = None
        self.grid_snap = True
        self.grid_size = 1.0
        
        # Mouse interaction
        self.last_mouse_pos = QPoint()
        self.is_rotating = False
        self.is_panning = False
        
        # Movement timer (inherited behavior)
        self.move_timer = QTimer(self)
        self.move_timer.timeout.connect(self._tick)
        self.move_timer.start(16)
        self.keys = {Qt.Key_W: False, Qt.Key_A: False, Qt.Key_S: False, Qt.Key_D: False}
        # Use ClickFocus instead of StrongFocus to prevent focus grabbing on creation
        # StrongFocus causes the widget to grab focus when it becomes visible, which
        # makes the main window appear to disappear when opening model files
        self.setFocusPolicy(Qt.ClickFocus)
        self.setMouseTracking(True)
        
        # Model bounds (inherited)
        self.model_min = None
        self.model_max = None
        self.model_center = None
        self.model_size = None
        self.env_size = None
        self.env_min = None
        self.env_max = None
        
        # Lighting (inherited)
        self.model_lit = True
        self.external_light_enabled = False
        self.light_color = QColor(255, 255, 255)
        self.light_position_mode = "top"
        self.internal_light_brightness = 1.0
        self.external_light_brightness = 5.0
        self.lighting_style = "Default"
        self._original_vertices = None
        self._original_indices = None
        
        # Performance optimizations
        self._geometry_dirty = True
    
    def load_from_preview(self, preview_widget):
        """Load geometry from a ModelPreviewGLWidget"""
        if preview_widget.vertices is not None:
            self.vertices = preview_widget.vertices.copy()
            self.indices = preview_widget.indices.copy() if preview_widget.indices is not None else None
            self.normals = preview_widget.normals.copy() if preview_widget.normals is not None else None
            self.tex_coords = preview_widget.tex_coords.copy() if preview_widget.tex_coords is not None else None
            self.materials = preview_widget.materials.copy()
            self.textures = preview_widget.textures.copy()
            self.face_materials = preview_widget.face_materials[:]
            self.blended_textures = preview_widget.blended_textures.copy()
            
            # Convert to edges for editing
            self._convert_vertices_to_edges()
            
            # Recalculate bounds
            if self.vertices is not None and len(self.vertices) > 0:
                self.model_min = np.min(self.vertices, axis=0)
                self.model_max = np.max(self.vertices, axis=0)
                self.model_size = self.model_max - self.model_min
                self.model_center = (self.model_min + self.model_max) / 2.0
                self.env_size = self.model_size * 10.0
                env_half_size = self.env_size / 2.0
                self.env_min = self.model_center - env_half_size
                self.env_max = self.model_center + env_half_size
            
            self._geometry_dirty = True
            self.update()
    
    def _convert_vertices_to_edges_only(self):
        """Convert indexed vertices to Edge objects for editing WITHOUT rebuilding geometry
        This preserves the original vertices/indices for rendering while creating edges for selection"""
        if self.vertices is None or self.indices is None:
            return
        
        self.edges = []
        edge_keys = set()
        num_vertices = len(self.vertices)
        
        # Create edges from triangle indices
        for i in range(0, len(self.indices), 3):
            if i + 2 < len(self.indices):
                # Cast to int but preserve as-is for bounds checking (no precision loss needed here)
                v0_idx = self.indices[i]
                v1_idx = self.indices[i + 1]
                v2_idx = self.indices[i + 2]
                
                # Ensure indices are valid BEFORE creating any edges
                if (0 <= v0_idx < num_vertices and 
                    0 <= v1_idx < num_vertices and 
                    0 <= v2_idx < num_vertices):
                    # Add three edges per triangle
                    for edge_pair in [(v0_idx, v1_idx), (v1_idx, v2_idx), (v2_idx, v0_idx)]:
                        a_idx, b_idx = edge_pair
                        # Create unique key (smaller index first)
                        key = tuple(sorted([int(a_idx), int(b_idx)]))
                        if key not in edge_keys:
                            edge_keys.add(key)
                            # Direct access - no intermediate casts that lose precision
                            v0 = Vector3(float(self.vertices[a_idx][0]), 
                                       float(self.vertices[a_idx][1]), 
                                       float(self.vertices[a_idx][2]))
                            v1 = Vector3(float(self.vertices[b_idx][0]), 
                                       float(self.vertices[b_idx][1]), 
                                       float(self.vertices[b_idx][2]))
                            edge = Edge(start=v0, end=v1, id=self.next_id)
                            self.next_id += 1
                            self.edges.append(edge)
        
        # DON'T detect faces or rebuild geometry here - preserve original geometry for rendering
        # Faces can be detected later when needed for editing operations
        # NEVER call _rebuild_geometry() from this method - it will destroy texture coordinates!
    
    def _convert_vertices_to_edges(self):
        """Convert indexed vertices to Edge objects for editing and rebuild geometry"""
        if self.vertices is None or self.indices is None:
            return
        
        self.edges = []
        edge_keys = set()
        
        # Create edges from triangle indices
        for i in range(0, len(self.indices), 3):
            if i + 2 < len(self.indices):
                v0_idx = self.indices[i]
                v1_idx = self.indices[i + 1]
                v2_idx = self.indices[i + 2]
                
                # Add three edges per triangle
                for edge_pair in [(v0_idx, v1_idx), (v1_idx, v2_idx), (v2_idx, v0_idx)]:
                    a_idx, b_idx = edge_pair
                    # Create unique key (smaller index first)
                    key = tuple(sorted([int(a_idx), int(b_idx)]))
                    if key not in edge_keys:
                        edge_keys.add(key)
                        v0 = Vector3(self.vertices[a_idx][0], self.vertices[a_idx][1], self.vertices[a_idx][2])
                        v1 = Vector3(self.vertices[b_idx][0], self.vertices[b_idx][1], self.vertices[b_idx][2])
                        edge = Edge(start=v0, end=v1, id=self.next_id)
                        self.next_id += 1
                        self.edges.append(edge)
        
        # Detect faces from edges (this will rebuild geometry)
        self._detect_faces()
    
    def export_to_preview(self, preview_widget):
        """Export edited geometry back to a ModelPreviewGLWidget"""
        if self.vertices is not None:
            preview_widget.vertices = self.vertices.copy()
            preview_widget.indices = self.indices.copy() if self.indices is not None else None
            preview_widget.normals = self.normals.copy() if self.normals is not None else None
            preview_widget.tex_coords = self.tex_coords.copy() if self.tex_coords is not None else None
            
            # Recalculate normals and bounds
            if preview_widget.indices is not None:
                preview_widget.normals = preview_widget._calculate_normals()
            
            if preview_widget.vertices is not None and len(preview_widget.vertices) > 0:
                preview_widget.model_min = np.min(preview_widget.vertices, axis=0)
                preview_widget.model_max = np.max(preview_widget.vertices, axis=0)
                preview_widget.model_size = preview_widget.model_max - preview_widget.model_min
                preview_widget.model_center = (preview_widget.model_min + preview_widget.model_max) / 2.0
            
            preview_widget.update()
    
    def _find_closed_loops(self, edges_to_search=None):
        """Find closed loops/polygons from edges - can search specific edge set"""
        if edges_to_search is None:
            edges_to_search = self.edges
        
        if not edges_to_search or len(edges_to_search) < 3:
            return []
        
        def vertex_key(v):
            epsilon = 0.001
            return (
                round(v.x / epsilon) * epsilon,
                round(v.y / epsilon) * epsilon,
                round(v.z / epsilon) * epsilon
            )
        
        # Build adjacency information
        vertex_to_edges = {}
        edge_connections = {}
        
        for i, edge in enumerate(edges_to_search):
            start_key = vertex_key(edge.start)
            end_key = vertex_key(edge.end)
            edge_connections[i] = (start_key, end_key, edge.start, edge.end)
            
            if start_key not in vertex_to_edges:
                vertex_to_edges[start_key] = []
            if end_key not in vertex_to_edges:
                vertex_to_edges[end_key] = []
            
            vertex_to_edges[start_key].append(i)
            vertex_to_edges[end_key].append(i)
        
        # Find closed loops using DFS
        found_loops = []
        used_edges_global = set()
        
        for start_edge_idx in range(len(edges_to_search)):
            if start_edge_idx in used_edges_global:
                continue
            
            start_key, end_key, start_v, end_v = edge_connections[start_edge_idx]
            
            for direction in [(start_key, end_key, start_v, end_v), (end_key, start_key, end_v, start_v)]:
                origin_key, current_key, origin_v, current_v = direction
                path = [origin_v, current_v]
                path_keys = [origin_key, current_key]
                used_edges = {start_edge_idx}
                
                max_edges = len(edges_to_search)
                while len(used_edges) < max_edges:
                    next_edge_idx = None
                    next_key = None
                    next_vertex = None
                    
                    for edge_idx in vertex_to_edges.get(current_key, []):
                        if edge_idx in used_edges:
                            continue
                        
                        e_start_key, e_end_key, e_start_v, e_end_v = edge_connections[edge_idx]
                        
                        if e_start_key == current_key:
                            if e_end_key == origin_key and len(path) >= 3:
                                found_loops.append(path.copy())
                                used_edges_global.update(used_edges)
                                used_edges_global.add(edge_idx)
                                break
                            elif e_end_key not in path_keys[1:-1]:
                                next_edge_idx = edge_idx
                                next_key = e_end_key
                                next_vertex = e_end_v
                                break
                        elif e_end_key == current_key:
                            if e_start_key == origin_key and len(path) >= 3:
                                found_loops.append(path.copy())
                                used_edges_global.update(used_edges)
                                used_edges_global.add(edge_idx)
                                break
                            elif e_start_key not in path_keys[1:-1]:
                                next_edge_idx = edge_idx
                                next_key = e_start_key
                                next_vertex = e_start_v
                                break
                    
                    if next_edge_idx is None:
                        break
                    
                    path.append(next_vertex)
                    path_keys.append(next_key)
                    used_edges.add(next_edge_idx)
                    current_key = next_key
                    current_v = next_vertex
                
                if start_edge_idx in used_edges_global:
                    break
        
        return found_loops
    
    def _detect_faces(self):
        """Detect and store faces from closed loops in ORIGINAL mesh edges
        
        WARNING: This should NOT be called during normal edit mode operations
        as it will trigger _rebuild_geometry() which destroys texture coordinates.
        Only call this when explicitly creating new geometry or when exporting.
        """
        loops = self._find_closed_loops(self.edges)  # Use original edges only
        self.faces.clear()
        
        if not loops:
            return
        
        # Create faces from loops
        face_id = 0
        for loop in loops:
            if len(loop) >= 3:
                face = Face(vertices=loop, id=face_id, color=(0.7, 0.8, 0.85))
                self.faces.append(face)
                face_id += 1
        
        # CRITICAL: Only rebuild geometry if explicitly requested (not during normal editing)
        # This prevents destroying texture coordinates and material mappings
        if hasattr(self, '_allow_geometry_rebuild') and self._allow_geometry_rebuild:
            self._rebuild_geometry()
            self._geometry_dirty = True
        else:
            # Just store faces without rebuilding - preserve original geometry
            self._geometry_dirty = False
    
    def _detect_edit_faces(self):
        """Detect and store faces from closed loops in EDIT geometry edges"""
        loops = self._find_closed_loops(self._edit_edges)  # Use edit edges only
        
        if not loops:
            return
        
        # Create faces from loops in edit geometry
        face_id = len(self._edit_faces)
        for loop in loops:
            if len(loop) >= 3:
                face = Face(vertices=loop, id=face_id, color=(0.8, 0.7, 0.6))
                self._edit_faces.append(face)
                face_id += 1
        
        # Rebuild edit geometry (this is OK - it's separate from original mesh)
        self._rebuild_edit_geometry()
    
    def _rebuild_edit_geometry(self):
        """Rebuild edit geometry vertices/indices from edit edges/faces (separate from original mesh)"""
        if not self._edit_faces:
            # If no faces, create vertices from edges
            vertex_map = {}
            all_vertices = []
            all_indices = []
            
            for edge in self._edit_edges:
                for vertex in [edge.start, edge.end]:
                    key = (round(vertex.x, 6), round(vertex.y, 6), round(vertex.z, 6))
                    if key not in vertex_map:
                        vertex_map[key] = len(all_vertices)
                        all_vertices.append([vertex.x, vertex.y, vertex.z])
            
            # Create line indices
            for edge in self._edit_edges:
                start_key = (round(edge.start.x, 6), round(edge.start.y, 6), round(edge.start.z, 6))
                end_key = (round(edge.end.x, 6), round(edge.end.y, 6), round(edge.end.z, 6))
                if start_key in vertex_map and end_key in vertex_map:
                    all_indices.extend([vertex_map[start_key], vertex_map[end_key]])
            
            if all_vertices:
                self._edit_vertices = np.array(all_vertices, dtype=np.float32)
                self._edit_indices = np.array(all_indices, dtype=np.uint32) if all_indices else None
            else:
                self._edit_vertices = []
                self._edit_indices = None
        else:
            # Triangulate faces
            vertex_map = {}
            all_vertices = []
            all_indices = []
            
            def add_vertex(v):
                key = (round(v.x, 6), round(v.y, 6), round(v.z, 6))
                if key not in vertex_map:
                    vertex_map[key] = len(all_vertices)
                    all_vertices.append([v.x, v.y, v.z])
                return vertex_map[key]
            
            for face in self._edit_faces:
                if len(face.vertices) < 3:
                    continue
                
                v0 = add_vertex(face.vertices[0])
                for i in range(1, len(face.vertices) - 1):
                    v1 = add_vertex(face.vertices[i])
                    v2 = add_vertex(face.vertices[i + 1])
                    all_indices.extend([v0, v1, v2])
            
            if all_vertices:
                self._edit_vertices = np.array(all_vertices, dtype=np.float32)
                self._edit_indices = np.array(all_indices, dtype=np.uint32) if all_indices else None
            else:
                self._edit_vertices = []
                self._edit_indices = None
        
        # Calculate normals for edit geometry
        if self._edit_indices is not None and len(self._edit_indices) > 0:
            # Simple normal calculation
            self._edit_normals = np.zeros((len(self._edit_vertices), 3), dtype=np.float32)
            for i in range(0, len(self._edit_indices), 3):
                if i + 2 < len(self._edit_indices):
                    v0_idx = self._edit_indices[i]
                    v1_idx = self._edit_indices[i + 1]
                    v2_idx = self._edit_indices[i + 2]
                    if v0_idx < len(self._edit_vertices) and v1_idx < len(self._edit_vertices) and v2_idx < len(self._edit_vertices):
                        v0 = self._edit_vertices[v0_idx]
                        v1 = self._edit_vertices[v1_idx]
                        v2 = self._edit_vertices[v2_idx]
                        edge1 = v1 - v0
                        edge2 = v2 - v0
                        normal = np.cross(edge1, edge2)
                        norm = np.linalg.norm(normal)
                        if norm > 0:
                            normal = normal / norm
                            self._edit_normals[v0_idx] += normal
                            self._edit_normals[v1_idx] += normal
                            self._edit_normals[v2_idx] += normal
            
            # Normalize normals
            for i in range(len(self._edit_normals)):
                norm = np.linalg.norm(self._edit_normals[i])
                if norm > 0:
                    self._edit_normals[i] = self._edit_normals[i] / norm
    
    def _rebuild_geometry(self):
        """Rebuild vertices and indices from edges/faces
        
        WARNING: This modifies the original geometry. Only call when user explicitly edits,
        not when loading from preview mode.
        """
        if not self.faces:
            # If no faces, just use edges
            unique_vertices = []
            vertex_map = {}
            indices = []
            
            for edge in self.edges:
                for vertex in [edge.start, edge.end]:
                    key = (round(vertex.x, 6), round(vertex.y, 6), round(vertex.z, 6))
                    if key not in vertex_map:
                        vertex_map[key] = len(unique_vertices)
                        unique_vertices.append([vertex.x, vertex.y, vertex.z])
            
            # Create line indices
            for edge in self.edges:
                start_key = (round(edge.start.x, 6), round(edge.start.y, 6), round(edge.start.z, 6))
                end_key = (round(edge.end.x, 6), round(edge.end.y, 6), round(edge.end.z, 6))
                if start_key in vertex_map and end_key in vertex_map:
                    indices.extend([vertex_map[start_key], vertex_map[end_key]])
            
            if unique_vertices:
                self.vertices = np.array(unique_vertices, dtype=np.float32)
                self.indices = np.array(indices, dtype=np.uint32) if indices else None
            else:
                self.vertices = None
                self.indices = None
        else:
            # Triangulate faces and rebuild
            all_vertices = []
            all_indices = []
            vertex_map = {}
            
            def add_vertex(v):
                key = (round(v.x, 6), round(v.y, 6), round(v.z, 6))
                if key not in vertex_map:
                    vertex_map[key] = len(all_vertices)
                    all_vertices.append([v.x, v.y, v.z])
                return vertex_map[key]
            
            # Triangulate each face (simple fan triangulation)
            for face in self.faces:
                if len(face.vertices) < 3:
                    continue
                
                v0 = add_vertex(face.vertices[0])
                for i in range(1, len(face.vertices) - 1):
                    v1 = add_vertex(face.vertices[i])
                    v2 = add_vertex(face.vertices[i + 1])
                    all_indices.extend([v0, v1, v2])
            
            if all_vertices:
                self.vertices = np.array(all_vertices, dtype=np.float32)
                self.indices = np.array(all_indices, dtype=np.uint32) if all_indices else None
            else:
                self.vertices = None
                self.indices = None
        
        # Recalculate normals
        if self.indices is not None:
            self.normals = self._calculate_normals()
        
        # Update bounds
        if self.vertices is not None and len(self.vertices) > 0:
            self.model_min = np.min(self.vertices, axis=0)
            self.model_max = np.max(self.vertices, axis=0)
            self.model_size = self.model_max - self.model_min
            self.model_center = (self.model_min + self.model_max) / 2.0
    
    def initializeGL(self):
        """Initialize OpenGL"""
        ModelPreviewGLWidget.initializeGL(self)
    
    def resizeGL(self, width, height):
        """Handle window resize"""
        ModelPreviewGLWidget.resizeGL(self, width, height)
    
    def paintGL(self):
        """Render the scene with editing features"""
        # Draw original mesh using parent's method
        ModelPreviewGLWidget.paintGL(self)
        
        # Draw edit geometry layer (separate from original mesh)
        self._draw_edit_geometry()
        
        # Overlay editing UI (cursor, preview lines, etc.)
        if self.tool_mode == ToolMode.DRAW and self.draw_start_point:
            self._draw_draw_preview()
        
        self._draw_3d_cursor()
        
        # Draw selection and hover highlights
        self._draw_selection_highlights()
    
    def _draw_edit_geometry(self):
        """Draw the edit geometry layer separately from original mesh"""
        if self._edit_vertices is None or len(self._edit_vertices) == 0:
            return
        
        glEnable(GL_LIGHTING)
        glEnable(GL_DEPTH_TEST)
        
        # Enable vertex array
        glEnableClientState(GL_VERTEX_ARRAY)
        glVertexPointer(3, GL_FLOAT, 0, self._edit_vertices)
        
        # Enable normal array if available
        if self._edit_normals is not None:
            glEnableClientState(GL_NORMAL_ARRAY)
            glNormalPointer(GL_FLOAT, 0, self._edit_normals)
        
        # Set material for edit geometry (slightly different color to distinguish)
        glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE, [0.8, 0.7, 0.6, 1.0])
        
        # Draw edit geometry
        if self._edit_indices is not None and len(self._edit_indices) > 0:
            glDrawElements(GL_TRIANGLES, len(self._edit_indices), GL_UNSIGNED_INT, self._edit_indices)
        
        # Also draw as wireframe overlay
        glPolygonMode(GL_FRONT_AND_BACK, GL_LINE)
        glDisable(GL_LIGHTING)
        glColor3f(0.5, 0.5, 0.5)  # Gray wireframe
        if self._edit_indices is not None and len(self._edit_indices) > 0:
            glDrawElements(GL_TRIANGLES, len(self._edit_indices), GL_UNSIGNED_INT, self._edit_indices)
        glPolygonMode(GL_FRONT_AND_BACK, GL_FILL)
        glEnable(GL_LIGHTING)
        
        glDisableClientState(GL_VERTEX_ARRAY)
        glDisableClientState(GL_NORMAL_ARRAY)
    
    def _draw_draw_preview(self):
        """Draw preview line while drawing"""
        glDisable(GL_LIGHTING)
        glDisable(GL_DEPTH_TEST)
        glLineWidth(4.0)
        glColor3f(1.0, 1.0, 0.0)  # Yellow preview line
        glBegin(GL_LINES)
        glVertex3f(self.draw_start_point.x, self.draw_start_point.y, self.draw_start_point.z)
        glVertex3f(self.cursor_3d.x, self.cursor_3d.y, self.cursor_3d.z)
        glEnd()
        glEnable(GL_DEPTH_TEST)
        glEnable(GL_LIGHTING)
    
    def _draw_3d_cursor(self):
        """Draw 3D cursor indicator"""
        glDisable(GL_LIGHTING)
        glDisable(GL_DEPTH_TEST)
        glLineWidth(2.0)
        glColor3f(1.0, 1.0, 0.0)  # Yellow cursor
        size = 0.5
        glPushMatrix()
        glTranslatef(self.cursor_3d.x, self.cursor_3d.y, self.cursor_3d.z)
        glBegin(GL_LINES)
        glVertex3f(-size, 0, 0)
        glVertex3f(size, 0, 0)
        glVertex3f(0, -size, 0)
        glVertex3f(0, size, 0)
        glVertex3f(0, 0, -size)
        glVertex3f(0, 0, size)
        glEnd()
        glPopMatrix()
        glEnable(GL_DEPTH_TEST)
        glEnable(GL_LIGHTING)
    
    def _screen_to_world(self, x, y):
        """Convert screen coordinates to world coordinates"""
        # Use similar logic to PoorPerformanceCreationAndLoading
        width = self.width()
        height = self.height()
        
        if width == 0 or height == 0:
            return self.previous_cursor_3d
        
        # Intersect with floor plane (Y=0) for now
        nx = (2.0 * x) / width - 1.0
        ny = 1.0 - (2.0 * y) / height
        
        forward = self.camera.get_forward()
        right = self.camera.get_right()
        up = self.camera.get_up()
        
        fov_rad = np.radians(self.camera.fov)
        aspect = width / height if height > 0 else 1.0
        fov_factor = np.tan(fov_rad / 2.0)
        
        ray_dir = forward + right * (nx * fov_factor * aspect) + up * (ny * fov_factor)
        ray_dir = ray_dir.normalize()
        
        # Intersect with floor (Y=0)
        if abs(ray_dir.y) > 1e-6:
            t = -self.camera.position.y / ray_dir.y
            if t > 0:
                point = self.camera.position + ray_dir * t
                if self.grid_snap:
                    point = Vector3(
                        round(point.x / self.grid_size) * self.grid_size,
                        round(point.y / self.grid_size) * self.grid_size,
                        round(point.z / self.grid_size) * self.grid_size
                    )
                self.previous_cursor_3d = point
                return point
        
        return self.previous_cursor_3d
    
    def mousePressEvent(self, event):
        """Handle mouse press"""
        self.last_mouse_pos = event.position().toPoint()
        ctrl_pressed = event.modifiers() & Qt.ControlModifier
        
        if event.button() == Qt.LeftButton:
            if self.tool_mode == ToolMode.DRAW:
                # Drawing works on both new and loaded models - adds to edit geometry layer
                pos = self.cursor_3d
                if self.draw_start_point is None:
                    self.draw_start_point = pos
                    self.inference_point = pos
                else:
                    # Create edge in edit geometry layer (doesn't affect original mesh)
                    if (self.draw_start_point - pos).length() > 1e-6:
                        edge = Edge(start=self.draw_start_point, end=pos, id=self.next_id)
                        self.next_id += 1
                        self._edit_edges.append(edge)  # Add to edit layer, not original
                        
                        # Try to detect closed loops and create faces in edit geometry
                        self._detect_edit_faces()  # Only detects faces in edit geometry
                        self._geometry_dirty = True  # Mark that edit geometry changed
                        self.update()
                    self.draw_start_point = pos
            elif self.tool_mode == ToolMode.SELECT:
                # Handle selection
                self._handle_selection(self.last_mouse_pos, ctrl_pressed)
                self.update()
            elif self.tool_mode == ToolMode.ORBIT:
                self.is_rotating = True
            elif self.tool_mode == ToolMode.PAN:
                self.is_panning = True
        elif event.button() == Qt.MiddleButton:
            self.is_rotating = True
        
        self.update()
    
    def mouseMoveEvent(self, event):
        """Handle mouse move"""
        current_pos = event.position().toPoint()
        dx = current_pos.x() - self.last_mouse_pos.x()
        dy = current_pos.y() - self.last_mouse_pos.y()
        
        # Update 3D cursor
        world_pos = self._screen_to_world(current_pos.x(), current_pos.y())
        if world_pos:
            self.cursor_3d = world_pos
            self.previous_cursor_3d = world_pos
        
        # Update hovered elements for selection (throttle updates for performance)
        if self.tool_mode == ToolMode.SELECT:
            # Always update hover state - it's lightweight
            self._update_hovered_elements(current_pos)
            # Force repaint to show hover highlights
            self.update()
        
        if self.is_rotating:
            self.camera.yaw -= dx * 0.5
            self.camera.pitch -= dy * 0.5
            self.camera.pitch = max(-89.0, min(89.0, self.camera.pitch))
            self.update()
        elif self.is_panning:
            pan_speed = 0.01 * self._get_speed_multiplier()
            right = self.camera.get_right()
            up = self.camera.get_up()
            self.camera.position = self.camera.position + right * (dx * pan_speed)
            self.camera.position = self.camera.position + up * (-dy * pan_speed)
            self.camera.position = self._clamp_camera_position_outside_model(self.camera.position)
            self.update()
        else:
            # Update cursor display even when not rotating/panning
            self.update()
        
        self.last_mouse_pos = current_pos
    
    def mouseReleaseEvent(self, event):
        """Handle mouse release"""
        self.is_rotating = False
        self.is_panning = False
        self.update()
    
    def wheelEvent(self, event):
        """Handle mouse wheel for zooming"""
        delta = event.angleDelta().y()
        zoom_factor = delta * 0.01 * self._get_speed_multiplier()
        forward = self.camera.get_forward()
        self.camera.position = self.camera.position + forward * zoom_factor
        self.camera.position = self._clamp_camera_position_outside_model(self.camera.position)
        self.update()
    
    def keyPressEvent(self, event):
        """Handle key presses"""
        key = event.key()
        if key in self.keys:
            self.keys[key] = True
        elif key == Qt.Key_Escape and self.tool_mode == ToolMode.DRAW:
            self.draw_start_point = None
            self.inference_point = None
            self.update()
        else:
            ModelPreviewGLWidget.keyPressEvent(self, event)
    
    def keyReleaseEvent(self, event):
        """Handle key releases"""
        key = event.key()
        if key in self.keys:
            self.keys[key] = False
        else:
            ModelPreviewGLWidget.keyReleaseEvent(self, event)
    
    def paintEvent(self, event):
        """Override paintEvent to draw coordinate display overlay"""
        super().paintEvent(event)
        
        # Draw coordinate display in top left corner
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        
        # Set font
        font = QFont("Consolas", 10)
        painter.setFont(font)
        
        # Background rectangle
        painter.setPen(QPen(QColor(0, 0, 0, 180), 1))
        painter.setBrush(QColor(0, 0, 0, 180))
        coord_text = f"X: {self.cursor_3d.x:.2f}  Y: {self.cursor_3d.y:.2f}  Z: {self.cursor_3d.z:.2f}"
        text_rect = painter.fontMetrics().boundingRect(coord_text)
        margin = 5
        bg_rect = text_rect.adjusted(-margin, -margin, margin, margin)
        bg_rect.moveTopLeft(QPoint(10, 10))
        painter.drawRoundedRect(bg_rect, 3, 3)
        
        # Text
        painter.setPen(QPen(QColor(255, 255, 255), 1))
        painter.drawText(QPoint(15, 25), coord_text)
        
        painter.end()
    
    def _get_mouse_ray(self, x, y):
        """Get ray from camera through mouse position"""
        width = self.width()
        height = self.height()
        
        if width == 0 or height == 0:
            return None, None
        
        # Normalize to [-1, 1] range
        nx = (2.0 * x) / width - 1.0
        ny = 1.0 - (2.0 * y) / height  # Flip Y
        
        # Calculate ray direction in world space
        forward = self.camera.get_forward()
        right = self.camera.get_right()
        up = self.camera.get_up()
        
        # FOV calculation
        fov_rad = np.radians(self.camera.fov)
        fov_factor = np.tan(fov_rad / 2.0)
        aspect = width / height if height > 0 else 1.0
        
        # Calculate ray direction
        ray_dir = forward + right * (nx * fov_factor * aspect) + up * (ny * fov_factor)
        ray_dir = ray_dir.normalize()
        
        return self.camera.position, ray_dir
    
    def _ray_intersect_vertex(self, ray_origin, ray_dir, vertex, threshold=0.05):
        """Check if ray intersects a vertex"""
        # Calculate distance from ray to vertex
        to_vertex = vertex - ray_origin
        proj_length = to_vertex.x * ray_dir.x + to_vertex.y * ray_dir.y + to_vertex.z * ray_dir.z
        
        if proj_length < 0:
            return None
        
        closest_point = ray_origin + ray_dir * proj_length
        distance = (closest_point - vertex).length()
        
        if distance < threshold:
            return proj_length
        return None
    
    def _ray_intersect_edge(self, ray_origin, ray_dir, edge, threshold=0.05):
        """Check if ray intersects an edge - CORRECTED geometric intersection"""
        # Line segment from edge.start to edge.end
        edge_vec = edge.end - edge.start
        edge_length = edge_vec.length()
        
        if edge_length < 1e-6:
            return None
        
        # Calculate the closest points between the ray and edge line
        # Vector from edge start to ray origin
        w = edge.start - ray_origin
        
        # Calculate dot products
        a = ray_dir.dot(ray_dir)  # Should be 1.0 if normalized, but check anyway
        b = ray_dir.dot(edge_vec)
        c = edge_vec.dot(edge_vec)
        d = ray_dir.dot(w)
        e = edge_vec.dot(w)
        
        denom = a * c - b * b
        
        # Check if ray and edge are parallel
        if abs(denom) < 1e-6:
            # Parallel case - find distance from ray to edge line
            # Project w onto edge direction
            proj = e / edge_length if edge_length > 0 else 0
            proj = max(0.0, min(edge_length, proj))
            closest_on_edge = edge.start + (edge_vec / edge_length) * proj
            
            # Distance from ray to closest point on edge
            to_closest = closest_on_edge - ray_origin
            proj_on_ray = ray_dir.dot(to_closest)
            
            if proj_on_ray < 0:
                return None
            
            closest_on_ray = ray_origin + ray_dir * proj_on_ray
            distance = (closest_on_ray - closest_on_edge).length()
            
            if distance < threshold:
                return proj_on_ray
            return None
        
        # Non-parallel case - find closest approach
        s = (b * e - c * d) / denom
        t = (a * e - b * d) / denom
        
        # Clamp t to edge bounds [0, edge_length]
        t = max(0.0, min(edge_length, t))
        
        # Closest point on edge
        closest_on_edge = edge.start + (edge_vec / edge_length) * t
        
        # Closest point on ray
        if s < 0:
            return None  # Behind ray origin
        
        closest_on_ray = ray_origin + ray_dir * s
        
        # Distance between closest points
        distance = (closest_on_ray - closest_on_edge).length()
        
        if distance < threshold:
            return s  # Return distance along ray
        return None
    
    def _ray_intersect_face(self, ray_origin, ray_dir, face, threshold=0.1):
        """Check if ray intersects a face (triangle)"""
        if len(face.vertices) < 3:
            return None
        
        # Triangulate face and test each triangle
        min_t = None
        
        for i in range(1, len(face.vertices) - 1):
            v0 = face.vertices[0]
            v1 = face.vertices[i]
            v2 = face.vertices[i + 1]
            
            # Möller-Trumbore intersection algorithm
            edge1 = v1 - v0
            edge2 = v2 - v0
            h = Vector3(
                ray_dir.y * edge2.z - ray_dir.z * edge2.y,
                ray_dir.z * edge2.x - ray_dir.x * edge2.z,
                ray_dir.x * edge2.y - ray_dir.y * edge2.x
            )
            
            a = edge1.x * h.x + edge1.y * h.y + edge1.z * h.z
            if abs(a) < 1e-6:
                continue
            
            f = 1.0 / a
            s = ray_origin - v0
            u = f * (s.x * h.x + s.y * h.y + s.z * h.z)
            
            if u < 0.0 or u > 1.0:
                continue
            
            q = Vector3(
                s.y * edge1.z - s.z * edge1.y,
                s.z * edge1.x - s.x * edge1.z,
                s.x * edge1.y - s.y * edge1.x
            )
            v = f * (ray_dir.x * q.x + ray_dir.y * q.y + ray_dir.z * q.z)
            
            if v < 0.0 or u + v > 1.0:
                continue
            
            t = f * (edge2.x * q.x + edge2.y * q.y + edge2.z * q.z)
            
            if t > 0:
                if min_t is None or t < min_t:
                    min_t = t
        
        return min_t
    
    def _update_hovered_elements(self, screen_pos):
        """Update hovered elements based on mouse position"""
        self.hovered_edge = None
        self.hovered_face = None
        self.hovered_vertex = None
        
        if self.tool_mode != ToolMode.SELECT:
            return
        
        ray_origin, ray_dir = self._get_mouse_ray(screen_pos.x(), screen_pos.y())
        if ray_origin is None or ray_dir is None:
            return
        
        # Calculate selection radius based on model size and camera distance
        selection_radius = 0.1  # Default fallback
        
        # Try multiple methods to get model size
        if self.model_size is not None and len(self.model_size) > 0:
            max_dim = float(np.max(self.model_size))
            if max_dim > 0:
                # Scale selection radius based on model size
                selection_radius = max(0.05, min(2.0, max_dim / 100.0))
        elif self.vertices is not None and len(self.vertices) > 0:
            # Fallback: calculate from vertex bounds
            min_vals = np.min(self.vertices, axis=0)
            max_vals = np.max(self.vertices, axis=0)
            size = max_vals - min_vals
            max_dim = float(np.max(size))
            if max_dim > 0:
                selection_radius = max(0.05, min(2.0, max_dim / 100.0))
        
        # Also scale by camera distance for better selection at different zoom levels
        if hasattr(self, 'camera') and self.camera:
            # Approximate distance from camera to model center
            if self.model_center is not None:
                to_center = self.camera.position - Vector3(self.model_center[0], self.model_center[1], self.model_center[2])
                camera_distance = to_center.length()
                if camera_distance > 0:
                    # Scale selection radius by distance (closer = smaller radius, further = larger)
                    selection_radius *= max(0.5, min(2.0, camera_distance / 100.0))
        
        # Find closest vertex (from original mesh)
        closest_vertex_dist = None
        closest_vertex_idx = None
        
        if self.vertices is not None and len(self.vertices) > 0:
            for i, vertex in enumerate(self.vertices):
                v = Vector3(vertex[0], vertex[1], vertex[2])
                t = self._ray_intersect_vertex(ray_origin, ray_dir, v, selection_radius)
                if t is not None:
                    if closest_vertex_dist is None or t < closest_vertex_dist:
                        closest_vertex_dist = t
                        closest_vertex_idx = i
        
        # Find closest edge (check both original and edit edges)
        closest_edge_dist = None
        closest_edge = None
        
        # Check original mesh edges
        if self.edges and len(self.edges) > 0:
            for edge in self.edges:
                t = self._ray_intersect_edge(ray_origin, ray_dir, edge, selection_radius)
                if t is not None:
                    if closest_edge_dist is None or t < closest_edge_dist:
                        closest_edge_dist = t
                        closest_edge = edge
        
        # Check edit geometry edges
        if self._edit_edges and len(self._edit_edges) > 0:
            for edge in self._edit_edges:
                t = self._ray_intersect_edge(ray_origin, ray_dir, edge, selection_radius)
                if t is not None:
                    if closest_edge_dist is None or t < closest_edge_dist:
                        closest_edge_dist = t
                        closest_edge = edge
        
        # Find closest face (if faces exist)
        closest_face_dist = None
        closest_face = None
        
        # Check original mesh faces (if any detected)
        if self.faces and len(self.faces) > 0:
            for face in self.faces:
                t = self._ray_intersect_face(ray_origin, ray_dir, face, selection_radius * 2)
                if t is not None:
                    if closest_face_dist is None or t < closest_face_dist:
                        closest_face_dist = t
                        closest_face = face
        
        # Check edit geometry faces
        if self._edit_faces and len(self._edit_faces) > 0:
            for face in self._edit_faces:
                t = self._ray_intersect_face(ray_origin, ray_dir, face, selection_radius * 2)
                if t is not None:
                    if closest_face_dist is None or t < closest_face_dist:
                        closest_face_dist = t
                        closest_face = face
        
        # Determine what to highlight (prioritize vertices > edges > faces)
        # Only compare if we have valid distances
        if closest_vertex_dist is not None:
            # Vertex found - check if it's closest
            if closest_edge_dist is None and closest_face_dist is None:
                self.hovered_vertex = closest_vertex_idx
                self.hovered_edge = None
                self.hovered_face = None
            elif closest_edge_dist is not None and closest_vertex_dist < closest_edge_dist:
                if closest_face_dist is None or closest_vertex_dist < closest_face_dist:
                    self.hovered_vertex = closest_vertex_idx
                    self.hovered_edge = None
                    self.hovered_face = None
                else:
                    self.hovered_face = closest_face
                    self.hovered_vertex = None
                    self.hovered_edge = None
            elif closest_face_dist is not None and closest_vertex_dist < closest_face_dist:
                self.hovered_vertex = closest_vertex_idx
                self.hovered_edge = None
                self.hovered_face = None
            else:
                # Edge or face is closer
                if closest_edge_dist is not None:
                    if closest_face_dist is None or closest_edge_dist < closest_face_dist:
                        self.hovered_edge = closest_edge
                        self.hovered_vertex = None
                        self.hovered_face = None
                    else:
                        self.hovered_face = closest_face
                        self.hovered_vertex = None
                        self.hovered_edge = None
                elif closest_face_dist is not None:
                    self.hovered_face = closest_face
                    self.hovered_vertex = None
                    self.hovered_edge = None
        elif closest_edge_dist is not None:
            # Edge found
            if closest_face_dist is None or closest_edge_dist < closest_face_dist:
                self.hovered_edge = closest_edge
                self.hovered_vertex = None
                self.hovered_face = None
            else:
                self.hovered_face = closest_face
                self.hovered_vertex = None
                self.hovered_edge = None
        elif closest_face_dist is not None:
            # Only face found
            self.hovered_face = closest_face
            self.hovered_vertex = None
            self.hovered_edge = None
        else:
            # Nothing found
            self.hovered_vertex = None
            self.hovered_edge = None
            self.hovered_face = None
    
    def _handle_selection(self, screen_pos, ctrl_pressed=False):
        """Handle selection based on click position"""
        if self.tool_mode != ToolMode.SELECT:
            return
        
        ray_origin, ray_dir = self._get_mouse_ray(screen_pos.x(), screen_pos.y())
        if ray_origin is None or ray_dir is None:
            return
        
        # Use hovered elements for selection
        if not ctrl_pressed:
            # Clear selection if not Ctrl-clicking
            self.selected_edges.clear()
            self.selected_faces.clear()
            self.selected_vertices.clear()
        
        # Select based on hovered elements
        if self.hovered_vertex is not None:
            if ctrl_pressed and self.hovered_vertex in self.selected_vertices:
                self.selected_vertices.remove(self.hovered_vertex)
            else:
                self.selected_vertices.add(self.hovered_vertex)
        elif self.hovered_edge is not None:
            if ctrl_pressed and self.hovered_edge in self.selected_edges:
                self.selected_edges.remove(self.hovered_edge)
            else:
                self.selected_edges.add(self.hovered_edge)
        elif self.hovered_face is not None:
            if ctrl_pressed and self.hovered_face in self.selected_faces:
                self.selected_faces.remove(self.hovered_face)
            else:
                self.selected_faces.add(self.hovered_face)
    
    def _draw_selection_highlights(self):
        """Draw highlights for selected and hovered elements"""
        if self.tool_mode != ToolMode.SELECT:
            return
        
        # Get selection colors from settings (with fallback to defaults)
        if hasattr(self, 'app') and self.app and hasattr(self.app, 'settings'):
            settings = self.app.settings
            # Face selection color
            face_color_str = settings.get("Model_Selection_Face_Color", "#00ffff")  # Cyan default
            face_color = QColor(face_color_str)
            selected_face_color = (face_color.redF(), face_color.greenF(), face_color.blueF())
            # Edge selection color
            edge_color_str = settings.get("Model_Selection_Edge_Color", "#00ffff")  # Cyan default
            edge_color = QColor(edge_color_str)
            selected_edge_color = (edge_color.redF(), edge_color.greenF(), edge_color.blueF())
        else:
            selected_face_color = (0.0, 1.0, 1.0)  # Cyan
            selected_edge_color = (0.0, 1.0, 1.0)  # Cyan
        
        hover_color = (1.0, 1.0, 0.0)  # Yellow for hovered
        
        glDisable(GL_LIGHTING)
        glEnable(GL_DEPTH_TEST)  # Keep depth test for proper visibility
        glDepthFunc(GL_LEQUAL)  # Draw highlights on top
        glLineWidth(3.0)
        glPointSize(8.0)
        
        # Draw selected edges
        if self.selected_edges:
            glColor3f(*selected_edge_color)
            glBegin(GL_LINES)
            for edge in self.selected_edges:
                glVertex3f(edge.start.x, edge.start.y, edge.start.z)
                glVertex3f(edge.end.x, edge.end.y, edge.end.z)
            glEnd()
        
        # Draw hovered edge
        if self.hovered_edge and self.hovered_edge not in self.selected_edges:
            glColor3f(*hover_color)
            glBegin(GL_LINES)
            glVertex3f(self.hovered_edge.start.x, self.hovered_edge.start.y, self.hovered_edge.start.z)
            glVertex3f(self.hovered_edge.end.x, self.hovered_edge.end.y, self.hovered_edge.end.z)
            glEnd()
        
        # Draw selected vertices
        if self.selected_vertices and self.vertices is not None:
            glColor3f(*selected_edge_color)
            glPointSize(8.0)
            glBegin(GL_POINTS)
            for idx in self.selected_vertices:
                if idx < len(self.vertices):
                    v = self.vertices[idx]
                    glVertex3f(v[0], v[1], v[2])
            glEnd()
        
        # Draw hovered vertex
        if self.hovered_vertex is not None and self.hovered_vertex not in self.selected_vertices and self.vertices is not None:
            if self.hovered_vertex < len(self.vertices):
                glColor3f(*hover_color)
                glPointSize(8.0)
                glBegin(GL_POINTS)
                v = self.vertices[self.hovered_vertex]
                glVertex3f(v[0], v[1], v[2])
                glEnd()
        
        # Draw selected faces (outline)
        if self.selected_faces:
            glColor3f(*selected_face_color)
            glLineWidth(2.0)
            for face in self.selected_faces:
                if len(face.vertices) >= 3:
                    glBegin(GL_LINE_LOOP)
                    for v in face.vertices:
                        glVertex3f(v.x, v.y, v.z)
                    glEnd()
        
        # Draw hovered face (outline)
        if self.hovered_face and self.hovered_face not in self.selected_faces:
            glColor3f(*hover_color)
            glLineWidth(2.0)
            if len(self.hovered_face.vertices) >= 3:
                glBegin(GL_LINE_LOOP)
                for v in self.hovered_face.vertices:
                    glVertex3f(v.x, v.y, v.z)
                glEnd()
        
        glDepthFunc(GL_LESS)  # Restore default depth func
        glEnable(GL_LIGHTING)
        glLineWidth(1.0)
        glPointSize(1.0)
    
    def mousePressEvent(self, event):
        """Override mouse press event to handle transforms in edit mode"""
        self.last_mouse_pos = event.position().toPoint()
        
        if event.button() == Qt.LeftButton:
            # Check if we're in a transform mode with selection
            if (self.tool_mode in [ToolMode.MOVE, ToolMode.ROTATE, ToolMode.SCALE] and 
                (self.selected_vertices or self.selected_edges or self.selected_faces)):
                # Start transform operation
                self._start_transform(event.position().toPoint())
            elif self.tool_mode == ToolMode.SELECT:
                # Perform selection
                ctrl_pressed = (event.modifiers() & Qt.ControlModifier) != 0
                self._handle_selection(event.position().toPoint(), ctrl_pressed)
                
                # Update selection info in parent window
                if hasattr(self, 'parent') and self.parent():
                    parent_window = self.parent()
                    while parent_window and not isinstance(parent_window, ModelPreviewWindow):
                        parent_window = parent_window.parent()
                    if parent_window and hasattr(parent_window, '_update_selection_info'):
                        parent_window._update_selection_info()
                
                self.update()
            else:
                # Drawing or other tool modes
                self._handle_tool_click(event.position().toPoint())
        elif event.button() == Qt.MiddleButton:
            self.is_rotating = True
        elif event.button() == Qt.RightButton:
            self.is_panning = True
    
    def mouseMoveEvent(self, event):
        """Override mouse move event to handle transforms"""
        pos = event.position().toPoint()
        dx = pos.x() - self.last_mouse_pos.x()
        dy = pos.y() - self.last_mouse_pos.y()
        
        # Handle transform operations
        if self.is_transforming:
            self._update_transform(event.position().toPoint())
        elif self.is_rotating:
            # Camera rotation
            super().mouseMoveEvent(event)
        elif self.is_panning:
            # Camera panning
            super().mouseMoveEvent(event)
        else:
            # Update hover states for selection
            if self.tool_mode == ToolMode.SELECT:
                self._update_hovered_elements(event.position().toPoint())
                self.update()
            else:
                # Update for drawing tools
                super().mouseMoveEvent(event)
        
        self.last_mouse_pos = pos
    
    def mouseReleaseEvent(self, event):
        """Override mouse release event to finish transforms"""
        if self.is_transforming:
            self._finish_transform()
            self.is_transforming = False
        else:
            super().mouseReleaseEvent(event)
    
    def _start_transform(self, mouse_pos):
        """Start a transform operation"""
        if not (self.selected_vertices or self.selected_edges or self.selected_faces):
            return
        
        # Push undo state before transform
        self.push_undo()
        
        self.is_transforming = True
        self.transform_start_mouse = mouse_pos
        
        # Calculate transform center (average of selected vertices)
        selected_vertex_indices = set()
        
        # Collect vertex indices from selection
        if self.selected_vertices:
            selected_vertex_indices.update(self.selected_vertices)
        
        if self.selected_edges:
            for edge in self.selected_edges:
                # For edges, we need to find their vertex indices
                # Since edges store Vector3 positions, we need to match them to vertex indices
                for i, vertex in enumerate(self.vertices):
                    v = Vector3(vertex[0], vertex[1], vertex[2])
                    if (v - edge.start).length() < 0.001:
                        selected_vertex_indices.add(i)
                    if (v - edge.end).length() < 0.001:
                        selected_vertex_indices.add(i)
        
        if self.selected_faces:
            for face in self.selected_faces:
                # For faces, match vertices to indices
                for face_vertex in face.vertices:
                    for i, vertex in enumerate(self.vertices):
                        v = Vector3(vertex[0], vertex[1], vertex[2])
                        if (v - face_vertex).length() < 0.001:
                            selected_vertex_indices.add(i)
        
        # Calculate center of selected vertices
        if selected_vertex_indices and self.vertices is not None:
            selected_positions = [self.vertices[i] for i in selected_vertex_indices if i < len(self.vertices)]
            if selected_positions:
                center_array = np.mean(selected_positions, axis=0)
                self.transform_center = Vector3(center_array[0], center_array[1], center_array[2])
            else:
                self.transform_center = Vector3(0, 0, 0)
        else:
            self.transform_center = Vector3(0, 0, 0)
        
        # Store initial positions
        self.transform_initial_positions = {}
        for idx in selected_vertex_indices:
            if idx < len(self.vertices):
                self.transform_initial_positions[idx] = np.array([self.vertices[idx][0], self.vertices[idx][1], self.vertices[idx][2]])
        
        self.selected_vertex_indices_for_transform = selected_vertex_indices
    
    def _update_transform(self, mouse_pos):
        """Update transform based on mouse movement"""
        if not hasattr(self, 'selected_vertex_indices_for_transform') or not self.selected_vertex_indices_for_transform:
            return
        
        dx = mouse_pos.x() - self.transform_start_mouse.x()
        dy = mouse_pos.y() - self.transform_start_mouse.y()
        
        # Get camera vectors for screen-space to world-space conversion
        forward = self.camera.get_forward()
        right = self.camera.get_right()
        up = self.camera.get_up()
        
        # Calculate distance from camera to transform center for scaling
        camera_to_center = self.transform_center - self.camera.position
        camera_distance = camera_to_center.length()
        if camera_distance < 0.001:
            camera_distance = 1.0
        
        # Convert screen-space movement to world-space
        # Scale by camera distance to make movement consistent at different zoom levels
        world_scale = max(0.001, camera_distance) * 0.001
        
        if self.tool_mode == ToolMode.MOVE:
            # Move: translate selected vertices
            move_x = right * (dx * world_scale)
            move_y = up * (-dy * world_scale)  # Invert Y for screen-to-world conversion
            
            # Apply axis constraint if active
            if self.transform_constraint_axis == 'X':
                move_x = Vector3(move_x.x, 0, 0)
                move_y = Vector3(0, 0, 0)
            elif self.transform_constraint_axis == 'Y':
                move_x = Vector3(0, 0, 0)
                move_y = Vector3(0, move_y.y, 0)
            elif self.transform_constraint_axis == 'Z':
                move_x = Vector3(0, 0, move_x.z)
                move_y = Vector3(0, 0, move_y.z)
            
            translation = move_x + move_y
            
            # Apply translation to selected vertices
            for idx in self.selected_vertex_indices_for_transform:
                if idx in self.transform_initial_positions and idx < len(self.vertices):
                    initial_pos = self.transform_initial_positions[idx]
                    new_pos = Vector3(
                        initial_pos[0] + translation.x,
                        initial_pos[1] + translation.y,
                        initial_pos[2] + translation.z
                    )
                    # Apply grid snap if enabled
                    if self.transform_snap_grid:
                        grid = self.grid_size
                        new_pos.x = round(new_pos.x / grid) * grid
                        new_pos.y = round(new_pos.y / grid) * grid
                        new_pos.z = round(new_pos.z / grid) * grid
                    
                    self.vertices[idx] = np.array([new_pos.x, new_pos.y, new_pos.z])
        
        elif self.tool_mode == ToolMode.ROTATE:
            # Rotate: rotate selected vertices around transform center
            # Accumulate rotation from initial positions
            # Use total mouse delta for rotation amount
            total_dx = mouse_pos.x() - self.transform_start_mouse.x()
            total_dy = mouse_pos.y() - self.transform_start_mouse.y()
            angle_x = total_dy * 0.01  # Pitch rotation (accumulated)
            angle_y = total_dx * 0.01  # Yaw rotation (accumulated)
            
            # Create rotation matrices
            cos_x, sin_x = math.cos(angle_x), math.sin(angle_x)
            cos_y, sin_y = math.cos(angle_y), math.sin(angle_y)
            
            # Apply axis constraint
            if self.transform_constraint_axis == 'X':
                # Rotate around X axis only
                for idx in self.selected_vertex_indices_for_transform:
                    if idx in self.transform_initial_positions and idx < len(self.vertices):
                        initial_pos = self.transform_initial_positions[idx]
                        pos = Vector3(initial_pos[0], initial_pos[1], initial_pos[2])
                        pos_relative = pos - self.transform_center
                        
                        # Rotate around X axis
                        new_y = pos_relative.y * cos_x - pos_relative.z * sin_x
                        new_z = pos_relative.y * sin_x + pos_relative.z * cos_x
                        
                        new_pos = self.transform_center + Vector3(pos_relative.x, new_y, new_z)
                        self.vertices[idx] = np.array([new_pos.x, new_pos.y, new_pos.z])
            elif self.transform_constraint_axis == 'Y':
                # Rotate around Y axis only
                for idx in self.selected_vertex_indices_for_transform:
                    if idx in self.transform_initial_positions and idx < len(self.vertices):
                        initial_pos = self.transform_initial_positions[idx]
                        pos = Vector3(initial_pos[0], initial_pos[1], initial_pos[2])
                        pos_relative = pos - self.transform_center
                        
                        # Rotate around Y axis
                        new_x = pos_relative.x * cos_y + pos_relative.z * sin_y
                        new_z = -pos_relative.x * sin_y + pos_relative.z * cos_y
                        
                        new_pos = self.transform_center + Vector3(new_x, pos_relative.y, new_z)
                        self.vertices[idx] = np.array([new_pos.x, new_pos.y, new_pos.z])
            elif self.transform_constraint_axis == 'Z':
                # Rotate around Z axis only
                for idx in self.selected_vertex_indices_for_transform:
                    if idx in self.transform_initial_positions and idx < len(self.vertices):
                        initial_pos = self.transform_initial_positions[idx]
                        pos = Vector3(initial_pos[0], initial_pos[1], initial_pos[2])
                        pos_relative = pos - self.transform_center
                        
                        # Rotate around Z axis
                        new_x = pos_relative.x * cos_y - pos_relative.y * sin_y
                        new_y = pos_relative.x * sin_y + pos_relative.y * cos_y
                        
                        new_pos = self.transform_center + Vector3(new_x, new_y, pos_relative.z)
                        self.vertices[idx] = np.array([new_pos.x, new_pos.y, new_pos.z])
            else:
                # Free rotation (combine X and Y)
                for idx in self.selected_vertex_indices_for_transform:
                    if idx in self.transform_initial_positions and idx < len(self.vertices):
                        initial_pos = self.transform_initial_positions[idx]
                        pos = Vector3(initial_pos[0], initial_pos[1], initial_pos[2])
                        pos_relative = pos - self.transform_center
                        
                        # Apply Y rotation first (around Y axis)
                        new_x = pos_relative.x * cos_y + pos_relative.z * sin_y
                        new_z = -pos_relative.x * sin_y + pos_relative.z * cos_y
                        temp_pos = Vector3(new_x, pos_relative.y, new_z)
                        
                        # Then apply X rotation (around X axis)
                        new_y = temp_pos.y * cos_x - temp_pos.z * sin_x
                        new_z = temp_pos.y * sin_x + temp_pos.z * cos_x
                        
                        new_pos = self.transform_center + Vector3(temp_pos.x, new_y, new_z)
                        self.vertices[idx] = np.array([new_pos.x, new_pos.y, new_pos.z])
        
        elif self.tool_mode == ToolMode.SCALE:
            # Scale: scale selected vertices from transform center
            # Accumulate scale from initial positions
            total_dx = mouse_pos.x() - self.transform_start_mouse.x()
            total_dy = mouse_pos.y() - self.transform_start_mouse.y()
            scale_factor = 1.0 + (total_dx + total_dy) * 0.01
            scale_factor = max(0.01, scale_factor)  # Prevent negative/zero scale
            
            # Apply scale to selected vertices
            for idx in self.selected_vertex_indices_for_transform:
                if idx in self.transform_initial_positions and idx < len(self.vertices):
                    initial_pos = self.transform_initial_positions[idx]
                    pos = Vector3(initial_pos[0], initial_pos[1], initial_pos[2])
                    pos_relative = pos - self.transform_center
                    
                    # Apply scale
                    if self.transform_constraint_axis == 'X':
                        pos_relative.x *= scale_factor
                    elif self.transform_constraint_axis == 'Y':
                        pos_relative.y *= scale_factor
                    elif self.transform_constraint_axis == 'Z':
                        pos_relative.z *= scale_factor
                    else:
                        # Uniform scale
                        pos_relative = pos_relative * scale_factor
                    
                    new_pos = self.transform_center + pos_relative
                    self.vertices[idx] = np.array([new_pos.x, new_pos.y, new_pos.z])
        
        # Update normals and edges after transform
        if self.indices is not None:
            self.normals = self._calculate_normals()
        
        # Update edges if they exist
        if self.selected_edges and self.edges:
            for edge in self.selected_edges:
                # Find and update edge vertices
                for i, vertex in enumerate(self.vertices):
                    v = Vector3(vertex[0], vertex[1], vertex[2])
                    if (v - edge.start).length() < 0.001:
                        edge.start = v
                    if (v - edge.end).length() < 0.001:
                        edge.end = v
        
        self.update()
    
    def _finish_transform(self):
        """Finish transform operation and update geometry"""
        # Recalculate bounds
        if self.vertices is not None and len(self.vertices) > 0:
            self.model_min = np.min(self.vertices, axis=0)
            self.model_max = np.max(self.vertices, axis=0)
            self.model_size = self.model_max - self.model_min
            self.model_center = (self.model_min + self.model_max) / 2.0
        
        # Recalculate normals
        if self.indices is not None:
            self.normals = self._calculate_normals()
        
        # Clear transform state
        self.transform_initial_positions.clear()
        if hasattr(self, 'selected_vertex_indices_for_transform'):
            delattr(self, 'selected_vertex_indices_for_transform')
        
        # Update selection info in parent window
        if hasattr(self, 'parent') and self.parent():
            parent_window = self.parent()
            while parent_window and not isinstance(parent_window, ModelPreviewWindow):
                parent_window = parent_window.parent()
            if parent_window and hasattr(parent_window, '_update_selection_info'):
                parent_window._update_selection_info()
        
        self.update()
    
    def _handle_tool_click(self, mouse_pos):
        """Handle tool-specific click actions (drawing, etc)"""
        if self.tool_mode == ToolMode.DRAW:
            # Start drawing operation (placeholder)
            self.draw_start_point = self.cursor_3d
            self.update()


class StandaloneModelPreviewWindow(QMainWindow):
    """Standalone Model Preview Window - for running directly"""
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Model Preview")
        central = QWidget()
        self.setCentralWidget(central)
        layout = QVBoxLayout(central)
        layout.setContentsMargins(0, 0, 0, 0)
        self.gl = ModelPreviewGLWidget()
        if self.app:
            self.gl.app = self.app
        layout.addWidget(self.gl)
        self._build_menu()
        self.status = QStatusBar(self)
        self.setStatusBar(self.status)
        self.resize(1024, 720)

    def _build_menu(self):
        menubar = QMenuBar(self)
        self.setMenuBar(menubar)
        file_menu = menubar.addMenu("File")
        open_action = QAction("Open Model...", self)
        open_action.setShortcut(QKeySequence.Open)
        open_action.triggered.connect(self._open_model)
        file_menu.addAction(open_action)
        file_menu.addSeparator()
        exit_action = QAction("Close", self)
        exit_action.setShortcut(QKeySequence.Quit)
        exit_action.triggered.connect(self.close)
        file_menu.addAction(exit_action)

        view_menu = menubar.addMenu("View")
        reset_cam = QAction("Reset Camera", self)
        reset_cam.triggered.connect(self._reset_camera)
        view_menu.addAction(reset_cam)

    def _reset_camera(self):
        self.gl.camera = Camera()
        self.gl.update()

    def _open_model(self):
        filters = "Model Files (*.obj *.glb *.gltf *.dae *.g3d *.Model);;Wavefront OBJ (*.obj);;glTF Binary (*.glb);;glTF JSON (*.gltf);;Collada DAE (*.dae);;LibGDX G3D (*.g3d);;PyGenesis Model (*.Model);;All Files (*.*)"
        path, _ = QFileDialog.getOpenFileName(self, "Open Model", "", filters)
        if not path:
            return
        try:
            ext = path.lower().split('.')[-1]
            if ext == 'obj':
                self.gl.load_obj(path)
            elif ext in ('glb', 'gltf'):
                self.gl.load_gltf(path)
            elif ext == 'dae':
                self.gl.load_dae(path)
            elif ext == 'g3d':
                self.gl.load_g3d(path)
            elif ext == 'model':
                self.gl.load_json_model(path)
            else:
                QMessageBox.warning(self, "Unsupported", f"Unsupported file type: {ext}")
                return
            # Update animation UI after loading
            self._update_animation_combo()
            # Enable Import to JSON Model button after loading
            if hasattr(self, 'manage_textures_btn'):
                self.manage_textures_btn.setEnabled(True)
            self.status.showMessage(f"Loaded: {path}", 4000)
        except Exception as e:
            QMessageBox.critical(self, "Load Error", str(e))


class ModelPreviewWindow(QWidget, EditorInterface):
    """Model Preview Editor - embedded widget (like SoundEditor)"""
    def __init__(self, app=None, resource_data=None, parent=None):
        super().__init__(parent)
        self.app = app
        self.resource_data = resource_data or {}
        self._dirty = False  # Track unsaved changes
        self.edit_mode = False  # Track if we're in edit mode
        self.main_layout = None  # Store main layout for switching
        self.setup_ui()
        # Set app reference on GL widget for texture path resolution
        if hasattr(self, 'gl') and self.gl:
            self.gl.app = self.app
        if resource_data:
            self.open_resource(resource_data)
        # Load persistent settings after UI is set up
        self._load_model_editor_settings()
        
        # Connect to resource_updated signal to reload textures when they're updated
        if self.app and hasattr(self.app, 'resource_manager'):
            self.app.resource_manager.resource_updated.connect(self._on_resource_updated)
    
    def _on_resource_updated(self, resource_type, resource_data):
        """Handle resource updated signal - reload textures if texture resource was updated"""
        if resource_type == "textures":
            # Find the preview widget (could be self.gl or self.preview_panel.gl or similar)
            preview_widget = None
            if hasattr(self, 'gl') and self.gl:
                preview_widget = self.gl
            elif hasattr(self, 'preview_panel') and hasattr(self.preview_panel, 'gl'):
                preview_widget = self.preview_panel.gl
            elif hasattr(self, 'preview_widget'):
                preview_widget = self.preview_widget
            
            if not preview_widget or not hasattr(preview_widget, 'textures'):
                return
            # Check if this texture is used by the current model
            texture_name = resource_data.get("name", "")
            
            # Get the texture's frame file path from the resource data
            frames = resource_data.get("frames", [])
            if not frames:
                return
            
            # Get the PNG filename from the first frame
            texture_filename = None
            for frame in frames:
                if isinstance(frame, dict) and "file" in frame:
                    texture_filename = frame.get("file")
                    break
            
            if not texture_filename:
                return
            
            # Check if this texture filename matches any of the loaded textures
            # The texture dict keys are filenames (like "FitLink00_BodyA.png")
            texture_filename_base = os.path.basename(texture_filename)
            
            # Check all materials for this texture
            needs_reload = False
            for mat_name, mat_data in self.gl.materials.items():
                mat_texture = mat_data.get("texture")
                if mat_texture:
                    # mat_texture could be a full path or just filename
                    mat_texture_base = os.path.basename(mat_texture)
                    if texture_filename_base == mat_texture_base or texture_filename_base in mat_texture:
                        needs_reload = True
                        break
            
            if needs_reload:
                debug(f"Reloading texture {texture_filename_base} in ModelEditor")
                # Find the texture path and reload it
                texture_path = None
                
                # Try to find the texture file in the textures folder
                if self.app and hasattr(self.app, 'project_manager'):
                    project_path = self.app.project_manager.get_project_path()
                    if project_path:
                        # Check in Textures folder
                        texture_path = os.path.join(project_path, "Resources", "Textures", texture_filename_base)
                        if not os.path.exists(texture_path):
                            # Try with parent folder from resource_data
                            parent_folder = resource_data.get("parent_folder", "")
                            if parent_folder:
                                texture_path = os.path.join(project_path, "Resources", "Textures", parent_folder, texture_filename_base)
                        
                        # If still not found, check all texture paths we know about
                        if not os.path.exists(texture_path) and hasattr(preview_widget, 'textures'):
                            for existing_tex_name in preview_widget.textures.keys():
                                if texture_filename_base in existing_tex_name or existing_tex_name in texture_filename_base:
                                    # Found a matching texture, reload it
                                    if os.path.exists(existing_tex_name):
                                        texture_path = existing_tex_name
                                        break
                
                if texture_path and os.path.exists(texture_path):
                    # Reload the texture
                    old_texture_id = None
                    for mat_name, mat_data in preview_widget.materials.items():
                        if mat_data.get("texture") and texture_filename_base in os.path.basename(mat_data.get("texture", "")):
                            # Find the OpenGL texture ID for this material
                            for tex_name, tex_id in preview_widget.textures.items():
                                if texture_filename_base in tex_name:
                                    old_texture_id = tex_id
                                    break
                            
                            # Delete old texture and load new one
                            if old_texture_id:
                                glDeleteTextures([old_texture_id])
                                # Remove from textures dict
                                keys_to_remove = [k for k, v in preview_widget.textures.items() if v == old_texture_id]
                                for k in keys_to_remove:
                                    del preview_widget.textures[k]
                            
                            # Load new texture
                            new_texture_id = preview_widget._load_texture_image(texture_path)
                            if new_texture_id:
                                # Update texture dict - use original key if it exists
                                for original_key in list(preview_widget.textures.keys()):
                                    if texture_filename_base in original_key:
                                        preview_widget.textures[original_key] = new_texture_id
                                        break
                                else:
                                    # Add new entry
                                    preview_widget.textures[texture_filename_base] = new_texture_id
                                
                                # Update material reference
                                mat_data["texture"] = texture_path
                                debug(f"Successfully reloaded texture {texture_filename_base}")
                            
                            # Update the preview
                            preview_widget.update()
                            break

    def setup_ui(self):
        """Setup the UI - matches Sound/Sprite editor layout"""
        self.main_layout = QVBoxLayout(self)
        self.main_layout.setContentsMargins(0, 0, 0, 0)
        self.main_layout.setSpacing(0)
        
        # Menu bar (hidden in preview mode, shown in edit mode)
        self.menu_bar = self.create_menu_bar()
        self.menu_bar.hide()
        self.main_layout.addWidget(self.menu_bar)
        
        # Content area (switches between preview and edit layouts)
        self.content_widget = QWidget()
        self.content_layout = QHBoxLayout(self.content_widget)
        self.content_layout.setContentsMargins(5, 5, 5, 5)
        self.content_widget.setLayout(self.content_layout)
        
        # Create preview mode layout (default)
        self.setup_preview_mode()
        
        self.main_layout.addWidget(self.content_widget, 1)
        
        # Now that gl widget is created, update color button
        self._update_color_button()
        
        # Initialize create/edit button text
        self._update_create_edit_button()
    
    def setup_preview_mode(self):
        """Setup preview mode UI (default)"""
        # Clear content layout
        while self.content_layout.count():
            item = self.content_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
        
        # Create splitter for resizable panels (like SoundEditor)
        splitter = QSplitter(Qt.Horizontal)
        self.content_layout.addWidget(splitter)
        
        # Left panel - Model Properties
        left_panel = self.create_properties_panel()
        splitter.addWidget(left_panel)
        
        # Right panel - 3D Preview
        self.preview_panel = self.create_preview_panel()
        splitter.addWidget(self.preview_panel)
        
        # Set splitter proportions (40% left, 60% right) - same as SoundEditor
        splitter.setSizes([400, 600])
        splitter.setStretchFactor(0, 0)  # Left panel doesn't stretch
        splitter.setStretchFactor(1, 1)  # Right panel stretches to fill space
        splitter.setCollapsible(0, False)  # Prevent left panel from collapsing
        splitter.setCollapsible(1, False)  # Prevent right panel from collapsing
    
    def setup_edit_mode(self):
        """Setup embedded mode with left and right panels"""
        # Clear content layout
        while self.content_layout.count():
            item = self.content_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
        
        # Create main splitter for left/middle/right panels
        main_splitter = QSplitter(Qt.Horizontal)
        self.content_layout.addWidget(main_splitter)
        
        # Left panel - Tools
        left_panel = QFrame()
        left_panel.setFrameStyle(QFrame.StyledPanel)
        left_panel.setMinimumWidth(200)
        left_panel.setMaximumWidth(300)
        left_layout = QVBoxLayout(left_panel)
        left_layout.setContentsMargins(10, 10, 10, 10)
        
        # Tools group
        tools_group = QGroupBox("Tools")
        tools_layout = QVBoxLayout(tools_group)
        
        # Tool buttons (radio button style)
        self.select_tool_btn = QPushButton("Select")
        self.select_tool_btn.setCheckable(True)
        self.select_tool_btn.setChecked(True)
        self.select_tool_btn.clicked.connect(lambda: self._set_tool_mode(ToolMode.SELECT))
        tools_layout.addWidget(self.select_tool_btn)
        
        self.scale_tool_btn = QPushButton("Scale")
        self.scale_tool_btn.setCheckable(True)
        self.scale_tool_btn.clicked.connect(lambda: self._set_tool_mode(ToolMode.SCALE))
        tools_layout.addWidget(self.scale_tool_btn)
        
        self.rotate_tool_btn = QPushButton("Rotate")
        self.rotate_tool_btn.setCheckable(True)
        self.rotate_tool_btn.clicked.connect(lambda: self._set_tool_mode(ToolMode.ROTATE))
        tools_layout.addWidget(self.rotate_tool_btn)
        
        self.draw_tool_btn = QPushButton("Draw")
        self.draw_tool_btn.setCheckable(True)
        self.draw_tool_btn.clicked.connect(lambda: self._set_tool_mode(ToolMode.DRAW))
        tools_layout.addWidget(self.draw_tool_btn)
        
        left_layout.addWidget(tools_group)
        
        # Selection info group
        selection_group = QGroupBox("Selection")
        selection_layout = QVBoxLayout(selection_group)
        
        self.selection_info_label = QLabel("No selection")
        self.selection_info_label.setWordWrap(True)
        selection_layout.addWidget(self.selection_info_label)
        
        left_layout.addWidget(selection_group)
        
        left_layout.addStretch()
        
        main_splitter.addWidget(left_panel)
        
        # Middle panel - 3D Preview (switch to ModelEditGLWidget in edit mode)
        middle_panel = QFrame()
        middle_layout = QVBoxLayout(middle_panel)
        middle_layout.setContentsMargins(0, 0, 0, 0)
        
        # Create or switch to ModelEditGLWidget for editing
        if hasattr(self, 'gl') and self.gl:
            # Store reference to preview widget
            if not isinstance(self.gl, ModelEditGLWidget):
                self.preview_gl = self.gl
                # Create new edit widget
                edit_gl = ModelEditGLWidget()
                if self.app:
                    edit_gl.app = self.app
                # Copy geometry and state from preview widget
                if hasattr(self.preview_gl, 'vertices') and self.preview_gl.vertices is not None:
                    edit_gl.vertices = self.preview_gl.vertices.copy() if hasattr(self.preview_gl.vertices, 'copy') else np.array(self.preview_gl.vertices)
                    edit_gl.indices = self.preview_gl.indices.copy() if hasattr(self.preview_gl.indices, 'copy') else np.array(self.preview_gl.indices)
                    edit_gl.normals = self.preview_gl.normals.copy() if hasattr(self.preview_gl.normals, 'copy') and self.preview_gl.normals is not None else None
                    edit_gl.tex_coords = self.preview_gl.tex_coords.copy() if hasattr(self.preview_gl.tex_coords, 'copy') and self.preview_gl.tex_coords is not None else None
                    edit_gl.textures = self.preview_gl.textures.copy()
                    edit_gl.materials = self.preview_gl.materials.copy()
                    edit_gl.model_dir = self.preview_gl.model_dir
                    edit_gl.camera = self.preview_gl.camera
                    # Store original for undo/redo
                    edit_gl._original_vertices = edit_gl.vertices.copy()
                    edit_gl._original_indices = edit_gl.indices.copy()
                    edit_gl._original_normals = edit_gl.normals.copy() if edit_gl.normals is not None else None
                    edit_gl._original_tex_coords = edit_gl.tex_coords.copy() if edit_gl.tex_coords is not None else None
                self.gl = edit_gl
            middle_layout.addWidget(self.gl, 1)
        else:
            # Create new edit widget if no preview widget exists
            self.gl = ModelEditGLWidget()
            if self.app:
                self.gl.app = self.app
            middle_layout.addWidget(self.gl, 1)
        
        main_splitter.addWidget(middle_panel)
        
        # Right panel (blank for now)
        right_panel = QFrame()
        right_panel.setFrameStyle(QFrame.StyledPanel)
        right_panel.setMinimumWidth(200)
        right_panel.setMaximumWidth(300)
        main_splitter.addWidget(right_panel)
        
        # Set splitter proportions (15% left, 70% middle, 15% right)
        main_splitter.setSizes([200, 700, 200])
        main_splitter.setStretchFactor(0, 0)  # Left panel doesn't stretch
        main_splitter.setStretchFactor(1, 1)  # Middle panel stretches
        main_splitter.setStretchFactor(2, 0)  # Right panel doesn't stretch
        main_splitter.setCollapsible(0, False)  # Prevent left panel from collapsing
        main_splitter.setCollapsible(1, False)  # Prevent middle panel from collapsing
        main_splitter.setCollapsible(2, False)  # Prevent right panel from collapsing
    
    def create_properties_panel(self):
        """Create the left properties panel - matches Sound/Sprite editor style"""
        panel = QFrame()
        panel.setFrameStyle(QFrame.StyledPanel)
        panel.setMinimumWidth(300)
        panel.setMaximumWidth(500)
        
        # Scroll area for properties
        scroll = QScrollArea()
        scroll.setWidget(panel)
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        scroll.setMinimumWidth(300)
        scroll.setMaximumWidth(500)
        
        layout = QVBoxLayout(panel)
        layout.setContentsMargins(10, 10, 10, 10)
        layout.setSpacing(15)
        
        # Title
        title_label = QLabel("Model Properties")
        title_label.setStyleSheet("font-size: 14px; font-weight: bold; margin-bottom: 10px;")
        layout.addWidget(title_label)
        
        # Basic Info Group
        info_group = QGroupBox("Basic Information")
        info_layout = QGridLayout(info_group)
        
        # Name
        info_layout.addWidget(QLabel("Name:"), 0, 0)
        self.name_edit = QLineEdit()
        self.name_edit.textChanged.connect(self.on_name_changed)
        info_layout.addWidget(self.name_edit, 0, 1)
        
        # File path (read-only)
        info_layout.addWidget(QLabel("File:"), 1, 0)
        self.file_label = QLabel("No model loaded")
        self.file_label.setWordWrap(True)
        self.file_label.setStyleSheet("color: #888;")
        info_layout.addWidget(self.file_label, 1, 1)
        
        # Create/Edit Model button (changes based on whether model is loaded)
        self.create_edit_btn = QPushButton("Create Model")
        self.create_edit_btn.clicked.connect(self.toggle_edit_mode)
        info_layout.addWidget(self.create_edit_btn, 2, 0, 1, 2)
        
        # Load Model button
        self.load_btn = QPushButton("Load Model")
        self.load_btn.clicked.connect(self.load_model_file)
        info_layout.addWidget(self.load_btn, 3, 0, 1, 2)
        
        # Manage Textures button
        self.manage_textures_btn = QPushButton("Manage Textures")
        self.manage_textures_btn.clicked.connect(self.open_manage_textures_dialog)
        self.manage_textures_btn.setEnabled(False)  # Disabled until a model is loaded
        info_layout.addWidget(self.manage_textures_btn, 4, 0, 1, 2)
        
        layout.addWidget(info_group)
        
        # Model Dimensions Group
        dim_group = QGroupBox("Model Dimensions")
        dim_layout = QGridLayout(dim_group)
        
        # Width (X dimension)
        dim_layout.addWidget(QLabel("Width (X):"), 0, 0)
        self.width_label = QLabel("N/A")
        self.width_label.setStyleSheet("color: #888;")
        dim_layout.addWidget(self.width_label, 0, 1)
        
        # Height (Y dimension)
        dim_layout.addWidget(QLabel("Height (Y):"), 1, 0)
        self.height_label = QLabel("N/A")
        self.height_label.setStyleSheet("color: #888;")
        dim_layout.addWidget(self.height_label, 1, 1)
        
        # Length (Z dimension)
        dim_layout.addWidget(QLabel("Length (Z):"), 2, 0)
        self.length_label = QLabel("N/A")
        self.length_label.setStyleSheet("color: #888;")
        dim_layout.addWidget(self.length_label, 2, 1)
        
        layout.addWidget(dim_group)
        
        # Preview Scale Group
        preview_group = QGroupBox("Preview Settings")
        preview_layout = QGridLayout(preview_group)
        
        # Preview scale for large models
        preview_layout.addWidget(QLabel("Preview Scale:"), 0, 0)
        self.preview_scale_spin = QDoubleSpinBox()
        self.preview_scale_spin.setRange(0.01, 1.0)
        self.preview_scale_spin.setValue(1.0)
        self.preview_scale_spin.setSingleStep(0.1)
        self.preview_scale_spin.setDecimals(2)
        self.preview_scale_spin.setSuffix("x")
        self.preview_scale_spin.valueChanged.connect(self._on_preview_scale_changed)
        preview_layout.addWidget(self.preview_scale_spin, 0, 1)
        
        preview_layout.addWidget(QLabel("(Scale down large models for preview)"), 1, 0, 1, 2)
        preview_layout.itemAt(preview_layout.count() - 1).widget().setStyleSheet("color: #888; font-size: 9px;")
        
        # Smooth Movement checkbox
        self.smooth_movement_checkbox = QCheckBox("Smooth Movement")
        self.smooth_movement_checkbox.setChecked(False)
        self.smooth_movement_checkbox.stateChanged.connect(self._on_smooth_movement_changed)
        preview_layout.addWidget(self.smooth_movement_checkbox, 2, 0, 1, 2)
        
        # Smooth Camera checkbox
        self.smooth_camera_checkbox = QCheckBox("Smooth Camera")
        self.smooth_camera_checkbox.setChecked(False)
        self.smooth_camera_checkbox.stateChanged.connect(self._on_smooth_camera_changed)
        preview_layout.addWidget(self.smooth_camera_checkbox, 3, 0, 1, 2)
        
        layout.addWidget(preview_group)
        
        # Lighting Group
        lighting_group = QGroupBox("Lighting")
        lighting_layout = QGridLayout(lighting_group)
        
        # Model lit checkbox
        self.model_lit_checkbox = QCheckBox("Model Lit")
        self.model_lit_checkbox.setChecked(True)
        self.model_lit_checkbox.stateChanged.connect(self._on_model_lit_changed)
        lighting_layout.addWidget(self.model_lit_checkbox, 0, 0, 1, 2)
        
        # External light checkbox
        self.external_light_checkbox = QCheckBox("External Light")
        self.external_light_checkbox.setChecked(False)
        # Connect both stateChanged and toggled signals for better compatibility
        self.external_light_checkbox.stateChanged.connect(self._on_external_light_changed)
        self.external_light_checkbox.toggled.connect(lambda checked: debug(f"External light toggled signal: {checked}"))
        lighting_layout.addWidget(self.external_light_checkbox, 1, 0, 1, 2)
        
        # Light color button
        self.light_color_btn = QPushButton("Light Color")
        self.light_color_btn.clicked.connect(self._pick_light_color)
        # Don't update color button here - will be updated after gl widget is created
        lighting_layout.addWidget(QLabel("Color:"), 2, 0)
        lighting_layout.addWidget(self.light_color_btn, 2, 1)
        
        # Light position dropdown
        lighting_layout.addWidget(QLabel("Position:"), 3, 0)
        self.light_position_combo = QComboBox()
        self.light_position_combo.addItems(["top", "bottom", "left", "right", "middle"])
        self.light_position_combo.setCurrentText("top")
        self.light_position_combo.currentTextChanged.connect(self._on_light_position_changed)
        lighting_layout.addWidget(self.light_position_combo, 3, 1)
        
        # Internal light brightness
        lighting_layout.addWidget(QLabel("Internal Brightness:"), 4, 0)
        self.internal_brightness_spin = QDoubleSpinBox()
        self.internal_brightness_spin.setRange(0.1, 10.0)
        self.internal_brightness_spin.setValue(1.0)
        self.internal_brightness_spin.setSingleStep(0.1)
        self.internal_brightness_spin.setDecimals(1)
        self.internal_brightness_spin.valueChanged.connect(self._on_internal_brightness_changed)
        lighting_layout.addWidget(self.internal_brightness_spin, 4, 1)
        
        # External light brightness
        lighting_layout.addWidget(QLabel("External Brightness:"), 5, 0)
        self.external_brightness_spin = QDoubleSpinBox()
        self.external_brightness_spin.setRange(0.1, 20.0)
        self.external_brightness_spin.setValue(5.0)
        self.external_brightness_spin.setSingleStep(0.5)
        self.external_brightness_spin.setDecimals(1)
        self.external_brightness_spin.valueChanged.connect(self._on_external_brightness_changed)
        lighting_layout.addWidget(self.external_brightness_spin, 5, 1)
        
        # Lighting style dropdown
        lighting_layout.addWidget(QLabel("Style:"), 6, 0)
        self.lighting_style_combo = QComboBox()
        self.lighting_style_combo.addItems(["Default", "Toon Ramp", "Low Poly", "Wireframe", "Fresnel", "Unlit"])
        self.lighting_style_combo.setCurrentText("Default")
        self.lighting_style_combo.currentTextChanged.connect(self._on_lighting_style_changed)
        lighting_layout.addWidget(self.lighting_style_combo, 6, 1)
        
        layout.addWidget(lighting_group)
        
        # Background/Floor Group
        background_group = QGroupBox("Background/Floor")
        background_layout = QGridLayout(background_group)
        
        # Background color
        background_layout.addWidget(QLabel("Color:"), 0, 0)
        self.background_color_btn = QPushButton()
        self.background_color_btn.clicked.connect(self._pick_background_color)
        background_layout.addWidget(self.background_color_btn, 0, 1)
        
        # Background texture
        background_layout.addWidget(QLabel("Texture:"), 1, 0)
        background_texture_layout = QHBoxLayout()
        self.background_texture_combo = QComboBox()
        self.background_texture_combo.addItem("None (use color)")
        self.background_texture_combo.setEditable(False)
        self.background_texture_combo.currentTextChanged.connect(self._on_background_texture_changed)
        background_texture_browse_btn = QPushButton("...")
        background_texture_browse_btn.setFixedWidth(30)
        background_texture_browse_btn.clicked.connect(self._browse_background_texture)
        background_texture_layout.addWidget(self.background_texture_combo)
        background_texture_layout.addWidget(background_texture_browse_btn)
        background_layout.addLayout(background_texture_layout, 1, 1)
        
        # Background texture mode
        background_layout.addWidget(QLabel("Mode:"), 2, 0)
        self.background_texture_mode_combo = QComboBox()
        self.background_texture_mode_combo.addItems(["Stretch", "Repeat (1x1)", "Repeat (2x2)", "Repeat (4x4)", "Repeat (8x8)", "Repeat (Custom)"])
        self.background_texture_mode_combo.currentTextChanged.connect(self._on_background_texture_mode_changed)
        background_layout.addWidget(self.background_texture_mode_combo, 2, 1)
        
        # Custom scale (shown for Custom mode)
        background_layout.addWidget(QLabel("Custom Scale:"), 3, 0)
        background_scale_layout = QHBoxLayout()
        self.background_scale_x = QDoubleSpinBox()
        self.background_scale_x.setRange(0.1, 100.0)
        self.background_scale_x.setValue(1.0)
        self.background_scale_x.setSingleStep(0.1)
        self.background_scale_x.setDecimals(1)
        self.background_scale_x.setSuffix("x")
        self.background_scale_x.setFixedWidth(60)
        self.background_scale_x.valueChanged.connect(self._on_background_scale_changed)
        self.background_scale_y = QDoubleSpinBox()
        self.background_scale_y.setRange(0.1, 100.0)
        self.background_scale_y.setValue(1.0)
        self.background_scale_y.setSingleStep(0.1)
        self.background_scale_y.setDecimals(1)
        self.background_scale_y.setSuffix("x")
        self.background_scale_y.setFixedWidth(60)
        self.background_scale_y.valueChanged.connect(self._on_background_scale_changed)
        background_scale_layout.addWidget(QLabel("X:"))
        background_scale_layout.addWidget(self.background_scale_x)
        background_scale_layout.addWidget(QLabel("Y:"))
        background_scale_layout.addWidget(self.background_scale_y)
        background_layout.addLayout(background_scale_layout, 3, 1)
        
        layout.addWidget(background_group)
        
        # Skyline Group
        skyline_group = QGroupBox("Skyline")
        skyline_layout = QGridLayout(skyline_group)
        
        # Skyline color
        skyline_layout.addWidget(QLabel("Color:"), 0, 0)
        self.skyline_color_btn = QPushButton()
        self.skyline_color_btn.clicked.connect(self._pick_skyline_color)
        skyline_layout.addWidget(self.skyline_color_btn, 0, 1)
        
        # Skyline texture
        skyline_layout.addWidget(QLabel("Texture:"), 1, 0)
        skyline_texture_layout = QHBoxLayout()
        self.skyline_texture_combo = QComboBox()
        self.skyline_texture_combo.addItem("None (use color)")
        self.skyline_texture_combo.setEditable(False)
        self.skyline_texture_combo.currentTextChanged.connect(self._on_skyline_texture_changed)
        skyline_texture_browse_btn = QPushButton("...")
        skyline_texture_browse_btn.setFixedWidth(30)
        skyline_texture_browse_btn.clicked.connect(self._browse_skyline_texture)
        skyline_texture_layout.addWidget(self.skyline_texture_combo)
        skyline_texture_layout.addWidget(skyline_texture_browse_btn)
        skyline_layout.addLayout(skyline_texture_layout, 1, 1)
        
        # Skyline texture mode
        skyline_layout.addWidget(QLabel("Mode:"), 2, 0)
        self.skyline_texture_mode_combo = QComboBox()
        self.skyline_texture_mode_combo.addItems(["Stretch", "Repeat (1x1)", "Repeat (2x2)", "Repeat (4x4)", "Repeat (8x8)", "Repeat (Custom)"])
        self.skyline_texture_mode_combo.currentTextChanged.connect(self._on_skyline_texture_mode_changed)
        skyline_layout.addWidget(self.skyline_texture_mode_combo, 2, 1)
        
        # Custom scale (shown for Custom mode)
        skyline_layout.addWidget(QLabel("Custom Scale:"), 3, 0)
        skyline_scale_layout = QHBoxLayout()
        self.skyline_scale_x = QDoubleSpinBox()
        self.skyline_scale_x.setRange(0.1, 100.0)
        self.skyline_scale_x.setValue(1.0)
        self.skyline_scale_x.setSingleStep(0.1)
        self.skyline_scale_x.setDecimals(1)
        self.skyline_scale_x.setSuffix("x")
        self.skyline_scale_x.setFixedWidth(60)
        self.skyline_scale_x.valueChanged.connect(self._on_skyline_scale_changed)
        self.skyline_scale_y = QDoubleSpinBox()
        self.skyline_scale_y.setRange(0.1, 100.0)
        self.skyline_scale_y.setValue(1.0)
        self.skyline_scale_y.setSingleStep(0.1)
        self.skyline_scale_y.setDecimals(1)
        self.skyline_scale_y.setSuffix("x")
        self.skyline_scale_y.setFixedWidth(60)
        self.skyline_scale_y.valueChanged.connect(self._on_skyline_scale_changed)
        skyline_scale_layout.addWidget(QLabel("X:"))
        skyline_scale_layout.addWidget(self.skyline_scale_x)
        skyline_scale_layout.addWidget(QLabel("Y:"))
        skyline_scale_layout.addWidget(self.skyline_scale_y)
        skyline_layout.addLayout(skyline_scale_layout, 3, 1)
        
        layout.addWidget(skyline_group)
        
        layout.addStretch()
        
        return scroll
    
    def create_preview_panel(self):
        """Create the right preview panel - matches Sound/Sprite editor style"""
        panel = QFrame()
        panel.setFrameStyle(QFrame.StyledPanel)
        
        layout = QVBoxLayout(panel)
        layout.setContentsMargins(10, 10, 10, 10)
        layout.setSpacing(10)
        
        # Title
        title_label = QLabel("Model Preview")
        title_label.setStyleSheet("font-size: 14px; font-weight: bold; margin-bottom: 10px;")
        layout.addWidget(title_label)
        
        # Animation controls (similar to SpriteEditor)
        controls_layout = QHBoxLayout()
        controls_layout.setContentsMargins(0, 0, 0, 0)
        controls_layout.setSpacing(8)
        
        # Previous frame button
        self.prev_frame_btn = QPushButton("◀")
        self.prev_frame_btn.clicked.connect(self.previous_animation_frame)
        self.prev_frame_btn.setFixedSize(30, 30)
        controls_layout.addWidget(self.prev_frame_btn)
        
        # Play button
        self.play_animation_btn = QPushButton("▶")
        self.play_animation_btn.clicked.connect(self.toggle_animation_playback)
        self.play_animation_btn.setFixedSize(30, 30)
        controls_layout.addWidget(self.play_animation_btn)
        
        # Pause/Stop button
        self.stop_animation_btn = QPushButton("⏹")
        self.stop_animation_btn.clicked.connect(self.stop_animation_playback)
        self.stop_animation_btn.setFixedSize(30, 30)
        controls_layout.addWidget(self.stop_animation_btn)
        
        # Next frame button
        self.next_frame_btn = QPushButton("▶")
        self.next_frame_btn.clicked.connect(self.next_animation_frame)
        self.next_frame_btn.setFixedSize(30, 30)
        controls_layout.addWidget(self.next_frame_btn)
        
        # Frame counter
        self.animation_frame_counter = QLabel("1 / 1")
        self.animation_frame_counter.setAlignment(Qt.AlignCenter)
        self.animation_frame_counter.setMinimumWidth(60)
        controls_layout.addWidget(self.animation_frame_counter)
        
        controls_layout.addStretch()
        
        # Animation selector (like SpriteEditor Tags)
        animation_label = QLabel("Animation:")
        controls_layout.addWidget(animation_label)
        self.animation_combo = QComboBox()
        self.animation_combo.addItem("None")
        self.animation_combo.setFixedWidth(120)
        self.animation_combo.currentTextChanged.connect(self.on_animation_changed)
        controls_layout.addWidget(self.animation_combo)
        
        # Loop toggle
        self.animation_loop_checkbox = QCheckBox("Loop")
        self.animation_loop_checkbox.setChecked(True)
        self.animation_loop_checkbox.stateChanged.connect(self.on_animation_loop_changed)
        controls_layout.addWidget(self.animation_loop_checkbox)
        
        # Speed control
        speed_label = QLabel("Speed:")
        controls_layout.addWidget(speed_label)
        self.animation_speed_spin = QDoubleSpinBox()
        self.animation_speed_spin.setRange(0.1, 5.0)
        self.animation_speed_spin.setValue(1.0)
        self.animation_speed_spin.setSingleStep(0.1)
        self.animation_speed_spin.setDecimals(1)
        self.animation_speed_spin.setSuffix("x")
        self.animation_speed_spin.setFixedWidth(70)
        self.animation_speed_spin.valueChanged.connect(self.on_animation_speed_changed)
        controls_layout.addWidget(self.animation_speed_spin)
        
        layout.addLayout(controls_layout)
        
        # OpenGL widget (3D viewport)
        self.gl = ModelPreviewGLWidget()
        if self.app:
            self.gl.app = self.app
        # Store resource_data and app references for texture loading in ModelCreator
        self.gl.resource_data = self.resource_data
        self.gl.app = self.app
        layout.addWidget(self.gl, 1)  # Takes all remaining space
        
        return panel
    
    def on_name_changed(self, text):
        """Handle name field change"""
        if self.resource_data and text:
            old_name = self.resource_data.get("name", "")
            if old_name != text:
                # Rename resource
                if hasattr(self.app, 'resource_manager'):
                    self.app.resource_manager.rename_resource("models", self.resource_data.get("id"), text)
    
    def _on_model_lit_changed(self, state):
        """Handle model lit checkbox change - with live update"""
        is_enabled = self.model_lit_checkbox.isChecked()
        from Core.Debug import debug
        debug(f" Model lit checkbox changed - state={state}, isChecked()={is_enabled}")
        self.gl.model_lit = is_enabled
        debug(f" gl.model_lit is now: {self.gl.model_lit}")
        self._refresh_model_view()
    
    def _on_external_light_changed(self, state):
        """Handle external light checkbox change - with live update"""
        # stateChanged gives us an int: 0=Unchecked, 2=Checked
        # Use isChecked() for more reliable state detection
        is_enabled = self.external_light_checkbox.isChecked()
        from Core.Debug import debug
        debug(f" External light stateChanged - state={state} (type={type(state)}), isChecked()={is_enabled}")
        debug(f" Qt.CheckState.Checked={Qt.CheckState.Checked.value}, state==Checked: {state == Qt.CheckState.Checked.value}")
        self.gl.external_light_enabled = is_enabled
        debug(f" gl.external_light_enabled is now: {self.gl.external_light_enabled}")
        debug(f" Also checking model_lit status: {self.gl.model_lit}")
        if not self.gl.model_lit and is_enabled:
            debug(f" WARNING - External light requires Model Lit to be enabled!")
            # Don't auto-enable - let user control it
        self._refresh_model_view()
        # Save setting persistently
        self._save_model_editor_settings()
    
    def _pick_light_color(self):
        """Open color picker for light color - with live update"""
        color = QColorDialog.getColor(self.gl.light_color, self, "Select Light Color")
        if color.isValid():
            self.gl.light_color = color
            self._update_color_button()
            self._refresh_model_view()
    
    def _update_color_button(self):
        """Update color button appearance"""
        color = self.gl.light_color
        self.light_color_btn.setStyleSheet(
            f"background-color: rgb({color.red()}, {color.green()}, {color.blue()});"
            f"color: {'white' if color.lightness() < 128 else 'black'};"
        )
    
    def _on_light_position_changed(self, text):
        """Handle light position dropdown change - with live update"""
        self.gl.light_position_mode = text
        self._refresh_model_view()
        # Save setting persistently
        self._save_model_editor_settings()
    
    def _on_internal_brightness_changed(self, value):
        """Handle internal light brightness change"""
        if self.gl:
            self.gl.internal_light_brightness = value
            self._refresh_model_view()
    
    def _on_external_brightness_changed(self, value):
        """Handle external light brightness change"""
        if self.gl:
            self.gl.external_light_brightness = value
            self._refresh_model_view()
        # Save setting persistently
        self._save_model_editor_settings()
    
    def _on_smooth_movement_changed(self, state):
        """Handle smooth movement checkbox change"""
        is_enabled = self.smooth_movement_checkbox.isChecked()
        if self.gl:
            self.gl.smooth_movement = is_enabled
            if is_enabled:
                # Sync target position with current position when enabling
                self.gl.target_position = Vector3(
                    self.gl.camera.position.x,
                    self.gl.camera.position.y,
                    self.gl.camera.position.z
                )
            else:
                # When disabling, snap camera to target position to prevent jump
                self.gl.camera.position = Vector3(
                    self.gl.target_position.x,
                    self.gl.target_position.y,
                    self.gl.target_position.z
                )
                self.gl.update()
    
    def _on_smooth_camera_changed(self, state):
        """Handle smooth camera checkbox change"""
        is_enabled = self.smooth_camera_checkbox.isChecked()
        if self.gl:
            self.gl.smooth_camera = is_enabled
            if is_enabled:
                # Sync target rotation with current rotation when enabling
                self.gl.target_yaw = self.gl.camera.yaw
                self.gl.target_pitch = self.gl.camera.pitch
            else:
                # When disabling, snap camera to target rotation to prevent jump
                self.gl.camera.yaw = self.gl.target_yaw
                self.gl.camera.pitch = self.gl.target_pitch
                self.gl.update()
    
    def _on_preview_scale_changed(self, value):
        """Handle preview scale change - reload model with new scale"""
        if not self.gl or not hasattr(self.gl, 'vertices') or self.gl.vertices is None:
            return
        
        # Store the preview scale
        self.gl._preview_scale = value
        
        # Reload the model to reapply transformations with new preview scale
        if self.resource_data:
            self.load_resource_data()
    
    def _on_lighting_style_changed(self, text):
        """Handle lighting style dropdown change - with live update"""
        old_style = self.gl.lighting_style
        self.gl.lighting_style = text
        debug(f"Lighting style changed from {old_style} to {text}")
        # Always recalculate normals when switching styles to ensure clean transition
        if self.gl.vertices is not None and self.gl.indices is not None:
            self.gl._recalculate_normals_for_style()
        self._refresh_model_view()
        # Save setting persistently
        self._save_model_editor_settings()
    
    def _pick_background_color(self):
        """Open color picker for background/floor color"""
        color = QColorDialog.getColor(self.gl.background_color, self, "Select Background/Floor Color")
        if color.isValid():
            self.gl.background_color = color
            self.gl.floor_color = color  # Same as background
            # Save per-model setting (not Preferences)
            if hasattr(self, 'resource_data') and self.resource_data:
                if "model_preview_settings" not in self.resource_data:
                    self.resource_data["model_preview_settings"] = {}
                self.resource_data["model_preview_settings"]["background_color"] = color.name()
            self._update_background_color_button()
            self._refresh_model_view()
            # Note: We don't update Preferences, only per-model settings
    
    def _update_background_color_button(self):
        """Update background color button appearance"""
        color = self.gl.background_color
        self.background_color_btn.setStyleSheet(
            f"background-color: rgb({color.red()}, {color.green()}, {color.blue()});"
            f"color: {'white' if color.lightness() < 128 else 'black'};"
            f"min-width: 50px; min-height: 25px;"
        )
    
    def _pick_skyline_color(self):
        """Open color picker for skyline color"""
        color = QColorDialog.getColor(self.gl.skyline_color, self, "Select Skyline Color")
        if color.isValid():
            self.gl.skyline_color = color
            # Save per-model setting (not Preferences)
            if hasattr(self, 'resource_data') and self.resource_data:
                if "model_preview_settings" not in self.resource_data:
                    self.resource_data["model_preview_settings"] = {}
                self.resource_data["model_preview_settings"]["skyline_color"] = color.name()
            self._update_skyline_color_button()
            self._refresh_model_view()
            # Note: We don't update Preferences, only per-model settings
    
    def _update_skyline_color_button(self):
        """Update skyline color button appearance"""
        color = self.gl.skyline_color
        self.skyline_color_btn.setStyleSheet(
            f"background-color: rgb({color.red()}, {color.green()}, {color.blue()});"
            f"color: {'white' if color.lightness() < 128 else 'black'};"
            f"min-width: 50px; min-height: 25px;"
        )
    
    def _browse_background_texture(self):
        """Browse for background/floor texture from project resources"""
        if not self.app or not hasattr(self.app, 'project_manager'):
            QMessageBox.warning(self, "Error", "Project manager not available.")
            return
        
        # Get list of texture resources from project
        try:
            texture_resources = self.app.project_manager.get_resources("textures")
        except:
            texture_resources = []
        
        if not texture_resources:
            QMessageBox.information(self, "No Textures", "No texture resources found in the project.\nPlease create textures in the Textures folder first.")
            return
        
        # Create a simple dialog to select texture
        from PySide6.QtWidgets import QDialog, QVBoxLayout, QListWidget, QDialogButtonBox
        
        dialog = QDialog(self)
        dialog.setWindowTitle("Select Background/Floor Texture")
        dialog.setMinimumWidth(400)
        dialog.setMinimumHeight(300)
        
        layout = QVBoxLayout(dialog)
        
        # List of textures
        texture_list = QListWidget()
        texture_list.addItem("None (use color)")
        for texture_resource in texture_resources:
            texture_name = texture_resource.get("name", "Unknown")
            texture_list.addItem(texture_name)
        texture_list.setCurrentRow(0)
        
        layout.addWidget(QLabel("Select texture from project Textures:"))
        layout.addWidget(texture_list)
        
        # Buttons
        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.accepted.connect(dialog.accept)
        buttons.rejected.connect(dialog.reject)
        layout.addWidget(buttons)
        
        if dialog.exec() == QDialog.Accepted:
            selected_item = texture_list.currentItem()
            if selected_item:
                selected_name = selected_item.text()
                # Update combo box
                if selected_name == "None (use color)":
                    self.background_texture_combo.setCurrentText("None (use color)")
                else:
                    # Find texture resource ID
                    for texture_resource in texture_resources:
                        if texture_resource.get("name") == selected_name:
                            texture_id = texture_resource.get("id")
                            # Update settings (save texture ID)
                            if self.app and hasattr(self.app, 'settings'):
                                self.app.settings.set("Model_Background_Texture", texture_id)
                            # Update combo box (will trigger _on_background_texture_changed)
                            self.background_texture_combo.blockSignals(True)
                            # Clear and add items
                            self.background_texture_combo.clear()
                            self.background_texture_combo.addItem("None (use color)")
                            current_index = 0
                            for i, tex in enumerate(texture_resources):
                                self.background_texture_combo.addItem(tex.get("name", "Unknown"))
                                if tex.get("name") == selected_name:
                                    current_index = i + 1
                            self.background_texture_combo.setCurrentIndex(current_index)
                            self.background_texture_combo.blockSignals(False)
                            # Trigger update
                            self._on_background_texture_changed(selected_name)
                            break
    
    def _browse_skyline_texture(self):
        """Browse for skyline texture from project resources"""
        if not self.app or not hasattr(self.app, 'project_manager'):
            QMessageBox.warning(self, "Error", "Project manager not available.")
            return
        
        # Get list of texture resources from project
        try:
            texture_resources = self.app.project_manager.get_resources("textures")
        except:
            texture_resources = []
        
        if not texture_resources:
            QMessageBox.information(self, "No Textures", "No texture resources found in the project.\nPlease create textures in the Textures folder first.")
            return
        
        # Create a simple dialog to select texture
        from PySide6.QtWidgets import QDialog, QVBoxLayout, QListWidget, QDialogButtonBox
        
        dialog = QDialog(self)
        dialog.setWindowTitle("Select Skyline Texture")
        dialog.setMinimumWidth(400)
        dialog.setMinimumHeight(300)
        
        layout = QVBoxLayout(dialog)
        
        # List of textures
        texture_list = QListWidget()
        texture_list.addItem("None (use color)")
        for texture_resource in texture_resources:
            texture_name = texture_resource.get("name", "Unknown")
            texture_list.addItem(texture_name)
        texture_list.setCurrentRow(0)
        
        layout.addWidget(QLabel("Select texture from project Textures:"))
        layout.addWidget(texture_list)
        
        # Buttons
        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.accepted.connect(dialog.accept)
        buttons.rejected.connect(dialog.reject)
        layout.addWidget(buttons)
        
        if dialog.exec() == QDialog.Accepted:
            selected_item = texture_list.currentItem()
            if selected_item:
                selected_name = selected_item.text()
                # Update combo box
                if selected_name == "None (use color)":
                    self.skyline_texture_combo.setCurrentText("None (use color)")
                else:
                    # Find texture resource ID
                    for texture_resource in texture_resources:
                        if texture_resource.get("name") == selected_name:
                            texture_id = texture_resource.get("id")
                            # Update settings (save texture ID)
                            if self.app and hasattr(self.app, 'settings'):
                                self.app.settings.set("Model_Skyline_Texture", texture_id)
                            # Update combo box (will trigger _on_skyline_texture_changed)
                            self.skyline_texture_combo.blockSignals(True)
                            # Clear and add items
                            self.skyline_texture_combo.clear()
                            self.skyline_texture_combo.addItem("None (use color)")
                            current_index = 0
                            for i, tex in enumerate(texture_resources):
                                self.skyline_texture_combo.addItem(tex.get("name", "Unknown"))
                                if tex.get("name") == selected_name:
                                    current_index = i + 1
                            self.skyline_texture_combo.setCurrentIndex(current_index)
                            self.skyline_texture_combo.blockSignals(False)
                            # Trigger update
                            self._on_skyline_texture_changed(selected_name)
                            break
    
    def _on_background_texture_changed(self, texture_name):
        """Handle background texture selection change"""
        if texture_name == "None (use color)" or not texture_name:
            # Clear texture
            self.gl.background_texture_path = ""
            self.gl.floor_texture_path = ""
            if hasattr(self.gl, 'background_texture_id') and self.gl.background_texture_id:
                glDeleteTextures([self.gl.background_texture_id])
                self.gl.background_texture_id = None
            if hasattr(self.gl, 'floor_texture_id') and self.gl.floor_texture_id:
                glDeleteTextures([self.gl.floor_texture_id])
                self.gl.floor_texture_id = None
            # Save per-model setting (not Preferences)
            if hasattr(self, 'resource_data') and self.resource_data:
                if "model_preview_settings" not in self.resource_data:
                    self.resource_data["model_preview_settings"] = {}
                self.resource_data["model_preview_settings"]["background_texture_id"] = ""
        else:
            # Load texture from resource
            if self.app and hasattr(self.app, 'project_manager'):
                try:
                    texture_resources = self.app.project_manager.get_resources("textures")
                    for tex in texture_resources:
                        if tex.get("name") == texture_name:
                            texture_id = tex.get("id")
                            # Save texture ID to per-model settings (not Preferences)
                            if hasattr(self, 'resource_data') and self.resource_data:
                                if "model_preview_settings" not in self.resource_data:
                                    self.resource_data["model_preview_settings"] = {}
                                self.resource_data["model_preview_settings"]["background_texture_id"] = texture_id
                                debug(f"Saved per-model background texture: {texture_id}")
                            
                            frames = tex.get("frames", [])
                            if frames and len(frames) > 0:
                                frame_file = frames[0].get("file", "")
                                if frame_file:
                                    project_path = self.app.project_manager.project_path
                                    # Check if frame_file already includes path info
                                    if os.path.sep in frame_file or (os.path.altsep and os.path.altsep in frame_file):
                                        # Already has path, use as-is
                                        texture_path = os.path.join(project_path, "Resources", "Textures", frame_file)
                                    else:
                                        # No path, check if texture resource has parent_folder
                                        parent_folder = tex.get("parent_folder", "")
                                        if parent_folder:
                                            texture_path = os.path.join(project_path, "Resources", "Textures", parent_folder, frame_file)
                                        else:
                                            texture_path = os.path.join(project_path, "Resources", "Textures", frame_file)
                                    
                                    if os.path.exists(texture_path):
                                        self.gl.background_texture_path = texture_path
                                        self.gl.floor_texture_path = texture_path
                                        # Clear old texture IDs to force reload
                                        if hasattr(self.gl, 'background_texture_id'):
                                            if self.gl.background_texture_id:
                                                glDeleteTextures([self.gl.background_texture_id])
                                            self.gl.background_texture_id = None
                                        if hasattr(self.gl, 'floor_texture_id'):
                                            if self.gl.floor_texture_id:
                                                glDeleteTextures([self.gl.floor_texture_id])
                                            self.gl.floor_texture_id = None
                                        debug(f"Set background/floor texture path: {texture_path}")
                                        # Force immediate reload by calling update
                                        self.gl.update()
                                    else:
                                        debug(f"Background texture file not found: {texture_path}, tried frame_file: {frame_file}")
                                break
                except Exception as e:
                    debug(f"Error loading background texture: {e}")
        self._refresh_model_view()
        # Note: Settings saved to resource_data above, not Preferences
    
    def _on_skyline_texture_changed(self, texture_name):
        """Handle skyline texture selection change"""
        if texture_name == "None (use color)" or not texture_name:
            # Clear texture
            self.gl.skyline_texture_path = ""
            if hasattr(self.gl, 'skyline_texture_id') and self.gl.skyline_texture_id:
                glDeleteTextures([self.gl.skyline_texture_id])
                self.gl.skyline_texture_id = None
            # Save per-model setting (not Preferences)
            if hasattr(self, 'resource_data') and self.resource_data:
                if "model_preview_settings" not in self.resource_data:
                    self.resource_data["model_preview_settings"] = {}
                self.resource_data["model_preview_settings"]["skyline_texture_id"] = ""
        else:
            # Load texture from resource
            if self.app and hasattr(self.app, 'project_manager'):
                try:
                    texture_resources = self.app.project_manager.get_resources("textures")
                    for tex in texture_resources:
                        if tex.get("name") == texture_name:
                            texture_id = tex.get("id")
                            # Save texture ID to per-model settings (not Preferences)
                            if hasattr(self, 'resource_data') and self.resource_data:
                                if "model_preview_settings" not in self.resource_data:
                                    self.resource_data["model_preview_settings"] = {}
                                self.resource_data["model_preview_settings"]["skyline_texture_id"] = texture_id
                                debug(f"Saved per-model skyline texture: {texture_id}")
                            
                            frames = tex.get("frames", [])
                            if frames and len(frames) > 0:
                                frame_file = frames[0].get("file", "")
                                if frame_file:
                                    project_path = self.app.project_manager.project_path
                                    # Check if frame_file already includes path info
                                    if os.path.sep in frame_file or (os.path.altsep and os.path.altsep in frame_file):
                                        # Already has path, use as-is
                                        texture_path = os.path.join(project_path, "Resources", "Textures", frame_file)
                                    else:
                                        # No path, check if texture resource has parent_folder
                                        parent_folder = tex.get("parent_folder", "")
                                        if parent_folder:
                                            texture_path = os.path.join(project_path, "Resources", "Textures", parent_folder, frame_file)
                                        else:
                                            texture_path = os.path.join(project_path, "Resources", "Textures", frame_file)
                                    
                                    if os.path.exists(texture_path):
                                        self.gl.skyline_texture_path = texture_path
                                        # Clear old texture ID to force reload
                                        if hasattr(self.gl, 'skyline_texture_id'):
                                            self.gl.skyline_texture_id = None
                                        debug(f"Set skyline texture path: {texture_path}")
                                    else:
                                        debug(f"Skyline texture file not found: {texture_path}, tried frame_file: {frame_file}")
                                break
                except Exception as e:
                    debug(f"Error loading skyline texture: {e}")
        self._refresh_model_view()
        # Note: Settings saved to resource_data above, not Preferences
    
    def _on_background_texture_mode_changed(self, mode):
        """Handle background texture mode change"""
        if hasattr(self.gl, 'background_texture_mode'):
            self.gl.background_texture_mode = mode
            # Save per-model setting (not Preferences)
            if hasattr(self, 'resource_data') and self.resource_data:
                if "model_preview_settings" not in self.resource_data:
                    self.resource_data["model_preview_settings"] = {}
                self.resource_data["model_preview_settings"]["background_texture_mode"] = mode
            # Show/hide custom scale controls based on mode
            is_custom = (mode == "Repeat (Custom)")
            self.background_scale_x.setVisible(is_custom)
            self.background_scale_y.setVisible(is_custom)
            self._refresh_model_view()
            # Note: We don't update Preferences, only per-model settings
    
    def _on_skyline_texture_mode_changed(self, mode):
        """Handle skyline texture mode change"""
        if hasattr(self.gl, 'skyline_texture_mode'):
            self.gl.skyline_texture_mode = mode
            # Save per-model setting (not Preferences)
            if hasattr(self, 'resource_data') and self.resource_data:
                if "model_preview_settings" not in self.resource_data:
                    self.resource_data["model_preview_settings"] = {}
                self.resource_data["model_preview_settings"]["skyline_texture_mode"] = mode
            # Show/hide custom scale controls based on mode
            is_custom = (mode == "Repeat (Custom)")
            self.skyline_scale_x.setVisible(is_custom)
            self.skyline_scale_y.setVisible(is_custom)
            self._refresh_model_view()
            # Note: We don't update Preferences, only per-model settings
    
    def _on_background_scale_changed(self, value):
        """Handle background texture scale change"""
        if hasattr(self.gl, 'background_texture_scale_x') and hasattr(self.gl, 'background_texture_scale_y'):
            self.gl.background_texture_scale_x = self.background_scale_x.value()
            self.gl.background_texture_scale_y = self.background_scale_y.value()
            # Save per-model setting (not Preferences)
            if hasattr(self, 'resource_data') and self.resource_data:
                if "model_preview_settings" not in self.resource_data:
                    self.resource_data["model_preview_settings"] = {}
                self.resource_data["model_preview_settings"]["background_texture_scale_x"] = self.gl.background_texture_scale_x
                self.resource_data["model_preview_settings"]["background_texture_scale_y"] = self.gl.background_texture_scale_y
            self._refresh_model_view()
            # Note: We don't update Preferences, only per-model settings
    
    def _on_skyline_scale_changed(self, value):
        """Handle skyline texture scale change"""
        if hasattr(self.gl, 'skyline_texture_scale_x') and hasattr(self.gl, 'skyline_texture_scale_y'):
            self.gl.skyline_texture_scale_x = self.skyline_scale_x.value()
            self.gl.skyline_texture_scale_y = self.skyline_scale_y.value()
            # Save per-model setting (not Preferences)
            if hasattr(self, 'resource_data') and self.resource_data:
                if "model_preview_settings" not in self.resource_data:
                    self.resource_data["model_preview_settings"] = {}
                self.resource_data["model_preview_settings"]["skyline_texture_scale_x"] = self.gl.skyline_texture_scale_x
                self.resource_data["model_preview_settings"]["skyline_texture_scale_y"] = self.gl.skyline_texture_scale_y
            self._refresh_model_view()
            # Note: We don't update Preferences, only per-model settings
    
    def _refresh_model_view(self):
        """Force immediate update of the 3D model view"""
        if hasattr(self, 'gl') and self.gl:
            self.gl.update()  # Schedule repaint
            self.gl.repaint()  # Force immediate repaint
            # Process events to ensure update happens immediately
            QApplication.processEvents()
    
    def _update_create_edit_button(self):
        """Update the Create/Edit button text based on whether model is loaded"""
        if hasattr(self, 'gl') and self.gl and hasattr(self.gl, 'vertices') and self.gl.vertices is not None:
            self.create_edit_btn.setText("Edit Model")
        else:
            self.create_edit_btn.setText("Create Model")
    
    def toggle_edit_mode(self):
        """Toggle embedded mode - show/hide menu bar and panels, keep same preview widget"""
        self.edit_mode = not self.edit_mode
        
        if self.edit_mode:
            # Switch to embedded mode - show menu bar and setup panels
            self.setup_edit_mode()
            self.menu_bar.show()
            self.create_edit_btn.setText("Exit Edit Mode")
        else:
            # Switch back to preview mode - restore preview layout
            self.setup_preview_mode()
            self.menu_bar.hide()
            self._update_create_edit_button()
    
    def create_menu_bar(self):
        """Create menu bar with File, Edit, and View menus"""
        menu_bar = QMenuBar(self)
        
        # File menu
        file_menu = menu_bar.addMenu("File")
        
        save_action = QAction("Save", self)
        save_action.setShortcut(QKeySequence.Save)
        save_action.triggered.connect(self.save_model)
        file_menu.addAction(save_action)
        
        save_as_action = QAction("Save As...", self)
        save_as_action.triggered.connect(self.save_model_as)
        file_menu.addAction(save_as_action)
        
        file_menu.addSeparator()
        
        close_action = QAction("Close", self)
        close_action.setShortcut(QKeySequence.Quit)
        close_action.triggered.connect(self.toggle_edit_mode)
        file_menu.addAction(close_action)
        
        # Edit menu
        edit_menu = menu_bar.addMenu("Edit")
        
        cut_action = QAction("Cut", self)
        cut_action.setShortcut(QKeySequence.Cut)
        cut_action.triggered.connect(self.cut_selection)
        edit_menu.addAction(cut_action)
        
        copy_action = QAction("Copy", self)
        copy_action.setShortcut(QKeySequence.Copy)
        copy_action.triggered.connect(self.copy_selection)
        edit_menu.addAction(copy_action)
        
        paste_action = QAction("Paste", self)
        paste_action.setShortcut(QKeySequence.Paste)
        paste_action.triggered.connect(self.paste_selection)
        edit_menu.addAction(paste_action)
        
        delete_action = QAction("Delete", self)
        delete_action.setShortcut(QKeySequence.Delete)
        delete_action.triggered.connect(self.delete_selection)
        edit_menu.addAction(delete_action)
        
        edit_menu.addSeparator()
        
        undo_action = QAction("Undo", self)
        undo_action.setShortcut(QKeySequence.Undo)
        undo_action.triggered.connect(self.undo_action)
        edit_menu.addAction(undo_action)
        
        redo_action = QAction("Redo", self)
        redo_action.setShortcut(QKeySequence.Redo)
        redo_action.triggered.connect(self.redo_action)
        edit_menu.addAction(redo_action)
        
        edit_menu.addSeparator()
        
        preferences_action = QAction("Preferences...", self)
        preferences_action.setShortcut(QKeySequence.Preferences)
        preferences_action.triggered.connect(self.show_preferences)
        edit_menu.addAction(preferences_action)
        
        # View menu
        view_menu = menu_bar.addMenu("View")
        
        lighting_action = QAction("Lighting...", self)
        lighting_action.triggered.connect(self.show_lighting_settings)
        view_menu.addAction(lighting_action)
        
        view_menu.addSeparator()
        
        fullscreen_action = QAction("Fullscreen", self)
        fullscreen_action.setShortcut(QKeySequence.FullScreen)
        fullscreen_action.triggered.connect(self.toggle_fullscreen)
        view_menu.addAction(fullscreen_action)
        
        return menu_bar
    
    def save_resource(self) -> bool:
        """Save the model resource (EditorInterface implementation)"""
        try:
            if not self.resource_data:
                QMessageBox.warning(self, "No Model", "No model loaded to save.")
                return False
            
            # Save to the resource file
            if hasattr(self, 'gl') and self.gl and isinstance(self.gl, ModelEditGLWidget):
                # Export edited geometry back to preview widget
                if hasattr(self, 'preview_gl') and self.preview_gl:
                    self.gl.export_to_preview(self.preview_gl)
            
            # Use resource manager to save
            result = False
            if self.app and hasattr(self.app, 'resource_manager'):
                try:
                    result = self.app.resource_manager.save_resource("models", self.resource_data.get("id"), self.resource_data)
                    if result:
                        self._dirty = False
                except Exception as e:
                    QMessageBox.critical(self, "Save Error", f"Failed to save model: {str(e)}")
                    return False
            
            return result
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to save resource: {str(e)}")
            return False
    
    def save_model(self):
        """Save model (legacy method - calls save_resource)"""
        self.save_resource()
    
    def save_model_as(self):
        """Save model as"""
        filters = "Wavefront OBJ (*.obj);;glTF Binary (*.glb);;glTF JSON (*.gltf);;Collada DAE (*.dae);;PyGenesis Model (*.Model);;All Files (*.*)"
        path, selected_filter = QFileDialog.getSaveFileName(self, "Save Model As", "", filters)
        if path:
            # TODO: Implement save logic based on file extension
            QMessageBox.information(self, "Save As", f"Save as functionality coming soon. Would save to: {path}")
    
    def _set_tool_mode(self, mode):
        """Set the current tool mode and update button states"""
        if hasattr(self, 'gl') and isinstance(self.gl, ModelEditGLWidget):
            self.gl.tool_mode = mode
            # Update button states
            self.select_tool_btn.setChecked(mode == ToolMode.SELECT)
            self.scale_tool_btn.setChecked(mode == ToolMode.SCALE)
            self.rotate_tool_btn.setChecked(mode == ToolMode.ROTATE)
            self.draw_tool_btn.setChecked(mode == ToolMode.DRAW)
            self.gl.update()
    
    def cut_selection(self):
        """Cut selected elements"""
        self.copy_selection()
        self.delete_selection()
    
    def copy_selection(self):
        """Copy selected elements to clipboard"""
        if not hasattr(self, 'gl') or not isinstance(self.gl, ModelEditGLWidget):
            return
        
        # Store selection data for paste
        self.gl.clipboard_edges = list(self.gl.selected_edges)
        self.gl.clipboard_faces = list(self.gl.selected_faces)
        self.gl.clipboard_vertices = list(self.gl.selected_vertices)
        
        # Store geometry data for selected elements
        if self.gl.clipboard_vertices and self.gl.vertices is not None:
            self.gl.clipboard_vertex_data = []
            for v_idx in self.gl.clipboard_vertices:
                if v_idx < len(self.gl.vertices):
                    self.gl.clipboard_vertex_data.append(self.gl.vertices[v_idx].copy())
        
        QMessageBox.information(self, "Copy", f"Copied {len(self.gl.clipboard_edges)} edges, {len(self.gl.clipboard_faces)} faces, {len(self.gl.clipboard_vertices)} vertices")
    
    def paste_selection(self):
        """Paste clipboard elements"""
        if not hasattr(self, 'gl') or not isinstance(self.gl, ModelEditGLWidget):
            return
        
        if not hasattr(self.gl, 'clipboard_edges') or not self.gl.clipboard_edges:
            QMessageBox.warning(self, "Paste", "Clipboard is empty.")
            return
        
        # TODO: Implement paste - duplicate selected elements at offset position
        QMessageBox.information(self, "Paste", "Paste functionality coming soon")
    
    def delete_selection(self):
        """Delete selected elements"""
        if not hasattr(self, 'gl') or not isinstance(self.gl, ModelEditGLWidget):
            return
        
        # Push undo state
        self.gl.push_undo()
        
        # Remove selected elements
        if self.gl.selected_vertices:
            # Remove vertices and update indices
            self.gl._delete_vertices(self.gl.selected_vertices)
        if self.gl.selected_edges:
            # Remove edges
            edges_to_remove = list(self.gl.selected_edges)
            for edge in edges_to_remove:
                if edge in self.gl.edges:
                    self.gl.edges.remove(edge)
                if edge in self.gl._edit_edges:
                    self.gl._edit_edges.remove(edge)
        if self.gl.selected_faces:
            # Remove faces
            faces_to_remove = list(self.gl.selected_faces)
            for face in faces_to_remove:
                if face in self.gl.faces:
                    self.gl.faces.remove(face)
                if face in self.gl._edit_faces:
                    self.gl._edit_faces.remove(face)
        
        # Clear selection
        self.gl.selected_vertices.clear()
        self.gl.selected_edges.clear()
        self.gl.selected_faces.clear()
        
        # Rebuild geometry
        if self.gl._allow_geometry_rebuild:
            self.gl._rebuild_geometry()
        
        self.gl.update()
        self._update_selection_info()
    
    def undo_action(self):
        """Undo last action"""
        if hasattr(self, 'gl') and isinstance(self.gl, ModelEditGLWidget):
            if hasattr(self.gl, 'undo'):
                self.gl.undo()
                self.gl.update()
                self._update_selection_info()
    
    def redo_action(self):
        """Redo last undone action"""
        if hasattr(self, 'gl') and isinstance(self.gl, ModelEditGLWidget):
            if hasattr(self.gl, 'redo'):
                self.gl.redo()
                self.gl.update()
                self._update_selection_info()
    
    def show_preferences(self):
        """Show preferences dialog"""
        if self.app:
            from UI.CommonDialogs.PreferencesDialog import PreferencesDialog
            dialog = PreferencesDialog(self.app, self)
            # Connect to preferences changed signal to reload settings
            dialog.preferences_changed.connect(self._load_model_editor_settings)
            dialog.exec()
    
    def show_lighting_settings(self):
        """Show lighting settings dialog"""
        # For now, just show a message - can be expanded to a dialog
        QMessageBox.information(self, "Lighting Settings", "Lighting settings are available in the right panel.")
    
    def _update_selection_info(self):
        """Update selection info label"""
        if not hasattr(self, 'selection_info_label'):
            return
        
        if not hasattr(self, 'gl') or not isinstance(self.gl, ModelEditGLWidget):
            return
        
        edge_count = len(self.gl.selected_edges)
        face_count = len(self.gl.selected_faces)
        vertex_count = len(self.gl.selected_vertices)
        
        parts = []
        if vertex_count > 0:
            parts.append(f"{vertex_count} vertex{'ices' if vertex_count != 1 else ''}")
        if edge_count > 0:
            parts.append(f"{edge_count} edge{'s' if edge_count != 1 else ''}")
        if face_count > 0:
            parts.append(f"{face_count} face{'s' if face_count != 1 else ''}")
        
        if parts:
            self.selection_info_label.setText(", ".join(parts))
        else:
            self.selection_info_label.setText("No selection")
    
    def _update_animation_combo(self):
        """Update animation combo box with available animations"""
        if not hasattr(self, 'animation_combo'):
            return
        
        self.animation_combo.clear()
        self.animation_combo.addItem("None")
        
        if hasattr(self.gl, 'animations') and self.gl.animations:
            for anim_name in self.gl.animations.keys():
                self.animation_combo.addItem(anim_name)
    
    def on_animation_changed(self, animation_name):
        """Handle animation selection change"""
        # Stop playback if active
        if hasattr(self, '_animation_timer') and self._animation_timer:
            self.stop_animation_playback()
        
        # Set current animation
        if hasattr(self.gl, 'animations'):
            if animation_name == "None":
                self.gl.current_animation = None
                self.gl.current_animation_time = 0.0
            else:
                self.gl.current_animation = animation_name
                self.gl.current_animation_time = 0.0
                # Evaluate initial pose
                if hasattr(self.gl, '_evaluate_animation_pose'):
                    self.gl._evaluate_animation_pose()
        
        # Update frame counter
        self._update_animation_frame_counter()
    
    def toggle_animation_playback(self):
        """Toggle animation playback"""
        if not hasattr(self.gl, 'current_animation') or not self.gl.current_animation:
            return
        
        if not hasattr(self.gl, 'is_playing_animation'):
            self.gl.is_playing_animation = False
        
        if self.gl.is_playing_animation:
            self.stop_animation_playback()
        else:
            self.start_animation_playback()
    
    def start_animation_playback(self):
        """Start animation playback"""
        if not hasattr(self.gl, 'current_animation') or not self.gl.current_animation:
            return
        
        if not hasattr(self.gl, 'animations') or self.gl.current_animation not in self.gl.animations:
            return
        
        anim_clip = self.gl.animations[self.gl.current_animation]
        if not isinstance(anim_clip, AnimationClip):
            return
        
        if anim_clip.frame_count <= 1:
            return
        
        self.gl.is_playing_animation = True
        self.play_animation_btn.setText("⏸")  # Pause icon
        
        # Create timer if it doesn't exist
        if not hasattr(self, '_animation_timer'):
            self._animation_timer = QTimer(self)
            self._animation_timer.timeout.connect(self._advance_animation_frame)
        
        # Set timer interval based on frame rate and speed
        base_fps = anim_clip.frame_rate
        adjusted_fps = base_fps * self.gl.animation_speed
        self._animation_timer.start(int(1000 / adjusted_fps) if adjusted_fps > 0 else 33)
    
    def stop_animation_playback(self):
        """Stop animation playback"""
        if hasattr(self.gl, 'is_playing_animation'):
            self.gl.is_playing_animation = False
        
        if hasattr(self, '_animation_timer') and self._animation_timer:
            self._animation_timer.stop()
        
        self.play_animation_btn.setText("▶")  # Play icon
    
    def _advance_animation_frame(self):
        """Advance animation time (called by timer)"""
        if not hasattr(self.gl, 'current_animation') or not self.gl.current_animation:
            self.stop_animation_playback()
            return
        
        if not hasattr(self.gl, 'animations') or self.gl.current_animation not in self.gl.animations:
            self.stop_animation_playback()
            return
        
        anim_clip = self.gl.animations[self.gl.current_animation]
        if not isinstance(anim_clip, AnimationClip):
            # Legacy format - convert
            self.stop_animation_playback()
            return
        
        # Advance time based on speed
        dt = 0.033 * self.gl.animation_speed  # ~30 FPS base, scaled by speed
        # Ensure current_animation_time is a float
        try:
            self.gl.current_animation_time = float(self.gl.current_animation_time) + dt
        except (ValueError, TypeError):
            self.gl.current_animation_time = dt
        
        # Handle looping - ensure both are floats
        try:
            current_time = float(self.gl.current_animation_time)
            duration = float(anim_clip.duration)
        except (ValueError, TypeError):
            current_time = 0.0
            duration = 1.0
        
        if current_time >= duration:
            if self.gl.animation_loop:
                self.gl.current_animation_time = current_time % duration
            else:
                self.gl.current_animation_time = duration
                self.stop_animation_playback()
        
        # Update the actual time
        self.gl.current_animation_time = current_time
        
        # Evaluate pose and apply transforms
        self.gl._evaluate_animation_pose()
        
        # Update display and render
        self._update_animation_frame_counter()
        self.gl.update()
    
    def next_animation_frame(self):
        """Go to next animation frame"""
        if not hasattr(self.gl, 'current_animation') or not self.gl.current_animation:
            return
        
        if not hasattr(self.gl, 'animations') or self.gl.current_animation not in self.gl.animations:
            return
        
        anim_clip = self.gl.animations[self.gl.current_animation]
        if not isinstance(anim_clip, AnimationClip):
            return
        
        # Advance by one frame time
        frame_time = 1.0 / float(anim_clip.frame_rate)
        
        # Ensure current_animation_time is a float
        try:
            current_time = float(self.gl.current_animation_time) + frame_time
            duration = float(anim_clip.duration)
        except (ValueError, TypeError):
            current_time = frame_time
            duration = 1.0
        
        if current_time >= duration:
            if self.gl.animation_loop:
                current_time = current_time % duration
            else:
                current_time = duration
        
        self.gl.current_animation_time = current_time
        
        self.gl._evaluate_animation_pose()
        self._update_animation_frame_counter()
        self.gl.update()
    
    def previous_animation_frame(self):
        """Go to previous animation frame"""
        if not hasattr(self.gl, 'current_animation') or not self.gl.current_animation:
            return
        
        if not hasattr(self.gl, 'animations') or self.gl.current_animation not in self.gl.animations:
            return
        
        anim_clip = self.gl.animations[self.gl.current_animation]
        if not isinstance(anim_clip, AnimationClip):
            return
        
        # Go back by one frame time
        frame_time = 1.0 / float(anim_clip.frame_rate)
        
        # Ensure current_animation_time is a float
        try:
            current_time = float(self.gl.current_animation_time) - frame_time
            duration = float(anim_clip.duration)
        except (ValueError, TypeError):
            current_time = 0.0
            duration = 1.0
        
        if current_time < 0:
            if self.gl.animation_loop:
                current_time = duration + (current_time % duration)
            else:
                current_time = 0.0
        
        self.gl.current_animation_time = current_time
        
        self.gl._evaluate_animation_pose()
        self._update_animation_frame_counter()
        self.gl.update()
    
    def _update_animation_frame_counter(self):
        """Update the animation frame counter display"""
        if not hasattr(self, 'animation_frame_counter'):
            return
        
        if not hasattr(self.gl, 'current_animation') or not self.gl.current_animation:
            self.animation_frame_counter.setText("1 / 1")
            return
        
        if not hasattr(self.gl, 'animations') or self.gl.current_animation not in self.gl.animations:
            self.animation_frame_counter.setText("1 / 1")
            return
        
        anim_clip = self.gl.animations[self.gl.current_animation]
        if not isinstance(anim_clip, AnimationClip):
            self.animation_frame_counter.setText("1 / 1")
            return
        
        frame_count = anim_clip.frame_count
        current_time = getattr(self.gl, 'current_animation_time', 0.0)
        # Ensure it's a float
        try:
            current_time = float(current_time)
            frame_rate = float(anim_clip.frame_rate)
        except (ValueError, TypeError):
            current_time = 0.0
            frame_rate = 30.0
        current_frame = int(current_time * frame_rate) + 1
        current_frame = max(1, min(current_frame, frame_count))
        
        self.animation_frame_counter.setText(f"{current_frame} / {frame_count}")
    
    def on_animation_loop_changed(self, state):
        """Handle animation loop checkbox change"""
        if hasattr(self.gl, 'animation_loop'):
            self.gl.animation_loop = (state == Qt.Checked)
    
    def on_animation_speed_changed(self, value):
        """Handle animation speed change"""
        if hasattr(self.gl, 'animation_speed'):
            self.gl.animation_speed = value
            # Restart timer with new speed if playing
            if self.gl.is_playing_animation and hasattr(self, '_animation_timer') and self._animation_timer:
                self._animation_timer.stop()
                if self.gl.current_animation and self.gl.current_animation in self.gl.animations:
                    anim_clip = self.gl.animations[self.gl.current_animation]
                    if isinstance(anim_clip, AnimationClip):
                        base_fps = anim_clip.frame_rate
                        adjusted_fps = base_fps * self.gl.animation_speed
                        self._animation_timer.start(int(1000 / adjusted_fps) if adjusted_fps > 0 else 33)
    
    def create_entity_info_panel_OLD(self):
        """Create right panel for entity information"""
        panel = QFrame()
        panel.setFrameStyle(QFrame.StyledPanel)
        panel.setMinimumWidth(200)
        panel.setMaximumWidth(300)
        
        scroll = QScrollArea()
        scroll.setWidget(panel)
        scroll.setWidgetResizable(True)
        scroll.setMinimumWidth(200)
        scroll.setMaximumWidth(300)
        
        layout = QVBoxLayout(panel)
        layout.setContentsMargins(10, 10, 10, 10)
        layout.setSpacing(15)
        
        # Selected Entity Information
        entity_group = QGroupBox("Selected Entity")
        entity_layout = QVBoxLayout(entity_group)
        
        self.entity_info_label = QLabel("No selection")
        self.entity_info_label.setWordWrap(True)
        self.entity_info_label.setStyleSheet("color: #888;")
        entity_layout.addWidget(self.entity_info_label)
        
        layout.addWidget(entity_group)
        
        # Colour / Texture
        color_tex_group = QGroupBox("Colour / Texture")
        color_tex_layout = QGridLayout(color_tex_group)
        
        color_tex_layout.addWidget(QLabel("Colour:"), 0, 0)
        self.entity_color_btn = QPushButton()
        self.entity_color_btn.setFixedSize(50, 30)
        self.entity_color_btn.setStyleSheet("background-color: #888;")
        self.entity_color_btn.clicked.connect(self.pick_entity_color)
        color_tex_layout.addWidget(self.entity_color_btn, 0, 1)
        
        color_tex_layout.addWidget(QLabel("Texture:"), 1, 0)
        self.entity_texture_label = QLabel("None")
        self.entity_texture_label.setStyleSheet("color: #888;")
        color_tex_layout.addWidget(self.entity_texture_label, 1, 1)
        
        layout.addWidget(color_tex_group)
        
        # Groups
        groups_group = QGroupBox("Groups")
        groups_layout = QVBoxLayout(groups_group)
        
        self.groups_list = QLabel("No groups")
        self.groups_list.setStyleSheet("color: #888;")
        groups_layout.addWidget(self.groups_list)
        
        layout.addWidget(groups_group)
        
        layout.addStretch()
        
        return scroll
    
    def set_tool_OLD(self, tool_name):
        """Set the active tool"""
        # Uncheck all buttons
        for btn in [self.draw_line_btn, self.select_btn, self.orbit_btn, 
                     self.pan_btn, self.scale_btn, self.rotate_btn]:
            btn.setChecked(False)
        
        # Check the selected button
        if tool_name == "draw":
            self.draw_line_btn.setChecked(True)
        elif tool_name == "select":
            self.select_btn.setChecked(True)
        elif tool_name == "orbit":
            self.orbit_btn.setChecked(True)
        elif tool_name == "pan":
            self.pan_btn.setChecked(True)
        elif tool_name == "scale":
            self.scale_btn.setChecked(True)
        elif tool_name == "rotate":
            self.rotate_btn.setChecked(True)
        
        # Set tool on edit GL widget
        if hasattr(self, 'edit_gl') and self.edit_gl:
            if tool_name == "draw":
                self.edit_gl.tool_mode = ToolMode.DRAW
            elif tool_name == "select":
                self.edit_gl.tool_mode = ToolMode.SELECT
            elif tool_name == "orbit":
                self.edit_gl.tool_mode = ToolMode.ORBIT
            elif tool_name == "pan":
                self.edit_gl.tool_mode = ToolMode.PAN
            elif tool_name == "scale":
                self.edit_gl.tool_mode = ToolMode.SCALE
            elif tool_name == "rotate":
                self.edit_gl.tool_mode = ToolMode.ROTATE
    
    def pick_colour_OLD(self):
        """Pick color for drawing/editing"""
        color = QColorDialog.getColor(QColor(128, 128, 128), self, "Pick Color")
        if color.isValid():
            # Store color for tools
            if hasattr(self.gl, 'draw_color'):
                self.gl.draw_color = color
            self.colour_btn.setStyleSheet(
                f"background-color: rgb({color.red()}, {color.green()}, {color.blue()});"
                f"color: {'white' if color.lightness() < 128 else 'black'};"
            )
    
    def pick_entity_color_OLD(self):
        """Pick color for selected entity"""
        color = QColorDialog.getColor(QColor(128, 128, 128), self, "Pick Entity Color")
        if color.isValid():
            self.entity_color_btn.setStyleSheet(
                f"background-color: rgb({color.red()}, {color.green()}, {color.blue()});"
            )
    
    def save_model(self):
        """Save the current model"""
        # TODO: Implement save logic
        QMessageBox.information(self, "Save", "Save functionality to be implemented")
    
    def save_model_as_OLD(self):
        """Old save model as - removed duplicate"""
        pass
    
    def show_preferences(self):
        """Show preferences dialog"""
        from UI.CommonDialogs.PreferencesDialog import PreferencesDialog
        dialog = PreferencesDialog(self.app, self)
        if dialog.exec():
            # Load Model Editor specific settings
            self._load_model_editor_settings()
    
    def _load_model_editor_settings(self):
        """Load Model Editor specific settings from preferences"""
        if not self.app or not hasattr(self.app, 'settings'):
            return
        
        settings = self.app.settings
        
        # Load lighting style
        lighting_style = settings.get("Model_Editor_Lighting_Style", "Default")
        if hasattr(self.gl, 'lighting_style') and lighting_style in ["Default", "Toon Ramp", "Low Poly", "Wireframe", "Fresnel", "Unlit"]:
            self.gl.lighting_style = lighting_style
            self.gl._recalculate_normals_for_style()
            # Update UI
            if hasattr(self, 'lighting_style_combo'):
                index = self.lighting_style_combo.findText(lighting_style)
                if index >= 0:
                    self.lighting_style_combo.setCurrentIndex(index)
        
        # Load external light settings
        if hasattr(self.gl, 'external_light_enabled'):
            external_light_enabled = settings.get("Model_Editor_External_Light_Enabled", False)
            # Ensure boolean conversion
            if isinstance(external_light_enabled, str):
                external_light_enabled = external_light_enabled.lower() in ('true', '1', 'yes')
            self.gl.external_light_enabled = bool(external_light_enabled)
            # Update UI checkbox
            if hasattr(self, 'external_light_checkbox'):
                self.external_light_checkbox.setChecked(self.gl.external_light_enabled)
            
            brightness = settings.get("Model_Editor_External_Light_Brightness", 5.0)
            # Ensure brightness is a float
            try:
                self.gl.external_light_brightness = float(brightness)
            except (ValueError, TypeError):
                self.gl.external_light_brightness = 5.0
            # Update UI (convert from float 0.0-20.0 to percentage 1-100)
            if hasattr(self, 'external_brightness_spin'):
                brightness_percent = int(self.gl.external_light_brightness * 10.0)
                brightness_percent = max(1, min(100, brightness_percent))
                self.external_brightness_spin.setValue(brightness_percent)
            
            self.gl.light_position_mode = settings.get("Model_Editor_Light_Position_Mode", "top")
            # Update UI dropdown
            if hasattr(self, 'light_position_combo'):
                index = self.light_position_combo.findText(self.gl.light_position_mode)
                if index >= 0:
                    self.light_position_combo.setCurrentIndex(index)
        
        # Load preview settings
        if hasattr(self.gl, 'model_lit'):
            model_lit = settings.get("Model_Editor_Model_Lit", True)
            # Ensure boolean conversion
            if isinstance(model_lit, str):
                model_lit = model_lit.lower() in ('true', '1', 'yes')
            self.gl.model_lit = bool(model_lit)
            # Update UI checkbox
            if hasattr(self, 'model_lit_checkbox'):
                self.model_lit_checkbox.setChecked(self.gl.model_lit)
        
        # Load preview scale (if available)
        if hasattr(self, 'preview_scale_spin'):
            preview_scale = settings.get("Model_Editor_Preview_Scale", 1.0)
            # Ensure it's a float
            try:
                preview_scale = float(preview_scale)
            except (ValueError, TypeError):
                preview_scale = 1.0
            self.preview_scale_spin.setValue(preview_scale)
            if hasattr(self.gl, '_resource_scale'):
                self.gl._resource_scale = preview_scale
        
        # Load smooth movement/camera settings
        if hasattr(self.gl, 'smooth_movement'):
            smooth_movement = settings.get("Model_Smooth_Movement_Enabled", False)
            # Ensure boolean conversion
            if isinstance(smooth_movement, str):
                smooth_movement = smooth_movement.lower() in ('true', '1', 'yes')
            self.gl.smooth_movement = bool(smooth_movement)
            if hasattr(self, 'smooth_movement_checkbox'):
                self.smooth_movement_checkbox.setChecked(self.gl.smooth_movement)
        
        if hasattr(self.gl, 'smooth_camera'):
            smooth_camera = settings.get("Model_Smooth_Camera_Enabled", False)
            # Ensure boolean conversion
            if isinstance(smooth_camera, str):
                smooth_camera = smooth_camera.lower() in ('true', '1', 'yes')
            self.gl.smooth_camera = bool(smooth_camera)
            if hasattr(self, 'smooth_camera_checkbox'):
                self.smooth_camera_checkbox.setChecked(self.gl.smooth_camera)
        
        if hasattr(self.gl, 'smooth_factor'):
            smooth_factor = settings.get("Model_Smooth_Factor", 0.15)
            try:
                self.gl.smooth_factor = float(smooth_factor)
            except (ValueError, TypeError):
                self.gl.smooth_factor = 0.15
        
        # Load view settings (grid, background, skyline)
        if hasattr(self.gl, 'show_grid'):
            show_grid = settings.get("Model_Show_Grid", True)
            if isinstance(show_grid, str):
                show_grid = show_grid.lower() in ('true', '1', 'yes')
            self.gl.show_grid = bool(show_grid)
        
        if hasattr(self.gl, 'show_background'):
            show_background = settings.get("Model_Show_Background", True)
            if isinstance(show_background, str):
                show_background = show_background.lower() in ('true', '1', 'yes')
            self.gl.show_background = bool(show_background)
        
        if hasattr(self.gl, 'show_skyline'):
            show_skyline = settings.get("Model_Show_Skyline", False)
            if isinstance(show_skyline, str):
                show_skyline = show_skyline.lower() in ('true', '1', 'yes')
            self.gl.show_skyline = bool(show_skyline)
        
        # Load background/floor and skyline colors/textures
        # Check per-model settings first (from resource_data), then fall back to Preferences
        model_settings = {}
        if hasattr(self, 'resource_data') and self.resource_data:
            model_settings = self.resource_data.get("model_preview_settings", {})
        
        if hasattr(self.gl, 'background_color'):
            # Check per-model setting first
            bg_color_str = model_settings.get("background_color", None)
            if bg_color_str is None:
                bg_color_str = str(settings.get("Model_Background_Color", "#1a1a1a"))
            bg_color = QColor(bg_color_str)
            if bg_color.isValid():
                self.gl.background_color = bg_color
        
        if hasattr(self.gl, 'floor_color'):
            # Floor uses same color as background
            if bg_color.isValid():
                self.gl.floor_color = bg_color
        
        if hasattr(self.gl, 'skyline_color'):
            # Check per-model setting first
            skyline_color_str = model_settings.get("skyline_color", None)
            if skyline_color_str is None:
                skyline_color_str = str(settings.get("Model_Skyline_Color", "#87ceeb"))
            skyline_color = QColor(skyline_color_str)
            if skyline_color.isValid():
                self.gl.skyline_color = skyline_color
        
        # Load texture paths - convert texture resource IDs to file paths
        if hasattr(self.gl, 'background_texture_path') and self.app and hasattr(self.app, 'project_manager'):
            # Check per-model setting first
            background_texture_id = model_settings.get("background_texture_id", None)
            if background_texture_id is None:
                background_texture_id = settings.get("Model_Background_Texture", "")
            else:
                debug(f"Using per-model background texture: {background_texture_id}")
            if background_texture_id:
                # Look up texture resource and get the actual file path
                try:
                    texture_resources = self.app.project_manager.get_resources("textures")
                    for tex in texture_resources:
                        if tex.get("id") == background_texture_id:
                            # Get the first frame's file path
                            frames = tex.get("frames", [])
                            if frames and len(frames) > 0:
                                frame_file = frames[0].get("file", "")
                                if frame_file:
                                    # Resolve to full path - frame_file might include subfolder
                                    project_path = self.app.project_manager.project_path
                                    # Check if frame_file already includes path info
                                    if os.path.sep in frame_file or (os.path.altsep and os.path.altsep in frame_file):
                                        # Already has path, use as-is
                                        texture_path = os.path.join(project_path, "Resources", "Textures", frame_file)
                                    else:
                                        # No path, check if texture resource has parent_folder
                                        parent_folder = tex.get("parent_folder", "")
                                        if parent_folder:
                                            texture_path = os.path.join(project_path, "Resources", "Textures", parent_folder, frame_file)
                                        else:
                                            texture_path = os.path.join(project_path, "Resources", "Textures", frame_file)
                                    
                                    if os.path.exists(texture_path):
                                        self.gl.background_texture_path = texture_path
                                        self.gl.floor_texture_path = texture_path  # Same for floor
                                        # Clear old texture IDs to force reload
                                        if hasattr(self.gl, 'background_texture_id') and self.gl.background_texture_id:
                                            glDeleteTextures([self.gl.background_texture_id])
                                            self.gl.background_texture_id = None
                                        if hasattr(self.gl, 'floor_texture_id') and self.gl.floor_texture_id:
                                            glDeleteTextures([self.gl.floor_texture_id])
                                            self.gl.floor_texture_id = None
                                        debug(f"Loaded background/floor texture from settings: {texture_path}")
                                        # Force update to reload texture
                                        self.gl.update()
                                    else:
                                        # Try alternative path resolution
                                        debug(f"Texture not found at {texture_path}, trying alternatives...")
                                        # Try without parent folder
                                        alt_path = os.path.join(project_path, "Resources", "Textures", frame_file)
                                        if os.path.exists(alt_path):
                                            self.gl.background_texture_path = alt_path
                                            self.gl.floor_texture_path = alt_path
                                            if hasattr(self.gl, 'background_texture_id'):
                                                self.gl.background_texture_id = None
                                            if hasattr(self.gl, 'floor_texture_id'):
                                                self.gl.floor_texture_id = None
                                        else:
                                            self.gl.background_texture_path = ""
                                            self.gl.floor_texture_path = ""
                                            debug(f"Background texture file not found: {frame_file}")
                                break
                    else:
                        self.gl.background_texture_path = ""
                        self.gl.floor_texture_path = ""
                except Exception as e:
                    debug(f"Error loading background texture: {e}")
                    self.gl.background_texture_path = ""
                    self.gl.floor_texture_path = ""
            else:
                self.gl.background_texture_path = ""
                self.gl.floor_texture_path = ""
        
        if hasattr(self.gl, 'skyline_texture_path') and self.app and hasattr(self.app, 'project_manager'):
            # Check per-model setting first
            skyline_texture_id = model_settings.get("skyline_texture_id", None)
            if skyline_texture_id is None:
                skyline_texture_id = settings.get("Model_Skyline_Texture", "")
            else:
                debug(f"Using per-model skyline texture: {skyline_texture_id}")
            if skyline_texture_id:
                # Look up texture resource and get the actual file path
                try:
                    texture_resources = self.app.project_manager.get_resources("textures")
                    for tex in texture_resources:
                        if tex.get("id") == skyline_texture_id:
                            # Get the first frame's file path
                            frames = tex.get("frames", [])
                            if frames and len(frames) > 0:
                                frame_file = frames[0].get("file", "")
                                if frame_file:
                                    # Resolve to full path - frame_file might include subfolder
                                    project_path = self.app.project_manager.project_path
                                    # Check if frame_file already includes path info
                                    if os.path.sep in frame_file or (os.path.altsep and os.path.altsep in frame_file):
                                        # Already has path, use as-is
                                        texture_path = os.path.join(project_path, "Resources", "Textures", frame_file)
                                    else:
                                        # No path, check if texture resource has parent_folder
                                        parent_folder = tex.get("parent_folder", "")
                                        if parent_folder:
                                            texture_path = os.path.join(project_path, "Resources", "Textures", parent_folder, frame_file)
                                        else:
                                            texture_path = os.path.join(project_path, "Resources", "Textures", frame_file)
                                    
                                    if os.path.exists(texture_path):
                                        self.gl.skyline_texture_path = texture_path
                                        # Clear old texture ID to force reload
                                        if hasattr(self.gl, 'skyline_texture_id'):
                                            self.gl.skyline_texture_id = None
                                    else:
                                        # Try alternative path resolution
                                        debug(f"Skyline texture not found at {texture_path}, trying alternatives...")
                                        # Try without parent folder
                                        alt_path = os.path.join(project_path, "Resources", "Textures", frame_file)
                                        if os.path.exists(alt_path):
                                            self.gl.skyline_texture_path = alt_path
                                            if hasattr(self.gl, 'skyline_texture_id'):
                                                self.gl.skyline_texture_id = None
                                        else:
                                            self.gl.skyline_texture_path = ""
                                            debug(f"Skyline texture file not found: {frame_file}")
                                break
                    else:
                        self.gl.skyline_texture_path = ""
                except Exception as e:
                    debug(f"Error loading skyline texture: {e}")
                    self.gl.skyline_texture_path = ""
            else:
                self.gl.skyline_texture_path = ""
        
        # Load texture mapping modes and scales
        if hasattr(self.gl, 'background_texture_mode'):
            # Check per-model settings first
            self.gl.background_texture_mode = str(model_settings.get("background_texture_mode", settings.get("Model_Background_Texture_Mode", "Stretch")))
            self.gl.background_texture_scale_x = float(model_settings.get("background_texture_scale_x", settings.get("Model_Background_Texture_Scale_X", 1.0)))
            self.gl.background_texture_scale_y = float(model_settings.get("background_texture_scale_y", settings.get("Model_Background_Texture_Scale_Y", 1.0)))
            
            # Update UI controls
            if hasattr(self, 'background_texture_mode_combo'):
                index = self.background_texture_mode_combo.findText(self.gl.background_texture_mode)
                if index >= 0:
                    self.background_texture_mode_combo.setCurrentIndex(index)
            if hasattr(self, 'background_scale_x'):
                self.background_scale_x.setValue(self.gl.background_texture_scale_x)
            if hasattr(self, 'background_scale_y'):
                self.background_scale_y.setValue(self.gl.background_texture_scale_y)
                # Show/hide custom scale based on mode
                if hasattr(self, 'background_texture_mode_combo'):
                    is_custom = (self.background_texture_mode_combo.currentText() == "Repeat (Custom)")
                    self.background_scale_x.setVisible(is_custom)
                    self.background_scale_y.setVisible(is_custom)
        
        if hasattr(self.gl, 'skyline_texture_mode'):
            # Check per-model settings first
            self.gl.skyline_texture_mode = str(model_settings.get("skyline_texture_mode", settings.get("Model_Skyline_Texture_Mode", "Stretch")))
            self.gl.skyline_texture_scale_x = float(model_settings.get("skyline_texture_scale_x", settings.get("Model_Skyline_Texture_Scale_X", 1.0)))
            self.gl.skyline_texture_scale_y = float(model_settings.get("skyline_texture_scale_y", settings.get("Model_Skyline_Texture_Scale_Y", 1.0)))
            
            # Update UI controls
            if hasattr(self, 'skyline_texture_mode_combo'):
                index = self.skyline_texture_mode_combo.findText(self.gl.skyline_texture_mode)
                if index >= 0:
                    self.skyline_texture_mode_combo.setCurrentIndex(index)
            if hasattr(self, 'skyline_scale_x'):
                self.skyline_scale_x.setValue(self.gl.skyline_texture_scale_x)
            if hasattr(self, 'skyline_scale_y'):
                self.skyline_scale_y.setValue(self.gl.skyline_texture_scale_y)
                # Show/hide custom scale based on mode
                if hasattr(self, 'skyline_texture_mode_combo'):
                    is_custom = (self.skyline_texture_mode_combo.currentText() == "Repeat (Custom)")
                    self.skyline_scale_x.setVisible(is_custom)
                    self.skyline_scale_y.setVisible(is_custom)
        
        # Update color buttons
        if hasattr(self, '_update_background_color_button'):
            self._update_background_color_button()
        if hasattr(self, '_update_skyline_color_button'):
            self._update_skyline_color_button()
        
        # Populate texture combo boxes
        if hasattr(self, 'background_texture_combo') and self.app and hasattr(self.app, 'project_manager'):
            try:
                texture_resources = self.app.project_manager.get_resources("textures")
                self.background_texture_combo.clear()
                self.background_texture_combo.addItem("None (use color)")
                # Check per-model setting first
                current_texture_id = model_settings.get("background_texture_id", settings.get("Model_Background_Texture", ""))
                current_index = 0
                for i, tex in enumerate(texture_resources):
                    self.background_texture_combo.addItem(tex.get("name", "Unknown"))
                    if tex.get("id") == current_texture_id:
                        current_index = i + 1
                self.background_texture_combo.setCurrentIndex(current_index)
            except:
                pass
        
        if hasattr(self, 'skyline_texture_combo') and self.app and hasattr(self.app, 'project_manager'):
            try:
                texture_resources = self.app.project_manager.get_resources("textures")
                self.skyline_texture_combo.clear()
                self.skyline_texture_combo.addItem("None (use color)")
                # Check per-model setting first
                current_texture_id = model_settings.get("skyline_texture_id", settings.get("Model_Skyline_Texture", ""))
                current_index = 0
                for i, tex in enumerate(texture_resources):
                    self.skyline_texture_combo.addItem(tex.get("name", "Unknown"))
                    if tex.get("id") == current_texture_id:
                        current_index = i + 1
                self.skyline_texture_combo.setCurrentIndex(current_index)
            except:
                pass
        
        # Force texture reload by clearing texture IDs
        if hasattr(self.gl, 'background_texture_path') and self.gl.background_texture_path:
            if hasattr(self.gl, 'background_texture_id'):
                self.gl.background_texture_id = None
            if hasattr(self.gl, 'floor_texture_id'):
                self.gl.floor_texture_id = None
        
        if hasattr(self.gl, 'skyline_texture_path') and self.gl.skyline_texture_path:
            if hasattr(self.gl, 'skyline_texture_id'):
                self.gl.skyline_texture_id = None
        
        # Refresh view
        if hasattr(self, '_refresh_model_view'):
            self._refresh_model_view()
    
    def _save_model_editor_settings(self):
        """Save Model Editor specific settings to preferences"""
        if not self.app or not hasattr(self.app, 'settings'):
            return
        
        settings = self.app.settings
        
        # Save lighting style
        if hasattr(self.gl, 'lighting_style'):
            settings.set("Model_Editor_Lighting_Style", self.gl.lighting_style)
        
        # Save external light settings
        if hasattr(self.gl, 'external_light_enabled'):
            settings.set("Model_Editor_External_Light_Enabled", self.gl.external_light_enabled)
            settings.set("Model_Editor_External_Light_Brightness", self.gl.external_light_brightness)
            settings.set("Model_Editor_Light_Position_Mode", self.gl.light_position_mode)
        
        # Save preview settings
        if hasattr(self.gl, 'model_lit'):
            settings.set("Model_Editor_Model_Lit", self.gl.model_lit)
        
        # Save preview scale
        if hasattr(self, 'preview_scale_spin'):
            settings.set("Model_Editor_Preview_Scale", self.preview_scale_spin.value())
        
        # Save background/floor settings
        if hasattr(self.gl, 'background_color'):
            settings.set("Model_Background_Color", self.gl.background_color.name())
        if hasattr(self.gl, 'background_texture_mode'):
            settings.set("Model_Background_Texture_Mode", self.gl.background_texture_mode)
            settings.set("Model_Background_Texture_Scale_X", self.gl.background_texture_scale_x)
            settings.set("Model_Background_Texture_Scale_Y", self.gl.background_texture_scale_y)
        
        # Save skyline settings
        if hasattr(self.gl, 'skyline_color'):
            settings.set("Model_Skyline_Color", self.gl.skyline_color.name())
        if hasattr(self.gl, 'skyline_texture_mode'):
            settings.set("Model_Skyline_Texture_Mode", self.gl.skyline_texture_mode)
            settings.set("Model_Skyline_Texture_Scale_X", self.gl.skyline_texture_scale_x)
            settings.set("Model_Skyline_Texture_Scale_Y", self.gl.skyline_texture_scale_y)
        
        # Sync settings
        settings.sync()
    
    def toggle_fullscreen(self):
        """Toggle fullscreen mode"""
        if hasattr(self, '_is_fullscreen'):
            if self._is_fullscreen:
                # Exit fullscreen
                self.showNormal()
                self._is_fullscreen = False
            else:
                # Enter fullscreen
                self.showFullScreen()
                self._is_fullscreen = True
        else:
            # First time - enter fullscreen
            self.showFullScreen()
            self._is_fullscreen = True
    
    
    def exit_edit_mode_old(self):
        """Exit edit mode and return to preview (old implementation)"""
        if hasattr(self, 'model_creator_widget') and self.model_creator_widget:
            # If in fullscreen, close fullscreen first
            if self.model_creator_widget.is_fullscreen and self.model_creator_widget.fullscreen_window:
                self.model_creator_widget.toggle_fullscreen()
            
            # Get edited model data
            if hasattr(self.model_creator_widget.gl_widget, 'vertices') and self.model_creator_widget.gl_widget.vertices is not None:
                # Export edited geometry back to preview
                vertices, indices, normals = self.model_creator_widget.gl_widget.export_to_arrays()
                if vertices is not None and indices is not None:
                    self.gl.vertices = vertices
                    self.gl.indices = indices
                    self.gl.normals = normals if normals is not None else self.gl._calculate_normals()
                    self.gl._geometry_dirty = True
                    self.gl.update()
            
            # Remove ModelCreator widget and restore preview
            if hasattr(self, 'preview_panel'):
                layout = self.preview_panel.layout()
                if layout:
                    for i in range(layout.count()):
                        item = layout.itemAt(i)
                        if item and item.widget() == self.model_creator_widget:
                            layout.removeWidget(self.model_creator_widget)
                            self.model_creator_widget.hide()
                            
                            # Restore GL widget
                            layout.addWidget(self.gl)
                            self.gl.show()
                            break
            
            self.model_creator_widget = None
            self._update_create_edit_button()
    
    def _on_model_creator_saved(self, updated_resource_data):
        """Handle model saved from ModelCreator"""
        debug(f"ModelCreator saved model: {updated_resource_data.get('name')}")
        # Update our resource_data with changes from ModelCreator
        self.resource_data.update(updated_resource_data)
        # Reload the model in ModelEditor's preview to reflect changes
        self.load_resource_data()
        self._update_create_edit_button()
    
    def _update_dimensions_display(self):
        """Update the model dimensions display in the properties panel"""
        if not hasattr(self, 'gl') or not self.gl:
            return
        
        # Get theme colors from app if available
        text_color = "#ffffff"  # Default for dark theme
        disabled_color = "#808080"
        
        if self.app and hasattr(self.app, 'theme_manager'):
            colors = self.app.theme_manager.get_colors()
            text_color = colors.get('text_primary', '#ffffff')
            disabled_color = colors.get('text_disabled', '#808080')
        
        if hasattr(self.gl, 'model_size') and self.gl.model_size is not None:
            # model_size is [width (X), height (Y), length (Z)]
            width = self.gl.model_size[0]
            height = self.gl.model_size[1]
            length = self.gl.model_size[2]
            
            if hasattr(self, 'width_label'):
                self.width_label.setText(f"{width:.2f} units")
                self.width_label.setStyleSheet(f"color: {text_color};")
            if hasattr(self, 'height_label'):
                self.height_label.setText(f"{height:.2f} units")
                self.height_label.setStyleSheet(f"color: {text_color};")
            if hasattr(self, 'length_label'):
                self.length_label.setText(f"{length:.2f} units")
                self.length_label.setStyleSheet(f"color: {text_color};")
        else:
            # No model loaded
            if hasattr(self, 'width_label'):
                self.width_label.setText("N/A")
                self.width_label.setStyleSheet(f"color: {disabled_color};")
            if hasattr(self, 'height_label'):
                self.height_label.setText("N/A")
                self.height_label.setStyleSheet(f"color: {disabled_color};")
            if hasattr(self, 'length_label'):
                self.length_label.setText("N/A")
                self.length_label.setStyleSheet(f"color: {disabled_color};")

    def open_resource(self, resource_data: Dict) -> bool:
        """Load resource data into the editor (EditorInterface implementation)"""
        try:
            self.resource_data = resource_data
            self._dirty = False
            self.load_resource_data()
            return True
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to load resource: {str(e)}")
            return False
    
    def load_resource_data(self):
        """Load model from resource data and populate UI (legacy method)"""
        if not self.resource_data:
            debug("load_resource_data: No resource_data")
            return
        
        # Migrate old models: If texture_paths is missing but texture_files exists, generate texture_paths
        # This ensures texture_paths is always the single source of truth
        if not self.resource_data.get("texture_paths") and self.resource_data.get("texture_files"):
            model_name = self.resource_data.get("name", "")
            texture_files = self.resource_data.get("texture_files", [])
            if model_name and texture_files:
                debug(f"Migrating old model: Generating texture_paths from texture_files for '{model_name}'")
                texture_paths = []
                for tex_file in texture_files:
                    # Format: "ModelName/texture.png" relative to Resources/Textures
                    texture_paths.append(f"{model_name}/{tex_file}")
                self.resource_data["texture_paths"] = texture_paths
                # Save the migrated model file
                if self.app and hasattr(self.app, 'resource_manager'):
                    try:
                        self.app.resource_manager.save_resource_file_only("models", self.resource_data)
                        debug(f"Migrated model: Set texture_paths as single source of truth")
                    except Exception as e:
                        debug(f"Failed to save migrated model: {e}")
        
        # Populate name field
        if hasattr(self, 'name_edit'):
            model_name = self.resource_data.get("name", "")
            self.name_edit.setText(model_name)
        
        # Get model file path - always use model_file (relative filename)
        model_file = self.resource_data.get("model_file")
        original_model_file = self.resource_data.get("original_model_file")
        
        # Migration: Fix old format where original_model_file was an absolute path
        # If original_model_file looks like an absolute path, extract just the filename
        if original_model_file and (os.path.isabs(original_model_file) or os.path.sep in original_model_file):
            # Extract just the filename
            self.resource_data["original_model_file"] = os.path.basename(original_model_file)
            # Save the fixed resource file
            if self.app and hasattr(self.app, 'resource_manager'):
                try:
                    self.app.resource_manager.save_resource_file_only("models", self.resource_data)
                    debug(f"load_resource_data: Migrated original_model_file to filename format")
                except Exception as e:
                    debug(f"load_resource_data: Failed to save migrated resource: {e}")
        
        if not model_file:
            debug("load_resource_data: No model_file in resource_data")
            return
        
        if not self.app:
            debug("load_resource_data: No app reference")
            return
        
        # Always construct path from model_file (relative filename)
        models_folder = os.path.join(
            self.app.project_manager.get_project_path(),
            "Resources", "Models"
        )
        
        parent_folder = self.resource_data.get("parent_folder", "")
        if parent_folder:
            models_folder = os.path.join(models_folder, parent_folder)
        
        # model_file should be just the filename
        model_filename = os.path.basename(model_file)  # Safety: extract filename
        model_path = os.path.normpath(os.path.join(models_folder, model_filename))
        
        debug(f"load_resource_data: Looking for model at: {model_path}")
        
        if os.path.exists(model_path):
            try:
                # Get scale from resource data (if specified)
                scale = self.resource_data.get("scale", 1.0)
                self.gl._resource_scale = scale  # Store for use in load methods
                
                ext = model_path.lower().split('.')[-1]
                debug(f"load_resource_data: Loading {ext} file: {model_path}, scale: {scale}")
                if ext == 'obj':
                    self.gl.load_obj(model_path)
                    
                    # If MTL file wasn't loaded during OBJ parsing, try loading from resource_data
                    if not self.gl.materials and self.resource_data.get("mtl_file"):
                        mtl_file = self.resource_data.get("mtl_file")
                        mtl_path = os.path.normpath(os.path.join(models_folder, mtl_file))
                        if os.path.exists(mtl_path):
                            debug(f"Loading MTL from resource_data: {mtl_path}")
                            mtl_dir = os.path.dirname(os.path.abspath(mtl_path))
                            self.gl._load_mtl(mtl_path, mtl_dir)
                        else:
                            debug(f"MTL file from resource_data not found: {mtl_path}")
                    
                elif ext in ('glb', 'gltf'):
                    self.gl.load_gltf(model_path)
                elif ext == 'dae':
                    self.gl.load_dae(model_path)
                elif ext == 'model':
                    self.gl.load_json_model(model_path)
                else:
                    QMessageBox.warning(self, "Unsupported Format", f"Unsupported model format: {ext}")
                    return
                
                # Update animation UI after loading
                self._update_animation_combo()
                
                # Show Import to JSON Model button after loading
                if hasattr(self, 'import_json_btn'):
                    self.import_json_btn.setVisible(True)
                
                self.file_label.setText(os.path.basename(model_path))
                debug(f"load_resource_data: Successfully loaded model")
                debug(f"Materials after load: {len(self.gl.materials)}")
                if self.gl.materials:
                    debug(f"Material names: {list(self.gl.materials.keys())}")
                
                # Initialize brightness controls if they exist
                if hasattr(self, 'internal_brightness_spin') and hasattr(self.gl, 'internal_light_brightness'):
                    self.gl.internal_light_brightness = self.internal_brightness_spin.value()
                if hasattr(self, 'external_brightness_spin') and hasattr(self.gl, 'external_light_brightness'):
                    self.gl.external_light_brightness = self.external_brightness_spin.value()
                
                # Update model dimensions display
                self._update_dimensions_display()
                
                # Update create/edit button text
                self._update_create_edit_button()
                
                # Copy textures to Resources\Textures\ModelName\ folder and create texture resources
                model_name = self.resource_data.get("name", os.path.splitext(os.path.basename(model_file))[0])
                textures_folder = os.path.join(
                    self.app.project_manager.get_project_path(),
                    "Resources", "Textures", model_name
                )
                
                # Load textures - texture_paths is the single source of truth
                texture_paths_to_load = []
                textures_base_folder = os.path.join(
                    self.app.project_manager.get_project_path(),
                    "Resources", "Textures"
                )
                
                # PRIMARY STRATEGY: Use texture_paths from .Model file (single source of truth)
                # Format: "ModelName/texture.png" relative to Resources/Textures
                texture_paths = self.resource_data.get("texture_paths", [])
                if texture_paths:
                    debug(f"Using texture_paths as single source of truth: {len(texture_paths)} texture(s)")
                    for tex_path_rel in texture_paths:
                        # Normalize path separators (handle both / and \)
                        tex_path_normalized = tex_path_rel.replace('\\', os.path.sep).replace('/', os.path.sep)
                        # Split into components and join properly
                        path_parts = [p for p in tex_path_normalized.split(os.path.sep) if p]
                        full_tex_path = os.path.join(textures_base_folder, *path_parts)
                        full_tex_path = os.path.normpath(full_tex_path)
                        if os.path.exists(full_tex_path):
                            if full_tex_path not in texture_paths_to_load:
                                texture_paths_to_load.append(full_tex_path)
                                debug(f"  ✓ Found texture from texture_paths: {full_tex_path}")
                        else:
                            debug(f"  ✗ Texture path not found: {full_tex_path}")
                
                # FALLBACK STRATEGY 1: If texture_paths is empty, try texture_files array
                # This handles old models that were imported before texture_paths was implemented
                if not texture_paths_to_load:
                    texture_files = self.resource_data.get("texture_files", [])
                    if texture_files:
                        debug(f"Fallback: Checking {len(texture_files)} texture files from texture_files array")
                        debug(f"  Textures folder: {textures_folder}")
                        debug(f"  Models folder: {models_folder}")
                        for tex_file in texture_files:
                            # First try Textures/ModelName folder (new organized structure)
                            tex_path_in_textures = os.path.join(textures_folder, tex_file)
                            tex_path_in_textures = os.path.normpath(tex_path_in_textures)
                            if os.path.exists(tex_path_in_textures):
                                if tex_path_in_textures not in texture_paths_to_load:
                                    texture_paths_to_load.append(tex_path_in_textures)
                                    debug(f"  ✓ Found texture in Textures/{model_name} folder: {tex_path_in_textures}")
                            else:
                                # Fallback: try Models folder (backwards compatibility)
                                tex_path_in_models = os.path.join(models_folder, tex_file)
                                tex_path_in_models = os.path.normpath(tex_path_in_models)
                                if os.path.exists(tex_path_in_models):
                                    if tex_path_in_models not in texture_paths_to_load:
                                        texture_paths_to_load.append(tex_path_in_models)
                                        debug(f"  ✓ Found texture in Models folder: {tex_path_in_models}")
                
                # FALLBACK STRATEGY 2: Check MTL references (for models where texture_paths wasn't set)
                if not texture_paths_to_load and hasattr(self.gl, 'materials') and self.gl.materials:
                    debug("Fallback: Checking MTL material texture references")
                    for mat_name, mat_data in self.gl.materials.items():
                        tex_ref = mat_data.get('texture', '')
                        if tex_ref:
                            # Check if it's a Textures/ reference (from updated MTL)
                            if 'Textures' in tex_ref or tex_ref.startswith('Textures'):
                                # Resolve relative to project
                                # Format: Textures\ModelName\texture.png or Textures/ModelName/texture.png
                                tex_path_normalized = tex_ref.replace('\\', os.path.sep).replace('/', os.path.sep)
                                if tex_path_normalized.startswith('Textures'):
                                    tex_path_normalized = tex_path_normalized[len('Textures'):].lstrip(os.path.sep)
                                full_tex_path = os.path.join(textures_base_folder, tex_path_normalized)
                                if os.path.exists(full_tex_path):
                                    if full_tex_path not in texture_paths_to_load:
                                        texture_paths_to_load.append(full_tex_path)
                                        debug(f"  ✓ Found texture from MTL reference: {full_tex_path}")
                
                # Load textures
                if texture_paths_to_load:
                    debug(f"Loading {len(texture_paths_to_load)} texture(s) from texture_paths")
                    debug(f"Texture paths to load: {texture_paths_to_load}")
                    debug(f"Materials before loading: {list(self.gl.materials.keys()) if hasattr(self.gl, 'materials') else 'No materials'}")
                    self.gl.load_textures_from_files(texture_paths_to_load)
                    debug(f"Textures after loading: {list(self.gl.textures.keys()) if hasattr(self.gl, 'textures') else 'No textures dict'}")
                    debug(f"Materials after loading: {list(self.gl.materials.keys()) if hasattr(self.gl, 'materials') else 'No materials'}")
                    self._update_dimensions_display()
                    self._refresh_model_view()
                else:
                    debug(f"No textures to load for model '{model_name}'")
                    debug(f"  texture_paths in resource_data: {self.resource_data.get('texture_paths', [])}")
                    debug(f"  texture_files in resource_data: {self.resource_data.get('texture_files', [])}")
                    debug(f"  materials: {list(self.gl.materials.keys()) if hasattr(self.gl, 'materials') and self.gl.materials else 'No materials'}")
                    # If materials have texture references but we haven't loaded them, try loading from material texture paths
                    if hasattr(self.gl, 'materials') and self.gl.materials:
                        material_tex_paths = []
                        for mat_name, mat_data in self.gl.materials.items():
                            tex_path = mat_data.get('texture', '')
                            debug(f"  Material '{mat_name}' has texture reference: {tex_path}")
                            if tex_path:
                                # Try to resolve the texture path
                                # Could be relative to Textures folder, Models folder, or absolute
                                resolved_paths = []
                                
                                # Try as-is (absolute or relative to current dir)
                                if os.path.exists(tex_path):
                                    resolved_paths.append(tex_path)
                                
                                # Try relative to Textures/ModelName
                                tex_in_textures = os.path.join(textures_folder, os.path.basename(tex_path))
                                if os.path.exists(tex_in_textures):
                                    resolved_paths.append(tex_in_textures)
                                
                                # Try relative to Models folder
                                tex_in_models = os.path.join(models_folder, os.path.basename(tex_path))
                                if os.path.exists(tex_in_models):
                                    resolved_paths.append(tex_in_models)
                                
                                if resolved_paths:
                                    material_tex_paths.append(resolved_paths[0])
                                    debug(f"    Resolved to: {resolved_paths[0]}")
                                
                        if material_tex_paths:
                            debug(f"Loading {len(material_tex_paths)} texture(s) from material references")
                            self.gl.load_textures_from_files(material_tex_paths)
                            self._update_dimensions_display()
                            self._refresh_model_view()
                        else:
                            debug(f"  No valid texture paths found from material references")
            except Exception as e:
                debug(f"load_resource_data: Exception loading model: {e}")
                import traceback
                traceback.print_exc()
                QMessageBox.warning(self, "Load Error", f"Failed to load model: {str(e)}")
        else:
            debug(f"load_resource_data: Model file not found: {model_path}")
            self.file_label.setText("Model file not found")
        
        # Enable Manage Textures button if model is loaded
        if hasattr(self, 'manage_textures_btn') and hasattr(self.gl, 'vertices') and self.gl.vertices is not None and len(self.gl.vertices) > 0:
            self.manage_textures_btn.setEnabled(True)
        else:
            if hasattr(self, 'manage_textures_btn'):
                self.manage_textures_btn.setEnabled(False)

    def load_model_file(self):
        """Open file dialog to load model file (OBJ, GLB/GLTF)"""
        filters = "Model Files (*.obj *.glb *.gltf *.dae *.g3d *.Model);;Wavefront OBJ (*.obj);;glTF Binary (*.glb);;glTF JSON (*.gltf);;Collada DAE (*.dae);;LibGDX G3D (*.g3d);;PyGenesis Model (*.Model);;All Files (*.*)"
        file_path, _ = QFileDialog.getOpenFileName(
            self,
            "Load Model File",
            "",
            filters
        )
        
        if file_path:
            self.load_model_file_from_path(file_path)
            # Enable Import to JSON Model button after loading
            if hasattr(self, 'manage_textures_btn'):
                self.manage_textures_btn.setEnabled(True)
        
        # Also enable button when loading from resource data
        if hasattr(self, 'import_json_btn') and hasattr(self.gl, 'vertices') and self.gl.vertices is not None and len(self.gl.vertices) > 0:
            self.import_json_btn.setEnabled(True)
        else:
            if hasattr(self, 'import_json_btn'):
                self.import_json_btn.setEnabled(False)
    
    def _get_model_directory(self):
        """Get the directory where the current model file is located"""
        if hasattr(self.gl, 'model_dir') and self.gl.model_dir:
            return self.gl.model_dir
        elif hasattr(self, 'resource_data') and self.resource_data:
            model_file = self.resource_data.get("model_file")
            if model_file and self.app:
                models_folder = os.path.join(self.app.project_manager.get_project_path(), "Resources", "Models")
                parent_folder = self.resource_data.get("parent_folder", "")
                if parent_folder:
                    models_folder = os.path.join(models_folder, parent_folder)
                if os.path.exists(models_folder):
                    return models_folder
        return ""
    
    def _detect_related_model_files(self):
        """Detect related model files in the same directory (DAE, OBJ, GLB with similar names).
        
        Returns:
            dict with keys: 'dae_files', 'obj_files', 'glb_files', 'gltf_files'
            Each contains list of (filename, full_path) tuples
        """
        model_dir = self._get_model_directory()
        if not model_dir or not os.path.exists(model_dir):
            return {'dae_files': [], 'obj_files': [], 'glb_files': [], 'gltf_files': []}
        
        # Get current model filename (without extension) for matching
        current_model_name = None
        if hasattr(self, 'resource_data') and self.resource_data:
            model_file = self.resource_data.get("model_file", "")
            if model_file:
                current_model_name = os.path.splitext(os.path.basename(model_file))[0]
        
        related_files = {
            'dae_files': [],
            'obj_files': [],
            'glb_files': [],
            'gltf_files': []
        }
        
        # Scan directory for related files
        for filename in os.listdir(model_dir):
            file_path = os.path.join(model_dir, filename)
            if not os.path.isfile(file_path):
                continue
            
            name_lower = filename.lower()
            base_name = os.path.splitext(filename)[0]
            
            # Check if filename is related (same base name or similar)
            is_related = False
            if current_model_name:
                # Exact match (different extension)
                if base_name.lower() == current_model_name.lower():
                    is_related = True
                # Similar name (e.g., "Diamond Steppe Island (Baked Colors)")
                elif current_model_name.lower() in base_name.lower() or base_name.lower() in current_model_name.lower():
                    is_related = True
            else:
                # If no current model, include all model files
                is_related = True
            
            if is_related:
                if name_lower.endswith('.dae'):
                    related_files['dae_files'].append((filename, file_path))
                elif name_lower.endswith('.obj'):
                    related_files['obj_files'].append((filename, file_path))
                elif name_lower.endswith('.glb'):
                    related_files['glb_files'].append((filename, file_path))
                elif name_lower.endswith('.gltf'):
                    related_files['gltf_files'].append((filename, file_path))
        
        # Sort by filename
        for key in related_files:
            related_files[key].sort(key=lambda x: x[0])
        
        return related_files
    
    def _detect_related_files_for_import(self, source_dir: str, source_model_name: str):
        """Detect related model files in source directory for import.
        
        Args:
            source_dir: Directory to scan for related files
            source_model_name: Base name of the model being imported (without extension)
            
        Returns:
            dict with categorized files:
            - 'baked_versions': Files with "baked", "bake", "color" in name
            - 'animation_files': Files that might contain animations
            - 'other_formats': Same model in different formats (OBJ, DAE, GLB)
            - 'mtl_files': MTL files that could apply to related models
            - 'texture_files': Texture images in the directory
        """
        if not source_dir or not os.path.exists(source_dir):
            return {
                'baked_versions': [],
                'animation_files': [],
                'other_formats': [],
                'mtl_files': [],
                'texture_files': []
            }
        
        categorized = {
            'baked_versions': [],
            'animation_files': [],
            'other_formats': [],
            'mtl_files': [],
            'texture_files': []
        }
        
        # Keywords to identify file types
        baked_keywords = ['baked', 'bake', 'vertexcolor', 'vertex_color', 'vc']
        animation_keywords = ['anim', 'animation', 'animdata', 'motion', 'keyframe', 'skeleton', 'rig', 'bones']
        model_extensions = ['.obj', '.dae', '.glb', '.gltf', '.g3d', '.fbx', '.bvh', '.smd']
        texture_extensions = ['.png', '.jpg', '.jpeg', '.bmp', '.tga', '.tiff', '.tif']
        
        # Additional animation file extensions
        animation_extensions = ['.anim', '.animation', '.dae', '.gltf', '.glb', '.fbx', '.bvh', '.smd', '.xanim']
        
        for filename in os.listdir(source_dir):
            file_path = os.path.join(source_dir, filename)
            if not os.path.isfile(file_path):
                continue
            
            name_lower = filename.lower()
            base_name = os.path.splitext(filename)[0]
            ext = os.path.splitext(filename)[1].lower()
            
            # Check if related to source model (same base name or similar)
            is_related = False
            if source_model_name:
                if base_name.lower() == source_model_name.lower():
                    is_related = True
                elif (source_model_name.lower() in base_name.lower() or 
                      base_name.lower() in source_model_name.lower()):
                    is_related = True
            
            # Skip the file we just imported
            if base_name.lower() == source_model_name.lower() and ext in model_extensions:
                continue
            
            # Categorize files
            if ext in model_extensions and is_related:
                # Check if it's a baked version
                if any(keyword in name_lower for keyword in baked_keywords):
                    categorized['baked_versions'].append((filename, file_path))
                # Check if it might contain animations (by name or extension)
                elif (any(keyword in name_lower for keyword in animation_keywords) or 
                      ext in animation_extensions):
                    # Also check file content to verify it contains animation data
                    if self._check_file_contains_animations(file_path, ext):
                        categorized['animation_files'].append((filename, file_path))
                    else:
                        # Might still be an animation file, just can't verify
                        categorized['animation_files'].append((filename, file_path))
                # Otherwise it's the same model in different format
                else:
                    categorized['other_formats'].append((filename, file_path))
            
            # Check standalone animation files (not model files)
            elif ext in animation_extensions and ext not in model_extensions:
                # These are likely pure animation files
                if is_related or any(keyword in name_lower for keyword in animation_keywords):
                    categorized['animation_files'].append((filename, file_path))
            
            elif ext == '.mtl' and is_related:
                categorized['mtl_files'].append((filename, file_path))
            
            elif ext in texture_extensions:
                # Include all textures - they might apply to related models
                categorized['texture_files'].append((filename, file_path))
        
        # Sort all lists by filename
        for key in categorized:
            categorized[key].sort(key=lambda x: x[0])
        
        return categorized
    
    def _check_file_contains_animations(self, file_path: str, ext: str) -> bool:
        """Check if a file actually contains animation data.
        
        This performs basic content checks to verify animation data exists,
        rather than just relying on filename patterns.
        
        Args:
            file_path: Path to the file to check
            ext: File extension
            
        Returns:
            bool: True if file appears to contain animation data
        """
        if not os.path.exists(file_path) or not os.path.isfile(file_path):
            return False
        
        try:
            # For DAE files, check for <animation> or <library_animation_clips> elements
            if ext == '.dae':
                try:
                    import xml.etree.ElementTree as ET
                    tree = ET.parse(file_path)
                    root = tree.getroot()
                    ns = {'collada': 'http://www.collada.org/2005/11/COLLADASchema'}
                    # Check for animation elements
                    if (root.find('.//collada:animation', ns) is not None or
                        root.find('.//collada:library_animation_clips', ns) is not None):
                        return True
                except Exception:
                    pass
            
            # For GLTF files, check JSON for animations array
            elif ext == '.gltf':
                try:
                    import json
                    with open(file_path, 'r', encoding='utf-8') as f:
                        data = f.read(1024)  # Read first 1KB
                        if '"animations"' in data or '"animation"' in data:
                            # Full parse to verify
                            f.seek(0)
                            gltf_data = json.load(f)
                            if 'animations' in gltf_data and len(gltf_data['animations']) > 0:
                                return True
                except Exception:
                    pass
            
            # For GLB files, check binary format (simplified - just check if it's a GLB)
            elif ext == '.glb':
                try:
                    with open(file_path, 'rb') as f:
                        header = f.read(12)
                        # GLB files start with "glTF" magic
                        if header[:4] == b'glTF':
                            # Try to read JSON chunk to check for animations
                            json_length = int.from_bytes(header[8:12], byteorder='little')
                            json_data = f.read(min(json_length, 4096))  # Read up to 4KB
                            if b'"animations"' in json_data:
                                return True
                except Exception:
                    pass
            
            # For FBX files, check for animation markers (simplified check)
            elif ext == '.fbx':
                try:
                    with open(file_path, 'rb') as f:
                        data = f.read(2048)
                        # FBX files contain various markers - look for common animation-related strings
                        if b'Animation' in data or b'AnimStack' in data or b'AnimLayer' in data:
                            return True
                except Exception:
                    pass
            
            # For BVH files, check format
            elif ext == '.bvh':
                try:
                    with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                        first_lines = f.read(512)
                        if 'HIERARCHY' in first_lines and 'MOTION' in first_lines:
                            return True
                except Exception:
                    pass
        
        except Exception as e:
            debug(f"Error checking file for animations: {e}")
        
        return False
    
    def _prompt_and_import_related_files(self, source_dir: str, source_model_name: str, project_models_folder: str):
        """Detect related files and prompt user to import them.
        
        Args:
            source_dir: Directory where the original file was imported from
            source_model_name: Base name of the imported model
            project_models_folder: Project's Models folder where files should be copied
        """
        # Detect related files
        related_files = self._detect_related_files_for_import(source_dir, source_model_name)
        
        # Count total related files
        total_files = (len(related_files['baked_versions']) + 
                      len(related_files['animation_files']) + 
                      len(related_files['other_formats']) + 
                      len(related_files['mtl_files']))
        
        if total_files == 0:
            # No related files found, skip prompt
            return
        
        # Build message for user
        message = f"Found {total_files} related file(s) in the import directory:\n\n"
        
        if related_files['baked_versions']:
            message += f"Baked/Color Versions ({len(related_files['baked_versions'])}):\n"
            for filename, _ in related_files['baked_versions']:
                message += f"  • {filename}\n"
            message += "\n"
        
        if related_files['animation_files']:
            message += f"Animation Files ({len(related_files['animation_files'])}):\n"
            for filename, _ in related_files['animation_files']:
                message += f"  • {filename}\n"
            message += "\n"
        
        if related_files['other_formats']:
            message += f"Other Formats ({len(related_files['other_formats'])}):\n"
            for filename, _ in related_files['other_formats']:
                message += f"  • {filename}\n"
            message += "\n"
        
        if related_files['mtl_files']:
            message += f"Material Files ({len(related_files['mtl_files'])}):\n"
            for filename, _ in related_files['mtl_files']:
                message += f"  • {filename}\n"
            message += "\n"
        
        message += "Would you like to import these related files?\n\n"
        message += "They will be copied to the project and associated with textures/materials."
        
        # Show dialog
        reply = QMessageBox.question(
            self,
            "Import Related Files?",
            message,
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.Yes
        )
        
        if reply == QMessageBox.Yes:
            self._import_related_files(related_files, source_dir, project_models_folder, source_model_name)
    
    def _import_related_files(self, related_files: dict, source_dir: str, project_models_folder: str, source_model_name: str):
        """Import the selected related files into the project.
        
        Args:
            related_files: Categorized dict of files to import
            source_dir: Source directory where files are located
            project_models_folder: Project's Models folder
            source_model_name: Base name of the original model
        """
        imported_count = 0
        errors = []
        
        # Import model files (baked versions, animations, other formats)
        model_files = (related_files['baked_versions'] + 
                      related_files['animation_files'] + 
                      related_files['other_formats'])
        
        for filename, source_path in model_files:
            try:
                # Create a temporary resource data for this related file
                # We'll create a new resource for each related file
                related_resource = {
                    "name": os.path.splitext(filename)[0],
                    "model_file": filename,
                    "format": os.path.splitext(filename)[1][1:].lower(),  # Remove dot
                    "mtl_file": None,
                    "texture_files": [],
                    "parent_folder": self.resource_data.get("parent_folder", "")
                }
                
                # Copy the model file using resource manager
                if hasattr(self.app, 'resource_manager'):
                    success = self.app.resource_manager._copy_model_file(related_resource, source_path)
                    if success:
                        # Try to find and copy associated MTL/textures
                        # Look for MTL with same base name
                        base_name = os.path.splitext(filename)[0]
                        mtl_candidates = [
                            base_name + '.mtl',
                            source_model_name + '.mtl',
                            base_name + ' (Low Poly).mtl'
                        ]
                        
                        for mtl_name in mtl_candidates:
                            mtl_source = os.path.join(source_dir, mtl_name)
                            if os.path.exists(mtl_source):
                                # Copy MTL and update resource
                                mtl_dest = os.path.join(project_models_folder, os.path.basename(mtl_name))
                                if not os.path.exists(mtl_dest):
                                    shutil.copy2(mtl_source, mtl_dest)
                                related_resource["mtl_file"] = os.path.basename(mtl_name)
                                
                                # Parse MTL to find texture references (without needing OpenGL context)
                                try:
                                    texture_files = []
                                    with open(mtl_source, "r", encoding="utf-8", errors="ignore") as f:
                                        for line in f:
                                            line = line.strip()
                                            # Look for texture map lines
                                            if line.startswith("map_Kd ") or line.startswith("map_diffuse "):
                                                parts = line.split()
                                                if len(parts) >= 2:
                                                    # Handle spaces in filename
                                                    if len(parts) > 2:
                                                        tex_file = " ".join(parts[1:])
                                                    else:
                                                        tex_file = parts[1]
                                                    
                                                    tex_basename = os.path.basename(tex_file)
                                                    tex_source_path = os.path.join(source_dir, tex_basename)
                                                    if os.path.exists(tex_source_path):
                                                        tex_dest = os.path.join(project_models_folder, tex_basename)
                                                        if not os.path.exists(tex_dest):
                                                            shutil.copy2(tex_source_path, tex_dest)
                                                        if tex_basename not in texture_files:
                                                            texture_files.append(tex_basename)
                                    
                                    if texture_files:
                                        related_resource["texture_files"] = texture_files
                                except Exception as e:
                                    debug(f"Could not parse MTL for related file {filename}: {e}")
                                    import traceback
                                    traceback.print_exc()
                                
                                break
                        
                        # Also copy any texture files found in the directory that match
                        # (this helps with baked DAE files that might need textures)
                        for tex_filename, tex_source in related_files['texture_files']:
                            tex_dest = os.path.join(project_models_folder, tex_filename)
                            if not os.path.exists(tex_dest):
                                shutil.copy2(tex_source, tex_dest)
                            if tex_filename not in related_resource["texture_files"]:
                                related_resource["texture_files"].append(tex_filename)
                        
                        # Save the resource as a new model resource
                        # Use the resource manager's create_resource method to properly set up the resource
                        created_resource = self.app.resource_manager.create_resource("models", related_resource["name"], 
                                                                                   related_resource.get("parent_folder", ""))
                        if created_resource:
                            # Update with our imported data
                            created_resource.update(related_resource)
                            # Save it (save_resource takes resource_type and resource_data)
                            self.app.resource_manager.save_resource("models", created_resource)
                        
                        imported_count += 1
                        debug(f"Imported related file: {filename}")
                    else:
                        errors.append(f"Failed to copy {filename}")
                else:
                    errors.append(f"Resource manager not available")
                    
            except Exception as e:
                errors.append(f"{filename}: {str(e)}")
                import traceback
                traceback.print_exc()
        
        # Import standalone MTL files (that weren't associated with models above)
        for filename, source_path in related_files['mtl_files']:
            try:
                mtl_dest = os.path.join(project_models_folder, filename)
                if not os.path.exists(mtl_dest):
                    shutil.copy2(source_path, mtl_dest)
                    debug(f"Imported MTL file: {filename}")
            except Exception as e:
                errors.append(f"MTL {filename}: {str(e)}")
        
        # Copy texture files that weren't already copied
        for filename, source_path in related_files['texture_files']:
            try:
                tex_dest = os.path.join(project_models_folder, filename)
                if not os.path.exists(tex_dest):
                    shutil.copy2(source_path, tex_dest)
                    debug(f"Imported texture file: {filename}")
            except Exception as e:
                errors.append(f"Texture {filename}: {str(e)}")
        
        # Show results
        if imported_count > 0:
            result_msg = f"Successfully imported {imported_count} related file(s)."
            if errors:
                result_msg += f"\n\nErrors:\n" + "\n".join(errors[:5])
                if len(errors) > 5:
                    result_msg += f"\n... and {len(errors) - 5} more"
            QMessageBox.information(self, "Import Complete", result_msg)
        elif errors:
            QMessageBox.warning(self, "Import Errors", 
                              f"Failed to import related files:\n" + "\n".join(errors[:10]))
    
    def associate_other_model_files(self):
        """Associate other model files (DAE, OBJ, GLB) that are related to the current model.
        
        Related files are detected automatically by filename similarity.
        For DAE files, related DAE files might be animation variants or baked texture versions.
        """
        if not hasattr(self.gl, 'vertices') or self.gl.vertices is None:
            QMessageBox.warning(self, "Error", "Please load a model first")
            return
        
        related_files = self._detect_related_model_files()
        
        # Count total related files
        total_files = (len(related_files['dae_files']) + 
                      len(related_files['obj_files']) + 
                      len(related_files['glb_files']) + 
                      len(related_files['gltf_files']))
        
        if total_files == 0:
            QMessageBox.information(self, "No Related Files", 
                                  "No related model files found in the model directory.\n\n"
                                  "Related files are detected by filename similarity (same base name).")
            return
        
        # Build message showing found files
        message = f"Found {total_files} related model file(s):\n\n"
        
        if related_files['dae_files']:
            message += f"DAE Files ({len(related_files['dae_files'])}):\n"
            for filename, _ in related_files['dae_files']:
                message += f"  • {filename}\n"
            message += "\n"
        
        if related_files['obj_files']:
            message += f"OBJ Files ({len(related_files['obj_files'])}):\n"
            for filename, _ in related_files['obj_files']:
                message += f"  • {filename}\n"
            message += "\n"
        
        if related_files['glb_files']:
            message += f"GLB Files ({len(related_files['glb_files'])}):\n"
            for filename, _ in related_files['glb_files']:
                message += f"  • {filename}\n"
            message += "\n"
        
        if related_files['gltf_files']:
            message += f"GLTF Files ({len(related_files['gltf_files'])}):\n"
            for filename, _ in related_files['gltf_files']:
                message += f"  • {filename}\n"
        
        message += "\nRelated files are automatically detected and can be used for:\n"
        message += "• Animation variants (e.g., 'Baked Colors' DAE files)\n"
        message += "• Alternative model formats\n"
        message += "• Texture sources (OBJ files with MTL/textures)"
        
        QMessageBox.information(self, "Related Model Files", message)
        
        # TODO: In the future, this could allow switching between related files
        # or loading them as animation frames/variants
    
    def associate_model_texture_files(self):
        """Associate an MTL file with the current model to load textures.
        
        This finds all MTL files in the model directory and lets the user select one.
        After selection, loads the MTL and all textures referenced in it.
        """
        if not hasattr(self.gl, 'vertices') or self.gl.vertices is None:
            QMessageBox.warning(self, "Error", "Please load a model first")
            return
        
        model_dir = self._get_model_directory()
        if not model_dir or not os.path.exists(model_dir):
            QMessageBox.warning(self, "Error", "Cannot find model directory")
            return
        
        # Find all MTL files in the directory
        mtl_files = []
        for filename in os.listdir(model_dir):
            if filename.lower().endswith('.mtl'):
                file_path = os.path.join(model_dir, filename)
                if os.path.isfile(file_path):
                    mtl_files.append((filename, file_path))
        
        if not mtl_files:
            QMessageBox.information(self, "No MTL Files", 
                                  "No MTL (Material Library) files found in the model directory.\n\n"
                                  "For OBJ files, you need an MTL file to define materials and textures.\n"
                                  "For DAE files, textures are usually embedded in the DAE file itself.")
            return
        
        # Sort by filename
        mtl_files.sort(key=lambda x: x[0])
        
        # If only one MTL, use it automatically
        if len(mtl_files) == 1:
            mtl_filename, mtl_path = mtl_files[0]
            self._load_mtl_and_textures(mtl_path, model_dir)
            QMessageBox.information(self, "Textures Loaded", 
                                  f"Successfully loaded textures from:\n{mtl_filename}")
        else:
            # Multiple MTL files - let user select
            mtl_names = [filename for filename, _ in mtl_files]
            selected_name, ok = QInputDialog.getItem(
                self,
                "Select MTL File",
                f"Found {len(mtl_files)} MTL files.\nPlease select which one to use:",
                mtl_names,
                0,
                False
            )
            
            if ok and selected_name:
                # Find selected MTL path
                for mtl_filename, mtl_path in mtl_files:
                    if mtl_filename == selected_name:
                        self._load_mtl_and_textures(mtl_path, model_dir)
                        self.associate_textures_btn.setVisible(False)
                        self.associate_mtl_btn.setVisible(False)
                        QMessageBox.information(self, "Textures Loaded", 
                                              f"Successfully loaded textures from:\n{selected_name}")
                        break
    
    def _load_mtl_and_textures(self, mtl_path: str, model_dir: str):
        """Load an MTL file and all textures referenced in it."""
        debug(f"Loading MTL file: {mtl_path}")
        
        # Load MTL
        self.gl._load_mtl(mtl_path, model_dir)
        
        # Extract texture paths from materials and load them
        if self.gl.materials:
            texture_paths = []
            for mat_name, mat_data in self.gl.materials.items():
                tex_file = mat_data.get('texture')
                if tex_file:
                    # Try to find texture file
                    tex_basename = os.path.basename(tex_file)
                    tex_path = os.path.join(model_dir, tex_basename)
                    if os.path.exists(tex_path):
                        if tex_path not in texture_paths:
                            texture_paths.append(tex_path)
                    else:
                        # Try original path from MTL
                        if os.path.exists(tex_file):
                            if tex_file not in texture_paths:
                                texture_paths.append(tex_file)
            
            if texture_paths:
                debug(f"Loading {len(texture_paths)} textures from MTL")
                self.gl.load_textures_from_files(texture_paths)
                self._refresh_model_view()
    
    def associate_mtl_file(self):
        """Manually select an MTL file and import all textures listed in it.
        
        This is useful for DAE files or other models that don't have an associated MTL,
        but you want to apply textures from a different model's MTL file.
        """
        if not hasattr(self.gl, 'vertices') or self.gl.vertices is None:
            QMessageBox.warning(self, "Error", "Please load a model first")
            return
        
        # Get model directory as starting point
        model_dir = self._get_model_directory()
        if not model_dir or not os.path.exists(model_dir):
            model_dir = ""
        
        # Open file dialog to select MTL file
        filters = "Material Library Files (*.mtl);;All Files (*.*)"
        mtl_path, _ = QFileDialog.getOpenFileName(
            self,
            "Select MTL File to Import Textures From",
            model_dir,
            filters
        )
        
        if not mtl_path or not os.path.exists(mtl_path):
            return
        
        # Get directory of the MTL file (textures are usually in the same directory as MTL)
        mtl_dir = os.path.dirname(os.path.abspath(mtl_path))
        
        # Load the MTL file
        debug(f"Loading MTL file for texture import: {mtl_path}")
        
        # Parse MTL to extract texture references
        texture_paths = []
        materials_found = {}
        
        try:
            with open(mtl_path, "r", encoding="utf-8", errors="ignore") as f:
                current_material = None
                for line in f:
                    line = line.strip()
                    if not line or line.startswith("#"):
                        continue
                    
                    if line.startswith("newmtl "):
                        current_material = line.split()[1]
                        materials_found[current_material] = {
                            'diffuse': [0.8, 0.8, 0.8],
                            'ambient': [0.2, 0.2, 0.2],
                            'specular': [0.0, 0.0, 0.0],
                            'shininess': 0.0,
                            'texture': None
                        }
                    elif current_material:
                        if line.startswith("map_Kd ") or line.startswith("map_diffuse "):
                            # Diffuse texture map
                            parts = line.split()
                            if len(parts) >= 2:
                                # Handle spaces in filename
                                if len(parts) > 2:
                                    tex_file = " ".join(parts[1:])
                                else:
                                    tex_file = parts[1]
                                
                                materials_found[current_material]['texture'] = tex_file
                                
                                # Try to find texture file
                                tex_basename = os.path.basename(tex_file)
                                
                                # Try MTL directory first
                                tex_path = os.path.join(mtl_dir, tex_basename)
                                if os.path.exists(tex_path):
                                    if tex_path not in texture_paths:
                                        texture_paths.append(tex_path)
                                else:
                                    # Try model directory
                                    if model_dir:
                                        tex_path_model = os.path.join(model_dir, tex_basename)
                                        if os.path.exists(tex_path_model):
                                            if tex_path_model not in texture_paths:
                                                texture_paths.append(tex_path_model)
                                    # Try original path
                                    if os.path.exists(tex_file):
                                        if tex_file not in texture_paths:
                                            texture_paths.append(tex_file)
                        
                        elif line.startswith("Kd ") or line.startswith("diffuse "):
                            # Diffuse color
                            parts = line.split()
                            if len(parts) >= 4:
                                materials_found[current_material]['diffuse'] = [
                                    float(parts[1]), float(parts[2]), float(parts[3])
                                ]
                        elif line.startswith("Ka "):
                            # Ambient color
                            parts = line.split()
                            if len(parts) >= 4:
                                materials_found[current_material]['ambient'] = [
                                    float(parts[1]), float(parts[2]), float(parts[3])
                                ]
                        elif line.startswith("Ks "):
                            # Specular color
                            parts = line.split()
                            if len(parts) >= 4:
                                materials_found[current_material]['specular'] = [
                                    float(parts[1]), float(parts[2]), float(parts[3])
                                ]
                        elif line.startswith("Ns ") or line.startswith("shininess "):
                            # Shininess
                            shininess_val = float(line.split()[1])
                            if shininess_val < 0:
                                shininess_val = 0.0
                            elif shininess_val > 128:
                                if shininess_val <= 1000:
                                    shininess_val = (shininess_val / 1000.0) * 128.0
                                else:
                                    shininess_val = 128.0
                            materials_found[current_material]['shininess'] = shininess_val
            
            # Add materials to the GL widget
            for mat_name, mat_data in materials_found.items():
                if mat_name not in self.gl.materials:
                    self.gl.materials[mat_name] = mat_data
            
            # Load textures if found
            if texture_paths:
                debug(f"Loading {len(texture_paths)} textures from MTL file")
                self.gl.load_textures_from_files(texture_paths)
                
                # CRITICAL FIX: After loading MTL materials and textures, reassign face_materials
                # DAE files may have old material assignments that don't match the new MTL materials
                num_faces = len(self.gl.indices) // 3 if self.gl.indices is not None else 0
                if num_faces > 0 and self.gl.materials:
                    # Get the first material that has a texture (prefer textured materials)
                    textured_material = None
                    untextured_material = None
                    
                    for mat_name in self.gl.materials.keys():
                        if mat_name in self.gl.textures:
                            textured_material = mat_name
                            break
                        elif untextured_material is None:
                            untextured_material = mat_name
                    
                    # Use textured material if available, otherwise use any material
                    default_mat = textured_material or untextured_material or list(self.gl.materials.keys())[0]
                    
                    # Reassign ALL faces to use materials from the MTL file
                    # If we have multiple materials with textures, distribute faces among them
                    mat_list = list(self.gl.materials.keys())
                    for i in range(num_faces):
                        # Cycle through materials to distribute evenly, or use first textured material
                        if len(mat_list) > 1:
                            # Distribute evenly across all materials
                            self.gl.face_materials[i] = mat_list[i % len(mat_list)]
                        else:
                            # Use the single/default material
                            self.gl.face_materials[i] = default_mat
                    
                    debug(f"Reassigned {num_faces} faces to MTL materials (using '{default_mat}' as primary)")
                
                self._refresh_model_view()
                
                QMessageBox.information(self, "Textures Loaded", 
                                      f"Successfully loaded {len(texture_paths)} texture(s) from MTL file:\n"
                                      f"{os.path.basename(mtl_path)}\n\n"
                                      f"Materials found: {len(materials_found)}")
            else:
                # No textures found in MTL, but materials were loaded
                if materials_found:
                    # Still reassign face materials to the new MTL materials
                    num_faces = len(self.gl.indices) // 3 if self.gl.indices is not None else 0
                    if num_faces > 0:
                        default_mat = list(self.gl.materials.keys())[0]
                        self.gl.face_materials = [default_mat] * num_faces
                        debug(f"Reassigned {num_faces} faces to MTL materials (no textures)")
                    
                    self._refresh_model_view()
                    QMessageBox.information(self, "Materials Loaded", 
                                          f"Loaded {len(materials_found)} material(s) from MTL file:\n"
                                          f"{os.path.basename(mtl_path)}\n\n"
                                          "No texture files were found.")
                else:
                    QMessageBox.warning(self, "No Data Found", 
                                      f"No materials or textures found in MTL file:\n{os.path.basename(mtl_path)}")
                    
        except Exception as e:
            QMessageBox.warning(self, "Error", f"Failed to load MTL file:\n{str(e)}")
            import traceback
            traceback.print_exc()
    
    def open_manage_textures_dialog(self):
        """Open the Manage Textures dialog"""
        if not hasattr(self, 'gl') or not hasattr(self.gl, 'textures') or not self.gl.textures:
            QMessageBox.information(self, "No Textures", "No textures are currently loaded for this model.")
            return
        
        # Ensure textures are loaded from the correct folder (Resources\Textures\ModelName\)
        model_name = self.resource_data.get("name") if self.resource_data else None
        if model_name:
            textures_folder = os.path.join(
                self.app.project_manager.get_project_path(),
                "Resources", "Textures", model_name
            )
            
            # Textures should already be loaded from MTL references or texture_paths
            # Just ensure they're loaded before showing dialog
            if not hasattr(self.gl, 'textures') or not self.gl.textures:
                # Try to load from texture_paths if available
                texture_paths = self.resource_data.get("texture_paths", [])
                if texture_paths:
                    textures_base_folder = os.path.join(
                        self.app.project_manager.get_project_path(),
                        "Resources", "Textures"
                    )
                    tex_paths_to_load = []
                    for tex_path_rel in texture_paths:
                        full_tex_path = os.path.join(textures_base_folder, tex_path_rel)
                        if os.path.exists(full_tex_path):
                            tex_paths_to_load.append(full_tex_path)
                    
                    if tex_paths_to_load:
                        debug(f"Loading {len(tex_paths_to_load)} textures for Manage Textures dialog")
                        self.gl.load_textures_from_files(tex_paths_to_load)
                        self._refresh_model_view()
        
        dialog = ManageTexturesDialog(self, self.gl)
        if dialog.exec():
            # Update enabled/disabled lists from dialog
            self.gl.enabled_textures = dialog.get_enabled_textures()
            self.gl.disabled_textures = dialog.get_disabled_textures()
            # Refresh preview
            self.gl.update()
    
    def _serialize_model_to_json(self):
        """Serialize the current model data to JSON format.
        
        Returns:
            dict: Complete model data in JSON-serializable format
        """
        import json
        import base64
        
        # Get model name and metadata
        model_name = self.resource_data.get("name", "Untitled_Model") if self.resource_data else "Untitled_Model"
        
        # Get original format if available
        original_file = self.resource_data.get("original_model_file", "") if self.resource_data else ""
        original_format = os.path.splitext(original_file)[1].lstrip('.') if original_file else "unknown"
        
        # Build model data structure
        model_data = {
            "version": "1.0",
            "format": "PyGenesis Model",
            "metadata": {
                "name": model_name,
                "original_format": original_format,
                "original_filename": original_file,
                "import_date": datetime.datetime.now().isoformat(),
                "scale": getattr(self.gl, '_resource_scale', 1.0) if hasattr(self.gl, '_resource_scale') else 1.0
            },
            "geometry": {
                "vertices": self.gl.vertices.tolist() if self.gl.vertices is not None else [],
                "indices": self.gl.indices.tolist() if self.gl.indices is not None else [],
                "normals": self.gl.normals.tolist() if hasattr(self.gl, 'normals') and self.gl.normals is not None else [],
                "tex_coords": self.gl.tex_coords.tolist() if hasattr(self.gl, 'tex_coords') and self.gl.tex_coords is not None else [],
                "face_materials": self.gl.face_materials if hasattr(self.gl, 'face_materials') else []
            },
            "materials": {},
            "textures": {},
            "animations": {},
            "skeleton": None
        }
        
        # Serialize materials
        if hasattr(self.gl, 'materials') and self.gl.materials:
            for mat_name, mat_data in self.gl.materials.items():
                model_data["materials"][mat_name] = {
                    "diffuse": mat_data.get("diffuse", [0.8, 0.8, 0.8]),
                    "ambient": mat_data.get("ambient", [0.2, 0.2, 0.2]),
                    "specular": mat_data.get("specular", [0.0, 0.0, 0.0]),
                    "shininess": mat_data.get("shininess", 0.0),
                    "texture": mat_data.get("texture")  # Path reference, not embedded
                }
        
        # Serialize texture references and enabled/disabled states
        if hasattr(self.gl, 'textures') and self.gl.textures:
            models_folder = os.path.join(self.app.project_manager.get_project_path(), "Resources", "Models")
            parent_folder = self.resource_data.get("parent_folder", "") if self.resource_data else ""
            if parent_folder:
                models_folder = os.path.join(models_folder, parent_folder)
            
            for mat_name, texture_id in self.gl.textures.items():
                # Get texture path from material
                mat = self.gl.materials.get(mat_name, {})
                texture_path = mat.get("texture")
                if texture_path:
                    # Store relative path
                    if os.path.isabs(texture_path):
                        rel_path = os.path.relpath(texture_path, models_folder)
                    else:
                        rel_path = texture_path
                    texture_name = os.path.basename(texture_path)
                    model_data["textures"][mat_name] = {
                        "path": rel_path,
                        "material": mat_name
                    }
        
        # Serialize enabled and disabled texture lists
        model_data["enabled_textures"] = getattr(self.gl, 'enabled_textures', [])
        model_data["disabled_textures"] = getattr(self.gl, 'disabled_textures', [])
        
        # Serialize animations
        if hasattr(self.gl, 'animations') and self.gl.animations:
            for anim_name, anim_clip in self.gl.animations.items():
                if isinstance(anim_clip, AnimationClip):
                    anim_data = {
                        "name": anim_clip.name,
                        "duration": float(anim_clip.duration),
                        "frame_rate": float(anim_clip.frame_rate),
                        "keyframes": {}
                    }
                    
                    # Serialize keyframes for each node
                    for node_name in anim_clip.get_node_names():
                        node_keyframes = {
                            "position": [],
                            "rotation": [],
                            "scale": []
                        }
                        
                        # Get keyframes from AnimationClip
                        if node_name in anim_clip.keyframes:
                            node_data = anim_clip.keyframes[node_name]
                            node_keyframes["position"] = node_data.get("position", [])
                            node_keyframes["rotation"] = node_data.get("rotation", [])
                            node_keyframes["scale"] = node_data.get("scale", [])
                        
                        anim_data["keyframes"][node_name] = node_keyframes
                    
                    model_data["animations"][anim_name] = anim_data
        
        # Serialize skeleton if available
        if hasattr(self.gl, 'skeleton') and self.gl.skeleton:
            model_data["skeleton"] = self.gl.skeleton
        
        return model_data
    
    def load_model_file_from_path(self, file_path):
        """Load model file from specified path (supports OBJ, GLB/GLTF)"""
        if not os.path.exists(file_path):
            QMessageBox.warning(self, "File Not Found", f"Model file not found: {file_path}")
            return
        
        if not self.app or not self.resource_data:
            QMessageBox.warning(self, "Error", "Cannot load model: No resource data available")
            return
        
        # Check if the file is already in the project's models folder
        models_folder = os.path.join(self.app.project_manager.get_project_path(), "Resources", "Models")
        parent_folder = self.resource_data.get("parent_folder", "")
        if parent_folder:
            models_folder = os.path.join(models_folder, parent_folder)
        
        is_in_project_folder = file_path.startswith(models_folder)
        
        # Store the source directory for related file detection
        source_dir = os.path.dirname(os.path.abspath(file_path))
        source_model_name = os.path.splitext(os.path.basename(file_path))[0]
        
        if not is_in_project_folder:
            # Copy the model file to the project's models folder
            if hasattr(self.app, 'resource_manager'):
                success = self.app.resource_manager._copy_model_file(self.resource_data, file_path)
                if not success:
                    QMessageBox.warning(self, "Copy Error", "Failed to copy model file to project folder")
                    return
            else:
                QMessageBox.warning(self, "Error", "Resource manager not available")
                return
            
            # Use the copied file - always construct path from model_file (relative filename)
            copied_filename = self.resource_data.get("model_file")
            if copied_filename:
                model_filename = os.path.basename(copied_filename)  # Safety: extract filename
                model_file_path = os.path.normpath(os.path.join(models_folder, model_filename))
            else:
                QMessageBox.warning(self, "Copy Error", "Failed to get copied file path")
                return
        else:
            # File is already in project folder, use it directly (normalize path)
            model_file_path = os.path.normpath(file_path)
            # Update resource data with just the filename
            self.resource_data["model_file"] = os.path.basename(file_path)
        
        # Verify file exists before loading
        if not os.path.exists(model_file_path):
            QMessageBox.warning(self, "File Not Found", f"Model file not found: {model_file_path}")
            return
        
        # Load into preview widget using unified importer
        try:
            # Use unified import_model function
            self.gl.import_model(model_file_path)
            
            # Post-load texture resolution (Material Resolver handles most of this, but check for MTL)
            ext = model_file_path.lower().split('.')[-1]
            if ext == 'obj' and len(self.gl.materials) == 0:
                # Try to find matching MTL file
                model_base_name = os.path.splitext(os.path.basename(model_file_path))[0]
                model_dir = os.path.dirname(model_file_path)
                mtl_path = os.path.join(model_dir, model_base_name + ".mtl")
                if os.path.exists(mtl_path):
                    debug(f"Found matching MTL file: {mtl_path}")
                    self.gl._load_mtl(mtl_path, model_dir)
            
            # If still no materials/textures, try auto-detecting textures in directory
            if len(self.gl.materials) == 0 and len(self.gl.textures) == 0:
                model_dir = os.path.dirname(model_file_path)
                resolver = MaterialResolver(model_directory=model_dir)
                found_textures = resolver.find_textures_in_directory()
                if found_textures:
                    debug(f"Auto-loading {len(found_textures)} texture files from directory")
                    self.gl.load_textures_from_files(found_textures)
            
            self.file_label.setText(os.path.basename(model_file_path))
            
            # Enable Import to JSON Model button after loading
            if hasattr(self, 'manage_textures_btn'):
                self.manage_textures_btn.setEnabled(True)
            
            # Update resource data
            self.resource_data["format"] = ext
            if not is_in_project_folder:
                self.resource_data["model_file"] = os.path.basename(model_file_path)
            
            # Copy textures to Resources\Textures\ModelName\ folder
            if hasattr(self.gl, 'textures') and self.gl.textures:
                model_name = self.resource_data.get("name", os.path.splitext(os.path.basename(model_file_path))[0])
                textures_folder = os.path.join(
                    self.app.project_manager.get_project_path(),
                    "Resources", "Textures", model_name
                )
                os.makedirs(textures_folder, exist_ok=True)
                
                copied_textures = []
                for tex_name, tex_path in list(self.gl.textures.items()):
                    if tex_path and os.path.exists(tex_path):
                        # Check if texture is already in the textures folder
                        tex_filename = os.path.basename(tex_path)
                        dest_path = os.path.join(textures_folder, tex_filename)
                        
                        # Only copy if not already there
                        if not os.path.exists(dest_path) or os.path.abspath(tex_path) != os.path.abspath(dest_path):
                            import shutil
                            shutil.copy2(tex_path, dest_path)
                            debug(f"Copied texture {tex_filename} to {dest_path}")
                        
                        # Update texture path in GL widget to point to new location
                        self.gl.textures[tex_name] = dest_path
                        copied_textures.append(tex_filename)
                
                # Update resource data with texture file references
                if copied_textures:
                    self.resource_data["texture_files"] = copied_textures
                    debug(f"Updated resource_data with {len(copied_textures)} texture files")
            
            # Save the .model file to disk so the purge system knows about it
            try:
                self.app.resource_manager.save_resource_file_only("models", self.resource_data)
            except Exception as e:
                import traceback
                traceback.print_exc()
            
            # Update model dimensions display
            self._update_dimensions_display()
            
            # Textures are imported and .Texture files created by ResourceManager._import_textures_for_model
            # Just ensure .Model file is saved with texture_resources reference
            try:
                self.app.resource_manager.save_resource_file_only("models", self.resource_data)
            except Exception as e:
                debug(f"Failed to save model resource: {e}")
        
        except Exception as e:
            import traceback
            traceback.print_exc()
            QMessageBox.warning(self, "Load Error", f"Failed to load model: {e}")
    
    def close_editor(self) -> bool:
        """Cleanup and close the editor (EditorInterface implementation)"""
        # ModelEditor doesn't need special cleanup
        return True
    
    def get_editor_widget(self) -> QWidget:
        """Get the main widget for this editor (EditorInterface implementation)"""
        return self
    
    def is_dirty(self) -> bool:
        """Check if the editor has unsaved changes (EditorInterface implementation)"""
        return self._dirty
    
    def get_resource_type(self) -> str:
        """Get the resource type this editor handles (EditorInterface implementation)"""
        return "models"
    
    def get_resource_id(self) -> Optional[str]:
        """Get the ID of the currently loaded resource (EditorInterface implementation)"""
        return self.resource_data.get("id") if self.resource_data else None
    
    def get_resource_name(self) -> Optional[str]:
        """Get the name of the currently loaded resource"""
        return self.resource_data.get("name") if self.resource_data else None


def main():
    app = QApplication(sys.argv)
    w = StandaloneModelPreviewWindow()
    w.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()


