"""
Texture Editor for Python Game IDE
GameMaker 8-style texture editor with properties panel and preview box
"""

from PySide6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLabel, 
                               QPushButton, QSpinBox, QCheckBox, QScrollArea,
                               QFrame, QSplitter, QListWidget, QListWidgetItem,
                               QMessageBox, QFileDialog, QInputDialog, QComboBox, 
                               QSizePolicy, QLineEdit, QGroupBox, QGridLayout,
                               QDialog, QDialogButtonBox, QTabWidget, QTextEdit,
                               QMenu, QMenuBar, QSlider)
from PySide6.QtCore import Qt, Signal, QSize, QTimer
from PySide6.QtGui import QPainter, QPen, QBrush, QColor, QPixmap, QFont, QAction

import os
import json
from typing import Dict, Optional
from Core.Debug import debug
from Core.EditorInterface import EditorInterface
from Editors.Shared.BaseImageResourceEditor import BaseImageResourceEditor

from Editors.Shared.IntegratedImageEditor import IntegratedImageEditor

class TextureEditor(BaseImageResourceEditor):
    """Texture Editor - inherits from BaseImageResourceEditor"""
    
    def __init__(self, app, resource_data):
        super().__init__(app, resource_data, "textures")
        self.image_editor = None
        
        # Animation filtering
        self.selected_animation = None  # None means all frames, otherwise tag name
        self.animation_frames = []  # List of frame indices for current animation
        self.animation_frame_index = 0  # Current position in animation_frames list
        
        # Initialize runtime frames storage (separate from serializable data)
        self.runtime_frames = []  # Store PIL objects separately
        
        # Store the original file path for this texture
        if resource_data and hasattr(self.app, 'resource_manager'):
            self.original_file_path = self.app.resource_manager.get_resource_file_path("textures", resource_data)
        else:
            self.original_file_path = None
        
        # Connect to signals for resource updates
        if hasattr(self.app, 'resource_manager'):
            self.app.resource_manager.resource_updated.connect(self.on_resource_updated)
            self.app.resource_manager.resource_deleted.connect(self.on_resource_deleted)
        if hasattr(self.app, 'project_manager'):
            self.app.project_manager.project_loaded.connect(self.on_project_changed)
        
        # Base class handles setup_ui() via _build_ui_complete()
    
    # create_properties_panel is inherited from base class - no override needed
    # The base class already connects load_button to self.load_resource_files()
    # create_preview_panel is inherited from base class - no override needed
    
    def open_resource(self, resource_data: Dict) -> bool:
        """Load resource data into the editor (EditorInterface implementation)"""
        try:
            self.resource_data = resource_data
            self._dirty = False
            
            # Update original file path
            if hasattr(self.app, 'resource_manager'):
                self.original_file_path = self.app.resource_manager.get_resource_file_path("textures", resource_data)
            
            # Call the existing load logic
            self.load_resource_data()
            return True
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to load resource: {str(e)}")
            return False
    
    def load_resource_data(self):
        """Load resource data into the editor - override to add texture-specific loading"""
        # Call base class to load basic resource data
        super().load_resource_data()
        
        # Texture-specific: Load runtime frames immediately
        if self.total_frames > 0:
            self._load_runtime_frames()
            if hasattr(self, 'preview_canvas'):
                self.preview_canvas.update()
    
    def _load_runtime_frames(self):
        """Load runtime frames from texture files - override base class"""
        if not self.resource_data:
            return
        
        from PIL import Image
        import os
        
        self.runtime_frames = []
        frames = self.resource_data.get("frames", [])
        project_path = self.app.project_manager.get_project_path()
        parent_folder = self.resource_data.get("parent_folder", "")
        
        textures_folder = os.path.join(project_path, "Resources", "Textures")
        if parent_folder:
            textures_folder = os.path.join(textures_folder, parent_folder)
        
        for frame_data in frames:
            if isinstance(frame_data, dict):
                frame_file = frame_data.get("file", "")
                if frame_file:
                    frame_path = os.path.join(textures_folder, frame_file)
                    if os.path.exists(frame_path):
                        try:
                            img = Image.open(frame_path).convert("RGBA")
                            self.runtime_frames.append(img)
                        except Exception as e:
                            debug(f"Failed to load frame {frame_file}: {e}")
        
        # Update dimensions from first frame if available
        if self.runtime_frames:
            first_frame = self.runtime_frames[0]
            width, height = first_frame.size
            self.resource_data["width"] = width
            self.resource_data["height"] = height
            if hasattr(self, 'width_label'):
                self.width_label.setText(f"Width: {width}")
            if hasattr(self, 'height_label'):
                self.height_label.setText(f"Height: {height}")
    
    def on_name_changed(self, name):
        """Handle name change - override to add texture-specific tab title update"""
        # Call base class to update resource data
        super().on_name_changed(name)
        # Update editor tab title
        self.update_editor_tab_title()
    
    def on_tab_close_requested(self, index):
        """Handle tab close request"""
        tab_text = self.tab_widget.tabText(index)
        if tab_text.startswith("Image Editor -"):
            # Close the image editor
            self.close_image_editor()
        elif index > 0:  # Don't allow closing the Home tab
            self.tab_widget.removeTab(index)
    
    def update_editor_tab_title(self):
        """Update the image editor tab title when sprite name changes"""
        for i in range(self.tab_widget.count()):
            if self.tab_widget.tabText(i).startswith("Image Editor -"):
                sprite_name = self.name_edit.text() or "Untitled"
                self.tab_widget.setTabText(i, f"Image Editor - {sprite_name}")
                break
    
    def open_image_editor(self):
        """Open the integrated PySide6 image editor"""
        try:
            # Import the PySide6 image editor components
            import sys
            import os
            
            # Add the Image Editor path to sys.path
            image_editor_path = os.path.join(os.path.dirname(__file__), "..", "ImageEditor", "core")
            if image_editor_path not in sys.path:
                sys.path.insert(0, image_editor_path)
            
            from Editors.ImageEditor.core.ui.main_window import MainWindow as ImageEditorMainWindow
            from Editors.ImageEditor.core.core.state import EditorState
            from Editors.ImageEditor.core.ui.dialogs.new_image_dialog import NewImageDialog
            
            # CRITICAL: Reload resource data from disk to get latest tags/colors before opening editor
            resource_id = self.resource_data.get("id") if self.resource_data else None
            if resource_id and self.app and hasattr(self.app, 'resource_manager'):
                fresh_resource_data = self.app.resource_manager.load_resource_from_disk("textures", resource_id)
                if fresh_resource_data:
                    # Update resource_data with fresh data
                    self.resource_data = fresh_resource_data
                    # Also update resource_data frames to ensure tags field exists
                    for i, frame in enumerate(self.resource_data.get("frames", [])):
                        if isinstance(frame, dict):
                            if "tags" not in frame:
                                frame["tags"] = []
                            if "color_code" not in frame:
                                frame["color_code"] = None
            
            # Check if we have existing texture data (now with fresh tags/colors)
            texture_data = self.get_texture_data()
            has_existing_data = self.has_existing_texture_data()
            
            # If no existing data, show new texture dialog
            if not has_existing_data:
                dialog = NewImageDialog(self)
                if dialog.exec() == QDialog.Accepted:
                    width, height = dialog.get_size()
                    # Update texture data with new dimensions
                    texture_data["width"] = width
                    texture_data["height"] = height
                    # Update the UI to reflect new dimensions
                    self.width_label.setText(f"Width: {width} px")
                    self.height_label.setText(f"Height: {height} px")
                else:
                    # User cancelled, don't open image editor
                    return
            
            # Create integrated image editor
            from Editors.SpriteEditor.SpriteEditor import IntegratedImageEditor
            self.image_editor = IntegratedImageEditor(
                parent=self, 
                resource_data=texture_data,
                resource_type="textures",
                on_save_callback=self.on_texture_saved,
                app=self.app
            )
            
            # Show the editor in a container within the texture editor
            self.show_image_editor()
            
        except ImportError as e:
            QMessageBox.critical(self, "Error", f"Failed to import Image Editor: {str(e)}")
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to open Image Editor: {str(e)}")
    
    def show_image_editor(self):
        """Show the image editor in a new tab"""
        if not hasattr(self, 'image_editor') or self.image_editor is None:
            return
        
        # Get texture name for tab title
        texture_name = self.name_edit.text() or "Untitled"
        tab_title = f"Image Editor - {texture_name}"
        
        # Check if editor tab already exists
        for i in range(self.tab_widget.count()):
            if self.tab_widget.tabText(i).startswith("Image Editor -"):
                # Replace existing editor tab
                self.tab_widget.removeTab(i)
                break
        
        # Create fullscreen container for the image editor
        editor_container = QWidget()
        editor_container.setStyleSheet("""
            QWidget {
                background-color: #2b2b2b;
            }
        """)
        
        # Add the image editor to the container (fullscreen)
        editor_layout = QVBoxLayout(editor_container)
        editor_layout.setContentsMargins(0, 0, 0, 0)
        editor_layout.addWidget(self.image_editor)
        
        # Add as new tab
        tab_index = self.tab_widget.addTab(editor_container, tab_title)
        self.tab_widget.setCurrentIndex(tab_index)
        
        # Store reference to editor container
        self.editor_container = editor_container
        
        # Show close editor button and hide edit button
        self.edit_button.hide()
        self.close_editor_button.show()
    
    def on_texture_saved(self, updated_texture_data):
        """Handle texture save from the image editor"""
        # Update resource data with changes from editor
        # Important: Update frames array completely to preserve structure
        if "frames" in updated_texture_data:
            # Replace frames entirely with updated frames
            self.resource_data["frames"] = updated_texture_data["frames"]
        
        # Update other properties
        self.resource_data.update({k: v for k, v in updated_texture_data.items() if k != "frames"})
        
        # Update UI elements
        self.name_edit.setText(updated_texture_data.get("name", ""))
        
        # Save individual frame files to disk
        self.save_frame_files_to_disk(updated_texture_data)
        
        # Save the texture resource file to disk
        result = self.save_resource()
        
        # Update animation combo to reflect any new tags
        self._update_animation_combo()
        
        # Refresh preview
        self.refresh_preview()
        
        # Notify the main application of changes
        if hasattr(self.app, 'project_manager'):
            self.app.project_manager.mark_project_dirty()
    
    def save_frame_files_to_disk(self, texture_data):
        """Save individual frame files to disk from Image Editor state"""
        try:
            import os
            import numpy as np
            from PIL import Image
            
            # Get the textures folder path
            if not hasattr(self, 'app') or not self.app.project_manager:
                debug("No app or project manager available for saving frame files")
                return
                
            project_path = self.app.project_manager.get_project_path()
            if not project_path:
                debug("No project path available for saving frame files")
                return
                
            textures_folder = os.path.join(project_path, "Resources", "Textures")
            parent_folder = texture_data.get("parent_folder", "")
            if parent_folder:
                textures_folder = os.path.join(textures_folder, parent_folder)
            
            # Ensure the folder exists
            os.makedirs(textures_folder, exist_ok=True)
            
            # Try to get image data directly from Image Editor state
            try:
                from core.state import state
                lm = state.layer_manager
                
                if lm.layers and len(lm.layers) > 0:
                    layer = lm.layers[0]
                    frames = texture_data.get("frames", [])
                    
                    # Save each frame's image data directly from Image Editor
                    for frame_idx, frame_obj in enumerate(layer.frames):
                        if frame_obj.image is not None:
                            # Get filename from frame data or generate one
                            if frame_idx < len(frames):
                                filename = frames[frame_idx].get("file", f"{texture_data.get('name', 'texture')}_{frame_idx}.png")
                            else:
                                filename = f"{texture_data.get('name', 'texture')}_{frame_idx}.png"
                            
                            # Convert numpy array to PIL Image
                            img_array = frame_obj.image
                            
                            # Handle different image formats
                            if len(img_array.shape) == 3:
                                # RGB or RGBA
                                if img_array.shape[2] == 4:
                                    # RGBA
                                    pil_image = Image.fromarray(img_array.astype(np.uint8), 'RGBA')
                                elif img_array.shape[2] == 3:
                                    # RGB
                                    pil_image = Image.fromarray(img_array.astype(np.uint8), 'RGB')
                                else:
                                    debug(f"Unsupported image shape: {img_array.shape}")
                                    continue
                            else:
                                # Grayscale
                                pil_image = Image.fromarray(img_array.astype(np.uint8), 'L')
                            
                            # Save to disk
                            frame_path = os.path.join(textures_folder, filename)
                            pil_image.save(frame_path, "PNG")
                            debug(f"Saved frame file: {filename} ({pil_image.size[0]}x{pil_image.size[1]})")
                            
            except Exception as e:
                debug(f"Could not save from Image Editor state, trying fallback: {e}")
                import traceback
                traceback.print_exc()
                
                # Fallback: Try to save from base64 image_data if available
                frames = texture_data.get("frames", [])
                for frame in frames:
                    if isinstance(frame, dict) and "image_data" in frame:
                        import base64
                        # Decode base64 image data
                        img_data = base64.b64decode(frame["image_data"])
                        
                        # Get the filename
                        filename = frame.get("file", f"{texture_data.get('name', 'texture')}_{len(frames)}.png")
                        
                        # Save to disk
                        frame_path = os.path.join(textures_folder, filename)
                        with open(frame_path, 'wb') as f:
                            f.write(img_data)
                        
                        debug(f"Saved frame file (base64): {filename}")
                    
        except Exception as e:
            debug(f"Error saving frame files to disk: {e}")
            import traceback
            traceback.print_exc()
    
    def refresh_preview(self):
        """Refresh the texture preview"""
        if hasattr(self, 'preview_canvas') and self.preview_canvas:
            self.preview_canvas.update()
    
    def close_image_editor(self):
        """Close the image editor and return to home tab"""
        # Find and remove the image editor tab
        for i in range(self.tab_widget.count()):
            if self.tab_widget.tabText(i).startswith("Image Editor -"):
                self.tab_widget.removeTab(i)
                break
        
        # Clean up image editor
        if hasattr(self, 'image_editor') and self.image_editor is not None:
            self.image_editor.close()
            self.image_editor = None
        
        # Switch to home tab
        self.tab_widget.setCurrentIndex(0)  # Home tab is always index 0
        
        # Show edit button and hide close editor button
        self.edit_button.show()
        self.close_editor_button.hide()
    
    def get_texture_data(self):
        """Get current texture data for the image editor"""
        # Get frames with file references (no PIL objects)
        frames = self.resource_data.get("frames", [])
        serializable_frames = []
        for frame in frames:
            serializable_frame = {
                "id": frame.get("id"),
                "file": frame.get("file"),  # Just the filename
                "duration": frame.get("duration")
            }
            serializable_frames.append(serializable_frame)
        
        return {
            "id": self.resource_data.get("id"),  # Include the ID field
            "name": self.name_edit.text(),
            "type": self.resource_data.get("type", "textures"),
            "parent_folder": self.resource_data.get("parent_folder", ""),
            "created": self.resource_data.get("created"),
            "width": self.resource_data.get("width", 256),
            "height": self.resource_data.get("height", 256),
            "frames": serializable_frames,  # JSON serializable frames
        }
    
    def has_existing_texture_data(self):
        """Check if we have existing texture data (not just default values)"""
        # Check if we have actual texture frames or if this is a new/empty texture
        if not hasattr(self, 'resource_data') or not self.resource_data:
            return False
        
        # Check if we have frames or if this is just a default texture
        frames = self.resource_data.get("frames", [])
        if not frames or len(frames) == 0:
            return False
        
        # Check if frames contain file references
        for frame in frames:
            if frame and frame.get("file"):
                return True
        
        return False
    
    # Removed update_sprite_dimensions - not needed for textures
    # Removed load_sprite_files - use load_texture_files instead
    
    def load_resource_files(self):
        """Load texture files from file dialog - overrides base class"""
        from PySide6.QtWidgets import QFileDialog
        files, _ = QFileDialog.getOpenFileNames(
            self, "Load Texture Images", "", 
            "Image Files (*.png *.jpg *.jpeg *.gif *.bmp);;All Files (*.*)"
        )
        if files:
            self.load_texture_from_files(files)
    
    def load_texture_from_files(self, files):
        """Load texture from selected files"""
        if not files:
            return
        
        from PIL import Image
        from PySide6.QtWidgets import QMessageBox
        import os
        
        frames = []
        # Use the current texture name from the UI, not from resource_data
        texture_name = self.name_edit.text() if hasattr(self, 'name_edit') and self.name_edit.text() else self.resource_data.get("name", "texture")
        
        print(f"Loading texture files for texture: '{texture_name}'")
        print(f"Resource data name: '{self.resource_data.get('name', 'None')}'")
        print(f"UI name edit text: '{self.name_edit.text() if hasattr(self, 'name_edit') else 'No name_edit'}'")
        
        # Get the textures folder path, including parent folder if specified
        textures_folder = os.path.join(
            self.app.project_manager.get_project_path(),
            "Resources", "Textures"
        )
        
        # Add parent folder to path if specified
        parent_folder = self.resource_data.get("parent_folder", "")
        if parent_folder:
            textures_folder = os.path.join(textures_folder, parent_folder)
        
        os.makedirs(textures_folder, exist_ok=True)
        
        for file_path in files:
            try:
                # Load image file
                img = Image.open(file_path)
                
                if img.format == "GIF" and hasattr(img, 'n_frames') and img.n_frames > 1:
                    # Animated GIF - extract all frames
                    for frame_idx in range(img.n_frames):
                        img.seek(frame_idx)
                        frame = img.convert("RGBA")
                        
                        # Save frame as individual PNG file
                        frame_filename = f"{texture_name}_{len(frames)}.png"
                        frame_path = os.path.join(textures_folder, frame_filename)
                        frame.save(frame_path, "PNG")
                        print(f"Created frame file: {frame_filename}")
                        
                        # Store frame reference in texture data
                        frames.append({
                            "id": f"frame_{len(frames)}",
                            "file": frame_filename,  # Just the filename, not full path
                            "duration": img.info.get('duration', 100) / 1000.0,
                            "tags": []  # Initialize tags as empty list
                        })
                        
                        # Store PIL object for runtime use
                        self.runtime_frames.append(frame)
                else:
                    # Static image (PNG, JPG, static GIF, etc.)
                    frame = img.convert("RGBA")
                    
                    # Save frame as individual PNG file
                    frame_filename = f"{texture_name}_{len(frames)}.png"
                    frame_path = os.path.join(textures_folder, frame_filename)
                    frame.save(frame_path, "PNG")
                    print(f"Created frame file: {frame_filename}")
                    
                    # Store frame reference in texture data
                    frames.append({
                        "id": f"frame_{len(frames)}",
                        "file": frame_filename,  # Just the filename, not full path
                        "duration": 1.0,
                        "tags": []  # Initialize tags as empty list
                    })
                    
                    # Store PIL object for runtime use
                    self.runtime_frames.append(frame)
                    
            except Exception as e:
                QMessageBox.warning(self, "Error", f"Failed to load {file_path}: {str(e)}")
                continue
        
        if frames:
            # Update texture data with frame references
            self.resource_data["frames"] = frames
            self.total_frames = len(frames)
            self.current_frame = 0
            self.frames_label.setText(f"Frames: {self.total_frames}")
            self.update_frame_display()
            
            # Load texture data
            self.load_resource_data()
            
            self.preview_canvas.update()
            
            # Save the updated texture data to the .texture file
            self.save_resource()
            
            QMessageBox.information(self, "Images Loaded", f"Loaded {len(frames)} frames from {len(files)} file(s)")
        else:
            QMessageBox.warning(self, "Error", "No valid images were loaded")
    
    # Removed load_sprite_data - textures use load_resource_data instead
    
    # Removed open_sprite_settings - not needed for textures
    
    def update_sprite_dimensions(self, width, height):
        """Update sprite dimensions and refresh display"""
        self.resource_data["width"] = width
        self.resource_data["height"] = height
        self.width_label.setText(f"Width: {width}")
        self.height_label.setText(f"Height: {height}")
        
        # Update origin spinbox ranges
        self.origin_x_spin.setRange(0, width)
        self.origin_y_spin.setRange(0, height)
        
        self.preview_canvas.update()
    
    def save_resource(self):
        """Save the texture resource"""
        # Try to get updated texture data from Image Editor if available
        # This ensures tags and other frame metadata are included
        serializable_data = None
        
        # Check for IntegratedImageEditor (stored as image_editor)
        # Note: IntegratedImageEditor uses get_updated_sprite_data() method name
        if hasattr(self, 'image_editor') and self.image_editor:
            if hasattr(self.image_editor, 'get_updated_sprite_data'):
                try:
                    debug("Getting updated texture data from Image Editor...")
                    serializable_data = self.image_editor.get_updated_sprite_data()
                    debug(f"Got updated texture data with {len(serializable_data.get('frames', []))} frames")
                except Exception as e:
                    debug(f"Failed to get updated texture data from Image Editor: {e}")
                    import traceback
                    traceback.print_exc()
                    # Fall back to basic texture data
                    serializable_data = self.get_texture_data()
            else:
                debug("Image Editor doesn't have get_updated_sprite_data method")
                serializable_data = self.get_texture_data()
        else:
            # Get JSON-serializable data instead of raw resource_data
            debug("No Image Editor available, using basic texture data")
            serializable_data = self.get_texture_data()
            
        if not serializable_data:
            serializable_data = self.get_texture_data()
        
        # Update runtime data
        resource_id = self.resource_data.get("id")
        if resource_id:
            self.app.project_manager.update_runtime_resource("textures", resource_id, serializable_data)
        
        # Save to disk
        import os
        result = False
        if hasattr(self.app, 'resource_manager'):
            result = self.app.resource_manager.save_resource("textures", serializable_data, self.original_file_path)
        
        if result:
            self._dirty = False
        return result
    
    def get_resource_type(self) -> str:
        """Get the resource type this editor handles (EditorInterface implementation)"""
        return "textures"
    
    def update_project_data(self):
        """Update the runtime data with current texture state (called before main save)"""
        # Update the runtime data with current texture state
        serializable_data = self.get_texture_data()
        
        # Update the texture in runtime
        resource_id = self.resource_data.get("id")
        if resource_id:
            self.app.project_manager.update_runtime_resource("textures", resource_id, serializable_data)
            debug(f"Updated texture {resource_id} in runtime")
    
    def release_file_handles(self):
        """Release file handles to allow file operations"""
        # Clear the runtime_frames to release PIL Image objects
        self.runtime_frames.clear()
        debug(f"Released file handles for texture {self.resource_data.get('name', 'Unknown')}")
    
    def delete_sprite_files(self):
        """Delete all frame files associated with this sprite"""
        import os
        
        # Get the sprites folder path
        sprites_folder = os.path.join(
            self.app.project_manager.get_project_path(),
            "Resources", "Sprites"
        )
        
        # Delete all frame files
        frames = self.resource_data.get("frames", [])
        for frame in frames:
            if "file" in frame:
                frame_path = os.path.join(sprites_folder, frame["file"])
                if os.path.exists(frame_path):
                    try:
                        os.remove(frame_path)
                        print(f"Deleted frame file: {frame['file']}")
                    except Exception as e:
                        print(f"Failed to delete frame file {frame['file']}: {e}")
        
        # Delete the sprite file itself
        if os.path.exists(self.original_file_path):
            try:
                os.remove(self.original_file_path)
                print(f"Deleted sprite file: {self.original_file_path}")
            except Exception as e:
                print(f"Failed to delete sprite file: {e}")
    
    def rename_sprite_files(self, old_name, new_name):
        """Rename all frame files when sprite is renamed"""
        import os
        
        # Get the sprites folder path
        sprites_folder = os.path.join(
            self.app.project_manager.get_project_path(),
            "Resources", "Sprites"
        )
        
        # Rename all frame files
        frames = self.resource_data.get("frames", [])
        for frame in frames:
            if "file" in frame:
                old_frame_path = os.path.join(sprites_folder, frame["file"])
                if os.path.exists(old_frame_path):
                    # Generate new filename
                    new_frame_filename = frame["file"].replace(old_name, new_name)
                    new_frame_path = os.path.join(sprites_folder, new_frame_filename)
                    
                    try:
                        os.rename(old_frame_path, new_frame_path)
                        # Update the frame reference
                        frame["file"] = new_frame_filename
                        print(f"Renamed frame file: {frame['file']} -> {new_frame_filename}")
                    except Exception as e:
                        print(f"Failed to rename frame file {frame['file']}: {e}")
        
        # Update the sprite file path
        old_file_path = self.original_file_path
        new_file_path = old_file_path.replace(old_name, new_name)
        
        if os.path.exists(old_file_path):
            try:
                os.rename(old_file_path, new_file_path)
                self.original_file_path = new_file_path
                print(f"Renamed sprite file: {old_file_path} -> {new_file_path}")
            except Exception as e:
                print(f"Failed to rename sprite file: {e}")
    
    def update_sprite_name(self, new_name):
        """Update sprite name and rename all associated files"""
        old_name = self.resource_data.get("name", "")
        if old_name and old_name != new_name:
            # Rename all frame files
            self.rename_sprite_files(old_name, new_name)
            
            # Update resource data
            self.resource_data["name"] = new_name
            
            # Save the updated sprite file
            self.save_resource()

class SpritePreviewCanvas(QWidget):
    def __init__(self, editor):
        super().__init__()
        self.editor = editor
        self.setMinimumSize(300, 300)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        
        # For bounding box dragging
        self.bbox_drag_start = None
        self.bbox_dragging = False
    
    def paintEvent(self, event):
        """Paint the sprite preview"""
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        
        # Clear background - use theme color
        if hasattr(self.editor, 'app') and self.editor.app and hasattr(self.editor.app, 'theme_manager'):
            colors = self.editor.app.theme_manager.get_colors()
            bg_color = QColor(colors.get('sprite_canvas', '#000000'))
        else:
            bg_color = QColor(0, 0, 0)
        painter.fillRect(self.rect(), bg_color)
        
        # Draw sprite
        self.draw_sprite(painter)
    
    def draw_grid(self, painter):
        """Draw grid on the canvas"""
        grid_size = 32
        pen = QPen(QColor(200, 200, 200), 1)
        painter.setPen(pen)
        
        # Vertical lines
        for x in range(0, self.width(), grid_size):
            painter.drawLine(x, 0, x, self.height())
        
        # Horizontal lines
        for y in range(0, self.height(), grid_size):
            painter.drawLine(0, y, self.width(), y)
    
    def draw_sprite(self, painter):
        """Draw the current sprite frame"""
        if not self.editor.resource_data:
            return
        
        frames = self.editor.resource_data.get("frames", [])
        if not frames or self.editor.current_frame >= len(frames):
            return
        
        # Get sprite dimensions
        sprite_width = self.editor.resource_data.get("width", 32)
        sprite_height = self.editor.resource_data.get("height", 32)
        
        # Calculate scaling to fit the canvas while maintaining aspect ratio
        canvas_width = self.width() - 40  # Leave some margin
        canvas_height = self.height() - 40
        
        # Calculate scale factors
        scale_x = canvas_width / sprite_width
        scale_y = canvas_height / sprite_height
        scale = min(scale_x, scale_y)  # Use smaller scale to fit in canvas
        
        # Don't scale up large sprites - only scale down
        scale = min(scale, 1.0)
        
        # Calculate scaled dimensions
        scaled_width = int(sprite_width * scale)
        scaled_height = int(sprite_height * scale)
        
        # Calculate position to center the sprite
        x = (self.width() - scaled_width) // 2
        y = (self.height() - scaled_height) // 2
        
        
        # Get current frame data
        current_frame_data = frames[self.editor.current_frame]
        
        # Check if we have actual image data
        if self.editor.current_frame < len(self.editor.runtime_frames):
            # Get PIL image from runtime_frames
            pil_image = self.editor.runtime_frames[self.editor.current_frame]
            if pil_image:
                # Convert PIL to QImage
                from PySide6.QtGui import QImage
                import numpy as np
                
                # Convert PIL RGBA to numpy array
                img_array = np.array(pil_image)
                h, w, ch = img_array.shape
                
                # Create QImage from numpy array
                qimg = QImage(img_array.data, w, h, ch * w, QImage.Format_RGBA8888)
                qpixmap = QPixmap.fromImage(qimg)
                
                # Draw the actual image
                painter.drawPixmap(x, y, scaled_width, scaled_height, qpixmap)
            else:
                # Fallback to placeholder
                self.draw_placeholder(painter, x, y, scaled_width, scaled_height, sprite_width, sprite_height)
        else:
            # Fallback to placeholder
            self.draw_placeholder(painter, x, y, scaled_width, scaled_height, sprite_width, sprite_height)
        
        # Draw frame number (fixed position in top-left corner of widget, not relative to sprite)
        painter.setPen(QPen(QColor(255, 255, 255), 1))
        font = painter.font()
        font.setPointSize(10)  # Fixed font size
        painter.setFont(font)
        # Draw at fixed position in top-left corner of the widget
        painter.drawText(5, 15, f"Frame {self.editor.current_frame + 1}")
    
    def draw_placeholder(self, painter, x, y, width, height, sprite_width, sprite_height):
        """Draw placeholder rectangle when no image data is available"""
        pen = QPen(QColor(150, 150, 150), 2)
        painter.setPen(pen)
        painter.setBrush(QBrush(QColor(200, 200, 200)))
        painter.drawRect(x, y, width, height)
        
        # Draw origin point if set (normal size, not scaled)
        origin_x = self.editor.resource_data.get("origin_x", sprite_width // 2)
        origin_y = self.editor.resource_data.get("origin_y", sprite_height // 2)
        
        # Calculate scale factor
        scale = width / sprite_width if sprite_width > 0 else 1.0
        
        # Scale origin coordinates
        origin_screen_x = x + int(origin_x * scale)
        origin_screen_y = y + int(origin_y * scale)
        
        # Draw origin crosshair (normal size, not scaled)
        crosshair_size = 8  # Fixed crosshair size
        painter.setPen(QPen(QColor(255, 0, 0), 2))
        painter.drawLine(origin_screen_x - crosshair_size, origin_screen_y, 
                        origin_screen_x + crosshair_size, origin_screen_y)
        painter.drawLine(origin_screen_x, origin_screen_y - crosshair_size, 
                        origin_screen_x, origin_screen_y + crosshair_size)
        
        # Draw bounding box if not using precise collision
        if not self.editor.resource_data.get("precise_collision", True):
            collision_bbox = self.editor.resource_data.get("collision_bbox", {})
            if collision_bbox:
                bbox_x = collision_bbox.get("x", 0)
                bbox_y = collision_bbox.get("y", 0)
                bbox_w = collision_bbox.get("width", sprite_width)
                bbox_h = collision_bbox.get("height", sprite_height)
                
                # Scale bounding box coordinates
                bbox_screen_x = x + int(bbox_x * scale)
                bbox_screen_y = y + int(bbox_y * scale)
                bbox_screen_w = int(bbox_w * scale)
                bbox_screen_h = int(bbox_h * scale)
                
                # Draw bounding box with yellow/orange color
                painter.setPen(QPen(QColor(255, 200, 0), 2))
                painter.setBrush(QBrush())  # No fill
                painter.drawRect(bbox_screen_x, bbox_screen_y, bbox_screen_w, bbox_screen_h)
                
                # Draw corner handles if in edit mode
                if hasattr(self.editor, 'bbox_editing_mode') and self.editor.bbox_editing_mode:
                    handle_size = 6
                    handles = [
                        (bbox_screen_x, bbox_screen_y),  # Top-left
                        (bbox_screen_x + bbox_screen_w, bbox_screen_y),  # Top-right
                        (bbox_screen_x, bbox_screen_y + bbox_screen_h),  # Bottom-left
                        (bbox_screen_x + bbox_screen_w, bbox_screen_y + bbox_screen_h),  # Bottom-right
                    ]
                    for hx, hy in handles:
                        painter.fillRect(hx - handle_size//2, hy - handle_size//2, handle_size, handle_size, QColor(255, 200, 0))
        
        # Draw sprite border
        painter.setPen(QPen(QColor(100, 100, 100), 1))
        painter.setBrush(QBrush())  # No fill
        painter.drawRect(x, y, width, height)
    
    def _get_sprite_coords_from_screen(self, screen_x, screen_y):
        """Convert screen coordinates to sprite coordinates"""
        if not self.editor.resource_data:
            return None, None
        
        sprite_width = self.editor.resource_data.get("width", 32)
        sprite_height = self.editor.resource_data.get("height", 32)
        
        # Calculate scaling (same as in draw_sprite)
        canvas_width = self.width() - 40
        canvas_height = self.height() - 40
        scale_x = canvas_width / sprite_width
        scale_y = canvas_height / sprite_height
        scale = min(scale_x, scale_y, 1.0)
        
        # Calculate sprite position on canvas
        scaled_width = int(sprite_width * scale)
        scaled_height = int(sprite_height * scale)
        sprite_x = (self.width() - scaled_width) // 2
        sprite_y = (self.height() - scaled_height) // 2
        
        # Convert screen coords to sprite coords
        if screen_x < sprite_x or screen_x > sprite_x + scaled_width:
            return None, None
        if screen_y < sprite_y or screen_y > sprite_y + scaled_height:
            return None, None
        
        sprite_coord_x = int((screen_x - sprite_x) / scale)
        sprite_coord_y = int((screen_y - sprite_y) / scale)
        
        # Clamp to sprite bounds
        sprite_coord_x = max(0, min(sprite_width - 1, sprite_coord_x))
        sprite_coord_y = max(0, min(sprite_height - 1, sprite_coord_y))
        
        return sprite_coord_x, sprite_coord_y
    
    def mousePressEvent(self, event):
        """Handle mouse click for origin/bbox setting"""
        if event.button() == Qt.LeftButton:
            screen_x = event.position().x()
            screen_y = event.position().y()
            sprite_x, sprite_y = self._get_sprite_coords_from_screen(screen_x, screen_y)
            
            if sprite_x is not None and sprite_y is not None:
                # Origin setting mode
                if hasattr(self.editor, 'origin_setting_mode') and self.editor.origin_setting_mode:
                    self.editor.origin_x_spin.setValue(sprite_x)
                    self.editor.origin_y_spin.setValue(sprite_y)
                    # Turn off origin setting mode after clicking
                    self.editor.set_origin_button.setChecked(False)
                    self.editor.origin_setting_mode = False
                    self.setCursor(Qt.ArrowCursor)
                    self.update()
                
                # Bounding box editing mode - start drag
                elif hasattr(self.editor, 'bbox_editing_mode') and self.editor.bbox_editing_mode:
                    self.bbox_drag_start = (sprite_x, sprite_y)
                    self.bbox_dragging = True
                    self.update()
    
    def mouseMoveEvent(self, event):
        """Handle mouse move for bounding box dragging"""
        if self.bbox_dragging and self.bbox_drag_start:
            screen_x = event.position().x()
            screen_y = event.position().y()
            sprite_x, sprite_y = self._get_sprite_coords_from_screen(screen_x, screen_y)
            
            if sprite_x is not None and sprite_y is not None:
                # Calculate bounding box from drag
                start_x, start_y = self.bbox_drag_start
                bbox_x = min(start_x, sprite_x)
                bbox_y = min(start_y, sprite_y)
                bbox_w = abs(sprite_x - start_x) + 1
                bbox_h = abs(sprite_y - start_y) + 1
                
                # Update spinboxes (this will trigger on_bbox_changed)
                self.editor.bbox_x_spin.setValue(bbox_x)
                self.editor.bbox_y_spin.setValue(bbox_y)
                self.editor.bbox_w_spin.setValue(bbox_w)
                self.editor.bbox_h_spin.setValue(bbox_h)
                
                self.update()
    
    def mouseReleaseEvent(self, event):
        """Handle mouse release"""
        if event.button() == Qt.LeftButton and self.bbox_dragging:
            self.bbox_dragging = False
            self.bbox_drag_start = None
            self.update()

class SpriteSettingsDialog(QDialog):
    def __init__(self, parent, resource_data):
        super().__init__(parent)
        self.resource_data = resource_data
        self.setWindowTitle("Sprite Settings")
        self.setModal(True)
        self.resize(400, 300)
        
        self.setup_ui()
        self.load_settings()
    
    def setup_ui(self):
        """Setup the settings dialog UI"""
        layout = QVBoxLayout(self)
        
        # Create tabs
        tabs = QTabWidget()
        
        # Origin tab
        origin_tab = self.create_origin_tab()
        tabs.addTab(origin_tab, "Origin")
        
        # Collision tab
        collision_tab = self.create_collision_tab()
        tabs.addTab(collision_tab, "Collision Shape")
        
        layout.addWidget(tabs)
        
        # Dialog buttons
        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)
    
    def create_origin_tab(self):
        """Create the origin settings tab"""
        tab = QWidget()
        layout = QVBoxLayout(tab)
        
        # Origin coordinates
        coords_group = QGroupBox("Origin Coordinates")
        coords_layout = QGridLayout(coords_group)
        
        coords_layout.addWidget(QLabel("X:"), 0, 0)
        self.origin_x_spin = QSpinBox()
        self.origin_x_spin.setRange(0, 1024)
        coords_layout.addWidget(self.origin_x_spin, 0, 1)
        
        coords_layout.addWidget(QLabel("Y:"), 1, 0)
        self.origin_y_spin = QSpinBox()
        self.origin_y_spin.setRange(0, 1024)
        coords_layout.addWidget(self.origin_y_spin, 1, 1)
        
        layout.addWidget(coords_group)
        
        # Quick origin buttons
        buttons_group = QGroupBox("Quick Origin")
        buttons_layout = QGridLayout(buttons_group)
        
        # Create 3x3 grid of origin buttons
        positions = [
            ("Top Left", 0, 0), ("Top Center", 0, 1), ("Top Right", 0, 2),
            ("Middle Left", 1, 0), ("Middle Center", 1, 1), ("Middle Right", 1, 2),
            ("Bottom Left", 2, 0), ("Bottom Center", 2, 1), ("Bottom Right", 2, 2)
        ]
        
        for text, row, col in positions:
            button = QPushButton(text)
            button.clicked.connect(lambda checked, pos=text: self.set_quick_origin(pos))
            buttons_layout.addWidget(button, row, col)
        
        layout.addWidget(buttons_group)
        layout.addStretch()
        
        return tab
    
    def create_collision_tab(self):
        """Create the collision settings tab"""
        tab = QWidget()
        layout = QVBoxLayout(tab)
        
        # Collision type
        type_group = QGroupBox("Collision Type")
        type_layout = QVBoxLayout(type_group)
        
        self.collision_automatic = QCheckBox("Automatic")
        self.collision_automatic.toggled.connect(self.on_collision_type_changed)
        type_layout.addWidget(self.collision_automatic)
        
        self.collision_manual = QCheckBox("Manual")
        self.collision_manual.toggled.connect(self.on_collision_type_changed)
        type_layout.addWidget(self.collision_manual)
        
        layout.addWidget(type_group)
        
        # Manual collision settings
        self.manual_group = QGroupBox("Manual Collision Settings")
        manual_layout = QVBoxLayout(self.manual_group)
        
        # Shape selection
        shape_layout = QHBoxLayout()
        shape_layout.addWidget(QLabel("Shape:"))
        self.shape_combo = QComboBox()
        self.shape_combo.addItems(["Rectangle", "Ellipse", "Diamond"])
        shape_layout.addWidget(self.shape_combo)
        manual_layout.addLayout(shape_layout)
        
        # Collision coordinates
        coords_layout = QGridLayout()
        
        coords_layout.addWidget(QLabel("Top Left X:"), 0, 0)
        self.tl_x_spin = QSpinBox()
        self.tl_x_spin.setRange(0, 1024)
        coords_layout.addWidget(self.tl_x_spin, 0, 1)
        
        coords_layout.addWidget(QLabel("Top Left Y:"), 0, 2)
        self.tl_y_spin = QSpinBox()
        self.tl_y_spin.setRange(0, 1024)
        coords_layout.addWidget(self.tl_y_spin, 0, 3)
        
        coords_layout.addWidget(QLabel("Bottom Right X:"), 1, 0)
        self.br_x_spin = QSpinBox()
        self.br_x_spin.setRange(0, 1024)
        coords_layout.addWidget(self.br_x_spin, 1, 1)
        
        coords_layout.addWidget(QLabel("Bottom Right Y:"), 1, 2)
        self.br_y_spin = QSpinBox()
        self.br_y_spin.setRange(0, 1024)
        coords_layout.addWidget(self.br_y_spin, 1, 3)
        
        manual_layout.addLayout(coords_layout)
        layout.addWidget(self.manual_group)
        
        layout.addStretch()
        return tab
    
    def load_settings(self):
        """Load current settings"""
        # Load origin settings
        self.origin_x_spin.setValue(self.resource_data.get("origin_x", 0))
        self.origin_y_spin.setValue(self.resource_data.get("origin_y", 0))
        
        # Load collision settings
        collision_type = self.resource_data.get("collision_type", "automatic")
        if collision_type == "automatic":
            self.collision_automatic.setChecked(True)
            self.collision_manual.setChecked(False)
        else:
            self.collision_automatic.setChecked(False)
            self.collision_manual.setChecked(True)
        
        self.on_collision_type_changed()
        
        # Load manual collision settings
        self.tl_x_spin.setValue(self.resource_data.get("collision_tl_x", 0))
        self.tl_y_spin.setValue(self.resource_data.get("collision_tl_y", 0))
        self.br_x_spin.setValue(self.resource_data.get("collision_br_x", 32))
        self.br_y_spin.setValue(self.resource_data.get("collision_br_y", 32))
        
        shape = self.resource_data.get("collision_shape", "Rectangle")
        self.shape_combo.setCurrentText(shape)
    
    def set_quick_origin(self, position):
        """Set origin based on quick position"""
        width = self.resource_data.get("width", 32)
        height = self.resource_data.get("height", 32)
        
        positions = {
            "Top Left": (0, 0),
            "Top Center": (width // 2, 0),
            "Top Right": (width, 0),
            "Middle Left": (0, height // 2),
            "Middle Center": (width // 2, height // 2),
            "Middle Right": (width, height // 2),
            "Bottom Left": (0, height),
            "Bottom Center": (width // 2, height),
            "Bottom Right": (width, height)
        }
        
        if position in positions:
            x, y = positions[position]
            self.origin_x_spin.setValue(x)
            self.origin_y_spin.setValue(y)
    
    def on_collision_type_changed(self):
        """Handle collision type change"""
        is_manual = self.collision_manual.isChecked()
        self.manual_group.setEnabled(is_manual)
    
    def get_settings(self):
        """Get current settings"""
        settings = {
            "origin_x": self.origin_x_spin.value(),
            "origin_y": self.origin_y_spin.value(),
            "collision_type": "manual" if self.collision_manual.isChecked() else "automatic",
            "collision_shape": self.shape_combo.currentText(),
            "collision_tl_x": self.tl_x_spin.value(),
            "collision_tl_y": self.tl_y_spin.value(),
            "collision_br_x": self.br_x_spin.value(),
            "collision_br_y": self.br_y_spin.value()
        }
        return settings
