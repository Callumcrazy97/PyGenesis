"""
Background Editor for Python Game IDE
Uses BaseImageResourceEditor for common functionality
"""

from PySide6.QtWidgets import QMessageBox, QDialog
from Core.Debug import debug
from Editors.Shared.BaseImageResourceEditor import BaseImageResourceEditor


class BackgroundEditor(BaseImageResourceEditor):
    """Background Editor - inherits from BaseImageResourceEditor"""
    
    def __init__(self, app, resource_data):
        super().__init__(app, resource_data, "backgrounds")
        self.image_editor = None
    
    def load_resource_files(self):
        """Load background files (images, GIF)"""
        from PySide6.QtWidgets import QFileDialog
        files, _ = QFileDialog.getOpenFileNames(
            self, "Load Background Images", "", 
            "Image Files (*.png *.jpg *.jpeg *.gif *.bmp);;All Files (*.*)"
        )
        if files:
            self.load_background_from_files(files)
    
    def load_background_from_files(self, files):
        """Load background from selected files"""
        if not files:
            return
        
        from PIL import Image
        import os
        
        frames = []
        background_name = self.name_edit.text() if hasattr(self, 'name_edit') and self.name_edit.text() else self.resource_data.get("name", "background")
        
        debug(f"Loading background files for background: '{background_name}'")
        
        # Get the backgrounds folder path, including parent folder if specified
        backgrounds_folder = os.path.join(
            self.app.project_manager.get_project_path(),
            "Resources", "Backgrounds"
        )
        
        # Add parent folder to path if specified
        parent_folder = self.resource_data.get("parent_folder", "")
        if parent_folder:
            backgrounds_folder = os.path.join(backgrounds_folder, parent_folder)
        
        os.makedirs(backgrounds_folder, exist_ok=True)
        
        for file_path in files:
            try:
                # Load image file
                img = Image.open(file_path)
                
                if img.format == "GIF" and hasattr(img, 'n_frames') and img.n_frames > 1:
                    # Animated GIF - extract all frames
                    for frame_idx in range(img.n_frames):
                        img.seek(frame_idx)
                        frame = img.convert("RGBA")
                        
                        # Save frame as individual PNG file
                        frame_filename = f"{background_name}_{len(frames)}.png"
                        frame_path = os.path.join(backgrounds_folder, frame_filename)
                        frame.save(frame_path, "PNG")
                        debug(f"Created frame file: {frame_filename}")
                        
                        # Store frame reference in background data
                        frames.append({
                            "id": f"frame_{len(frames)}",
                            "file": frame_filename,
                            "duration": img.info.get('duration', 100) / 1000.0,
                            "tags": []
                        })
                        
                        # Store PIL object for runtime use
                        self.runtime_frames.append(frame)
                else:
                    # Static image
                    frame = img.convert("RGBA")
                    
                    # Save frame as individual PNG file
                    frame_filename = f"{background_name}_{len(frames)}.png"
                    frame_path = os.path.join(backgrounds_folder, frame_filename)
                    frame.save(frame_path, "PNG")
                    debug(f"Created frame file: {frame_filename}")
                    
                    # Store frame reference in background data
                    frames.append({
                        "id": f"frame_{len(frames)}",
                        "file": frame_filename,
                        "duration": 1.0,
                        "tags": []
                    })
                    
                    # Store PIL object for runtime use
                    self.runtime_frames.append(frame)
                    
            except Exception as e:
                QMessageBox.warning(self, "Error", f"Failed to load {file_path}: {str(e)}")
                continue
        
        if frames:
            # Update background data with frame references
            self.resource_data["frames"] = frames
            self.total_frames = len(frames)
            self.current_frame = 0
            self.frames_label.setText(f"Number of subimages: {self.total_frames}")
            self.update_frame_display()
            
            # Update dimensions from first frame
            if self.runtime_frames:
                first_frame = self.runtime_frames[0]
                width, height = first_frame.size
                self.resource_data["width"] = width
                self.resource_data["height"] = height
                self.width_label.setText(f"Width: {width}")
                self.height_label.setText(f"Height: {height}")
            
            self._dirty = True
            self._update_animation_combo()
            
            if hasattr(self, 'preview_canvas'):
                self.preview_canvas.update()
    
    def open_image_editor(self):
        """Open the integrated PySide6 image editor"""
        try:
            # Import the PySide6 image editor components
            import sys
            import os
            
            # Add the Image Editor path to sys.path
            image_editor_path = os.path.join(os.path.dirname(__file__), "..", "ImageEditor", "core")
            if image_editor_path not in sys.path:
                sys.path.insert(0, image_editor_path)
            
            from Editors.ImageEditor.core.ui.main_window import MainWindow as ImageEditorMainWindow
            from Editors.ImageEditor.core.core.state import EditorState
            from Editors.ImageEditor.core.ui.dialogs.new_image_dialog import NewImageDialog
            
            # CRITICAL: Reload resource data from disk to get latest tags/colors before opening editor
            resource_id = self.resource_data.get("id") if self.resource_data else None
            if resource_id and self.app and hasattr(self.app, 'resource_manager'):
                debug(f"DEBUG open_image_editor: Reloading background {resource_id} from disk before opening editor...")
                fresh_resource_data = self.app.resource_manager.load_resource_from_disk("backgrounds", resource_id)
                if fresh_resource_data:
                    debug(f"DEBUG open_image_editor: Reloaded data with {len(fresh_resource_data.get('frames', []))} frames")
                    # Update resource_data with fresh data
                    self.resource_data = fresh_resource_data
                    # Also update resource_data frames to ensure tags field exists
                    for i, frame in enumerate(self.resource_data.get("frames", [])):
                        if isinstance(frame, dict):
                            if "tags" not in frame:
                                frame["tags"] = []
                            if "color_code" not in frame:
                                frame["color_code"] = None
                else:
                    debug(f"DEBUG open_image_editor: WARNING - Could not reload from disk")
            
            # Check if we have existing background data
            background_data = self.get_background_data()
            has_existing_data = self.has_existing_background_data()
            
            # If no existing data, show new image dialog
            if not has_existing_data:
                dialog = NewImageDialog(self)
                if dialog.exec() == QDialog.Accepted:
                    width, height = dialog.get_size()
                    # Update background data with new dimensions
                    background_data["width"] = width
                    background_data["height"] = height
                    # Update the UI to reflect new dimensions
                    self.update_background_dimensions(width, height)
                else:
                    # User cancelled, don't open image editor
                    return
            
            # Create integrated image editor
            from Editors.SpriteEditor.SpriteEditor import IntegratedImageEditor
            self.image_editor = IntegratedImageEditor(
                parent=self, 
                resource_data=background_data,
                resource_type="backgrounds",
                on_save_callback=self.on_background_saved,
                app=self.app
            )
            
            # Show the editor in a container within the background editor
            self.show_image_editor()
            
        except ImportError as e:
            QMessageBox.critical(self, "Error", f"Failed to import Image Editor: {str(e)}")
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to open Image Editor: {str(e)}")
            import traceback
            debug(traceback.format_exc())
    
    def show_image_editor(self):
        """Show the image editor in a new tab"""
        if not hasattr(self, 'image_editor') or self.image_editor is None:
            return
        
        # Get background name for tab title
        background_name = self.name_edit.text() or "Untitled"
        tab_title = f"Image Editor - {background_name}"
        
        # Check if editor tab already exists
        for i in range(self.tab_widget.count()):
            if self.tab_widget.tabText(i).startswith("Image Editor -"):
                # Replace existing editor tab
                self.tab_widget.removeTab(i)
                break
        
        # Create fullscreen container for the image editor
        from PySide6.QtWidgets import QWidget
        from PySide6.QtWidgets import QVBoxLayout
        editor_container = QWidget()
        editor_container.setStyleSheet("""
            QWidget {
                background-color: #2b2b2b;
            }
        """)
        
        # Add the image editor to the container (fullscreen)
        editor_layout = QVBoxLayout(editor_container)
        editor_layout.setContentsMargins(0, 0, 0, 0)
        editor_layout.addWidget(self.image_editor)
        
        # Add container as new tab
        self.tab_widget.addTab(editor_container, tab_title)
        self.tab_widget.setCurrentIndex(self.tab_widget.count() - 1)
        
        # Show close editor button
        if hasattr(self, 'close_editor_button'):
            self.close_editor_button.show()
    
    def close_image_editor(self):
        """Close the image editor"""
        if hasattr(self, 'image_editor') and self.image_editor:
            # Find and remove the image editor tab
            for i in range(self.tab_widget.count()):
                if self.tab_widget.tabText(i).startswith("Image Editor -"):
                    self.tab_widget.removeTab(i)
                    break
            
            # Clean up
            self.image_editor = None
            
            # Hide close editor button
            if hasattr(self, 'close_editor_button'):
                self.close_editor_button.hide()
    
    def get_background_data(self):
        """Get current background data for the image editor"""
        # Get frames with file references (no PIL objects)
        frames = self.resource_data.get("frames", [])
        serializable_frames = []
        for frame in frames:
            serializable_frame = {
                "id": frame.get("id", ""),
                "file": frame.get("file", ""),
                "tags": frame.get("tags", []),
                "color_code": frame.get("color_code"),
                "duration": frame.get("duration", 1.0)
            }
            serializable_frames.append(serializable_frame)
        
        return {
            "id": self.resource_data.get("id", ""),
            "name": self.resource_data.get("name", ""),
            "type": "background",
            "parent_folder": self.resource_data.get("parent_folder", ""),
            "width": self.resource_data.get("width", 32),
            "height": self.resource_data.get("height", 32),
            "frames": serializable_frames,
            "origin_x": self.resource_data.get("origin_x", 0),
            "origin_y": self.resource_data.get("origin_y", 0)
        }
    
    def has_existing_background_data(self):
        """Check if background has existing frame data"""
        frames = self.resource_data.get("frames", [])
        return len(frames) > 0
    
    def update_background_dimensions(self, width, height):
        """Update background dimensions in UI"""
        self.resource_data["width"] = width
        self.resource_data["height"] = height
        self.width_label.setText(f"Width: {width}")
        self.height_label.setText(f"Height: {height}")
        self._dirty = True
    
    def on_background_saved(self, saved_data):
        """Handle background saved from image editor"""
        try:
            # Update resource_data with saved data
            if saved_data:
                # Update frames with saved data
                self.resource_data["frames"] = saved_data.get("frames", [])
                self.total_frames = len(self.resource_data["frames"])
                self.frames_label.setText(f"Number of subimages: {self.total_frames}")
                
                # Update dimensions if changed
                if "width" in saved_data:
                    self.resource_data["width"] = saved_data["width"]
                    self.width_label.setText(f"Width: {saved_data['width']}")
                if "height" in saved_data:
                    self.resource_data["height"] = saved_data["height"]
                    self.height_label.setText(f"Height: {saved_data['height']}")
                
                # Update other properties
                self.resource_data.update({k: v for k, v in saved_data.items() if k != "frames"})
                
                # Update UI elements
                self.name_edit.setText(saved_data.get("name", ""))
                self.origin_x_spin.setValue(saved_data.get("origin_x", 0))
                self.origin_y_spin.setValue(saved_data.get("origin_y", 0))
                
                # Save individual frame files to disk
                self.save_frame_files_to_disk(saved_data)
                
                # Save the background resource file to disk
                debug(f"DEBUG on_background_saved: About to call save_resource()")
                result = self.save_resource()
                debug(f"DEBUG on_background_saved: save_resource() returned {result}")
                
                # Update animation combo to reflect any new tags
                self._update_animation_combo()
                
                # Refresh preview
                if hasattr(self, 'preview_canvas'):
                    self.preview_canvas.update()
                
                # Notify the main application of changes
                if hasattr(self.app, 'project_manager'):
                    self.app.project_manager.mark_project_dirty()
                
                self._dirty = False
                debug("Background saved successfully")
        except Exception as e:
            debug(f"Error updating background from image editor: {e}")
            import traceback
            debug(traceback.format_exc())
    
    def _load_runtime_frames(self):
        """Load runtime frames from background files"""
        if not self.resource_data:
            return
        
        from PIL import Image
        import os
        
        self.runtime_frames = []
        frames = self.resource_data.get("frames", [])
        project_path = self.app.project_manager.get_project_path()
        parent_folder = self.resource_data.get("parent_folder", "")
        
        backgrounds_folder = os.path.join(project_path, "Resources", "Backgrounds")
        if parent_folder:
            backgrounds_folder = os.path.join(backgrounds_folder, parent_folder)
        
        for frame_data in frames:
            if isinstance(frame_data, dict):
                frame_file = frame_data.get("file", "")
                if frame_file:
                    frame_path = os.path.join(backgrounds_folder, frame_file)
                    if os.path.exists(frame_path):
                        try:
                            img = Image.open(frame_path).convert("RGBA")
                            self.runtime_frames.append(img)
                        except Exception as e:
                            debug(f"Failed to load frame {frame_file}: {e}")
    
    def save_resource(self):
        """Save the background resource"""
        if not self.resource_data:
            return False
        
        # Update resource data with current UI values
        self.resource_data["name"] = self.name_edit.text()
        self.resource_data["origin_x"] = self.origin_x_spin.value()
        self.resource_data["origin_y"] = self.origin_y_spin.value()
        
        # Get serializable data (no PIL objects)
        serializable_data = self.get_background_data()
        
        # Save to disk
        import os
        result = False
        if hasattr(self.app, 'resource_manager'):
            result = self.app.resource_manager.save_resource("backgrounds", serializable_data, self.original_file_path)
        
        if result:
            self._dirty = False
            debug(f"Background saved successfully with {len(serializable_data.get('frames', []))} frames")
        
        return result
    
    def save_frame_files_to_disk(self, background_data):
        """Save individual frame files to disk from Image Editor state - mirrors texture/sprite saving"""
        try:
            import os
            import numpy as np
            from PIL import Image
            
            # Get the backgrounds folder path
            if not hasattr(self, 'app') or not self.app.project_manager:
                debug("No app or project manager available for saving frame files")
                return
                
            project_path = self.app.project_manager.get_project_path()
            if not project_path:
                debug("No project path available for saving frame files")
                return
                
            backgrounds_folder = os.path.join(project_path, "Resources", "Backgrounds")
            parent_folder = background_data.get("parent_folder", "")
            if parent_folder:
                backgrounds_folder = os.path.join(backgrounds_folder, parent_folder)
            
            # Ensure the folder exists
            os.makedirs(backgrounds_folder, exist_ok=True)
            
            # Try to get image data directly from Image Editor state
            try:
                from core.state import state
                lm = state.layer_manager
                
                if lm.layers and len(lm.layers) > 0:
                    layer = lm.layers[0]
                    frames = background_data.get("frames", [])
                    
                    # Save each frame's image data directly from Image Editor
                    for frame_idx, frame_obj in enumerate(layer.frames):
                        if frame_obj.image is not None:
                            # Get filename from frame data or generate one
                            if frame_idx < len(frames):
                                filename = frames[frame_idx].get("file", f"{background_data.get('name', 'background')}_{frame_idx}.png")
                            else:
                                filename = f"{background_data.get('name', 'background')}_{frame_idx}.png"
                            
                            # Convert numpy array to PIL Image
                            img_array = frame_obj.image
                            
                            # Handle different image formats
                            if len(img_array.shape) == 3:
                                # RGB or RGBA
                                if img_array.shape[2] == 4:
                                    # RGBA
                                    pil_image = Image.fromarray(img_array.astype(np.uint8), 'RGBA')
                                elif img_array.shape[2] == 3:
                                    # RGB
                                    pil_image = Image.fromarray(img_array.astype(np.uint8), 'RGB')
                                else:
                                    debug(f"Unsupported image shape: {img_array.shape}")
                                    continue
                            else:
                                # Grayscale
                                pil_image = Image.fromarray(img_array.astype(np.uint8), 'L')
                            
                            # Save to disk
                            frame_path = os.path.join(backgrounds_folder, filename)
                            pil_image.save(frame_path, "PNG")
                            debug(f"Saved frame file: {filename} ({pil_image.size[0]}x{pil_image.size[1]})")
                            
            except Exception as e:
                debug(f"Could not save from Image Editor state, trying fallback: {e}")
                import traceback
                traceback.print_exc()
                
                # Fallback: Try to save from base64 image_data if available
                frames = background_data.get("frames", [])
                for frame in frames:
                    if isinstance(frame, dict) and "image_data" in frame:
                        import base64
                        # Decode base64 image data
                        img_data = base64.b64decode(frame["image_data"])
                        
                        # Get the filename
                        filename = frame.get("file", f"{background_data.get('name', 'background')}_{len(frames)}.png")
                        
                        # Save to disk
                        frame_path = os.path.join(backgrounds_folder, filename)
                        with open(frame_path, 'wb') as f:
                            f.write(img_data)
                        
                        debug(f"Saved frame file (base64): {filename}")
                    
        except Exception as e:
            debug(f"Error saving frame files to disk: {e}")
            import traceback
            traceback.print_exc()

