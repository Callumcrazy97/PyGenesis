"""
Base Image Resource Editor
Shared base class for SpriteEditor, TextureEditor, and BackgroundEditor
Eliminates code duplication by providing common functionality
"""

from PySide6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLabel, 
                               QPushButton, QSpinBox, QCheckBox, QScrollArea,
                               QFrame, QListWidget, QListWidgetItem,
                               QMessageBox, QFileDialog, QInputDialog, QComboBox, 
                               QSizePolicy, QLineEdit, QGroupBox, QGridLayout,
                               QTabWidget, QSlider)
from PySide6.QtCore import Qt, Signal, QSize, QTimer
from PySide6.QtGui import QPainter, QPen, QBrush, QColor, QPixmap, QFont, QAction

import os
import json
from typing import Dict, Optional
from Core.Debug import debug
from Core.EditorInterface import EditorInterface


class BaseImageResourceEditor(QWidget, EditorInterface):
    """
    Base class for image-based resource editors (Sprites, Textures, Backgrounds)
    
    This class provides all the common functionality, with subclasses only needing
    to override resource_type and resource-specific methods.
    """
    
    def __init__(self, app, resource_data, resource_type: str):
        """
        Initialize the base editor
        
        Args:
            app: Application instance
            resource_data: Resource data dictionary
            resource_type: Resource type string ("sprites", "textures", "backgrounds")
        """
        super().__init__()
        self.app = app
        self.resource_data = resource_data or {}
        self.resource_type = resource_type  # Set by subclass
        self._dirty = False  # Track unsaved changes
        self.current_frame = 0
        self.total_frames = 0
        self.is_playing = False
        self.playback_timer = QTimer()
        self.playback_timer.timeout.connect(self.next_frame)
        
        # Animation filtering
        self.selected_animation = None  # None means all frames, otherwise tag name
        self.animation_frames = []  # List of frame indices for current animation
        self.animation_frame_index = 0  # Current position in animation_frames list
        
        # Initialize runtime frames storage (separate from serializable data)
        self.runtime_frames = []  # Store PIL objects separately
        
        # Store the original file path for this resource
        if resource_data and hasattr(self.app, 'resource_manager'):
            self.original_file_path = self.app.resource_manager.get_resource_file_path(resource_type, resource_data)
        else:
            self.original_file_path = None
        
        # Connect to signals for resource updates
        if hasattr(self.app, 'resource_manager'):
            self.app.resource_manager.resource_updated.connect(self.on_resource_updated)
            self.app.resource_manager.resource_deleted.connect(self.on_resource_deleted)
        if hasattr(self.app, 'project_manager'):
            self.app.project_manager.project_loaded.connect(self.on_project_changed)
        
        # OPTIMIZATION: Build UI fully before showing (prevents flashing)
        from Core.EditorOptimizer import EditorOptimizer
        EditorOptimizer.build_editor_before_show(self, self._build_ui_complete)
        
        # OPTIMIZATION: Defer resource loading until after window is visible
        if resource_data:
            EditorOptimizer.defer_heavy_operation(lambda: self.open_resource(resource_data), delay_ms=0)
    
    def _build_ui_complete(self):
        """Build all UI components before showing (optimized)"""
        # Freeze updates during construction to prevent flashing
        self.setUpdatesEnabled(False)
        try:
            self.setup_ui()
        finally:
            self.setUpdatesEnabled(True)
    
    def setup_ui(self):
        """Setup the editor UI with tab system"""
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)
        
        # Create tab widget
        self.tab_widget = QTabWidget()
        # Tab widget styling will be handled by theme system
        
        # Create Home tab (resource properties view)
        self.home_tab = self.create_home_tab()
        self.tab_widget.addTab(self.home_tab, "Home")
        
        # Connect tab close signal
        self.tab_widget.tabCloseRequested.connect(self.on_tab_close_requested)
        
        layout.addWidget(self.tab_widget)
        
        # Store reference to panels for easy access
        self.properties_panel = self.home_tab.findChild(QFrame, "properties_panel")
        self.preview_panel = self.home_tab.findChild(QFrame, "preview_panel")
    
    def create_home_tab(self):
        """Create the home tab with resource properties and preview"""
        home_widget = QWidget()
        layout = QHBoxLayout(home_widget)
        layout.setContentsMargins(10, 10, 10, 10)
        layout.setSpacing(15)
        
        # Left panel - Resource Properties
        properties_panel = self.create_properties_panel()
        properties_panel.setObjectName("properties_panel")
        layout.addWidget(properties_panel, 0)  # Fixed width
        
        # Right panel - Resource Preview Box
        preview_panel = self.create_preview_panel()
        preview_panel.setObjectName("preview_panel")
        layout.addWidget(preview_panel, 1)  # Takes remaining space
        
        return home_widget
    
    def create_properties_panel(self):
        """Create the left properties panel - GameMaker style"""
        panel = QFrame()
        panel.setFrameStyle(QFrame.StyledPanel)
        panel.setFixedWidth(320)  # Fixed width like GameMaker
        # Panel styling will be handled by theme system
        layout = QVBoxLayout(panel)
        layout.setContentsMargins(15, 15, 15, 15)
        layout.setSpacing(15)
        
        # Basic Information Group
        grp_info = QGroupBox("Basic Information")
        l_info = QVBoxLayout()
        self.name_edit = QLineEdit()
        self.name_edit.textChanged.connect(self.on_name_changed)
        # Input field styling will be handled by theme system
        l_info.addWidget(QLabel("Name:"))
        l_info.addWidget(self.name_edit)
        
        self.load_button = QPushButton("Load Image(s)")
        self.load_button.clicked.connect(self.load_resource_files)
        # Button styling will be handled by theme system
        l_info.addWidget(self.load_button)
        
        self.edit_button = QPushButton("Edit")
        self.edit_button.clicked.connect(self.open_image_editor)
        # Button styling will be handled by theme system
        l_info.addWidget(self.edit_button)
        
        self.close_editor_button = QPushButton("Close Editor")
        self.close_editor_button.clicked.connect(self.close_image_editor)
        # Button styling will be handled by theme system
        self.close_editor_button.hide()  # Initially hidden
        l_info.addWidget(self.close_editor_button)
        
        grp_info.setLayout(l_info)
        layout.addWidget(grp_info)
        
        # Resource dimensions
        dims_group = QGroupBox("Dimensions")
        dims_layout = QVBoxLayout(dims_group)
        dims_layout.setContentsMargins(15, 20, 15, 15)
        dims_layout.setSpacing(8)
        
        self.width_label = QLabel("Width: 0")
        self.height_label = QLabel("Height: 0")
        self.frames_label = QLabel("Number of subimages: 0")
        
        dims_layout.addWidget(self.width_label)
        dims_layout.addWidget(self.height_label)
        dims_layout.addWidget(self.frames_label)
        layout.addWidget(dims_group)
        
        # Show frame - Hidden but kept for functionality
        show_layout = QHBoxLayout()
        show_layout.setSpacing(10)
        show_layout.addWidget(QLabel("Show:"))
        self.frame_spin = QSpinBox()
        self.frame_spin.setRange(0, 0)
        self.frame_spin.valueChanged.connect(self.on_frame_changed)
        # SpinBox styling will be handled by theme system
        show_layout.addWidget(self.frame_spin)
        show_layout.addStretch()
        # Hide the show frame section - functionality preserved
        show_container = QWidget()
        show_container.setLayout(show_layout)
        show_container.hide()
        layout.addWidget(show_container)
        
        # Origin settings
        origin_group = QGroupBox("Origin")
        origin_layout = QVBoxLayout(origin_group)
        origin_layout.setContentsMargins(15, 20, 15, 15)
        origin_layout.setSpacing(10)
        
        origin_coords_layout = QHBoxLayout()
        origin_coords_layout.setSpacing(10)
        origin_coords_layout.addWidget(QLabel("X:"))
        self.origin_x_spin = QSpinBox()
        self.origin_x_spin.setRange(0, 1024)
        self.origin_x_spin.valueChanged.connect(self.on_origin_changed)
        # SpinBox styling will be handled by theme system
        origin_coords_layout.addWidget(self.origin_x_spin)
        
        origin_coords_layout.addWidget(QLabel("Y:"))
        self.origin_y_spin = QSpinBox()
        self.origin_y_spin.setRange(0, 1024)
        self.origin_y_spin.valueChanged.connect(self.on_origin_changed)
        # SpinBox styling will be handled by theme system
        origin_coords_layout.addWidget(self.origin_y_spin)
        
        origin_layout.addLayout(origin_coords_layout)
        
        # Origin setting buttons
        button_layout = QHBoxLayout()
        
        # Center button
        self.center_button = QPushButton("Center")
        self.center_button.clicked.connect(self.center_origin)
        button_layout.addWidget(self.center_button)
        
        # Set Origin button (interactive - click this then click preview)
        self.set_origin_button = QPushButton("Set Origin")
        self.set_origin_button.setCheckable(True)
        self.set_origin_button.toggled.connect(self.on_set_origin_mode_toggled)
        button_layout.addWidget(self.set_origin_button)
        
        # Preset buttons
        preset_layout = QHBoxLayout()
        preset_layout.addWidget(QLabel("Presets:"))
        
        # Top-left
        self.origin_tl_button = QPushButton("TL")
        self.origin_tl_button.setToolTip("Top-Left (0, 0)")
        self.origin_tl_button.clicked.connect(lambda: self.set_origin_preset(0, 0))
        preset_layout.addWidget(self.origin_tl_button)
        
        # Top-center
        self.origin_tc_button = QPushButton("TC")
        self.origin_tc_button.setToolTip("Top-Center")
        self.origin_tc_button.clicked.connect(lambda: self.set_origin_preset(self.resource_data.get("width", 32) // 2, 0))
        preset_layout.addWidget(self.origin_tc_button)
        
        # Top-right
        self.origin_tr_button = QPushButton("TR")
        self.origin_tr_button.setToolTip("Top-Right")
        self.origin_tr_button.clicked.connect(lambda: self.set_origin_preset(self.resource_data.get("width", 32) - 1, 0))
        preset_layout.addWidget(self.origin_tr_button)
        
        origin_layout.addLayout(button_layout)
        origin_layout.addLayout(preset_layout)
        
        # Initialize origin setting mode
        self.origin_setting_mode = False
        
        layout.addWidget(origin_group)
        
        # Collision checking - Hidden but kept for functionality
        collision_group = QGroupBox("Collision Checking")
        collision_layout = QVBoxLayout(collision_group)
        collision_layout.setContentsMargins(15, 20, 15, 15)
        collision_layout.setSpacing(8)
        
        self.precise_check = QCheckBox("Precise collision checking")
        self.precise_check.toggled.connect(self.on_collision_changed)
        collision_layout.addWidget(self.precise_check)
        
        self.separate_check = QCheckBox("Separate collision masks")
        self.separate_check.toggled.connect(self.on_collision_changed)
        collision_layout.addWidget(self.separate_check)
        
        # Bounding box editing (for when not using precise collision)
        bounding_box_layout = QHBoxLayout()
        bounding_box_layout.addWidget(QLabel("Box:"))
        
        self.bbox_x_spin = QSpinBox()
        self.bbox_x_spin.setRange(-1024, 2048)
        self.bbox_x_spin.setToolTip("Bounding box X position")
        self.bbox_x_spin.valueChanged.connect(self.on_bbox_changed)
        bounding_box_layout.addWidget(QLabel("X:"))
        bounding_box_layout.addWidget(self.bbox_x_spin)
        
        self.bbox_y_spin = QSpinBox()
        self.bbox_y_spin.setRange(-1024, 2048)
        self.bbox_y_spin.setToolTip("Bounding box Y position")
        self.bbox_y_spin.valueChanged.connect(self.on_bbox_changed)
        bounding_box_layout.addWidget(QLabel("Y:"))
        bounding_box_layout.addWidget(self.bbox_y_spin)
        
        self.bbox_w_spin = QSpinBox()
        self.bbox_w_spin.setRange(1, 2048)
        self.bbox_w_spin.setToolTip("Bounding box width")
        self.bbox_w_spin.valueChanged.connect(self.on_bbox_changed)
        bounding_box_layout.addWidget(QLabel("W:"))
        bounding_box_layout.addWidget(self.bbox_w_spin)
        
        self.bbox_h_spin = QSpinBox()
        self.bbox_h_spin.setRange(1, 2048)
        self.bbox_h_spin.setToolTip("Bounding box height")
        self.bbox_h_spin.valueChanged.connect(self.on_bbox_changed)
        bounding_box_layout.addWidget(QLabel("H:"))
        bounding_box_layout.addWidget(self.bbox_h_spin)
        
        collision_layout.addLayout(bounding_box_layout)
        
        # Edit bounding box button (interactive - click this then drag on preview)
        self.edit_bbox_button = QPushButton("Edit Bounding Box")
        self.edit_bbox_button.setCheckable(True)
        self.edit_bbox_button.toggled.connect(self.on_edit_bbox_mode_toggled)
        collision_layout.addWidget(self.edit_bbox_button)
        
        self.modify_mask_button = QPushButton("Modify Mask")
        self.modify_mask_button.clicked.connect(self.modify_collision_mask)
        # Button styling will be handled by theme system
        collision_layout.addWidget(self.modify_mask_button)
        
        # Initialize bounding box editing mode
        self.bbox_editing_mode = False
        
        collision_group.hide()  # Hide but keep for functionality
        layout.addWidget(collision_group)
        
        # Texture settings - Hidden but kept for functionality
        texture_group = QGroupBox("Texture Settings")
        texture_layout = QVBoxLayout(texture_group)
        texture_layout.setContentsMargins(15, 20, 15, 15)
        texture_layout.setSpacing(8)
        
        self.tile_h_check = QCheckBox("Tile: Horizontal")
        self.tile_h_check.toggled.connect(self.on_texture_changed)
        texture_layout.addWidget(self.tile_h_check)
        
        self.tile_v_check = QCheckBox("Tile: Vertical")
        self.tile_v_check.toggled.connect(self.on_texture_changed)
        texture_layout.addWidget(self.tile_v_check)
        
        self.used_3d_check = QCheckBox("Used for 3D")
        self.used_3d_check.toggled.connect(self.on_texture_changed)
        texture_layout.addWidget(self.used_3d_check)
        
        texture_group_layout = QHBoxLayout()
        texture_group_layout.setSpacing(10)
        texture_group_layout.addWidget(QLabel("Texture Group:"))
        self.texture_group_combo = QComboBox()
        self.texture_group_combo.addItems(["Default", "Backgrounds", "Sprites", "UI"])
        # ComboBox styling will be handled by theme system
        texture_group_layout.addWidget(self.texture_group_combo)
        texture_layout.addLayout(texture_group_layout)
        
        texture_group.hide()  # Hide but keep for functionality
        layout.addWidget(texture_group)
        
        layout.addStretch()
        return panel
    
    def create_preview_panel(self):
        """Create the right preview panel - GameMaker style"""
        panel = QFrame()
        panel.setFrameStyle(QFrame.StyledPanel)
        # Panel styling will be handled by theme system
        layout = QVBoxLayout(panel)
        layout.setContentsMargins(10, 10, 10, 10)
        layout.setSpacing(10)
        
        # Preview widget wrapped in scroll area
        self.scroll_area = QScrollArea()
        self.scroll_area.setWidgetResizable(True)
        self.scroll_area.setAlignment(Qt.AlignCenter)
        # Import preview canvas from SpriteEditor (shared implementation)
        # SpritePreviewCanvas works for all image-based resources (sprites, textures, backgrounds)
        try:
            from Editors.SpriteEditor.SpriteEditor import SpritePreviewCanvas
            self.preview_canvas = SpritePreviewCanvas(self)
            self.preview_canvas.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
            self.scroll_area.setWidget(self.preview_canvas)
        except ImportError:
            # Fallback if SpritePreviewCanvas not available
            self.preview_canvas = QWidget()
            self.preview_canvas.setMinimumSize(300, 300)
            self.scroll_area.setWidget(self.preview_canvas)
        layout.addWidget(self.scroll_area, 1)
        
        # Animation Controls Group
        controls_group = QGroupBox("Animation Controls")
        controls_layout = QVBoxLayout(controls_group)
        
        # Play/Pause/Stop buttons
        button_layout = QHBoxLayout()
        self.play_button = QPushButton("▶ Play")
        self.play_button.clicked.connect(self.toggle_playback)
        self.pause_button = QPushButton("⏸ Pause")
        self.pause_button.clicked.connect(self.pause_animation)
        self.pause_button.setEnabled(False)
        self.stop_button = QPushButton("⏹ Stop")
        self.stop_button.clicked.connect(self.stop_playback)
        button_layout.addWidget(self.play_button)
        button_layout.addWidget(self.pause_button)
        button_layout.addWidget(self.stop_button)
        controls_layout.addLayout(button_layout)
        
        # Frame navigation
        frame_layout = QHBoxLayout()
        self.prev_button = QPushButton("◀ Prev")
        self.prev_button.clicked.connect(self.previous_frame)
        self.frame_counter = QLabel("Frame: 0 / 0")
        self.frame_counter.setAlignment(Qt.AlignCenter)
        self.next_button = QPushButton("Next ▶")
        self.next_button.clicked.connect(self.next_frame)
        frame_layout.addWidget(self.prev_button)
        frame_layout.addWidget(self.frame_counter)
        frame_layout.addWidget(self.next_button)
        controls_layout.addLayout(frame_layout)
        
        # Animation selector (tag system) - integrated nicely
        animation_layout = QHBoxLayout()
        animation_label = QLabel("Animation:")
        self.animation_combo = QComboBox()
        self.animation_combo.addItem("None")
        self.animation_combo.currentTextChanged.connect(self.on_animation_changed)
        animation_layout.addWidget(animation_label)
        animation_layout.addWidget(self.animation_combo)
        animation_layout.addStretch()
        controls_layout.addLayout(animation_layout)
        
        # Speed control
        speed_layout = QHBoxLayout()
        speed_label = QLabel("Speed (FPS):")
        self.slider_speed = QSlider(Qt.Horizontal)
        self.slider_speed.setRange(0, 60)
        
        # Get default FPS from preferences
        default_fps = 30  # Default fallback
        if hasattr(self.app, 'settings'):
            default_fps = self.app.settings.get("Default_Sprite_FPS", 30)
        
        self.slider_speed.setValue(default_fps)
        self.slider_speed.setTickInterval(1)
        self.slider_speed.setTickPosition(QSlider.TicksBelow)
        self.slider_speed.setSingleStep(1)
        self.slider_speed.valueChanged.connect(self.on_speed_changed)
        self.lbl_speed = QLabel(str(default_fps))
        self.lbl_speed.setMinimumWidth(30)
        self.lbl_speed.setAlignment(Qt.AlignCenter)
        speed_layout.addWidget(speed_label)
        speed_layout.addWidget(self.slider_speed)
        speed_layout.addWidget(self.lbl_speed)
        controls_layout.addLayout(speed_layout)
        
        # Scale mode toggle button
        scale_layout = QHBoxLayout()
        self.btn_scale_mode = QPushButton("Scaled")
        self.btn_scale_mode.clicked.connect(self.toggle_scale_mode)
        scale_layout.addWidget(self.btn_scale_mode)
        controls_layout.addLayout(scale_layout)
        
        layout.addWidget(controls_group)
        
        return panel
    
    # Abstract methods that subclasses must implement
    def get_resource_type(self) -> str:
        """Get the resource type this editor handles (EditorInterface implementation)"""
        return self.resource_type
    
    def load_resource_files(self):
        """Load resource files - subclasses should override with specific implementation"""
        raise NotImplementedError("Subclasses must implement load_resource_files")
    
    def open_image_editor(self):
        """Open the integrated image editor - subclasses should override with specific implementation"""
        raise NotImplementedError("Subclasses must implement open_image_editor")
    
    def close_image_editor(self):
        """Close the image editor - subclasses should override with specific implementation"""
        raise NotImplementedError("Subclasses must implement close_image_editor")
    
    def save_resource(self):
        """Save the resource - subclasses should override with specific implementation"""
        raise NotImplementedError("Subclasses must implement save_resource")
    
    # Common methods that can be shared
    def on_name_changed(self, name):
        """Handle name change"""
        if self.resource_data:
            self.resource_data["name"] = name
            self._dirty = True
    
    def on_frame_changed(self, frame):
        """Handle frame selection change"""
        if 0 <= frame < self.total_frames:
            self.current_frame = frame
            self.update_frame_display()
    
    def on_origin_changed(self):
        """Handle origin change"""
        if self.resource_data:
            self.resource_data["origin_x"] = self.origin_x_spin.value()
            self.resource_data["origin_y"] = self.origin_y_spin.value()
            self._dirty = True
            if hasattr(self, 'preview_canvas'):
                self.preview_canvas.update()
    
    def center_origin(self):
        """Center the origin"""
        width = self.resource_data.get("width", 32)
        height = self.resource_data.get("height", 32)
        self.origin_x_spin.setValue(width // 2)
        self.origin_y_spin.setValue(height // 2)
    
    def set_origin_preset(self, x, y):
        """Set origin to preset position"""
        self.origin_x_spin.setValue(x)
        self.origin_y_spin.setValue(y)
    
    def on_set_origin_mode_toggled(self, checked):
        """Handle set origin mode toggle"""
        self.origin_setting_mode = checked
        if hasattr(self, 'preview_canvas'):
            self.preview_canvas.update()
    
    def on_collision_changed(self):
        """Handle collision settings change"""
        if self.resource_data:
            self.resource_data["precise_collision"] = self.precise_check.isChecked()
            self.resource_data["separate_masks"] = self.separate_check.isChecked()
            self._dirty = True
    
    def on_bbox_changed(self):
        """Handle bounding box change"""
        if self.resource_data:
            if "collision_bbox" not in self.resource_data:
                self.resource_data["collision_bbox"] = {}
            self.resource_data["collision_bbox"]["x"] = self.bbox_x_spin.value()
            self.resource_data["collision_bbox"]["y"] = self.bbox_y_spin.value()
            self.resource_data["collision_bbox"]["width"] = self.bbox_w_spin.value()
            self.resource_data["collision_bbox"]["height"] = self.bbox_h_spin.value()
            self._dirty = True
            if hasattr(self, 'preview_canvas'):
                self.preview_canvas.update()
    
    def on_edit_bbox_mode_toggled(self, checked):
        """Handle edit bounding box mode toggle"""
        self.bbox_editing_mode = checked
        if hasattr(self, 'preview_canvas'):
            self.preview_canvas.update()
    
    def modify_collision_mask(self):
        """Modify collision mask - placeholder for future implementation"""
        QMessageBox.information(self, "Not Implemented", "Collision mask modification will be implemented in a future update.")
    
    def on_texture_changed(self):
        """Handle texture settings change"""
        if self.resource_data:
            self.resource_data["tile_horizontal"] = self.tile_h_check.isChecked()
            self.resource_data["tile_vertical"] = self.tile_v_check.isChecked()
            self.resource_data["used_3d"] = self.used_3d_check.isChecked()
            self.resource_data["texture_group"] = self.texture_group_combo.currentText()
            self._dirty = True
    
    def pause_animation(self):
        """Pause animation playback"""
        self.is_playing = False
        self.playback_timer.stop()
        if hasattr(self, 'play_button'):
            self.play_button.setEnabled(True)
        if hasattr(self, 'pause_button'):
            self.pause_button.setEnabled(False)
    
    def on_speed_changed(self, speed):
        """Handle speed change"""
        self.resource_data["speed"] = speed
        # Update speed label
        if hasattr(self, 'lbl_speed'):
            self.lbl_speed.setText(str(speed))
        if self.is_playing:
            # Restart timer with new speed
            self.stop_playback()
            self.start_playback()
    
    def toggle_scale_mode(self):
        """Toggle between scaled and original size modes"""
        if hasattr(self, 'btn_scale_mode'):
            current_text = self.btn_scale_mode.text()
            if current_text == "Scaled":
                self.btn_scale_mode.setText("Original")
                # Set preview to original size if needed
                if hasattr(self, 'scroll_area'):
                    self.scroll_area.setWidgetResizable(False)
            else:
                self.btn_scale_mode.setText("Scaled")
                # Set preview to scaled if needed
                if hasattr(self, 'scroll_area'):
                    self.scroll_area.setWidgetResizable(True)
            # Force preview update
            if hasattr(self, 'preview_canvas'):
                self.preview_canvas.update()
    
    def toggle_playback(self):
        """Toggle animation playback"""
        if self.is_playing:
            self.pause_animation()
        else:
            self.start_playback()
    
    def start_playback(self):
        """Start animation playback"""
        if self.total_frames == 0:
            return
        
        self.is_playing = True
        fps = self.resource_data.get("speed", 30)
        if fps <= 0:
            fps = 30
        interval = int(1000 / fps)
        self.playback_timer.start(interval)
        
        if hasattr(self, 'play_button'):
            self.play_button.setText("⏸ Pause")
            self.play_button.setToolTip("Pause")
            self.play_button.setEnabled(False)
        if hasattr(self, 'pause_button'):
            self.pause_button.setEnabled(True)
    
    def stop_playback(self):
        """Stop playback and reset to first frame"""
        self.is_playing = False
        self.playback_timer.stop()
        
        # Reset to first frame
        self.current_frame = 0
        self.animation_frame_index = 0
        self.update_frame_display()
        
        if hasattr(self, 'preview_canvas'):
            self.preview_canvas.update()
        
        if hasattr(self, 'play_button'):
            self.play_button.setText("▶ Play")
            self.play_button.setToolTip("Play")
            self.play_button.setEnabled(True)
        if hasattr(self, 'pause_button'):
            self.pause_button.setEnabled(False)
    
    def previous_frame(self):
        """Go to previous frame"""
        if self.selected_animation and self.animation_frames:
            # Navigate within animation
            if self.animation_frame_index > 0:
                self.animation_frame_index -= 1
                self.current_frame = self.animation_frames[self.animation_frame_index]
            else:
                # Wrap to end
                self.animation_frame_index = len(self.animation_frames) - 1
                self.current_frame = self.animation_frames[self.animation_frame_index]
        else:
            # Navigate all frames
            if self.current_frame > 0:
                self.current_frame -= 1
            else:
                self.current_frame = self.total_frames - 1
        
        self.update_frame_display()
        if hasattr(self, 'preview_canvas'):
            self.preview_canvas.update()
    
    def next_frame(self):
        """Go to next frame"""
        if self.selected_animation and self.animation_frames:
            # Navigate within animation
            if self.animation_frame_index < len(self.animation_frames) - 1:
                self.animation_frame_index += 1
                self.current_frame = self.animation_frames[self.animation_frame_index]
            else:
                # Wrap to start
                self.animation_frame_index = 0
                self.current_frame = self.animation_frames[0]
        else:
            # Navigate all frames
            if self.current_frame < self.total_frames - 1:
                self.current_frame += 1
            else:
                self.current_frame = 0
        
        self.update_frame_display()
        if hasattr(self, 'preview_canvas'):
            self.preview_canvas.update()
    
    def on_animation_changed(self, animation_name):
        """Handle animation selection change"""
        was_playing = self.is_playing
        # Stop playback if active
        if was_playing:
            self.stop_playback()
        
        # Update selected animation
        if animation_name == "None":
            self.selected_animation = None
        else:
            self.selected_animation = animation_name
        
        # Update animation frames
        self._update_animation_frames()
        
        # Restart playback if it was playing
        if was_playing and ((self.selected_animation and len(self.animation_frames) > 0) or (not self.selected_animation and self.total_frames > 0)):
            self.start_playback()
    
    def _update_animation_frames(self):
        """Update the list of frames for the current animation"""
        if not self.selected_animation:
            # All frames
            self.animation_frames = list(range(self.total_frames))
            self.animation_frame_index = self.current_frame
        else:
            # Filter frames by tag
            frames = self.resource_data.get("frames", [])
            self.animation_frames = []
            for i, frame_data in enumerate(frames):
                if isinstance(frame_data, dict):
                    frame_tags = frame_data.get("tags", [])
                    if isinstance(frame_tags, list) and self.selected_animation in frame_tags:
                        self.animation_frames.append(i)
            
            # Update current frame to first frame of animation if current not in animation
            if self.animation_frames and self.current_frame not in self.animation_frames:
                self.current_frame = self.animation_frames[0]
                self.animation_frame_index = 0
            elif self.animation_frames:
                # Find current position in animation
                try:
                    self.animation_frame_index = self.animation_frames.index(self.current_frame)
                except ValueError:
                    self.animation_frame_index = 0
                    self.current_frame = self.animation_frames[0]
    
    def update_frame_display(self):
        """Update frame counter display (matches SpriteEditor format)"""
        if hasattr(self, 'frame_counter'):
            if self.selected_animation and self.animation_frames:
                # Show animation-specific counter
                anim_frame_num = self.animation_frame_index + 1
                anim_total = len(self.animation_frames)
                global_frame_num = self.current_frame + 1
                global_total = self.total_frames
                self.frame_counter.setText(f"Frame: {global_frame_num} / {global_total} ({anim_frame_num}/{anim_total})")
            else:
                # Show all frames counter in format "Frame: X / Y"
                current = self.current_frame + 1
                total = self.total_frames
                self.frame_counter.setText(f"Frame: {current} / {total}")
    
    def _update_animation_combo(self):
        """Update the animation combo box with available tags from frames"""
        self.animation_combo.blockSignals(True)
        current_selection = self.animation_combo.currentText()
        
        self.animation_combo.clear()
        self.animation_combo.addItem("None")
        
        # Collect all unique tags from frames
        frames = self.resource_data.get("frames", [])
        tags = set()
        for frame_data in frames:
            frame_tags = frame_data.get("tags", [])
            if isinstance(frame_tags, list):
                for tag in frame_tags:
                    if tag:
                        tags.add(tag)
        
        # Add tags to combo
        for tag in sorted(tags):
            self.animation_combo.addItem(tag)
        
        # Restore selection if possible
        index = self.animation_combo.findText(current_selection)
        if index >= 0:
            self.animation_combo.setCurrentIndex(index)
        else:
            self.animation_combo.setCurrentIndex(0)  # Default to "None"
        
        self.animation_combo.blockSignals(False)
    
    def on_tab_close_requested(self, index):
        """Handle tab close request"""
        # Prevent closing the Home tab
        if index == 0:
            return
        self.tab_widget.removeTab(index)
    
    # EditorInterface implementation
    def open_resource(self, resource_data: Dict) -> bool:
        """Load resource data into the editor (EditorInterface implementation)"""
        try:
            self.resource_data = resource_data
            self._dirty = False
            
            # Update original file path
            if hasattr(self.app, 'resource_manager'):
                self.original_file_path = self.app.resource_manager.get_resource_file_path(self.resource_type, resource_data)
            
            # Call the existing load logic
            self.load_resource_data()
            return True
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to load resource: {str(e)}")
            return False
    
    def load_resource_data(self):
        """Load resource data into the editor (legacy method)"""
        if not self.resource_data:
            return
        
        # Load complete resource data from disk (includes frames)
        resource_id = self.resource_data.get("id")
        if resource_id:
            complete_resource_data = self.app.resource_manager.load_resource_from_disk(self.resource_type, resource_id)
            if complete_resource_data:
                self.resource_data = complete_resource_data
        
        # Load basic properties
        self.name_edit.setText(self.resource_data.get("name", ""))
        
        # Load resource dimensions
        width = self.resource_data.get("width", 0)
        height = self.resource_data.get("height", 0)
        self.width_label.setText(f"Width: {width}")
        self.height_label.setText(f"Height: {height}")
        
        # Load frames and ensure all frames have required fields including tags
        frames = self.resource_data.get("frames", [])
        
        # Ensure all frames have tags field (initialize if missing)
        for i, frame in enumerate(frames):
            if isinstance(frame, dict):
                # Ensure required fields exist
                if "id" not in frame:
                    frame["id"] = f"frame_{i}"
                if "tags" not in frame:
                    frame["tags"] = []
                # Ensure file field exists for backward compatibility
                if "file" not in frame and "id" in frame:
                    frame["file"] = f"{self.resource_data.get('name', 'resource')}_{i}.png"
        
        # Load bounding box coordinates if they exist
        collision_bbox = self.resource_data.get("collision_bbox", {})
        if collision_bbox and hasattr(self, 'bbox_x_spin'):
            self.bbox_x_spin.setValue(collision_bbox.get("x", 0))
            self.bbox_y_spin.setValue(collision_bbox.get("y", 0))
            self.bbox_w_spin.setValue(collision_bbox.get("width", self.resource_data.get("width", 32)))
            self.bbox_h_spin.setValue(collision_bbox.get("height", self.resource_data.get("height", 32)))
        elif hasattr(self, 'bbox_x_spin'):
            # Initialize with resource bounds
            width = self.resource_data.get("width", 32)
            height = self.resource_data.get("height", 32)
            self.bbox_x_spin.setValue(0)
            self.bbox_y_spin.setValue(0)
            self.bbox_w_spin.setValue(width)
            self.bbox_h_spin.setValue(height)
        
        # Update resource_data with normalized frames
        self.resource_data["frames"] = frames
        
        self.total_frames = len(frames)
        self.frames_label.setText(f"Number of subimages: {self.total_frames}")
        
        # Update frame spinbox
        self.frame_spin.setRange(0, max(0, self.total_frames - 1))
        
        # Update animation combo with available tags
        self._update_animation_combo()
        
        # Reset animation selection to None
        self.selected_animation = None
        self._update_animation_frames()
        
        # Load origin
        if hasattr(self, 'origin_x_spin'):
            self.origin_x_spin.setValue(self.resource_data.get("origin_x", 0))
            self.origin_y_spin.setValue(self.resource_data.get("origin_y", 0))
        
        # Load collision settings
        if hasattr(self, 'precise_check'):
            self.precise_check.setChecked(self.resource_data.get("precise_collision", False))
            self.separate_check.setChecked(self.resource_data.get("separate_masks", False))
        
        # Load texture settings
        if hasattr(self, 'tile_h_check'):
            self.tile_h_check.setChecked(self.resource_data.get("tile_horizontal", False))
            self.tile_v_check.setChecked(self.resource_data.get("tile_vertical", False))
            self.used_3d_check.setChecked(self.resource_data.get("used_3d", False))
            if hasattr(self, 'texture_group_combo'):
                texture_group = self.resource_data.get("texture_group", "Default")
                index = self.texture_group_combo.findText(texture_group)
                if index >= 0:
                    self.texture_group_combo.setCurrentIndex(index)
        
        # Update frame display
        self.current_frame = 0
        self.update_frame_display()
        
        # Load runtime frames
        self._load_runtime_frames()
        
        # Update preview
        if hasattr(self, 'preview_canvas'):
            self.preview_canvas.update()
    
    def _load_runtime_frames(self):
        """Load runtime frames from resource files - subclasses should override if needed"""
        # Base implementation - can be overridden by subclasses
        pass
    
    def get_resource_id(self) -> Optional[str]:
        """Get the ID of the currently loaded resource (EditorInterface implementation)"""
        return self.resource_data.get("id") if self.resource_data else None
    
    def get_resource_name(self) -> Optional[str]:
        """Get the name of the currently loaded resource"""
        return self.resource_data.get("name") if self.resource_data else None
    
    def is_dirty(self) -> bool:
        """Check if the editor has unsaved changes (EditorInterface implementation)"""
        return self._dirty
    
    def get_editor_widget(self) -> QWidget:
        """Get the main widget for this editor (EditorInterface implementation)"""
        return self
    
    def close_editor(self) -> bool:
        """Cleanup and close the editor (EditorInterface implementation)"""
        # Stop playback if running
        if self.is_playing:
            self.stop_playback()
        return True
    
    def on_resource_updated(self, resource_type, resource_data):
        """Handle resource updated signal"""
        if resource_type == self.resource_type and resource_data.get("id") == self.resource_data.get("id"):
            self.resource_data = resource_data
            self.load_resource_data()
    
    def on_resource_deleted(self, resource_type, resource_id):
        """Handle resource deleted signal"""
        if resource_type == self.resource_type and resource_id == self.resource_data.get("id"):
            QMessageBox.warning(self, "Resource Deleted", f"This {resource_type[:-1]} has been deleted.")
            # Could close the editor here if desired
    
    def on_project_changed(self, project_path):
        """Handle project changed signal"""
        # Could reload resource or close editor
        pass

