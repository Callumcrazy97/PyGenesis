"""
Integrated Image Editor for Python Game IDE
GameMaker 8-style sprite editor with properties panel and preview box
"""

from PySide6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLabel, 
                               QPushButton, QSpinBox, QCheckBox, QScrollArea,
                               QFrame, QSplitter, QListWidget, QListWidgetItem,
                               QMessageBox, QFileDialog, QInputDialog, QComboBox, 
                               QSizePolicy, QLineEdit, QGroupBox, QGridLayout,
                               QDialog, QDialogButtonBox, QTabWidget, QTextEdit,
                               QMenu, QMenuBar, QSlider)
from PySide6.QtCore import Qt, Signal, QSize, QTimer
from PySide6.QtGui import QPainter, QPen, QBrush, QColor, QPixmap, QFont, QAction

import os
import json
from typing import Dict, Optional
from Core.Debug import debug
from Core.EditorInterface import EditorInterface
from Editors.Shared.BaseImageResourceEditor import BaseImageResourceEditor

class IntegratedImageEditor(QWidget):
    """Integrated PySide6 Image Editor for PyGenesis IDE - supports sprites, textures, and backgrounds"""
    
    def __init__(self, parent, sprite_data=None, resource_data=None, resource_type="sprites", on_save_callback=None, app=None):
        super().__init__(parent)
        # Support both old (sprite_data) and new (resource_data) parameter names for backward compatibility
        self.resource_data = resource_data if resource_data is not None else sprite_data
        self.resource_type = resource_type  # "sprites", "textures", or "backgrounds"
        self.on_save_callback = on_save_callback
        self.app = app
        self.editor_state = None
        self.main_editor = None  # Initialize to None - will be created asynchronously
        
        # Store reference to main window for fullscreen functionality
        self.main_window = None
        if self.app and hasattr(self.app, 'main_window'):
            self.main_window = self.app.main_window
        
        # Backward compatibility: maintain sprite_data attribute
        self.sprite_data = self.resource_data
        
        self.setup_ui()
        self.initialize_editor()  # This is now async - main_editor will be created later
        self.apply_theme()  # This should check for main_editor existence
    
    def setup_ui(self):
        """Setup the integrated editor UI"""
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        
        # Create menu bar for image editor
        self.menu_bar = self.create_image_editor_menu()
        layout.addWidget(self.menu_bar)
        
        # Create editor container
        self.editor_container = QWidget()
        layout.addWidget(self.editor_container, 1)
        
        # Fullscreen state
        self.is_fullscreen = False
        self.original_geometry = None
    
    def create_image_editor_menu(self):
        """Create the image editor specific menu bar"""
        from PySide6.QtWidgets import QMenuBar, QMenu
        from PySide6.QtGui import QAction, QKeySequence
        
        menu_bar = QMenuBar()
        # Menu bar styling will be handled by theme system
        
        # File menu
        file_menu = menu_bar.addMenu("&File")
        
        # New resource (sprite/texture/background)
        resource_name = self._get_resource_name()
        new_action = QAction(f"&New {resource_name}", self)
        new_action.setShortcut(QKeySequence.New)
        new_action.triggered.connect(self.new_sprite)
        file_menu.addAction(new_action)
        
        # Save resource - simplified to just "Save"
        save_action = QAction("&Save", self)
        save_action.setShortcut(QKeySequence.Save)
        save_action.triggered.connect(self.save_sprite)
        file_menu.addAction(save_action)
        
        # Import group (includes open + import flows)
        import_menu = file_menu.addMenu("&Import")
        
        open_sprite_action = QAction("Open &Sprite...", self)
        open_sprite_action.triggered.connect(self.open_sprite)
        import_menu.addAction(open_sprite_action)
        
        open_image_action = QAction("Open &Image...", self)
        open_image_action.triggered.connect(self.open_image)
        import_menu.addAction(open_image_action)
        
        open_gif_action = QAction("Open &GIF...", self)
        open_gif_action.triggered.connect(self.open_gif)
        import_menu.addAction(open_gif_action)
        
        import_menu.addSeparator()
        
        import_image_action = QAction("Import &Image...", self)
        import_image_action.triggered.connect(self.import_image)
        import_menu.addAction(import_image_action)
        
        import_gif_action = QAction("Import &GIF...", self)
        import_gif_action.triggered.connect(self.import_gif)
        import_menu.addAction(import_gif_action)
        
        import_pgsprite_action = QAction("Import .&PgSprite...", self)
        import_pgsprite_action.triggered.connect(self.import_pgsprite)
        import_menu.addAction(import_pgsprite_action)
        
        # Export group
        export_menu = file_menu.addMenu("&Export")
        
        export_png_action = QAction("Export &PNG...", self)
        export_png_action.triggered.connect(self.save_as_image)
        export_menu.addAction(export_png_action)
        
        export_gif_action = QAction("Export &GIF...", self)
        export_gif_action.triggered.connect(self.save_as_gif)
        export_menu.addAction(export_gif_action)
        
        export_pgsprite_action = QAction("Export .Pg&Sprite...", self)
        export_pgsprite_action.triggered.connect(self.save_as_sprite)
        export_menu.addAction(export_pgsprite_action)
        
        collections_menu = export_menu.addMenu("&Collections")
        save_selection_action = QAction("Save Selection to Memory...", self)
        save_selection_action.triggered.connect(self.save_selection_to_memory)
        collections_menu.addAction(save_selection_action)
        
        insert_memory_action = QAction("Insert Memory...", self)
        insert_memory_action.triggered.connect(self.insert_memory_from_collections)
        collections_menu.addAction(insert_memory_action)
        
        # Edit menu
        edit_menu = menu_bar.addMenu("&Edit")
        
        # History
        history_menu = edit_menu.addMenu("&History")
        undo_action = QAction("&Undo", self)
        undo_action.triggered.connect(self.undo_action)
        history_menu.addAction(undo_action)
        
        redo_action = QAction("&Redo", self)
        redo_action.triggered.connect(self.redo_action)
        history_menu.addAction(redo_action)
        
        # Clipboard
        clipboard_menu = edit_menu.addMenu("&Clipboard")
        cut_action = QAction("Cu&t", self)
        cut_action.triggered.connect(self.cut_action)
        clipboard_menu.addAction(cut_action)
        
        copy_action = QAction("&Copy", self)
        copy_action.triggered.connect(self.copy_action)
        clipboard_menu.addAction(copy_action)
        
        paste_action = QAction("&Paste", self)
        paste_action.triggered.connect(self.paste_action)
        clipboard_menu.addAction(paste_action)
        
        delete_action = QAction("&Delete", self)
        delete_action.triggered.connect(self.delete_action)
        clipboard_menu.addAction(delete_action)
        
        # Transform
        transform_menu = edit_menu.addMenu("&Transform")
        crop_action = QAction("Crop to Content...", self)
        crop_action.triggered.connect(self.crop_to_content)
        transform_menu.addAction(crop_action)
        
        remove_blank_action = QAction("Remove Blank Space...", self)
        remove_blank_action.triggered.connect(self.remove_blank_space_action)
        transform_menu.addAction(remove_blank_action)
        
        resize_selection_action = QAction("Resize Selection...", self)
        resize_selection_action.triggered.connect(self.resize_selection_action)
        transform_menu.addAction(resize_selection_action)
        
        # Quick Access
        quick_menu = edit_menu.addMenu("&Quick Access")
        select_all_action = QAction("Select &All", self)
        select_all_action.triggered.connect(self.select_all_action)
        quick_menu.addAction(select_all_action)
        
        clear_selection_action = QAction("&Clear Selection", self)
        clear_selection_action.triggered.connect(self.clear_selection_action)
        quick_menu.addAction(clear_selection_action)
        
        duplicate_frame_action = QAction("Duplicate Frame", self)
        duplicate_frame_action.triggered.connect(self.duplicate_frame_action)
        quick_menu.addAction(duplicate_frame_action)
        
        clear_frame_action = QAction("Clear Frame", self)
        clear_frame_action.triggered.connect(self.clear_frame_action)
        quick_menu.addAction(clear_frame_action)
        
        quick_menu.addSeparator()
        preferences_action = QAction("&Preferences...", self)
        preferences_action.setShortcut(QKeySequence("Ctrl+,"))
        preferences_action.triggered.connect(self.show_preferences)
        quick_menu.addAction(preferences_action)
        
        # Effects menu will be dynamically synced from the Image Editor
        # This ensures consistency and eliminates duplication
        self.effects_menu = menu_bar.addMenu("&Effects")
        self.effects_menu.setEnabled(False)  # Disabled until Image Editor is opened
        
        # Enable AI menu when Image Editor is ready (will be enabled in initialize_editor)
        
        # AI menu - will forward to Image Editor
        self.ai_menu = menu_bar.addMenu("&AI")
        self.ai_menu.setEnabled(False)  # Disabled until Image Editor is opened
        
        # Generation submenu
        generation_ai_menu = self.ai_menu.addMenu("&Generation")
        generate_base_action = QAction("Create &Base Sprite...", self)
        generate_base_action.triggered.connect(self.ai_generate_base_sprite)
        generation_ai_menu.addAction(generate_base_action)
        
        generate_animation_action = QAction("Create &Animated Sprite...", self)
        generate_animation_action.triggered.connect(self.ai_generate_animation)
        generation_ai_menu.addAction(generate_animation_action)
        
        generate_texture_pack_action = QAction("Create &Texture Pack...", self)
        generate_texture_pack_action.triggered.connect(self.ai_generate_texture_pack)
        generation_ai_menu.addAction(generate_texture_pack_action)
        
        # Analysis submenu
        analysis_ai_menu = self.ai_menu.addMenu("&Analysis")
        detect_skeleton_action = QAction("Generate 2D &Skeleton...", self)
        detect_skeleton_action.triggered.connect(self.ai_detect_skeleton)
        analysis_ai_menu.addAction(detect_skeleton_action)
        
        analyze_sprite_action = QAction("&Analyze Sprite Structure...", self)
        analyze_sprite_action.triggered.connect(self.ai_analyze_sprite)
        analysis_ai_menu.addAction(analyze_sprite_action)
        
        # Enhancement submenu
        enhancement_ai_menu = self.ai_menu.addMenu("&Enhancement")
        ai_upscale_action = QAction("AI &Upscale...", self)
        ai_upscale_action.triggered.connect(self.ai_upscale)
        enhancement_ai_menu.addAction(ai_upscale_action)
        
        background_removal_ai_action = QAction("&Background Removal...", self)
        background_removal_ai_action.triggered.connect(self.ai_background_removal)
        enhancement_ai_menu.addAction(background_removal_ai_action)
        
        # Conversion submenu
        conversion_ai_menu = self.ai_menu.addMenu("&Conversion")
        image_to_3d_action = QAction("Image to &3D Model...", self)
        image_to_3d_action.triggered.connect(self.ai_image_to_3d)
        conversion_ai_menu.addAction(image_to_3d_action)
        
        sprite_to_3d_action = QAction("Sprite to &3D Model...", self)
        sprite_to_3d_action.triggered.connect(self.ai_sprite_to_3d)
        conversion_ai_menu.addAction(sprite_to_3d_action)
        
        # View menu
        view_menu = menu_bar.addMenu("&View")
        
        # Zoom controls
        zoom_menu = view_menu.addMenu("&Zoom")
        zoom_in_action = QAction("Zoom &In", self)
        zoom_in_action.setShortcut(QKeySequence("Ctrl+Plus"))
        zoom_in_action.triggered.connect(self.zoom_in_action)
        zoom_menu.addAction(zoom_in_action)
        
        zoom_out_action = QAction("Zoom &Out", self)
        zoom_out_action.setShortcut(QKeySequence("Ctrl+-"))
        zoom_out_action.triggered.connect(self.zoom_out_action)
        zoom_menu.addAction(zoom_out_action)
        
        zoom_reset_action = QAction("Zoom &Reset", self)
        zoom_reset_action.setShortcut(QKeySequence("Ctrl+0"))
        zoom_reset_action.triggered.connect(self.zoom_reset_action)
        zoom_menu.addAction(zoom_reset_action)
        
        view_menu.addSeparator()
        
        # Grid controls
        grid_menu = view_menu.addMenu("&Grid")
        self.grid_toggle_action = QAction("Toggle &Grid", self)
        self.grid_toggle_action.setCheckable(True)
        self.grid_toggle_action.triggered.connect(self.toggle_grid_action)
        grid_menu.addAction(self.grid_toggle_action)
        
        self.snap_to_grid_action = QAction("Snap to &Grid", self)
        self.snap_to_grid_action.setCheckable(True)
        self.snap_to_grid_action.triggered.connect(self.toggle_snap_to_grid_action)
        grid_menu.addAction(self.snap_to_grid_action)
        
        view_menu.addSeparator()
        
        # Timeline toggle
        timeline_action = QAction("Toggle &Timeline", self)
        timeline_action.setShortcut(QKeySequence("Ctrl+Shift+T"))
        timeline_action.triggered.connect(self.toggle_timeline)
        view_menu.addAction(timeline_action)
        
        # Fullscreen toggle
        self.fullscreen_action = QAction("&Fullscreen", self)
        self.fullscreen_action.setShortcut(QKeySequence("F11"))
        self.fullscreen_action.setCheckable(True)
        self.fullscreen_action.triggered.connect(self.toggle_fullscreen)
        view_menu.addAction(self.fullscreen_action)
        
        return menu_bar
    
    def save_selection_to_memory(self):
        """Forward to Image Editor if available; otherwise notify user."""
        try:
            if hasattr(self, 'main_editor') and self.main_editor and hasattr(self.main_editor, 'save_selection_to_memory'):
                self.main_editor.save_selection_to_memory()
            else:
                QMessageBox.information(self, "Collections", "Save Selection to Memory is not available in this build.")
        except Exception as e:
            QMessageBox.warning(self, "Collections", f"Error: {e}")
    
    def insert_memory_from_collections(self):
        """Forward to Image Editor if available; otherwise notify user."""
        try:
            if hasattr(self, 'main_editor') and self.main_editor and hasattr(self.main_editor, 'insert_memory'):
                self.main_editor.insert_memory()
            else:
                QMessageBox.information(self, "Collections", "Insert Memory is not available in this build.")
        except Exception as e:
            QMessageBox.warning(self, "Collections", f"Error: {e}")
    
    def sync_effects_menu_from_image_editor(self):
        """Sync the Effects menu from the Image Editor's MainWindow using introspection"""
        if not hasattr(self, 'main_editor') or self.main_editor is None:
            return
        
        # Clear existing effects menu items
        self.effects_menu.clear()
        self.effects_menu.setEnabled(False)
        
        try:
            # Get the Effects menu structure from the Image Editor
            debug("DEBUG sync_effects_menu: Getting menu structure")
            menu_data = self.main_editor.get_effects_menu_structure()
            
            if not menu_data:
                debug("DEBUG sync_effects_menu: No menu data")
                return
            
            debug(f"DEBUG sync_effects_menu: Menu data received, building menu")
            # Build the Effects menu from the extracted data
            self._build_menu_from_data(menu_data, self.effects_menu)
            self.effects_menu.setEnabled(True)
            debug("DEBUG sync_effects_menu: Menu synced successfully")
            
        except Exception as e:
            debug(f"DEBUG sync_effects_menu: Exception: {e}")
            import traceback
            import traceback
            traceback.print_exc()
            # Fallback: create a simple "Effects not available" message
            no_effects_action = QAction("Effects not available", self)
            no_effects_action.setEnabled(False)
            self.effects_menu.addAction(no_effects_action)
    
    def sync_edit_menu_from_image_editor(self):
        """Sync the Edit menu (Undo/Redo/Cut/Copy/Paste) from the Image Editor's MainWindow"""
        if not hasattr(self, 'main_editor') or self.main_editor is None:
            return
        
        try:
            # Get the Edit menu structure from the Image Editor
            menu_data = self.main_editor.get_edit_menu_structure()
            
            if not menu_data:
                return
            
            # Find or create the Edit menu
            edit_menu = None
            menu_bar = self.menu_bar
            for action in menu_bar.actions():
                if action.menu() and action.menu().title() == "&Edit":
                    edit_menu = action.menu()
                    break
            
            if not edit_menu:
                return
            
            # Find the Utils submenu or create it
            utils_menu = None
            for action in edit_menu.actions():
                if action.menu() and action.menu().title() == "&Utils":
                    utils_menu = action.menu()
                    break
            
            if utils_menu:
                # Clear existing Utils menu items except the basic ones we want to keep
                # We'll replace with Image Editor's Edit menu items
                utils_menu.clear()
                
                # Rebuild with Image Editor's menu items
                self._build_menu_from_data(menu_data, utils_menu)
            
        except Exception as e:
            debug(f"Error syncing Edit menu from Image Editor: {e}")
    
    def _build_menu_from_data(self, menu_data, target_menu):
        """Build menu from extracted data"""
        for action_data in menu_data['actions']:
            if action_data['type'] == 'separator':
                target_menu.addSeparator()
            elif action_data['type'] == 'submenu':
                # This is a submenu
                debug(f"DEBUG _build_menu_from_data: Building submenu: {action_data['text']}")
                submenu = target_menu.addMenu(action_data['text'])
                self._build_menu_from_data(action_data['menu'], submenu)
            elif action_data['type'] == 'action':
                # This is a regular action
                action_text = action_data['text']
                method_name = action_data.get('method_name')
                debug(f"DEBUG _build_menu_from_data: Building action: {action_text}, method: {method_name}")
                
                cloned_action = QAction(action_text, self)
                shortcut_text = action_data.get('shortcut')
                if not shortcut_text:
                    # Provide default shortcuts for core edit operations if missing (for display only)
                    default_shortcuts = {
                        "&Undo": "Ctrl+Z",
                        "Undo": "Ctrl+Z",
                        "&Redo": "Ctrl+Y",
                        "Redo": "Ctrl+Y",
                        "&Cut": "Ctrl+X",
                        "Cut": "Ctrl+X",
                        "&Copy": "Ctrl+C",
                        "Copy": "Ctrl+C",
                        "&Paste": "Ctrl+V",
                        "Paste": "Ctrl+V",
                    }
                    shortcut_text = default_shortcuts.get(action_text)

                if shortcut_text:
                    # Show shortcut in menu text without registering an additional action shortcut
                    cloned_action.setText(f"{action_text}\t{shortcut_text}")
                else:
                    cloned_action.setText(action_text)
                cloned_action.setEnabled(action_data.get('enabled', True))
                
                # Connect to a wrapper method that calls the Image Editor's method
                if method_name:
                    # Create a wrapper method that calls the Image Editor method
                    wrapper_method = lambda checked=False, m=method_name: self._call_image_editor_method(m)
                    cloned_action.triggered.connect(wrapper_method)
                    debug(f"DEBUG _build_menu_from_data: Connected {action_text} to {method_name}")
                else:
                    debug(f"DEBUG _build_menu_from_data: No method_name for {action_text}")
                
                target_menu.addAction(cloned_action)
    
    def _call_image_editor_method(self, method_name):
        """Wrapper method to call Image Editor methods from the Sprite Editor context"""
        try:
            debug(f"DEBUG _call_image_editor_method: Calling {method_name} on main_editor")
            if not hasattr(self, 'main_editor') or self.main_editor is None:
                debug(f"DEBUG _call_image_editor_method: main_editor is None or doesn't exist")
                from PySide6.QtWidgets import QMessageBox
                QMessageBox.warning(self, "Error", "Image Editor is not available.")
                return
            
            if hasattr(self.main_editor, method_name):
                method = getattr(self.main_editor, method_name)
                debug(f"DEBUG _call_image_editor_method: Found method, calling it")
                method()
            else:
                debug(f"DEBUG _call_image_editor_method: Method {method_name} not found on main_editor")
                from PySide6.QtWidgets import QMessageBox
                QMessageBox.warning(self, "Error", f"Method {method_name} is not available in the Image Editor.")
        except Exception as e:
            debug(f"DEBUG _call_image_editor_method: Exception occurred: {e}")
            import traceback
            import traceback
            traceback.print_exc()
            from PySide6.QtWidgets import QMessageBox
            QMessageBox.critical(self, "Error", 
                               f"Error calling {method_name}: {str(e)}")
    
    def create_toolbar(self):
        """Create toolbar with save/cancel buttons"""
        toolbar = QFrame()
        toolbar.setStyleSheet("""
            QFrame {
                background-color: #3c3c3c;
                border-bottom: 1px solid #555555;
                padding: 5px;
            }
            QPushButton {
                background-color: #4a4a4a;
                border: 1px solid #666666;
                padding: 5px 10px;
                color: white;
                border-radius: 3px;
            }
            QPushButton:hover {
                background-color: #5a5a5a;
            }
            QPushButton:pressed {
                background-color: #2a2a2a;
            }
        """)
        
        layout = QHBoxLayout(toolbar)
        layout.setContentsMargins(10, 5, 10, 5)
        
        # Save button
        save_btn = QPushButton("Save Sprite")
        save_btn.clicked.connect(self.save_sprite)
        layout.addWidget(save_btn)
        
        # Cancel button
        cancel_btn = QPushButton("Cancel")
        cancel_btn.clicked.connect(self.cancel_editing)
        layout.addWidget(cancel_btn)
        
        layout.addStretch()
        
        return toolbar
    
    def initialize_editor(self):
        """Initialize the PySide6 image editor - optimized for fast loading"""
        try:
            # Defer Image Editor import and creation to avoid blocking UI
            # This allows the SpriteEditor UI to appear immediately
            from PySide6.QtCore import QTimer
            
            def create_image_editor_async():
                """Create Image Editor asynchronously to avoid blocking"""
                try:
                    # Import the image editor components (heavy imports happen here)
                    from ui.main_window import MainWindow as ImageEditorMainWindow
                    from core.state import EditorState, state
                    
                    # Get dimensions from resource data
                    width = self.resource_data.get("width", 32)
                    height = self.resource_data.get("height", 32)
                    
                    # Update the global state with correct dimensions
                    state.set_size(width, height)
                    
                    # Set grid settings for new sprites (grid off by default)
                    state.set_grid_visible(False)  # Grid off by default
                    state.set_grid_size(16)  # Match the UI setting
                    state.global_grid = False  # Global grid off by default
                    
                    self.editor_state = state
                    
                    # Create the main editor window in embedded mode
                    self.main_editor = ImageEditorMainWindow(parent=self, embedded_mode=True, app=self.app)
                    debug(f"DEBUG: Created main_editor: {self.main_editor}")
                    
                    # Load sprite data immediately (critical for display)
                    self.load_sprite_data()
                    
                    # Sync menus and refresh in background (non-critical, can be deferred)
                    def sync_menus():
                        self.sync_effects_menu_from_image_editor()
                        self.sync_edit_menu_from_image_editor()
                        self.sync_grid_states()
                        # Enable AI menu now that Image Editor is ready
                        if hasattr(self, 'ai_menu'):
                            self.ai_menu.setEnabled(True)
                    # Reduced delay - only 50ms for menu sync (non-critical)
                    QTimer.singleShot(50, sync_menus)
                    
                    # Get the central widget and add it to our container
                    central_widget = self.main_editor.get_central_widget()
                    debug(f"DEBUG: Central widget: {central_widget}")
                    if central_widget:
                        # Add to our container
                        editor_layout = QVBoxLayout(self.editor_container)
                        editor_layout.setContentsMargins(0, 0, 0, 0)
                        editor_layout.addWidget(central_widget)
                    
                    # Force refresh immediately (critical for display) - after widget is added
                    self.force_canvas_refresh()
                    
                    # Apply theme now that editor is created
                    if hasattr(self, 'apply_theme'):
                        self.apply_theme()
                        
                except Exception as e:
                    debug(f"Error creating Image Editor: {e}")
                    import traceback
                    debug(traceback.format_exc())
                    # Show error to user
                    error_label = QLabel(f"Failed to initialize image editor: {e}")
                    error_label.setWordWrap(True)
                    error_label.setAlignment(Qt.AlignCenter)
                    editor_layout = QVBoxLayout(self.editor_container)
                    editor_layout.addWidget(error_label)
            
            # Defer Image Editor creation to next event loop cycle (non-blocking)
            QTimer.singleShot(0, create_image_editor_async)
            
        except Exception as e:
            # Show error message
            error_label = QLabel(f"Failed to initialize image editor: {str(e)}")
            error_label.setStyleSheet("color: red; padding: 20px;")
            error_label.setAlignment(Qt.AlignCenter)
            
            editor_layout = QVBoxLayout(self.editor_container)
            editor_layout.addWidget(error_label)
    
    def _get_resource_name(self):
        """Get human-readable resource name based on resource type"""
        names = {
            "sprites": "Sprite",
            "textures": "Texture",
            "backgrounds": "Background"
        }
        return names.get(self.resource_type, "Resource")
    
    def _get_resource_folder(self):
        """Get the resource folder name based on resource type"""
        folders = {
            "sprites": "Sprites",
            "textures": "Textures",
            "backgrounds": "Backgrounds"
        }
        return folders.get(self.resource_type, "Sprites")
    
    def load_sprite_data(self):
        """Load resource data into the image editor (supports sprites, textures, backgrounds)"""
        try:
            if not self.editor_state or not self.main_editor:
                debug("Editor not ready, retrying...")
                from PySide6.QtCore import QTimer
                QTimer.singleShot(100, self.load_sprite_data)
                return
            
            # CRITICAL: Reload resource data from disk to get latest tags/colors
            # The resource_data passed to IntegratedImageEditor might be stale
            if self.app and hasattr(self.app, 'resource_manager'):
                resource_id = self.resource_data.get("id")
                if resource_id:
                    debug(f"DEBUG load_sprite_data: Reloading {self.resource_type} {resource_id} from disk...")
                    fresh_resource_data = self.app.resource_manager.load_resource_from_disk(self.resource_type, resource_id)
                    if fresh_resource_data:
                        debug(f"DEBUG load_sprite_data: Loaded fresh data with {len(fresh_resource_data.get('frames', []))} frames")
                        # Check if frames have tags/colors
                        frames_with_tags = [i for i, f in enumerate(fresh_resource_data.get('frames', [])) if f.get('tags', [])]
                        frames_with_colors = [i for i, f in enumerate(fresh_resource_data.get('frames', [])) if f.get('color_code')]
                        debug(f"DEBUG load_sprite_data: Fresh data has {len(frames_with_tags)} frames with tags, {len(frames_with_colors)} with colors")
                        # Update self.resource_data with fresh data
                        self.resource_data = fresh_resource_data
                        self.sprite_data = fresh_resource_data  # Backward compatibility
                    else:
                        debug(f"DEBUG load_sprite_data: WARNING - Could not reload from disk, using existing resource_data")
            
            # Get frames from resource data (now fresh from disk)
            frames = self.resource_data.get("frames", [])
            debug(f"DEBUG load_sprite_data: Using {len(frames)} frames from resource_data")
            if frames and len(frames) > 0:
                import os
                from PIL import Image
                import numpy as np
                
                # Get the resource folder path, including parent folder if specified
                resource_folder_name = self._get_resource_folder()
                resource_folder = os.path.join(
                    self.app.project_manager.get_project_path(),
                    "Resources", resource_folder_name
                )
                
                # Add parent folder to path if specified
                parent_folder = self.resource_data.get("parent_folder", "")
                if parent_folder:
                    resource_folder = os.path.join(resource_folder, parent_folder)
                
                # Load all frames
                loaded_frames = []
                for frame_data in frames:
                    if "file" in frame_data:
                        frame_path = os.path.join(resource_folder, frame_data["file"])
                        if os.path.exists(frame_path):
                            pil_image = Image.open(frame_path)
                            img_array = np.array(pil_image)
                            loaded_frames.append(img_array)
                            debug(f"Loaded frame: {frame_data['file']}")
                        else:
                            debug(f"Frame file not found: {frame_path}")
                
                if loaded_frames:
                    # Use first frame for dimensions
                    first_frame_array = loaded_frames[0]
                    h, w = first_frame_array.shape[:2]
                    
                    # Update global state
                    from core.state import state
                    state.history.push_undo()
                    state.width = w
                    state.height = h
                    
                    # Get the current layer
                    layer = state.layer_manager.get_current_layer()
                    
                    # Clear existing frames and add all loaded frames
                    layer.frames.clear()
                    # Also clear frame histories since we're replacing all frames
                    layer.frame_histories.clear()
                    
                    # Add all frames to the layer
                    for i, frame_array in enumerate(loaded_frames):
                        # Add a new frame to the layer
                        layer.add_frame(w, h, state)
                        
                        # IMPORTANT: Get the frame DIRECTLY from the frames list, not via get_frame()
                        # This ensures we're working with the actual frame object that will be used
                        if i < len(layer.frames):
                            frame = layer.frames[i]
                        else:
                            # Fallback to get_frame if direct access fails
                            frame = layer.get_frame(i)
                        
                        # Set the image first
                        frame.image = frame_array.copy()
                        
                        # Load tags and color_code from frame_data if available
                        # IMPORTANT: Always ensure tags and color_code are loaded from sprite file
                        if i < len(frames):
                            # Load tags - ALWAYS set, even if empty list
                            frame_tags = frames[i].get("tags", [])
                            if isinstance(frame_tags, list):
                                frame.tags = frame_tags.copy() if frame_tags else []
                            else:
                                frame.tags = []
                            
                            if frame.tags:
                                debug(f"✓ Loaded frame {i+1}/{len(loaded_frames)} with {len(frame.tags)} tag(s): {frame.tags}")
                            else:
                                debug(f"  Loaded frame {i+1}/{len(loaded_frames)} (no tags)")
                            
                            # Load color_code - explicitly set it, even if None
                            frame_color = frames[i].get("color_code", None)
                            frame.color_code = frame_color if frame_color else None
                            if frame_color:
                                debug(f"  ✓ Loaded frame {i+1} color: {frame_color}")
                        else:
                            # Frame index out of bounds - ensure tags list exists
                            frame.tags = []
                            frame.color_code = None
                            debug(f"  Loaded frame {i+1}/{len(loaded_frames)} (index out of bounds, no tags/color)")
                        
                        # Force verify tags and color_code are set correctly
                        if not hasattr(frame, 'tags'):
                            frame.tags = []
                            debug(f"  WARNING: Frame {i+1} missing tags attribute after loading!")
                        if not hasattr(frame, 'color_code'):
                            frame.color_code = None
                            debug(f"  WARNING: Frame {i+1} missing color_code attribute after loading!")
                        
                        # Final verification before moving to next frame
                        debug(f"  DEBUG: Frame {i} - tags: {frame.tags}, color: {frame.color_code}")
                    
                    # Set current frame to 0
                    state.layer_manager.current_frame = 0
                    
                    # Update canvas size
                    debug(f"DEBUG: Updating canvas size to {w}x{h}")
                    self.main_editor.canvas.set_image_size(w, h)
                    self.main_editor.canvas.update()
                    
                    # Force a complete refresh of the canvas
                    self.main_editor.canvas.repaint()
                    self.main_editor.canvas.show()
                    debug("DEBUG: Canvas updated and refreshed")
                    
                    # CRITICAL: Verify all frames have tags/colors BEFORE updating timeline
                    debug(f"\nDEBUG: Pre-timeline verification - checking {len(layer.frames)} frames:")
                    for i, f in enumerate(layer.frames):
                        has_tags = hasattr(f, 'tags') and f.tags
                        has_color = hasattr(f, 'color_code') and f.color_code
                        if has_tags or has_color:
                            debug(f"  Frame {i}: tags={f.tags if hasattr(f, 'tags') else 'MISSING'}, color={f.color_code if hasattr(f, 'color_code') else 'MISSING'}")
                    
                    # Update timeline if it exists
                    if hasattr(self.main_editor, 'timeline') and self.main_editor.timeline:
                        debug(f"\nDEBUG: Updating timeline with {len(layer.frames)} frames...")
                        # Force timeline to update with loaded data (including tags and colors)
                        self.main_editor.timeline.set_layers(state.layer_manager.layers)
                        self.main_editor.timeline.set_current_frame(0)
                        # Force a repaint of the timeline
                        self.main_editor.timeline.update()
                        self.main_editor.timeline.repaint()
                        debug(f"DEBUG: Timeline update complete")
                        
                        # Verify tags and colors are present in timeline frames AFTER update
                        if layer.frames:
                            frames_with_tags = [i for i, f in enumerate(layer.frames) if hasattr(f, 'tags') and f.tags]
                            frames_with_colors = [i for i, f in enumerate(layer.frames) if hasattr(f, 'color_code') and f.color_code]
                            debug(f"DEBUG: Post-update - {len(frames_with_tags)} frames with tags, {len(frames_with_colors)} with colors")
                            if frames_with_tags:
                                sample_idx = frames_with_tags[0]
                                sample_frame = layer.frames[sample_idx]
                                debug(f"DEBUG: Sample frame {sample_idx}: tags={sample_frame.tags}, color={sample_frame.color_code}")
                    
                    debug(f"Loaded {len(loaded_frames)} frames from sprite: {w}x{h} pixels")
                else:
                    debug("No frame files could be loaded")
            else:
                debug("No sprite data to load")
        
        except Exception as e:
            debug(f"Error loading sprite data: {e}")
            # Retry after a short delay
            from PySide6.QtCore import QTimer
            QTimer.singleShot(100, self.load_sprite_data)
    
    def force_canvas_refresh(self):
        """Force a complete refresh of the canvas"""
        try:
            if hasattr(self, 'main_editor') and self.main_editor and hasattr(self.main_editor, 'canvas'):
                debug("DEBUG: Forcing canvas refresh")
                self.main_editor.canvas.repaint()
                self.main_editor.canvas.update()
                # Also try to refresh the parent widget
                if hasattr(self.main_editor.canvas, 'parent'):
                    parent = self.main_editor.canvas.parent()
                    if parent:
                        parent.repaint()
                        parent.update()
                debug("DEBUG: Canvas refresh completed")
        except Exception as e:
            debug(f"DEBUG: Error forcing canvas refresh: {e}")
    
    def import_image(self):
        """Import an image file into the Image Editor"""
        if not self.main_editor:
            return
        
        # Delegate to the main editor's import_image method
        self.main_editor.import_image()
    
    def import_gif(self):
        """Import a GIF file into the Image Editor"""
        if not self.main_editor:
            return
        
        # Delegate to the main editor's import_gif method
        self.main_editor.import_gif()
    
    def import_pgsprite(self):
        """Import a .PgSprite file into the Image Editor"""
        if not self.main_editor:
            return
        
        # Delegate to the main editor's import_pgsprite method
        self.main_editor.import_pgsprite()
    
    def save_sprite(self):
        """Save resource data and notify parent (supports sprites, textures, backgrounds)"""
        if self.on_save_callback:
            # Get updated data from editor
            updated_data = self.get_updated_sprite_data()
            self.on_save_callback(updated_data)
            
            # Show success message
            from PySide6.QtWidgets import QMessageBox
            resource_name = self._get_resource_name()
            QMessageBox.information(self, "Success", f"{resource_name} saved successfully!")
    
    def get_sprite_data(self):
        """Get JSON-serializable resource data (supports sprites, textures, backgrounds)"""
        # Ensure all frames have tags field, even if empty
        frames = self.resource_data.get("frames", [])
        frames_with_tags = []
        for frame in frames:
            if isinstance(frame, dict):
                frame_copy = frame.copy()
                if "tags" not in frame_copy:
                    frame_copy["tags"] = []
                frames_with_tags.append(frame_copy)
            else:
                frames_with_tags.append(frame)
        
        return {
            "id": self.resource_data.get("id", ""),
            "name": self.resource_data.get("name", ""),
            "type": self.resource_type,  # Use actual resource type
            "parent_folder": self.resource_data.get("parent_folder", ""),
            "created": self.resource_data.get("created", ""),
            "modified": self.resource_data.get("modified", ""),
            "width": self.resource_data.get("width", 32),
            "height": self.resource_data.get("height", 32),
            "frames": frames_with_tags,  # Frames with ensured tags field
            "origin_x": self.resource_data.get("origin_x", 0),
            "origin_y": self.resource_data.get("origin_y", 0),
            "collision_mask": self.resource_data.get("collision_mask", "Full Image"),
            "tile_horizontal": self.resource_data.get("tile_horizontal", False),
            "tile_vertical": self.resource_data.get("tile_vertical", False),
            "used_3d": self.resource_data.get("used_3d", False),
            "texture_group": self.resource_data.get("texture_group", "Default"),
            "speed": self.resource_data.get("speed", 30)
        }
    
    def get_updated_sprite_data(self):
        """Get updated sprite data from editor - returns JSON serializable data"""
        # Always try to get data from the actual Image Editor state, even if editor_state is not set
        # Extract data from editor state and create JSON-serializable version
        updated_data = self.get_sprite_data()  # Start with JSON-serializable base
        
        # Extract frame data from the Image Editor's layer manager
        # Preserve existing frame structure (id, file, duration) and add/update tags
        try:
            from core.state import state
            lm = state.layer_manager
            
            # Update width/height from state if available
            if hasattr(state, 'width') and hasattr(state, 'height'):
                updated_data.update({
                    "width": state.width,
                    "height": state.height,
                })
            
            # Get all frames from the first layer (sprites typically use one layer)
            if lm.layers and len(lm.layers) > 0:
                layer = lm.layers[0]  # Use first layer for sprite frames
                
                # Get existing frames from sprite_data to preserve structure
                existing_frames = updated_data.get("frames", [])
                frames_data = []
                
                for frame_idx, frame in enumerate(layer.frames):
                    if frame.image is not None:
                        # Get tags from frame object
                        frame_tags = getattr(frame, 'tags', [])
                        if not isinstance(frame_tags, list):
                            frame_tags = []
                        
                        # Get color_code from frame object
                        frame_color = getattr(frame, 'color_code', None)
                        if frame_color == "":
                            frame_color = None
                        
                        # Convert frame image (numpy array) to PNG bytes
                        import numpy as np
                        import base64
                        import io
                        from PIL import Image
                        
                        try:
                            # Convert numpy array to PIL Image
                            # frame.image is (height, width, channels) with channels=4 (RGBA)
                            img_array = frame.image
                            if img_array.dtype != np.uint8:
                                # Ensure it's uint8
                                img_array = np.clip(img_array, 0, 255).astype(np.uint8)
                            
                            # Convert RGBA numpy array to PIL Image
                            pil_img = Image.fromarray(img_array, 'RGBA')
                            
                            # Convert PIL Image to PNG bytes
                            img_bytes = io.BytesIO()
                            pil_img.save(img_bytes, format='PNG')
                            img_bytes.seek(0)
                            image_data_base64 = base64.b64encode(img_bytes.getvalue()).decode('utf-8')
                            
                        except Exception as e:
                            debug(f"DEBUG: Error converting frame {frame_idx} image to PNG: {e}")
                            import traceback
                            traceback.print_exc()
                            image_data_base64 = None
                        
                        # Preserve existing frame data if available, otherwise create new
                        if frame_idx < len(existing_frames):
                            frame_data = existing_frames[frame_idx].copy()
                            # Update tags and color_code
                            frame_data["tags"] = frame_tags
                            if frame_color:
                                frame_data["color_code"] = frame_color
                            elif "color_code" in frame_data:
                                # Remove color_code if it's None
                                del frame_data["color_code"]
                        else:
                            # Create new frame entry matching the sprite file format
                            frame_data = {
                                "id": f"frame_{frame_idx}",
                                "file": f"{self.resource_data.get('name', self.resource_type[:-1])}_{frame_idx}.png",
                                "duration": 0.03,  # Default duration in seconds (matches format)
                                "tags": frame_tags
                            }
                            if frame_color:
                                frame_data["color_code"] = frame_color
                        
                        # Always include the image data so frame files can be saved
                        if image_data_base64:
                            frame_data["image_data"] = image_data_base64
                        
                        frames_data.append(frame_data)
                
                # Update the frames data
                updated_data["frames"] = frames_data
                
                # Update frame count
                updated_data["frame_count"] = len(frames_data)
                
                debug(f"DEBUG: Extracted {len(frames_data)} frames from Image Editor")
                # Debug: Print tags and colors for all frames
                frames_with_tags = [i for i, fd in enumerate(frames_data) if fd.get('tags', [])]
                frames_with_colors = [i for i, fd in enumerate(frames_data) if fd.get('color_code')]
                if frames_with_tags:
                    debug(f"DEBUG: Frames with tags: {frames_with_tags}")
                    for i in frames_with_tags[:10]:  # Show first 10 frames with tags
                        debug(f"DEBUG: Frame {i} tags: {frames_data[i].get('tags', [])}")
                else:
                    debug("DEBUG: WARNING - No frames have tags!")
                if frames_with_colors:
                    debug(f"DEBUG: Frames with colors: {frames_with_colors}")
            else:
                debug("DEBUG: No layers found in Image Editor")
                debug(f"DEBUG: Layer manager has {len(lm.layers) if hasattr(lm, 'layers') else 0} layers")
                
        except Exception as e:
            debug(f"DEBUG: Error extracting frame data from Image Editor: {e}")
            import traceback
            import traceback
            traceback.print_exc()
            # Fall back to existing data but ensure tags exist
            existing_frames = updated_data.get("frames", [])
            for frame_data in existing_frames:
                if "tags" not in frame_data:
                    frame_data["tags"] = []
            debug(f"DEBUG: Using fallback data with {len(existing_frames)} frames")
        
        return updated_data
    
    def cancel_editing(self):
        """Cancel editing and close editor"""
        # Find the SpriteEditor parent and call close_image_editor
        parent = self.parent()
        while parent and not hasattr(parent, 'close_image_editor'):
            parent = parent.parent()
        
        if parent and hasattr(parent, 'close_image_editor'):
            parent.close_image_editor()
    
    # Image Editor Menu Actions
    def new_sprite(self):
        """Create a new sprite"""
        try:
            # Import the NewImageDialog
            import sys
            import os
            
            # Add the Image Editor 2 path to sys.path
            image_editor_path = os.path.join(os.path.dirname(__file__), "Image", "2")
            if image_editor_path not in sys.path:
                sys.path.insert(0, image_editor_path)
            
            from ui.dialogs import NewImageDialog
            
            # Show new sprite dialog
            dialog = NewImageDialog(self)
            dialog.setWindowTitle("New Sprite")
            
            if dialog.exec() == QDialog.Accepted:
                width, height = dialog.get_size()
                
                # Reset sprite data
                self.resource_data = {
                    "name": "NewSprite",
                    "width": width,
                    "height": height,
                    "frames": [],
                    "origin_x": 0,
                    "origin_y": 0,
                }
                
                # Update UI
                self.name_edit.setText("NewSprite")
                self.origin_x_spin.setValue(0)
                self.origin_y_spin.setValue(0)
                
                # Clear any existing image editor
                if hasattr(self, 'image_editor') and self.image_editor:
                    self.close_image_editor()
                
                # Open image editor with new sprite
                self.open_image_editor()
                
        except ImportError as e:
            QMessageBox.critical(self, "Error", f"Failed to import NewImageDialog: {str(e)}")
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to create new sprite: {str(e)}")
    
    def open_sprite(self):
        """Open a sprite file - stub implementation"""
        from PySide6.QtWidgets import QMessageBox
        QMessageBox.information(self, "Open Sprite", "Open Sprite functionality will be implemented here.")
    
    def open_image(self):
        """Open an image file - stub implementation"""
        from PySide6.QtWidgets import QMessageBox
        QMessageBox.information(self, "Open Image", "Open Image functionality will be implemented here.")
    
    def open_gif(self):
        """Open a GIF file and load all frames"""
        from PySide6.QtWidgets import QFileDialog, QMessageBox
        from PIL import Image
        
        file_path, _ = QFileDialog.getOpenFileName(self, "Open GIF", "", "GIF Files (*.gif)")
        if file_path:
            try:
                # Load GIF and extract all frames
                gif = Image.open(file_path)
                frames = []
                
                if hasattr(gif, 'n_frames') and gif.n_frames > 1:
                    # Animated GIF
                    for frame_idx in range(gif.n_frames):
                        gif.seek(frame_idx)
                        frame = gif.convert("RGBA")
                        frames.append({
                            "id": f"frame_{frame_idx}",
                            "image": frame,
                            "duration": gif.info.get('duration', 100) / 1000.0,  # Convert to seconds
                            "file_path": file_path
                        })
                else:
                    # Static GIF
                    frame = gif.convert("RGBA")
                    frames.append({
                        "id": "frame_0",
                        "image": frame,
                        "duration": 1.0,
                        "file_path": file_path
                    })
                
                # Update sprite data
                self.resource_data["frames"] = frames
                self.total_frames = len(frames)
                self.current_frame = 0
                self.frames_label.setText(f"Frames: {self.total_frames}")
                self.update_frame_display()
                self.preview_canvas.update()
                
                QMessageBox.information(self, "GIF Loaded", f"Loaded {len(frames)} frames from GIF")
                
            except Exception as e:
                QMessageBox.warning(self, "Error", f"Failed to load GIF: {str(e)}")
    
    def save_as_sprite(self):
        """Save as sprite file (.pgsprite format)"""
        if not hasattr(self, 'main_editor') or self.main_editor is None:
            from PySide6.QtWidgets import QMessageBox
            QMessageBox.warning(self, "Error", "Image editor not initialized")
            return
        self.main_editor.export_pgsprite()
    
    def save_as_image(self):
        """Save as image file (PNG)"""
        if not hasattr(self, 'main_editor') or self.main_editor is None:
            from PySide6.QtWidgets import QMessageBox
            QMessageBox.warning(self, "Error", "Image editor not initialized")
            return
        self.main_editor.export_image()
    
    def save_as_gif(self):
        """Save as GIF file"""
        if not hasattr(self, 'main_editor') or self.main_editor is None:
            from PySide6.QtWidgets import QMessageBox
            QMessageBox.warning(self, "Error", "Image editor not initialized")
            return
        self.main_editor.export_gif()
    
    def undo_action(self):
        """Undo action - delegates to Image Editor"""
        if hasattr(self, 'main_editor') and self.main_editor:
            self.main_editor.undo()
    
    def redo_action(self):
        """Redo action - delegates to Image Editor"""
        if hasattr(self, 'main_editor') and self.main_editor:
            self.main_editor.redo()
    
    def cut_action(self):
        """Cut action - delegates to Image Editor"""
        if hasattr(self, 'main_editor') and self.main_editor:
            self.main_editor.cut_selection()
    
    def copy_action(self):
        """Copy action - delegates to Image Editor"""
        if hasattr(self, 'main_editor') and self.main_editor:
            self.main_editor.copy_selection()
    
    def paste_action(self):
        """Paste action - delegates to Image Editor"""
        if hasattr(self, 'main_editor') and self.main_editor:
            self.main_editor.paste_selection()
    
    def delete_action(self):
        """Delete action - delegates to Image Editor"""
        if hasattr(self, 'main_editor') and self.main_editor:
            if hasattr(self.main_editor, 'canvas') and hasattr(self.main_editor.canvas, '_delete_selection'):
                self.main_editor.canvas._delete_selection()
    
    def crop_to_content(self):
        """Crop canvas to content - delegates to Image Editor"""
        if hasattr(self, 'main_editor') and self.main_editor:
            if hasattr(self.main_editor, 'crop_canvas'):
                self.main_editor.crop_canvas()
    
    def remove_blank_space_action(self):
        """Remove blank space - delegates to Image Editor"""
        if hasattr(self, 'main_editor') and self.main_editor:
            if hasattr(self.main_editor, 'remove_blank_space'):
                self.main_editor.remove_blank_space()
    
    def resize_selection_action(self):
        """Resize selection - delegates to Image Editor"""
        if hasattr(self, 'main_editor') and self.main_editor:
            if hasattr(self.main_editor, 'resize_selection_dialog'):
                self.main_editor.resize_selection_dialog()
    
    def select_all_action(self):
        """Select all - delegates to Image Editor"""
        if hasattr(self, 'main_editor') and self.main_editor:
            if hasattr(self.main_editor, 'canvas') and hasattr(self.main_editor.canvas, 'select_all'):
                self.main_editor.canvas.select_all()
    
    def clear_selection_action(self):
        """Clear selection - delegates to Image Editor"""
        if hasattr(self, 'main_editor') and self.main_editor:
            if hasattr(self.main_editor, 'canvas') and hasattr(self.main_editor.canvas, 'clear_selection'):
                self.main_editor.canvas.clear_selection()
    
    def duplicate_frame_action(self):
        """Duplicate frame - delegates to Image Editor"""
        if hasattr(self, 'main_editor') and self.main_editor:
            if hasattr(self.main_editor, 'duplicate_frame'):
                self.main_editor.duplicate_frame()
    
    def clear_frame_action(self):
        """Clear frame - delegates to Image Editor"""
        if hasattr(self, 'main_editor') and self.main_editor:
            if hasattr(self.main_editor, 'clear_frame'):
                self.main_editor.clear_frame()
    
    def zoom_in_action(self):
        """Zoom in - delegates to Image Editor"""
        if hasattr(self, 'main_editor') and self.main_editor:
            if hasattr(self.main_editor, 'left_panel') and hasattr(self.main_editor.left_panel, 'zoom_in'):
                self.main_editor.left_panel.zoom_in()
    
    def zoom_out_action(self):
        """Zoom out - delegates to Image Editor"""
        if hasattr(self, 'main_editor') and self.main_editor:
            if hasattr(self.main_editor, 'left_panel') and hasattr(self.main_editor.left_panel, 'zoom_out'):
                self.main_editor.left_panel.zoom_out()
    
    def zoom_reset_action(self):
        """Zoom reset - delegates to Image Editor"""
        if hasattr(self, 'main_editor') and self.main_editor:
            if hasattr(self.main_editor, 'left_panel') and hasattr(self.main_editor.left_panel, 'zoom_reset'):
                self.main_editor.left_panel.zoom_reset()
    
    def toggle_grid_action(self, checked):
        """Toggle grid visibility - delegates to Image Editor"""
        if hasattr(self, 'main_editor') and self.main_editor:
            if hasattr(self.main_editor, 'left_panel') and hasattr(self.main_editor.left_panel, 'toggle_grid'):
                self.main_editor.left_panel.toggle_grid(checked)
    
    def toggle_snap_to_grid_action(self, checked):
        """Toggle snap to grid - delegates to Image Editor"""
        if hasattr(self, 'main_editor') and self.main_editor:
            if hasattr(self.main_editor, 'left_panel') and hasattr(self.main_editor.left_panel, 'toggle_grid_snap'):
                self.main_editor.left_panel.toggle_grid_snap(checked)
    
    # ==================== AI Methods (Forward to Image Editor) ====================
    
    def ai_generate_base_sprite(self):
        """Forward to Image Editor's AI base sprite generation."""
        if hasattr(self, 'main_editor') and self.main_editor:
            if hasattr(self.main_editor, 'ai_generate_base_sprite'):
                self.main_editor.ai_generate_base_sprite()
            else:
                QMessageBox.warning(self, "AI Feature", "AI features are not available in this build.")
        else:
            QMessageBox.warning(self, "AI Feature", "Please open a sprite first.")
    
    def ai_generate_animation(self):
        """Forward to Image Editor's AI animation generation."""
        if hasattr(self, 'main_editor') and self.main_editor:
            if hasattr(self.main_editor, 'ai_generate_animation'):
                self.main_editor.ai_generate_animation()
            else:
                QMessageBox.warning(self, "AI Feature", "AI features are not available in this build.")
        else:
            QMessageBox.warning(self, "AI Feature", "Please open a sprite first.")
    
    def ai_generate_texture_pack(self):
        """Forward to Image Editor's AI texture pack generation."""
        if hasattr(self, 'main_editor') and self.main_editor:
            if hasattr(self.main_editor, 'ai_generate_texture_pack'):
                self.main_editor.ai_generate_texture_pack()
            else:
                QMessageBox.warning(self, "AI Feature", "AI features are not available in this build.")
        else:
            QMessageBox.warning(self, "AI Feature", "Please open a sprite first.")
    
    def ai_detect_skeleton(self):
        """Forward to Image Editor's AI skeleton detection."""
        if hasattr(self, 'main_editor') and self.main_editor:
            if hasattr(self.main_editor, 'ai_detect_skeleton'):
                self.main_editor.ai_detect_skeleton()
            else:
                QMessageBox.warning(self, "AI Feature", "AI features are not available in this build.")
        else:
            QMessageBox.warning(self, "AI Feature", "Please open a sprite first.")
    
    def ai_analyze_sprite(self):
        """Forward to Image Editor's AI sprite analysis."""
        if hasattr(self, 'main_editor') and self.main_editor:
            if hasattr(self.main_editor, 'ai_analyze_sprite'):
                self.main_editor.ai_analyze_sprite()
            else:
                QMessageBox.warning(self, "AI Feature", "AI features are not available in this build.")
        else:
            QMessageBox.warning(self, "AI Feature", "Please open a sprite first.")
    
    def ai_upscale(self):
        """Forward to Image Editor's AI upscale."""
        if hasattr(self, 'main_editor') and self.main_editor:
            if hasattr(self.main_editor, 'ai_upscale'):
                self.main_editor.ai_upscale()
            else:
                QMessageBox.warning(self, "AI Feature", "AI features are not available in this build.")
        else:
            QMessageBox.warning(self, "AI Feature", "Please open a sprite first.")
    
    def ai_background_removal(self):
        """Forward to Image Editor's AI background removal."""
        if hasattr(self, 'main_editor') and self.main_editor:
            if hasattr(self.main_editor, 'ai_background_removal'):
                self.main_editor.ai_background_removal()
            else:
                QMessageBox.warning(self, "AI Feature", "AI features are not available in this build.")
        else:
            QMessageBox.warning(self, "AI Feature", "Please open a sprite first.")
    
    def ai_image_to_3d(self):
        """Forward to Image Editor's AI image to 3D conversion."""
        if hasattr(self, 'main_editor') and self.main_editor:
            if hasattr(self.main_editor, 'ai_image_to_3d'):
                self.main_editor.ai_image_to_3d()
            else:
                QMessageBox.warning(self, "AI Feature", "AI features are not available in this build.")
        else:
            QMessageBox.warning(self, "AI Feature", "Please open a sprite first.")
    
    def ai_sprite_to_3d(self):
        """Forward to Image Editor's AI sprite to 3D conversion."""
        if hasattr(self, 'main_editor') and self.main_editor:
            if hasattr(self.main_editor, 'ai_sprite_to_3d'):
                self.main_editor.ai_sprite_to_3d()
            else:
                QMessageBox.warning(self, "AI Feature", "AI features are not available in this build.")
        else:
            QMessageBox.warning(self, "AI Feature", "Please open a sprite first.")
    
    def sync_grid_states(self):
        """Sync grid toggle states with Image Editor state"""
        if hasattr(self, 'main_editor') and self.main_editor:
            try:
                # Import state from Image Editor (path should already be in sys.path)
                import sys
                import os
                image_editor_path = os.path.join(os.path.dirname(__file__), 'Image', '2')
                if image_editor_path not in sys.path:
                    sys.path.insert(0, image_editor_path)
                from core.state import state
                if hasattr(self, 'grid_toggle_action'):
                    self.grid_toggle_action.setChecked(state.grid_visible)
                if hasattr(self, 'snap_to_grid_action'):
                    self.snap_to_grid_action.setChecked(state.grid_snap)
            except Exception as e:
                debug(f"DEBUG sync_grid_states: Error syncing grid states: {e}")
    
    def invert_colors(self):
        """Invert colors effect - stub implementation"""
        from PySide6.QtWidgets import QMessageBox
        QMessageBox.information(self, "Invert Colors", "Invert Colors effect will be implemented here.")
    
    def apply_theme(self):
        """Apply current theme to sprite editor"""
        if not self.app or not hasattr(self.app, 'theme_manager'):
            return
            
        theme_stylesheet = self.app.theme_manager.get_stylesheet("sprite_editor")
        self.setStyleSheet(theme_stylesheet)
        
        # Apply theme to all child widgets
        for widget in self.findChildren(QWidget):
            if widget != self:
                widget.setStyleSheet(theme_stylesheet)
    
    def blur_effect(self):
        """Blur effect - stub implementation"""
        from PySide6.QtWidgets import QMessageBox
        QMessageBox.information(self, "Blur", "Blur effect will be implemented here.")
    
    def sharpen_effect(self):
        """Sharpen effect - stub implementation"""
        from PySide6.QtWidgets import QMessageBox
        QMessageBox.information(self, "Sharpen", "Sharpen effect will be implemented here.")
    
    def show_preferences(self):
        """Show image editor preferences - stub implementation"""
        from PySide6.QtWidgets import QMessageBox
        QMessageBox.information(self, "Image Editor Preferences", "Image Editor preferences will be implemented here with settings specific to the image editor.")
    
    # Image Editor Effects - Delegate to the embedded Image Editor
    def effect_invert(self):
        if hasattr(self, 'main_editor') and self.main_editor:
            self.main_editor.effect_invert()
    
    def effect_brightness(self):
        if hasattr(self, 'main_editor') and self.main_editor:
            self.main_editor.effect_brightness()
    
    def effect_contrast(self):
        if hasattr(self, 'main_editor') and self.main_editor:
            self.main_editor.effect_contrast()
    
    def effect_greyscale(self):
        if hasattr(self, 'main_editor') and self.main_editor:
            self.main_editor.effect_greyscale()
    
    def effect_fade(self):
        if hasattr(self, 'main_editor') and self.main_editor:
            self.main_editor.effect_fade()
    
    def effect_opacity(self):
        if hasattr(self, 'main_editor') and self.main_editor:
            self.main_editor.effect_opacity()
    
    def effect_blur(self):
        if hasattr(self, 'main_editor') and self.main_editor:
            self.main_editor.effect_blur()
    
    def effect_sharpen(self):
        if hasattr(self, 'main_editor') and self.main_editor:
            self.main_editor.effect_sharpen()
    
    def effect_noise(self):
        if hasattr(self, 'main_editor') and self.main_editor:
            self.main_editor.effect_noise()
    
    def effect_pixelate(self):
        if hasattr(self, 'main_editor') and self.main_editor:
            self.main_editor.effect_pixelate()
    
    def effect_dither(self):
        if hasattr(self, 'main_editor') and self.main_editor:
            self.main_editor.effect_dither()
    
    def effect_vignette(self):
        debug("=" * 60)
        debug("DEBUG: SpriteEditor.effect_vignette called")
        debug(f"DEBUG: hasattr(self, 'main_editor'): {hasattr(self, 'main_editor')}")
        if hasattr(self, 'main_editor'):
            debug(f"DEBUG: self.main_editor exists: {self.main_editor is not None}")
            debug(f"DEBUG: Calling self.main_editor.effect_vignette()")
            self.main_editor.effect_vignette()
            debug("DEBUG: Returned from main_editor call")
        else:
            debug("DEBUG: ERROR - No main_editor found!")
        debug("=" * 60)
    
    def effect_saturation(self):
        if hasattr(self, 'main_editor') and self.main_editor:
            self.main_editor.effect_saturation()
    
    def effect_posterize(self):
        if hasattr(self, 'main_editor') and self.main_editor:
            self.main_editor.effect_posterize()
    
    def effect_emboss(self):
        if hasattr(self, 'main_editor') and self.main_editor:
            self.main_editor.effect_emboss()
    
    def effect_edge_detection(self):
        if hasattr(self, 'main_editor') and self.main_editor:
            self.main_editor.effect_edge_detection()
    
    def effect_colorize(self):
        if hasattr(self, 'main_editor') and self.main_editor:
            self.main_editor.effect_colorize()
    
    def effect_oil_painting(self):
        if hasattr(self, 'main_editor') and self.main_editor:
            self.main_editor.effect_oil_painting()
    
    def effect_glow(self):
        if hasattr(self, 'main_editor') and self.main_editor:
            self.main_editor.effect_glow()
    
    def effect_solarize(self):
        if hasattr(self, 'main_editor') and self.main_editor:
            self.main_editor.effect_solarize()
    
    def effect_upscale(self):
        if hasattr(self, 'main_editor') and self.main_editor:
            self.main_editor.effect_upscale()
    
    def effect_motion_blur(self):
        if hasattr(self, 'main_editor') and self.main_editor:
            self.main_editor.effect_motion_blur()
    
    def effect_shader_bloom(self):
        if hasattr(self, 'main_editor') and self.main_editor:
            self.main_editor.effect_shader_bloom()
    
    def effect_palette_cycler(self):
        if hasattr(self, 'main_editor') and self.main_editor:
            self.main_editor.effect_palette_cycler()
    
    def effect_pixel_depth(self):
        if hasattr(self, 'main_editor') and self.main_editor:
            self.main_editor.effect_pixel_depth()
    
    def effect_hd_crisp(self):
        if hasattr(self, 'main_editor') and self.main_editor:
            self.main_editor.effect_hd_crisp()
    
    # Reshade Gaming placeholders
    def effect_voxelize(self):
        if hasattr(self, 'main_editor') and self.main_editor:
            self.main_editor.effect_voxelize()
    
    def effect_dream_diffuse(self):
        if hasattr(self, 'main_editor') and self.main_editor:
            self.main_editor.effect_dream_diffuse()
    
    def effect_vhs(self):
        if hasattr(self, 'main_editor') and self.main_editor:
            self.main_editor.effect_vhs()
    
    def effect_posterizer(self):
        if hasattr(self, 'main_editor') and self.main_editor:
            self.main_editor.effect_posterizer()
    
    # Reshade Lighting
    def effect_normal_map(self):
        if hasattr(self, 'main_editor') and self.main_editor:
            self.main_editor.effect_normal_map()
    
    def effect_light_overlay(self):
        if hasattr(self, 'main_editor') and self.main_editor:
            self.main_editor.effect_light_overlay()
    
    def effect_mirror_horizontal(self):
        if hasattr(self, 'main_editor') and self.main_editor:
            self.main_editor.effect_mirror_horizontal()
    
    def effect_mirror_vertical(self):
        if hasattr(self, 'main_editor') and self.main_editor:
            self.main_editor.effect_mirror_vertical()
    
    def effect_rotate_90(self):
        if hasattr(self, 'main_editor') and self.main_editor:
            self.main_editor.effect_rotate_90()
    
    def effect_rotate_180(self):
        if hasattr(self, 'main_editor') and self.main_editor:
            self.main_editor.effect_rotate_180()
    
    def effect_rotate_custom(self):
        if hasattr(self, 'main_editor') and self.main_editor:
            self.main_editor.effect_rotate_custom()
    
    def effect_map_generator(self):
        if hasattr(self, 'main_editor') and self.main_editor:
            self.main_editor.effect_map_generator()
    
    def effect_texture_2d(self):
        if hasattr(self, 'main_editor') and self.main_editor:
            self.main_editor.effect_texture_2d()
    
    def nine_slice_import(self):
        """Forward Nine-Slice import to Image Editor"""
        debug("DEBUG: IntegratedImageEditor.nine_slice_import() called")
        if hasattr(self, 'main_editor') and self.main_editor:
            debug("DEBUG: Calling main_editor.nine_slice_import()")
            self.main_editor.nine_slice_import()
        else:
            debug("DEBUG: main_editor not available")
            from PySide6.QtWidgets import QMessageBox
            QMessageBox.warning(self, "Image Editor Not Available", 
                              "Please open the Image Editor first by clicking 'Edit' on a sprite.")
    
    def effect_generate_lod(self):
        if hasattr(self, 'main_editor') and self.main_editor:
            self.main_editor.effect_generate_lod()
    
    def effect_advanced_atlas(self):
        if hasattr(self, 'main_editor') and self.main_editor:
            self.main_editor.open_advanced_atlas_dialog()
    
    def effect_character_creation(self):
        if hasattr(self, 'main_editor') and self.main_editor:
            self.main_editor.open_character_creator()
    
    def toggle_timeline(self):
        """Toggle timeline visibility in the embedded Image Editor"""
        if hasattr(self, 'main_editor') and self.main_editor:
            if hasattr(self.main_editor, 'toggle_timeline'):
                self.main_editor.toggle_timeline()
    
    def toggle_fullscreen(self, checked=False):
        """Toggle fullscreen mode"""
        if not self.is_fullscreen:
            self.enter_fullscreen()
        else:
            self.exit_fullscreen()
    
    def enter_fullscreen(self):
        """Enter fullscreen mode"""
        # Use stored main window reference
        if self.main_window:
            # Store original geometry
            self.original_geometry = self.main_window.geometry()
            
            # Store the original parent and layout for restoration
            self.original_parent = self.parent()
            self.original_layout = None
            if self.original_parent and hasattr(self.original_parent, 'layout'):
                self.original_layout = self.original_parent.layout()
            
            # Hide the main window and show fullscreen
            self.main_window.hide()
            
            # Create a new fullscreen window
            self.fullscreen_window = QWidget()
            self.fullscreen_window.setWindowTitle("Image Editor - Fullscreen")
            self.fullscreen_window.setWindowState(Qt.WindowMaximized)
            
            # Handle window close event to exit fullscreen instead of closing app
            self.fullscreen_window.closeEvent = self.fullscreen_close_event
            
            # Add the editor to the fullscreen window
            layout = QVBoxLayout(self.fullscreen_window)
            layout.setContentsMargins(0, 0, 0, 0)
            layout.addWidget(self)
            
            # Show fullscreen
            self.fullscreen_window.show()
            self.is_fullscreen = True
            self.fullscreen_action.setChecked(True)
            
            debug("DEBUG: Entered fullscreen mode")
        else:
            debug("DEBUG: No main window reference available for fullscreen")
    
    def exit_fullscreen(self):
        """Exit fullscreen mode"""
        if self.is_fullscreen and hasattr(self, 'fullscreen_window'):
            # Hide fullscreen window
            self.fullscreen_window.hide()
            
            # Use stored main window reference
            if self.main_window and self.original_geometry:
                self.main_window.setGeometry(self.original_geometry)
                self.main_window.show()
                self.main_window.raise_()  # Bring to front
                self.main_window.activateWindow()  # Activate the window
                
                # Restore the widget to its original parent
                if hasattr(self, 'original_parent') and self.original_parent:
                    debug("DEBUG: Restoring widget to original parent")
                    # Remove from fullscreen window
                    self.setParent(None)
                    # Add back to original parent
                    if hasattr(self.original_parent, 'layout') and self.original_parent.layout():
                        self.original_parent.layout().addWidget(self)
                    else:
                        # If no layout, create a simple one
                        layout = QVBoxLayout(self.original_parent)
                        layout.setContentsMargins(0, 0, 0, 0)
                        layout.addWidget(self)
                    
                    # Ensure the Image Editor tab is visible and focused
                    self._restore_image_editor_tab()
                
                debug("DEBUG: Restored main window from fullscreen")
            else:
                debug("DEBUG: No main window reference or geometry to restore from fullscreen")
                # If we can't restore the main window, just clean up and stay in the current state
                # This prevents the app from closing unexpectedly
            
            # Clean up
            self.fullscreen_window.deleteLater()
            delattr(self, 'fullscreen_window')
            
            self.is_fullscreen = False
            self.fullscreen_action.setChecked(False)
            
            debug("DEBUG: Exited fullscreen mode")
    
    def _restore_image_editor_tab(self):
        """Restore and focus the Image Editor tab after exiting fullscreen"""
        try:
            # Find the SpriteEditor that contains this IntegratedImageEditor
            sprite_editor = None
            current = self.parent()
            
            # Traverse up the parent hierarchy more thoroughly
            while current:
                debug(f"DEBUG: Checking parent: {type(current).__name__}")
                if hasattr(current, 'tab_widget') and hasattr(current, 'name_edit'):
                    sprite_editor = current
                    debug(f"DEBUG: Found SpriteEditor: {sprite_editor}")
                    break
                current = current.parent()
            
            if sprite_editor and hasattr(sprite_editor, 'tab_widget'):
                debug(f"DEBUG: SpriteEditor has {sprite_editor.tab_widget.count()} tabs")
                # Find the Image Editor tab
                for i in range(sprite_editor.tab_widget.count()):
                    tab_text = sprite_editor.tab_widget.tabText(i)
                    debug(f"DEBUG: Tab {i}: {tab_text}")
                    if tab_text.startswith("Image Editor -"):
                        # Switch to the Image Editor tab
                        sprite_editor.tab_widget.setCurrentIndex(i)
                        debug(f"DEBUG: Switched to Image Editor tab: {tab_text}")
                        return
                
                debug("DEBUG: Image Editor tab not found in existing tabs")
                # If no Image Editor tab exists, create one
                sprite_editor.open_image_editor()
            else:
                debug("DEBUG: Could not find SpriteEditor to restore tab")
                
        except Exception as e:
            debug(f"DEBUG: Error restoring Image Editor tab: {e}")
    
    def fullscreen_close_event(self, event):
        """Handle fullscreen window close event - exit fullscreen instead of closing"""
        debug("DEBUG: Fullscreen window close event - exiting fullscreen")
        self.exit_fullscreen()
        event.accept()  # Accept the close event to prevent app termination

