"""
Room Editor Main Window
GameMaker-style room editor with tabbed interface for Objects, Background, Settings, Views, and Instance Order.
"""

from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel,
    QPushButton, QSpinBox, QCheckBox, QScrollArea,
    QFrame, QSplitter, QListWidget, QListWidgetItem,
    QMessageBox, QFileDialog, QInputDialog, QComboBox,
    QGroupBox, QLineEdit, QMenu, QColorDialog,
    QDoubleSpinBox, QTabWidget
)
from PySide6.QtCore import Qt, QPoint
from PySide6.QtGui import QColor
from typing import Dict, Optional, Any, List

from Core.EditorInterface import EditorInterface
from Core.Debug import debug
from ..widgets.room_canvas import RoomCanvas
from ..core.room_data import RoomDataManager
from ..services.room_io import RoomIOService


class RoomEditor(QWidget, EditorInterface):
    """
    Main Room Editor widget.
    - Integrates with PyGenesis app + project_manager/resource_manager.
    - 2D only for now; 3D mode is a stub flag.
    """

    def __init__(self, app, resource_data):
        super().__init__()
        self.app = app
        self.resource_data: Dict[str, Any] = resource_data or {}
        self._dirty = False

        # Initialize services
        self.room_io = RoomIOService(app)

        # Editor state
        self.selected_object_id: Optional[str] = None  # Currently selected object type (for placement)
        self.selected_instance_index: int = -1
        self.dragging_instance: bool = False
        self.drag_start_pos: Optional[QPoint] = None

        # 2D/3D mode flag (3D is placeholder only)
        self.is_3d_mode: bool = False

        # Views data (per-room camera setups, etc.)
        self.views: List[Dict[str, Any]] = self.resource_data.get("views", [])

        self.setup_ui()

        # After UI exists, open current resource data
        if resource_data:
            self.open_resource(resource_data)
        else:
            # Some sane defaults if creating a new room
            default_room = RoomDataManager.create_default_room()
            for key, value in default_room.items():
                if key not in self.resource_data:
                    self.resource_data[key] = value
            self.views = self.resource_data["views"]
            self.update_instances_list()
            self.update_views_list()

    # -------------------------------------------------------------------------
    # UI Setup
    # -------------------------------------------------------------------------

    def setup_ui(self):
        """Setup main layout: top toolbar + left dock-style tabs + central canvas."""
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(0)

        # Top toolbar row (simple controls, acts like GM top panel)
        toolbar = self.create_top_toolbar()
        main_layout.addWidget(toolbar)

        # Main splitter: left panel (tabs) + canvas
        main_splitter = QSplitter(Qt.Horizontal)
        main_splitter.setChildrenCollapsible(False)

        # Left tabbed panel
        self.left_panel_tabs = self.create_left_tab_panel()
        self.left_panel_tabs.setMinimumWidth(260)
        self.left_panel_tabs.setMaximumWidth(380)
        main_splitter.addWidget(self.left_panel_tabs)

        # Room canvas (inside a scroll area)
        canvas_scroll = QScrollArea()
        canvas_scroll.setWidgetResizable(True)
        canvas_scroll.setAlignment(Qt.AlignCenter)
        self.canvas = RoomCanvas(self)
        canvas_scroll.setWidget(self.canvas)
        main_splitter.addWidget(canvas_scroll)

        main_splitter.setStretchFactor(0, 0)
        main_splitter.setStretchFactor(1, 1)
        main_splitter.setSizes([280, 900])

        main_layout.addWidget(main_splitter)

    def create_top_toolbar(self) -> QFrame:
        """Create top toolbar with grid/snap/zoom/2D-3D controls."""
        toolbar = QFrame()
        toolbar.setFixedHeight(38)
        toolbar.setStyleSheet("""
            QFrame {
                background-color: #2b2b2b;
                border-bottom: 1px solid #404060;
            }
        """)

        layout = QHBoxLayout(toolbar)
        layout.setContentsMargins(8, 4, 8, 4)
        layout.setSpacing(8)

        # Snap
        self.snap_check = QCheckBox("Snap")
        self.snap_check.setChecked(True)
        self.snap_check.toggled.connect(self.on_snap_changed)
        layout.addWidget(self.snap_check)

        # Grid
        self.show_grid_check = QCheckBox("Grid")
        self.show_grid_check.setChecked(True)
        self.show_grid_check.toggled.connect(self.on_show_grid_changed)
        layout.addWidget(self.show_grid_check)

        # Grid size
        layout.addWidget(QLabel("Grid:"))
        self.grid_x_spin = QSpinBox()
        self.grid_x_spin.setRange(4, 256)
        self.grid_x_spin.setValue(32)
        self.grid_x_spin.valueChanged.connect(self.on_grid_changed)
        self.grid_x_spin.setMinimumWidth(60)
        layout.addWidget(self.grid_x_spin)

        self.grid_y_spin = QSpinBox()
        self.grid_y_spin.setRange(4, 256)
        self.grid_y_spin.setValue(32)
        self.grid_y_spin.valueChanged.connect(self.on_grid_changed)
        self.grid_y_spin.setMinimumWidth(60)
        layout.addWidget(self.grid_y_spin)

        # Placeholder Z grid for future 3D
        self.grid_z_label = QLabel("Z:")
        self.grid_z_spin = QSpinBox()
        self.grid_z_spin.setRange(4, 256)
        self.grid_z_spin.setValue(32)
        self.grid_z_spin.valueChanged.connect(self.on_grid_changed)
        self.grid_z_spin.setMinimumWidth(60)
        self.grid_z_label.setVisible(False)
        self.grid_z_spin.setVisible(False)
        layout.addWidget(self.grid_z_label)
        layout.addWidget(self.grid_z_spin)

        layout.addSpacing(12)

        # Zoom controls (they affect RoomCanvas zoom)
        layout.addWidget(QLabel("Zoom:"))
        self.zoom_spin = QDoubleSpinBox()
        self.zoom_spin.setDecimals(2)
        self.zoom_spin.setRange(0.1, 4.0)
        self.zoom_spin.setSingleStep(0.1)
        self.zoom_spin.setValue(1.0)
        self.zoom_spin.valueChanged.connect(self.on_zoom_changed)
        layout.addWidget(self.zoom_spin)

        reset_zoom_btn = QPushButton("Reset")
        reset_zoom_btn.clicked.connect(self.on_reset_zoom_clicked)
        reset_zoom_btn.setFixedWidth(60)
        layout.addWidget(reset_zoom_btn)

        layout.addStretch()

        # 2D / 3D mode toggle (3D placeholder only)
        self.mode_3d_check = QCheckBox("3D Mode (future)")
        self.mode_3d_check.setChecked(False)
        self.mode_3d_check.toggled.connect(self.on_3d_mode_changed)
        layout.addWidget(self.mode_3d_check)

        return toolbar

    def create_left_tab_panel(self) -> QTabWidget:
        """Create left-side QTabWidget with separate tabs for Objects, Background, Settings, Views, Instance Order."""
        tabs = QTabWidget()
        tabs.setDocumentMode(True)
        tabs.setTabPosition(QTabWidget.North)

        # Objects tab
        objects_tab = QWidget()
        objects_layout = QVBoxLayout(objects_tab)
        objects_layout.setContentsMargins(6, 6, 6, 6)
        objects_layout.setSpacing(6)
        objects_layout.addWidget(self.create_objects_group())
        objects_layout.addStretch()
        tabs.addTab(objects_tab, "Objects")

        # Background tab
        background_tab = QWidget()
        bg_layout = QVBoxLayout(background_tab)
        bg_layout.setContentsMargins(6, 6, 6, 6)
        bg_layout.setSpacing(6)
        bg_layout.addWidget(self.create_background_group())
        bg_layout.addStretch()
        tabs.addTab(background_tab, "Background")

        # Settings tab
        settings_tab = QWidget()
        st_layout = QVBoxLayout(settings_tab)
        st_layout.setContentsMargins(6, 6, 6, 6)
        st_layout.setSpacing(6)
        st_layout.addWidget(self.create_settings_group())
        st_layout.addStretch()
        tabs.addTab(settings_tab, "Settings")

        # Views tab (camera / view configuration)
        views_tab = QWidget()
        v_layout = QVBoxLayout(views_tab)
        v_layout.setContentsMargins(6, 6, 6, 6)
        v_layout.setSpacing(6)
        v_layout.addWidget(self.create_views_group())
        v_layout.addStretch()
        tabs.addTab(views_tab, "Views")

        # Instance Order tab
        order_tab = QWidget()
        o_layout = QVBoxLayout(order_tab)
        o_layout.setContentsMargins(6, 6, 6, 6)
        o_layout.setSpacing(6)
        o_layout.addWidget(self.create_instance_order_group())
        o_layout.addStretch()
        tabs.addTab(order_tab, "Instance Order")

        return tabs

    # -------------------------------------------------------------------------
    # Objects Tab
    # -------------------------------------------------------------------------

    def create_objects_group(self) -> QGroupBox:
        """Objects tab: object selection & instance list."""
        group = QGroupBox("Objects")
        group.setStyleSheet("""
            QGroupBox {
                font-weight: bold;
                border: 1px solid #404060;
                border-radius: 4px;
                margin-top: 10px;
                padding-top: 10px;
            }
            QGroupBox::title {
                subcontrol-origin: margin;
                left: 10px;
                padding: 0 5px;
            }
        """)

        layout = QVBoxLayout(group)
        layout.setContentsMargins(8, 20, 8, 8)
        layout.setSpacing(6)

        layout.addWidget(QLabel("Object browser:"))
        self.objects_list = QListWidget()
        self.objects_list.setMaximumHeight(160)
        self.objects_list.itemClicked.connect(self.on_object_selected)
        self.objects_list.setContextMenuPolicy(Qt.CustomContextMenu)
        self.objects_list.customContextMenuRequested.connect(self.on_objects_list_context_menu)
        layout.addWidget(self.objects_list)

        self.populate_objects_list()

        self.object_info_label = QLabel("No object selected.\nClick an object above, then click in the room to place.")
        self.object_info_label.setWordWrap(True)
        self.object_info_label.setStyleSheet("color: #aaaaaa; font-size: 10px;")
        layout.addWidget(self.object_info_label)

        layout.addWidget(QLabel("Placed instances:"))
        self.instances_list = QListWidget()
        self.instances_list.setMaximumHeight(160)
        self.instances_list.itemClicked.connect(self.on_instance_list_selected)
        self.instances_list.setContextMenuPolicy(Qt.CustomContextMenu)
        self.instances_list.customContextMenuRequested.connect(self.on_instances_list_context_menu)
        layout.addWidget(self.instances_list)

        btn_row = QHBoxLayout()
        self.remove_instance_btn = QPushButton("Remove")
        self.remove_instance_btn.clicked.connect(self.remove_instance)
        self.remove_instance_btn.setEnabled(False)
        btn_row.addWidget(self.remove_instance_btn)

        self.duplicate_instance_btn = QPushButton("Duplicate")
        self.duplicate_instance_btn.clicked.connect(self.duplicate_selected_instance)
        self.duplicate_instance_btn.setEnabled(False)
        btn_row.addWidget(self.duplicate_instance_btn)

        layout.addLayout(btn_row)

        return group

    def populate_objects_list(self):
        """Populate object list from project resources."""
        self.objects_list.clear()
        if not hasattr(self.app, "project_manager") or self.app.project_manager is None:
            return

        objects = self.app.project_manager.get_runtime_resources("objects")
        for obj_id, obj_data in objects.items():
            obj_name = obj_data.get("name", obj_id)
            item = QListWidgetItem(obj_name)
            item.setData(Qt.UserRole, obj_id)
            self.objects_list.addItem(item)

    # -------------------------------------------------------------------------
    # Background Tab
    # -------------------------------------------------------------------------

    def create_background_group(self) -> QGroupBox:
        group = QGroupBox("Background")
        group.setStyleSheet("""
            QGroupBox {
                font-weight: bold;
                border: 1px solid #404060;
                border-radius: 4px;
                margin-top: 10px;
                padding-top: 10px;
            }
            QGroupBox::title {
                subcontrol-origin: margin;
                left: 10px;
                padding: 0 5px;
            }
        """)
        layout = QVBoxLayout(group)
        layout.setContentsMargins(8, 20, 8, 8)
        layout.setSpacing(6)

        layout.addWidget(QLabel("Background sprite:"))
        self.background_combo = QComboBox()
        self.background_combo.addItem("(none)", None)
        self.background_combo.currentIndexChanged.connect(self.on_background_selected)
        layout.addWidget(self.background_combo)

        self.populate_backgrounds_combo()

        # Background colour
        color_row = QHBoxLayout()
        color_row.addWidget(QLabel("Clear color:"))
        self.bg_color_btn = QPushButton()
        self.bg_color_btn.setFixedSize(40, 24)
        self.bg_color_btn.clicked.connect(self.on_bg_color_clicked)
        color_row.addWidget(self.bg_color_btn)
        color_row.addStretch()
        layout.addLayout(color_row)

        # Scroll / speed
        speed_row = QHBoxLayout()
        speed_row.addWidget(QLabel("Scroll:"))
        self.bg_hspeed_spin = QDoubleSpinBox()
        self.bg_hspeed_spin.setRange(-1000.0, 1000.0)
        self.bg_hspeed_spin.setDecimals(2)
        self.bg_hspeed_spin.setValue(0.0)
        self.bg_hspeed_spin.setSuffix(" H")
        self.bg_hspeed_spin.valueChanged.connect(self.on_background_settings_changed)
        speed_row.addWidget(self.bg_hspeed_spin)

        self.bg_vspeed_spin = QDoubleSpinBox()
        self.bg_vspeed_spin.setRange(-1000.0, 1000.0)
        self.bg_vspeed_spin.setDecimals(2)
        self.bg_vspeed_spin.setValue(0.0)
        self.bg_vspeed_spin.setSuffix(" V")
        self.bg_vspeed_spin.valueChanged.connect(self.on_background_settings_changed)
        speed_row.addWidget(self.bg_vspeed_spin)
        layout.addLayout(speed_row)

        # Stretch / tile
        self.bg_stretch_check = QCheckBox("Stretch to fill room")
        self.bg_stretch_check.toggled.connect(self.on_background_settings_changed)
        layout.addWidget(self.bg_stretch_check)

        tile_row = QHBoxLayout()
        tile_row.addWidget(QLabel("Tile:"))
        self.bg_tile_h_check = QCheckBox("Horizontal")
        self.bg_tile_h_check.toggled.connect(self.on_background_settings_changed)
        tile_row.addWidget(self.bg_tile_h_check)

        self.bg_tile_v_check = QCheckBox("Vertical")
        self.bg_tile_v_check.toggled.connect(self.on_background_settings_changed)
        tile_row.addWidget(self.bg_tile_v_check)
        tile_row.addStretch()
        layout.addLayout(tile_row)

        # Repeat counts (for tile)
        repeat_row = QHBoxLayout()
        repeat_row.addWidget(QLabel("Repeat:"))
        self.bg_repeat_h_spin = QSpinBox()
        self.bg_repeat_h_spin.setRange(1, 999)
        self.bg_repeat_h_spin.setValue(1)
        self.bg_repeat_h_spin.setSuffix(" H")
        self.bg_repeat_h_spin.valueChanged.connect(self.on_background_settings_changed)
        repeat_row.addWidget(self.bg_repeat_h_spin)

        self.bg_repeat_v_spin = QSpinBox()
        self.bg_repeat_v_spin.setRange(1, 999)
        self.bg_repeat_v_spin.setValue(1)
        self.bg_repeat_v_spin.setSuffix(" V")
        self.bg_repeat_v_spin.valueChanged.connect(self.on_background_settings_changed)
        repeat_row.addWidget(self.bg_repeat_v_spin)
        layout.addLayout(repeat_row)

        return group

    def populate_backgrounds_combo(self):
        """Fill backgrounds combo from resources (using 'backgrounds' or 'sprites' set)."""
        if not hasattr(self.app, "project_manager") or self.app.project_manager is None:
            return

        # Try backgrounds first, fallback to sprites
        backgrounds = self.app.project_manager.get_runtime_resources("backgrounds")
        if not backgrounds:
            backgrounds = self.app.project_manager.get_runtime_resources("sprites")

        for bg_id, bg_data in backgrounds.items():
            name = bg_data.get("name", bg_id)
            self.background_combo.addItem(name, bg_id)

    # -------------------------------------------------------------------------
    # Settings Tab
    # -------------------------------------------------------------------------

    def create_settings_group(self) -> QGroupBox:
        group = QGroupBox("Settings")
        group.setStyleSheet("""
            QGroupBox {
                font-weight: bold;
                border: 1px solid #404060;
                border-radius: 4px;
                margin-top: 10px;
                padding-top: 10px;
            }
            QGroupBox::title {
                subcontrol-origin: margin;
                left: 10px;
                padding: 0 5px;
            }
        """)
        layout = QVBoxLayout(group)
        layout.setContentsMargins(8, 20, 8, 8)
        layout.setSpacing(6)

        # Title
        layout.addWidget(QLabel("Room name:"))
        self.title_edit = QLineEdit()
        self.title_edit.textChanged.connect(self.on_settings_changed)
        layout.addWidget(self.title_edit)

        # Room size
        size_row = QHBoxLayout()
        size_row.addWidget(QLabel("Size:"))
        self.width_spin = QSpinBox()
        self.width_spin.setRange(64, 16384)
        self.width_spin.setValue(1024)
        self.width_spin.setSuffix(" W")
        self.width_spin.valueChanged.connect(self.on_size_changed)
        size_row.addWidget(self.width_spin)

        self.height_spin = QSpinBox()
        self.height_spin.setRange(64, 16384)
        self.height_spin.setValue(768)
        self.height_spin.setSuffix(" H")
        self.height_spin.valueChanged.connect(self.on_size_changed)
        size_row.addWidget(self.height_spin)
        layout.addLayout(size_row)

        # Room speed (logic)
        layout.addWidget(QLabel("Room speed:"))
        self.room_speed_spin = QDoubleSpinBox()
        self.room_speed_spin.setRange(0.1, 1000.0)
        self.room_speed_spin.setDecimals(2)
        self.room_speed_spin.setSingleStep(0.1)
        self.room_speed_spin.setValue(1.0)
        self.room_speed_spin.valueChanged.connect(self.on_settings_changed)
        layout.addWidget(self.room_speed_spin)

        # Room scroll speed (parallax)
        speed_row = QHBoxLayout()
        speed_row.addWidget(QLabel("Scroll override:"))
        self.room_hspeed_spin = QDoubleSpinBox()
        self.room_hspeed_spin.setRange(-1000.0, 1000.0)
        self.room_hspeed_spin.setDecimals(2)
        self.room_hspeed_spin.setSuffix(" H")
        self.room_hspeed_spin.valueChanged.connect(self.on_settings_changed)
        speed_row.addWidget(self.room_hspeed_spin)

        self.room_vspeed_spin = QDoubleSpinBox()
        self.room_vspeed_spin.setRange(-1000.0, 1000.0)
        self.room_vspeed_spin.setDecimals(2)
        self.room_vspeed_spin.setSuffix(" V")
        self.room_vspeed_spin.valueChanged.connect(self.on_settings_changed)
        speed_row.addWidget(self.room_vspeed_spin)
        layout.addLayout(speed_row)

        return group

    # -------------------------------------------------------------------------
    # Views Tab
    # -------------------------------------------------------------------------

    def create_views_group(self) -> QGroupBox:
        group = QGroupBox("Views / Cameras")
        group.setStyleSheet("""
            QGroupBox {
                font-weight: bold;
                border: 1px solid #404060;
                border-radius: 4px;
                margin-top: 10px;
                padding-top: 10px;
            }
            QGroupBox::title {
                subcontrol-origin: margin;
                left: 10px;
                padding: 0 5px;
            }
        """)

        layout = QVBoxLayout(group)
        layout.setContentsMargins(8, 20, 8, 8)
        layout.setSpacing(6)

        self.views_enabled_check = QCheckBox("Enable views")
        self.views_enabled_check.toggled.connect(self.on_views_enabled_changed)
        layout.addWidget(self.views_enabled_check)

        self.views_list = QListWidget()
        self.views_list.setMaximumHeight(140)
        self.views_list.itemSelectionChanged.connect(self.on_view_selected)
        layout.addWidget(self.views_list)

        btn_row = QHBoxLayout()
        add_btn = QPushButton("Add View")
        add_btn.clicked.connect(self.add_view)
        btn_row.addWidget(add_btn)

        remove_btn = QPushButton("Remove")
        remove_btn.clicked.connect(self.remove_selected_view)
        btn_row.addWidget(remove_btn)
        layout.addLayout(btn_row)

        # Simple properties (for selected view)
        layout.addWidget(QLabel("View properties:"))
        coord_row1 = QHBoxLayout()
        self.view_x_spin = QSpinBox()
        self.view_x_spin.setRange(-999999, 999999)
        self.view_x_spin.setPrefix("X:")
        self.view_x_spin.valueChanged.connect(self.on_view_property_changed)
        coord_row1.addWidget(self.view_x_spin)

        self.view_y_spin = QSpinBox()
        self.view_y_spin.setRange(-999999, 999999)
        self.view_y_spin.setPrefix("Y:")
        self.view_y_spin.valueChanged.connect(self.on_view_property_changed)
        coord_row1.addWidget(self.view_y_spin)
        layout.addLayout(coord_row1)

        coord_row2 = QHBoxLayout()
        self.view_w_spin = QSpinBox()
        self.view_w_spin.setRange(1, 999999)
        self.view_w_spin.setPrefix("W:")
        self.view_w_spin.setValue(640)
        self.view_w_spin.valueChanged.connect(self.on_view_property_changed)
        coord_row2.addWidget(self.view_w_spin)

        self.view_h_spin = QSpinBox()
        self.view_h_spin.setRange(1, 999999)
        self.view_h_spin.setPrefix("H:")
        self.view_h_spin.setValue(480)
        self.view_h_spin.valueChanged.connect(self.on_view_property_changed)
        coord_row2.addWidget(self.view_h_spin)
        layout.addLayout(coord_row2)

        layout.addWidget(QLabel("Follow object (name or ID):"))
        self.view_follow_edit = QLineEdit()
        self.view_follow_edit.textChanged.connect(self.on_view_property_changed)
        layout.addWidget(self.view_follow_edit)

        return group

    def update_views_list(self):
        """Refresh views list widget from self.views."""
        self.views_list.clear()
        for i, view in enumerate(self.views):
            name = view.get("name", f"View {i}")
            enabled_flag = "[On]" if view.get("enabled", True) else "[Off]"
            item = QListWidgetItem(f"{enabled_flag} {name}")
            item.setData(Qt.UserRole, i)
            self.views_list.addItem(item)

    def on_views_enabled_changed(self, enabled: bool):
        self.resource_data["views_enabled"] = enabled
        self._dirty = True

    def add_view(self):
        new_view = RoomDataManager.create_default_view(len(self.views))
        self.views.append(new_view)
        self.resource_data["views"] = self.views
        self.update_views_list()
        self._dirty = True

    def remove_selected_view(self):
        row = self.views_list.currentRow()
        if row < 0 or row >= len(self.views):
            return
        del self.views[row]
        self.resource_data["views"] = self.views
        self.update_views_list()
        self.clear_view_edit_fields()
        self._dirty = True

    def on_view_selected(self):
        row = self.views_list.currentRow()
        if row < 0 or row >= len(self.views):
            self.clear_view_edit_fields()
            return
        view = self.views[row]
        self.view_x_spin.blockSignals(True)
        self.view_y_spin.blockSignals(True)
        self.view_w_spin.blockSignals(True)
        self.view_h_spin.blockSignals(True)
        self.view_follow_edit.blockSignals(True)

        self.view_x_spin.setValue(view.get("x", 0))
        self.view_y_spin.setValue(view.get("y", 0))
        self.view_w_spin.setValue(view.get("w", 640))
        self.view_h_spin.setValue(view.get("h", 480))
        self.view_follow_edit.setText(view.get("follow_object", ""))

        self.view_x_spin.blockSignals(False)
        self.view_y_spin.blockSignals(False)
        self.view_w_spin.blockSignals(False)
        self.view_h_spin.blockSignals(False)
        self.view_follow_edit.blockSignals(False)

    def clear_view_edit_fields(self):
        self.view_x_spin.blockSignals(True)
        self.view_y_spin.blockSignals(True)
        self.view_w_spin.blockSignals(True)
        self.view_h_spin.blockSignals(True)
        self.view_follow_edit.blockSignals(True)

        self.view_x_spin.setValue(0)
        self.view_y_spin.setValue(0)
        self.view_w_spin.setValue(640)
        self.view_h_spin.setValue(480)
        self.view_follow_edit.setText("")

        self.view_x_spin.blockSignals(False)
        self.view_y_spin.blockSignals(False)
        self.view_w_spin.blockSignals(False)
        self.view_h_spin.blockSignals(False)
        self.view_follow_edit.blockSignals(False)

    def on_view_property_changed(self):
        row = self.views_list.currentRow()
        if row < 0 or row >= len(self.views):
            return
        view = self.views[row]
        view["x"] = self.view_x_spin.value()
        view["y"] = self.view_y_spin.value()
        view["w"] = self.view_w_spin.value()
        view["h"] = self.view_h_spin.value()
        view["follow_object"] = self.view_follow_edit.text()
        self.resource_data["views"] = self.views
        self._dirty = True

    # -------------------------------------------------------------------------
    # Instance Order Tab
    # -------------------------------------------------------------------------

    def create_instance_order_group(self) -> QGroupBox:
        group = QGroupBox("Instance Order")
        group.setStyleSheet("""
            QGroupBox {
                font-weight: bold;
                border: 1px solid #404060;
                border-radius: 4px;
                margin-top: 10px;
                padding-top: 10px;
            }
            QGroupBox::title {
                subcontrol-origin: margin;
                left: 10px;
                padding: 0 5px;
            }
        """)
        layout = QVBoxLayout(group)
        layout.setContentsMargins(8, 20, 8, 8)
        layout.setSpacing(6)

        self.instance_order_list = QListWidget()
        self.instance_order_list.setSelectionMode(QListWidget.SingleSelection)
        layout.addWidget(self.instance_order_list)

        btn_row = QHBoxLayout()
        up_btn = QPushButton("Move Up")
        up_btn.clicked.connect(self.move_instance_up)
        btn_row.addWidget(up_btn)

        down_btn = QPushButton("Move Down")
        down_btn.clicked.connect(self.move_instance_down)
        btn_row.addWidget(down_btn)
        layout.addLayout(btn_row)

        return group

    def update_instance_order_list(self):
        self.instance_order_list.clear()
        instances = self.resource_data.get("instances", [])
        for i, inst in enumerate(instances):
            name = inst.get("object_name", "Unknown")
            x = inst.get("x", 0)
            y = inst.get("y", 0)
            item = QListWidgetItem(f"{i}: {name} @ ({x},{y})")
            item.setData(Qt.UserRole, i)
            self.instance_order_list.addItem(item)

    def move_instance_up(self):
        row = self.instance_order_list.currentRow()
        instances = self.resource_data.get("instances", [])
        if row <= 0 or row >= len(instances):
            return
        instances[row - 1], instances[row] = instances[row], instances[row - 1]
        # Reassign order indices
        for i, inst in enumerate(instances):
            inst["order"] = i
        self.resource_data["instances"] = instances
        self._dirty = True
        self.update_instances_list()
        self.update_instance_order_list()
        self.instance_order_list.setCurrentRow(row - 1)

    def move_instance_down(self):
        row = self.instance_order_list.currentRow()
        instances = self.resource_data.get("instances", [])
        if row < 0 or row >= len(instances) - 1:
            return
        instances[row + 1], instances[row] = instances[row], instances[row + 1]
        for i, inst in enumerate(instances):
            inst["order"] = i
        self.resource_data["instances"] = instances
        self._dirty = True
        self.update_instances_list()
        self.update_instance_order_list()
        self.instance_order_list.setCurrentRow(row + 1)

    # -------------------------------------------------------------------------
    # Objects / Instances handlers
    # -------------------------------------------------------------------------

    def on_object_selected(self, item: QListWidgetItem):
        """Set object ID for placement."""
        obj_id = item.data(Qt.UserRole)
        self.selected_object_id = obj_id

        obj_data = self.app.project_manager.get_runtime_resource("objects", obj_id)
        if obj_data:
            sprite_name = obj_data.get("sprite", "")
            if sprite_name:
                self.object_info_label.setText(
                    f"Object: {obj_data.get('name', 'Unknown')}\nSprite: {sprite_name}"
                )
            else:
                self.object_info_label.setText(
                    f"Object: {obj_data.get('name', 'Unknown')}\nNo sprite assigned."
                )

        if self.canvas:
            self.canvas.selected_object_id = obj_id
            self.canvas.update()

    def on_objects_list_context_menu(self, pos):
        item = self.objects_list.itemAt(pos)
        if not item:
            return
        obj_id = item.data(Qt.UserRole)

        menu = QMenu(self)
        obj_data = self.app.project_manager.get_runtime_resource("objects", obj_id)
        if obj_data:
            props_act = menu.addAction("Properties...")
            props_act.triggered.connect(lambda: self.show_object_properties(obj_id))

            open_act = menu.addAction("Open in Object Editor")
            open_act.triggered.connect(lambda: self.open_object_editor(obj_id))

        menu.exec(self.objects_list.mapToGlobal(pos))

    def on_instances_list_context_menu(self, pos):
        item = self.instances_list.itemAt(pos)
        if not item:
            return

        menu = QMenu(self)
        inst_index = item.data(Qt.UserRole)
        instances = self.resource_data.get("instances", [])
        if inst_index >= len(instances):
            return

        props_act = menu.addAction("Properties...")
        props_act.triggered.connect(lambda: self.show_instance_properties(inst_index))

        dup_act = menu.addAction("Duplicate")
        dup_act.triggered.connect(lambda: self.duplicate_instance(inst_index))

        menu.addSeparator()
        rem_act = menu.addAction("Remove")
        rem_act.triggered.connect(lambda: self.remove_instance_at_index(inst_index))

        menu.exec(self.instances_list.mapToGlobal(pos))

    def on_instance_list_selected(self, item: QListWidgetItem):
        inst_index = item.data(Qt.UserRole)
        self.selected_instance_index = inst_index
        if self.canvas:
            self.canvas.selected_instance = inst_index
            self.canvas.update()
        self.remove_instance_btn.setEnabled(True)
        self.duplicate_instance_btn.setEnabled(True)

    def update_instances_list(self):
        self.instances_list.clear()
        instances = self.resource_data.get("instances", [])
        for i, inst in enumerate(instances):
            name = inst.get("object_name", "Unknown")
            x = inst.get("x", 0)
            y = inst.get("y", 0)
            order = inst.get("order", i)
            item = QListWidgetItem(f"{name} @ ({x},{y}) [Order: {order}]")
            item.setData(Qt.UserRole, i)
            self.instances_list.addItem(item)
        self.update_instance_order_list()

    def duplicate_selected_instance(self):
        if self.selected_instance_index < 0:
            return
        self.duplicate_instance(self.selected_instance_index)

    def duplicate_instance(self, inst_index: int):
        instances = self.resource_data.get("instances", [])
        if inst_index < 0 or inst_index >= len(instances):
            return
        original = instances[inst_index]
        new_inst = dict(original)
        new_inst["id"] = f"instance_{len(instances)}"
        new_inst["x"] = original.get("x", 0) + 32
        new_inst["y"] = original.get("y", 0) + 32
        new_inst["order"] = len(instances)
        instances.append(new_inst)
        self.resource_data["instances"] = instances
        self._dirty = True
        self.update_instances_list()
        if self.canvas:
            self.canvas.update()

    def remove_instance(self):
        if self.selected_instance_index < 0:
            return
        self.remove_instance_at_index(self.selected_instance_index)

    def remove_instance_at_index(self, inst_index: int):
        instances = self.resource_data.get("instances", [])
        if inst_index < 0 or inst_index >= len(instances):
            return
        instances.pop(inst_index)
        # Reassign order indices
        for i, inst in enumerate(instances):
            inst["order"] = i
        self.resource_data["instances"] = instances
        self._dirty = True
        self.update_instances_list()
        self.selected_instance_index = -1
        self.remove_instance_btn.setEnabled(False)
        self.duplicate_instance_btn.setEnabled(False)
        if self.canvas:
            self.canvas.selected_instance = -1
            self.canvas.update()

    # -------------------------------------------------------------------------
    # Background handlers
    # -------------------------------------------------------------------------

    def on_background_selected(self):
        idx = self.background_combo.currentIndex()
        bg_id = self.background_combo.itemData(idx)
        if not bg_id:
            self.resource_data["background_id"] = None
            self.resource_data["background_name"] = None
        else:
            bg_data = self.app.project_manager.get_runtime_resource("backgrounds", bg_id)
            if not bg_data:
                bg_data = self.app.project_manager.get_runtime_resource("sprites", bg_id)
            if bg_data:
                self.resource_data["background_id"] = bg_id
                self.resource_data["background_name"] = bg_data.get("name", "")
        self._dirty = True
        if self.canvas:
            self.canvas.update()

    def on_bg_color_clicked(self):
        current_color = self.resource_data.get("background_color", "#000000")
        if isinstance(current_color, str):
            color = QColor(current_color)
        else:
            color = QColor(0, 0, 0)
        color = QColorDialog.getColor(color, self, "Select Background Color")
        if color.isValid():
            hex_color = color.name()
            self.resource_data["background_color"] = hex_color
            self.bg_color_btn.setStyleSheet(f"background-color: {hex_color}; border: 1px solid #606060;")
            self._dirty = True
            if self.canvas:
                self.canvas.update()

    def on_background_settings_changed(self):
        self.resource_data["bg_hspeed"] = self.bg_hspeed_spin.value()
        self.resource_data["bg_vspeed"] = self.bg_vspeed_spin.value()
        self.resource_data["bg_stretch"] = self.bg_stretch_check.isChecked()
        self.resource_data["bg_tile_h"] = self.bg_tile_h_check.isChecked()
        self.resource_data["bg_tile_v"] = self.bg_tile_v_check.isChecked()
        self.resource_data["bg_repeat_h"] = self.bg_repeat_h_spin.value()
        self.resource_data["bg_repeat_v"] = self.bg_repeat_v_spin.value()
        self._dirty = True
        if self.canvas:
            self.canvas.update()

    # -------------------------------------------------------------------------
    # Settings / grid / zoom handlers
    # -------------------------------------------------------------------------

    def on_settings_changed(self):
        self.resource_data["name"] = self.title_edit.text()
        self.resource_data["room_speed"] = self.room_speed_spin.value()
        self.resource_data["room_hspeed"] = self.room_hspeed_spin.value()
        self.resource_data["room_vspeed"] = self.room_vspeed_spin.value()
        self._dirty = True

    def on_size_changed(self):
        self.resource_data["width"] = self.width_spin.value()
        self.resource_data["height"] = self.height_spin.value()
        self._dirty = True
        if self.canvas:
            self.canvas.update()

    def on_grid_changed(self):
        self.resource_data["grid_size_x"] = self.grid_x_spin.value()
        self.resource_data["grid_size_y"] = self.grid_y_spin.value()
        if self.is_3d_mode:
            self.resource_data["grid_size_z"] = self.grid_z_spin.value()
        self._dirty = True
        if self.canvas:
            self.canvas.grid_size_x = self.grid_x_spin.value()
            self.canvas.grid_size_y = self.grid_y_spin.value()
            self.canvas.update()

    def on_snap_changed(self, snap: bool):
        self.resource_data["snap_to_grid"] = snap
        if self.canvas:
            self.canvas.snap_to_grid = snap
        self._dirty = True

    def on_show_grid_changed(self, show: bool):
        self.resource_data["show_grid"] = show
        if self.canvas:
            self.canvas.show_grid = show
            self.canvas.update()
        self._dirty = True

    def on_3d_mode_changed(self, enabled: bool):
        """
        Placeholder only for now. No 3D rendering here yet.
        """
        self.is_3d_mode = enabled
        self.resource_data["is_3d"] = enabled
        self.grid_z_label.setVisible(enabled)
        self.grid_z_spin.setVisible(enabled)
        self._dirty = True
        if self.canvas:
            self.canvas.is_3d = enabled
            self.canvas.update()

    def on_zoom_changed(self, value: float):
        if self.canvas:
            self.canvas.zoom = float(value)
            self.canvas.update()

    def on_reset_zoom_clicked(self):
        self.zoom_spin.setValue(1.0)

    # -------------------------------------------------------------------------
    # Object / instance properties helpers
    # -------------------------------------------------------------------------

    def show_object_properties(self, obj_id: str):
        obj_data = self.app.project_manager.get_runtime_resource("objects", obj_id)
        if not obj_data:
            return
        sprite = obj_data.get("sprite", "None")
        solid = obj_data.get("solid", False)
        QMessageBox.information(
            self,
            "Object Properties",
            f"Name: {obj_data.get('name', 'Unknown')}\n"
            f"Sprite: {sprite}\n"
            f"Solid: {solid}"
        )

    def open_object_editor(self, obj_id: str):
        if hasattr(self.app, "main_window") and self.app.main_window:
            self.app.main_window.open_resource("objects", obj_id)

    def show_instance_properties(self, inst_index: int):
        instances = self.resource_data.get("instances", [])
        if inst_index < 0 or inst_index >= len(instances):
            return
        inst = instances[inst_index]
        QMessageBox.information(
            self,
            "Instance Properties",
            f"Object: {inst.get('object_name', 'Unknown')}\n"
            f"Position: ({inst.get('x', 0)}, {inst.get('y', 0)}, {inst.get('z', 0)})\n"
            f"Order: {inst.get('order', inst_index)}"
        )

    # -------------------------------------------------------------------------
    # Sprite drawing info (size + origin) – hook for ResourceManager
    # -------------------------------------------------------------------------

    def get_instance_draw_info(self, instance: Dict[str, Any]) -> Dict[str, Any]:
        """
        Returns drawing info for an instance: width, height, origin_x, origin_y.

        This is where you wire to your real Sprite resource format.
        Assumptions:
        - instance["object_id"] is a valid object resource id.
        - object_data has a 'sprite' field with sprite id/name.
        - sprite_data has width/height + origin_x/origin_y.
        """
        # Default fallback
        default_size = 32
        info = {
            "width": default_size,
            "height": default_size,
            "origin_x": default_size // 2,
            "origin_y": default_size // 2
        }

        try:
            obj_id = instance.get("object_id")
            if not obj_id or not hasattr(self.app, "project_manager"):
                return info

            obj_data = self.app.project_manager.get_runtime_resource("objects", obj_id)
            if not obj_data:
                return info

            sprite_id = obj_data.get("sprite")
            if not sprite_id:
                return info

            # Try 'sprites' first, then 'backgrounds'
            sprite_data = self.app.project_manager.get_runtime_resource("sprites", sprite_id)
            if not sprite_data:
                sprite_data = self.app.project_manager.get_runtime_resource("backgrounds", sprite_id)
            if not sprite_data:
                return info

            width = int(sprite_data.get("width", default_size))
            height = int(sprite_data.get("height", default_size))

            origin_x = sprite_data.get("origin_x", width // 2)
            origin_y = sprite_data.get("origin_y", height // 2)

            info["width"] = width
            info["height"] = height
            info["origin_x"] = int(origin_x)
            info["origin_y"] = int(origin_y)
            return info

        except Exception as e:
            debug(f"RoomEditor.get_instance_draw_info error: {e}")
            return info

    # -------------------------------------------------------------------------
    # EditorInterface implementation
    # -------------------------------------------------------------------------

    def open_resource(self, resource_data: Dict) -> bool:
        try:
            self.resource_data = resource_data
            self._dirty = False

            # Name
            self.title_edit.setText(resource_data.get("name", ""))

            # Size
            width = int(resource_data.get("width", 1024))
            height = int(resource_data.get("height", 768))
            self.width_spin.setValue(width)
            self.height_spin.setValue(height)

            # Room speed
            self.room_speed_spin.setValue(resource_data.get("room_speed", 1.0))
            self.room_hspeed_spin.setValue(resource_data.get("room_hspeed", 0.0))
            self.room_vspeed_spin.setValue(resource_data.get("room_vspeed", 0.0))

            # Grid
            grid_x = resource_data.get("grid_size_x", resource_data.get("grid_size", 32))
            grid_y = resource_data.get("grid_size_y", resource_data.get("grid_size", 32))
            grid_z = resource_data.get("grid_size_z", 32)
            self.grid_x_spin.setValue(int(grid_x))
            self.grid_y_spin.setValue(int(grid_y))
            self.grid_z_spin.setValue(int(grid_z))
            self.snap_check.setChecked(resource_data.get("snap_to_grid", True))
            self.show_grid_check.setChecked(resource_data.get("show_grid", True))

            if self.canvas:
                self.canvas.grid_size_x = int(grid_x)
                self.canvas.grid_size_y = int(grid_y)
                self.canvas.snap_to_grid = self.snap_check.isChecked()
                self.canvas.show_grid = self.show_grid_check.isChecked()
                self.canvas.update()

            # 2D/3D
            self.is_3d_mode = resource_data.get("is_3d", False)
            self.mode_3d_check.setChecked(self.is_3d_mode)

            # Background
            bg_name = resource_data.get("background_name")
            if bg_name:
                idx = self.background_combo.findText(bg_name)
                if idx >= 0:
                    self.background_combo.setCurrentIndex(idx)

            bg_color = resource_data.get("background_color", "#000000")
            if isinstance(bg_color, str):
                self.bg_color_btn.setStyleSheet(f"background-color: {bg_color}; border: 1px solid #606060;")

            self.bg_hspeed_spin.setValue(resource_data.get("bg_hspeed", 0.0))
            self.bg_vspeed_spin.setValue(resource_data.get("bg_vspeed", 0.0))
            self.bg_stretch_check.setChecked(resource_data.get("bg_stretch", False))
            self.bg_tile_h_check.setChecked(resource_data.get("bg_tile_h", False))
            self.bg_tile_v_check.setChecked(resource_data.get("bg_tile_v", False))
            self.bg_repeat_h_spin.setValue(resource_data.get("bg_repeat_h", 1))
            self.bg_repeat_v_spin.setValue(resource_data.get("bg_repeat_v", 1))

            # Instances
            self.update_instances_list()

            # Views
            self.views = resource_data.get("views", [])
            self.resource_data["views"] = self.views
            self.views_enabled_check.setChecked(resource_data.get("views_enabled", bool(self.views)))
            self.update_views_list()

            if self.canvas:
                self.canvas.update()

            return True
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to load room: {e}")
            return False

    def load_resource_data(self):
        if self.resource_data:
            self.open_resource(self.resource_data)

    def save_resource(self) -> bool:
        try:
            if hasattr(self.app, "resource_manager") and self.app.resource_manager:
                if self.app.resource_manager.save_resource("rooms", self.resource_data):
                    self._dirty = False
                    return True
            return False
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to save room: {e}")
            return False

    def close_editor(self) -> bool:
        return True

    def get_editor_widget(self) -> QWidget:
        return self

    def is_dirty(self) -> bool:
        return self._dirty

    def get_resource_type(self) -> str:
        return "rooms"

    def get_resource_id(self) -> Optional[str]:
        return self.resource_data.get("id") if self.resource_data else None

    def get_resource_name(self) -> Optional[str]:
        return self.resource_data.get("name") if self.resource_data else None

