"""
ImageEditor compatibility shim
Imports the actual ImageEditor from core
"""
from core.app import *
from ui.main_window import MainWindow as ImageEditor

__all__ = ['ImageEditor']
