# selection_helpers.py
# Helper functions for smooth contour extraction

import numpy as np
from PySide6.QtGui import QPainterPath
from PySide6.QtCore import QPointF

def mask_to_smooth_qpaths(mask, scale=1.0, offset_x=0, offset_y=0):
    """
    Convert boolean mask to smooth QPainterPath contours using skimage.
    Returns list of QPainterPath objects for smooth marching ants.
    """
    paths = []
    
    try:
        from skimage import measure
        contours = measure.find_contours(mask.astype(float), 0.5)
        
        for contour in contours:
            if len(contour) < 3:
                continue
                
            path = QPainterPath()
            # contour is (N, 2) with (row, col) format
            row, col = contour[0]
            screen_x = col * scale + offset_x
            screen_y = row * scale + offset_y
            path.moveTo(QPointF(screen_x, screen_y))
            
            for point in contour[1:]:
                row, col = point
                screen_x = col * scale + offset_x
                screen_y = row * scale + offset_y
                path.lineTo(QPointF(screen_x, screen_y))
            
            path.closeSubpath()
            paths.append(path)
        
        return paths
        
    except ImportError:
        # Fallback to OpenCV if skimage not available
        try:
            import cv2
            contours, _ = cv2.findContours(
                (mask.astype('uint8') * 255), 
                cv2.RETR_EXTERNAL, 
                cv2.CHAIN_APPROX_SIMPLE
            )
            for cnt in contours:
                if cnt is None or len(cnt) == 0:
                    continue
                cnt = cnt.squeeze()
                if len(cnt.shape) == 1:
                    continue
                p = QPainterPath()
                x0, y0 = cnt[0]
                p.moveTo(QPointF(x0 * scale + offset_x, y0 * scale + offset_y))
                for (x, y) in cnt[1:]:
                    p.lineTo(QPointF(x * scale + offset_x, y * scale + offset_y))
                p.closeSubpath()
                paths.append(p)
            return paths
        except Exception:
            pass
    
    # Final fallback: simple bounding box
    if np.any(mask):
        h, w = mask.shape
        coords = np.where(mask)
        y1, y2 = coords[0].min(), coords[0].max()
        x1, x2 = coords[1].min(), coords[1].max()
        
        path = QPainterPath()
        path.moveTo(QPointF(x1 * scale + offset_x, y1 * scale + offset_y))
        path.lineTo(QPointF(x2 * scale + offset_x, y1 * scale + offset_y))
        path.lineTo(QPointF(x2 * scale + offset_x, y2 * scale + offset_y))
        path.lineTo(QPointF(x1 * scale + offset_x, y2 * scale + offset_y))
        path.closeSubpath()
        paths.append(path)
    
    return paths

# Backwards compatibility
mask_to_qpaths = mask_to_smooth_qpaths