"""
API Key Input Dialog for Gemini
"""

from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit, 
    QPushButton, QDialogButtonBox, QTextEdit, QMessageBox
)
from PySide6.QtCore import Qt
from PySide6.QtGui import QFont


class APIKeyDialog(QDialog):
    """Dialog for entering Gemini API key."""
    
    def __init__(self, parent=None, current_key: str = ""):
        super().__init__(parent)
        self.setWindowTitle("Gemini API Key Required")
        self.setMinimumWidth(500)
        self.setModal(True)
        
        layout = QVBoxLayout(self)
        
        # Instructions
        instructions = QLabel(
            "To use AI features, you need a Gemini API key.\n\n"
            "How to get your API key:\n"
            "1. Visit: https://aistudio.google.com/app/apikey\n"
            "2. Sign in with your Google account\n"
            "3. Click 'Create API Key'\n"
            "4. Copy the key and paste it below\n\n"
            "Your API key will be saved locally for future use."
        )
        instructions.setWordWrap(True)
        instructions.setStyleSheet("padding: 10px; background: #f0f0f0; border-radius: 5px;")
        layout.addWidget(instructions)
        
        # API Key input
        key_label = QLabel("API Key:")
        layout.addWidget(key_label)
        
        self.key_edit = QLineEdit()
        self.key_edit.setPlaceholderText("Enter your Gemini API key here...")
        self.key_edit.setText(current_key)
        self.key_edit.setEchoMode(QLineEdit.Password)  # Hide key by default
        layout.addWidget(self.key_edit)
        
        # Show/Hide toggle
        toggle_layout = QHBoxLayout()
        toggle_layout.addStretch()
        self.show_key_btn = QPushButton("Show Key")
        self.show_key_btn.setCheckable(True)
        self.show_key_btn.clicked.connect(self.toggle_key_visibility)
        toggle_layout.addWidget(self.show_key_btn)
        layout.addLayout(toggle_layout)
        
        # Open link button
        link_layout = QHBoxLayout()
        link_layout.addStretch()
        open_link_btn = QPushButton("Open API Key Page")
        open_link_btn.clicked.connect(self.open_api_key_page)
        link_layout.addWidget(open_link_btn)
        layout.addLayout(link_layout)
        
        # Buttons
        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.accepted.connect(self.validate_and_accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)
        
        # Store result
        self.api_key = None
    
    def toggle_key_visibility(self, checked: bool):
        """Toggle between showing and hiding the API key."""
        if checked:
            self.key_edit.setEchoMode(QLineEdit.Normal)
            self.show_key_btn.setText("Hide Key")
        else:
            self.key_edit.setEchoMode(QLineEdit.Password)
            self.show_key_btn.setText("Show Key")
    
    def open_api_key_page(self):
        """Open the API key page in default browser."""
        from PySide6.QtGui import QDesktopServices
        from PySide6.QtCore import QUrl
        QDesktopServices.openUrl(QUrl("https://aistudio.google.com/app/apikey"))
    
    def validate_and_accept(self):
        """Validate API key format and accept."""
        key = self.key_edit.text().strip()
        
        if not key:
            QMessageBox.warning(self, "Invalid Key", "Please enter an API key.")
            return
        
        # Basic validation (Gemini keys are typically long alphanumeric strings)
        if len(key) < 20:
            QMessageBox.warning(self, "Invalid Key", 
                              "API key appears to be too short. Please check your key.")
            return
        
        self.api_key = key
        self.accept()
    
    def get_api_key(self) -> str:
        """Get the entered API key."""
        return self.api_key or ""

