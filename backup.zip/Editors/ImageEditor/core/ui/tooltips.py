from PySide6.QtWidgets import QLabel, QApplication
from PySide6.QtCore import Qt, QTimer, QPoint

class CustomTooltip(QLabel):
    def __init__(self, text, parent=None):
        super().__init__(text, parent, Qt.ToolTip)
        self.setWindowFlags(Qt.ToolTip)
        self.setStyleSheet("background: #222; color: #fff; border: 1px solid #888; padding: 4px; border-radius: 4px;")
        self.setAlignment(Qt.AlignCenter)
        self.adjustSize()

_tooltip_instance = None

def attach_tooltip(widget, text):
    def show_tooltip(event):
        global _tooltip_instance
        if _tooltip_instance:
            _tooltip_instance.hide()
            _tooltip_instance.deleteLater()
        _tooltip_instance = CustomTooltip(text)
        pos = widget.mapToGlobal(event.pos())
        _tooltip_instance.move(pos + QPoint(0, -_tooltip_instance.height() - 8))
        _tooltip_instance.show()
    def hide_tooltip(event):
        global _tooltip_instance
        if _tooltip_instance:
            _tooltip_instance.hide()
            _tooltip_instance.deleteLater()
            _tooltip_instance = None
    widget.enterEvent = show_tooltip
    widget.leaveEvent = hide_tooltip 