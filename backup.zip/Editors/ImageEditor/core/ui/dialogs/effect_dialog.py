"""
Unified Effect Dialog for Image Editor
Extracted from dialogs.py
"""

from PySide6.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QLabel, 
                               QPushButton, QComboBox, QCheckBox, QSlider, 
                               QSpinBox, QDoubleSpinBox, QColorDialog, QGroupBox,
                               QGridLayout, QScrollArea, QWidget, QFrame, QTabWidget,
                               QListWidget, QListWidgetItem, QLineEdit, QTextEdit, QFileDialog,
                               QRadioButton)
from PySide6.QtCore import Qt, QTimer, Signal
from PySide6.QtGui import QColor, QPixmap, QPainter, QPen, QBrush, QImage
import numpy as np
from PIL import Image
from core.state import state
from Core.Debug import debug
from ui.dialogs.parameter_widgets import (
    ParameterWidget, SliderWidget, DoubleSliderWidget, ColorPickerWidget,
    DropdownWidget, CheckboxWidget, TextBoxWidget, ColorListWidget
)
from ui.dialogs.preview_widgets import CheckerboardPreviewWidget

class UnifiedEffectDialog(QDialog):
    def __init__(self, effect_type, parent=None):
        super().__init__(parent)
        self.effect_type = effect_type
        self.parameters = {}
        self.frame_option = "current"
        self.selection_option = "entire"
        self.param_widgets = {}  # Initialize param_widgets
        self.preview_timer = QTimer()
        self.preview_timer.timeout.connect(self.update_preview)
        self.preview_timer.setSingleShot(True)
        self.preview_image = None
        
        # Animation mode
        self.animation_mode = "static"  # or "animated"
        self.animation_start_values = {}
        self.animation_end_values = {}
        
        # Get current frame info from parent (Image Editor)
        self.current_frame_num = 1
        self.total_frames = 1
        self.canvas_width = 256
        self.canvas_height = 256
        self.has_selection = False
        self.selection_bounds = None
        self._get_editor_state()
        
        self.setup_ui()
    
    def _get_editor_state(self):
        """Get current state from the Image Editor."""
        try:
            from core.state import state
            if hasattr(state, 'layer_manager'):
                lm = state.layer_manager
                self.current_frame_num = lm.current_frame + 1  # Display as 1-based
                layer = lm.get_current_layer()
                if layer:
                    self.total_frames = len(layer.frames)
                self.canvas_width = state.width
                self.canvas_height = state.height
            
            # Check for selection
            if hasattr(state, 'selection_manager'):
                self.has_selection = state.selection_manager.has_selection()
                if self.has_selection:
                    self.selection_bounds = state.selection_manager.get_selection_bounds()
        except Exception as e:
            print(f"Could not get editor state: {e}")
    
    def _generate_summary(self):
        """Generate simple summary of what will happen."""
        summary_lines = []
        
        # Frame info
        if self.frame_option == "current":
            summary_lines.append(f"• Apply to Frame {self.current_frame_num} only")
        elif self.frame_option == "all":
            summary_lines.append(f"• Apply to all {self.total_frames} frames")
        elif self.frame_option == "create_frames":
            num_frames = self.frame_count_spinbox.value()
            summary_lines.append(f"• Create {num_frames} new animated frames")
        
        # Area info
        if self.selection_option == "entire":
            summary_lines.append(f"• Target: Entire image ({self.canvas_width}×{self.canvas_height})")
        else:
            if self.has_selection and self.selection_bounds:
                x, y, w, h = self.selection_bounds
                summary_lines.append(f"• Target: Selected area ({w}×{h})")
            else:
                summary_lines.append(f"• Target: Selected area (no selection)")
        
        # Mode info
        merge_mode = self.get_merge_replace_mode()
        if merge_mode == "replace":
            summary_lines.append("• Mode: Replace (clear frame first)")
        else:
            summary_lines.append("• Mode: Blend with existing content")
        
        return "\n".join(summary_lines)
    
    def _update_summary(self):
        """Update the summary text box."""
        if hasattr(self, 'summary_text'):
            summary = self._generate_summary()
            self.summary_text.setText(summary)
        
        # Show/hide frame navigation based on frame option
        if hasattr(self, 'frame_nav_widget'):
            if self.frame_option == "create_frames" and hasattr(self, 'frame_count_spinbox'):
                num_frames = self.frame_count_spinbox.value()
                self.total_preview_frames = num_frames
                self.current_preview_frame = 0
                self.frame_nav_widget.setVisible(num_frames > 1)
                self.preview_frame_label.setText(f"Frame 1 / {num_frames}")
                # Enable/disable navigation buttons
                self.prev_frame_btn.setEnabled(False)
                self.next_frame_btn.setEnabled(num_frames > 1)
            else:
                self.frame_nav_widget.setVisible(False)
                self.current_preview_frame = 0
                self.total_preview_frames = 1
    
    def _on_frame_current_toggled(self, checked):
        """Handle current frame radio button toggle."""
        if checked:
            self.frame_option = "current"
        self._update_summary()
    
    def _on_create_frames_toggled(self, checked):
        """Handle create frames radio button toggle."""
        if checked:
            self.frame_option = "create_frames"
        self._update_summary()
    
    def _on_frame_all_toggled(self, checked):
        """Handle all frames radio button toggle."""
        if checked:
            self.frame_option = "all"
        self._update_summary()
    
    
    def _on_area_entire_toggled(self, checked):
        """Handle entire area radio button toggle."""
        if checked:
            self.selection_option = "entire"
        self._update_summary()
    
    def _on_area_selection_toggled(self, checked):
        """Handle selection area radio button toggle."""
        if checked:
            self.selection_option = "selection"
        self._update_summary()
    
    def setup_ui(self):
        effect_config = EFFECT_REGISTRY.get(self.effect_type, {})
        self.setWindowTitle(effect_config.get('name', self.effect_type.title()))
        self.setModal(True)
        
        # Adjust dialog size based on effect type and complexity
        is_complex = self.effect_type in ['map_generator', 'texture_2d']
        if is_complex:
            self.resize(550, 750)
        else:
            self.resize(500, 650)
        
        # Create scroll area for content
        scroll_area = QScrollArea()
        scroll_widget = QWidget()
        layout = QVBoxLayout()
        layout.setSpacing(10)
        
        # Simple and intuitive options
        options_group = QGroupBox("Apply Effect To:")
        options_layout = QVBoxLayout()
        
        # Frame options - only show if frame_options is True in effect config
        effect_config = EFFECT_REGISTRY.get(self.effect_type, {})
        show_frame_options = effect_config.get('frame_options', True)
        
        if show_frame_options:
            # Frame options - simplified
            self.frame_radio_current = QRadioButton(f"Current frame only (Frame {self.current_frame_num})")
            self.frame_radio_current.setChecked(True)
            self.frame_radio_current.toggled.connect(self._on_frame_current_toggled)
            options_layout.addWidget(self.frame_radio_current)
            
            self.frame_radio_all = QRadioButton(f"All {self.total_frames} frames")
            self.frame_radio_all.toggled.connect(self._on_frame_all_toggled)
            options_layout.addWidget(self.frame_radio_all)
            
            # Create frames option
            create_layout = QHBoxLayout()
            self.frame_radio_create = QRadioButton("Create")
            self.frame_radio_create.toggled.connect(self._on_create_frames_toggled)
            create_layout.addWidget(self.frame_radio_create)
            self.frame_count_spinbox = QSpinBox()
            self.frame_count_spinbox.setRange(2, 50)
            self.frame_count_spinbox.setValue(4)
            self.frame_count_spinbox.valueChanged.connect(self._update_summary)
            create_layout.addWidget(self.frame_count_spinbox)
            create_layout.addWidget(QLabel("new frames"))
            create_layout.addStretch()
            options_layout.addLayout(create_layout)
        else:
            # For effects without frame options (like texture_2d with custom mode), create hidden widgets
            # so the code doesn't break, but they won't be visible
            self.frame_radio_current = QRadioButton(f"Current frame only (Frame {self.current_frame_num})")
            self.frame_radio_current.setChecked(True)
            self.frame_radio_current.setVisible(False)
            self.frame_radio_all = QRadioButton(f"All {self.total_frames} frames")
            self.frame_radio_all.setVisible(False)
            self.frame_radio_create = QRadioButton("Create")
            self.frame_radio_create.setVisible(False)
            self.frame_count_spinbox = QSpinBox()
            self.frame_count_spinbox.setRange(2, 50)
            self.frame_count_spinbox.setValue(4)
            self.frame_count_spinbox.setVisible(False)
            # Set frame_option to "current" by default for effects without frame options
            self.frame_option = "current"
        
        options_layout.addSpacing(10)
        
        # Area options
        if self.has_selection and self.selection_bounds:
            x, y, w, h = self.selection_bounds
            selection_text = f"Selected area ({w}×{h})"
        else:
            selection_text = "Selected area (no selection)"
        
        self.area_radio_entire = QRadioButton(f"Entire image ({self.canvas_width}×{self.canvas_height})")
        self.area_radio_entire.setChecked(True)
        self.area_radio_entire.toggled.connect(self._on_area_entire_toggled)
        options_layout.addWidget(self.area_radio_entire)
        
        self.area_radio_selection = QRadioButton(selection_text)
        self.area_radio_selection.toggled.connect(self._on_area_selection_toggled)
        options_layout.addWidget(self.area_radio_selection)
        
        options_layout.addSpacing(10)
        
        # Mode options - simplified
        self.replace_radio = QRadioButton("Replace (clear frame first)")
        self.replace_radio.setChecked(True)
        self.replace_radio.toggled.connect(self._update_summary)
        options_layout.addWidget(self.replace_radio)
        
        self.merge_radio = QRadioButton("Blend with existing content")
        self.merge_radio.toggled.connect(self._update_summary)
        options_layout.addWidget(self.merge_radio)
        
        options_group.setLayout(options_layout)
        layout.addWidget(options_group)
        
        # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        # EFFECT PROPERTIES Section (effect-specific parameters)
        # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        # Effect parameters (only if the effect has parameters)
        if effect_config.get('parameters'):
            params_group = QGroupBox("Parameters:")
            params_layout = QVBoxLayout()
            
            for param_config in effect_config['parameters']:
                # Handle separator
                if param_config.get('type') == 'separator':
                    from PySide6.QtWidgets import QFrame
                    separator = QFrame()
                    separator.setFrameShape(QFrame.Shape.HLine)
                    separator.setFrameShadow(QFrame.Shadow.Sunken)
                    params_layout.addWidget(separator)
                    continue
                
                widget = self.create_parameter_widget(param_config)
                if widget:
                    self.param_widgets[param_config['name']] = widget
                    widget.value_changed.connect(self.on_parameter_changed)
                    params_layout.addWidget(widget)
            
            params_group.setLayout(params_layout)
            layout.addWidget(params_group)
            
            # Advanced parameters (collapsible, hidden by default)
            if effect_config.get('advanced_parameters'):
                # Create collapsible advanced options section
                advanced_toggle_button = QPushButton("▼ Advanced Options")
                advanced_toggle_button.setCheckable(True)
                advanced_toggle_button.setChecked(False)
                advanced_toggle_button.clicked.connect(
                    lambda checked: self.toggle_advanced_options(checked, advanced_toggle_button)
                )
                layout.addWidget(advanced_toggle_button)
                
                # Create advanced parameters group (hidden by default)
                advanced_group = QGroupBox()
                advanced_layout = QVBoxLayout()
                
                for param_config in effect_config['advanced_parameters']:
                    widget = self.create_parameter_widget(param_config)
                    if widget:
                        self.param_widgets[param_config['name']] = widget
                        widget.value_changed.connect(self.on_parameter_changed)
                        advanced_layout.addWidget(widget)
                
                advanced_group.setLayout(advanced_layout)
                advanced_group.setVisible(False)
                self.advanced_options_group = advanced_group  # Store reference
                self.advanced_toggle_button = advanced_toggle_button  # Store reference
                layout.addWidget(advanced_group)
        
        # Set up conditional visibility for texture_2d effect
        if self.effect_type == 'texture_2d' and effect_config.get('parameters'):
            for param_config in effect_config['parameters']:
                if param_config['name'] in self.param_widgets:
                    widget = self.param_widgets[param_config['name']]
                    if param_config['name'] in ['custom_width', 'custom_height', 'custom_width_text', 'custom_height_text']:
                        widget.setVisible(False)  # Hidden by default
                    elif param_config['name'] in ['position_x', 'position_y', 'position_x_text', 'position_y_text']:
                        widget.setVisible(False)  # Hidden by default
                    elif param_config['name'] == 'animation_speed':
                        widget.setVisible(False)  # Hidden by default
                    
                    # Connect checkbox widgets to show/hide related parameters
                    if param_config['name'] == 'use_custom_size' and hasattr(widget, 'checkbox'):
                        widget.value_changed.connect(self._toggle_custom_size_visibility)
                    elif param_config['name'] == 'use_custom_position' and hasattr(widget, 'checkbox'):
                        widget.value_changed.connect(self._toggle_custom_position_visibility)
                    elif param_config['name'] == 'texture_mode':
                        # Connect texture_mode dropdown to show/hide animation_frames
                        widget.value_changed.connect(self._toggle_texture_mode_visibility)
                        # Set initial visibility
                        self._toggle_texture_mode_visibility(widget.get_value() if hasattr(widget, 'get_value') else 'Static')
                    elif param_config['name'] == 'animation_frames':
                        # Hide by default (shown when Animated is selected)
                        widget.setVisible(False)
                    elif param_config['name'] == 'animated' and hasattr(widget, 'checkbox'):
                        widget.value_changed.connect(self._toggle_animation_visibility)
        
        # Set up conditional visibility for image_enhancement effect
        if self.effect_type == 'image_enhancement' and effect_config.get('parameters'):
            # Hide size slider by default, show quality slider by default (quality is enabled by default)
            if 'upscale_size_factor' in self.param_widgets:
                self.param_widgets['upscale_size_factor'].setVisible(False)
            if 'upscale_quality_factor' in self.param_widgets:
                # Show quality slider if quality is enabled by default (default is True)
                self.param_widgets['upscale_quality_factor'].setVisible(True)
            
            # Connect checkboxes to show/hide sliders
            if 'enable_upscale_size' in self.param_widgets:
                self.param_widgets['enable_upscale_size'].value_changed.connect(self._toggle_upscale_size_visibility)
            if 'enable_upscale_quality' in self.param_widgets:
                self.param_widgets['enable_upscale_quality'].value_changed.connect(self._toggle_upscale_quality_visibility)
            
            params_group.setLayout(params_layout)
            layout.addWidget(params_group)
        
        # Add export options for LOD generation (outside texture_2d conditional)
        if self.effect_type == 'generate_lod':
            export_group = QGroupBox("Export Options:")
            export_layout = QVBoxLayout()
            
            # Export format selection
            format_layout = QHBoxLayout()
            format_layout.addWidget(QLabel("Export Format:"))
            self.export_format_combo = QComboBox()
            self.export_format_combo.addItems(["PNG", "JPG", "GIF", ".PgSprite"])
            format_layout.addWidget(self.export_format_combo)
            export_layout.addLayout(format_layout)
            
            # Export path
            path_layout = QHBoxLayout()
            path_layout.addWidget(QLabel("Export Path:"))
            self.export_path_edit = QLineEdit()
            self.export_path_edit.setPlaceholderText("Leave empty for default location")
            path_layout.addWidget(self.export_path_edit)
            browse_button = QPushButton("Browse...")
            browse_button.clicked.connect(self.browse_export_path)
            path_layout.addWidget(browse_button)
            export_layout.addLayout(path_layout)
            
            export_group.setLayout(export_layout)
            layout.addWidget(export_group)
        
        # Special handling for map generator with collapsible sections
        if self.effect_type == 'map_generator':
            # Elevation parameters section
            elevation_group = QGroupBox("Elevation Settings")
            elevation_group.setCheckable(True)
            elevation_group.setChecked(True)
            elevation_layout = QVBoxLayout()
            
            for param_config in effect_config.get('elevation_parameters', []):
                widget = self.create_parameter_widget(param_config)
                if widget:
                    self.param_widgets[param_config['name']] = widget
                    widget.value_changed.connect(self.on_parameter_changed)
                    elevation_layout.addWidget(widget)
            
            elevation_group.setLayout(elevation_layout)
            layout.addWidget(elevation_group)
            
            # Color parameters section
            color_group = QGroupBox("Color Settings")
            color_group.setCheckable(True)
            color_group.setChecked(True)
            color_layout = QVBoxLayout()
            
            for param_config in effect_config.get('color_parameters', []):
                widget = self.create_parameter_widget(param_config)
                if widget:
                    self.param_widgets[param_config['name']] = widget
                    widget.value_changed.connect(self.on_parameter_changed)
                    color_layout.addWidget(widget)
            
            color_group.setLayout(color_layout)
            layout.addWidget(color_group)
            
            # Animation parameters section
            animation_group = QGroupBox("Animation Settings")
            animation_group.setCheckable(True)
            animation_group.setChecked(False)
            animation_layout = QVBoxLayout()
            
            # Add enable animations checkbox first
            enable_animations_widget = self.create_parameter_widget({'type': 'checkbox', 'name': 'enable_animations', 'label': 'Enable Animations', 'default': False})
            if enable_animations_widget:
                self.param_widgets['enable_animations'] = enable_animations_widget
                enable_animations_widget.value_changed.connect(self.on_parameter_changed)
                animation_layout.addWidget(enable_animations_widget)
            
            # Add animation speed dropdown
            animation_speed_widget = self.create_parameter_widget({'type': 'dropdown', 'name': 'animation_speed', 'label': 'Animation Speed', 'options': ['Slow', 'Medium', 'Fast'], 'default': 'Medium'})
            if animation_speed_widget:
                self.param_widgets['animation_speed'] = animation_speed_widget
                animation_speed_widget.value_changed.connect(self.on_parameter_changed)
                animation_layout.addWidget(animation_speed_widget)
            
            # Add detected features info
            self.features_info = QLabel("Detected features will be shown here")
            self.features_info.setWordWrap(True)
            self.features_info.setStyleSheet("color: #888; font-style: italic;")
            animation_layout.addWidget(self.features_info)
            
            # Add animation checkboxes
            for param_config in effect_config.get('animation_parameters', []):
                widget = self.create_parameter_widget(param_config)
                if widget:
                    self.param_widgets[param_config['name']] = widget
                    widget.value_changed.connect(self.on_parameter_changed)
                    animation_layout.addWidget(widget)
            
            animation_group.setLayout(animation_layout)
            layout.addWidget(animation_group)
        
        # Simple summary
        summary_group = QGroupBox("What will happen:")
        summary_layout = QVBoxLayout()
        
        self.summary_text = QTextEdit()
        self.summary_text.setReadOnly(True)
        self.summary_text.setMaximumHeight(80)
        self.summary_text.setStyleSheet("QTextEdit { background: transparent; border: none; }")
        summary_layout.addWidget(self.summary_text)
        
        summary_group.setLayout(summary_layout)
        layout.addWidget(summary_group)
        
        # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        # PREVIEW Section
        # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        preview_group = QGroupBox("Preview:")
        preview_layout = QVBoxLayout()
        
        self.preview_label = CheckerboardPreviewWidget()
        self.preview_label.setMinimumSize(200, 150)
        preview_layout.addWidget(self.preview_label)
        
        # Frame navigation controls (for multi-frame effects)
        self.frame_nav_widget = QWidget()
        frame_nav_layout = QHBoxLayout()
        frame_nav_layout.setContentsMargins(0, 5, 0, 0)
        
        self.prev_frame_btn = QPushButton("◄")
        self.prev_frame_btn.setFixedSize(30, 25)
        self.prev_frame_btn.setToolTip("Previous frame preview")
        self.prev_frame_btn.clicked.connect(self.preview_prev_frame)
        frame_nav_layout.addWidget(self.prev_frame_btn)
        
        self.preview_frame_label = QLabel("Frame 1 / 1")
        self.preview_frame_label.setAlignment(Qt.AlignCenter)
        frame_nav_layout.addWidget(self.preview_frame_label)
        
        self.next_frame_btn = QPushButton("►")
        self.next_frame_btn.setFixedSize(30, 25)
        self.next_frame_btn.setToolTip("Next frame preview")
        self.next_frame_btn.clicked.connect(self.preview_next_frame)
        frame_nav_layout.addWidget(self.next_frame_btn)
        
        self.frame_nav_widget.setLayout(frame_nav_layout)
        preview_layout.addWidget(self.frame_nav_widget)
        
        # Initially hide frame navigation (only show when creating multiple frames)
        self.frame_nav_widget.setVisible(False)
        self.current_preview_frame = 0
        self.total_preview_frames = 1
        
        preview_group.setLayout(preview_layout)
        layout.addWidget(preview_group)
        
        # Generate initial summary
        self._update_summary()
        
        # Set up scroll area
        scroll_widget.setLayout(layout)
        scroll_area.setWidget(scroll_widget)
        scroll_area.setWidgetResizable(True)
        scroll_area.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        
        # Main layout
        main_layout = QVBoxLayout()
        main_layout.addWidget(scroll_area)
        
        # Buttons (outside scroll area)
        button_layout = QHBoxLayout()
        
        # Add Randomize button for effects with parameters
        if effect_config.get('parameters') or self.effect_type == 'map_generator':
            random_button = QPushButton("🎲 Randomize")
            random_button.setToolTip("Randomize all effect parameters (Ctrl+R)")
            random_button.setShortcut("Ctrl+R")
            random_button.clicked.connect(self.randomize_parameters)
            button_layout.addWidget(random_button)
        
        button_layout.addStretch()
        
        cancel_button = QPushButton("Cancel")
        cancel_button.setToolTip("Cancel without applying (Esc)")
        cancel_button.clicked.connect(self.reject)
        button_layout.addWidget(cancel_button)
        
        ok_button = QPushButton("Apply Effect")
        ok_button.setToolTip("Apply the effect (Enter)")
        ok_button.setDefault(True)  # Makes Enter key work
        ok_button.clicked.connect(self.accept)
        button_layout.addWidget(ok_button)
        
        main_layout.addLayout(button_layout)
        
        self.setLayout(main_layout)
    
    
    def get_frame_option(self):
        """Get the selected frame option."""
        if hasattr(self, 'frame_radio_current') and self.frame_radio_current.isChecked():
            return "current"
        elif hasattr(self, 'frame_radio_create') and self.frame_radio_create.isChecked():
            return "create_frames"  # Use the actual option name
        elif hasattr(self, 'frame_radio_all') and self.frame_radio_all.isChecked():
            return "all"
        else:
            return "current"
    
    def get_selection_option(self):
        """Get the selected area option."""
        if hasattr(self, 'area_radio_entire') and self.area_radio_entire.isChecked():
            return "entire"
        elif hasattr(self, 'area_radio_selection') and self.area_radio_selection.isChecked():
            return "selection"
        else:
            return "entire"
    
    def get_parameters(self):
        """Get effect parameters from widgets."""
        params = {}
        for name, widget in self.param_widgets.items():
            if hasattr(widget, 'get_value'):
                params[name] = widget.get_value()
        return params
    
    def get_frame_count(self):
        """Get the number of frames to create."""
        if hasattr(self, 'frame_count_spinbox'):
            return self.frame_count_spinbox.value()
        return 4
    
    def get_merge_replace_mode(self):
        """Get the merge/replace mode."""
        if hasattr(self, 'replace_radio') and self.replace_radio.isChecked():
            return "replace"
        else:
            return "merge"
    
    def get_export_options(self):
        """Get export options (for LOD generation)."""
        return {}  # Default empty for most effects
    
    def create_parameter_widget(self, param_config):
        param_type = param_config['type']
        
        if param_type == 'slider':
            return SliderWidget(param_config)
        elif param_type == 'double_slider':
            return DoubleSliderWidget(param_config)
        elif param_type == 'color_picker':
            return ColorPickerWidget(param_config)
        elif param_type == 'dropdown':
            return DropdownWidget(param_config)
        elif param_type == 'checkbox':
            return CheckboxWidget(param_config)
        elif param_type == 'textbox':
            return TextBoxWidget(param_config)
        elif param_type == 'color_list':
            return ColorListWidget(param_config)
        
        return None
    
    def create_advanced_section(self, section_name):
        if section_name == 'biome_settings':
            return self.create_biome_settings()
        elif section_name == 'animation_controls':
            return self.create_animation_controls()
        return None
    
    def create_biome_settings(self):
        group = QGroupBox("Biome Settings")
        layout = QGridLayout()
        
        # Temperature
        temp_label = QLabel("Temperature:")
        self.temp_slider = QSlider(Qt.Horizontal)
        self.temp_slider.setRange(0, 100)
        self.temp_slider.setValue(50)
        layout.addWidget(temp_label, 0, 0)
        layout.addWidget(self.temp_slider, 0, 1)
        
        # Humidity
        humidity_label = QLabel("Humidity:")
        self.humidity_slider = QSlider(Qt.Horizontal)
        self.humidity_slider.setRange(0, 100)
        self.humidity_slider.setValue(50)
        layout.addWidget(humidity_label, 1, 0)
        layout.addWidget(self.humidity_slider, 1, 1)
        
        group.setLayout(layout)
        return group
    
    def create_animation_controls(self):
        group = QGroupBox("Animation Controls")
        layout = QVBoxLayout()
        
        # Animate checkbox
        self.animate_checkbox = QCheckBox("Animate")
        layout.addWidget(self.animate_checkbox)
        
        # Frame count
        frame_label = QLabel("Frame Count:")
        self.frame_count_spin = QSpinBox()
        self.frame_count_spin.setRange(1, 20)
        self.frame_count_spin.setValue(5)
        layout.addWidget(frame_label)
        layout.addWidget(self.frame_count_spin)
        
        group.setLayout(layout)
        return group
    
    def on_frame_option_changed(self, text=None):
        """Handle frame option changes - updated for new radio button system."""
        if hasattr(self, 'frame_radio_current') and self.frame_radio_current.isChecked():
            self.frame_option = "current"
        elif hasattr(self, 'frame_radio_create') and self.frame_radio_create.isChecked():
            self.frame_option = "create_frames"
        elif hasattr(self, 'frame_radio_all') and self.frame_radio_all.isChecked():
            self.frame_option = "all"
        elif hasattr(self, 'frame_radio_range') and self.frame_radio_range.isChecked():
            self.frame_option = "range"
        else:
            self.frame_option = "current"  # Default fallback
        
        self._update_summary()
    
    def on_selection_option_changed(self, text=None):
        """Handle selection option changes - updated for new radio button system."""
        if hasattr(self, 'area_radio_entire') and self.area_radio_entire.isChecked():
            self.selection_option = "entire"
        elif hasattr(self, 'area_radio_selection') and self.area_radio_selection.isChecked():
            self.selection_option = "selection"
        else:
            self.selection_option = "entire"  # Default fallback
        
        self._update_summary()
    
    def _toggle_upscale_size_visibility(self, checked):
        """Toggle visibility of upscale size slider based on checkbox."""
        if 'upscale_size_factor' in self.param_widgets:
            self.param_widgets['upscale_size_factor'].setVisible(checked)
    
    def _toggle_upscale_quality_visibility(self, checked):
        """Toggle visibility of upscale quality slider based on checkbox."""
        if 'upscale_quality_factor' in self.param_widgets:
            self.param_widgets['upscale_quality_factor'].setVisible(checked)
    
    def get_frame_count(self):
        """Get the number of frames to animate over."""
        return self.frame_count_spinbox.value()
    
    def get_merge_replace_mode(self):
        """Get the merge/replace mode."""
        if self.merge_radio.isChecked():
            return "merge"
        else:
            return "replace"
    
    def on_parameter_changed(self):
        # Debounce preview updates
        self.preview_timer.start(100)
        
        # Update features info for map generator
        if self.effect_type == 'map_generator':
            self._update_features_info()
    
    def toggle_advanced_options(self, checked, button):
        """Toggle visibility of advanced options."""
        if hasattr(self, 'advanced_options_group'):
            self.advanced_options_group.setVisible(checked)
            if checked:
                button.setText("▲ Advanced Options")
            else:
                button.setText("▼ Advanced Options")
    
    def _update_features_info(self):
        """Update the features info display for map generator."""
        if not hasattr(self, 'features_info'):
            return
        
        try:
            # Get current parameters
            parameters = self.get_parameters()
            map_type = parameters.get('map_type', 'Minecraft')
            
            # Generate a preview map to detect features
            if hasattr(self, 'preview_image') and self.preview_image is not None:
                # Use the preview image to detect features
                from ui.main_window import MapAnimationSystem
                animation_system = MapAnimationSystem()
                available_animations = animation_system.get_available_animations(map_type, self.preview_image)
                
                if available_animations:
                    features_text = "Detected features:\n"
                    for animation, info in available_animations.items():
                        pixel_count = info['pixel_count']
                        features_text += f"• {info['name']}: {pixel_count:,} pixels\n"
                    self.features_info.setText(features_text)
                    self.features_info.setStyleSheet("color: #4CAF50; font-style: normal;")
                else:
                    self.features_info.setText("No animatable features detected in this map type.")
                    self.features_info.setStyleSheet("color: #FF9800; font-style: italic;")
            else:
                self.features_info.setText("Generate a preview to see detected features.")
                self.features_info.setStyleSheet("color: #888; font-style: italic;")
        except Exception as e:
            self.features_info.setText(f"Error detecting features: {str(e)}")
            self.features_info.setStyleSheet("color: #F44336; font-style: italic;")
    
    
    def preview_prev_frame(self):
        """Navigate to previous frame in preview."""
        if self.current_preview_frame > 0:
            self.current_preview_frame -= 1
            self.preview_frame_label.setText(f"Frame {self.current_preview_frame + 1} / {self.total_preview_frames}")
            # Update button states
            self.prev_frame_btn.setEnabled(self.current_preview_frame > 0)
            self.next_frame_btn.setEnabled(self.current_preview_frame < self.total_preview_frames - 1)
            # Update preview with new frame index
            self.update_preview()
    
    def preview_next_frame(self):
        """Navigate to next frame in preview."""
        if self.current_preview_frame < self.total_preview_frames - 1:
            self.current_preview_frame += 1
            self.preview_frame_label.setText(f"Frame {self.current_preview_frame + 1} / {self.total_preview_frames}")
            # Update button states
            self.prev_frame_btn.setEnabled(self.current_preview_frame > 0)
            self.next_frame_btn.setEnabled(self.current_preview_frame < self.total_preview_frames - 1)
            # Update preview with new frame index
            self.update_preview()
    
    def update_preview(self):
        """Update the preview with the current effect applied."""
        if self.preview_image is None:
            debug("DEBUG: update_preview called but preview_image is None")
            return
        
        try:
            debug(f"DEBUG: update_preview called for effect_type: {self.effect_type}")
            debug(f"DEBUG: preview_image shape: {self.preview_image.shape if hasattr(self.preview_image, 'shape') else 'No shape'}")
            
            # Get current parameters
            parameters = self.get_parameters()
            debug(f"DEBUG: parameters: {parameters}")
            
            # Apply effect to preview image with frame index
            processed_image = self._apply_effect_to_preview(self.preview_image, parameters, self.current_preview_frame)
            debug(f"DEBUG: processed_image shape: {processed_image.shape if processed_image is not None else 'None'}")
            
            # Convert to QPixmap and display
            if processed_image is not None:
                height, width = processed_image.shape[:2]
                bytes_per_line = 4 * width
                
                # Convert RGBA to QImage
                q_image = QImage(processed_image.data, width, height, bytes_per_line, QImage.Format_RGBA8888)
                pixmap = QPixmap.fromImage(q_image)
                
                # Scale to fit preview area
                scaled_pixmap = pixmap.scaled(200, 150, Qt.KeepAspectRatio, Qt.SmoothTransformation)
                self.preview_label.setPixmap(scaled_pixmap)
            else:
                debug("DEBUG: processed_image is None, setting error text")
                self.preview_label.setText("Preview Error")
                
        except Exception as e:
            debug(f"DEBUG: Exception in update_preview: {e}")
            import traceback
            traceback.print_exc()
            self.preview_label.setText(f"Preview Error: {str(e)}")
    
    def _prepare_preview_image(self, pil_img, max_preview_size=400):
        """
        Prepare image for preview by downscaling if necessary.
        This significantly speeds up preview rendering for large images.
        
        Args:
            pil_img: PIL Image to prepare
            max_preview_size: Maximum dimension for preview (default 400px)
            
        Returns:
            tuple: (prepared_pil_img, original_size, was_downscaled)
        """
        from PIL import Image
        
        original_size = pil_img.size
        
        # Downscale if image is larger than max_preview_size
        if max(original_size) > max_preview_size:
            scale = max_preview_size / max(original_size)
            preview_size = (int(original_size[0] * scale), int(original_size[1] * scale))
            preview_img = pil_img.resize(preview_size, Image.LANCZOS)
            return preview_img, original_size, True
        
        return pil_img, original_size, False
    
    def _apply_effect_to_preview(self, img, parameters, frame_idx=0):
        """Apply effect to preview image with frame index for animation."""
        from PIL import Image
        import numpy as np
        
        # Convert numpy array to PIL Image
        pil_img = Image.fromarray(img, mode='RGBA')
        
        if self.effect_type == 'invert':
            return self._apply_invert_effect(pil_img)
        elif self.effect_type == 'brightness':
            return self._apply_brightness_effect(pil_img, parameters, frame_idx)
        elif self.effect_type == 'contrast':
            return self._apply_contrast_effect(pil_img, parameters, frame_idx)
        elif self.effect_type == 'greyscale':
            return self._apply_greyscale_effect(pil_img)
        elif self.effect_type == 'vignette':
            return self._apply_vignette(pil_img, parameters, frame_idx)
        elif self.effect_type == 'saturation':
            return self._apply_saturation(pil_img, parameters, frame_idx)
        elif self.effect_type == 'posterize':
            return self._apply_posterize(pil_img, parameters, frame_idx)
        elif self.effect_type == 'emboss':
            return self._apply_emboss(pil_img, parameters, frame_idx)
        elif self.effect_type == 'edge_detection':
            return self._apply_edge_detection(pil_img, parameters, frame_idx)
        elif self.effect_type == 'colorize':
            return self._apply_colorize(pil_img, parameters, frame_idx)
        elif self.effect_type == 'oil_painting':
            return self._apply_oil_painting(pil_img, parameters, frame_idx)
        elif self.effect_type == 'glow':
            return self._apply_glow(pil_img, parameters, frame_idx)
        elif self.effect_type == 'solarize':
            return self._apply_solarize(pil_img, parameters, frame_idx)
        elif self.effect_type == 'image_enhancement':
            return self._apply_image_enhancement(pil_img, parameters, frame_idx)
        elif self.effect_type == 'quality_enhancement':
            return self._apply_quality_enhancement(pil_img, parameters, frame_idx)
        elif self.effect_type == 'upscale':
            return self._apply_upscale(pil_img, parameters, frame_idx)
        elif self.effect_type == 'motion_blur':
            return self._apply_motion_blur(pil_img, parameters, frame_idx)
        elif self.effect_type == 'shader_bloom':
            return self._apply_shader_bloom(pil_img, parameters, frame_idx)
        elif self.effect_type == 'palette_cycler':
            return self._apply_palette_cycler(pil_img, parameters, frame_idx)
        elif self.effect_type == 'pixel_depth':
            return self._apply_pixel_depth(pil_img, parameters, frame_idx)
        elif self.effect_type == 'hd_crisp':
            return self._apply_hd_crisp(pil_img, parameters, frame_idx)
        elif self.effect_type == 'fade':
            return self._apply_fade_effect(pil_img, parameters, frame_idx)
        elif self.effect_type == 'opacity':
            return self._apply_opacity_effect(pil_img, parameters)
        elif self.effect_type == 'blur':
            return self._apply_blur_effect(pil_img, parameters)
        elif self.effect_type == 'sharpen':
            return self._apply_sharpen_effect(pil_img, parameters)
        elif self.effect_type == 'noise':
            return self._apply_noise_effect(pil_img, parameters)
        elif self.effect_type == 'dither':
            return self._apply_dither_effect(pil_img, parameters)
        elif self.effect_type == 'pixelate':
            return self._apply_pixelate_effect(pil_img, parameters)
        elif self.effect_type == 'mirror_horizontal':
            return self._apply_mirror_horizontal_effect(pil_img)
        elif self.effect_type == 'mirror_vertical':
            return self._apply_mirror_vertical_effect(pil_img)
        elif self.effect_type == 'rotate_90':
            return self._apply_rotate_90_effect(pil_img)
        elif self.effect_type == 'rotate_180':
            return self._apply_rotate_180_effect(pil_img)
        elif self.effect_type == 'rotate_custom':
            return self._apply_rotate_custom_effect(pil_img, parameters, frame_idx)
        elif self.effect_type == 'map_generator':
            return self._apply_map_generator_effect(pil_img, parameters)
        elif self.effect_type == 'texture_2d':
            return self._apply_texture_2d_effect(pil_img, parameters, frame_idx)
        elif self.effect_type == 'generate_lod':
            return self._apply_generate_lod_effect(pil_img, parameters)
        elif self.effect_type == 'atmospheric_lighting':
            return self._apply_atmospheric_lighting_effect(pil_img, parameters)
        elif self.effect_type == 'wind_waker':
            return self._apply_wind_waker_effect(pil_img, parameters)
        elif self.effect_type == 'ocarina_of_time':
            return self._apply_ocarina_of_time_effect(pil_img, parameters)
        elif self.effect_type == 'luigis_mansion':
            return self._apply_luigis_mansion_effect(pil_img, parameters)
        elif self.effect_type == 'eternal_darkness':
            return self._apply_eternal_darkness_effect(pil_img, parameters)
        elif self.effect_type == 'pokemon_colosseum':
            return self._apply_pokemon_colosseum_effect(pil_img, parameters)
        elif self.effect_type == 'mario_kart_8':
            return self._apply_mario_kart_8_effect(pil_img, parameters)
        elif self.effect_type == 'image_enhancement':
            return self._apply_image_enhancement_effect(pil_img, parameters)
        elif self.effect_type == 'quality_enhancement':
            return self._apply_quality_enhancement_effect(pil_img, parameters)
        elif self.effect_type == 'upscale':
            return self._apply_upscale_effect(pil_img, parameters)
        elif self.effect_type == 'noise_reduction':
            return self._apply_noise_reduction_effect(pil_img, parameters)
        elif self.effect_type == 'hdr_tone_mapping':
            return self._apply_hdr_tone_mapping_effect(pil_img, parameters)

        else:
            return np.array(pil_img)
    
    def _apply_invert_effect(self, pil_img):
        """Apply invert colors effect."""
        from PIL import Image
        # Invert RGB channels but keep alpha
        r, g, b, a = pil_img.split()
        inverted = Image.merge('RGB', (r.point(lambda x: 255 - x), 
                                      g.point(lambda x: 255 - x), 
                                      b.point(lambda x: 255 - x)))
        inverted.putalpha(a)
        return np.array(inverted)
    
    def _apply_greyscale_effect(self, pil_img):
        """Apply greyscale effect."""
        l_img = pil_img.convert('L')
        a = pil_img.getchannel('A')
        l_img.putalpha(a)
        out = l_img.convert('RGBA')
        return np.array(out)
    
    def _apply_brightness_effect(self, pil_img, parameters, frame_idx=0):
        """Apply brightness adjustment effect with progressive animation support."""
        base_factor = parameters.get('factor', 1.0)
        from PIL import ImageEnhance
        
        # If creating multiple frames, interpolate brightness based on frame_idx
        if self.frame_option == "create_frames" and self.total_preview_frames > 1:
            # Progressive brightness: frame 0 = 1.0 (normal), last frame = factor
            factor = 1.0 + (base_factor - 1.0) * (frame_idx / (self.total_preview_frames - 1)) if self.total_preview_frames > 1 else base_factor
        else:
            factor = base_factor
        
        # Apply brightness while preserving alpha
        if pil_img.mode != 'RGBA':
            pil_img = pil_img.convert('RGBA')
        
        # Convert to RGB for brightness adjustment, then restore alpha
        rgb_img = pil_img.convert('RGB')
        enhancer = ImageEnhance.Brightness(rgb_img)
        brightened_rgb = enhancer.enhance(factor)
        
        # Restore alpha channel
        brightened_rgb.putalpha(pil_img.getchannel('A'))
        return np.array(brightened_rgb)
    
    def _apply_vignette(self, pil_img, parameters, frame_idx=0):
        """Apply vignette effect with progressive animation support."""
        base_strength = parameters.get('strength', 0.5)
        radius = parameters.get('radius', 0.8)
        shape = parameters.get('shape', 'circular')
        
        # If creating multiple frames, interpolate strength based on frame_idx
        if self.frame_option == "create_frames" and self.total_preview_frames > 1:
            # Progressive vignette: frame 0 = 0 (no vignette), last frame = strength
            strength = base_strength * (frame_idx / (self.total_preview_frames - 1)) if self.total_preview_frames > 1 else base_strength
        else:
            strength = base_strength
        
        # Ensure RGBA mode
        if pil_img.mode != 'RGBA':
            pil_img = pil_img.convert('RGBA')
        
        # Get image dimensions
        width, height = pil_img.size
        img_array = np.array(pil_img)
        
        # Create coordinate grids
        x, y = np.meshgrid(np.arange(width), np.arange(height))
        
        # Normalize coordinates to -1 to 1
        x_norm = (x / width - 0.5) * 2
        y_norm = (y / height - 0.5) * 2
        
        # Calculate distance from center based on shape
        if shape == 'circular':
            distance = np.sqrt(x_norm**2 + y_norm**2)
        else:  # square
            distance = np.maximum(np.abs(x_norm), np.abs(y_norm))
        
        # Calculate vignette mask (0 = fully darkened, 1 = no change)
        # Use smooth falloff
        falloff = distance / radius
        falloff = np.clip(falloff, 0, 1)
        vignette_mask = 1 - (falloff * strength)
        
        # Apply vignette to RGB channels only
        vignette_alpha = vignette_mask[:, :, np.newaxis]
        result_array = img_array.copy()
        result_array[:, :, :3] = (result_array[:, :, :3] * vignette_alpha).astype(np.uint8)
        
        # Preserve original alpha channel
        result_array[:, :, 3] = img_array[:, :, 3]
        
        return result_array
	
    
    def _apply_saturation(self, pil_img, parameters, frame_idx=0):
        """Apply saturation effect with progressive animation support."""
        base_factor = parameters.get('factor', 1.0)
        from PIL import ImageEnhance
        
        # If creating multiple frames, interpolate saturation
        if self.frame_option == "create_frames" and self.total_preview_frames > 1:
            factor = 1.0 + (base_factor - 1.0) * (frame_idx / (self.total_preview_frames - 1)) if self.total_preview_frames > 1 else base_factor
        else:
            factor = base_factor
        
        # Apply saturation while preserving alpha
        if pil_img.mode != 'RGBA':
            pil_img = pil_img.convert('RGBA')
        
        rgb_img = pil_img.convert('RGB')
        enhancer = ImageEnhance.Color(rgb_img)
        adjusted_rgb = enhancer.enhance(factor)
        adjusted_rgb.putalpha(pil_img.getchannel('A'))
        return np.array(adjusted_rgb)
    
    def _apply_posterize(self, pil_img, parameters, frame_idx=0):
        """Apply posterize effect."""
        levels = parameters.get('levels', 8)
        
        if pil_img.mode != 'RGBA':
            pil_img = pil_img.convert('RGBA')
        
        img_array = np.array(pil_img)
        result_array = img_array.copy()
        quantize_step = 256 // levels
        
        for channel in range(3):
            result_array[:, :, channel] = (img_array[:, :, channel] // quantize_step) * quantize_step
        
        result_array[:, :, 3] = img_array[:, :, 3]
        return result_array
    
    def _apply_emboss(self, pil_img, parameters, frame_idx=0):
        """Apply emboss effect."""
        base_strength = parameters.get('strength', 1.0)
        
        # Progressive emboss if creating frames
        if self.frame_option == "create_frames" and self.total_preview_frames > 1:
            strength = base_strength * (frame_idx / (self.total_preview_frames - 1)) if self.total_preview_frames > 1 else base_strength
        else:
            strength = base_strength
        
        if pil_img.mode != 'RGBA':
            pil_img = pil_img.convert('RGBA')
        
        gray = pil_img.convert('L')
        gray_array = np.array(gray, dtype=np.float32)
        
        kernel = np.array([[-2*strength, -1*strength, 0],
                           [-1*strength,  1,         1*strength],
                           [ 0,            1*strength, 2*strength]])
        
        from scipy import ndimage
        embossed = ndimage.convolve(gray_array, kernel, mode='constant')
        embossed = np.clip(embossed + 128, 0, 255).astype(np.uint8)
        
        result = np.zeros((*embossed.shape, 4), dtype=np.uint8)
        result[:, :, :3] = embossed[:, :, np.newaxis]
        result[:, :, 3] = np.array(pil_img.getchannel('A'))
        
        return result
    
    def _apply_edge_detection(self, pil_img, parameters, frame_idx=0):
        """Apply edge detection effect - with grayscale gradients."""
        threshold = parameters.get('threshold', 50)
        
        if pil_img.mode != 'RGBA':
            pil_img = pil_img.convert('RGBA')
        
        gray = pil_img.convert('L')
        gray_array = np.array(gray, dtype=np.float32)
        
        sobel_x = np.array([[-1, 0, 1], [-2, 0, 2], [-1, 0, 1]])
        sobel_y = np.array([[-1, -2, -1], [ 0,  0,  0], [ 1,  2,  1]])
        
        from scipy import ndimage
        edge_x = ndimage.convolve(gray_array, sobel_x)
        edge_y = ndimage.convolve(gray_array, sobel_y)
        
        magnitude = np.sqrt(edge_x**2 + edge_y**2)
        
        # Normalize to show gradients instead of binary threshold
        magnitude_normalized = np.clip((magnitude / threshold) * 255, 0, 255).astype(np.uint8)
        
        result = np.zeros((*magnitude_normalized.shape, 4), dtype=np.uint8)
        result[:, :, :3] = magnitude_normalized[:, :, np.newaxis]
        result[:, :, 3] = np.array(pil_img.getchannel('A'))
        
        return result
    
    def _apply_colorize(self, pil_img, parameters, frame_idx=0):
        """Apply colorize effect."""
        color_hex = parameters.get('color', '#FF0000')
        base_strength = parameters.get('strength', 0.5)
        
        # Progressive colorize if creating frames
        if self.frame_option == "create_frames" and self.total_preview_frames > 1:
            strength = base_strength * (frame_idx / (self.total_preview_frames - 1)) if self.total_preview_frames > 1 else base_strength
        else:
            strength = base_strength
        
        color_hex = color_hex.lstrip('#')
        tint_r = int(color_hex[0:2], 16)
        tint_g = int(color_hex[2:4], 16)
        tint_b = int(color_hex[4:6], 16)
        
        if pil_img.mode != 'RGBA':
            pil_img = pil_img.convert('RGBA')
        
        img_array = np.array(pil_img, dtype=np.float32)
        gray = np.dot(img_array[:, :, :3], [0.299, 0.587, 0.114])[:, :, np.newaxis]
        
        tinted = (1 - strength) * gray + strength * np.array([tint_r, tint_g, tint_b])
        tinted = tinted.astype(np.uint8)
        
        result_array = np.zeros_like(img_array, dtype=np.uint8)
        result_array[:, :, :3] = tinted
        result_array[:, :, 3] = img_array[:, :, 3].astype(np.uint8)
        
        return result_array
    
    def _apply_oil_painting(self, pil_img, parameters, frame_idx=0):
        """Apply oil painting effect for preview - optimized with centralized preview downscaling."""
        brush_size = int(parameters.get('brush_size', 3))
        intensity = parameters.get('intensity', 0.7)
        
        if pil_img.mode != 'RGBA':
            pil_img = pil_img.convert('RGBA')
        
        # BATCH 2 OPTIMIZATION: Use centralized preview downscaling
        # Oil painting median filter is very slow on large images
        pil_img, original_size, was_downscaled = self._prepare_preview_image(pil_img, max_preview_size=400)
        
        img_array = np.array(pil_img)
        
        # Use minimal median filter for speed
        from scipy import ndimage
        oiled = np.zeros_like(img_array)
        
        # Oil painting uses median filter which is slow - already downscaled for preview
        for channel in range(3):
            oiled[:, :, channel] = ndimage.median_filter(img_array[:, :, channel], size=max(2, brush_size * 2 - 1))
        oiled[:, :, 3] = img_array[:, :, 3]
        
        blended = (intensity * oiled + (1 - intensity) * img_array).astype(np.uint8)
        
        return blended
    
    def _apply_glow(self, pil_img, parameters, frame_idx=0):
        """Apply glow effect for preview - optimized with preview downscaling."""
        base_radius = parameters.get('radius', 10)
        base_strength = parameters.get('strength', 1.5)
        
        # Progressive glow
        if self.frame_option == "create_frames" and self.total_preview_frames > 1:
            radius = base_radius * (frame_idx / (self.total_preview_frames - 1))
            strength = base_strength * (frame_idx / (self.total_preview_frames - 1))
        else:
            radius = base_radius
            strength = base_strength
        
        if pil_img.mode != 'RGBA':
            pil_img = pil_img.convert('RGBA')
        
        # BATCH 2 OPTIMIZATION: Downscale for preview to speed up processing
        # Glow with large radius can be very slow on large images
        if radius > 10 or max(pil_img.size) > 400:
            pil_img, original_size, was_downscaled = self._prepare_preview_image(pil_img, max_preview_size=400)
        
        img_array = np.array(pil_img, dtype=np.float32)
        from scipy import ndimage
        blurred = np.zeros_like(img_array)
        for channel in range(3):
            blurred[:, :, channel] = ndimage.gaussian_filter(img_array[:, :, channel], sigma=max(1, radius))
        
        result = np.clip(img_array + (blurred * strength), 0, 255).astype(np.uint8)
        result[:, :, 3] = img_array[:, :, 3].astype(np.uint8)
        return result
    
    def _apply_solarize(self, pil_img, parameters, frame_idx=0):
        """Apply solarize effect for preview."""
        threshold = parameters.get('threshold', 128)
        
        if pil_img.mode != 'RGBA':
            pil_img = pil_img.convert('RGBA')
        
        img_array = np.array(pil_img, dtype=np.float32)
        mask = img_array[:, :, :3] > threshold
        inverted = np.where(mask, 255 - img_array[:, :, :3], img_array[:, :, :3])
        result = img_array.copy()
        result[:, :, :3] = inverted
        result = np.clip(result, 0, 255).astype(np.uint8)
        return result
    
    def _apply_image_enhancement(self, pil_img, parameters, frame_idx=0):
        """Apply simplified image enhancement effect for preview."""
        from PIL import Image
        
        # Step 1: Apply quality enhancement if enabled (on original size)
        enable_quality = parameters.get('enable_upscale_quality', True)
        quality_factor = parameters.get('upscale_quality_factor', 5)
        
        if enable_quality:
            # Map quality factor (1-8) to quality parameters
            # Higher factor = more aggressive enhancement
            quality_intensity = quality_factor / 8.0  # 0.125 to 1.0
            quality_params = {
                'sharpness': 0.5 + quality_intensity * 1.5,  # 0.5 to 2.0
                'detail': quality_intensity * 1.5,  # 0 to 1.5
                'contrast': quality_intensity * 0.6,  # 0 to 0.6
                'denoise': quality_intensity * 0.3,  # 0 to 0.3
                'enhance_edges': True,
                'preserve_colors': True,
            }
            result_array = self._apply_quality_enhancement(pil_img, quality_params, frame_idx)
            pil_img = Image.fromarray(result_array, mode='RGBA')
        
        # Step 2: Apply size upscale if enabled
        enable_upscale_size = parameters.get('enable_upscale_size', False)
        size_factor = parameters.get('upscale_size_factor', 2)
        
        if enable_upscale_size and size_factor > 1:
            width, height = pil_img.size
            new_width = width * size_factor
            new_height = height * size_factor
            pil_img = pil_img.resize((new_width, new_height), Image.LANCZOS)
        
        return np.array(pil_img)
    
    def _apply_quality_enhancement(self, pil_img, parameters, frame_idx=0):
        """Apply quality enhancement for preview - improves detail and sharpness while keeping same dimensions."""
        sharpness = float(parameters.get('sharpness', 1.0))
        detail = float(parameters.get('detail', 0.5))
        contrast = float(parameters.get('contrast', 0.3))
        denoise = float(parameters.get('denoise', 0.2))
        enhance_edges = parameters.get('enhance_edges', True)
        preserve_colors = parameters.get('preserve_colors', True)
        
        if pil_img.mode != 'RGBA':
            pil_img = pil_img.convert('RGBA')
        
        # Convert to numpy array
        img_array = np.array(pil_img, dtype=np.float32)
        height, width = img_array.shape[:2]
        
        # Extract RGB channels
        rgb_img = img_array[:, :, :3].astype(np.uint8)
        
        # Use OpenCV for processing
        import cv2
        bgr_img = cv2.cvtColor(rgb_img, cv2.COLOR_RGB2BGR)
        
        # Step 1: Optional denoising
        if denoise > 0:
            # Fast denoising - preserves edges better than simple blur
            denoised = cv2.fastNlMeansDenoisingColored(
                bgr_img, None,
                h=int(denoise * 10),  # Denoise strength
                hColor=int(denoise * 10),
                templateWindowSize=7,
                searchWindowSize=21
            )
            # Blend with original based on denoise strength
            bgr_img = cv2.addWeighted(bgr_img, 1.0 - denoise, denoised, denoise, 0)
        
        # Step 2: Edge-aware sharpening and detail enhancement
        if enhance_edges:
            # Convert to LAB color space for better detail enhancement
            lab = cv2.cvtColor(bgr_img, cv2.COLOR_BGR2LAB)
            l_channel, a_channel, b_channel = cv2.split(lab)
            
            # Apply unsharp masking to L channel (lightness)
            blurred_l = cv2.GaussianBlur(l_channel, (0, 0), 1.0)
            sharpened_l = cv2.addWeighted(l_channel, 1.0 + sharpness, blurred_l, -sharpness, 0)
            
            # Detail enhancement - boost mid-frequency details
            if detail > 0:
                # Create detail layer by subtracting blurred from original
                detail_layer = cv2.subtract(l_channel.astype(np.float32), blurred_l.astype(np.float32))
                # Boost detail layer
                enhanced_l = np.clip(l_channel.astype(np.float32) + detail_layer * detail, 0, 255).astype(np.uint8)
                # Blend with sharpened
                l_final = cv2.addWeighted(sharpened_l, 0.7, enhanced_l, 0.3, 0)
            else:
                l_final = sharpened_l
            
            # Local contrast enhancement (CLAHE)
            if contrast > 0:
                clahe = cv2.createCLAHE(clipLimit=1.0 + contrast * 2.0, tileGridSize=(8, 8))
                l_final = clahe.apply(l_final)
            
            # Recombine LAB channels
            enhanced_lab = cv2.merge([l_final, a_channel, b_channel])
            result_bgr = cv2.cvtColor(enhanced_lab, cv2.COLOR_LAB2BGR)
        else:
            # Simple global sharpening
            blurred = cv2.GaussianBlur(bgr_img, (0, 0), 1.0)
            result_bgr = cv2.addWeighted(bgr_img, 1.0 + sharpness, blurred, -sharpness, 0)
        
        # Step 3: Color preservation (optional)
        if preserve_colors:
            # Convert to HSV to preserve hue/saturation
            hsv_original = cv2.cvtColor(rgb_img, cv2.COLOR_RGB2HSV)
            hsv_result = cv2.cvtColor(cv2.cvtColor(result_bgr, cv2.COLOR_BGR2RGB), cv2.COLOR_RGB2HSV)
            
            # Keep original hue and saturation, use enhanced value
            hsv_result[:, :, 0] = hsv_original[:, :, 0]  # Preserve hue
            hsv_result[:, :, 1] = cv2.addWeighted(hsv_original[:, :, 1], 0.8, hsv_result[:, :, 1], 0.2, 0)  # Blend saturation
            
            # Convert back to RGB
            result_rgb = cv2.cvtColor(hsv_result, cv2.COLOR_HSV2RGB)
        else:
            result_rgb = cv2.cvtColor(result_bgr, cv2.COLOR_BGR2RGB)
        
        # Reconstruct RGBA with original alpha
        result = np.zeros((height, width, 4), dtype=np.uint8)
        result[:, :, :3] = np.clip(result_rgb, 0, 255).astype(np.uint8)
        result[:, :, 3] = img_array[:, :, 3].astype(np.uint8)
        
        return result
    
    def _apply_upscale(self, pil_img, parameters, frame_idx=0):
        """Apply upscale effect for preview - simplified for performance."""
        scale = int(parameters.get('scale', 2))
        sharpening = float(parameters.get('sharpening', 1.2))
        
        if pil_img.mode != 'RGBA':
            pil_img = pil_img.convert('RGBA')
        
        # Downscale for preview if too large
        preview_max_size = 400
        original_size = pil_img.size
        if max(original_size) > preview_max_size:
            scale_for_preview = preview_max_size / max(original_size)
            preview_size = (int(original_size[0] * scale_for_preview), int(original_size[1] * scale_for_preview))
            pil_img = pil_img.resize(preview_size, Image.LANCZOS)
        
        width, height = pil_img.size
        new_width = width * scale
        new_height = height * scale
        
        upscaled = pil_img.resize((new_width, new_height), Image.LANCZOS)
        
        # Apply sharpening with OpenCV for preview
        import cv2
        img_array = np.array(upscaled)
        rgb_img = img_array[:, :, :3].astype(np.uint8)
        bgr_img = cv2.cvtColor(rgb_img, cv2.COLOR_RGB2BGR)
        blurred = cv2.GaussianBlur(bgr_img, (0, 0), 1.0)
        sharpened_bgr = np.clip(bgr_img.astype(np.float32) + (bgr_img.astype(np.float32) - blurred.astype(np.float32)) * sharpening, 0, 255).astype(np.uint8)
        sharpened_rgb = cv2.cvtColor(sharpened_bgr, cv2.COLOR_BGR2RGB)
        
        # Reconstruct RGBA
        result = np.zeros_like(img_array)
        result[:, :, :3] = sharpened_rgb
        result[:, :, 3] = img_array[:, :, 3]
        
        return result
    
    def _apply_motion_blur(self, pil_img, parameters, frame_idx=0):
        """Apply motion blur for preview - optimized with preview downscaling."""
        angle = parameters.get('angle', 45)
        distance = int(parameters.get('distance', 10))
        
        if pil_img.mode != 'RGBA':
            pil_img = pil_img.convert('RGBA')
        
        # BATCH 2 OPTIMIZATION: Downscale for preview to speed up processing
        # Motion blur convolution can be slow on large images
        if distance > 10 or max(pil_img.size) > 400:
            pil_img, original_size, was_downscaled = self._prepare_preview_image(pil_img, max_preview_size=400)
        
        img_array = np.array(pil_img)
        import math
        rad = math.radians(angle)
        kernel_size = distance * 2 + 1
        kernel = np.zeros((kernel_size, kernel_size))
        
        for i in range(-distance, distance + 1):
            x_offset = int(i * math.cos(rad))
            y_offset = int(i * math.sin(rad))
            center = kernel_size // 2
            x = center + x_offset
            y = center + y_offset
            if 0 <= x < kernel_size and 0 <= y < kernel_size:
                kernel[y, x] = 1.0
        
        kernel /= kernel.sum()
        from scipy import ndimage
        result = img_array.copy()
        for channel in range(3):
            result[:, :, channel] = ndimage.convolve(img_array[:, :, channel], kernel)
        result[:, :, 3] = img_array[:, :, 3]
        return result
    
    def _apply_shader_bloom(self, pil_img, parameters, frame_idx=0):
        """Apply shader bloom for preview - optimized with OpenCV and preview downscaling."""
        intensity = parameters.get('intensity', 1.0)
        threshold = parameters.get('threshold', 200)
        radius = int(parameters.get('radius', 15))
        
        if pil_img.mode != 'RGBA':
            pil_img = pil_img.convert('RGBA')
        
        # BATCH 2 OPTIMIZATION: Downscale for preview to speed up processing
        pil_img, original_size, was_downscaled = self._prepare_preview_image(pil_img, max_preview_size=400)
        
        img_array = np.array(pil_img, dtype=np.float32)
        height, width = img_array.shape[:2]
        
        # Extract bright areas above threshold
        bright_mask = np.max(img_array[:, :, :3], axis=2) > threshold
        bright_pixels = img_array.copy()
        bright_pixels[~bright_mask] = 0
        
        # Convert to uint8 for OpenCV
        bright_pixels_uint8 = np.clip(bright_pixels[:, :, :3], 0, 255).astype(np.uint8)
        
        # Use OpenCV for much faster Gaussian blur
        import cv2
        bright_bgr = cv2.cvtColor(bright_pixels_uint8, cv2.COLOR_RGB2BGR)
        
        # Calculate kernel size (must be odd)
        kernel_size = int(radius * 6) | 1
        if kernel_size < 3:
            kernel_size = 3
        
        # First blur pass
        bloom_bgr = cv2.GaussianBlur(bright_bgr, (kernel_size, kernel_size), radius)
        
        # Second pass (reduced radius)
        radius2 = radius * 0.7
        kernel_size2 = int(radius2 * 6) | 1
        if kernel_size2 < 3:
            kernel_size2 = 3
        bloom_bgr = cv2.GaussianBlur(bloom_bgr, (kernel_size2, kernel_size2), radius2)
        
        # Convert back to RGB
        bloom_rgb = cv2.cvtColor(bloom_bgr, cv2.COLOR_BGR2RGB).astype(np.float32)
        
        # Add bloom to original
        result = np.clip(img_array[:, :, :3] + (bloom_rgb * intensity), 0, 255).astype(np.uint8)
        
        # Reconstruct RGBA
        result_rgba = np.zeros((height, width, 4), dtype=np.uint8)
        result_rgba[:, :, :3] = result
        result_rgba[:, :, 3] = img_array[:, :, 3].astype(np.uint8)
        
        return result_rgba
    
    def _apply_palette_cycler(self, pil_img, parameters, frame_idx=0):
        """Apply palette cycler for preview - simplified for performance."""
        cycle_speed = parameters.get('cycle_speed', 0.5)
        direction = parameters.get('direction', 'forward')
        
        if pil_img.mode != 'RGBA':
            pil_img = pil_img.convert('RGBA')
        
        img_array = np.array(pil_img)
        
        # Simplified: just shift hue uniformly for preview
        from colorsys import rgb_to_hsv, hsv_to_rgb
        
        # Sample every 4th pixel for performance
        result = img_array.copy()
        for y in range(0, img_array.shape[0], 4):
            for x in range(0, img_array.shape[1], 4):
                r, g, b, a = img_array[y, x]
                h, s, v = rgb_to_hsv(r/255.0, g/255.0, b/255.0)
                shift = cycle_speed * (v * 2 - 1)
                if direction == 'reverse':
                    shift = -shift
                h_shifted = (h + shift) % 1.0
                r_new, g_new, b_new = hsv_to_rgb(h_shifted, s, v)
                result[y, x] = [int(r_new*255), int(g_new*255), int(b_new*255), a]
        
        return result
    
    def _apply_pixel_depth(self, pil_img, parameters, frame_idx=0):
        """Apply pixel depth for preview."""
        depth = parameters.get('depth', 0.5)
        angle = parameters.get('angle', 45)
        
        if pil_img.mode != 'RGBA':
            pil_img = pil_img.convert('RGBA')
        
        img_array = np.array(pil_img, dtype=np.float32)
        gray = np.dot(img_array[:, :, :3], [0.299, 0.587, 0.114])
        
        import math
        rad = math.radians(angle)
        offset_x = depth * math.cos(rad)
        offset_y = depth * math.sin(rad)
        displacement = (gray - 128) / 128
        
        result = img_array.copy()
        depth_factor = 1 + (displacement * depth)
        result[:, :, :3] = np.clip(img_array[:, :, :3] * depth_factor[:, :, np.newaxis], 0, 255)
        result[:, :, 3] = img_array[:, :, 3]
        result = np.clip(result, 0, 255).astype(np.uint8)
        return result
    
    def _apply_hd_crisp(self, pil_img, parameters, frame_idx=0):
        """Apply HD Crisp for preview - optimized with OpenCV and downscaling for large images."""
        # For preview, downscale large images to speed up processing
        sharpening = parameters.get('sharpening', 1.0)
        preview_max_size = 800  # Max dimension for preview
        
        if pil_img.mode != 'RGBA':
            pil_img = pil_img.convert('RGBA')
        
        # Downscale for preview if image is large
        original_size = pil_img.size
        if max(original_size) > preview_max_size:
            scale = preview_max_size / max(original_size)
            preview_size = (int(original_size[0] * scale), int(original_size[1] * scale))
            pil_img = pil_img.resize(preview_size, Image.LANCZOS)
        
        img_array = np.array(pil_img, dtype=np.float32)
        height, width = img_array.shape[:2]
        
        # Use OpenCV for faster blur
        import cv2
        img_rgb = img_array[:, :, :3].astype(np.uint8)
        img_bgr = cv2.cvtColor(img_rgb, cv2.COLOR_RGB2BGR)
        
        # Single-pass unsharp masking using OpenCV
        blurred_bgr = cv2.GaussianBlur(img_bgr, (0, 0), 1.0)
        blurred_rgb = cv2.cvtColor(blurred_bgr, cv2.COLOR_BGR2RGB).astype(np.float32)
        
        # Simple sharpening
        result = img_array[:, :, :3] + (img_array[:, :, :3] - blurred_rgb) * sharpening * 0.5
        result = np.clip(result, 0, 255)
        
        # Tiny contrast boost
        result = np.power(result / 255.0, 0.97) * 255
        result = np.clip(result, 0, 255)
        
        # Reconstruct RGBA
        result_rgba = np.zeros((height, width, 4), dtype=np.uint8)
        result_rgba[:, :, :3] = result.astype(np.uint8)
        result_rgba[:, :, 3] = img_array[:, :, 3].astype(np.uint8)
        
        return result_rgba
    
    def _apply_contrast_effect(self, pil_img, parameters, frame_idx=0):
        """Apply contrast adjustment effect with progressive animation support."""
        base_factor = parameters.get('factor', 1.0)
        from PIL import ImageEnhance
        
        # If creating multiple frames, interpolate contrast based on frame_idx
        if self.frame_option == "create_frames" and self.total_preview_frames > 1:
            # Progressive contrast: frame 0 = 1.0 (normal), last frame = factor
            factor = 1.0 + (base_factor - 1.0) * (frame_idx / (self.total_preview_frames - 1)) if self.total_preview_frames > 1 else base_factor
        else:
            factor = base_factor
        
        # Apply brightness while preserving alpha
        if pil_img.mode != 'RGBA':
            pil_img = pil_img.convert('RGBA')
        
        # Convert to RGB for contrast adjustment, then restore alpha
        rgb_img = pil_img.convert('RGB')
        enhancer = ImageEnhance.Contrast(rgb_img)
        contrasted_rgb = enhancer.enhance(factor)
        
        # Restore alpha channel
        contrasted_rgb.putalpha(pil_img.getchannel('A'))
        return np.array(contrasted_rgb)
    
    def _apply_fade_effect(self, pil_img, parameters, frame_idx=0):
        """Apply fade to color effect with progressive animation support."""
        target_color = parameters.get('target_color', '#000000')
        base_intensity = parameters.get('intensity', 0.5)
        
        # If creating multiple frames, interpolate intensity based on frame_idx
        if self.frame_option == "create_frames" and self.total_preview_frames > 1:
            # Progressive fade: frame 0 = 0% intensity, last frame = 100% intensity
            intensity = (frame_idx / (self.total_preview_frames - 1)) if self.total_preview_frames > 1 else base_intensity
        else:
            intensity = base_intensity
        
        # Convert hex to RGB
        target_rgb = tuple(int(target_color[i:i+2], 16) for i in (1, 3, 5))
        
        # Blend with target color
        r, g, b, a = pil_img.split()
        faded_r = r.point(lambda x: int(x * (1 - intensity) + target_rgb[0] * intensity))
        faded_g = g.point(lambda x: int(x * (1 - intensity) + target_rgb[1] * intensity))
        faded_b = b.point(lambda x: int(x * (1 - intensity) + target_rgb[2] * intensity))
        
        faded = Image.merge('RGB', (faded_r, faded_g, faded_b))
        faded.putalpha(a)
        return np.array(faded)
    
    def _apply_opacity_effect(self, pil_img, parameters):
        """Apply opacity adjustment effect."""
        opacity = parameters.get('opacity', 0.5)
        
        # Adjust alpha channel
        r, g, b, a = pil_img.split()
        new_alpha = a.point(lambda x: int(x * opacity))
        result = Image.merge('RGBA', (r, g, b, new_alpha))
        return np.array(result)
    
    def _apply_blur_effect(self, pil_img, parameters):
        """Apply blur effect - optimized with preview downscaling for large images."""
        radius = parameters.get('radius', 5)
        
        # BATCH 2 OPTIMIZATION: Downscale for preview if image is large
        # Large images with large blur radius can be very slow
        if radius > 10 or max(pil_img.size) > 400:
            pil_img, original_size, was_downscaled = self._prepare_preview_image(pil_img, max_preview_size=400)
        
        from PIL import ImageFilter
        blurred = pil_img.filter(ImageFilter.GaussianBlur(radius=radius))
        return np.array(blurred)
    
    def _apply_sharpen_effect(self, pil_img, parameters):
        """Apply sharpen effect."""
        amount = parameters.get('amount', 50)
        from PIL import ImageEnhance
        enhancer = ImageEnhance.Sharpness(pil_img)
        sharpened = enhancer.enhance(1 + amount / 100.0)
        return np.array(sharpened)
    
    def _apply_noise_effect(self, pil_img, parameters):
        """Apply noise effect - optimized version."""
        import random
        
        intensity = parameters.get('intensity', 50)
        noise_type = parameters.get('type', 'Random')
        seed = parameters.get('seed', 42)
        
        # Set random seed for reproducible noise
        random.seed(seed)
        
        # Convert PIL to numpy array
        img_array = np.array(pil_img)
        height, width = img_array.shape[:2]
        
        if noise_type == 'Coherent':
            # Vectorized coherent noise generation
            x_coords, y_coords = np.meshgrid(np.arange(width), np.arange(height))
            x_coords = x_coords * 0.1
            y_coords = y_coords * 0.1
            
            # Vectorized hash function
            def vectorized_noise(x, y):
                n = (x * 73856093 + y * 19349663 + seed).astype(np.int64) & 0x7fffffff
                n = (n << 13) ^ n
                return ((n * (n * n * 15731 + 789221) + 1376312589) & 0x7fffffff) / 0x7fffffff
            
            # Generate noise map vectorized
            noise_map = vectorized_noise(x_coords, y_coords) * (intensity / 100.0)
            
            # Apply noise to RGB channels vectorized
            noise_3d = np.stack([noise_map] * 3, axis=2)
            img_array[:, :, :3] = np.clip(img_array[:, :, :3] + noise_3d * 255, 0, 255)
        else:
            # Vectorized random noise
            noise = np.random.randint(-intensity, intensity, img_array.shape[:3], dtype=np.int16)
            img_array = np.clip(img_array.astype(np.int16) + noise, 0, 255).astype(np.uint8)
        
        return img_array
    
    def _apply_dither_effect(self, pil_img, parameters):
        """Apply dither effect with multiple algorithms using NumPy only."""
        intensity = parameters.get('intensity', 50) / 100.0
        pattern = parameters.get('pattern', 'Floyd-Steinberg')
        
        # BATCH 2 OPTIMIZATION: Downscale for preview to speed up processing
        # Floyd-Steinberg dithering is pixel-by-pixel and can be very slow on large images
        if pil_img.mode != 'RGBA':
            pil_img = pil_img.convert('RGBA')
        pil_img, original_size, was_downscaled = self._prepare_preview_image(pil_img, max_preview_size=400)
        
        # Convert PIL image to numpy array
        img_array = np.array(pil_img)
        height, width = img_array.shape[:2]
        
        # Ensure we have RGB data
        if len(img_array.shape) == 3 and img_array.shape[2] == 4:
            # RGBA - extract RGB channels
            rgb_array = img_array[:, :, :3]
            alpha_channel = img_array[:, :, 3]
        else:
            # RGB or grayscale
            rgb_array = img_array
            alpha_channel = None
        
        if pattern == 'Floyd-Steinberg':
            result = self._floyd_steinberg_dither(rgb_array, intensity)
        elif pattern == 'Ordered':
            result = self._ordered_dither(rgb_array, intensity)
        elif pattern == 'Random':
            result = self._random_dither(rgb_array, intensity)
        else:
            result = self._floyd_steinberg_dither(rgb_array, intensity)
        
        # Reconstruct the image with alpha if it existed
        if alpha_channel is not None:
            result_img = np.zeros((height, width, 4), dtype=np.uint8)
            result_img[:, :, :3] = result
            result_img[:, :, 3] = alpha_channel
        else:
            result_img = result
        
        return result_img
    
    def _floyd_steinberg_dither(self, img_array, intensity):
        """Floyd-Steinberg dithering algorithm - color preserving."""
        height, width = img_array.shape[:2]
        
        # Calculate number of output levels based on intensity
        # Higher intensity = fewer levels = more visible dithering
        max_levels = 256
        min_levels = 4  # Much fewer levels for visible effect
        levels = max(min_levels, int(max_levels * (1 - intensity * 0.9)))
        
        # Create output image
        result = img_array.copy().astype(float)
        
        # Process each color channel separately
        for channel in range(3):
            # Create error buffer for this channel
            error_buffer = np.zeros((height, width), dtype=float)
            
            for y in range(height):
                for x in range(width):
                    # Get original pixel value
                    old_pixel = result[y, x, channel] + error_buffer[y, x]
                    
                    # Quantize to nearest level
                    new_pixel = round(old_pixel / (256 / (levels - 1))) * (256 / (levels - 1))
                    new_pixel = max(0, min(255, new_pixel))
                    
                    # Set output pixel
                    result[y, x, channel] = new_pixel
                    
                    # Calculate quantization error
                    error = old_pixel - new_pixel
                    
                    # Distribute error to neighboring pixels (Floyd-Steinberg pattern)
                    if x + 1 < width:
                        error_buffer[y, x + 1] += error * 7 / 16
                    if x - 1 >= 0 and y + 1 < height:
                        error_buffer[y + 1, x - 1] += error * 3 / 16
                    if y + 1 < height:
                        error_buffer[y + 1, x] += error * 5 / 16
                    if x + 1 < width and y + 1 < height:
                        error_buffer[y + 1, x + 1] += error * 1 / 16
        
        return np.clip(result, 0, 255).astype(np.uint8)
    
    def _ordered_dither(self, img_array, intensity):
        """Ordered dithering using Bayer matrix - color preserving."""
        height, width = img_array.shape[:2]
        
        # 8x8 Bayer matrix
        bayer_matrix = np.array([
            [ 0, 48, 12, 60,  3, 51, 15, 63],
            [32, 16, 44, 28, 35, 19, 47, 31],
            [ 8, 56,  4, 52, 11, 59,  7, 55],
            [40, 24, 36, 20, 43, 27, 39, 23],
            [ 2, 50, 14, 62,  1, 49, 13, 61],
            [34, 18, 46, 30, 33, 17, 45, 29],
            [10, 58,  6, 54,  9, 57,  5, 53],
            [42, 26, 38, 22, 41, 25, 37, 21]
        ]) / 64.0
        
        # Calculate number of output levels
        max_levels = 256
        min_levels = 4  # Much fewer levels for visible effect
        levels = max(min_levels, int(max_levels * (1 - intensity * 0.9)))
        
        # Create output image
        result = img_array.copy().astype(float)
        
        # Process each color channel separately
        for channel in range(3):
            for y in range(height):
                for x in range(width):
                    # Get threshold from Bayer matrix
                    threshold = bayer_matrix[y % 8, x % 8]
                    
                    # Get original pixel value
                    pixel_value = result[y, x, channel]
                    
                    # Apply threshold-based quantization
                    threshold_value = threshold * 256
                    step = 256 / levels
                    
                    # Quantize based on threshold and levels
                    if pixel_value > threshold_value:
                        result[y, x, channel] = min(255, pixel_value + step)
                    else:
                        result[y, x, channel] = max(0, pixel_value - step)
        
        return np.clip(result, 0, 255).astype(np.uint8)
    
    def _random_dither(self, img_array, intensity):
        """Random dithering - color preserving."""
        height, width = img_array.shape[:2]
        
        # Calculate number of output levels
        max_levels = 256
        min_levels = 4  # Much fewer levels for visible effect
        levels = max(min_levels, int(max_levels * (1 - intensity * 0.9)))
        
        # Create output image
        result = img_array.copy().astype(float)
        
        # Generate random noise for each channel
        np.random.seed(42)  # Fixed seed for consistency
        noise = np.random.uniform(-32, 32, (height, width, 3))
        
        # Process each color channel separately
        for channel in range(3):
            for y in range(height):
                for x in range(width):
                    # Get original pixel value
                    pixel_value = result[y, x, channel]
                    
                    # Add random noise
                    noisy_value = pixel_value + noise[y, x, channel]
                    
                    # Quantize to nearest level
                    step = 256 / levels
                    quantized = round(noisy_value / step) * step
                    quantized = max(0, min(255, quantized))
                    
                    result[y, x, channel] = quantized
        
        return np.clip(result, 0, 255).astype(np.uint8)
    
    def _apply_pixelate_effect(self, pil_img, parameters):
        """Apply simple pixelate effect with customizable block size."""
        block_size = parameters.get('block_size', 4)
        
        # Convert PIL image to numpy array
        img_array = np.array(pil_img)
        height, width = img_array.shape[:2]
        
        # Ensure we have RGB data
        if len(img_array.shape) == 3 and img_array.shape[2] == 4:
            # RGBA - extract RGB channels
            rgb_array = img_array[:, :, :3]
            alpha_channel = img_array[:, :, 3]
        else:
            # RGB or grayscale
            rgb_array = img_array
            alpha_channel = None
        
        # Pixelate by averaging blocks
        result = self._pixelate_blocks(rgb_array, block_size)
        
        # Reconstruct the image with alpha if it existed
        if alpha_channel is not None:
            result_img = np.zeros((height, width, 4), dtype=np.uint8)
            result_img[:, :, :3] = result
            result_img[:, :, 3] = alpha_channel
        else:
            result_img = result
        
        return result_img
    
    def _pixelate_blocks(self, img_array, block_size):
        """Create pixelated blocks by averaging colors."""
        height, width = img_array.shape[:2]
        result = img_array.copy()
        
        for y in range(0, height, block_size):
            for x in range(0, width, block_size):
                # Get block bounds
                y_end = min(y + block_size, height)
                x_end = min(x + block_size, width)
                
                # Calculate average color for this block
                block = img_array[y:y_end, x:x_end]
                avg_color = np.mean(block, axis=(0, 1))
                
                # Apply average color to entire block
                result[y:y_end, x:x_end] = avg_color
        
        return result
    
    def _quantize_minecraft_style(self, img_array, palette_rgb):
        """Quantize colors to Minecraft-style palette."""
        height, width = img_array.shape[:2]
        result = img_array.copy()
        
        # Minecraft-style color mapping
        minecraft_colors = {
            'dirt': [139, 69, 19],      # Brown
            'stone': [128, 128, 128],   # Gray
            'grass': [34, 139, 34],     # Green
            'water': [0, 0, 255],       # Blue
            'sand': [244, 164, 96],     # Tan
            'wood': [160, 82, 45],      # Brown
            'leaves': [0, 100, 0],      # Dark green
            'coal': [64, 64, 64],       # Dark gray
            'gold': [255, 215, 0],      # Gold
            'iron': [192, 192, 192],    # Silver
        }
        
        palette_rgb.extend(minecraft_colors.values())
        
        for y in range(height):
            for x in range(width):
                pixel = img_array[y, x]
                # Find closest color in palette
                closest_color = self._find_closest_color(pixel, palette_rgb)
                result[y, x] = closest_color
        
        return result
    
    def _quantize_retro_style(self, img_array, palette_rgb):
        """Quantize colors to retro/8-bit style."""
        height, width = img_array.shape[:2]
        result = img_array.copy()
        
        # Retro color palette (8-bit style)
        retro_colors = [
            [0, 0, 0],        # Black
            [255, 255, 255],  # White
            [255, 0, 0],      # Red
            [0, 255, 0],      # Green
            [0, 0, 255],      # Blue
            [255, 255, 0],    # Yellow
            [255, 0, 255],    # Magenta
            [0, 255, 255],    # Cyan
            [128, 128, 128],  # Gray
            [255, 128, 0],    # Orange
            [128, 0, 128],    # Purple
            [0, 128, 128],    # Teal
        ]
        
        palette_rgb.extend(retro_colors)
        
        for y in range(height):
            for x in range(width):
                pixel = img_array[y, x]
                # Find closest color in palette
                closest_color = self._find_closest_color(pixel, palette_rgb)
                result[y, x] = closest_color
        
        return result
    
    def _quantize_custom_palette(self, img_array, palette_rgb):
        """Quantize colors to custom palette."""
        height, width = img_array.shape[:2]
        result = img_array.copy()
        
        for y in range(height):
            for x in range(width):
                pixel = img_array[y, x]
                # Find closest color in custom palette
                closest_color = self._find_closest_color(pixel, palette_rgb)
                result[y, x] = closest_color
        
        return result
    
    def _find_closest_color(self, pixel, palette_rgb):
        """Find the closest color in the palette to the given pixel."""
        min_distance = float('inf')
        closest_color = [0, 0, 0]
        
        for color in palette_rgb:
            # Calculate Euclidean distance in RGB space
            distance = np.sqrt(np.sum((pixel[:3] - color) ** 2))
            if distance < min_distance:
                min_distance = distance
                closest_color = color
        
        return closest_color
    
    def _apply_mirror_horizontal_effect(self, pil_img):
        """Apply horizontal mirror effect."""
        mirrored = pil_img.transpose(Image.FLIP_LEFT_RIGHT)
        return np.array(mirrored)
    
    def _apply_mirror_vertical_effect(self, pil_img):
        """Apply vertical mirror effect."""
        mirrored = pil_img.transpose(Image.FLIP_TOP_BOTTOM)
        return np.array(mirrored)
    
    def _apply_rotate_90_effect(self, pil_img):
        """Apply 90 degree rotation."""
        rotated = pil_img.rotate(-90, expand=True)
        return np.array(rotated)
    
    def _apply_rotate_180_effect(self, pil_img):
        """Apply 180 degree rotation."""
        rotated = pil_img.rotate(180)
        return np.array(rotated)
    
    def _apply_rotate_custom_effect(self, pil_img, parameters, frame_idx=0):
        """Apply custom rotation with progressive animation support."""
        base_angle = parameters.get('angle', 90)
        
        # If creating multiple frames, interpolate rotation based on frame_idx
        if self.frame_option == "create_frames" and self.total_preview_frames > 1:
            # Progressive rotation: frame 0 = 0°, last frame = full angle
            angle = base_angle * (frame_idx / (self.total_preview_frames - 1)) if self.total_preview_frames > 1 else base_angle
        else:
            angle = base_angle
        
        rotated = pil_img.rotate(-angle, expand=True)
        return np.array(rotated)
    
    def _apply_map_generator_effect(self, pil_img, parameters):
        """Apply 2D map generation effect with enhanced elevation features - optimized."""
        import random
        import math
        
        # BATCH 2 OPTIMIZATION: Downscale for preview to speed up processing
        # Map generation with noise can be slow on large images
        if pil_img.mode != 'RGBA':
            pil_img = pil_img.convert('RGBA')
        pil_img, original_size, was_downscaled = self._prepare_preview_image(pil_img, max_preview_size=400)
        
        # Get parameters
        scale = parameters.get('scale', 0.05)
        detail = parameters.get('detail', 4)
        map_type = parameters.get('map_type', 'Minecraft')
        biome_variation = parameters.get('biome_variation', 30) / 100.0
        seed = parameters.get('seed', 12345)
        temperature = parameters.get('temperature', 50) / 100.0
        humidity = parameters.get('humidity', 50) / 100.0
        
        # Performance optimization: reduce detail for very large images
        w, h = pil_img.size
        total_pixels = w * h
        if total_pixels > 2000000:  # 2MP+ (e.g., 1920x1080)
            # Reduce detail octaves for large images to maintain performance
            if detail > 4:
                detail = max(3, detail - 1)
                # Also reduce scale slightly to compensate
                scale = scale * 1.1
        
        # New elevation parameters
        elevation_intensity = parameters.get('elevation_intensity', 100) / 100.0
        mountain_height = parameters.get('mountain_height', 100) / 100.0
        hill_prominence = parameters.get('hill_prominence', 100) / 100.0
        sea_level = parameters.get('sea_level', 30) / 100.0
        elevation_mode = parameters.get('elevation_mode', 'Normal')
        show_contours = parameters.get('show_contours', False)
        contour_spacing = parameters.get('contour_spacing', 15) / 100.0
        
        # Color definitions
        colors = {
            'deep_water': parameters.get('deep_water_color', '#000080'),
            'shallow_water': parameters.get('shallow_water_color', '#4169E1'),
            'sand': parameters.get('sand_color', '#F4A460'),
            'grass': parameters.get('grass_color', '#228B22'),
            'forest': parameters.get('forest_color', '#228B22'),
            'mountain': parameters.get('mountain_color', '#8B4513'),
            'snow': parameters.get('snow_color', '#FFFFFF'),
            'desert': parameters.get('desert_color', '#DEB887'),
            'contour': parameters.get('contour_color', '#000000')
        }
        
        def hex_to_rgb(hex_color):
            """Convert hex color to RGB tuple."""
            hex_color = hex_color.lstrip('#')
            return tuple(int(hex_color[i:i+2], 16) for i in (0, 2, 4))
        
        # Vectorized noise functions
        def vectorized_noise(x, y):
            """Vectorized coherent noise function."""
            n = (x * 73856093 + y * 19349663 + seed).astype(np.int64) & 0x7fffffff
            n = (n << 13) ^ n
            return ((n * (n * n * 15731 + 789221) + 1376312589) & 0x7fffffff) / 0x7fffffff
        
        def vectorized_smooth_noise(x, y):
            """Vectorized smooth noise using bilinear interpolation."""
            x_int = np.floor(x).astype(int)
            y_int = np.floor(y).astype(int)
            x_frac = x - x_int
            y_frac = y - y_int
            
            v1 = vectorized_noise(x_int, y_int)
            v2 = vectorized_noise(x_int + 1, y_int)
            v3 = vectorized_noise(x_int, y_int + 1)
            v4 = vectorized_noise(x_int + 1, y_int + 1)
            
            i1 = v1 * (1 - x_frac) + v2 * x_frac
            i2 = v3 * (1 - x_frac) + v4 * x_frac
            return i1 * (1 - y_frac) + i2 * y_frac
        
        def vectorized_fractal_noise(x, y, octaves, persistence):
            """Vectorized fractal noise for realistic terrain."""
            total = np.zeros_like(x)
            frequency = 1.0
            amplitude = 1.0
            max_value = 0
            
            for i in range(octaves):
                total += vectorized_smooth_noise(x * frequency, y * frequency) * amplitude
                max_value += amplitude
                amplitude *= persistence
                frequency *= 2
            
            return np.clip(total / max_value, 0, 1)
        
        # Generate map
        w, h = pil_img.size
        img_array = np.array(pil_img)
        
        # Set random seed
        random.seed(seed)
        
        # Pre-calculate island factors for Island map type
        island_factors = None
        if map_type == "Island":
            center_x, center_y = w / 2, h / 2
            max_dist = math.sqrt(center_x**2 + center_y**2)
            island_factors = {}
            for y in range(h):
                for x in range(w):
                    dist = math.sqrt((x - center_x)**2 + (y - center_y)**2)
                    island_factors[(x, y)] = max(0, 1 - dist / max_dist)
        
        # Create coordinate grids for vectorized operations
        x_coords, y_coords = np.meshgrid(np.arange(w), np.arange(h))
        nx_coords = x_coords * scale
        ny_coords = y_coords * scale
        
        # Generate base height using vectorized fractal noise
        base_height = vectorized_fractal_noise(nx_coords, ny_coords, detail, 0.5)
        
        # Generate additional noise layers for more 3D-like terrain
        detail_noise = vectorized_fractal_noise(nx_coords * 4, ny_coords * 4, 2, 0.3) * 0.2
        ridge_noise = vectorized_fractal_noise(nx_coords * 8, ny_coords * 8, 1, 0.2) * 0.1
        
        # Combine noise layers for more realistic terrain
        height = base_height + detail_noise + ridge_noise
        
        # Apply elevation intensity scaling
        height = (height - 0.5) * elevation_intensity + 0.5
        height = np.clip(height, 0, 1)
        
        # Apply map type specific modifications
        if map_type == "Island":
            # Vectorized island factor calculation
            center_x, center_y = w / 2, h / 2
            max_dist = math.sqrt(center_x**2 + center_y**2)
            dist = np.sqrt((x_coords - center_x)**2 + (y_coords - center_y)**2)
            island_factors = np.maximum(0, 1 - dist / max_dist)
            height *= island_factors
        elif map_type == "Archipelago":
            # Vectorized archipelago calculation
            island_centers = [(w * 0.2, h * 0.2), (w * 0.8, h * 0.8), (w * 0.8, h * 0.2), (w * 0.2, h * 0.8)]
            island_factor = np.zeros_like(height)
            for center_x, center_y in island_centers:
                dist = np.sqrt((x_coords - center_x)**2 + (y_coords - center_y)**2)
                island_factor = np.maximum(island_factor, np.maximum(0, 1 - dist / (w * 0.15)))
            height *= island_factor
        elif map_type == "Desert":
            # Vectorized desert modifications
            height = height * 0.7 + 0.1
            dune_noise = vectorized_fractal_noise(nx_coords * 3, ny_coords * 3, 3, 0.4) * 0.3
            height += dune_noise
        elif map_type == "Snow":
            # Vectorized snow modifications
            height = height * 0.8 + 0.2
            snow_noise = vectorized_fractal_noise(nx_coords * 2, ny_coords * 2, 2, 0.5) * 0.4
            height += snow_noise
        elif map_type == "Jungle":
            # Vectorized jungle modifications
            height = height * 0.6 + 0.2
            jungle_noise = vectorized_fractal_noise(nx_coords * 5, ny_coords * 5, 4, 0.3) * 0.3
            height += jungle_noise
        elif map_type == "Ocean":
            # Vectorized ocean modifications
            height = height * 0.5
            ocean_noise = vectorized_fractal_noise(nx_coords * 2, ny_coords * 2, 3, 0.4) * 0.3
            height += ocean_noise
        
        # Generate biome variation
        biome_noise = vectorized_fractal_noise(nx_coords * 2, ny_coords * 2, 2, 0.5)
        moisture_noise = vectorized_fractal_noise(nx_coords * 3, ny_coords * 3, 2, 0.4)
        
        # Create color map using vectorized operations
        color_map = np.zeros((h, w, 3), dtype=np.uint8)
        
        # Vectorized terrain type determination
        if map_type == "Ocean":
            # Ocean floor biomes
            deep_water_mask = height < 0.2
            shallow_water_mask = (height >= 0.2) & (height < 0.4)
            underwater_plains_mask = (height >= 0.4) & (height < 0.6)
            underwater_mountains_mask = height >= 0.6
            
            color_map[deep_water_mask] = hex_to_rgb(colors['deep_water'])
            color_map[shallow_water_mask] = hex_to_rgb(colors['shallow_water'])
            color_map[underwater_plains_mask] = hex_to_rgb('#2F4F4F')
            color_map[underwater_mountains_mask] = hex_to_rgb('#4682B4')
            
        elif map_type == "Desert":
            # Desert biomes
            sand_mask = height < 0.3
            desert_plains_mask = (height >= 0.3) & (height < 0.6)
            oasis_mask = desert_plains_mask & (moisture_noise > 0.7)
            desert_mountains_mask = height >= 0.6
            
            color_map[sand_mask] = hex_to_rgb(colors['sand'])
            color_map[desert_plains_mask] = hex_to_rgb(colors['desert'])
            color_map[oasis_mask] = hex_to_rgb('#8FBC8F')
            color_map[desert_mountains_mask] = hex_to_rgb('#CD853F')
            
        elif map_type == "Snow":
            # Snow biomes
            snow_mask = height < 0.4
            snow_plains_mask = (height >= 0.4) & (height < 0.7)
            frozen_lakes_mask = snow_plains_mask & (moisture_noise > 0.6)
            ice_mountains_mask = height >= 0.7
            
            color_map[snow_mask] = hex_to_rgb(colors['snow'])
            color_map[snow_plains_mask] = hex_to_rgb('#F0F8FF')
            color_map[frozen_lakes_mask] = hex_to_rgb('#87CEEB')
            color_map[ice_mountains_mask] = hex_to_rgb('#B0C4DE')
            
        elif map_type == "Jungle":
            # Jungle biomes
            jungle_low_mask = height < 0.3
            jungle_plains_mask = (height >= 0.3) & (height < 0.6)
            dense_jungle_mask = jungle_plains_mask & (moisture_noise > 0.5)
            jungle_mountains_mask = height >= 0.6
            
            color_map[jungle_low_mask] = hex_to_rgb('#228B22')
            color_map[jungle_plains_mask] = hex_to_rgb('#32CD32')
            color_map[dense_jungle_mask] = hex_to_rgb('#006400')
            color_map[jungle_mountains_mask] = hex_to_rgb('#556B2F')
            
        else:
            # Standard terrain (Minecraft, Island, Continental, etc.) with elevation controls
            # Calculate elevation thresholds based on parameters
            deep_water_threshold = sea_level * 0.5
            shallow_water_threshold = sea_level
            sand_threshold = sea_level + 0.1
            grass_threshold = sea_level + 0.3
            hill_threshold = sea_level + 0.4 + (0.3 * hill_prominence)
            mountain_threshold = sea_level + 0.6 + (0.3 * mountain_height)
            snow_threshold = sea_level + 0.8 + (0.2 * mountain_height)
            
            deep_water_mask = height < deep_water_threshold
            shallow_water_mask = (height >= deep_water_threshold) & (height < shallow_water_threshold)
            sand_mask = (height >= shallow_water_threshold) & (height < sand_threshold)
            grass_mask = (height >= sand_threshold) & (height < grass_threshold) & (biome_noise <= 0.6)
            forest_mask = (height >= sand_threshold) & (height < grass_threshold) & (biome_noise > 0.6)
            hills_mask = (height >= grass_threshold) & (height < hill_threshold)
            mountains_mask = (height >= hill_threshold) & (height < mountain_threshold)
            snow_mask = height >= snow_threshold
            
            color_map[deep_water_mask] = hex_to_rgb(colors['deep_water'])
            color_map[shallow_water_mask] = hex_to_rgb(colors['shallow_water'])
            color_map[sand_mask] = hex_to_rgb(colors['sand'])
            color_map[grass_mask] = hex_to_rgb(colors['grass'])
            color_map[forest_mask] = hex_to_rgb(colors['forest'])
            color_map[hills_mask] = hex_to_rgb('#8B7355')
            color_map[mountains_mask] = hex_to_rgb(colors['mountain'])
            color_map[snow_mask] = hex_to_rgb(colors['snow'])
        
        # Handle elevation modes
        if elevation_mode == 'Height Map':
            # Convert height to grayscale for height map visualization
            height_normalized = (height * 255).astype(np.uint8)
            color_map = np.stack([height_normalized] * 3, axis=2)
        elif elevation_mode == 'Contour Lines':
            # Generate contour lines
            contour_color_rgb = hex_to_rgb(colors['contour'])
            contour_thickness = 1
            
            # Create contour lines at regular intervals
            contour_levels = np.arange(0, 1, contour_spacing)
            for level in contour_levels:
                # Find pixels close to the contour level
                contour_mask = np.abs(height - level) < 0.02
                color_map[contour_mask] = contour_color_rgb
        
        # Add contour lines overlay if enabled
        if show_contours and elevation_mode == 'Normal':
            contour_color_rgb = hex_to_rgb(colors['contour'])
            contour_thickness = 1
            
            # Create contour lines at regular intervals
            contour_levels = np.arange(0, 1, contour_spacing)
            for level in contour_levels:
                # Find pixels close to the contour level
                contour_mask = np.abs(height - level) < 0.02
                # Only draw contours on land (not water)
                land_mask = height > sea_level
                final_contour_mask = contour_mask & land_mask
                color_map[final_contour_mask] = contour_color_rgb
        
        # Apply temperature and humidity effects with gradual transitions
        # Temperature effects - gradual snow coverage based on height and temperature
        if temperature < 0.5:  # Cold to moderate
            # Calculate snow probability based on temperature and height
            snow_probability = (0.5 - temperature) * 2.0  # 0 at 0.5 temp, 1 at 0 temp
            snow_height_threshold = 0.4 + (0.5 - temperature) * 0.4  # Lower threshold for colder temps
            
            # Apply snow to high elevations with probability
            high_elevation_mask = height > snow_height_threshold
            snow_mask = high_elevation_mask & (np.random.random(height.shape) < snow_probability)
            color_map[snow_mask] = hex_to_rgb(colors['snow'])
            
            # Gradual transition to snow for very cold temperatures
            if temperature < 0.2:
                cold_plains_mask = (height > 0.3) & (height < snow_height_threshold)
                color_map[cold_plains_mask] = hex_to_rgb('#E6E6FA')  # Light lavender for cold plains
                
        elif temperature > 0.6:  # Hot to very hot
            # Calculate desert probability based on temperature and humidity
            desert_probability = (temperature - 0.6) * 2.5  # 0 at 0.6 temp, 1 at 1.0 temp
            humidity_factor = max(0, 1 - humidity)  # Higher humidity reduces desert probability
            
            # Apply desert to low elevations with probability
            low_elevation_mask = (height < 0.6) & (height > 0.2)
            desert_mask = low_elevation_mask & (np.random.random(height.shape) < desert_probability * humidity_factor)
            color_map[desert_mask] = hex_to_rgb(colors['desert'])
            
            # Gradual transition to arid conditions
            if temperature > 0.8 and humidity < 0.4:
                arid_mask = (height < 0.5) & (height > 0.2)
                color_map[arid_mask] = hex_to_rgb('#DEB887')  # Burlywood for arid plains
        
        # Add 3D-like shading based on height and slope (simplified for speed)
        # Calculate gradient for shading
        grad_x = np.gradient(height, axis=1)
        grad_y = np.gradient(height, axis=0)
        slope = np.sqrt(grad_x**2 + grad_y**2)
        shade_factor = 1.0 - slope * 0.3
        shade_factor = np.clip(shade_factor, 0.7, 1.3)
        
        # Apply shading
        shade_factor_3d = np.stack([shade_factor] * 3, axis=2)
        color_map = np.clip(color_map * shade_factor_3d, 0, 255).astype(np.uint8)
        
        # Set the result
        img_array[:, :, :3] = color_map
        img_array[:, :, 3] = 255  # Full alpha
        
        return img_array
    
    def _apply_texture_2d_effect(self, pil_img, parameters, frame_idx=0):
        """Apply 2D texture creation effect with frame animation support."""
        from core.texture_utils import generate_block_texture_qimage
        
        # Get parameters
        texture_type = parameters.get('texture_type', 'None')
        block_size = parameters.get('block_size', 4)
        opacity = parameters.get('opacity', 255)
        color1 = parameters.get('color1', '#8B4513')
        color2 = parameters.get('color2', '#A0522D')
        seed = parameters.get('seed', 42)
        use_custom_size = parameters.get('use_custom_size', False)
        custom_width = parameters.get('custom_width', 64)
        custom_height = parameters.get('custom_height', 64)
        use_custom_position = parameters.get('use_custom_position', False)
        position_x = parameters.get('position_x', 0)
        position_y = parameters.get('position_y', 0)
        texture_mode = parameters.get('texture_mode', 'Static')
        animation_speed = parameters.get('animation_speed', 5)
        
        # Get canvas dimensions
        canvas_width, canvas_height = pil_img.size
        
        # Determine texture dimensions
        if use_custom_size:
            texture_width = custom_width
            texture_height = custom_height
        else:
            texture_width = canvas_width
            texture_height = canvas_height
        
        # Determine if we should use animation (for Static mode, only animate if texture_type supports it)
        # For Animated mode, this is handled separately in main_window._handle_animated_texture_creation
        if texture_mode == 'Animated' and texture_type != 'None':
            # Use the texture type as animation type
            anim_type = texture_type
        else:
            anim_type = None
        
        # Calculate animation time based on frame index and speed
        speed_multipliers = {
            1: 0.5, 2: 0.8, 3: 1.0, 4: 1.5, 5: 2.0,
            6: 3.0, 7: 4.0, 8: 5.0, 9: 7.0, 10: 10.0
        }
        time_step = speed_multipliers.get(animation_speed, 2.0)
        animation_time = frame_idx * time_step
        
        # Generate texture with animation time
        texture = generate_block_texture_qimage(
            texture_width, texture_height, [color1, color2], block_size, 255,  # Force 100% opacity
            texture_type, None, animation_time, seed
        )
        
        # Convert QImage to numpy array
        texture_array = self._qimage_to_numpy(texture)
        
        # If using custom position, create a canvas-sized result and place texture at position
        if use_custom_position:
            # Create a canvas-sized array with transparency
            result = np.zeros((canvas_height, canvas_width, 4), dtype=np.uint8)
            
            # Calculate position bounds
            end_x = min(position_x + texture_width, canvas_width)
            end_y = min(position_y + texture_height, canvas_height)
            start_x = max(position_x, 0)
            start_y = max(position_y, 0)
            
            # Calculate texture bounds
            tex_start_x = max(0, -position_x)
            tex_start_y = max(0, -position_y)
            tex_end_x = min(texture_width, canvas_width - position_x)
            tex_end_y = min(texture_height, canvas_height - position_y)
            
            # Copy texture to result at specified position
            if tex_end_x > tex_start_x and tex_end_y > tex_start_y:
                result[start_y:end_y, start_x:end_x] = texture_array[tex_start_y:tex_end_y, tex_start_x:tex_end_x]
            
            return result
        else:
            # If not using custom position, return the texture as-is
            return texture_array
    
    def _qimage_to_numpy(self, qimage):
        """Convert QImage to numpy array."""
        from PySide6.QtGui import QImage
        if qimage.format() != QImage.Format_RGBA8888:
            qimage = qimage.convertToFormat(QImage.Format_RGBA8888)
        
        width = qimage.width()
        height = qimage.height()
        
        # Get the image data as bytes
        ptr = qimage.bits()
        arr = np.frombuffer(ptr, np.uint8).reshape((height, width, 4))
        
        # Ensure we have a copy to avoid memory issues
        return arr.copy()
    
    def _toggle_custom_size_visibility(self, enabled):
        """Show/hide custom size parameters."""
        if 'custom_width' in self.param_widgets:
            self.param_widgets['custom_width'].setVisible(enabled)
        if 'custom_height' in self.param_widgets:
            self.param_widgets['custom_height'].setVisible(enabled)
        if 'custom_width_text' in self.param_widgets:
            self.param_widgets['custom_width_text'].setVisible(enabled)
        if 'custom_height_text' in self.param_widgets:
            self.param_widgets['custom_height_text'].setVisible(enabled)
    
    def _toggle_custom_position_visibility(self, enabled):
        """Show/hide custom position parameters."""
        if 'position_x' in self.param_widgets:
            self.param_widgets['position_x'].setVisible(enabled)
        if 'position_y' in self.param_widgets:
            self.param_widgets['position_y'].setVisible(enabled)
        if 'position_x_text' in self.param_widgets:
            self.param_widgets['position_x_text'].setVisible(enabled)
        if 'position_y_text' in self.param_widgets:
            self.param_widgets['position_y_text'].setVisible(enabled)
    
    def _toggle_animation_visibility(self, enabled):
        """Show/hide animation parameters."""
        if 'animation_speed' in self.param_widgets:
            self.param_widgets['animation_speed'].setVisible(enabled)
    
    def _toggle_texture_mode_visibility(self, mode):
        """Show/hide animation_frames based on texture_mode (Static/Animated)."""
        if 'animation_frames' in self.param_widgets:
            # Show animation_frames only when Animated is selected
            self.param_widgets['animation_frames'].setVisible(mode == 'Animated')
        if 'animation_speed' in self.param_widgets:
            # Show animation_speed only when Animated is selected
            self.param_widgets['animation_speed'].setVisible(mode == 'Animated')
    
    def _sync_slider_to_text(self, text_widget_name, value):
        """Sync slider value to textbox."""
        if text_widget_name in self.param_widgets:
            self.param_widgets[text_widget_name].set_value(str(value))
    
    def _sync_text_to_slider(self, slider_widget_name, text_value):
        """Sync textbox value to slider."""
        try:
            value = int(text_value)
            if slider_widget_name in self.param_widgets:
                # Get the slider's range to validate the value
                slider = self.param_widgets[slider_widget_name]
                if hasattr(slider, 'slider'):
                    min_val = slider.slider.minimum()
                    max_val = slider.slider.maximum()
                    value = max(min_val, min(max_val, value))
                    # Temporarily disconnect the slider's signal to prevent feedback loop
                    slider.slider.valueChanged.disconnect()
                    slider.set_value(value)
                    # Reconnect the signal
                    slider.slider.valueChanged.connect(lambda val: slider.value_changed.emit(val))
        except ValueError:
            pass  # Ignore invalid text input
    
    def _apply_generate_lod_effect(self, pil_img, parameters):
        """Apply LOD (Level of Detail) generation effect."""
        from PIL import Image, ImageFilter
        
        # Get parameters
        lod_level = parameters.get('lod_level', 2)
        method = parameters.get('method', 'Box Downsample')
        preserve_alpha = parameters.get('preserve_alpha', True)
        export_only = parameters.get('export_only', False)
        
        # Calculate new dimensions
        original_width, original_height = pil_img.size
        new_width = max(1, original_width // lod_level)
        new_height = max(1, original_height // lod_level)
        
        # Apply different downsampling methods
        if method == 'Box Downsample':
            # Simple box downsampling
            resized_img = pil_img.resize((new_width, new_height), Image.Resampling.BOX)
        elif method == 'Gaussian Blur':
            # Apply Gaussian blur then resize
            blurred_img = pil_img.filter(ImageFilter.GaussianBlur(radius=lod_level * 0.5))
            resized_img = blurred_img.resize((new_width, new_height), Image.Resampling.LANCZOS)
        elif method == 'Bilinear':
            # Bilinear interpolation
            resized_img = pil_img.resize((new_width, new_height), Image.Resampling.BILINEAR)
        elif method == 'Nearest Neighbor':
            # Nearest neighbor (pixelated)
            resized_img = pil_img.resize((new_width, new_height), Image.Resampling.NEAREST)
        else:
            # Default to box downsampling
            resized_img = pil_img.resize((new_width, new_height), Image.Resampling.BOX)
        
        # Handle alpha channel
        if preserve_alpha and resized_img.mode == 'RGBA':
            # Ensure alpha channel is preserved
            pass  # Already handled by PIL
        elif not preserve_alpha and resized_img.mode == 'RGBA':
            # Convert to RGB if alpha preservation is disabled
            resized_img = resized_img.convert('RGB')
        
        # If export_only is True, we'll handle the export in the dialog
        # For now, just return the processed image
        return np.array(resized_img)

    def _apply_atmospheric_lighting_effect(self, pil_img, parameters):
        """Apply advanced Atmospheric Lighting effect with intelligent light source detection."""
        from PIL import Image, ImageEnhance, ImageFilter
        import numpy as np
        import cv2
        from .atmospheric_lighting_helpers import AtmosphericLightingSystem, LightSource
        
        # BATCH 2 OPTIMIZATION: Downscale for preview to speed up processing
        # Atmospheric lighting with light detection can be very slow on large images
        if pil_img.mode != 'RGBA':
            pil_img = pil_img.convert('RGBA')
        pil_img, original_size, was_downscaled = self._prepare_preview_image(pil_img, max_preview_size=400)
        
        # Get parameters with defaults
        use_defaults = parameters.get('use_defaults', True)
        auto_detect_lights = parameters.get('auto_detect_lights', True)
        manual_lights = parameters.get('manual_lights', [])
        style_preset = parameters.get('style_preset', 'Natural Lighting')
        
        # Convert PIL to numpy for processing
        if hasattr(pil_img, 'shape'):
            # Already a numpy array
            img_array = pil_img
        else:
            # PIL Image object
            img_array = np.array(pil_img)
        height, width = img_array.shape[:2]
        
        # Create atmospheric lighting system
        lighting_system = AtmosphericLightingSystem(img_array.shape)
        
        # Apply preset configurations when preset changes
        if style_preset != 'Custom':
            preset_configs = self._get_lighting_preset_configs(style_preset)
            # Only update parameters that haven't been explicitly set by user
            for key, value in preset_configs.items():
                if key not in parameters:
                    parameters[key] = value
        
        # Step 1: Detect or create light sources
        light_sources = []
        
        if auto_detect_lights:
            # Simple and effective light source detection
            detection_params = {
                'threshold_percentile': 75,  # Brightest 25% of pixels - much more lenient
                'min_light_area': 5,  # Very small minimum area
                'contrast_threshold': 2,  # Very low contrast threshold
                'merge_distance': 30  # Merge nearby lights
            }
            
            detected_lights = lighting_system.detect_light_sources(img_array, detection_params)
            light_sources.extend(detected_lights)
            
            # Debug output for detected lights
            print(f"DEBUG: Detection params - percentile: 75, min_area: 5, contrast: 5")
            print(f"DEBUG: Detected {len(detected_lights)} light sources:")
            for i, light in enumerate(detected_lights):
                print(f"  Light {i+1}: pos=({light.x},{light.y}), radius={light.radius:.1f}, intensity={light.intensity:.2f}")
            
            # If too many lights detected, be more selective
            if len(light_sources) > 10:
                # Sort by intensity and keep only the brightest ones
                light_sources.sort(key=lambda x: x.intensity, reverse=True)
                light_sources = light_sources[:5]  # Keep only top 5 brightest
                print(f"DEBUG: Limited to top 5 brightest lights")
        
        # Add manual light sources
        for manual_light in manual_lights:
            light = LightSource(
                x=int(width * manual_light.get('x', 50) / 100),
                y=int(height * manual_light.get('y', 50) / 100),
                radius=manual_light.get('radius', 100),
                intensity=manual_light.get('intensity', 1.0),
                color=manual_light.get('color', '#FFFFFF'),
                light_type=manual_light.get('type', 'point')
            )
            light.falloff_exponent = manual_light.get('falloff_exponent', 2.0)
            light.flicker_amount = manual_light.get('flicker_amount', 0.0)
            light_sources.append(light)
        
        # Only create default light if auto-detect is enabled but no lights found
        if not light_sources and auto_detect_lights:
            print("DEBUG: Auto-detect enabled but no lights found, using ambient-only lighting")
            # Don't create artificial lights - just use ambient lighting
        
        # Step 2: Create lighting map
        falloff_type = parameters.get('falloff_type', 'quadratic')
        global_intensity = parameters.get('global_intensity', 1.0)
        lighting_map = lighting_system.create_lighting_map(light_sources, falloff_type, global_intensity)
        
        # Step 3: Create shadow map
        shadow_params = {
            'enable_shadows': parameters.get('enable_shadows', True),
            'shadow_softness': parameters.get('shadow_softness', 1.5),
            'shadow_darkness': parameters.get('shadow_darkness', 0.7),
            'shadow_length': parameters.get('shadow_length', 200)
        }
        shadow_map = lighting_system.create_shadow_map(light_sources, shadow_params)
        
        # Step 4: Apply atmospheric effects
        atmosphere_params = {
            'atmosphere_density': parameters.get('atmosphere_density', 0),
            'atmosphere_color': parameters.get('atmosphere_color', '#808080'),
            'atmosphere_distance': parameters.get('atmosphere_distance', 0.5)
        }
        img_with_atmosphere = lighting_system.apply_atmospheric_effects(img_array, atmosphere_params)
        
        # Detect dominant colors for warmth slider
        warmth = parameters.get('warmth', 0.5)
        dominant_colors = self._detect_dominant_colors(img_array)
        warmth_color = self._get_warmth_color(dominant_colors, warmth)
        
        # Step 5: Apply complete lighting system
        ambient_params = {
            'ambient_light': parameters.get('ambient_light', 0.2) * global_intensity,  # Apply intensity to ambient light
            'ambient_color': warmth_color,  # Use warmth-adjusted color
            'brightness_boost': parameters.get('brightness_boost', 1.0),
            'contrast_boost': parameters.get('contrast_boost', 1.0)
        }
        
        # Debug output for key parameters
        print(f"DEBUG: Key parameters - ambient_light: {ambient_params['ambient_light']}, "
              f"global_intensity: {global_intensity}, brightness_boost: {ambient_params['brightness_boost']}, "
              f"contrast_boost: {ambient_params['contrast_boost']}, lights: {len(light_sources)}")
        print(f"DEBUG: Warmth: {warmth}, Warmth color: {warmth_color}")
        
        result = lighting_system.apply_lighting_to_image(
            img_with_atmosphere, lighting_map, shadow_map, ambient_params, shadow_params
        )
        
        # Always show light source highlights when auto-detect is enabled
        if auto_detect_lights and light_sources:
            print(f"DEBUG: Showing light source highlights")
            highlighted_result = lighting_system.create_light_source_highlight(result, light_sources)
            # Ensure we return a numpy array, not a PIL Image
            if hasattr(highlighted_result, 'shape'):
                return highlighted_result
            else:
                return np.array(highlighted_result)
        
        # Ensure we return a numpy array, not a PIL Image
        if hasattr(result, 'shape'):
            return result
        else:
            return np.array(result)
    
    def _detect_dominant_colors(self, img_array):
        """Detect dominant colors in the image for warmth calculation."""
        import cv2
        # Convert to RGB if needed
        if len(img_array.shape) == 3 and img_array.shape[2] == 4:
            rgb_img = img_array[:, :, :3]
        elif len(img_array.shape) == 3:
            rgb_img = img_array
        else:
            rgb_img = cv2.cvtColor(img_array, cv2.COLOR_GRAY2RGB)
        
        # Reshape image to be a list of pixels
        pixels = rgb_img.reshape(-1, 3)
        
        # Sample pixels (every 10th pixel for performance)
        sample_pixels = pixels[::10]
        
        # Calculate average color
        avg_color = np.mean(sample_pixels, axis=0)
        
        return avg_color
    
    def _get_warmth_color(self, dominant_colors, warmth):
        """Get warmth color based on dominant colors and warmth slider."""
        # Convert to int
        avg_r, avg_g, avg_b = dominant_colors.astype(int)
        
        # Interpolate between cool and warm based on warmth slider
        if warmth < 0.5:
            # Cool colors (blue/cyan)
            cool_factor = 1.0 - (warmth * 2)
            r = int(avg_r * (1 - cool_factor * 0.5))
            g = int(avg_g * (1 - cool_factor * 0.3))
            b = int(min(255, avg_b + (255 - avg_b) * cool_factor * 0.5))
        else:
            # Warm colors (orange/red)
            warm_factor = (warmth - 0.5) * 2
            r = int(min(255, avg_r + (255 - avg_r) * warm_factor * 0.6))
            g = int(avg_g + (255 - avg_g) * warm_factor * 0.3)
            b = int(avg_b * (1 - warm_factor * 0.4))
        
        warmth_color = f"#{r:02x}{g:02x}{b:02x}"
        return warmth_color
    
    def _get_lighting_preset_configs(self, preset_name):
        """Get preset configurations for different lighting styles."""
        presets = {
            'Natural Lighting': {
                'ambient_light': 0.3,
                'ambient_color': '#FFE4B5',
                'global_intensity': 1.2,
                'falloff_type': 'quadratic',
                'enable_shadows': True,
                'shadow_softness': 2.0,
                'shadow_darkness': 0.6,
                'atmosphere_density': 0,
                'brightness_boost': 1.1,
                'contrast_boost': 1.1
            },
            'Dramatic Lighting': {
                'ambient_light': 0.15,
                'ambient_color': '#2C2C2C',
                'global_intensity': 1.8,
                'falloff_type': 'exponential',
                'enable_shadows': True,
                'shadow_softness': 1.5,
                'shadow_darkness': 0.8,
                'atmosphere_density': 15,
                'atmosphere_color': '#404040',
                'brightness_boost': 1.3,
                'contrast_boost': 1.4,
                'default_light_intensity': 2.0  # Stronger default light
            },
            'Warm Sunset': {
                'ambient_light': 0.4,
                'ambient_color': '#FF8C00',
                'global_intensity': 1.5,
                'falloff_type': 'quadratic',
                'enable_shadows': True,
                'shadow_softness': 2.5,
                'shadow_darkness': 0.5,
                'atmosphere_density': 20,
                'atmosphere_color': '#FFA500',
                'brightness_boost': 1.2,
                'contrast_boost': 1.2
            },
            'Cool Moonlight': {
                'ambient_light': 0.2,
                'ambient_color': '#B0C4DE',
                'global_intensity': 1.3,
                'falloff_type': 'linear',
                'enable_shadows': True,
                'shadow_softness': 3.0,
                'shadow_darkness': 0.7,
                'atmosphere_density': 10,
                'atmosphere_color': '#708090',
                'brightness_boost': 1.0,
                'contrast_boost': 1.1
            },
            'Mystical Fog': {
                'ambient_light': 0.25,
                'ambient_color': '#E6E6FA',
                'global_intensity': 1.4,
                'falloff_type': 'exponential',
                'enable_shadows': True,
                'shadow_softness': 4.0,
                'shadow_darkness': 0.4,
                'atmosphere_density': 40,
                'atmosphere_color': '#D3D3D3',
                'brightness_boost': 1.1,
                'contrast_boost': 1.0
            },
            'Indoor Ambient': {
                'ambient_light': 0.35,
                'ambient_color': '#F5F5DC',
                'global_intensity': 1.1,
                'falloff_type': 'quadratic',
                'enable_shadows': True,
                'shadow_softness': 1.8,
                'shadow_darkness': 0.6,
                'atmosphere_density': 5,
                'atmosphere_color': '#F0F0F0',
                'brightness_boost': 1.0,
                'contrast_boost': 1.0
            },
            'Cinematic': {
                'ambient_light': 0.1,
                'ambient_color': '#1A1A1A',
                'global_intensity': 2.0,
                'falloff_type': 'inverse_square',
                'enable_shadows': True,
                'shadow_softness': 1.2,
                'shadow_darkness': 0.9,
                'atmosphere_density': 25,
                'atmosphere_color': '#2C2C2C',
                'brightness_boost': 1.5,
                'contrast_boost': 1.6
            }
        }
        
        return presets.get(preset_name, presets['Natural Lighting'])
    
    def _get_default_parameter_value(self, param_name):
        """Get the default value for a parameter from the registry."""
        # This is a simplified version - in practice you'd extract from EFFECT_REGISTRY
        defaults = {
            'brightness_threshold': 220,
            'min_light_area': 25,
            'max_light_area': 800,
            'global_intensity': 1.0,
            'falloff_type': 'quadratic',
            'ambient_light': 0.2,
            'ambient_color': '#404040',
            'enable_shadows': True,
            'shadow_softness': 1.5,
            'shadow_darkness': 0.7,
            'shadow_length': 200,
            'atmosphere_density': 0,
            'atmosphere_color': '#808080',
            'atmosphere_distance': 0.5,
            'brightness_boost': 1.0,
            'contrast_boost': 1.0,
            'default_light_radius': 150,
            'default_light_intensity': 1.5,
            'default_light_color': '#FFE4B5'
        }
        return defaults.get(param_name, None)
    
    def _apply_wind_waker_effect(self, pil_img, parameters):
        """Apply Wind Waker style effect - bright, vibrant, cel-shaded with bold outlines."""
        from PIL import Image, ImageEnhance, ImageFilter
        import numpy as np
        import cv2
        
        # BATCH 2 OPTIMIZATION: Downscale for preview to speed up processing
        # Style effects with multiple passes can be slow on large images
        if pil_img.mode != 'RGBA':
            pil_img = pil_img.convert('RGBA')
        pil_img, original_size, was_downscaled = self._prepare_preview_image(pil_img, max_preview_size=400)
        
        # Get standardized parameters
        base_strength = parameters.get('base_effect_strength', 1.0)
        brightness = parameters.get('brightness', 1.3)
        saturation = parameters.get('saturation', 1.3)
        contrast = parameters.get('contrast', 1.0)
        color_temp = parameters.get('color_temperature', 1.0)
        
        # Base Effect: Cel Shading + Black Outlines + High Posterization
        # Map base_strength to the core WindWaker effects
        cel_levels = int(3 + base_strength * 3)  # 3-6 levels based on strength
        enable_outlines = (base_strength > 0.5)  # Enable outlines at medium+ strength
        posterization_strength = base_strength  # High posterization (color reduction)
        
        # Convert PIL to numpy - ensure we're working with a consistent format
        img_array = np.array(pil_img)
        
        # Simple WindWaker-style cel shading with posterization
        result = self._apply_simple_windwaker(img_array, cel_levels, brightness, saturation, enable_outlines, posterization_strength)
        
        return result.astype(np.uint8)
    
    def _apply_simple_windwaker(self, img_array, cel_levels, brightness, saturation, enable_outlines, posterization=1.0):
        """Simple WindWaker-style cel shading - flat colors, vibrant, no heavy outlines."""
        import cv2
        import numpy as np
        
        # Handle RGBA images
        if len(img_array.shape) == 3 and img_array.shape[2] == 4:
            rgb_img = img_array[:, :, :3]
            alpha_channel = img_array[:, :, 3]
        else:
            rgb_img = img_array
            alpha_channel = None
        
        # Step 1: Apply posterization (reduce colors to flat bands for high posterization effect)
        if posterization < 1.0:
            # Reduce color levels for posterization
            color_levels = int(16 + (posterization * 32))  # 16-48 color levels
            for i in range(3):
                rgb_img[:, :, i] = np.round(rgb_img[:, :, i] / (256.0 / color_levels)) * (256.0 / color_levels)
        
        # Step 2: Apply brightness boost
        result = rgb_img.astype(np.float32) * brightness
        result = np.clip(result, 0, 255)
        
        # Step 2: Boost saturation for vibrant colors (but tone it down)
        hsv = cv2.cvtColor(result.astype(np.uint8), cv2.COLOR_RGB2HSV).astype(np.float32)
        # Use a more gentle saturation boost to prevent oversaturation
        hsv[:, :, 1] = np.clip(hsv[:, :, 1] * (0.5 + saturation * 0.5), 0, 255)
        result = cv2.cvtColor(hsv.astype(np.uint8), cv2.COLOR_HSV2RGB).astype(np.float32)
        
        # Step 3: Apply cel shading (quantize colors to flat bands)
        # Convert to grayscale for cel shading calculation
        gray = cv2.cvtColor(result.astype(np.uint8), cv2.COLOR_RGB2GRAY)
        
        # Create cel shading bands
        step = 255 / (cel_levels - 1)
        cel_bands = np.round(gray / step) * step
        
        # Apply cel shading to each RGB channel
        cel_mask = cel_bands / 255.0
        for i in range(3):
            result[:, :, i] = result[:, :, i] * cel_mask
        
        result = np.clip(result, 0, 255).astype(np.uint8)
        
        # Step 3.5: Apply a gentle bilateral filter AFTER cel shading to smooth band edges (much lighter than before)
        result = cv2.bilateralFilter(result, 9, 30, 30)  # Reduced from 75,75 to 30,30 for sharper result
        
        # Step 4: Add subtle outlines only if enabled (WindWaker doesn't use heavy outlines)
        if enable_outlines:
            # Very subtle edge detection
            gray = cv2.cvtColor(result, cv2.COLOR_RGB2GRAY)
            edges = cv2.Canny(gray, 50, 150)
            
            # Thin outlines
            kernel = np.ones((1, 1), np.uint8)
            edges = cv2.dilate(edges, kernel, iterations=1)
            
            # Apply subtle dark outlines
            outline_mask = edges > 0
            result[outline_mask] = result[outline_mask] * 0.7  # Darken edges slightly
        
        # Step 5: Restore alpha channel if original had one
        if alpha_channel is not None:
            result = np.dstack([result, alpha_channel])
        
        return result
    
    def _apply_ocarina_of_time_effect(self, pil_img, parameters):
        """Apply Ocarina of Time N64-style filter."""
        from PIL import Image, ImageEnhance, ImageFilter
        import numpy as np
        import cv2
        
        # BATCH 2 OPTIMIZATION: Downscale for preview to speed up processing
        if pil_img.mode != 'RGBA':
            pil_img = pil_img.convert('RGBA')
        pil_img, original_size, was_downscaled = self._prepare_preview_image(pil_img, max_preview_size=400)
        
        # Get parameters
        base_strength = parameters.get('base_effect_strength', 1.0)
        
        # Base Effect: Low-Polygon Models + Gouraud Shading + Texture Filtering
        # Map base_strength to the core OOT effects
        enable_polygon = (base_strength > 0.3)
        texture_blur = parameters.get('texture_blur', 1.0 + base_strength * 4.0)  # 1-5 based on strength
        gouraud_shading = base_strength
        
        contrast = parameters.get('contrast', 1.8)
        color_temperature = parameters.get('color_temperature', 1.1)
        fog_amount = parameters.get('fog_amount', 0.6)
        vignette_strength = parameters.get('vignette_strength', 0.7)
        enable_noise = parameters.get('enable_noise', True)
        
        # Convert PIL to numpy
        img_array = np.array(pil_img)
        
        # Apply N64-style processing
        result = self._apply_n64_filter(img_array, texture_blur, contrast, color_temperature, fog_amount, vignette_strength, enable_noise, enable_polygon)
        
        return result.astype(np.uint8)
    
    def _apply_n64_filter(self, img_array, texture_blur, contrast, color_temp, fog_amount, vignette_strength, enable_noise, enable_polygon):
        """Apply N64-style filtering to create Ocarina of Time look."""
        import cv2
        import numpy as np
        
        # Handle RGBA images
        if len(img_array.shape) == 3 and img_array.shape[2] == 4:
            rgb_img = img_array[:, :, :3]
            alpha_channel = img_array[:, :, 3]
        else:
            rgb_img = img_array
            alpha_channel = None
        
        # Step 1: Apply aggressive texture blur/smear (N64 texture filtering signature)
        # Use Gaussian blur to simulate N64's texture filtering
        kernel_size = int(texture_blur * 2) | 1  # Ensure odd number
        result = cv2.GaussianBlur(rgb_img, (kernel_size, kernel_size), texture_blur)
        
        # Step 2: Optional low-polygon look (blocky, angular geometry)
        if enable_polygon:
            # Apply pixelation to create that blocky N64 geometry feel
            h, w = result.shape[:2]
            pixelation_size = 6  # Block size for low-poly look
            downscaled = cv2.resize(result, (w // pixelation_size, h // pixelation_size), interpolation=cv2.INTER_NEAREST)
            result = cv2.resize(downscaled, (w, h), interpolation=cv2.INTER_NEAREST)
        
        # Step 3: Reduce resolution and upscale for aliasing (N64 edge softening)
        # Downscale then upscale to create that soft, diffused look
        scale_factor = 0.7
        h, w = result.shape[:2]
        downscaled = cv2.resize(result, (int(w * scale_factor), int(h * scale_factor)), interpolation=cv2.INTER_LINEAR)
        result = cv2.resize(downscaled, (w, h), interpolation=cv2.INTER_LINEAR)
        
        # Step 3: Apply high contrast with soft shadows
        result = result.astype(np.float32)
        # Increase contrast (make brights brighter, darks darker)
        result = ((result - 128) * contrast) + 128
        result = np.clip(result, 0, 255).astype(np.uint8)
        
        # Step 4: Color temperature adjustment (warm sepia tint)
        result = result.astype(np.float32)
        # Warmer colors: boost red, slightly boost green, reduce blue
        result[:, :, 0] = np.clip(result[:, :, 0] * (1.0 + (color_temp - 1.0) * 0.3), 0, 255)  # Red
        result[:, :, 1] = np.clip(result[:, :, 1] * (1.0 + (color_temp - 1.0) * 0.15), 0, 255)  # Green
        result[:, :, 2] = np.clip(result[:, :, 2] * (1.0 - (color_temp - 1.0) * 0.2), 0, 255)  # Blue
        result = np.clip(result, 0, 255).astype(np.uint8)
        
        # Step 5: Apply distance fog effect
        if fog_amount > 0:
            h, w = result.shape[:2]
            # Create a radial fog mask (more fog in distance)
            y, x = np.ogrid[:h, :w]
            center_x, center_y = w // 2, h // 2
            distance = np.sqrt((x - center_x)**2 + (y - center_y)**2)
            max_distance = np.sqrt(center_x**2 + center_y**2)
            fog_mask = (distance / max_distance) * fog_amount
            
            # Apply fog (blend with white/brown tint for atmosphere)
            fog_color = np.array([200, 190, 175], dtype=np.float32)  # Sepia fog color
            for i in range(3):
                result[:, :, i] = np.clip(
                    result[:, :, i] * (1 - fog_mask) + fog_color[i] * fog_mask, 
                    0, 255
                )
        
        # Step 6: Add N64 noise/grain
        if enable_noise:
            # Add subtle noise
            noise = np.random.normal(0, 8, result.shape).astype(np.float32)
            result = result.astype(np.float32) + noise
            result = np.clip(result, 0, 255).astype(np.uint8)
        
        # Step 6.5: Apply vignette effect (dream/memory/hallucination look)
        if vignette_strength > 0:
            h, w = result.shape[:2]
            # Create a radial gradient from center to edges
            y, x = np.ogrid[:h, :w]
            center_x, center_y = w / 2.0, h / 2.0
            distance = np.sqrt((x - center_x)**2 + (y - center_y)**2)
            max_distance = np.sqrt(center_x**2 + center_y**2)
            
            # Create vignette mask (darker at edges)
            vignette_mask = (distance / max_distance) ** 0.8  # Gradual falloff
            
            # Apply darkening to edges based on vignette strength
            result = result.astype(np.float32)
            # Expand vignette_mask to 3 dimensions to match RGB
            vignette_mask_3d = vignette_mask[:, :, np.newaxis]
            result = result * (1 - vignette_mask_3d * vignette_strength)
            result = np.clip(result, 0, 255).astype(np.uint8)
        
        # Step 7: Subtle desaturation (OOT's muted palette)
        hsv = cv2.cvtColor(result, cv2.COLOR_RGB2HSV).astype(np.float32)
        hsv[:, :, 1] = hsv[:, :, 1] * 0.85  # Slight desaturation
        result = cv2.cvtColor(hsv.astype(np.uint8), cv2.COLOR_HSV2RGB)
        
        # Step 8: Restore alpha channel if original had one
        if alpha_channel is not None:
            result = np.dstack([result, alpha_channel])
        
        return result
    
    def _apply_luigis_mansion_effect(self, pil_img, parameters):
        """Apply Luigi's Mansion atmospheric lighting effect."""
        from PIL import Image, ImageEnhance, ImageFilter
        import numpy as np
        import cv2
        
        # BATCH 2 OPTIMIZATION: Downscale for preview to speed up processing
        if pil_img.mode != 'RGBA':
            pil_img = pil_img.convert('RGBA')
        pil_img, original_size, was_downscaled = self._prepare_preview_image(pil_img, max_preview_size=400)
        
        # Get parameters
        base_strength = parameters.get('base_effect_strength', 1.0)
        
        # Base Effect: Real-Time Lighting + Volumetric Lighting + Eerie Color Palette
        # Map base_strength to the core Luigi's Mansion effects
        realtime_lighting = base_strength  # Real-time lighting strength
        volumetric_strength = base_strength  # Volumetric lighting/atmosphere
        eerie_palette = base_strength  # Eerie color palette strength
        
        ambient_darkness = parameters.get('ambient_darkness', 0.0) * base_strength
        flashlight_intensity = parameters.get('flashlight_intensity', 0.3) * base_strength
        light_warmth = parameters.get('light_warmth', 1.5)
        dust_haze = parameters.get('dust_haze', 0.5) * base_strength
        desaturation = parameters.get('desaturation', 0.4) * base_strength
        enable_glow = parameters.get('enable_glow', False)
        
        # Convert PIL to numpy
        img_array = np.array(pil_img)
        
        # Apply Luigi's Mansion atmospheric effect
        result = self._apply_mansion_filter(img_array, ambient_darkness, flashlight_intensity, light_warmth, dust_haze, desaturation, enable_glow)
        
        return result.astype(np.uint8)
    
    def _apply_mansion_filter(self, img_array, ambient_dark, flashlight_int, light_warm, dust, desat, glow):
        """Apply Luigi's Mansion GameCube-style filtering - adjusts existing image to match the game's look."""
        import cv2
        import numpy as np
        
        # Handle RGBA images
        if len(img_array.shape) == 3 and img_array.shape[2] == 4:
            rgb_img = img_array[:, :, :3]
            alpha_channel = img_array[:, :, 3]
        else:
            rgb_img = img_array
            alpha_channel = None
        
        result = rgb_img.astype(np.float32)
        
        # Step 1: Medium-poly GameCube-era smoothing (cleaner than N64, soft but not perfect)
        result = cv2.bilateralFilter(result.astype(np.uint8), 9, 60, 60).astype(np.float32)
        
        # Step 2: Desaturate for muted, aged mansion palette (preserve color info)
        hsv = cv2.cvtColor(result.astype(np.uint8), cv2.COLOR_RGB2HSV).astype(np.float32)
        hsv[:, :, 1] = hsv[:, :, 1] * (1 - desat * 0.4)  # Moderate desaturation for aged look
        result = cv2.cvtColor(hsv.astype(np.uint8), cv2.COLOR_HSV2RGB).astype(np.float32)
        
        # Step 3: Apply cool blue-green ambient darkness (subtler, preserve highlights)
        result = result * (1 - ambient_dark * 0.3)  # Less aggressive darkening
        
        # Cool blue-green tint for ambient darkness (more subtle)
        result[:, :, 0] = np.clip(result[:, :, 0] * 0.95, 0, 255)  # Slight red reduction
        result[:, :, 1] = np.clip(result[:, :, 1] * 1.02, 0, 255)  # Minimal green boost
        result[:, :, 2] = np.clip(result[:, :, 2] * 1.08, 0, 255)  # Slight blue boost
        
        result = np.clip(result, 0, 255).astype(np.uint8)
        
        # Step 4: Warm accents in bright areas (flashlight-like effect on existing highlights)
        hsv = cv2.cvtColor(result, cv2.COLOR_RGB2HSV).astype(np.float32)
        brightness = hsv[:, :, 2]
        
        # Apply warm yellow/orange tint to bright areas (not creating light, adjusting existing)
        warmth_mask = (brightness / 255.0) ** 2  # Quadratic for stronger bright area effect
        warmth_amount = warmth_mask * light_warm
        
        result = result.astype(np.float32)
        # Boost yellow/orange in bright areas
        result[:, :, 0] = np.clip(result[:, :, 0] * (1 + warmth_amount * 0.4), 0, 255)  # Red boost
        result[:, :, 1] = np.clip(result[:, :, 1] * (1 + warmth_amount * 0.2), 0, 255)  # Green boost
        result[:, :, 2] = np.clip(result[:, :, 2] * (1 - warmth_amount * 0.3), 0, 255)  # Blue reduction
        result = np.clip(result, 0, 255).astype(np.uint8)
        
        # Step 5: Subtle atmospheric haze/dust
        if dust > 0:
            result = result.astype(np.float32)
            # Apply subtle radial fog for distance haze
            h, w = result.shape[:2]
            y, x = np.ogrid[:h, :w]
            center_x, center_y = w // 2, h // 2
            distance = np.sqrt((x - center_x)**2 + (y - center_y)**2)
            max_distance = np.sqrt(center_x**2 + center_y**2)
            haze_mask = (distance / max_distance) ** 1.5 * dust  # More pronounced at edges
            
            # Light fog color
            fog_color = np.array([235, 230, 225], dtype=np.float32)
            haze_mask_3d = haze_mask[:, :, np.newaxis]
            result = result * (1 - haze_mask_3d * 0.15) + fog_color * haze_mask_3d * 0.15
            result = np.clip(result, 0, 255).astype(np.uint8)
        
        # Step 6: Enhanced contrast (deep shadows, velvety edges) - preserve existing shadows
        result = result.astype(np.float32)
        contrast_amount = 1.1 + flashlight_int * 0.4  # Moderate contrast enhancement
        result = ((result - 128) * contrast_amount) + 128
        result = np.clip(result, 0, 255).astype(np.uint8)
        
        # Step 7: Subtle bloom/glow on bright sources (existing highlights)
        if flashlight_int > 0.5:
            # Apply subtle glow to bright areas
            hsv = cv2.cvtColor(result, cv2.COLOR_RGB2HSV).astype(np.float32)
            brightness = hsv[:, :, 2]
            
            # Boost brightness of very bright areas slightly (bloom effect)
            bloom_mask = np.where(brightness > 180, 1.1, 1.0)
            hsv[:, :, 2] = np.clip(hsv[:, :, 2] * bloom_mask, 0, 255)
            result = cv2.cvtColor(hsv.astype(np.uint8), cv2.COLOR_HSV2RGB)
        
        # Step 8: Ectoplasmic glow - boost saturation of bright, colorful areas (ghosts, etc.)
        if glow:
            hsv = cv2.cvtColor(result, cv2.COLOR_RGB2HSV).astype(np.float32)
            brightness = hsv[:, :, 2]
            saturation = hsv[:, :, 1]
            
            # Boost saturation of bright and already somewhat saturated areas
            glow_mask = np.where((brightness > 120) & (saturation > 60), 2.0, 1.0)
            hsv[:, :, 1] = np.clip(hsv[:, :, 1] * glow_mask, 0, 255)
            
            result = cv2.cvtColor(hsv.astype(np.uint8), cv2.COLOR_HSV2RGB)
        
        # Step 9: Subtle edge anti-aliasing (soft but not perfect GameCube-era edges)
        result = cv2.bilateralFilter(result, 5, 30, 30)
        
        # Step 10: Texture enhancement - aged/dusty feel for Luigi's Mansion textures
        # Apply subtle darkening to shadowed areas to create that "aged grime" look
        hsv = cv2.cvtColor(result, cv2.COLOR_RGB2HSV).astype(np.float32)
        brightness = hsv[:, :, 2]
        
        # Darken mid-tones slightly for aged texture feel (deepens grooves/crevices)
        darkness_curve = np.where(brightness < 128, 0.85, 1.0)  # Darken shadows slightly
        hsv[:, :, 2] = np.clip(hsv[:, :, 2] * darkness_curve, 0, 255)
        result = cv2.cvtColor(hsv.astype(np.uint8), cv2.COLOR_HSV2RGB)
        
        # Step 11: Restore alpha channel if original had one
        if alpha_channel is not None:
            result = np.dstack([result, alpha_channel])
        
        return result
    
    def _apply_eternal_darkness_effect(self, pil_img, parameters):
        """Apply Eternal Darkness sanity effects with pre-rendered lighting and volumetric fog."""
        from PIL import Image, ImageEnhance, ImageFilter
        import numpy as np
        import cv2
        
        # BATCH 2 OPTIMIZATION: Downscale for preview to speed up processing
        if pil_img.mode != 'RGBA':
            pil_img = pil_img.convert('RGBA')
        pil_img, original_size, was_downscaled = self._prepare_preview_image(pil_img, max_preview_size=400)
        
        # Get parameters
        base_strength = parameters.get('base_effect_strength', 1.0)
        brightness = parameters.get('brightness', 1.0)
        saturation = parameters.get('saturation', 0.5)
        contrast = parameters.get('contrast', 1.5)
        color_temp = parameters.get('color_temperature', 0.8)
        blur = parameters.get('blur_sharpness', 0.3)
        noise = parameters.get('noise_grain', 0.4)
        
        # Base Effect: Dynamic Sanity Filters + Pre-Rendered Lighting + Volumetric Fog
        sanity_intensity = parameters.get('sanity_effect_intensity', 0.6)
        lighting_depth = parameters.get('lighting_depth', 1.5)
        fog_amount = parameters.get('volumetric_fog', 0.7)
        enable_inversion = parameters.get('enable_color_inversion', False)
        enable_sepia = parameters.get('enable_sepia', False)
        enable_tilt = parameters.get('enable_screen_tilt', False)
        
        # Convert PIL to numpy
        img_array = np.array(pil_img)
        
        # Apply Eternal Darkness effects
        result = self._apply_eternal_darkness_filter(
            img_array, base_strength, brightness, saturation, contrast, color_temp, blur, noise,
            sanity_intensity, lighting_depth, fog_amount, enable_inversion, enable_sepia, enable_tilt
        )
        
        return result.astype(np.uint8)
    
    def _apply_eternal_darkness_filter(self, img_array, base_str, bright, sat, contr, temp, blur, noise_val,
                                        sanity_int, lighting, fog, inv, sep, tilt):
        """Apply Eternal Darkness survival horror filtering with sanity effects."""
        import cv2
        import numpy as np
        
        # Handle RGBA images
        if len(img_array.shape) == 3 and img_array.shape[2] == 4:
            rgb_img = img_array[:, :, :3]
            alpha_channel = img_array[:, :, 3]
        else:
            rgb_img = img_array
            alpha_channel = None
        
        result = rgb_img.astype(np.float32)
        
        # Step 1: Apply high-contrast pre-rendered lighting (deep shadows)
        result = result * bright
        result = ((result - 128) * contr * lighting) + 128
        result = np.clip(result, 0, 255).astype(np.uint8)
        
        # Step 2: Desaturate for survival horror aesthetic
        hsv = cv2.cvtColor(result, cv2.COLOR_RGB2HSV).astype(np.float32)
        hsv[:, :, 1] = hsv[:, :, 1] * sat
        result = cv2.cvtColor(hsv.astype(np.uint8), cv2.COLOR_HSV2RGB).astype(np.float32)
        
        # Step 3: Apply cool, eerie color temperature (toward blue/green)
        result[:, :, 0] = np.clip(result[:, :, 0] * 0.9, 0, 255)  # Reduce red
        result[:, :, 1] = np.clip(result[:, :, 1] * 1.05, 0, 255)  # Slight green
        result[:, :, 2] = np.clip(result[:, :, 2] * (1.0 + temp * 0.2), 0, 255)  # Boost blue
        result = np.clip(result, 0, 255).astype(np.uint8)
        
        # Step 4: Add volumetric fog (dense, layered)
        if fog > 0:
            h, w = result.shape[:2]
            y, x = np.ogrid[:h, :w]
            center_x, center_y = w // 2, h // 2
            distance = np.sqrt((x - center_x)**2 + (y - center_y)**2)
            max_distance = np.sqrt(center_x**2 + center_y**2)
            fog_mask = (distance / max_distance) ** 2 * fog
            
            # Pale blue fog color
            fog_color = np.array([200, 210, 220], dtype=np.float32)
            fog_mask_3d = fog_mask[:, :, np.newaxis]
            result = result.astype(np.float32)
            result = result * (1 - fog_mask_3d * 0.4) + fog_color * fog_mask_3d * 0.4
            result = np.clip(result, 0, 255).astype(np.uint8)
        
        # Step 5: Sanity effects (psychological horror distortions)
        if sanity_int > 0:
            if sep:
                # Sepia tone filter
                result = result.astype(np.float32)
                # Apply sepia formula
                result[:, :, 0] = np.clip(result[:, :, 0] * 0.393 + result[:, :, 1] * 0.769 + result[:, :, 2] * 0.189, 0, 255)
                result[:, :, 1] = np.clip(result[:, :, 0] * 0.349 + result[:, :, 1] * 0.686 + result[:, :, 2] * 0.168, 0, 255)
                result[:, :, 2] = np.clip(result[:, :, 0] * 0.272 + result[:, :, 1] * 0.534 + result[:, :, 2] * 0.131, 0, 255)
                result = np.clip(result, 0, 255).astype(np.uint8)
            
            if inv:
                # Color inversion
                result = 255 - result
            
            if tilt:
                # Screen tilt (subtle rotation/distortion)
                h, w = result.shape[:2]
                angle = sanity_int * 2  # Small tilt angle
                center = (w // 2, h // 2)
                M = cv2.getRotationMatrix2D(center, angle, 1.0)
                result = cv2.warpAffine(result, M, (w, h), flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_REPLICATE)
        
        # Step 6: Add noise/grain (film-like texture)
        if noise_val > 0:
            noise = np.random.normal(0, noise_val * 10, result.shape).astype(np.float32)
            result = result.astype(np.float32) + noise
            result = np.clip(result, 0, 255).astype(np.uint8)
        
        # Step 7: Apply base strength multiplier
        result = result.astype(np.float32) * base_str
        result = np.clip(result, 0, 255).astype(np.uint8)
        
        # Step 8: Restore alpha channel if original had one
        if alpha_channel is not None:
            result = np.dstack([result, alpha_channel])
        
        return result
    
    def _apply_pokemon_colosseum_effect(self, pil_img, parameters):
        """Apply Pokémon Colosseum/XD: Gale of Darkness cinematic 3D battle effect."""
        from PIL import Image, ImageEnhance, ImageFilter
        import numpy as np
        import cv2
        
        # BATCH 2 OPTIMIZATION: Downscale for preview to speed up processing
        if pil_img.mode != 'RGBA':
            pil_img = pil_img.convert('RGBA')
        pil_img, original_size, was_downscaled = self._prepare_preview_image(pil_img, max_preview_size=400)
        
        # Get parameters
        base_strength = parameters.get('base_effect_strength', 1.0)
        brightness = parameters.get('brightness', 1.2)
        saturation = parameters.get('saturation', 0.8)
        contrast = parameters.get('contrast', 1.3)
        color_temp = parameters.get('color_temperature', 1.0)
        blur = parameters.get('blur_sharpness', 0.1)
        noise = parameters.get('noise_grain', 0.2)
        
        # Base Effect: Dynamic Battle Lighting + Cinematic Bloom + Sharp Edges
        battle_lighting = parameters.get('battle_lighting', 0.7)
        specular = parameters.get('specular_highlights', 0.8)
        bloom = parameters.get('bloom_intensity', 0.6)
        desaturation = parameters.get('desaturation', 0.4)
        sharp_edges = parameters.get('enable_sharp_edges', True)
        
        # Convert PIL to numpy
        img_array = np.array(pil_img)
        
        # Apply Pokémon Colosseum effects
        result = self._apply_pokemon_colosseum_filter(
            img_array, base_strength, brightness, saturation, contrast, color_temp, blur, noise,
            battle_lighting, specular, bloom, desaturation, sharp_edges
        )
        
        return result.astype(np.uint8)
    
    def _apply_pokemon_colosseum_filter(self, img_array, base_str, bright, sat, contr, temp, blur, noise_val,
                                         battle, spec, bloom_int, desat, sharp):
        """Apply Pokémon Colosseum/XD gritty 3D realism with dynamic lighting and cinematic bloom."""
        import cv2
        import numpy as np
        
        # Handle RGBA images
        if len(img_array.shape) == 3 and img_array.shape[2] == 4:
            rgb_img = img_array[:, :, :3]
            alpha_channel = img_array[:, :, 3]
        else:
            rgb_img = img_array
            alpha_channel = None
        
        result = rgb_img.astype(np.float32)
        
        # Step 1: Apply brightness
        result = result * bright
        result = np.clip(result, 0, 255).astype(np.uint8)
        
        # Step 2: Apply Orre region desaturation (worn, dusty aesthetic)
        hsv = cv2.cvtColor(result, cv2.COLOR_RGB2HSV).astype(np.float32)
        hsv[:, :, 1] = hsv[:, :, 1] * sat * (1 - desat * 0.5)  # Apply both saturation and desaturation
        result = cv2.cvtColor(hsv.astype(np.uint8), cv2.COLOR_HSV2RGB).astype(np.float32)
        
        # Step 3: Add specular highlights (simulating 3D model reflections)
        if spec > 0:
            hsv = cv2.cvtColor(result.astype(np.uint8), cv2.COLOR_RGB2HSV).astype(np.float32)
            brightness = hsv[:, :, 2]
            
            # Boost brightness of very bright areas (specular highlights)
            specular_mask = np.where(brightness > 200, spec, 0)
            hsv[:, :, 2] = np.clip(hsv[:, :, 2] + specular_mask * 30, 0, 255)
            result = cv2.cvtColor(hsv.astype(np.uint8), cv2.COLOR_HSV2RGB).astype(np.float32)
        
        # Step 4: High-contrast cinematic presentation
        result = ((result - 128) * contr) + 128
        result = np.clip(result, 0, 255).astype(np.uint8)
        
        # Step 5: Apply directional battle lighting (dramatic shadows)
        if battle > 0:
            h, w = result.shape[:2]
            # Create a directional light from top-left (cinematic battle lighting)
            y, x = np.ogrid[:h, :w]
            light_x, light_y = w * 0.3, h * 0.3  # Light source position
            
            # Calculate distance from light
            distance = np.sqrt((x - light_x)**2 + (y - light_y)**2)
            max_distance = np.sqrt(light_x**2 + light_y**2)
            light_mask = np.clip(1 - (distance / max_distance), 0, 1)
            
            # Apply lighting gradient (brighter near light source)
            result = result.astype(np.float32)
            lighting_effect = light_mask * battle * 0.3
            lighting_effect_3d = lighting_effect[:, :, np.newaxis]  # Expand to 3D for RGB
            result = result * (1 + lighting_effect_3d)
            result = np.clip(result, 0, 255).astype(np.uint8)
        
        # Step 6: Cinematic bloom on bright areas (energy effects)
        if bloom_int > 0:
            hsv = cv2.cvtColor(result, cv2.COLOR_RGB2HSV).astype(np.float32)
            brightness = hsv[:, :, 2]
            
            # Add bloom to very bright areas
            bloom_mask = np.where(brightness > 180, 1.0 + bloom_int * 0.2, 1.0)
            hsv[:, :, 2] = np.clip(hsv[:, :, 2] * bloom_mask, 0, 255)
            
            result = cv2.cvtColor(hsv.astype(np.uint8), cv2.COLOR_HSV2RGB)
        
        # Step 7: Sharp edge detail (minimal anti-aliasing for raw GameCube look)
        if sharp:
            # Apply sharpening instead of smoothing
            kernel = np.array([[-1, -1, -1],
                               [-1,  9, -1],
                               [-1, -1, -1]]) * 0.5
            result = cv2.filter2D(result, -1, kernel)
            result = np.clip(result, 0, 255).astype(np.uint8)
        else:
            # Minimal bilateral filtering
            result = cv2.bilateralFilter(result, 3, 20, 20)
        
        # Step 8: Add subtle noise/grain
        if noise_val > 0:
            noise = np.random.normal(0, noise_val * 5, result.shape).astype(np.float32)
            result = result.astype(np.float32) + noise
            result = np.clip(result, 0, 255).astype(np.uint8)
        
        # Step 9: Apply base strength multiplier
        result = result.astype(np.float32) * base_str
        result = np.clip(result, 0, 255).astype(np.uint8)
        
        # Step 10: Restore alpha channel if original had one
        if alpha_channel is not None:
            result = np.dstack([result, alpha_channel])
        
        return result
    
    def _apply_mario_kart_8_effect(self, pil_img, parameters):
        """Apply Mario Kart 8 Deluxe vibrant, polished, toy-aesthetic effect."""
        from PIL import Image, ImageEnhance, ImageFilter
        import numpy as np
        import cv2
        
        # BATCH 2 OPTIMIZATION: Downscale for preview to speed up processing
        if pil_img.mode != 'RGBA':
            pil_img = pil_img.convert('RGBA')
        pil_img, original_size, was_downscaled = self._prepare_preview_image(pil_img, max_preview_size=400)
        
        # Get parameters
        base_strength = parameters.get('base_effect_strength', 1.0)
        brightness = parameters.get('brightness', 1.2)
        saturation = parameters.get('saturation', 1.3)
        contrast = parameters.get('contrast', 1.2)
        color_temp = parameters.get('color_temperature', 1.0)
        blur = parameters.get('blur_sharpness', 0.0)
        noise = parameters.get('noise_grain', 0.0)
        
        # Base Effect: Vibrant Saturation + High-Gloss Reflections + Sharp Edges
        specular_gloss = parameters.get('specular_gloss', 0.8)
        bloom_intensity = parameters.get('bloom_intensity', 0.4)
        motion_blur = parameters.get('motion_blur', 0.0)
        sharp_edges = parameters.get('enable_sharp_edges', True)
        
        # Convert PIL to numpy
        img_array = np.array(pil_img)
        
        # Apply Mario Kart 8 effects
        result = self._apply_mario_kart_8_filter(
            img_array, base_strength, brightness, saturation, contrast, color_temp, blur, noise,
            specular_gloss, bloom_intensity, motion_blur, sharp_edges
        )
        
        return result.astype(np.uint8)
    
    def _apply_mario_kart_8_filter(self, img_array, base_str, bright, sat, contr, temp, blur, noise_val,
                                    gloss, bloom_int, motion, sharp):
        """Apply Mario Kart 8 vibrant, polished toy aesthetic with high-gloss reflections and sharp edges."""
        import cv2
        import numpy as np
        
        # Handle RGBA images
        if len(img_array.shape) == 3 and img_array.shape[2] == 4:
            rgb_img = img_array[:, :, :3]
            alpha_channel = img_array[:, :, 3]
        else:
            rgb_img = img_array
            alpha_channel = None
        
        result = rgb_img.astype(np.float32)
        
        # Step 1: Apply brightness boost
        result = result * bright
        result = np.clip(result, 0, 255).astype(np.uint8)
        
        # Step 2: Boost saturation for vibrant, primary colors
        hsv = cv2.cvtColor(result, cv2.COLOR_RGB2HSV).astype(np.float32)
        hsv[:, :, 1] = hsv[:, :, 1] * sat
        result = cv2.cvtColor(hsv.astype(np.uint8), cv2.COLOR_HSV2RGB).astype(np.float32)
        
        # Step 3: Apply moderate-high contrast for clarity
        result = ((result - 128) * contr) + 128
        result = np.clip(result, 0, 255).astype(np.uint8)
        
        # Step 4: High-gloss specular reflections (plastic/toy look)
        if gloss > 0:
            hsv = cv2.cvtColor(result, cv2.COLOR_RGB2HSV).astype(np.float32)
            brightness = hsv[:, :, 2]
            
            # Boost very bright areas (simulating high-gloss reflections)
            gloss_mask = np.where(brightness > 150, gloss * 1.5, 1.0)
            hsv[:, :, 2] = np.clip(hsv[:, :, 2] * gloss_mask, 0, 255)
            result = cv2.cvtColor(hsv.astype(np.uint8), cv2.COLOR_HSV2RGB)
        
        # Step 5: Subtle bloom on bright areas (boost/item effects)
        if bloom_int > 0:
            hsv = cv2.cvtColor(result, cv2.COLOR_RGB2HSV).astype(np.float32)
            brightness = hsv[:, :, 2]
            
            bloom_mask = np.where(brightness > 180, 1.0 + bloom_int * 0.15, 1.0)
            hsv[:, :, 2] = np.clip(hsv[:, :, 2] * bloom_mask, 0, 255)
            result = cv2.cvtColor(hsv.astype(np.uint8), cv2.COLOR_HSV2RGB)
        
        # Step 6: Sharpen edges (no anti-aliasing for crisp, aliased look)
        if sharp:
            kernel = np.array([[-1, -1, -1],
                               [-1,  9, -1],
                               [-1, -1, -1]]) * 0.3
            result = cv2.filter2D(result, -1, kernel)
            result = np.clip(result, 0, 255).astype(np.uint8)
        
        # Step 7: Apply base strength multiplier
        result = result.astype(np.float32) * base_str
        result = np.clip(result, 0, 255).astype(np.uint8)
        
        # Step 8: Restore alpha channel if original had one
        if alpha_channel is not None:
            result = np.dstack([result, alpha_channel])
        
        return result
    
    def _apply_upscale_effect(self, pil_img, parameters):
        """Apply image upscaling with various interpolation methods."""
        from PIL import Image
        import numpy as np
        import cv2
        
        scale_str = parameters.get('scale_factor', '2x (2x2)')
        method_str = parameters.get('method', 'Lanczos (High Quality)')
        preserve_alpha = parameters.get('preserve_alpha', True)
        
        # Extract scale factor
        if '2x' in scale_str:
            scale = 2
        elif '4x' in scale_str:
            scale = 4
        elif '8x' in scale_str:
            scale = 8
        else:
            scale = 2
        
        # Determine OpenCV interpolation method
        if 'Nearest' in method_str:
            interp = cv2.INTER_NEAREST
        elif 'Lanczos' in method_str:
            interp = cv2.INTER_LANCZOS4
        elif 'Bicubic' in method_str:
            interp = cv2.INTER_CUBIC
        else:
            interp = cv2.INTER_LANCZOS4
        
        # Get original size
        orig_w, orig_h = pil_img.size
        
        # Calculate new size
        new_w, new_h = orig_w * scale, orig_h * scale
        
        # Resize
        if preserve_alpha and pil_img.mode == 'RGBA':
            result = pil_img.resize((new_w, new_h), resample=Image.LANCZOS)
        else:
            # Convert to RGB for OpenCV processing
            img_array = np.array(pil_img.convert('RGB'))
            
            # Upscale using OpenCV
            result_array = cv2.resize(img_array, (new_w, new_h), interpolation=interp)
            
            # Convert back to PIL
            result = Image.fromarray(result_array)
            
            # Restore alpha if needed
            if preserve_alpha and pil_img.mode == 'RGBA':
                alpha = pil_img.split()[3]
                alpha_resized = alpha.resize((new_w, new_h), resample=Image.LANCZOS)
                result = result.convert('RGBA')
                result.putalpha(alpha_resized)
        
        return np.array(result)
    
    def _apply_image_enhancement_effect(self, pil_img, parameters):
        """Apply simplified image enhancement effect - final version."""
        from PIL import Image
        import numpy as np
        
        # Step 1: Apply quality enhancement if enabled (on original size)
        enable_quality = parameters.get('enable_upscale_quality', True)
        quality_factor = parameters.get('upscale_quality_factor', 5)
        
        if enable_quality:
            # Map quality factor (1-8) to quality parameters
            quality_intensity = quality_factor / 8.0  # 0.125 to 1.0
            quality_params = {
                'sharpness': 0.5 + quality_intensity * 1.5,  # 0.5 to 2.0
                'detail': quality_intensity * 1.5,  # 0 to 1.5
                'contrast': quality_intensity * 0.6,  # 0 to 0.6
                'denoise': quality_intensity * 0.3,  # 0 to 0.3
                'enhance_edges': True,
                'preserve_colors': True,
            }
            result_array = self._apply_quality_enhancement_effect(pil_img, quality_params)
            pil_img = Image.fromarray(result_array, mode='RGBA')
        
        # Step 2: Apply size upscale if enabled
        enable_upscale_size = parameters.get('enable_upscale_size', False)
        size_factor = parameters.get('upscale_size_factor', 2)
        
        if enable_upscale_size and size_factor > 1:
            width, height = pil_img.size
            new_width = width * size_factor
            new_height = height * size_factor
            pil_img = pil_img.resize((new_width, new_height), Image.LANCZOS)
        
        return np.array(pil_img)
    
    def _apply_hd_crisp_for_final(self, pil_img, parameters):
        """Apply HD Crisp effect - helper for final version."""
        import cv2
        import numpy as np
        from PIL import Image
        
        upscale_factor = int(parameters.get('upscale', 2))
        sharpening = parameters.get('sharpening', 1.0)
        edge_enhancement = parameters.get('edge_enhancement', 0.8)
        denoise = parameters.get('denoise', False)
        
        if pil_img.mode != 'RGBA':
            pil_img = pil_img.convert('RGBA')
        
        img_array = np.array(pil_img, dtype=np.float32)
        height, width = img_array.shape[:2]
        
        # Safety check for maximum size
        max_dimension = 4000
        original_max = max(width, height)
        if original_max * upscale_factor > max_dimension:
            safe_upscale = max(1, int(max_dimension / original_max))
            upscale_factor = min(upscale_factor, safe_upscale)
        
        # Upscale using Lanczos
        new_width = width * upscale_factor
        new_height = height * upscale_factor
        upscaled = pil_img.resize((new_width, new_height), Image.LANCZOS)
        upscaled_array = np.array(upscaled, dtype=np.float32)
        up_h, up_w = upscaled_array.shape[:2]
        
        # Edge detection
        upscaled_rgb = upscaled_array[:, :, :3].astype(np.uint8)
        gray = cv2.cvtColor(upscaled_rgb, cv2.COLOR_RGB2GRAY)
        sobel_x = cv2.Sobel(gray, cv2.CV_64F, 1, 0, ksize=3)
        sobel_y = cv2.Sobel(gray, cv2.CV_64F, 0, 1, ksize=3)
        edge_magnitude = np.sqrt(sobel_x**2 + sobel_y**2)
        edge_max = np.max(edge_magnitude)
        if edge_max > 0:
            edge_mask = edge_magnitude / edge_max
        else:
            edge_mask = np.zeros_like(edge_magnitude)
        
        # Enhanced unsharp masking
        upscaled_bgr = cv2.cvtColor(upscaled_rgb, cv2.COLOR_RGB2BGR)
        blur_sigma = 1.0 + (upscale_factor - 2) * 0.3
        blurred_bgr = cv2.GaussianBlur(upscaled_bgr, (0, 0), blur_sigma)
        blurred_rgb = cv2.cvtColor(blurred_bgr, cv2.COLOR_BGR2RGB).astype(np.float32)
        unsharp = upscaled_array[:, :, :3] + (upscaled_array[:, :, :3] - blurred_rgb) * sharpening * 1.2
        unsharp = np.clip(unsharp, 0, 255)
        
        # Edge enhancement
        edge_boost = upscaled_array[:, :, :3].copy().astype(np.float32)
        # Convert to uint8 for Laplacian (OpenCV requirement)
        gray_uint8 = gray.astype(np.uint8)
        laplacian = cv2.Laplacian(gray_uint8, cv2.CV_64F)
        edge_mask_3d = edge_mask[:, :, np.newaxis]
        laplacian_3d = np.stack([laplacian] * 3, axis=2)
        laplacian_norm = np.clip((laplacian_3d + 128) / 128.0, 0.5, 1.5)
        edge_boost = edge_boost * laplacian_norm * (1.0 + edge_mask_3d * edge_enhancement * 0.5)
        edge_boost = np.clip(edge_boost, 0, 255)
        
        # Blend
        result = (unsharp * (1 - edge_mask_3d) + edge_boost * edge_mask_3d)
        result = np.clip(result, 0, 255)
        
        # Optional denoising
        if denoise:
            result_uint8 = result.astype(np.uint8)
            result_bgr = cv2.cvtColor(result_uint8, cv2.COLOR_RGB2BGR)
            result_bgr = cv2.medianBlur(result_bgr, 3)
            result = cv2.cvtColor(result_bgr, cv2.COLOR_BGR2RGB).astype(np.float32)
        
        # Contrast boost
        result = np.power(result / 255.0, 0.92) * 255
        result = np.clip(result, 0, 255)
        
        # Reconstruct RGBA
        result_rgba = np.zeros((up_h, up_w, 4), dtype=np.uint8)
        result_rgba[:, :, :3] = result.astype(np.uint8)
        result_rgba[:, :, 3] = upscaled_array[:, :, 3].astype(np.uint8)
        
        return result_rgba
    
    def _apply_quality_enhancement_effect(self, pil_img, parameters):
        """Apply quality enhancement - improves detail and sharpness while keeping same dimensions."""
        sharpness = float(parameters.get('sharpness', 1.0))
        detail = float(parameters.get('detail', 0.5))
        contrast = float(parameters.get('contrast', 0.3))
        denoise = float(parameters.get('denoise', 0.2))
        enhance_edges = parameters.get('enhance_edges', True)
        preserve_colors = parameters.get('preserve_colors', True)
        
        if pil_img.mode != 'RGBA':
            pil_img = pil_img.convert('RGBA')
        
        # Convert to numpy array
        img_array = np.array(pil_img, dtype=np.float32)
        height, width = img_array.shape[:2]
        
        # Extract RGB channels
        rgb_img = img_array[:, :, :3].astype(np.uint8)
        
        # Use OpenCV for processing
        import cv2
        bgr_img = cv2.cvtColor(rgb_img, cv2.COLOR_RGB2BGR)
        
        # Step 1: Optional denoising
        if denoise > 0:
            # Fast denoising - preserves edges better than simple blur
            denoised = cv2.fastNlMeansDenoisingColored(
                bgr_img, None,
                h=int(denoise * 10),  # Denoise strength
                hColor=int(denoise * 10),
                templateWindowSize=7,
                searchWindowSize=21
            )
            # Blend with original based on denoise strength
            bgr_img = cv2.addWeighted(bgr_img, 1.0 - denoise, denoised, denoise, 0)
        
        # Step 2: Edge-aware sharpening and detail enhancement
        if enhance_edges:
            # Convert to LAB color space for better detail enhancement
            lab = cv2.cvtColor(bgr_img, cv2.COLOR_BGR2LAB)
            l_channel, a_channel, b_channel = cv2.split(lab)
            
            # Apply unsharp masking to L channel (lightness)
            blurred_l = cv2.GaussianBlur(l_channel, (0, 0), 1.0)
            sharpened_l = cv2.addWeighted(l_channel, 1.0 + sharpness, blurred_l, -sharpness, 0)
            
            # Detail enhancement - boost mid-frequency details
            if detail > 0:
                # Create detail layer by subtracting blurred from original
                detail_layer = cv2.subtract(l_channel.astype(np.float32), blurred_l.astype(np.float32))
                # Boost detail layer
                enhanced_l = np.clip(l_channel.astype(np.float32) + detail_layer * detail, 0, 255).astype(np.uint8)
                # Blend with sharpened
                l_final = cv2.addWeighted(sharpened_l, 0.7, enhanced_l, 0.3, 0)
            else:
                l_final = sharpened_l
            
            # Local contrast enhancement (CLAHE)
            if contrast > 0:
                clahe = cv2.createCLAHE(clipLimit=1.0 + contrast * 2.0, tileGridSize=(8, 8))
                l_final = clahe.apply(l_final)
            
            # Recombine LAB channels
            enhanced_lab = cv2.merge([l_final, a_channel, b_channel])
            result_bgr = cv2.cvtColor(enhanced_lab, cv2.COLOR_LAB2BGR)
        else:
            # Simple global sharpening
            blurred = cv2.GaussianBlur(bgr_img, (0, 0), 1.0)
            result_bgr = cv2.addWeighted(bgr_img, 1.0 + sharpness, blurred, -sharpness, 0)
        
        # Step 3: Color preservation (optional)
        if preserve_colors:
            # Convert to HSV to preserve hue/saturation
            hsv_original = cv2.cvtColor(rgb_img, cv2.COLOR_RGB2HSV)
            hsv_result = cv2.cvtColor(cv2.cvtColor(result_bgr, cv2.COLOR_BGR2RGB), cv2.COLOR_RGB2HSV)
            
            # Keep original hue and saturation, use enhanced value
            hsv_result[:, :, 0] = hsv_original[:, :, 0]  # Preserve hue
            hsv_result[:, :, 1] = cv2.addWeighted(hsv_original[:, :, 1], 0.8, hsv_result[:, :, 1], 0.2, 0)  # Blend saturation
            
            # Convert back to RGB
            result_rgb = cv2.cvtColor(hsv_result, cv2.COLOR_HSV2RGB)
        else:
            result_rgb = cv2.cvtColor(result_bgr, cv2.COLOR_BGR2RGB)
        
        # Reconstruct RGBA with original alpha
        result_rgba = np.zeros((height, width, 4), dtype=np.uint8)
        result_rgba[:, :, :3] = np.clip(result_rgb, 0, 255).astype(np.uint8)
        result_rgba[:, :, 3] = img_array[:, :, 3].astype(np.uint8)
        
        return result_rgba
    
    def _apply_noise_reduction_effect(self, pil_img, parameters):
        """Apply noise reduction with various strength levels."""
        import numpy as np
        import cv2
        
        strength = parameters.get('strength', 30)
        preset = parameters.get('preset', 'Medium')
        preserve_edges = parameters.get('preserve_edges', True)
        
        # BATCH 2 OPTIMIZATION: Downscale for preview to speed up processing
        # Bilateral filter can be very slow on large images
        if pil_img.mode != 'RGBA':
            pil_img = pil_img.convert('RGBA')
        pil_img, original_size, was_downscaled = self._prepare_preview_image(pil_img, max_preview_size=400)
        
        # Map preset to strength if needed
        if preset == 'Light':
            strength = min(strength, 15)
        elif preset == 'Medium':
            strength = max(15, min(strength, 50))
        elif preset == 'Heavy':
            strength = max(50, strength)
        # Custom uses slider value as-is
        
        # Convert to numpy array
        img_array = np.array(pil_img)
        
        # Handle RGBA
        if len(img_array.shape) == 3 and img_array.shape[2] == 4:
            rgb_img = img_array[:, :, :3]
            alpha_channel = img_array[:, :, 3]
        else:
            rgb_img = img_array
            alpha_channel = None
        
        # Apply bilateral filter for edge-preserving denoising
        if preserve_edges:
            # Bilateral filter preserves edges
            d = 9  # Diameter
            sigma_color = strength
            sigma_space = strength * 2
            
            result = cv2.bilateralFilter(rgb_img, d, sigma_color, sigma_space)
        else:
            # Simple Gaussian blur (doesn't preserve edges)
            kernel_size = (strength // 10 * 2 + 1)  # Make odd
            sigma = strength / 3.0
            result = cv2.GaussianBlur(rgb_img, (kernel_size, kernel_size), sigma)
        
        # Restore alpha
        if alpha_channel is not None:
            result = np.dstack([result, alpha_channel])
        
        return result
    
    def _apply_hdr_tone_mapping_effect(self, pil_img, parameters):
        """Apply HDR tone mapping to compress dynamic range."""
        import numpy as np
        import cv2
        
        exposure = parameters.get('exposure', 0.0)
        highlight_recovery = parameters.get('highlight_recovery', 0.5)
        shadow_lift = parameters.get('shadow_lift', 0.3)
        mode = parameters.get('mode', 'Local HDR')
        
        # BATCH 2 OPTIMIZATION: Downscale for preview to speed up processing
        # Local HDR mode can be slower on large images
        if pil_img.mode != 'RGBA':
            pil_img = pil_img.convert('RGBA')
        if mode == 'Local HDR' or max(pil_img.size) > 400:
            pil_img, original_size, was_downscaled = self._prepare_preview_image(pil_img, max_preview_size=400)
        
        # Convert to numpy
        img_array = np.array(pil_img)
        
        # Handle RGBA
        if len(img_array.shape) == 3 and img_array.shape[2] == 4:
            rgb_img = img_array[:, :, :3]
            alpha_channel = img_array[:, :, 3]
        else:
            rgb_img = img_array
            alpha_channel = None
        
        # Convert to float and normalize
        result = rgb_img.astype(np.float32) / 255.0
        
        # Apply exposure adjustment
        result = result * (2.0 ** exposure)
        
        # Shadow lift
        shadow_mask = result < 0.5
        result[shadow_mask] = result[shadow_mask] + shadow_lift * 0.3
        
        # Highlight recovery
        highlight_mask = result > 0.8
        recovery_strength = (result[highlight_mask] - 0.8) * 5.0 * highlight_recovery
        result[highlight_mask] = result[highlight_mask] - recovery_strength
        
        # Tone mapping (Reinhard-style)
        result = result / (result + 1.0)
        
        # Apply local HDR if requested (simplified)
        if mode == 'Local HDR':
            # Add local contrast enhancement
            gray = np.dot(result[:, :, :3], [0.299, 0.587, 0.114])
            gray = gray[:, :, np.newaxis]
            local_contrast = 1.0 + (gray - 0.5) * 0.3
            result = np.clip(result * local_contrast, 0, 1)
        
        # Convert back to uint8
        result = np.clip(result * 255, 0, 255).astype(np.uint8)
        
        # Restore alpha
        if alpha_channel is not None:
            result = np.dstack([result, alpha_channel])
        
        return result
    
    def _apply_cel_shading(self, img_array, levels, contrast):
        """Apply cel shading by reducing color levels."""
        import numpy as np
        
        # Convert to grayscale for cel shading calculation
        gray = np.dot(img_array[...,:3], [0.299, 0.587, 0.114])
        
        # Apply contrast
        gray = np.clip((gray - 128) * contrast + 128, 0, 255)
        
        # Quantize to cel levels
        step = 255 / (levels - 1)
        gray_quantized = np.round(gray / step) * step
        
        # Create cel shading mask
        cel_mask = gray_quantized / 255.0
        
        # Apply cel shading to each color channel
        result = img_array.copy()
        for i in range(3):  # RGB channels
            result[..., i] = result[..., i] * cel_mask
        
        return result
    
    def _apply_gentle_cel_shading(self, img_array, levels, contrast):
        """Apply gentle cel shading that preserves brightness and vibrancy."""
        import numpy as np
        
        # Convert to grayscale for cel shading calculation
        gray = np.dot(img_array[...,:3], [0.299, 0.587, 0.114])
        
        # Apply gentle contrast (less aggressive)
        gray = np.clip((gray - 128) * contrast + 128, 0, 255)
        
        # Quantize to cel levels but preserve more brightness
        step = 255 / (levels - 1)
        gray_quantized = np.round(gray / step) * step
        
        # Create gentle cel shading mask (preserve more of original brightness)
        cel_mask = (gray_quantized / 255.0) * 0.7 + 0.3  # Keep at least 30% of original
        
        # Apply cel shading to each color channel
        result = img_array.copy()
        for i in range(3):  # RGB channels
            result[..., i] = np.clip(result[..., i] * cel_mask + result[..., i] * 0.2, 0, 255)
        
        return result
    
    def _detect_light_sources(self, img_array, sensitivity):
        """Detect potential light sources in the image using brightness and color analysis."""
        import numpy as np
        import cv2
        
        # Convert to grayscale
        gray = cv2.cvtColor(img_array, cv2.COLOR_RGBA2GRAY)
        
        # Find bright areas (potential light sources)
        # Use adaptive thresholding to find bright spots
        bright_threshold = 200 - (sensitivity * 10)  # Higher sensitivity = lower threshold
        bright_mask = gray > bright_threshold
        
        # Find contours of bright areas
        contours, _ = cv2.findContours(bright_mask.astype(np.uint8), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        
        light_sources = []
        for contour in contours:
            # Filter out very small areas
            area = cv2.contourArea(contour)
            if area > 50:  # Minimum area for light source
                # Get center of contour
                M = cv2.moments(contour)
                if M["m00"] != 0:
                    cx = int(M["m10"] / M["m00"])
                    cy = int(M["m01"] / M["m00"])
                    light_sources.append((cx, cy))
        
        # If no bright areas found, look for warm colors (orange/yellow)
        if not light_sources:
            # Convert to HSV for better color detection
            hsv = cv2.cvtColor(img_array, cv2.COLOR_RGBA2RGB)
            hsv = cv2.cvtColor(hsv, cv2.COLOR_RGB2HSV)
            
            # Define range for warm colors (orange/yellow)
            lower_warm = np.array([10, 100, 100])
            upper_warm = np.array([30, 255, 255])
            
            # Create mask for warm colors
            warm_mask = cv2.inRange(hsv, lower_warm, upper_warm)
            
            # Find contours of warm areas
            contours, _ = cv2.findContours(warm_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            
            for contour in contours:
                area = cv2.contourArea(contour)
                if area > 100:  # Larger minimum for color detection
                    M = cv2.moments(contour)
                    if M["m00"] != 0:
                        cx = int(M["m10"] / M["m00"])
                        cy = int(M["m01"] / M["m00"])
                        light_sources.append((cx, cy))
        
        return light_sources
    
    def _detect_objects(self, img_array, sensitivity):
        """Detect objects in the image that can cast shadows."""
        import numpy as np
        import cv2
        
        # Convert to grayscale
        gray = cv2.cvtColor(img_array, cv2.COLOR_RGBA2GRAY)
        
        # Use edge detection to find object boundaries
        edges = cv2.Canny(gray, 50, 150)
        
        # Dilate edges to connect nearby edges
        kernel = np.ones((3, 3), np.uint8)
        edges = cv2.dilate(edges, kernel, iterations=1)
        
        # Find contours
        contours, _ = cv2.findContours(edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        
        objects = []
        for contour in contours:
            area = cv2.contourArea(contour)
            if area > 200:  # Minimum area for object
                # Get bounding rectangle
                x, y, w, h = cv2.boundingRect(contour)
                objects.append({
                    'contour': contour,
                    'bbox': (x, y, w, h),
                    'center': (x + w//2, y + h//2),
                    'area': area
                })
        
        return objects
    
    def _create_lighting_map(self, img_array, light_sources, radius, intensity):
        """Create a lighting map based on light sources."""
        import numpy as np
        
        height, width = img_array.shape[:2]
        lighting_map = np.zeros((height, width), dtype=np.float32)
        
        for light_x, light_y in light_sources:
            # Create distance map from light source
            y, x = np.ogrid[:height, :width]
            distance = np.sqrt((x - light_x)**2 + (y - light_y)**2)
            
            # Create falloff lighting (inverse square law)
            light_strength = intensity / (1 + (distance / radius)**2)
            light_strength = np.clip(light_strength, 0, 1)
            
            # Add to lighting map
            lighting_map = np.maximum(lighting_map, light_strength)
        
        return lighting_map
    
    def _apply_torch_color(self, lighting_map, torch_color, warmth):
        """Apply torch color and warmth to the lighting map."""
        import numpy as np
        
        # Convert hex color to RGB
        torch_rgb = tuple(int(torch_color[i:i+2], 16) for i in (1, 3, 5))
        
        # Create colored lighting map
        colored_lighting = np.zeros((lighting_map.shape[0], lighting_map.shape[1], 3), dtype=np.float32)
        
        for i, color_component in enumerate(torch_rgb):
            colored_lighting[:, :, i] = lighting_map * (color_component / 255.0) * warmth
        
        return colored_lighting
    
    def _add_flicker(self, lighting_map, flicker_amount):
        """Add flickering effect to the lighting."""
        import numpy as np
        
        # Create random flicker pattern
        if len(lighting_map.shape) == 3:  # Colored lighting (height, width, 3)
            flicker = np.random.normal(1.0, flicker_amount / 100.0, lighting_map.shape[:2])  # Only height, width
            flicker = np.clip(flicker, 0.5, 1.5)  # Limit flicker range
            flickered = lighting_map * flicker[:, :, np.newaxis]  # Broadcast to 3 channels
        else:  # Grayscale lighting (height, width)
            flicker = np.random.normal(1.0, flicker_amount / 100.0, lighting_map.shape)
            flicker = np.clip(flicker, 0.5, 1.5)  # Limit flicker range
            flickered = lighting_map * flicker
        
        return np.clip(flickered, 0, 1)
    
    def _create_shadow_map(self, img_array, light_sources, objects, shadow_length, softness):
        """Create shadow map based on objects and light sources."""
        import numpy as np
        import cv2
        
        height, width = img_array.shape[:2]
        shadow_map = np.ones((height, width), dtype=np.float32)
        
        for light_x, light_y in light_sources:
            for obj in objects:
                # Get object center and size
                obj_x, obj_y = obj['center']
                obj_w, obj_h = obj['bbox'][2], obj['bbox'][3]
                
                # Calculate shadow direction (from light to object)
                dx = obj_x - light_x
                dy = obj_y - light_y
                distance = np.sqrt(dx**2 + dy**2)
                
                if distance > 0:
                    # Normalize direction
                    dx /= distance
                    dy /= distance
                    
                    # Create shadow area
                    shadow_start_x = obj_x + dx * (obj_w // 2)
                    shadow_start_y = obj_y + dy * (obj_h // 2)
                    shadow_end_x = shadow_start_x + dx * shadow_length
                    shadow_end_y = shadow_start_y + dy * shadow_length
                    
                    # Create shadow mask
                    shadow_mask = np.zeros((height, width), dtype=np.uint8)
                    
                    # Draw shadow as an ellipse
                    shadow_center = (int(shadow_end_x), int(shadow_end_y))
                    shadow_size = (int(obj_w * 1.5), int(obj_h * 1.5))
                    
                    cv2.ellipse(shadow_mask, shadow_center, shadow_size, 0, 0, 360, 255, -1)
                    
                    # Apply softness (blur)
                    if softness > 1.0:
                        kernel_size = int(softness * 10)
                        if kernel_size % 2 == 0:
                            kernel_size += 1
                        shadow_mask = cv2.GaussianBlur(shadow_mask, (kernel_size, kernel_size), softness)
                    
                    # Convert to float and apply to shadow map
                    shadow_strength = shadow_mask.astype(np.float32) / 255.0
                    shadow_map = np.minimum(shadow_map, 1.0 - shadow_strength)
        
        return shadow_map
    
    def _apply_shadows(self, lighting_map, shadow_map, shadow_darkness):
        """Apply shadows to the lighting map."""
        import numpy as np
        
        if len(lighting_map.shape) == 3:  # Colored lighting
            shadow_factor = 1.0 - (shadow_map * shadow_darkness)
            shadow_factor = shadow_factor[:, :, np.newaxis]
            return lighting_map * shadow_factor
        else:  # Grayscale lighting
            shadow_factor = 1.0 - (shadow_map * shadow_darkness)
            return lighting_map * shadow_factor
    
    def _apply_lighting_to_image(self, img_array, lighting_map, ambient_light):
        """Apply the lighting map to the original image."""
        import numpy as np
        
        # Convert image to float
        img_float = img_array.astype(np.float32) / 255.0
        
        # Apply ambient light
        img_float = img_float * ambient_light
        
        # Apply lighting map
        if len(lighting_map.shape) == 3:  # Colored lighting
            # Add colored lighting to each channel
            for i in range(3):
                img_float[:, :, i] = np.clip(img_float[:, :, i] + lighting_map[:, :, i], 0, 1)
        else:  # Grayscale lighting
            # Apply lighting to all channels
            for i in range(3):
                img_float[:, :, i] = np.clip(img_float[:, :, i] + lighting_map, 0, 1)
        
        # Convert back to uint8
        return (img_float * 255).astype(np.uint8)
    
    def _add_atmospheric_effects(self, img_array, density, torch_color):
        """Add atmospheric effects like smoke or haze."""
        import numpy as np
        
        if density == 0:
            return img_array
        
        # Create atmospheric overlay
        height, width = img_array.shape[:2]
        atmosphere = np.zeros((height, width, 3), dtype=np.float32)
        
        # Convert torch color to RGB
        torch_rgb = tuple(int(torch_color[i:i+2], 16) for i in (1, 3, 5))
        
        # Create subtle atmospheric tint
        for i, color_component in enumerate(torch_rgb):
            atmosphere[:, :, i] = (color_component / 255.0) * (density / 100.0) * 0.1
        
        # Apply atmospheric effect
        img_float = img_array.astype(np.float32) / 255.0
        img_float[:, :, :3] = np.clip(img_float[:, :, :3] + atmosphere, 0, 1)
        
        return (img_float * 255).astype(np.uint8)
    
    def _apply_vibrant_cel_shading(self, img_array, levels, contrast, shadow_intensity, highlight_intensity):
        """Apply vibrant cel shading that preserves brightness and creates Wind Waker style."""
        import numpy as np
        
        # Convert to grayscale for cel shading calculation
        gray = np.dot(img_array[...,:3], [0.299, 0.587, 0.114])
        
        # Apply gentle contrast
        gray = np.clip((gray - 128) * contrast + 128, 0, 255)
        
        # Quantize to cel levels
        step = 255 / (levels - 1)
        gray_quantized = np.round(gray / step) * step
        
        # Create vibrant cel shading mask
        cel_mask = gray_quantized / 255.0
        
        # Apply cel shading with vibrant enhancement
        result = img_array.copy()
        for i in range(3):  # RGB channels
            # Apply cel shading
            shaded = result[..., i] * cel_mask
            
            # Enhance highlights and preserve shadows
            enhanced = np.where(
                cel_mask > 0.7,  # Highlight areas
                np.clip(shaded * highlight_intensity, 0, 255),
                np.where(
                    cel_mask < 0.3,  # Shadow areas
                    np.clip(shaded * shadow_intensity, 0, 255),
                    shaded  # Mid-tones unchanged
                )
            )
            result[..., i] = enhanced
        
        return result
    
    def _reduce_colors_vibrantly(self, pil_img, levels):
        """Reduce colors while preserving vibrancy for Wind Waker style."""
        from PIL import Image
        
        # Use more colors to preserve vibrancy
        actual_levels = max(levels, 12)  # Minimum 12 colors for vibrancy
        
        # Convert to P mode with reduced palette
        img_p = pil_img.convert('P', palette=Image.ADAPTIVE, colors=actual_levels)
        
        # Convert back to RGBA
        return img_p.convert('RGBA')
    
    def _add_bold_outlines(self, pil_img, width, color, method):
        """Add bold, clean outlines for Wind Waker style."""
        import cv2
        import numpy as np
        from PIL import Image
        
        # Convert PIL to numpy
        img_array = np.array(pil_img)
        
        # Convert to grayscale for edge detection
        gray = cv2.cvtColor(img_array, cv2.COLOR_RGBA2GRAY)
        
        # Apply edge detection
        if method == 'Sobel':
            edges = cv2.Sobel(gray, cv2.CV_64F, 1, 1, ksize=3)
            edges = np.abs(edges)
        elif method == 'Canny':
            edges = cv2.Canny(gray, 30, 100)  # Lower thresholds for cleaner edges
        else:  # Laplacian
            edges = cv2.Laplacian(gray, cv2.CV_64F)
            edges = np.abs(edges)
        
        # Threshold edges (lower threshold for cleaner outlines)
        edges = (edges > 20).astype(np.uint8) * 255
        
        # Dilate edges to make them bolder
        kernel = np.ones((width, width), np.uint8)
        edges = cv2.dilate(edges, kernel, iterations=1)
        
        # Convert outline color to RGB
        color_rgb = tuple(int(color[i:i+2], 16) for i in (1, 3, 5))
        
        # Create outline mask
        outline_mask = edges > 0
        
        # Apply bold outlines
        result = img_array.copy()
        result[outline_mask] = [*color_rgb, 255]  # Set outline color with full alpha
        
        return Image.fromarray(result, mode='RGBA')
    
    def _reduce_colors(self, pil_img, levels):
        """Reduce color palette to specified number of levels."""
        from PIL import Image
        
        # Convert to P mode with reduced palette
        img_p = pil_img.convert('P', palette=Image.ADAPTIVE, colors=levels)
        
        # Convert back to RGBA
        return img_p.convert('RGBA')
    
    def _reduce_colors_lightly(self, pil_img, levels):
        """Reduce colors lightly to preserve vibrancy."""
        from PIL import Image
        
        # Use more colors to preserve vibrancy
        actual_levels = max(levels, 16)  # Minimum 16 colors
        
        # Convert to P mode with reduced palette
        img_p = pil_img.convert('P', palette=Image.ADAPTIVE, colors=actual_levels)
        
        # Convert back to RGBA
        return img_p.convert('RGBA')
    
    def _apply_dithering(self, pil_img, method):
        """Apply dithering to reduce banding."""
        from PIL import Image
        
        if method == 'Floyd-Steinberg':
            # Simple ordered dithering simulation
            img_array = np.array(pil_img)
            h, w = img_array.shape[:2]
            
            # Apply ordered dithering matrix
            dither_matrix = np.array([
                [0, 8, 2, 10],
                [12, 4, 14, 6],
                [3, 11, 1, 9],
                [15, 7, 13, 5]
            ]) / 16.0
            
            for y in range(h):
                for x in range(w):
                    for c in range(3):  # RGB channels
                        old_pixel = img_array[y, x, c]
                        new_pixel = 255 if old_pixel > 128 + dither_matrix[y % 4, x % 4] * 64 else 0
                        img_array[y, x, c] = new_pixel
            
            return Image.fromarray(img_array, mode='RGBA')
        
        return pil_img
    
    def _add_outlines(self, pil_img, width, color, method):
        """Add outlines to the image."""
        import cv2
        import numpy as np
        from PIL import Image
        
        # Convert PIL to numpy
        img_array = np.array(pil_img)
        
        # Convert to grayscale for edge detection
        gray = cv2.cvtColor(img_array, cv2.COLOR_RGBA2GRAY)
        
        # Apply edge detection
        if method == 'Sobel':
            edges = cv2.Sobel(gray, cv2.CV_64F, 1, 1, ksize=3)
            edges = np.abs(edges)
        elif method == 'Canny':
            edges = cv2.Canny(gray, 50, 150)
        else:  # Laplacian
            edges = cv2.Laplacian(gray, cv2.CV_64F)
            edges = np.abs(edges)
        
        # Threshold edges
        edges = (edges > 30).astype(np.uint8) * 255
        
        # Dilate edges to make them thicker
        kernel = np.ones((width, width), np.uint8)
        edges = cv2.dilate(edges, kernel, iterations=1)
        
        # Convert outline color to RGB
        color_rgb = tuple(int(color[i:i+2], 16) for i in (1, 3, 5))
        
        # Create outline mask
        outline_mask = edges > 0
        
        # Apply outlines
        result = img_array.copy()
        result[outline_mask] = [*color_rgb, 255]  # Set outline color with full alpha
        
        return Image.fromarray(result, mode='RGBA')

    
    def _apply_lighting_effect(self, img_array, lighting_type, tint_r, tint_g, tint_b, 
                              intensity, glow_radius, animate_glow, h, w):
        """Apply lighting effects like torch glow, sunlight, etc."""
        import numpy as np
        import math
        
        # Create glow mask based on lighting type
        if lighting_type == 'Torch Glow':
            # Create circular glow from center
            center_x, center_y = w // 2, h // 2
            y, x = np.ogrid[:h, :w]
            distance = np.sqrt((x - center_x)**2 + (y - center_y)**2)
            max_distance = min(w, h) * glow_radius * 0.5
            glow_mask = np.clip(1.0 - (distance / max_distance), 0, 1)
            
            # Add flickering for torch effect
            if animate_glow:
                flicker = 0.8 + 0.4 * math.sin(distance * 0.1)  # Flickering pattern
                glow_mask *= flicker
            
        elif lighting_type == 'Sunlight':
            # Create directional light from top-left
            y, x = np.ogrid[:h, :w]
            angle = np.arctan2(y, x) + math.pi/4  # 45 degree angle
            glow_mask = np.clip(np.cos(angle) * 0.5 + 0.5, 0, 1)
            
        elif lighting_type == 'Moonlight':
            # Soft blue glow from center
            center_x, center_y = w // 2, h // 2
            y, x = np.ogrid[:h, :w]
            distance = np.sqrt((x - center_x)**2 + (y - center_y)**2)
            max_distance = min(w, h) * glow_radius * 0.7
            glow_mask = np.clip(1.0 - (distance / max_distance), 0, 1)
            # Make it more blue
            tint_r = int(tint_r * 0.7)
            tint_g = int(tint_g * 0.8) 
            tint_b = int(tint_b * 1.2)
            
        elif lighting_type == 'Neon Glow':
            # Create multiple bright spots
            glow_mask = np.zeros((h, w))
            for i in range(3):
                center_x = w * (0.2 + i * 0.3)
                center_y = h * (0.3 + i * 0.2)
                y, x = np.ogrid[:h, :w]
                distance = np.sqrt((x - center_x)**2 + (y - center_y)**2)
                spot = np.exp(-distance / (min(w, h) * 0.1))
                glow_mask += spot
            glow_mask = np.clip(glow_mask, 0, 1)
            
        else:  # Candle Light
            # Small, warm glow from center
            center_x, center_y = w // 2, h // 2
            y, x = np.ogrid[:h, :w]
            distance = np.sqrt((x - center_x)**2 + (y - center_y)**2)
            max_distance = min(w, h) * glow_radius * 0.3
            glow_mask = np.exp(-distance / (max_distance * 0.5))
        
        # Apply glow effect
        glow_mask = glow_mask[:, :, np.newaxis]
        
        if False:  # preserve_colors not defined, using simplified approach
            # Blend with original colors
            for i in range(3):
                img_array[:,:,i] = np.clip(
                    img_array[:,:,i] * (1 - intensity) + 
                    img_array[:,:,i] * glow_mask[:,:,0] * intensity * (tint_r if i == 0 else tint_g if i == 1 else tint_b) / 255.0,
                    0, 255
                )
        else:
            # Apply tinted glow
            for i in range(3):
                tint_val = tint_r if i == 0 else tint_g if i == 1 else tint_b
                img_array[:,:,i] = np.clip(
                    img_array[:,:,i] * (1 - intensity * glow_mask[:,:,0]) + 
                    tint_val * intensity * glow_mask[:,:,0],
                    0, 255
                )
        
        return img_array
    
    def _apply_artistic_style(self, img_array, art_style, intensity, contrast, h, w):
        """Apply artistic styles like 8-bit, anime, etc."""
        import numpy as np
        
        if art_style == '8-bit Pixel':
            # Reduce to 16 colors and pixelate
            # Quantize colors
            img_array = (img_array // 16) * 16
            # Add dithering
            for y in range(0, h-1, 2):
                for x in range(0, w-1, 2):
                    if (x + y) % 4 == 0:  # Checkerboard dithering
                        img_array[y:y+2, x:x+2] = (img_array[y:y+2, x:x+2] // 32) * 32
            
        elif art_style == '16-bit SNES':
            # Smooth gradients with more colors
            img_array = (img_array // 8) * 8
            # Add subtle dithering
            noise = np.random.randint(-8, 8, img_array.shape)
            img_array = np.clip(img_array + noise, 0, 255)
            
        elif art_style == 'Anime Cel':
            # Cel shading with flat colors and bold outlines
            # Reduce to fewer colors
            img_array = (img_array // 32) * 32
            # Increase contrast for bold look
            img_array = np.clip(img_array * 1.3, 0, 255)
            
        elif art_style == 'Watercolor':
            # Soft, bleeding effect
            # Blur slightly
            from scipy import ndimage
            for i in range(3):
                img_array[:,:,i] = ndimage.gaussian_filter(img_array[:,:,i], sigma=1.0)
            # Reduce saturation
            gray = np.dot(img_array[...,:3], [0.299, 0.587, 0.114])
            for i in range(3):
                img_array[:,:,i] = np.clip(img_array[:,:,i] * 0.7 + gray * 0.3, 0, 255)
                
        elif art_style == 'Oil Painting':
            # Thick brushstrokes effect
            # Reduce colors and add texture
            img_array = (img_array // 16) * 16
            # Add noise for texture
            noise = np.random.randint(-16, 16, img_array.shape)
            img_array = np.clip(img_array + noise, 0, 255)
        
        return img_array

    
    def get_frame_option(self):
        return self.frame_option
    
    def get_selection_option(self):
        return self.selection_option
    
    def get_parameters(self):
        params = {}
        for name, widget in self.param_widgets.items():
            params[name] = widget.get_value()
        return params
    
    def randomize_parameters(self):
        """Randomize all parameters with full digit values (no decimals)."""
        import random
        
        effect_config = EFFECT_REGISTRY.get(self.effect_type, {})
        
        # Randomize basic parameters
        for param_config in effect_config.get('parameters', []):
            param_name = param_config['name']
            if param_name in self.param_widgets:
                widget = self.param_widgets[param_name]
                param_type = param_config['type']
                
                if param_type == 'slider':
                    min_val, max_val = param_config['range']
                    random_val = random.randint(int(min_val), int(max_val))
                    widget.set_value(random_val)
                elif param_type == 'double_slider':
                    min_val, max_val = param_config['range']
                    random_val = random.randint(int(min_val * 100), int(max_val * 100)) / 100.0
                    widget.set_value(random_val)
                elif param_type == 'dropdown':
                    options = param_config['options']
                    random_option = random.choice(options)
                    widget.set_value(random_option)
        
        # Randomize elevation parameters
        for param_config in effect_config.get('elevation_parameters', []):
            param_name = param_config['name']
            if param_name in self.param_widgets:
                widget = self.param_widgets[param_name]
                param_type = param_config['type']
                
                if param_type == 'slider':
                    min_val, max_val = param_config['range']
                    random_val = random.randint(int(min_val), int(max_val))
                    widget.set_value(random_val)
                elif param_type == 'dropdown':
                    options = param_config['options']
                    random_option = random.choice(options)
                    widget.set_value(random_option)
                elif param_type == 'checkbox':
                    random_bool = random.choice([True, False])
                    widget.set_value(random_bool)
        
        # Randomize color parameters with predefined color palette
        color_palette = [
            '#FF0000', '#00FF00', '#0000FF', '#FFFF00', '#FF00FF', '#00FFFF',
            '#FFFFFF', '#000000', '#888888', '#FFA500', '#800080', '#008000',
            '#8B4513', '#4169E1', '#F4A460', '#228B22', '#DEB887', '#B0C4DE'
        ]
        
        for param_config in effect_config.get('color_parameters', []):
            param_name = param_config['name']
            if param_name in self.param_widgets:
                widget = self.param_widgets[param_name]
                random_color = random.choice(color_palette)
                widget.set_value(random_color)
        
        # Update preview
        self.on_parameter_changed()
    
    def browse_export_path(self):
        """Browse for export path."""
        from PySide6.QtWidgets import QFileDialog
        
        export_format = self.export_format_combo.currentText()
        if export_format == ".PgSprite":
            file_path, _ = QFileDialog.getSaveFileName(
                self, "Save LOD as .PgSprite", "", "PgSprite Files (*.pgsprite)"
            )
        elif export_format == "GIF":
            file_path, _ = QFileDialog.getSaveFileName(
                self, "Save LOD as GIF", "", "GIF Files (*.gif)"
            )
        elif export_format == "JPG":
            file_path, _ = QFileDialog.getSaveFileName(
                self, "Save LOD as JPG", "", "JPEG Files (*.jpg *.jpeg)"
            )
        else:  # PNG
            file_path, _ = QFileDialog.getSaveFileName(
                self, "Save LOD as PNG", "", "PNG Files (*.png)"
            )
        
        if file_path:
            self.export_path_edit.setText(file_path)
    
    def get_export_options(self):
        """Get export options for LOD generation."""
        if self.effect_type == 'generate_lod':
            return {
                'format': self.export_format_combo.currentText(),
                'path': self.export_path_edit.text()
            }
        return None


# Effect Registry - defines all effects and their parameters
EFFECT_REGISTRY = {
    'invert': {
        'name': 'Invert Colors',
        'parameters': [],
        'preview_enabled': True,
        'frame_options': True,
        'selection_options': True
    },
    'brightness': {
        'name': 'Adjust Brightness',
        'parameters': [
            {'type': 'double_slider', 'name': 'factor', 'label': 'Brightness', 'range': (0.1, 3.0), 'default': 1.0}
        ],
        'preview_enabled': True,
        'frame_options': True,
        'selection_options': True
    },
    'contrast': {
        'name': 'Adjust Contrast',
        'parameters': [
            {'type': 'double_slider', 'name': 'factor', 'label': 'Contrast', 'range': (0.1, 3.0), 'default': 1.0}
        ],
        'preview_enabled': True,
        'frame_options': True,
        'selection_options': True
    },
    'greyscale': {
        'name': 'Greyscale',
        'parameters': [],
        'preview_enabled': True,
        'frame_options': True,
        'selection_options': True
    },
    'fade': {
        'name': 'Fade to Color',
        'parameters': [
            {'type': 'color_picker', 'name': 'target_color', 'label': 'Target Color', 'default': '#000000'},
            {'type': 'double_slider', 'name': 'intensity', 'label': 'Intensity', 'range': (0.0, 1.0), 'default': 0.5}
        ],
        'preview_enabled': True,
        'frame_options': True,
        'selection_options': True
    },
    'opacity': {
        'name': 'Opacity Adjustment',
        'parameters': [
            {'type': 'double_slider', 'name': 'opacity', 'label': 'Opacity', 'range': (0.0, 1.0), 'default': 0.5}
        ],
        'preview_enabled': True,
        'frame_options': True,
        'selection_options': True
    },
    'blur': {
        'name': 'Blur',
        'parameters': [
            {'type': 'slider', 'name': 'radius', 'label': 'Radius', 'range': (1, 20), 'default': 5}
        ],
        'preview_enabled': True,
        'frame_options': True,
        'selection_options': True
    },
    'sharpen': {
        'name': 'Sharpen',
        'parameters': [
            {'type': 'slider', 'name': 'amount', 'label': 'Amount', 'range': (1, 100), 'default': 50}
        ],
        'preview_enabled': True,
        'frame_options': True,
        'selection_options': True
    },
    'noise': {
        'name': 'Noise',
        'parameters': [
            {'type': 'slider', 'name': 'intensity', 'label': 'Intensity', 'range': (1, 100), 'default': 50},
            {'type': 'dropdown', 'name': 'type', 'label': 'Type', 'options': ['Random', 'Coherent'], 'default': 'Random'},
            {'type': 'slider', 'name': 'seed', 'label': 'Seed', 'range': (1, 99999), 'default': 42}
        ],
        'preview_enabled': True,
        'frame_options': True,
        'selection_options': True
    },
    'dither': {
        'name': 'Dither',
        'parameters': [
            {'type': 'slider', 'name': 'intensity', 'label': 'Intensity', 'range': (1, 100), 'default': 50},
            {'type': 'dropdown', 'name': 'pattern', 'label': 'Pattern', 'options': ['Floyd-Steinberg', 'Ordered', 'Random'], 'default': 'Floyd-Steinberg'}
        ],
        'preview_enabled': True,
        'frame_options': True,
        'selection_options': True
    },
    'vignette': {
        'name': 'Vignette',
        'parameters': [
            {'type': 'double_slider', 'name': 'strength', 'label': 'Strength', 'range': (0.0, 1.0), 'default': 0.5},
            {'type': 'double_slider', 'name': 'radius', 'label': 'Radius', 'range': (0.1, 1.5), 'default': 0.8},
            {'type': 'dropdown', 'name': 'shape', 'label': 'Shape', 'options': ['Circular', 'Square'], 'default': 'Circular'}
        ],
        'preview_enabled': True,
        'frame_options': True,
        'selection_options': True
    },
    'saturation': {
        'name': 'Saturation',
        'parameters': [
            {'type': 'double_slider', 'name': 'factor', 'label': 'Saturation', 'range': (0.0, 3.0), 'default': 1.0}
        ],
        'preview_enabled': True,
        'frame_options': True,
        'selection_options': True
    },
    'posterize': {
        'name': 'Posterize',
        'parameters': [
            {'type': 'slider', 'name': 'levels', 'label': 'Color Levels', 'range': (2, 32), 'default': 8}
        ],
        'preview_enabled': True,
        'frame_options': True,
        'selection_options': True
    },
    'emboss': {
        'name': 'Emboss',
        'parameters': [
            {'type': 'double_slider', 'name': 'strength', 'label': 'Strength', 'range': (0.5, 5.0), 'default': 1.0}
        ],
        'preview_enabled': True,
        'frame_options': True,
        'selection_options': True
    },
    'edge_detection': {
        'name': 'Edge Detection',
        'parameters': [
            {'type': 'slider', 'name': 'threshold', 'label': 'Threshold', 'range': (10, 200), 'default': 50}
        ],
        'preview_enabled': True,
        'frame_options': True,
        'selection_options': True
    },
    'colorize': {
        'name': 'Colorize',
        'parameters': [
            {'type': 'color_picker', 'name': 'color', 'label': 'Tint Color', 'default': '#FF0000'},
            {'type': 'double_slider', 'name': 'strength', 'label': 'Strength', 'range': (0.0, 1.0), 'default': 0.5}
        ],
        'preview_enabled': True,
        'frame_options': True,
        'selection_options': True
    },
    'oil_painting': {
        'name': 'Oil Painting',
        'parameters': [
            {'type': 'slider', 'name': 'brush_size', 'label': 'Brush Size', 'range': (1, 8), 'default': 3},
            {'type': 'double_slider', 'name': 'intensity', 'label': 'Intensity', 'range': (0.0, 1.0), 'default': 0.7}
        ],
        'preview_enabled': True,
        'frame_options': True,
        'selection_options': True
    },
    'glow': {
        'name': 'Glow',
        'parameters': [
            {'type': 'slider', 'name': 'radius', 'label': 'Glow Radius', 'range': (5, 30), 'default': 10},
            {'type': 'double_slider', 'name': 'strength', 'label': 'Strength', 'range': (0.5, 3.0), 'default': 1.5}
        ],
        'preview_enabled': True,
        'frame_options': True,
        'selection_options': True
    },
    'solarize': {
        'name': 'Solarize',
        'parameters': [
            {'type': 'slider', 'name': 'threshold', 'label': 'Threshold', 'range': (50, 200), 'default': 128}
        ],
        'preview_enabled': True,
        'frame_options': True,
        'selection_options': True
    },
    'upscale': {
        'name': 'Upscale',
        'parameters': [
            {'type': 'slider', 'name': 'scale', 'label': 'Scale Factor', 'range': (2, 4), 'default': 2},
            {'type': 'double_slider', 'name': 'sharpening', 'label': 'Post-Upscale Sharpening', 'range': (0.5, 2.5), 'default': 1.2},
            {'type': 'checkbox', 'name': 'enhance_edges', 'label': 'Enhance Edges', 'default': True}
        ],
        'preview_enabled': False,  # Disabled for performance
        'frame_options': False,
        'selection_options': True
    },
    'motion_blur': {
        'name': 'Motion Blur',
        'parameters': [
            {'type': 'slider', 'name': 'angle', 'label': 'Angle (degrees)', 'range': (0, 360), 'default': 45},
            {'type': 'slider', 'name': 'distance', 'label': 'Distance', 'range': (5, 50), 'default': 10}
        ],
        'preview_enabled': True,
        'frame_options': True,
        'selection_options': True
    },
    'shader_bloom': {
        'name': 'Shader Bloom FX',
        'parameters': [
            {'type': 'double_slider', 'name': 'intensity', 'label': 'Intensity', 'range': (0.0, 3.0), 'default': 1.0},
            {'type': 'slider', 'name': 'threshold', 'label': 'Brightness Threshold', 'range': (100, 255), 'default': 200},
            {'type': 'slider', 'name': 'radius', 'label': 'Bloom Radius', 'range': (5, 30), 'default': 15}
        ],
        'preview_enabled': True,
        'frame_options': True,
        'selection_options': True
    },
    'palette_cycler': {
        'name': 'Palette Cycler',
        'parameters': [
            {'type': 'double_slider', 'name': 'cycle_speed', 'label': 'Cycle Speed', 'range': (0.0, 1.0), 'default': 0.5},
            {'type': 'dropdown', 'name': 'direction', 'label': 'Direction', 'options': ['Forward', 'Reverse'], 'default': 'Forward'}
        ],
        'preview_enabled': True,
        'frame_options': True,
        'selection_options': True
    },
    'pixel_depth': {
        'name': 'Pixel Depth Mapper',
        'parameters': [
            {'type': 'double_slider', 'name': 'depth', 'label': 'Depth', 'range': (0.0, 1.0), 'default': 0.5},
            {'type': 'slider', 'name': 'angle', 'label': 'Light Angle (degrees)', 'range': (0, 360), 'default': 45}
        ],
        'preview_enabled': True,
        'frame_options': True,
        'selection_options': True
    },
    'hd_crisp': {
        'name': '⭐ HD Crisp',
        'parameters': [
            {'type': 'slider', 'name': 'upscale', 'label': 'Upscale Factor', 'range': (2, 4), 'default': 2},
            {'type': 'double_slider', 'name': 'sharpening', 'label': 'Sharpening', 'range': (0.5, 3.0), 'default': 1.5},
            {'type': 'double_slider', 'name': 'edge_enhancement', 'label': 'Edge Enhancement', 'range': (0.0, 2.0), 'default': 1.2},
            {'type': 'checkbox', 'name': 'denoise', 'label': 'Denoise', 'default': False}
        ],
        'preview_enabled': True,  # Enabled with downscaling
        'frame_options': False,
        'selection_options': True
    },
    'pixelate': {
        'name': 'Pixelate',
        'parameters': [
            {'type': 'slider', 'name': 'block_size', 'label': 'Block Size', 'range': (2, 16), 'default': 4}
        ],
        'preview_enabled': True,
        'frame_options': True,
        'selection_options': True
    },
    'mirror_horizontal': {
        'name': 'Mirror Horizontal',
        'parameters': [],
        'preview_enabled': True,
        'frame_options': True,
        'selection_options': True
    },
    'mirror_vertical': {
        'name': 'Mirror Vertical',
        'parameters': [],
        'preview_enabled': True,
        'frame_options': True,
        'selection_options': True
    },
    'rotate_90': {
        'name': 'Rotate 90°',
        'parameters': [],
        'preview_enabled': True,
        'frame_options': True,
        'selection_options': True
    },
    'rotate_180': {
        'name': 'Rotate 180°',
        'parameters': [],
        'preview_enabled': True,
        'frame_options': True,
        'selection_options': True
    },
    'rotate_custom': {
        'name': 'Rotate Custom',
        'parameters': [
            {'type': 'slider', 'name': 'angle', 'label': 'Angle', 'range': (0, 360), 'default': 90}
        ],
        'preview_enabled': True,
        'frame_options': True,
        'selection_options': True
    },
    'map_generator': {
        'name': '2D Map Generation',
        'parameters': [
            {'type': 'double_slider', 'name': 'scale', 'label': 'Scale', 'range': (0.01, 0.2), 'default': 0.05},
            {'type': 'slider', 'name': 'detail', 'label': 'Detail', 'range': (1, 8), 'default': 4},
            {'type': 'dropdown', 'name': 'map_type', 'label': 'Map Type', 'options': ['Minecraft', 'Island', 'Continental', 'Archipelago', 'Desert', 'Snow', 'Jungle', 'Ocean'], 'default': 'Minecraft'},
            {'type': 'slider', 'name': 'biome_variation', 'label': 'Biome Variation', 'range': (0, 100), 'default': 30},
            {'type': 'slider', 'name': 'seed', 'label': 'Seed', 'range': (1, 99999), 'default': 12345},
            {'type': 'slider', 'name': 'temperature', 'label': 'Temperature', 'range': (0, 100), 'default': 50},
            {'type': 'slider', 'name': 'humidity', 'label': 'Humidity', 'range': (0, 100), 'default': 50}
        ],
        'elevation_parameters': [
            {'type': 'slider', 'name': 'elevation_intensity', 'label': 'Elevation Intensity', 'range': (0, 200), 'default': 100},
            {'type': 'slider', 'name': 'mountain_height', 'label': 'Mountain Height', 'range': (0, 200), 'default': 100},
            {'type': 'slider', 'name': 'hill_prominence', 'label': 'Hill Prominence', 'range': (0, 200), 'default': 100},
            {'type': 'slider', 'name': 'sea_level', 'label': 'Sea Level', 'range': (0, 100), 'default': 30},
            {'type': 'dropdown', 'name': 'elevation_mode', 'label': 'Elevation Mode', 'options': ['Normal', 'Height Map', 'Contour Lines'], 'default': 'Normal'},
            {'type': 'checkbox', 'name': 'show_contours', 'label': 'Show Contour Lines', 'default': False},
            {'type': 'slider', 'name': 'contour_spacing', 'label': 'Contour Spacing', 'range': (5, 50), 'default': 15},
            {'type': 'color_picker', 'name': 'contour_color', 'label': 'Contour Lines', 'default': '#000000'}
        ],
        'color_parameters': [
            {'type': 'color_picker', 'name': 'deep_water_color', 'label': 'Deep Water', 'default': '#000080'},
            {'type': 'color_picker', 'name': 'shallow_water_color', 'label': 'Shallow Water', 'default': '#4169E1'},
            {'type': 'color_picker', 'name': 'sand_color', 'label': 'Sand', 'default': '#F4A460'},
            {'type': 'color_picker', 'name': 'grass_color', 'label': 'Grass', 'default': '#228B22'},
            {'type': 'color_picker', 'name': 'forest_color', 'label': 'Forest', 'default': '#228B22'},
            {'type': 'color_picker', 'name': 'mountain_color', 'label': 'Mountain', 'default': '#8B4513'},
            {'type': 'color_picker', 'name': 'snow_color', 'label': 'Snow', 'default': '#FFFFFF'},
            {'type': 'color_picker', 'name': 'desert_color', 'label': 'Desert', 'default': '#DEB887'}
        ],
        'animation_parameters': [
            {'type': 'checkbox', 'name': 'shoreline_waves', 'label': 'Shoreline Waves', 'default': False},
            {'type': 'checkbox', 'name': 'ocean_currents', 'label': 'Ocean Currents', 'default': False},
            {'type': 'checkbox', 'name': 'wind_sway', 'label': 'Wind Sway (Trees/Grass)', 'default': False},
            {'type': 'checkbox', 'name': 'sand_dunes', 'label': 'Sand Dunes Movement', 'default': False},
            {'type': 'checkbox', 'name': 'snow_drift', 'label': 'Snow Drift', 'default': False},
            {'type': 'checkbox', 'name': 'rain_effects', 'label': 'Rain Effects', 'default': False},
            {'type': 'checkbox', 'name': 'fog_effects', 'label': 'Fog Effects', 'default': False}
        ],
        'preview_enabled': True,
        'frame_options': True,
        'selection_options': True
    },
    'texture_2d': {
        'name': '2D Texture Creation',
        'parameters': [
            {'type': 'dropdown', 'name': 'texture_type', 'label': 'Texture Type', 'options': ['None', 'Water', 'Lava', 'Fire', 'Smoke', 'Fog', 'Crystal', 'Wind', 'Portal'], 'default': 'None'},
            {'type': 'slider', 'name': 'block_size', 'label': 'Block Size', 'range': (2, 16), 'default': 4},
            {'type': 'slider', 'name': 'opacity', 'label': 'Opacity', 'range': (50, 255), 'default': 255},
            {'type': 'color_picker', 'name': 'color1', 'label': 'Primary Color', 'default': '#8B4513'},
            {'type': 'color_picker', 'name': 'color2', 'label': 'Secondary Color', 'default': '#A0522D'},
            {'type': 'slider', 'name': 'seed', 'label': 'Seed', 'range': (1, 99999), 'default': 42},
            {'type': 'checkbox', 'name': 'use_custom_size', 'label': 'Use Custom Size', 'default': False},
            {'type': 'slider', 'name': 'custom_width', 'label': 'Custom Width', 'range': (16, 512), 'default': 64},
            {'type': 'textbox', 'name': 'custom_width_text', 'label': 'Width Text', 'default': '64'},
            {'type': 'slider', 'name': 'custom_height', 'label': 'Custom Height', 'range': (16, 512), 'default': 64},
            {'type': 'textbox', 'name': 'custom_height_text', 'label': 'Height Text', 'default': '64'},
            {'type': 'checkbox', 'name': 'use_custom_position', 'label': 'Use Custom Position', 'default': False},
            {'type': 'slider', 'name': 'position_x', 'label': 'Position X', 'range': (0, 1000), 'default': 0},
            {'type': 'textbox', 'name': 'position_x_text', 'label': 'X Text', 'default': '0'},
            {'type': 'slider', 'name': 'position_y', 'label': 'Position Y', 'range': (0, 1000), 'default': 0},
            {'type': 'textbox', 'name': 'position_y_text', 'label': 'Y Text', 'default': '0'},
            {'type': 'dropdown', 'name': 'texture_mode', 'label': 'Texture Mode', 'options': ['Static', 'Animated'], 'default': 'Static'},
            {'type': 'slider', 'name': 'animation_frames', 'label': 'Number of Frames', 'range': (2, 60), 'default': 4},
            {'type': 'slider', 'name': 'animation_speed', 'label': 'Animation Speed', 'range': (1, 10), 'default': 5},
            {'type': 'checkbox', 'name': 'keep_other_data', 'label': 'Keep Other Data', 'default': True}
        ],
        'preview_enabled': True,
        'frame_options': False,  # Use custom texture_mode instead
        'selection_options': True
    },
    'generate_lod': {
        'name': 'Generate LOD',
        'parameters': [
            {'type': 'slider', 'name': 'lod_level', 'label': 'LOD Level', 'range': (1, 8), 'default': 2},
            {'type': 'dropdown', 'name': 'method', 'label': 'Method', 'options': ['Box Downsample', 'Gaussian Blur', 'Bilinear', 'Nearest Neighbor'], 'default': 'Box Downsample'},
            {'type': 'checkbox', 'name': 'preserve_alpha', 'label': 'Preserve Alpha', 'default': True},
            {'type': 'checkbox', 'name': 'export_only', 'label': 'Export Only (Don\'t Replace)', 'default': False}
        ],
        'preview_enabled': True,
        'frame_options': True,
        'selection_options': True
    },
    'atmospheric_lighting': {
        'name': 'Atmospheric Lighting',
        'parameters': [
            # Simplified Controls
            {'type': 'checkbox', 'name': 'auto_detect_lights', 'label': 'Auto-detect Light Sources', 'default': True},
            {'type': 'double_slider', 'name': 'warmth', 'label': 'Warmth (Cold ← → Hot)', 'range': (0.0, 1.0), 'default': 0.5},
            {'type': 'double_slider', 'name': 'global_intensity', 'label': 'Light Intensity', 'range': (0.5, 3.0), 'default': 1.0},
            {'type': 'double_slider', 'name': 'ambient_light', 'label': 'Ambient Light', 'range': (0.0, 1.0), 'default': 0.2},
            {'type': 'checkbox', 'name': 'enable_shadows', 'label': 'Enable Shadows', 'default': True},
            {'type': 'double_slider', 'name': 'shadow_darkness', 'label': 'Shadow Darkness', 'range': (0.1, 1.0), 'default': 0.7},
        ],
        'preview_enabled': True,
        'frame_options': True,
        'selection_options': True
    },
    'wind_waker': {
        'name': 'Gamecube',
        'parameters': [
            # Standardized Controls (Always Visible)
            {'type': 'double_slider', 'name': 'base_effect_strength', 'label': 'Base Effect Strength', 'range': (0.0, 1.0), 'default': 1.0},
            {'type': 'double_slider', 'name': 'brightness', 'label': 'Brightness', 'range': (1.0, 2.0), 'default': 1.3},
            {'type': 'double_slider', 'name': 'saturation', 'label': 'Saturation', 'range': (1.0, 2.0), 'default': 1.3},
            {'type': 'double_slider', 'name': 'contrast', 'label': 'Contrast', 'range': (0.5, 2.0), 'default': 1.0},
            {'type': 'double_slider', 'name': 'color_temperature', 'label': 'Color Temperature', 'range': (0.5, 1.5), 'default': 1.0},
            {'type': 'double_slider', 'name': 'blur_sharpness', 'label': 'Blur/Sharpness', 'range': (0.0, 1.0), 'default': 0.0},
            {'type': 'double_slider', 'name': 'noise_grain', 'label': 'Noise/Grain', 'range': (0.0, 1.0), 'default': 0.0},
        ],
        'advanced_parameters': [
            # Advanced Controls (Hidden by Default)
            {'type': 'slider', 'name': 'cel_levels', 'label': 'Cel Shading Levels', 'range': (3, 6), 'default': 4},
            {'type': 'checkbox', 'name': 'enable_outlines', 'label': 'Subtle Outlines', 'default': False},
        ],
        'preview_enabled': True,
        'frame_options': True,
        'selection_options': True
    },
    'ocarina_of_time': {
        'name': 'Ocarina of Time',
        'parameters': [
            # Standardized Controls (Always Visible)
            {'type': 'double_slider', 'name': 'base_effect_strength', 'label': 'Base Effect Strength', 'range': (0.0, 1.0), 'default': 1.0},
            {'type': 'double_slider', 'name': 'brightness', 'label': 'Brightness', 'range': (1.0, 2.0), 'default': 1.0},
            {'type': 'double_slider', 'name': 'saturation', 'label': 'Saturation', 'range': (0.5, 1.5), 'default': 0.85},
            {'type': 'double_slider', 'name': 'contrast', 'label': 'Contrast', 'range': (0.5, 2.0), 'default': 1.8},
            {'type': 'double_slider', 'name': 'color_temperature', 'label': 'Color Temperature', 'range': (0.5, 1.5), 'default': 1.1},
            {'type': 'double_slider', 'name': 'blur_sharpness', 'label': 'Blur/Sharpness', 'range': (0.0, 1.0), 'default': 0.5},
            {'type': 'double_slider', 'name': 'noise_grain', 'label': 'Noise/Grain', 'range': (0.0, 1.0), 'default': 0.6},
        ],
        'advanced_parameters': [
            # Advanced Controls (Hidden by Default)
            {'type': 'double_slider', 'name': 'texture_blur', 'label': 'Texture Blur (N64 Smear)', 'range': (1.0, 5.0), 'default': 3.0},
            {'type': 'double_slider', 'name': 'fog_amount', 'label': 'Distance Fog', 'range': (0.0, 1.0), 'default': 0.6},
            {'type': 'double_slider', 'name': 'vignette_strength', 'label': 'Vignette (Dream/Memory Effect)', 'range': (0.0, 1.0), 'default': 0.7},
            {'type': 'checkbox', 'name': 'enable_noise', 'label': 'N64 Grain/Noise', 'default': True},
            {'type': 'checkbox', 'name': 'enable_polygon_look', 'label': 'Low-Polygon Look (N64 Geometry)', 'default': True},
        ],
        'preview_enabled': True,
        'frame_options': True,
        'selection_options': True
    },
    'luigis_mansion': {
        'name': "Luigi's Mansion",
        'parameters': [
            # Standardized Controls (Always Visible)
            {'type': 'double_slider', 'name': 'base_effect_strength', 'label': 'Base Effect Strength', 'range': (0.0, 1.0), 'default': 1.0},
            {'type': 'double_slider', 'name': 'brightness', 'label': 'Brightness', 'range': (1.0, 2.0), 'default': 1.0},
            {'type': 'double_slider', 'name': 'saturation', 'label': 'Saturation', 'range': (0.5, 1.5), 'default': 0.6},
            {'type': 'double_slider', 'name': 'contrast', 'label': 'Contrast', 'range': (0.5, 2.0), 'default': 1.3},
            {'type': 'double_slider', 'name': 'color_temperature', 'label': 'Color Temperature', 'range': (0.5, 1.5), 'default': 1.2},
            {'type': 'double_slider', 'name': 'blur_sharpness', 'label': 'Blur/Sharpness', 'range': (0.0, 1.0), 'default': 0.2},
            {'type': 'double_slider', 'name': 'noise_grain', 'label': 'Noise/Grain', 'range': (0.0, 1.0), 'default': 0.3},
        ],
        'advanced_parameters': [
            # Advanced Controls (Hidden by Default)
            {'type': 'double_slider', 'name': 'ambient_darkness', 'label': 'Ambient Darkness', 'range': (0.0, 1.0), 'default': 0.0},
            {'type': 'double_slider', 'name': 'flashlight_intensity', 'label': 'Flashlight Intensity', 'range': (0.0, 1.0), 'default': 0.3},
            {'type': 'double_slider', 'name': 'light_warmth', 'label': 'Light Warmth', 'range': (0.5, 1.5), 'default': 1.5},
            {'type': 'double_slider', 'name': 'dust_haze', 'label': 'Dust/Haze', 'range': (0.0, 1.0), 'default': 0.5},
            {'type': 'double_slider', 'name': 'desaturation', 'label': 'Color Desaturation', 'range': (0.0, 1.0), 'default': 0.4},
            {'type': 'checkbox', 'name': 'enable_glow', 'label': 'Ectoplasmic Glow', 'default': False},
        ],
        'preview_enabled': True,
        'frame_options': True,
        'selection_options': True
    },
    'eternal_darkness': {
        'name': 'Eternal Darkness',
        'parameters': [
            # Standardized Controls (Always Visible)
            {'type': 'double_slider', 'name': 'base_effect_strength', 'label': 'Base Effect Strength', 'range': (0.0, 1.0), 'default': 1.0},
            {'type': 'double_slider', 'name': 'brightness', 'label': 'Brightness', 'range': (1.0, 2.0), 'default': 1.0},
            {'type': 'double_slider', 'name': 'saturation', 'label': 'Saturation', 'range': (0.5, 1.5), 'default': 0.5},
            {'type': 'double_slider', 'name': 'contrast', 'label': 'Contrast', 'range': (0.5, 2.0), 'default': 1.5},
            {'type': 'double_slider', 'name': 'color_temperature', 'label': 'Color Temperature', 'range': (0.5, 1.5), 'default': 0.8},
            {'type': 'double_slider', 'name': 'blur_sharpness', 'label': 'Blur/Sharpness', 'range': (0.0, 1.0), 'default': 0.3},
            {'type': 'double_slider', 'name': 'noise_grain', 'label': 'Noise/Grain', 'range': (0.0, 1.0), 'default': 0.4},
        ],
        'advanced_parameters': [
            # Advanced Controls (Hidden by Default)
            {'type': 'double_slider', 'name': 'sanity_effect_intensity', 'label': 'Sanity Effect Intensity', 'range': (0.0, 1.0), 'default': 0.6},
            {'type': 'double_slider', 'name': 'lighting_depth', 'label': 'Pre-Rendered Lighting Depth', 'range': (0.5, 2.0), 'default': 1.5},
            {'type': 'double_slider', 'name': 'volumetric_fog', 'label': 'Volumetric Fog', 'range': (0.0, 1.0), 'default': 0.7},
            {'type': 'checkbox', 'name': 'enable_color_inversion', 'label': 'Enable Color Inversion', 'default': False},
            {'type': 'checkbox', 'name': 'enable_sepia', 'label': 'Enable Sepia Tone', 'default': False},
            {'type': 'checkbox', 'name': 'enable_screen_tilt', 'label': 'Enable Screen Tilt', 'default': False},
        ],
        'preview_enabled': True,
        'frame_options': True,
        'selection_options': True
    },
    'pokemon_colosseum': {
        'name': 'Pokémon Colosseum',
        'parameters': [
            # Standardized Controls (Always Visible)
            {'type': 'double_slider', 'name': 'base_effect_strength', 'label': 'Base Effect Strength', 'range': (0.0, 1.0), 'default': 1.0},
            {'type': 'double_slider', 'name': 'brightness', 'label': 'Brightness', 'range': (1.0, 2.0), 'default': 1.0},
            {'type': 'double_slider', 'name': 'saturation', 'label': 'Saturation', 'range': (0.5, 1.5), 'default': 0.6},
            {'type': 'double_slider', 'name': 'contrast', 'label': 'Contrast', 'range': (0.5, 2.0), 'default': 1.3},
            {'type': 'double_slider', 'name': 'color_temperature', 'label': 'Color Temperature', 'range': (0.5, 1.5), 'default': 1.0},
            {'type': 'double_slider', 'name': 'blur_sharpness', 'label': 'Blur/Sharpness', 'range': (0.0, 1.0), 'default': 0.1},
            {'type': 'double_slider', 'name': 'noise_grain', 'label': 'Noise/Grain', 'range': (0.0, 1.0), 'default': 0.2},
        ],
        'advanced_parameters': [
            # Advanced Controls (Hidden by Default)
            {'type': 'double_slider', 'name': 'battle_lighting', 'label': 'Dynamic Battle Lighting', 'range': (0.0, 1.0), 'default': 0.7},
            {'type': 'double_slider', 'name': 'specular_highlights', 'label': 'Specular Highlights', 'range': (0.0, 1.0), 'default': 0.8},
            {'type': 'double_slider', 'name': 'bloom_intensity', 'label': 'Cinematic Bloom', 'range': (0.0, 1.0), 'default': 0.6},
            {'type': 'double_slider', 'name': 'desaturation', 'label': 'Orre Desaturation', 'range': (0.0, 1.0), 'default': 0.4},
            {'type': 'checkbox', 'name': 'enable_sharp_edges', 'label': 'Sharp Edge Detail (Minimal Anti-Aliasing)', 'default': True},
        ],
        'preview_enabled': True,
        'frame_options': True,
        'selection_options': True
    },
    'mario_kart_8': {
        'name': 'Mario Kart 8',
        'parameters': [
            # Standardized Controls (Always Visible)
            {'type': 'double_slider', 'name': 'base_effect_strength', 'label': 'Base Effect Strength', 'range': (0.0, 1.0), 'default': 1.0},
            {'type': 'double_slider', 'name': 'brightness', 'label': 'Brightness', 'range': (1.0, 2.0), 'default': 1.2},
            {'type': 'double_slider', 'name': 'saturation', 'label': 'Saturation', 'range': (0.5, 1.5), 'default': 1.3},
            {'type': 'double_slider', 'name': 'contrast', 'label': 'Contrast', 'range': (0.5, 2.0), 'default': 1.2},
            {'type': 'double_slider', 'name': 'color_temperature', 'label': 'Color Temperature', 'range': (0.5, 1.5), 'default': 1.0},
            {'type': 'double_slider', 'name': 'blur_sharpness', 'label': 'Blur/Sharpness', 'range': (0.0, 1.0), 'default': 0.0},
            {'type': 'double_slider', 'name': 'noise_grain', 'label': 'Noise/Grain', 'range': (0.0, 1.0), 'default': 0.0},
        ],
        'advanced_parameters': [
            # Advanced Controls (Hidden by Default)
            {'type': 'double_slider', 'name': 'specular_gloss', 'label': 'High-Gloss Reflections', 'range': (0.0, 1.0), 'default': 0.8},
            {'type': 'double_slider', 'name': 'bloom_intensity', 'label': 'Bloom/Glow', 'range': (0.0, 1.0), 'default': 0.4},
            {'type': 'double_slider', 'name': 'motion_blur', 'label': 'Speed Motion Blur', 'range': (0.0, 1.0), 'default': 0.0},
            {'type': 'checkbox', 'name': 'enable_sharp_edges', 'label': 'Sharp Edges (No Anti-Aliasing)', 'default': True},
        ],
        'preview_enabled': True,
        'frame_options': True,
        'selection_options': True
    },
    'image_enhancement': {
        'name': '⭐ Image Enhancement',
        'parameters': [
            {'type': 'checkbox', 'name': 'enable_upscale_size', 'label': 'Upscale Image Size', 'default': False},
            {'type': 'slider', 'name': 'upscale_size_factor', 'label': 'Size Scale (1-8x)', 'range': (1, 8), 'default': 2},
            {'type': 'checkbox', 'name': 'enable_upscale_quality', 'label': 'Upscale Image Quality', 'default': True},
            {'type': 'slider', 'name': 'upscale_quality_factor', 'label': 'Quality Level (1-8)', 'range': (1, 8), 'default': 5},
        ],
        'preview_enabled': True,
        'frame_options': True,
        'selection_options': True
    },
    'quality_enhancement': {
        'name': 'Quality Enhancement',
        'parameters': [
            {'type': 'double_slider', 'name': 'sharpness', 'label': 'Sharpness', 'range': (0.0, 2.0), 'default': 1.0},
            {'type': 'double_slider', 'name': 'detail', 'label': 'Detail Enhancement', 'range': (0.0, 1.5), 'default': 0.5},
            {'type': 'double_slider', 'name': 'contrast', 'label': 'Local Contrast', 'range': (0.0, 1.0), 'default': 0.3},
            {'type': 'double_slider', 'name': 'denoise', 'label': 'Denoise Strength', 'range': (0.0, 1.0), 'default': 0.2},
            {'type': 'checkbox', 'name': 'enhance_edges', 'label': 'Enhance Edges', 'default': True},
            {'type': 'checkbox', 'name': 'preserve_colors', 'label': 'Preserve Colors', 'default': True},
        ],
        'preview_enabled': True,
        'frame_options': True,
        'selection_options': True
    },
    'upscale': {
        'name': 'Upscale',
        'parameters': [
            {'type': 'dropdown', 'name': 'scale_factor', 'label': 'Scale Factor', 'options': ['2x (2x2)', '4x (4x4)', '8x (8x8)'], 'default': '2x (2x2)'},
            {'type': 'dropdown', 'name': 'method', 'label': 'Interpolation Method', 'options': ['Nearest Neighbor (Pixel Perfect)', 'Lanczos (High Quality)', 'Bicubic (Smooth)'], 'default': 'Lanczos (High Quality)'},
            {'type': 'checkbox', 'name': 'preserve_alpha', 'label': 'Preserve Alpha Channel', 'default': True},
        ],
        'preview_enabled': True,
        'frame_options': True,
        'selection_options': True
    },
    'noise_reduction': {
        'name': 'Noise Reduction',
        'parameters': [
            {'type': 'slider', 'name': 'strength', 'label': 'Strength', 'range': (1, 100), 'default': 30},
            {'type': 'dropdown', 'name': 'preset', 'label': 'Preset', 'options': ['Light', 'Medium', 'Heavy', 'Custom'], 'default': 'Medium'},
            {'type': 'checkbox', 'name': 'preserve_edges', 'label': 'Preserve Edges', 'default': True},
        ],
        'preview_enabled': True,
        'frame_options': True,
        'selection_options': True
    },
    'hdr_tone_mapping': {
        'name': 'HDR Tone Mapping',
        'parameters': [
            {'type': 'double_slider', 'name': 'exposure', 'label': 'Exposure', 'range': (-2.0, 2.0), 'default': 0.0},
            {'type': 'double_slider', 'name': 'highlight_recovery', 'label': 'Highlight Recovery', 'range': (0.0, 1.0), 'default': 0.5},
            {'type': 'double_slider', 'name': 'shadow_lift', 'label': 'Shadow Lift', 'range': (0.0, 1.0), 'default': 0.3},
            {'type': 'dropdown', 'name': 'mode', 'label': 'Mode', 'options': ['Local HDR', 'Global HDR'], 'default': 'Local HDR'},
        ],
        'preview_enabled': True,
        'frame_options': True,
        'selection_options': True
    }

}


# Professional Torch Lighting Helper Methods for UnifiedEffectDialog
def _detect_light_sources_advanced(img_array, brightness_threshold, color_sensitivity, min_light_size):
    """Advanced light source detection using professional computer vision techniques."""
    import numpy as np
    import cv2
    
    height, width = img_array.shape[:2]
    light_sources = []
    
    # Method 1: Brightness-based detection
    gray = cv2.cvtColor(img_array, cv2.COLOR_RGBA2GRAY)
    
    # Use adaptive thresholding for better detection
    adaptive_thresh = cv2.adaptiveThreshold(gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 11, 2)
    
    # Find bright spots above threshold
    bright_mask = gray > brightness_threshold
    
    # Combine with adaptive threshold
    combined_mask = cv2.bitwise_and(bright_mask.astype(np.uint8) * 255, adaptive_thresh)
    
    # Morphological operations to clean up the mask
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5))
    combined_mask = cv2.morphologyEx(combined_mask, cv2.MORPH_CLOSE, kernel)
    combined_mask = cv2.morphologyEx(combined_mask, cv2.MORPH_OPEN, kernel)
    
    # Find contours
    contours, _ = cv2.findContours(combined_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    
    for contour in contours:
        area = cv2.contourArea(contour)
        if area > min_light_size:
            # Get center and calculate brightness
            M = cv2.moments(contour)
            if M["m00"] != 0:
                cx = int(M["m10"] / M["m00"])
                cy = int(M["m01"] / M["m00"])
                
                # Calculate average brightness in the region
                mask = np.zeros(gray.shape, dtype=np.uint8)
                cv2.fillPoly(mask, [contour], 255)
                mean_brightness = cv2.mean(gray, mask)[0]
                
                if mean_brightness > brightness_threshold:
                    light_sources.append((cx, cy, mean_brightness))
    
    # Method 2: Color-based detection for warm colors
    if len(light_sources) < 2:  # If we don't have enough bright sources
        hsv = cv2.cvtColor(img_array, cv2.COLOR_RGBA2RGB)
        hsv = cv2.cvtColor(hsv, cv2.COLOR_RGB2HSV)
        
        # Define warm color ranges (orange, yellow, red)
        lower_warm1 = np.array([0, 100, 100])      # Red
        upper_warm1 = np.array([10, 255, 255])
        lower_warm2 = np.array([10, 100, 100])     # Orange
        upper_warm2 = np.array([30, 255, 255])
        lower_warm3 = np.array([30, 100, 100])     # Yellow
        upper_warm3 = np.array([60, 255, 255])
        
        # Create combined warm color mask
        warm_mask1 = cv2.inRange(hsv, lower_warm1, upper_warm1)
        warm_mask2 = cv2.inRange(hsv, lower_warm2, upper_warm2)
        warm_mask3 = cv2.inRange(hsv, lower_warm3, upper_warm3)
        warm_mask = cv2.bitwise_or(warm_mask1, cv2.bitwise_or(warm_mask2, warm_mask3))
        
        # Apply sensitivity adjustment
        if color_sensitivity < 5:
            warm_mask = cv2.erode(warm_mask, np.ones((3, 3), np.uint8), iterations=1)
        elif color_sensitivity > 5:
            warm_mask = cv2.dilate(warm_mask, np.ones((3, 3), np.uint8), iterations=1)
        
        # Find contours of warm areas
        contours, _ = cv2.findContours(warm_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        
        for contour in contours:
            area = cv2.contourArea(contour)
            if area > min_light_size * 1.5:  # Larger minimum for color detection
                M = cv2.moments(contour)
                if M["m00"] != 0:
                    cx = int(M["m10"] / M["m00"])
                    cy = int(M["m01"] / M["m00"])
                    
                    # Calculate color intensity
                    mask = np.zeros(hsv.shape[:2], dtype=np.uint8)
                    cv2.fillPoly(mask, [contour], 255)
                    mean_saturation = cv2.mean(hsv[:, :, 1], mask)[0]
                    mean_value = cv2.mean(hsv[:, :, 2], mask)[0]
                    
                    if mean_saturation > 100 and mean_value > 150:
                        light_sources.append((cx, cy, mean_value))
    
    # Remove duplicates and sort by brightness
    unique_sources = []
    for source in light_sources:
        x, y, brightness = source
        # Check if this source is too close to existing ones
        too_close = False
        for existing in unique_sources:
            ex, ey, _ = existing
            distance = np.sqrt((x - ex)**2 + (y - ey)**2)
            if distance < min_light_size:
                too_close = True
                break
        if not too_close:
            unique_sources.append(source)
    
    # Sort by brightness and return top sources
    unique_sources.sort(key=lambda x: x[2], reverse=True)
    return [(x, y) for x, y, _ in unique_sources[:3]]  # Return top 3 light sources

def _detect_objects_advanced(img_array, edge_threshold_low, edge_threshold_high, min_object_size):
    """Advanced object detection using professional edge detection and contour analysis."""
    import numpy as np
    import cv2
    
    # Convert to grayscale
    gray = cv2.cvtColor(img_array, cv2.COLOR_RGBA2GRAY)
    
    # Apply Gaussian blur to reduce noise
    blurred = cv2.GaussianBlur(gray, (5, 5), 0)
    
    # Use Canny edge detection with adjustable thresholds
    edges = cv2.Canny(blurred, edge_threshold_low, edge_threshold_high)
    
    # Morphological operations to connect nearby edges
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3))
    edges = cv2.morphologyEx(edges, cv2.MORPH_CLOSE, kernel)
    
    # Dilate to make edges more prominent
    edges = cv2.dilate(edges, kernel, iterations=1)
    
    # Find contours
    contours, _ = cv2.findContours(edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    
    objects = []
    for contour in contours:
        area = cv2.contourArea(contour)
        if area > min_object_size:
            # Get bounding rectangle
            x, y, w, h = cv2.boundingRect(contour)
            
            # Calculate additional properties
            perimeter = cv2.arcLength(contour, True)
            if perimeter > 0:
                circularity = 4 * np.pi * area / (perimeter * perimeter)
            else:
                circularity = 0
            
            # Calculate aspect ratio
            aspect_ratio = float(w) / h if h > 0 else 0
            
            # Calculate solidity (area / convex hull area)
            hull = cv2.convexHull(contour)
            hull_area = cv2.contourArea(hull)
            solidity = float(area) / hull_area if hull_area > 0 else 0
            
            objects.append({
                'contour': contour,
                'bbox': (x, y, w, h),
                'center': (x + w//2, y + h//2),
                'area': area,
                'perimeter': perimeter,
                'circularity': circularity,
                'aspect_ratio': aspect_ratio,
                'solidity': solidity
            })
    
    # Sort objects by area (largest first)
    objects.sort(key=lambda x: x['area'], reverse=True)
    
    return objects[:10]  # Return top 10 largest objects

def _find_fallback_light_position(img_array):
    """Intelligent fallback for light position when no sources are detected."""
    import numpy as np
    import cv2
    
    height, width = img_array.shape[:2]
    
    # Analyze image to find the best fallback position
    gray = cv2.cvtColor(img_array, cv2.COLOR_RGBA2GRAY)
    
    # Find the brightest region
    min_val, max_val, min_loc, max_loc = cv2.minMaxLoc(gray)
    
    # If there's a reasonably bright area, use it
    if max_val > 100:
        return [max_loc]
    
    # Otherwise, use rule of thirds positioning
    # Try positions that would make sense for torch placement
    candidates = [
        (width // 3, height // 3),           # Top-left third
        (2 * width // 3, height // 3),       # Top-right third
        (width // 3, 2 * height // 3),       # Bottom-left third
        (2 * width // 3, 2 * height // 3),   # Bottom-right third
        (width // 2, height // 2),           # Center
    ]
    
    # Find the brightest candidate position
    best_pos = candidates[0]
    best_brightness = 0
    
    for x, y in candidates:
        # Sample a small area around the candidate
        x1, y1 = max(0, x-20), max(0, y-20)
        x2, y2 = min(width, x+20), min(height, y+20)
        region = gray[y1:y2, x1:x2]
        
        if region.size > 0:
            avg_brightness = np.mean(region)
            if avg_brightness > best_brightness:
                best_brightness = avg_brightness
                best_pos = (x, y)
    
    return [best_pos]

def _create_professional_lighting_map(img_array, light_sources, radius, intensity, falloff_exponent):
    """Create professional lighting map with realistic falloff and multiple light sources."""
    import numpy as np
    
    height, width = img_array.shape[:2]
    lighting_map = np.zeros((height, width), dtype=np.float32)
    
    for light_x, light_y in light_sources:
        # Create distance map from light source
        y, x = np.ogrid[:height, :width]
        distance = np.sqrt((x - light_x)**2 + (y - light_y)**2)
        
        # Create realistic falloff with configurable exponent
        # Use inverse power law: I = I0 / (1 + (d/r)^n)
        normalized_distance = distance / radius
        light_strength = intensity / (1 + normalized_distance**falloff_exponent)
        
        # Apply smooth falloff curve
        light_strength = np.clip(light_strength, 0, 1)
        
        # Add to lighting map (use maximum to combine multiple lights)
        lighting_map = np.maximum(lighting_map, light_strength)
    
    # Normalize the final lighting map
    if lighting_map.max() > 0:
        lighting_map = lighting_map / lighting_map.max()
    
    return lighting_map

def _apply_torch_color_advanced(lighting_map, torch_color, warmth):
    """Apply professional torch color and warmth with advanced color temperature control."""
    import numpy as np
    
    # Convert hex color to RGB
    torch_rgb = tuple(int(torch_color[i:i+2], 16) for i in (1, 3, 5))
    
    # Create colored lighting map
    colored_lighting = np.zeros((lighting_map.shape[0], lighting_map.shape[1], 3), dtype=np.float32)
    
    # Apply color with warmth adjustment
    for i, color_component in enumerate(torch_rgb):
        # Apply warmth as a multiplier that affects different channels differently
        if i == 0:  # Red channel - warmth increases red
            warmth_factor = warmth
        elif i == 1:  # Green channel - moderate warmth
            warmth_factor = 1.0 + (warmth - 1.0) * 0.7
        else:  # Blue channel - warmth decreases blue (cooler)
            warmth_factor = 1.0 - (warmth - 1.0) * 0.3
        
        colored_lighting[:, :, i] = lighting_map * (color_component / 255.0) * warmth_factor
    
    return colored_lighting

def _add_realistic_flicker(lighting_map, flicker_amount):
    """Add realistic flickering effect with temporal variation."""
    import numpy as np
    import cv2
    
    # Create more realistic flicker pattern
    if len(lighting_map.shape) == 3:  # Colored lighting (height, width, 3)
        # Create flicker with spatial variation
        flicker = np.random.normal(1.0, flicker_amount / 200.0, lighting_map.shape[:2])
        # Add some spatial correlation to make it more realistic
        flicker = cv2.GaussianBlur(flicker, (5, 5), 1.0)
        flicker = np.clip(flicker, 0.7, 1.3)  # More conservative range
        flickered = lighting_map * flicker[:, :, np.newaxis]
    else:  # Grayscale lighting (height, width)
        flicker = np.random.normal(1.0, flicker_amount / 200.0, lighting_map.shape)
        flicker = cv2.GaussianBlur(flicker, (5, 5), 1.0)
        flicker = np.clip(flicker, 0.7, 1.3)
        flickered = lighting_map * flicker
    
    return np.clip(flickered, 0, 1)

def _create_professional_shadow_map(img_array, light_sources, objects, shadow_length, shadow_softness, shadow_offset):
    """Create professional shadow map with realistic shadow casting."""
    import numpy as np
    import cv2
    
    height, width = img_array.shape[:2]
    shadow_map = np.ones((height, width), dtype=np.float32)
    
    for light_x, light_y in light_sources:
        for obj in objects:
            # Get object properties
            obj_x, obj_y = obj['center']
            obj_w, obj_h = obj['bbox'][2], obj['bbox'][3]
            
            # Calculate shadow direction (from light to object)
            dx = obj_x - light_x
            dy = obj_y - light_y
            distance = np.sqrt(dx**2 + dy**2)
            
            if distance > 0:
                # Normalize direction
                dx /= distance
                dy /= distance
                
                # Add offset to make shadows more realistic
                offset_x = dx * shadow_offset
                offset_y = dy * shadow_offset
                
                # Create shadow area
                shadow_start_x = obj_x + offset_x
                shadow_start_y = obj_y + offset_y
                shadow_end_x = shadow_start_x + dx * shadow_length
                shadow_end_y = shadow_start_y + dy * shadow_length
                
                # Create shadow mask
                shadow_mask = np.zeros((height, width), dtype=np.uint8)
                
                # Draw shadow as an ellipse with realistic proportions
                shadow_center = (int(shadow_end_x), int(shadow_end_y))
                shadow_size = (int(obj_w * 1.2), int(obj_h * 1.2))
                
                cv2.ellipse(shadow_mask, shadow_center, shadow_size, 0, 0, 360, 255, -1)
                
                # Apply professional softness with multiple blur passes
                if shadow_softness > 1.0:
                    kernel_size = int(shadow_softness * 8)
                    if kernel_size % 2 == 0:
                        kernel_size += 1
                    shadow_mask = cv2.GaussianBlur(shadow_mask, (kernel_size, kernel_size), shadow_softness)
                
                # Convert to float and apply to shadow map
                shadow_strength = shadow_mask.astype(np.float32) / 255.0
                shadow_map = np.minimum(shadow_map, 1.0 - shadow_strength)
    
    return shadow_map

def _apply_professional_shadows(lighting_map, shadow_map, shadow_darkness):
    """Apply professional shadows with realistic blending."""
    import numpy as np
    
    if len(lighting_map.shape) == 3:  # Colored lighting
        shadow_factor = 1.0 - (shadow_map * shadow_darkness)
        shadow_factor = shadow_factor[:, :, np.newaxis]
        return lighting_map * shadow_factor
    else:  # Grayscale lighting
        shadow_factor = 1.0 - (shadow_map * shadow_darkness)
        return lighting_map * shadow_factor

def _apply_professional_lighting(img_array, lighting_map, ambient_light, contrast_boost):
    """Apply professional lighting with advanced blending modes."""
    import numpy as np
    
    # Convert image to float
    img_float = img_array.astype(np.float32) / 255.0
    
    # Apply ambient light
    img_float = img_float * ambient_light
    
    # Apply lighting map with professional blending
    if len(lighting_map.shape) == 3:  # Colored lighting
        # Use screen blending for more realistic light addition
        for i in range(3):
            img_float[:, :, i] = 1.0 - (1.0 - img_float[:, :, i]) * (1.0 - lighting_map[:, :, i])
    else:  # Grayscale lighting
        for i in range(3):
            img_float[:, :, i] = 1.0 - (1.0 - img_float[:, :, i]) * (1.0 - lighting_map)
    
    # Apply contrast boost
    img_float = np.clip((img_float - 0.5) * contrast_boost + 0.5, 0, 1)
    
    # Convert back to uint8
    return (img_float * 255).astype(np.uint8)

def _add_rim_lighting(img_array, light_sources, torch_color):
    """Add rim lighting effect for professional look."""
    import numpy as np
    import cv2
    
    if not light_sources:
        return img_array
    
    # Convert to grayscale for edge detection
    gray = cv2.cvtColor(img_array, cv2.COLOR_RGBA2GRAY)
    
    # Find edges
    edges = cv2.Canny(gray, 50, 150)
    
    # Dilate edges to create rim
    kernel = np.ones((3, 3), np.uint8)
    rim_mask = cv2.dilate(edges, kernel, iterations=2)
    
    # Apply rim lighting
    result = img_array.copy().astype(np.float32)
    torch_rgb = tuple(int(torch_color[i:i+2], 16) for i in (1, 3, 5))
    
    rim_factor = 0.1  # Subtle rim lighting
    for i, color_component in enumerate(torch_rgb):
        result[:, :, i] = np.clip(result[:, :, i] + rim_mask * (color_component / 255.0) * rim_factor, 0, 255)
    
    return result.astype(np.uint8)

def _add_professional_atmosphere(img_array, density, torch_color, light_sources):
    """Add professional atmospheric effects."""
    import numpy as np
    
    if density == 0:
        return img_array
    
    height, width = img_array.shape[:2]
    
    # Create atmospheric overlay
    atmosphere = np.zeros((height, width, 3), dtype=np.float32)
    torch_rgb = tuple(int(torch_color[i:i+2], 16) for i in (1, 3, 5))
    
    # Add subtle atmospheric tint
    for i, color_component in enumerate(torch_rgb):
        atmosphere[:, :, i] = (color_component / 255.0) * (density / 100.0) * 0.05
    
    # Apply atmospheric effect
    img_float = img_array.astype(np.float32) / 255.0
    img_float[:, :, :3] = np.clip(img_float[:, :, :3] + atmosphere, 0, 1)
    
    return (img_float * 255).astype(np.uint8)
