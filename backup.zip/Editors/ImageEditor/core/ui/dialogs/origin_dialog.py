"""
Origin Selection Dialog for Image Editor
Extracted from dialogs.py
"""

from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QLabel, QRadioButton, QGroupBox, QDialogButtonBox
)


class OriginSelectionDialog(QDialog):
    """Dialog for selecting origin position after crop/remove blank space operations"""
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Select Origin")
        self.setModal(True)
        self.resize(300, 200)
        self.selected_origin = "top-left"  # Default
        
        layout = QVBoxLayout(self)
        
        label = QLabel("Select origin position for the cropped content:", self)
        layout.addWidget(label)
        
        # Radio buttons for origin selection
        self.top_left_radio = QRadioButton("Top Left", self)
        self.top_left_radio.setChecked(True)
        self.top_center_radio = QRadioButton("Top Center", self)
        self.top_right_radio = QRadioButton("Top Right", self)
        self.center_left_radio = QRadioButton("Center Left", self)
        self.center_radio = QRadioButton("Center", self)
        self.center_right_radio = QRadioButton("Center Right", self)
        self.bottom_left_radio = QRadioButton("Bottom Left", self)
        self.bottom_center_radio = QRadioButton("Bottom Center", self)
        self.bottom_right_radio = QRadioButton("Bottom Right", self)
        
        origin_group = QGroupBox("Origin Position", self)
        origin_layout = QVBoxLayout()
        origin_layout.addWidget(self.top_left_radio)
        origin_layout.addWidget(self.top_center_radio)
        origin_layout.addWidget(self.top_right_radio)
        origin_layout.addWidget(self.center_left_radio)
        origin_layout.addWidget(self.center_radio)
        origin_layout.addWidget(self.center_right_radio)
        origin_layout.addWidget(self.bottom_left_radio)
        origin_layout.addWidget(self.bottom_center_radio)
        origin_layout.addWidget(self.bottom_right_radio)
        origin_group.setLayout(origin_layout)
        layout.addWidget(origin_group)
        
        # Buttons
        button_box = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        button_box.accepted.connect(self.accept)
        button_box.rejected.connect(self.reject)
        layout.addWidget(button_box)
        
        # Connect radio buttons
        self.top_left_radio.toggled.connect(lambda: self._set_origin("top-left") if self.top_left_radio.isChecked() else None)
        self.top_center_radio.toggled.connect(lambda: self._set_origin("top-center") if self.top_center_radio.isChecked() else None)
        self.top_right_radio.toggled.connect(lambda: self._set_origin("top-right") if self.top_right_radio.isChecked() else None)
        self.center_left_radio.toggled.connect(lambda: self._set_origin("center-left") if self.center_left_radio.isChecked() else None)
        self.center_radio.toggled.connect(lambda: self._set_origin("center") if self.center_radio.isChecked() else None)
        self.center_right_radio.toggled.connect(lambda: self._set_origin("center-right") if self.center_right_radio.isChecked() else None)
        self.bottom_left_radio.toggled.connect(lambda: self._set_origin("bottom-left") if self.bottom_left_radio.isChecked() else None)
        self.bottom_center_radio.toggled.connect(lambda: self._set_origin("bottom-center") if self.bottom_center_radio.isChecked() else None)
        self.bottom_right_radio.toggled.connect(lambda: self._set_origin("bottom-right") if self.bottom_right_radio.isChecked() else None)
    
    def _set_origin(self, origin):
        """Set the selected origin"""
        self.selected_origin = origin
    
    def get_origin(self):
        """Get the selected origin position"""
        return self.selected_origin

