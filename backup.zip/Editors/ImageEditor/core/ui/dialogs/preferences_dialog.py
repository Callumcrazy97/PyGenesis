"""
Preferences Dialog for Image Editor
Extracted from dialogs.py
"""

from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QLabel, QPushButton, QTabWidget, QWidget, QHBoxLayout,
    QComboBox, QColorDialog, QFormLayout, QDialogButtonBox, QListWidget, QListWidgetItem, 
    QCheckBox, QInputDialog, QGroupBox, QSlider, QSizePolicy, QMessageBox
)
from PySide6.QtGui import QColor
from PySide6.QtCore import Qt
from core.settings import settings
from core.themes import THEMES
import json
import os
import collections
from .preview_widgets import LeftPanelPreviewWidget, RightPanelPreviewWidget

CUSTOM_PRESET_FILE = os.path.expanduser("~/.pixel_editor_custom_theme.json")
LEFT_PANEL_PRESETS_FILE = os.path.expanduser("~/.pixel_editor_left_panel_presets.json")


class PreferencesDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.main_window = parent  # Save reference to main window
        self.setWindowTitle("Preferences")
        self.resize(600, 400)
        self._original_theme = settings.theme
        self._custom_colors = dict(settings.custom_colors) if hasattr(settings, 'custom_colors') else {}
        self._original_use_gpu_canvas = getattr(settings, 'use_gpu_canvas', False)
        self._load_custom_preset()
        layout = QVBoxLayout(self)
        self.tabs = QTabWidget(self)
        # General tab
        self.general_tab = QWidget()
        self._setup_general_tab()
        self.tabs.addTab(self.general_tab, "General")
        # Add Left Panel tab
        self.left_panel_tab = QWidget()
        left_panel_layout = QVBoxLayout(self.left_panel_tab)
        # Preview
        self.left_panel_preview = LeftPanelPreviewWidget(self.left_panel_tab)
        left_panel_layout.addWidget(self.left_panel_preview)
        # Section list
        self.section_list = QListWidget(self.left_panel_tab)
        # Example sections (to be replaced with dynamic loading)
        for section in ["Current Tool", "Brushes", "Tools", "Shapes", "Selections", "Colour", "Grid", "Zoom"]:
            item = QListWidgetItem(section)
            item.setFlags(item.flags() | Qt.ItemIsUserCheckable | Qt.ItemIsEnabled | Qt.ItemIsSelectable)
            item.setCheckState(Qt.Checked)
            self.section_list.addItem(item)
        left_panel_layout.addWidget(QLabel("Sections (toggle and reorder):", self.left_panel_tab))
        left_panel_layout.addWidget(self.section_list)
        # Up/Down buttons
        btn_row = QHBoxLayout()
        self.up_btn = QPushButton("Up", self.left_panel_tab)
        self.down_btn = QPushButton("Down", self.left_panel_tab)
        btn_row.addWidget(self.up_btn)
        btn_row.addWidget(self.down_btn)
        left_panel_layout.addLayout(btn_row)
        # Preset controls
        preset_row = QHBoxLayout()
        self.preset_combo = QComboBox(self.left_panel_tab)
        self.save_preset_btn = QPushButton("Save as Preset", self.left_panel_tab)
        self.load_preset_btn = QPushButton("Load Preset", self.left_panel_tab)
        self.delete_preset_btn = QPushButton("Delete Preset", self.left_panel_tab)
        preset_row.addWidget(QLabel("Preset:", self.left_panel_tab))
        preset_row.addWidget(self.preset_combo)
        preset_row.addWidget(self.save_preset_btn)
        preset_row.addWidget(self.load_preset_btn)
        preset_row.addWidget(self.delete_preset_btn)
        left_panel_layout.addLayout(preset_row)
        self.tabs.addTab(self.left_panel_tab, "Left Panel")
        # Add Right Panel tab
        self.right_panel_tab = QWidget()
        right_panel_layout = QVBoxLayout(self.right_panel_tab)
        # Preview
        self.right_panel_preview = RightPanelPreviewWidget(self.right_panel_tab)
        right_panel_layout.addWidget(self.right_panel_preview)
        # Section list
        self.right_section_list = QListWidget(self.right_panel_tab)
        for section in ["Preview", "Frames", "Layers", "Properties", "Animation"]:
            item = QListWidgetItem(section)
            item.setFlags(item.flags() | Qt.ItemIsUserCheckable | Qt.ItemIsEnabled | Qt.ItemIsSelectable)
            item.setCheckState(Qt.Checked)
            self.right_section_list.addItem(item)
        right_panel_layout.addWidget(QLabel("Sections (toggle and reorder):", self.right_panel_tab))
        right_panel_layout.addWidget(self.right_section_list)
        # Up/Down buttons
        right_btn_row = QHBoxLayout()
        self.right_up_btn = QPushButton("Up", self.right_panel_tab)
        self.right_down_btn = QPushButton("Down", self.right_panel_tab)
        right_btn_row.addWidget(self.right_up_btn)
        right_btn_row.addWidget(self.right_down_btn)
        right_panel_layout.addLayout(right_btn_row)
        # Icon/tool list for selected section
        self.right_icon_list = QListWidget(self.right_panel_tab)
        right_panel_layout.addWidget(QLabel("Icons/Tools in Section:", self.right_panel_tab))
        right_panel_layout.addWidget(self.right_icon_list)
        self.right_icon_up_btn = QPushButton("Icon Up", self.right_panel_tab)
        self.right_icon_down_btn = QPushButton("Icon Down", self.right_panel_tab)
        right_icon_btn_row = QHBoxLayout()
        right_icon_btn_row.addWidget(self.right_icon_up_btn)
        right_icon_btn_row.addWidget(self.right_icon_down_btn)
        right_panel_layout.addLayout(right_icon_btn_row)
        # Preset controls
        right_preset_row = QHBoxLayout()
        self.right_preset_combo = QComboBox(self.right_panel_tab)
        self.right_save_preset_btn = QPushButton("Save as Preset", self.right_panel_tab)
        self.right_load_preset_btn = QPushButton("Load Preset", self.right_panel_tab)
        self.right_delete_preset_btn = QPushButton("Delete Preset", self.right_panel_tab)
        right_preset_row.addWidget(QLabel("Preset:", self.right_panel_tab))
        right_preset_row.addWidget(self.right_preset_combo)
        right_preset_row.addWidget(self.right_save_preset_btn)
        right_preset_row.addWidget(self.right_load_preset_btn)
        right_preset_row.addWidget(self.right_delete_preset_btn)
        right_panel_layout.addLayout(right_preset_row)
        self.tabs.addTab(self.right_panel_tab, "Right Panel")
        # Editor tab (Image Editor specific settings)
        self.editor_tab = QWidget()
        self._setup_editor_tab()
        self.tabs.addTab(self.editor_tab, "Editor")
        layout.addWidget(self.tabs)
        self.setLayout(layout)
        # OK/Cancel buttons
        self.button_box = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        self.button_box.accepted.connect(self.accept)
        self.button_box.rejected.connect(self.reject)
        layout.addWidget(self.button_box)
        self.section_list.itemChanged.connect(self._update_left_panel_preview_and_apply)
        self.up_btn.clicked.connect(self._move_section_up_and_apply)
        self.down_btn.clicked.connect(self._move_section_down_and_apply)
        self._update_left_panel_preview_and_apply()
        self._update_preset_combo()
        self.save_preset_btn.clicked.connect(self._on_save_preset)
        self.load_preset_btn.clicked.connect(self._on_load_preset)
        self.delete_preset_btn.clicked.connect(self._on_delete_preset)
        # After section_list is created:
        self.section_list.currentRowChanged.connect(self._update_icon_list)
        self.icon_list = QListWidget(self.left_panel_tab)
        self.icon_up_btn = QPushButton("Icon Up", self.left_panel_tab)
        self.icon_down_btn = QPushButton("Icon Down", self.left_panel_tab)
        self.icon_up_btn.clicked.connect(self._move_icon_up)
        self.icon_down_btn.clicked.connect(self._move_icon_down)
        icon_btn_row = QHBoxLayout()
        icon_btn_row.addWidget(self.icon_up_btn)
        icon_btn_row.addWidget(self.icon_down_btn)
        left_panel_layout = self.left_panel_tab.layout()
        left_panel_layout.addWidget(QLabel("Icons/Tools in Section:", self.left_panel_tab))
        left_panel_layout.addWidget(self.icon_list)
        left_panel_layout.addLayout(icon_btn_row)
        self.icon_list.itemChanged.connect(self._update_left_panel_preview_and_apply)
        self._update_icon_list()

    def _load_custom_preset(self):
        self._custom_preset = None
        if os.path.exists(CUSTOM_PRESET_FILE):
            try:
                with open(CUSTOM_PRESET_FILE, "r") as f:
                    self._custom_preset = json.load(f)
                THEMES["Custom"] = self._custom_preset
            except Exception:
                pass

    def _save_custom_preset(self):
        # Save current custom colors as a custom preset
        preset = {}
        theme_roles = list(THEMES[self.theme_combo.currentText()].keys())
        for role in theme_roles:
            preset[role] = self._custom_colors.get(role, THEMES[self.theme_combo.currentText()][role])
        with open(CUSTOM_PRESET_FILE, "w") as f:
            json.dump(preset, f, indent=2)
        THEMES["Custom"] = preset
        if "Custom" not in [self.theme_combo.itemText(i) for i in range(self.theme_combo.count())]:
            self.theme_combo.addItem("Custom")
        self.theme_combo.setCurrentText("Custom")

    def _load_left_panel_presets(self):
        if os.path.exists(LEFT_PANEL_PRESETS_FILE):
            with open(LEFT_PANEL_PRESETS_FILE, 'r') as f:
                return json.load(f)
        return {}

    def _save_left_panel_presets(self, presets):
        with open(LEFT_PANEL_PRESETS_FILE, 'w') as f:
            json.dump(presets, f, indent=2)

    def _update_preset_combo(self):
        self.preset_combo.blockSignals(True)
        self.preset_combo.clear()
        self.left_panel_presets = self._load_left_panel_presets()
        for name in self.left_panel_presets:
            self.preset_combo.addItem(name)
        self.preset_combo.blockSignals(False)

    def _get_current_section_preset(self):
        # Return a list of checked section names in order
        return [self.section_list.item(i).text() for i in range(self.section_list.count()) if self.section_list.item(i).checkState() == Qt.Checked]

    def _apply_section_preset(self, preset):
        # preset: list of section names (checked, in order)
        # Uncheck all, then check and order as in preset
        all_sections = [self.section_list.item(i).text() for i in range(self.section_list.count())]
        # Remove all items
        self.section_list.clear()
        # Add preset sections (checked)
        for section in preset:
            item = QListWidgetItem(section)
            item.setFlags(item.flags() | Qt.ItemIsUserCheckable | Qt.ItemIsEnabled | Qt.ItemIsSelectable)
            item.setCheckState(Qt.Checked)
            self.section_list.addItem(item)
        # Add any missing sections (unchecked)
        for section in all_sections:
            if section not in preset:
                item = QListWidgetItem(section)
                item.setFlags(item.flags() | Qt.ItemIsUserCheckable | Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                item.setCheckState(Qt.Unchecked)
                self.section_list.addItem(item)
        self._update_left_panel_preview_and_apply()

    def _get_current_left_panel_preset(self):
        # Returns a dict: section name -> list of (icon, checked) tuples
        preset = collections.OrderedDict()
        for i in range(self.section_list.count()):
            section_item = self.section_list.item(i)
            section = section_item.text()
            if section_item.checkState() == Qt.Checked:
                # Get icon list for this section
                if self.section_list.currentRow() == i:
                    icons = []
                    for j in range(self.icon_list.count()):
                        icon_item = self.icon_list.item(j)
                        icons.append((icon_item.text(), icon_item.checkState() == Qt.Checked))
                    preset[section] = icons
                else:
                    # Default: all icons checked (for non-selected sections)
                    section_icons = {
                        "Brushes": ["🖌️ Brush", "✏️ Pencil", "🖍️ Marker", "✒️ Calligraphy", "💨 Airbrush", "📏 Line"],
                        "Tools": ["🧽 Eraser", "🪣 Fill", "🧲 Eyedropper", "🖍️ Gradient", "🖍️ Dither"],
                        "Shapes": ["▭ Rect", "◯ Ellipse", "🔺 Polygon", "⭐ Star"],
                        "Selections": ["⬚ Rect Select", "🪢 Lasso Select", "🪄 Magic Wand"],
                        "Colour": ["Left Colour", "Right Colour"],
                        "Zoom": ["Zoom In", "Zoom Out", "Reset Zoom"],
                        "Grid": ["Grid Toggle", "Global Grid", "Grid Size", "Grid Colour", "Snap to Grid"],
                        "Current Tool": ["Tool Name", "Brush Preview", "Radius", "Opacity"],
                    }
                    preset[section] = [(icon, True) for icon in section_icons.get(section, [])]
        return preset

    def _apply_left_panel_preset(self, preset):
        # preset: dict of section name -> list of (icon, checked)
        self.section_list.blockSignals(True)
        self.section_list.clear()
        for section, icons in preset.items():
            item = QListWidgetItem(section)
            item.setFlags(item.flags() | Qt.ItemIsUserCheckable | Qt.ItemIsEnabled | Qt.ItemIsSelectable)
            item.setCheckState(Qt.Checked)
            self.section_list.addItem(item)
        # Add any missing sections (unchecked)
        section_icons = {
            "Brushes": ["🖌️ Brush", "✏️ Pencil", "🖍️ Marker", "✒️ Calligraphy", "💨 Airbrush", "📏 Line"],
            "Tools": ["🧽 Eraser", "🪣 Fill", "🧲 Eyedropper", "🖍️ Gradient", "🖍️ Dither"],
            "Shapes": ["▭ Rect", "◯ Ellipse", "🔺 Polygon", "⭐ Star"],
            "Selections": ["⬚ Rect Select", "🪢 Lasso Select", "🪄 Magic Wand"],
            "Colour": ["Left Colour", "Right Colour"],
            "Zoom": ["Zoom In", "Zoom Out", "Reset Zoom"],
            "Grid": ["Grid Toggle", "Global Grid", "Grid Size", "Grid Colour", "Snap to Grid"],
            "Current Tool": ["Tool Name", "Brush Preview", "Radius", "Opacity"],
        }
        for section in section_icons:
            if section not in preset:
                item = QListWidgetItem(section)
                item.setFlags(item.flags() | Qt.ItemIsUserCheckable | Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                item.setCheckState(Qt.Unchecked)
                self.section_list.addItem(item)
        self.section_list.blockSignals(False)
        # Set icons for the first section
        self.section_list.setCurrentRow(0)
        self._update_icon_list()
        if preset:
            first_section = next(iter(preset))
            icons = preset[first_section]
            self.icon_list.blockSignals(True)
            self.icon_list.clear()
            for icon, checked in icons:
                item = QListWidgetItem(icon)
                item.setFlags(item.flags() | Qt.ItemIsUserCheckable | Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                item.setCheckState(Qt.Checked if checked else Qt.Unchecked)
                self.icon_list.addItem(item)
            self.icon_list.blockSignals(False)
        self._update_left_panel_preview_and_apply()
        # Apply icon layouts for all sections in the preset
        if self.main_window and hasattr(self.main_window, 'left_panel'):
            for section, icons in preset.items():
                self.main_window.left_panel.apply_icon_layout(section, icons)

    def _on_save_preset(self):
        name, ok = QInputDialog.getText(self, "Save Preset", "Preset name:")
        if ok and name:
            presets = self._load_left_panel_presets()
            presets[name] = self._get_current_left_panel_preset()
            self._save_left_panel_presets(presets)
            self._update_preset_combo()
            self.preset_combo.setCurrentText(name)

    def _on_load_preset(self):
        name = self.preset_combo.currentText()
        if name:
            presets = self._load_left_panel_presets()
            if name in presets:
                self._apply_left_panel_preset(presets[name])

    def _on_delete_preset(self):
        name = self.preset_combo.currentText()
        if name:
            presets = self._load_left_panel_presets()
            if name in presets:
                del presets[name]
                self._save_left_panel_presets(presets)
                self._update_preset_combo()

    def _init_ui(self):
        layout = QVBoxLayout(self)
        self.tabs = QTabWidget(self)
        # General tab
        self.general_tab = QWidget()
        self._setup_general_tab()
        self.tabs.addTab(self.general_tab, "General")
        # Left Panel tab
        self.left_panel_tab = QWidget()
        self._setup_left_panel_tab()
        self.tabs.addTab(self.left_panel_tab, "Left Panel")
        # Right Panel tab
        self.right_panel_tab = QWidget()
        self._setup_right_panel_tab()
        self.tabs.addTab(self.right_panel_tab, "Right Panel")
        layout.addWidget(self.tabs)
        # OK/Cancel buttons
        self.button_box = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        self.button_box.accepted.connect(self.accept)
        self.button_box.rejected.connect(self.reject)
        layout.addWidget(self.button_box)

    def _setup_left_panel_tab(self):
        """Setup the Left Panel customization tab."""
        layout = QVBoxLayout(self.left_panel_tab)
        
        # Section visibility controls
        section_group = QGroupBox("Panel Sections")
        section_layout = QVBoxLayout(section_group)
        
        # Available sections
        self.section_list = QListWidget()
        available_sections = [
            "Brushes", "Tools", "Shapes", "Selections", 
            "Colour", "Zoom", "Grid", "Current Tool"
        ]
        for section in available_sections:
            item = QListWidgetItem(section)
            item.setFlags(item.flags() | Qt.ItemIsUserCheckable | Qt.ItemIsEnabled | Qt.ItemIsSelectable)
            item.setCheckState(Qt.Checked)  # Default to visible
            self.section_list.addItem(item)
        
        self.section_list.itemChanged.connect(self._update_left_panel_preview_and_apply)
        section_layout.addWidget(self.section_list)
        
        # Section reordering buttons
        reorder_layout = QHBoxLayout()
        up_btn = QPushButton("Move Up")
        up_btn.clicked.connect(self._move_section_up_and_apply)
        down_btn = QPushButton("Move Down")
        down_btn.clicked.connect(self._move_section_down_and_apply)
        reorder_layout.addWidget(up_btn)
        reorder_layout.addWidget(down_btn)
        section_layout.addLayout(reorder_layout)
        
        layout.addWidget(section_group)
        
        # Preview
        preview_group = QGroupBox("Preview")
        preview_layout = QVBoxLayout(preview_group)
        self.left_panel_preview = LeftPanelPreviewWidget()
        preview_layout.addWidget(self.left_panel_preview)
        layout.addWidget(preview_group)
        
        # Preset management
        preset_group = QGroupBox("Presets")
        preset_layout = QHBoxLayout(preset_group)
        
        self.preset_combo = QComboBox()
        self._update_preset_combo()
        preset_layout.addWidget(self.preset_combo)
        
        save_btn = QPushButton("Save Preset")
        save_btn.clicked.connect(self._on_save_preset)
        preset_layout.addWidget(save_btn)
        
        load_btn = QPushButton("Load Preset")
        load_btn.clicked.connect(self._on_load_preset)
        preset_layout.addWidget(load_btn)
        
        delete_btn = QPushButton("Delete Preset")
        delete_btn.clicked.connect(self._on_delete_preset)
        preset_layout.addWidget(delete_btn)
        
        layout.addWidget(preset_group)

    def _setup_right_panel_tab(self):
        """Setup the Right Panel customization tab."""
        layout = QVBoxLayout(self.right_panel_tab)
        
        # Layer panel settings
        layer_group = QGroupBox("Layer Panel")
        layer_layout = QVBoxLayout(layer_group)
        
        # Layer display options
        self.show_layer_thumbnails = QCheckBox("Show Layer Thumbnails")
        self.show_layer_thumbnails.setChecked(True)
        layer_layout.addWidget(self.show_layer_thumbnails)
        
        self.show_layer_opacity = QCheckBox("Show Layer Opacity Controls")
        self.show_layer_opacity.setChecked(True)
        layer_layout.addWidget(self.show_layer_opacity)
        
        self.show_layer_blend_mode = QCheckBox("Show Layer Blend Mode")
        self.show_layer_blend_mode.setChecked(False)
        layer_layout.addWidget(self.show_layer_blend_mode)
        
        layout.addWidget(layer_group)
        
        # Animation panel settings
        anim_group = QGroupBox("Animation Panel")
        anim_layout = QVBoxLayout(anim_group)
        
        self.show_frame_thumbnails = QCheckBox("Show Frame Thumbnails")
        self.show_frame_thumbnails.setChecked(True)
        anim_layout.addWidget(self.show_frame_thumbnails)
        
        self.show_animation_controls = QCheckBox("Show Animation Controls")
        self.show_animation_controls.setChecked(True)
        anim_layout.addWidget(self.show_animation_controls)
        
        self.show_onion_skin = QCheckBox("Show Onion Skin Controls")
        self.show_onion_skin.setChecked(True)
        anim_layout.addWidget(self.show_onion_skin)
        
        layout.addWidget(anim_group)
        
        # Preview panel settings
        preview_group = QGroupBox("Preview Panel")
        preview_layout = QVBoxLayout(preview_group)
        
        self.show_preview_controls = QCheckBox("Show Preview Controls")
        self.show_preview_controls.setChecked(True)
        preview_layout.addWidget(self.show_preview_controls)
        
        self.preview_size_label = QLabel("Preview Size:")
        preview_layout.addWidget(self.preview_size_label)
        
        self.preview_size_slider = QSlider(Qt.Horizontal)
        self.preview_size_slider.setMinimum(100)
        self.preview_size_slider.setMaximum(300)
        self.preview_size_slider.setValue(160)
        preview_layout.addWidget(self.preview_size_slider)
        
        layout.addWidget(preview_group)
        
        # Apply settings button
        apply_btn = QPushButton("Apply Settings")
        apply_btn.clicked.connect(self._apply_right_panel_settings)
        layout.addWidget(apply_btn)
        
        layout.addStretch()

    def _apply_right_panel_settings(self):
        """Apply the right panel settings to the actual panel."""
        if self.main_window and hasattr(self.main_window, 'right_panel'):
            # Apply layer panel settings
            if hasattr(self.main_window.right_panel, 'show_layer_thumbnails'):
                self.main_window.right_panel.show_layer_thumbnails = self.show_layer_thumbnails.isChecked()
            
            # Apply animation panel settings
            if hasattr(self.main_window.right_panel, 'show_animation_controls'):
                self.main_window.right_panel.show_animation_controls = self.show_animation_controls.isChecked()
            
            # Apply preview panel settings
            if hasattr(self.main_window.right_panel, 'preview_size'):
                self.main_window.right_panel.preview_size = self.preview_size_slider.value()
            
            # Refresh the right panel
            self.main_window.right_panel.update()

    def _setup_general_tab(self):
        layout = QFormLayout()
        # Theme preset dropdown
        self.theme_combo = QComboBox(self)
        self.theme_combo.addItems(THEMES.keys())
        self.theme_combo.setCurrentText(settings.theme)
        self.theme_combo.currentTextChanged.connect(self._on_theme_changed)
        layout.addRow("Colour Theme:", self.theme_combo)
        # Custom color pickers for theme roles
        self.color_buttons = {}
        # Only show editable roles
        editable_roles = [
            'background', 'panel', 'border', 'accent', 'text',
            'canvas_border', 'canvas_bg1', 'canvas_bg2'
        ]
        theme_roles = [role for role in THEMES[settings.theme].keys() if role in editable_roles]
        for role in theme_roles:
            btn = QPushButton(self)
            btn.setText(role.replace('_', ' ').title())
            btn.clicked.connect(lambda _, r=role: self._pick_color(r))
            self.color_buttons[role] = btn
            layout.addRow(f"{role.replace('_', ' ').title()}:", btn)
        # Selection Outline color
        sel_btn = QPushButton(self)
        sel_btn.setText("Selection Outline")
        sel_btn.clicked.connect(lambda: self._pick_color('selection_outline'))
        self.color_buttons['selection_outline'] = sel_btn
        layout.addRow("Selection Outline:", sel_btn)
        # Save as custom preset button
        save_btn = QPushButton("Save as Custom Preset", self)
        save_btn.clicked.connect(self._save_custom_preset)
        layout.addRow(save_btn)
        self.general_tab.setLayout(layout)
        self._update_color_buttons()
    
    def _setup_editor_tab(self):
        """Setup the Editor tab with Image Editor specific settings"""
        layout = QFormLayout()
        
        # Editor Specific - Image section
        editor_group = QGroupBox("Editor Specific - Image")
        editor_layout = QFormLayout(editor_group)
        
        # Hardware Rendering checkbox
        self.use_gpu_canvas_checkbox = QCheckBox(self)
        self.use_gpu_canvas_checkbox.setChecked(getattr(settings, 'use_gpu_canvas', False))
        self.use_gpu_canvas_checkbox.setToolTip(
            "Use GPU-accelerated rendering for better performance.\n"
            "If disabled, uses software rendering (QPainter-based canvas).\n"
            "Note: Changes take effect after restarting the Image Editor."
        )
        editor_layout.addRow("Use Hardware Rendering:", self.use_gpu_canvas_checkbox)
        
        editor_group.setLayout(editor_layout)
        layout.addRow(editor_group)
        
        # Add some spacing
        spacer = QWidget()
        spacer.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        layout.addRow(spacer)
        
        self.editor_tab.setLayout(layout)
    
    def _on_theme_changed(self, theme_name):
        if theme_name == "Custom" and self._custom_preset:
            self._custom_colors = dict(self._custom_preset)
        elif theme_name != "Custom":
            self._custom_colors = {}
        self._update_color_buttons(theme_name)

    def _update_color_buttons(self, theme_name=None):
        theme_name = theme_name or self.theme_combo.currentText()
        theme = THEMES[theme_name]
        for role, btn in self.color_buttons.items():
            if role == 'selection_outline':
                color = self._custom_colors.get(role, theme.get('accent', '#61afef'))
            else:
                color = self._custom_colors.get(role, theme[role])
            btn.setStyleSheet(f"background: {color}; color: #222; border: 1px solid #888;")

    def _pick_color(self, role):
        if role == 'selection_outline':
            current = self._custom_colors.get('selection_outline', THEMES[self.theme_combo.currentText()].get('accent', '#61afef'))
        else:
            current = self._custom_colors.get(role, THEMES[self.theme_combo.currentText()][role])
        color = QColorDialog.getColor(QColor(current), self, f"Pick color for {role}")
        if color.isValid():
            self._custom_colors[role] = color.name()
            self._update_color_buttons()

    def _update_left_panel_preview_and_apply(self):
        # Get visible sections in order
        sections = []
        for i in range(self.section_list.count()):
            item = self.section_list.item(i)
            if item.checkState() == Qt.Checked:
                sections.append(item.text())
        self.left_panel_preview.update_preview(sections)
        # Apply to actual Left Panel
        if self.main_window and hasattr(self.main_window, 'left_panel'):
            self.main_window.left_panel.apply_section_layout(sections)
            # Also apply icon layouts for all visible sections
            current_item = self.section_list.currentItem()
            current_section = current_item.text() if current_item else None
            for section in sections:
                if section == current_section:
                    # Use current icon_list for the selected section
                    icon_layout = [(self.icon_list.item(i).text(), self.icon_list.item(i).checkState() == Qt.Checked) for i in range(self.icon_list.count())]
                else:
                    # Default: all checked for other sections
                    section_icons = {
                        "Brushes": ["🖌️ Brush", "✏️ Pencil", "🖍️ Marker", "✒️ Calligraphy", "💨 Airbrush", "📏 Line"],
                        "Tools": ["🧽 Eraser", "🪣 Fill", "🧲 Eyedropper", "🖍️ Gradient", "🖍️ Dither"],
                        "Shapes": ["▭ Rect", "◯ Ellipse", "🔺 Polygon", "⭐ Star"],
                        "Selections": ["⬚ Rect Select", "🪢 Lasso Select", "🪄 Magic Wand"],
                        "Colour": ["Left Colour", "Right Colour"],
                        "Zoom": ["Zoom In", "Zoom Out", "Reset Zoom"],
                        "Grid": ["Grid Toggle", "Global Grid", "Grid Size", "Grid Colour", "Snap to Grid"],
                        "Current Tool": ["Tool Name", "Brush Preview", "Radius", "Opacity"],
                    }
                    icon_layout = [(icon, True) for icon in section_icons.get(section, [])]
                self.main_window.left_panel.apply_icon_layout(section, icon_layout)

    def _move_section_up_and_apply(self):
        row = self.section_list.currentRow()
        if row > 0:
            item = self.section_list.takeItem(row)
            self.section_list.insertItem(row - 1, item)
            self.section_list.setCurrentRow(row - 1)
            self._update_left_panel_preview_and_apply()

    def _move_section_down_and_apply(self):
        row = self.section_list.currentRow()
        if row < self.section_list.count() - 1 and row != -1:
            item = self.section_list.takeItem(row)
            self.section_list.insertItem(row + 1, item)
            self.section_list.setCurrentRow(row + 1)
            self._update_left_panel_preview_and_apply()

    def _update_icon_list(self):
        # Show icons/tools for the selected section
        section = None
        row = self.section_list.currentRow()
        if row != -1:
            section = self.section_list.item(row).text()
        self.icon_list.blockSignals(True)
        self.icon_list.clear()
        # Example icons for each section (replace with dynamic loading later)
        section_icons = {
            "Brushes": ["🖌️ Brush", "✏️ Pencil", "🖍️ Marker", "✒️ Calligraphy", "💨 Airbrush", "📏 Line"],
            "Tools": ["🧽 Eraser", "🪣 Fill", "🧲 Eyedropper", "🖍️ Gradient", "🖍️ Dither"],
            "Shapes": ["▭ Rect", "◯ Ellipse", "🔺 Polygon", "⭐ Star"],
            "Selections": ["⬚ Rect Select", "🪢 Lasso Select", "🪄 Magic Wand"],
            "Colour": ["Left Colour", "Right Colour"],
            "Zoom": ["Zoom In", "Zoom Out", "Reset Zoom"],
            "Grid": ["Grid Toggle", "Global Grid", "Grid Size", "Grid Colour", "Snap to Grid"],
            "Current Tool": ["Tool Name", "Brush Preview", "Radius", "Opacity"],
        }
        icons = section_icons.get(section, [])
        for icon in icons:
            item = QListWidgetItem(icon)
            item.setFlags(item.flags() | Qt.ItemIsUserCheckable | Qt.ItemIsEnabled | Qt.ItemIsSelectable)
            item.setCheckState(Qt.Checked)
            self.icon_list.addItem(item)
        self.icon_list.blockSignals(False)
        # Apply icon layout to Left Panel
        self._apply_icon_layout_to_left_panel(section)

    def _apply_icon_layout_to_left_panel(self, section):
        if not section or not self.main_window or not hasattr(self.main_window, 'left_panel'):
            return
        icon_layout = [(self.icon_list.item(i).text(), self.icon_list.item(i).checkState() == Qt.Checked) for i in range(self.icon_list.count())]
        self.main_window.left_panel.apply_icon_layout(section, icon_layout)

    def _move_icon_up(self):
        row = self.icon_list.currentRow()
        if row > 0:
            item = self.icon_list.takeItem(row)
            self.icon_list.insertItem(row - 1, item)
            self.icon_list.setCurrentRow(row - 1)
            section = self.section_list.currentItem().text() if self.section_list.currentItem() else None
            self._apply_icon_layout_to_left_panel(section)

    def _move_icon_down(self):
        row = self.icon_list.currentRow()
        if row < self.icon_list.count() - 1 and row != -1:
            item = self.icon_list.takeItem(row)
            self.icon_list.insertItem(row + 1, item)
            self.icon_list.setCurrentRow(row + 1)
            section = self.section_list.currentItem().text() if self.section_list.currentItem() else None
            self._apply_icon_layout_to_left_panel(section)

    def accept(self):
        settings.theme = self.theme_combo.currentText()
        settings.custom_colors = self._custom_colors
        # Save GPU canvas setting
        settings.use_gpu_canvas = self.use_gpu_canvas_checkbox.isChecked()
        settings.save()
        
        # Notify user if GPU canvas setting changed and requires restart
        if hasattr(self, '_original_use_gpu_canvas'):
            if self._original_use_gpu_canvas != settings.use_gpu_canvas:
                QMessageBox.information(
                    self,
                    "Setting Changed",
                    "Hardware rendering setting changed.\n"
                    "Please restart the Image Editor for changes to take effect."
                )
        
        super().accept()

    def reject(self):
        super().reject()

