"""
Merge/Replace Dialog for Image Editor
Extracted from dialogs.py
"""

from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QLabel, QRadioButton, QButtonGroup, QDialogButtonBox
)


class MergeReplaceDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Apply Effect to Multiple Frames")
        self.setMinimumWidth(340)
        layout = QVBoxLayout(self)
        label = QLabel("How should the effect be applied to affected frames?", self)
        layout.addWidget(label)
        self.button_group = QButtonGroup(self)
        self.radio_merge = QRadioButton("Merge (blend with existing content)", self)
        self.radio_replace = QRadioButton("Replace (overwrite affected area only)", self)
        self.radio_entire = QRadioButton("Replace Entire Image (overwrite whole frame)", self)
        self.button_group.addButton(self.radio_merge, 0)
        self.button_group.addButton(self.radio_replace, 1)
        self.button_group.addButton(self.radio_entire, 2)
        self.radio_merge.setChecked(True)
        layout.addWidget(self.radio_merge)
        layout.addWidget(self.radio_replace)
        layout.addWidget(self.radio_entire)
        btn_box = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel, self)
        btn_box.accepted.connect(self.accept)
        btn_box.rejected.connect(self.reject)
        layout.addWidget(btn_box)
    
    def get_mode(self):
        if self.radio_merge.isChecked():
            return 'merge'
        elif self.radio_replace.isChecked():
            return 'replace'
        elif self.radio_entire.isChecked():
            return 'entire'
        return 'merge'


