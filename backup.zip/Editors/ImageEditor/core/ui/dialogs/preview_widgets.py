"""
Preview Widgets for Image Editor
Extracted from dialogs.py
"""

from PySide6.QtWidgets import QWidget, QVBoxLayout, QLabel
from PySide6.QtGui import QPainter, QColor, QPixmap
from PySide6.QtCore import Qt


class LeftPanelPreviewWidget(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.layout = QVBoxLayout(self)
        self.section_labels = []
        self.setLayout(self.layout)

    def update_preview(self, sections):
        # Clear old labels
        for label in self.section_labels:
            self.layout.removeWidget(label)
            label.deleteLater()
        self.section_labels = []
        # Add new labels for each section
        for section in sections:
            label = QLabel(section, self)
            label.setStyleSheet("background: #444; color: #fff; padding: 4px; border-radius: 4px; margin: 2px;")
            self.layout.addWidget(label)
            self.section_labels.append(label)


class RightPanelPreviewWidget(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        layout = QVBoxLayout(self)
        label = QLabel("[Right Panel Preview Here]", self)
        layout.addWidget(label)
        self.setLayout(layout)


class CheckerboardPreviewWidget(QLabel):
    """Preview widget with checkerboard background like the main canvas."""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumSize(200, 150)
        self.setAlignment(Qt.AlignCenter)
        self.setText("Preview will appear here")
        self.setStyleSheet("border: 1px solid #888;")
        self.preview_pixmap = None
        
    def setPixmap(self, pixmap):
        """Override setPixmap to store the pixmap and trigger repaint."""
        self.preview_pixmap = pixmap
        self.update()  # Trigger repaint
        
    def paintEvent(self, event):
        """Override paint event to draw checkerboard background and preview image."""
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        
        # Get widget size
        width = self.width()
        height = self.height()
        
        # Draw checkerboard pattern
        checker_size = 8
        color1 = QColor(40, 40, 40)  # Dark gray
        color2 = QColor(60, 60, 60)  # Light gray
        
        for y in range(0, height, checker_size):
            for x in range(0, width, checker_size):
                # Alternate colors for checkerboard pattern
                if (x // checker_size + y // checker_size) % 2 == 0:
                    painter.fillRect(x, y, checker_size, checker_size, color1)
                else:
                    painter.fillRect(x, y, checker_size, checker_size, color2)
        
        # Draw the preview image if available
        if self.preview_pixmap is not None:
            # Calculate position to center the image
            pixmap_rect = self.preview_pixmap.rect()
            widget_rect = self.rect()
            
            # Scale to fit while maintaining aspect ratio
            scaled_pixmap = self.preview_pixmap.scaled(
                widget_rect.size(), 
                Qt.KeepAspectRatio, 
                Qt.SmoothTransformation
            )
            
            # Center the scaled pixmap
            x = (widget_rect.width() - scaled_pixmap.width()) // 2
            y = (widget_rect.height() - scaled_pixmap.height()) // 2
            
            painter.drawPixmap(x, y, scaled_pixmap)
        else:
            # Draw text if no pixmap
            painter.setPen(QColor(200, 200, 200))
            painter.drawText(self.rect(), Qt.AlignCenter, self.text())


