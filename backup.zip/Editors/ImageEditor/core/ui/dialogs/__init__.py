"""
Dialog modules for Image Editor
Split from dialogs.py for better modularity
"""

# Re-export all dialogs for backward compatibility
from ui.dialogs.preview_widgets import (
    LeftPanelPreviewWidget,
    RightPanelPreviewWidget,
    CheckerboardPreviewWidget
)
from ui.dialogs.preferences_dialog import PreferencesDialog
from ui.dialogs.new_image_dialog import NewImageDialog
from ui.dialogs.merge_replace_dialog import MergeReplaceDialog
from ui.dialogs.parameter_widgets import (
    ParameterWidget,
    SliderWidget,
    DoubleSliderWidget,
    ColorPickerWidget,
    DropdownWidget,
    CheckboxWidget,
    TextBoxWidget,
    ColorListWidget
)
from ui.dialogs.effect_dialog import UnifiedEffectDialog, EFFECT_REGISTRY
from ui.dialogs.origin_dialog import OriginSelectionDialog

__all__ = [
    'LeftPanelPreviewWidget',
    'RightPanelPreviewWidget',
    'CheckerboardPreviewWidget',
    'PreferencesDialog',
    'NewImageDialog',
    'MergeReplaceDialog',
    'ParameterWidget',
    'SliderWidget',
    'DoubleSliderWidget',
    'ColorPickerWidget',
    'DropdownWidget',
    'CheckboxWidget',
    'TextBoxWidget',
    'ColorListWidget',
    'UnifiedEffectDialog',
    'EFFECT_REGISTRY',
    'OriginSelectionDialog'
]


