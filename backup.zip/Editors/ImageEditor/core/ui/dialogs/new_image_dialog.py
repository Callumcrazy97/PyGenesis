"""
New Image Dialog for Image Editor
Extracted from dialogs.py
"""

from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit, QPushButton,
    QDialogButtonBox, QGridLayout, QGroupBox
)
from PySide6.QtCore import Qt


class NewImageDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("New Image")
        self.setMinimumWidth(300)
        layout = QVBoxLayout(self)
        
        # Size inputs
        size_group = QGroupBox("Size")
        size_layout = QGridLayout(size_group)
        
        size_layout.addWidget(QLabel("Width:"), 0, 0)
        self.width_input = QLineEdit("256")
        size_layout.addWidget(self.width_input, 0, 1)
        
        width_buttons = QHBoxLayout()
        width_decrease = QPushButton("-")
        width_decrease.clicked.connect(self.decrease_width)
        width_increase = QPushButton("+")
        width_increase.clicked.connect(self.increase_width)
        width_buttons.addWidget(width_decrease)
        width_buttons.addWidget(width_increase)
        size_layout.addLayout(width_buttons, 0, 2)
        
        size_layout.addWidget(QLabel("Height:"), 1, 0)
        self.height_input = QLineEdit("256")
        size_layout.addWidget(self.height_input, 1, 1)
        
        height_buttons = QHBoxLayout()
        height_decrease = QPushButton("-")
        height_decrease.clicked.connect(self.decrease_height)
        height_increase = QPushButton("+")
        height_increase.clicked.connect(self.increase_height)
        height_buttons.addWidget(height_decrease)
        height_buttons.addWidget(height_increase)
        size_layout.addLayout(height_buttons, 1, 2)
        
        layout.addWidget(size_group)
        
        # Preset sizes
        preset_group = QGroupBox("Presets")
        preset_layout = QGridLayout(preset_group)
        
        presets = [
            ("16x16", 16, 16),
            ("32x32", 32, 32),
            ("64x64", 64, 64),
            ("128x128", 128, 128),
            ("256x256", 256, 256),
            ("512x512", 512, 512),
            ("1024x1024", 1024, 1024)
        ]
        
        for i, (label, width, height) in enumerate(presets):
            btn = QPushButton(label)
            btn.clicked.connect(lambda checked, w=width, h=height: self.set_preset_size(w, h))
            preset_layout.addWidget(btn, i // 3, i % 3)
        
        layout.addWidget(preset_group)
        
        # Buttons
        btn_box = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel, self)
        btn_box.accepted.connect(self.accept)
        btn_box.rejected.connect(self.reject)
        layout.addWidget(btn_box)
    
    def get_size(self):
        """Get the size from the dialog"""
        try:
            width = int(self.width_input.text())
            height = int(self.height_input.text())
            return width, height
        except ValueError:
            return 256, 256
    
    def increase_width(self):
        try:
            current = int(self.width_input.text())
            if current < 1024:
                self.width_input.setText(str(current + 1))
        except ValueError:
            pass
    
    def decrease_width(self):
        try:
            current = int(self.width_input.text())
            if current > 1:
                self.width_input.setText(str(current - 1))
        except ValueError:
            pass
    
    def increase_height(self):
        try:
            current = int(self.height_input.text())
            if current < 1024:
                self.height_input.setText(str(current + 1))
        except ValueError:
            pass
    
    def decrease_height(self):
        try:
            current = int(self.height_input.text())
            if current > 1:
                self.height_input.setText(str(current - 1))
        except ValueError:
            pass
    
    def set_preset_size(self, width, height):
        """Set the canvas size to a preset value."""
        self.width_input.setText(str(width))
        self.height_input.setText(str(height))


