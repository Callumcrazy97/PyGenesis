"""
Parameter Widgets for Effect Dialogs
Extracted from dialogs.py
"""

from PySide6.QtWidgets import (
    QWidget, QHBoxLayout, QVBoxLayout, QLabel, QSlider, QSpinBox, QDoubleSpinBox,
    QPushButton, QComboBox, QCheckBox, QLineEdit, QListWidget, QListWidgetItem,
    QColorDialog
)
from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QColor, QPixmap


class ParameterWidget(QWidget):
    """Base class for parameter widgets"""
    value_changed = Signal(object)
    
    def __init__(self, param_config, parent=None):
        super().__init__(parent)
        self.param_config = param_config
        self.setup_ui()
    
    def setup_ui(self):
        layout = QHBoxLayout()
        layout.setContentsMargins(0, 0, 0, 0)
        
        label = QLabel(self.param_config.get('label', self.param_config['name']))
        layout.addWidget(label)
        
        self.setLayout(layout)
    
    def get_value(self):
        """Get the current value from the widget. Override in subclasses."""
        return getattr(self, '_value', None)
    
    def set_value(self, value):
        """Set the current value in the widget. Override in subclasses."""
        self._value = value


class SliderWidget(ParameterWidget):
    def setup_ui(self):
        layout = QHBoxLayout()
        layout.setContentsMargins(0, 0, 0, 0)
        
        label = QLabel(self.param_config.get('label', self.param_config['name']))
        layout.addWidget(label)
        
        self.slider = QSlider(Qt.Horizontal)
        self.slider.setRange(self.param_config['range'][0], self.param_config['range'][1])
        self.slider.setValue(self.param_config.get('default', self.param_config['range'][0]))
        self.slider.valueChanged.connect(self.value_changed.emit)
        layout.addWidget(self.slider)
        
        self.value_label = QLabel(str(self.slider.value()))
        self.slider.valueChanged.connect(lambda v: self.value_label.setText(str(v)))
        layout.addWidget(self.value_label)
        
        self.setLayout(layout)
    
    def get_value(self):
        return self.slider.value()
    
    def set_value(self, value):
        self.slider.setValue(value)


class DoubleSliderWidget(ParameterWidget):
    def setup_ui(self):
        layout = QHBoxLayout()
        layout.setContentsMargins(0, 0, 0, 0)
        
        label = QLabel(self.param_config.get('label', self.param_config['name']))
        layout.addWidget(label)
        
        self.spinbox = QDoubleSpinBox()
        self.spinbox.setRange(self.param_config['range'][0], self.param_config['range'][1])
        self.spinbox.setValue(self.param_config.get('default', self.param_config['range'][0]))
        self.spinbox.setDecimals(2)
        self.spinbox.setSingleStep(0.01)
        self.spinbox.valueChanged.connect(self.value_changed.emit)
        layout.addWidget(self.spinbox)
        
        self.setLayout(layout)
    
    def get_value(self):
        return self.spinbox.value()
    
    def set_value(self, value):
        self.spinbox.setValue(value)


class ColorPickerWidget(ParameterWidget):
    def setup_ui(self):
        layout = QHBoxLayout()
        layout.setContentsMargins(0, 0, 0, 0)
        
        label = QLabel(self.param_config.get('label', self.param_config['name']))
        layout.addWidget(label)
        
        self.color_button = QPushButton()
        self.color_button.setFixedSize(50, 25)
        self.color_button.clicked.connect(self.pick_color)
        self.set_color(self.param_config.get('default', '#000000'))
        layout.addWidget(self.color_button)
        
        self.setLayout(layout)
    
    def pick_color(self):
        color = QColorDialog.getColor(QColor(self.current_color), self)
        if color.isValid():
            self.set_color(color.name())
            self.value_changed.emit(color.name())
    
    def set_color(self, color):
        self.current_color = color
        self.color_button.setStyleSheet(f"background-color: {color}; border: 1px solid #888;")
    
    def get_value(self):
        return self.current_color


class DropdownWidget(ParameterWidget):
    def setup_ui(self):
        layout = QHBoxLayout()
        layout.setContentsMargins(0, 0, 0, 0)
        
        label = QLabel(self.param_config.get('label', self.param_config['name']))
        layout.addWidget(label)
        
        self.combo = QComboBox()
        self.combo.addItems(self.param_config['options'])
        self.combo.setCurrentText(self.param_config.get('default', self.param_config['options'][0]))
        self.combo.currentTextChanged.connect(self.value_changed.emit)
        layout.addWidget(self.combo)
        
        self.setLayout(layout)
    
    def get_value(self):
        return self.combo.currentText()
    
    def set_value(self, value):
        index = self.combo.findText(value)
        if index >= 0:
            self.combo.setCurrentIndex(index)


class CheckboxWidget(ParameterWidget):
    def setup_ui(self):
        layout = QHBoxLayout()
        layout.setContentsMargins(0, 0, 0, 0)
        
        self.checkbox = QCheckBox(self.param_config.get('label', self.param_config['name']))
        self.checkbox.setChecked(self.param_config.get('default', False))
        self.checkbox.toggled.connect(lambda checked: self.value_changed.emit(checked))
        layout.addWidget(self.checkbox)
        
        self.setLayout(layout)
    
    def get_value(self):
        return self.checkbox.isChecked()
    
    def set_value(self, value):
        self.checkbox.setChecked(value)


class TextBoxWidget(ParameterWidget):
    def setup_ui(self):
        layout = QHBoxLayout()
        layout.setContentsMargins(0, 0, 0, 0)
        
        label = QLabel(self.param_config.get('label', self.param_config['name']))
        layout.addWidget(label)
        
        self.textbox = QLineEdit()
        self.textbox.setText(str(self.param_config.get('default', '')))
        self.textbox.textChanged.connect(lambda text: self.value_changed.emit(text))
        layout.addWidget(self.textbox)
        
        self.setLayout(layout)
    
    def get_value(self):
        return self.textbox.text()
    
    def set_value(self, value):
        self.textbox.setText(str(value))


class ColorListWidget(ParameterWidget):
    def setup_ui(self):
        layout = QVBoxLayout()
        layout.setContentsMargins(0, 0, 0, 0)
        
        label = QLabel(self.param_config.get('label', self.param_config['name']))
        layout.addWidget(label)
        
        # Color list
        self.color_list = QListWidget()
        self.color_list.setMaximumHeight(100)
        for color in self.param_config.get('default', ['#000000']):
            self.add_color_item(color)
        layout.addWidget(self.color_list)
        
        # Buttons
        button_layout = QHBoxLayout()
        add_button = QPushButton("Add Color")
        remove_button = QPushButton("Remove Color")
        add_button.clicked.connect(self.add_color)
        remove_button.clicked.connect(self.remove_color)
        button_layout.addWidget(add_button)
        button_layout.addWidget(remove_button)
        layout.addLayout(button_layout)
        
        self.setLayout(layout)
    
    def add_color_item(self, color):
        item = QListWidgetItem()
        item.setData(Qt.UserRole, color)
        
        # Create color preview
        pixmap = QPixmap(20, 20)
        pixmap.fill(QColor(color))
        item.setIcon(pixmap)
        item.setText(color)
        
        self.color_list.addItem(item)
    
    def add_color(self):
        color = QColorDialog.getColor(QColor('#000000'), self)
        if color.isValid():
            self.add_color_item(color.name())
            self.value_changed.emit(None)
    
    def remove_color(self):
        current_item = self.color_list.currentItem()
        if current_item:
            self.color_list.takeItem(self.color_list.row(current_item))
            self.value_changed.emit(None)
    
    def get_value(self):
        colors = []
        for i in range(self.color_list.count()):
            item = self.color_list.item(i)
            colors.append(item.data(Qt.UserRole))
        return colors
    
    def set_value(self, colors):
        self.color_list.clear()
        for color in colors:
            self.add_color_item(color)


