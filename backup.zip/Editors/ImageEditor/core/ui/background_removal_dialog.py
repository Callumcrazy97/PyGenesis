from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QGroupBox,
    QDialogButtonBox, QScrollArea, QWidget,
    QMessageBox, QProgressDialog
)
from PySide6.QtCore import Qt
from PySide6.QtGui import QPixmap, QImage
import numpy as np
import cv2
import traceback
import subprocess
import sys
from pathlib import Path


class BackgroundRemovalDialog(QDialog):
    """
    Background removal using DeepLabv3 (PyTorch-based segmentation).
    """

    def __init__(self, image, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Background Removal (AI)")
        self.setModal(True)
        self.setMinimumSize(800, 600)

        # Normalize to RGB
        if image.dtype != np.uint8:
            image = np.clip(image, 0, 255).astype(np.uint8)

        if len(image.shape) == 2:
            image_rgb = cv2.cvtColor(image, cv2.COLOR_GRAY2RGB)
        elif len(image.shape) == 3 and image.shape[2] == 4:
            image_rgb = cv2.cvtColor(image, cv2.COLOR_RGBA2RGB)
        elif len(image.shape) == 3 and image.shape[2] == 3:
            image_rgb = image.copy()
        else:
            raise ValueError("Unsupported image shape")

        self.original_image_rgb = image_rgb
        self.original_image_bgr = cv2.cvtColor(image_rgb, cv2.COLOR_RGB2BGR)
        self.result_image_rgba = None
        
        # Lazy-loaded model
        self.deeplabv3_model = None
        
        self._setup_ui()
        self._update_original_preview()

    def _setup_ui(self):
        scroll = QScrollArea(self)
        scroll.setWidgetResizable(True)

        main_widget = QWidget()
        main_layout = QVBoxLayout(main_widget)

        # Instructions
        instructions = QLabel(
            "AI-powered background removal using DeepLabv3 (PyTorch-based segmentation).\n"
            "Requires PyTorch and torchvision to be installed."
        )
        instructions.setWordWrap(True)
        main_layout.addWidget(instructions)

        # Side-by-side preview
        preview_group = QGroupBox("Original and Result Preview")
        preview_layout = QHBoxLayout(preview_group)

        self.original_label = QLabel()
        self.original_label.setAlignment(Qt.AlignCenter)
        self.original_label.setMinimumSize(400, 300)
        self.original_label.setStyleSheet("border: 1px solid #888; background: #333;")
        preview_layout.addWidget(self.original_label)

        self.result_label = QLabel("Click 'Process' to generate result")
        self.result_label.setAlignment(Qt.AlignCenter)
        self.result_label.setMinimumSize(400, 300)
        self.result_label.setStyleSheet("border: 1px solid #888; background: #333;")
        preview_layout.addWidget(self.result_label)

        main_layout.addWidget(preview_group)

        # Process button
        btn_row = QHBoxLayout()
        self.process_btn = QPushButton("Process")
        self.process_btn.clicked.connect(self._on_process)
        btn_row.addWidget(self.process_btn)
        btn_row.addStretch()
        main_layout.addLayout(btn_row)

        scroll.setWidget(main_widget)

        outer_layout = QVBoxLayout(self)
        outer_layout.addWidget(scroll)

        button_box = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        button_box.accepted.connect(self._on_accept)
        button_box.rejected.connect(self.reject)
        outer_layout.addWidget(button_box)

    def _update_original_preview(self):
        rgb = self.original_image_rgb
        h, w = rgb.shape[:2]
        q_img = QImage(rgb.data, w, h, w * 3, QImage.Format_RGB888).copy()
        pix = QPixmap.fromImage(q_img)
        scaled = pix.scaled(
            self.original_label.minimumSize(),
            Qt.KeepAspectRatio,
            Qt.SmoothTransformation
        )
        self.original_label.setPixmap(scaled)

    def _update_result_preview(self):
        if self.result_image_rgba is None:
            return
        rgba = self.result_image_rgba
        h, w = rgba.shape[:2]
        q_img = QImage(rgba.data, w, h, w * 4, QImage.Format_RGBA8888).copy()
        pix = QPixmap.fromImage(q_img)
        scaled = pix.scaled(
            self.result_label.minimumSize(),
            Qt.KeepAspectRatio,
            Qt.SmoothTransformation
        )
        self.result_label.setPixmap(scaled)


    def _install_package(self, package_name, import_name=None):
        """Install a package and return True if successful."""
        if import_name is None:
            import_name = package_name
        
        # Check if already installed
        try:
            __import__(import_name)
            return True
        except ImportError:
            pass
        
        # Ask user
        reply = QMessageBox.question(
            self,
            "Package Required",
            f"The '{package_name}' package is required for this feature.\n\n"
            f"Would you like to install it now?\n\n"
            f"This may take a few minutes.",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.Yes
        )
        
        if reply != QMessageBox.Yes:
            return False
        
        # Try to get venv Python
        python_exe = sys.executable
        venv_path = Path.home() / ".pygenesis" / "venv"
        if venv_path.exists():
            if sys.platform == "win32":
                venv_python = venv_path / "Scripts" / "python.exe"
            else:
                venv_python = venv_path / "bin" / "python"
            if venv_python.exists():
                python_exe = str(venv_python)
        
        # Show progress
        progress = QProgressDialog(f"Installing {package_name}...", "Cancel", 0, 0, self)
        progress.setWindowModality(Qt.WindowModality.WindowModal)
        progress.setCancelButton(None)
        progress.show()
        
        try:
            # Install package
            result = subprocess.run(
                [python_exe, "-m", "pip", "install", package_name],
                capture_output=True,
                text=True,
                timeout=300  # 5 minute timeout
            )
            
            progress.close()
            
            if result.returncode == 0:
                # Verify installation
                try:
                    importlib = __import__('importlib')
                    importlib.invalidate_caches()
                    __import__(import_name)
                    QMessageBox.information(
                        self,
                        "Installation Complete",
                        f"{package_name} has been installed successfully.\n\n"
                        f"Please click 'Process' again."
                    )
                    return True
                except ImportError:
                    QMessageBox.warning(
                        self,
                        "Installation Issue",
                        f"{package_name} was installed but could not be imported.\n\n"
                        f"You may need to restart the application."
                    )
                    return False
            else:
                QMessageBox.critical(
                    self,
                    "Installation Failed",
                    f"Failed to install {package_name}.\n\n"
                    f"Error: {result.stderr}\n\n"
                    f"Please install manually: pip install {package_name}"
                )
                return False
        except subprocess.TimeoutExpired:
            progress.close()
            QMessageBox.critical(
                self,
                "Installation Timeout",
                f"Installation of {package_name} timed out.\n\n"
                f"Please try installing manually: pip install {package_name}"
            )
            return False
        except Exception as e:
            progress.close()
            QMessageBox.critical(
                self,
                "Installation Error",
                f"Error installing {package_name}:\n\n{str(e)}"
            )
            return False

    def _load_deeplabv3(self):
        """Load DeepLabv3 model (lazy loading)."""
        if self.deeplabv3_model is not None:
            return self.deeplabv3_model
        
        # Check if already available
        try:
            import torch
            import torchvision
        except ImportError:
            if not self._install_package("torch", "torch"):
                return None
            if not self._install_package("torchvision", "torchvision"):
                return None
        
        try:
            import torch
            import torchvision.transforms as transforms
            from torchvision.models.segmentation import deeplabv3_resnet50
            from torchvision.models.segmentation import DeepLabV3_ResNet50_Weights
            
            # Load model (use weights instead of deprecated pretrained)
            model = deeplabv3_resnet50(weights=DeepLabV3_ResNet50_Weights.DEFAULT)
            model.eval()
            
            # Store model and transforms
            self.deeplabv3_model = {
                'model': model,
                'transform': transforms.Compose([
                    transforms.ToPILImage(),
                    transforms.Resize((520, 520)),
                    transforms.ToTensor(),
                    transforms.Normalize(
                        mean=[0.485, 0.456, 0.406],
                        std=[0.229, 0.224, 0.225]
                    )
                ])
            }
            
            return self.deeplabv3_model
        except Exception as e:
            QMessageBox.critical(self, "DeepLabv3 Error", f"Failed to load DeepLabv3: {str(e)}")
            return None

    def _remove_background_deeplabv3(self, image_rgb):
        """Remove background using DeepLabv3."""
        model_data = self._load_deeplabv3()
        if model_data is None:
            return None
        
        try:
            import torch
            
            model = model_data['model']
            transform = model_data['transform']
            
            # Prepare image
            img_tensor = transform(image_rgb)
            img_tensor = img_tensor.unsqueeze(0)
            
            # Run inference
            with torch.no_grad():
                output = model(img_tensor)['out'][0]
            
            # Get segmentation mask (class 0 is background)
            mask = output.argmax(0).cpu().numpy()
            # Invert: 0=background, 1-20=foreground
            fg_mask = (mask > 0).astype(np.uint8) * 255
            
            # Resize mask to original image size
            h, w = image_rgb.shape[:2]
            fg_mask = cv2.resize(fg_mask, (w, h), interpolation=cv2.INTER_NEAREST)
            
            # Create RGBA output
            rgba = np.dstack([image_rgb, fg_mask])
            
            return rgba
        except Exception as e:
            QMessageBox.critical(self, "DeepLabv3 Processing Error", f"Error: {str(e)}")
            return None

    def _remove_background(self):
        """Main background removal pipeline using DeepLabv3."""
        model_data = self._load_deeplabv3()
        if model_data is None:
            QMessageBox.warning(
                self,
                "PyTorch Not Available",
                "PyTorch and torchvision are required for background removal.\n\n"
                "Please install: pip install torch torchvision"
            )
            return None
        
        return self._remove_background_deeplabv3(self.original_image_rgb)

    def _on_process(self):
        try:
            self.result_label.setText("Processing...")
            self.result_image_rgba = self._remove_background()
            if self.result_image_rgba is not None:
                self._update_result_preview()
            else:
                self.result_label.setText("Processing failed. Check error messages.")
        except Exception as e:
            self.result_label.setText(f"Error: {e}")
            traceback.print_exc()

    def _on_accept(self):
        if self.result_image_rgba is None:
            self._on_process()
        if self.result_image_rgba is not None:
            self.accept()

    def get_result(self):
        return self.result_image_rgba
