# Advanced Atmospheric Lighting Helper Functions
import numpy as np
import cv2
from typing import List, Tuple, Dict, Any, Optional
import math

class LightSource:
    """Represents a light source with position, properties, and effects."""
    
    def __init__(self, x: int, y: int, radius: float = 100.0, intensity: float = 1.0, 
                 color: str = "#FFFFFF", light_type: str = "point"):
        self.x = x
        self.y = y
        self.radius = radius
        self.intensity = intensity
        self.color = color
        self.light_type = light_type  # "point", "directional", "ambient", "spot"
        self.falloff_exponent = 2.0
        self.angle = 0.0  # For directional/spot lights
        self.cone_angle = 45.0  # For spot lights
        self.flicker_amount = 0.0
        self.flicker_speed = 1.0

class AtmosphericLightingSystem:
    """Advanced atmospheric lighting system with multiple light sources and effects."""
    
    def __init__(self, image_shape: Tuple[int, int]):
        self.height, self.width = image_shape[:2]
        self.light_sources: List[LightSource] = []
        self.ambient_light = 0.2
        self.ambient_color = "#404040"
        self.atmosphere_density = 0.0
        self.atmosphere_color = "#808080"
        
    def add_light_source(self, light: LightSource):
        """Add a light source to the system."""
        self.light_sources.append(light)
    
    def detect_light_sources(self, img_array: np.ndarray, detection_params: Dict[str, Any]) -> List[LightSource]:
        """Simple and effective light source detection based on brightness and local contrast."""
        detected_lights = []
        
        # Convert to grayscale for analysis (handle RGBA images)
        if len(img_array.shape) == 3:
            if img_array.shape[2] == 4:  # RGBA
                gray = cv2.cvtColor(img_array, cv2.COLOR_RGBA2GRAY)
            else:  # RGB
                gray = cv2.cvtColor(img_array, cv2.COLOR_RGB2GRAY)
        else:
            gray = img_array.copy()
        
        # Simple brightness-based detection with local contrast analysis
        brightness_lights = self._detect_brightness_lights_simple(gray, detection_params)
        detected_lights.extend(brightness_lights)
        
        # Merge nearby lights and remove duplicates
        merged_lights = self._merge_nearby_lights(detected_lights, detection_params.get('merge_distance', 30))
        
        return merged_lights
    
    def create_light_source_highlight(self, img_array: np.ndarray, light_sources: List[LightSource], 
                                    highlight_color: tuple = (0, 255, 255), glow_radius_multiplier: float = 2.0) -> np.ndarray:
        """
        Create a visual highlight of detected light sources for debugging/feedback.
        
        Args:
            img_array: Original image array
            light_sources: List of detected light sources
            highlight_color: RGB color for the highlight (default: cyan)
            glow_radius_multiplier: How much larger the glow should be than the light radius
            
        Returns:
            Image array with highlighted light sources
        """
        if not light_sources:
            return img_array.copy()
        
        # Create a copy to avoid modifying the original
        highlighted_img = img_array.copy()
        
        # Handle different image formats
        if len(highlighted_img.shape) == 3:
            if highlighted_img.shape[2] == 4:  # RGBA
                # Convert to RGB for highlighting, preserve alpha
                rgb_img = highlighted_img[:, :, :3].copy()
                alpha_channel = highlighted_img[:, :, 3:4].copy()
            else:  # RGB
                rgb_img = highlighted_img.copy()
                alpha_channel = None
        else:
            # Grayscale - convert to RGB
            rgb_img = cv2.cvtColor(highlighted_img, cv2.COLOR_GRAY2RGB)
            alpha_channel = None
        
        # Create highlight overlay
        overlay = np.zeros_like(rgb_img)
        
        for light in light_sources:
            # Calculate glow radius
            glow_radius = int(light.radius * glow_radius_multiplier)
            
            # Create circular highlight
            cv2.circle(overlay, (light.x, light.y), glow_radius, highlight_color, -1)
            
            # Add center dot
            cv2.circle(overlay, (light.x, light.y), max(3, int(light.radius * 0.3)), (255, 255, 255), -1)
            
            # Add intensity-based glow effect
            for radius in range(glow_radius, 0, -max(1, glow_radius // 10)):
                alpha = 0.3 * (1.0 - radius / glow_radius)
                color_with_alpha = tuple(int(c * alpha) for c in highlight_color)
                cv2.circle(overlay, (light.x, light.y), radius, color_with_alpha, -1)
        
        # Blend overlay with original image
        highlighted_rgb = cv2.addWeighted(rgb_img, 0.7, overlay, 0.3, 0)
        
        # Recombine with alpha if present
        if alpha_channel is not None:
            highlighted_img = np.concatenate([highlighted_rgb, alpha_channel], axis=2)
        else:
            highlighted_img = highlighted_rgb
        
        return highlighted_img
    
    def _detect_brightness_lights_simple(self, gray: np.ndarray, params: Dict[str, Any]) -> List[LightSource]:
        """
        Advanced light detection using percentile-based thresholding with local contrast analysis.
        Based on the principle: "light sources are brighter than their surroundings"
        """
        lights = []
        
        # Get parameters
        threshold_percentile = params.get('threshold_percentile', 75)  # Brightest 25% of pixels
        min_area = params.get('min_light_area', 5)  # Very small minimum area
        contrast_threshold = params.get('contrast_threshold', 2)  # Very low contrast threshold
        
        # Step 1: Apply Gaussian blur to reduce noise
        blurred = cv2.GaussianBlur(gray, (9, 9), 2)
        
        # Step 2: Calculate dynamic threshold based on brightness percentile
        threshold_value = np.percentile(blurred, threshold_percentile)
        print(f"DEBUG: Threshold value: {threshold_value:.1f} (percentile: {threshold_percentile})")
        
        # Step 3: Create binary mask of bright regions
        _, bright_mask = cv2.threshold(blurred, threshold_value, 255, cv2.THRESH_BINARY)
        
        # Debug: count bright pixels
        bright_pixels = np.sum(bright_mask > 0)
        print(f"DEBUG: Found {bright_pixels} bright pixels above threshold")
        
        # Step 4: Find contours of bright regions
        contours, _ = cv2.findContours(bright_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        print(f"DEBUG: Found {len(contours)} contours")
        
        for contour in contours:
            area = cv2.contourArea(contour)
            print(f"DEBUG: Contour area: {area:.1f} (min required: {min_area})")
            if area >= min_area:
                # Calculate centroid
                M = cv2.moments(contour)
                if M["m00"] != 0:
                    cx = int(M["m10"] / M["m00"])
                    cy = int(M["m01"] / M["m00"])
                    
                    # Step 5: Local contrast check - is this region brighter than its surroundings?
                    x, y, w, h = cv2.boundingRect(contour)
                    
                    # Expand bounding box to check surroundings
                    margin = max(w, h) // 2
                    x1 = max(0, x - margin)
                    y1 = max(0, y - margin)
                    x2 = min(gray.shape[1], x + w + margin)
                    y2 = min(gray.shape[0], y + h + margin)
                    
                    # Get region and surroundings
                    region = blurred[y:y+h, x:x+w]
                    surroundings = blurred[y1:y2, x1:x2]
                    
                    # Calculate average brightness of region vs surroundings
                    region_brightness = np.mean(region)
                    surroundings_brightness = np.mean(surroundings)
                    
                    # Check if region is significantly brighter than surroundings
                    contrast = region_brightness - surroundings_brightness
                    print(f"DEBUG: Contrast check - region: {region_brightness:.1f}, surroundings: {surroundings_brightness:.1f}, contrast: {contrast:.1f} (min: {contrast_threshold})")
                    
                    if contrast >= contrast_threshold:
                        # Calculate intensity based on brightness
                        intensity = min(region_brightness / 255.0, 1.0)
                        
                        # Estimate radius from area
                        radius = math.sqrt(area / math.pi)
                        
                        # Determine light color (default white for now)
                        light_color = "#FFFFFF"
                        
                        lights.append(LightSource(cx, cy, radius, intensity, light_color, "point"))
        
        return lights
    
    def _detect_edge_lights(self, gray: np.ndarray, params: Dict[str, Any]) -> List[LightSource]:
        """Detect light sources based on edge patterns (for light fixtures)."""
        lights = []
        
        # Edge detection
        edges = cv2.Canny(gray, 50, 150)
        
        # Find circular patterns (common for light fixtures)
        circles = cv2.HoughCircles(
            gray, cv2.HOUGH_GRADIENT, 1, 20,
            param1=50, param2=30, minRadius=5, maxRadius=50
        )
        
        if circles is not None:
            circles = np.round(circles[0, :]).astype("int")
            for (x, y, r) in circles:
                # Check if the center is bright
                center_brightness = gray[y, x] if 0 <= y < gray.shape[0] and 0 <= x < gray.shape[1] else 0
                if center_brightness > 150:
                    intensity = center_brightness / 255.0
                    lights.append(LightSource(x, y, r * 2, intensity, "#FFFFFF", "point"))
        
        return lights
    
    def _detect_color_lights(self, img_array: np.ndarray, params: Dict[str, Any]) -> List[LightSource]:
        """Detect colored light sources."""
        lights = []
        
        # Convert to HSV for better color detection
        hsv = cv2.cvtColor(img_array, cv2.COLOR_RGB2HSV)
        
        # Define color ranges for common light colors
        color_ranges = {
            'warm': ([0, 50, 50], [30, 255, 255]),      # Red/Yellow
            'cool': ([100, 50, 50], [130, 255, 255]),   # Blue
            'green': ([40, 50, 50], [80, 255, 255]),    # Green
            'purple': ([130, 50, 50], [160, 255, 255])  # Purple
        }
        
        for color_name, (lower, upper) in color_ranges.items():
            # Create mask for this color
            mask = cv2.inRange(hsv, np.array(lower), np.array(upper))
            
            # Find contours
            contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            
            for contour in contours:
                area = cv2.contourArea(contour)
                if area > 20:  # Minimum area for colored lights
                    M = cv2.moments(contour)
                    if M["m00"] != 0:
                        cx = int(M["m10"] / M["m00"])
                        cy = int(M["m01"] / M["m00"])
                        
                        # Get average color
                        mask_region = np.zeros(img_array.shape[:2], dtype=np.uint8)
                        cv2.fillPoly(mask_region, [contour], 255)
                        avg_color = np.mean(img_array[mask_region > 0], axis=0)
                        
                        # Convert to hex
                        color_hex = f"#{int(avg_color[0]):02x}{int(avg_color[1]):02x}{int(avg_color[2]):02x}"
                        
                        radius = math.sqrt(area / math.pi) * 2
                        intensity = np.mean(avg_color) / 255.0
                        
                        lights.append(LightSource(cx, cy, radius, intensity, color_hex, "point"))
        
        return lights
    
    def _detect_template_lights(self, gray: np.ndarray, params: Dict[str, Any]) -> List[LightSource]:
        """Detect light sources using template matching."""
        lights = []
        
        # This is a placeholder for template matching
        # In a full implementation, you would load templates for common light shapes
        # and use cv2.matchTemplate() to find them
        
        return lights
    
    def _merge_nearby_lights(self, lights: List[LightSource], merge_distance: float) -> List[LightSource]:
        """Merge lights that are too close to each other."""
        if not lights:
            return []
        
        merged = []
        used = set()
        
        for i, light1 in enumerate(lights):
            if i in used:
                continue
                
            # Find all lights close to this one
            nearby_lights = [light1]
            for j, light2 in enumerate(lights[i+1:], i+1):
                if j in used:
                    continue
                    
                distance = math.sqrt((light1.x - light2.x)**2 + (light1.y - light2.y)**2)
                if distance <= merge_distance:
                    nearby_lights.append(light2)
                    used.add(j)
            
            # Merge nearby lights
            if len(nearby_lights) > 1:
                # Calculate weighted average position
                total_intensity = sum(light.intensity for light in nearby_lights)
                avg_x = sum(light.x * light.intensity for light in nearby_lights) / total_intensity
                avg_y = sum(light.y * light.intensity for light in nearby_lights) / total_intensity
                avg_radius = sum(light.radius for light in nearby_lights) / len(nearby_lights)
                avg_intensity = total_intensity / len(nearby_lights)
                
                # Use the most intense light's color
                brightest_light = max(nearby_lights, key=lambda l: l.intensity)
                
                merged_light = LightSource(
                    int(avg_x), int(avg_y), avg_radius, avg_intensity,
                    brightest_light.color, brightest_light.light_type
                )
                merged.append(merged_light)
            else:
                merged.append(light1)
            
            used.add(i)
        
        return merged
    
    def create_lighting_map(self, light_sources: List[LightSource], 
                          falloff_type: str = "quadratic", 
                          global_intensity: float = 1.0) -> np.ndarray:
        """Create a comprehensive lighting map from all light sources."""
        lighting_map = np.zeros((self.height, self.width, 3), dtype=np.float32)
        
        for light in light_sources:
            # Create individual light map
            light_map = self._create_single_light_map(light, falloff_type, global_intensity)
            
            # Add to combined lighting map
            lighting_map = np.maximum(lighting_map, light_map)
        
        return lighting_map
    
    def _create_single_light_map(self, light: LightSource, falloff_type: str, global_intensity: float) -> np.ndarray:
        """Create lighting map for a single light source."""
        light_map = np.zeros((self.height, self.width, 3), dtype=np.float32)
        
        # Create coordinate grids
        y, x = np.ogrid[:self.height, :self.width]
        
        # Calculate distance from light source
        distance = np.sqrt((x - light.x)**2 + (y - light.y)**2)
        
        # Apply falloff based on type
        if falloff_type == "linear":
            falloff = np.maximum(0, 1 - distance / light.radius)
        elif falloff_type == "quadratic":
            falloff = np.maximum(0, 1 - (distance / light.radius)**2)
        elif falloff_type == "exponential":
            falloff = np.exp(-distance / (light.radius / 3))
        else:  # inverse_square
            falloff = 1 / (1 + (distance / light.radius)**2)
        
        # Apply falloff exponent
        falloff = np.power(falloff, light.falloff_exponent)
        
        # Apply intensity
        falloff *= light.intensity * global_intensity
        
        # Add flicker if enabled
        if light.flicker_amount > 0:
            flicker = 1.0 + np.random.normal(0, light.flicker_amount / 100.0)
            flicker = np.clip(flicker, 0.8, 1.2)
            falloff *= flicker
        
        # Apply light color
        light_rgb = self._hex_to_rgb(light.color)
        for i, color_component in enumerate(light_rgb):
            light_map[:, :, i] = falloff * (color_component / 255.0)
        
        return light_map
    
    def create_shadow_map(self, light_sources: List[LightSource], 
                         shadow_params: Dict[str, Any]) -> np.ndarray:
        """Create a shadow map based on light sources and image content."""
        shadow_map = np.ones((self.height, self.width), dtype=np.float32)
        
        if not shadow_params.get('enable_shadows', True):
            return shadow_map
        
        # This is a simplified shadow system
        # In a full implementation, you would analyze the image to determine
        # where shadows should be cast based on objects and light direction
        
        for light in light_sources:
            # Create distance-based shadow falloff
            y, x = np.ogrid[:self.height, :self.width]
            distance = np.sqrt((x - light.x)**2 + (y - light.y)**2)
            
            # Shadow gets stronger with distance from light
            shadow_strength = 1.0 - (distance / (light.radius * 2))
            shadow_strength = np.clip(shadow_strength, 0, 1)
            
            # Apply shadow darkness
            shadow_darkness = shadow_params.get('shadow_darkness', 0.7)
            shadow_strength *= shadow_darkness
            
            # Apply to shadow map
            shadow_map = np.minimum(shadow_map, 1.0 - shadow_strength)
        
        # Apply shadow softness
        shadow_softness = shadow_params.get('shadow_softness', 1.5)
        if shadow_softness > 1.0:
            kernel_size = int(shadow_softness * 5)
            if kernel_size % 2 == 0:
                kernel_size += 1
            shadow_map = cv2.GaussianBlur(shadow_map, (kernel_size, kernel_size), shadow_softness)
        
        return shadow_map
    
    def apply_atmospheric_effects(self, img_array: np.ndarray, 
                                atmosphere_params: Dict[str, Any]) -> np.ndarray:
        """Apply atmospheric effects like fog, haze, or dust."""
        if atmosphere_params.get('atmosphere_density', 0) <= 0:
            return img_array
        
        result = img_array.copy().astype(np.float32)
        
        # Get atmosphere parameters
        density = atmosphere_params.get('atmosphere_density', 0) / 100.0
        color = atmosphere_params.get('atmosphere_color', '#808080')
        distance_factor = atmosphere_params.get('atmosphere_distance', 0.5)
        
        # Convert atmosphere color to RGB
        atm_rgb = self._hex_to_rgb(color)
        
        # Handle different image formats (RGB vs RGBA)
        has_alpha = img_array.shape[2] == 4
        if has_alpha:
            # Only apply atmosphere to RGB channels, preserve alpha
            rgb_channels = result[:, :, :3]
            alpha_channel = result[:, :, 3:4]
        else:
            rgb_channels = result
        
        # Create distance-based atmosphere (simplified)
        # In a full implementation, you would calculate actual depth/distance
        center_x, center_y = self.width // 2, self.height // 2
        y, x = np.ogrid[:self.height, :self.width]
        distance = np.sqrt((x - center_x)**2 + (y - center_y)**2)
        max_distance = np.sqrt(center_x**2 + center_y**2)
        normalized_distance = distance / max_distance
        
        # Apply atmosphere based on distance
        for i, atm_component in enumerate(atm_rgb):
            atmosphere_layer = normalized_distance * density * (atm_component / 255.0)
            rgb_channels[:, :, i] = rgb_channels[:, :, i] * (1 - density) + atmosphere_layer * 255
        
        # Recombine with alpha if present
        if has_alpha:
            result = np.concatenate([rgb_channels, alpha_channel], axis=2)
        else:
            result = rgb_channels
        
        return np.clip(result, 0, 255).astype(np.uint8)
    
    def apply_lighting_to_image(self, img_array: np.ndarray, lighting_map: np.ndarray,
                              shadow_map: np.ndarray, ambient_params: Dict[str, Any], 
                              shadow_params: Optional[Dict[str, Any]] = None) -> np.ndarray:
        """Apply the complete lighting system to an image."""
        # Convert to float
        img_float = img_array.astype(np.float32) / 255.0
        
        # Handle different image formats (RGB vs RGBA)
        has_alpha = img_array.shape[2] == 4
        if has_alpha:
            # Separate RGB and alpha channels
            img_rgb = img_float[:, :, :3]
            img_alpha = img_float[:, :, 3:4]
        else:
            img_rgb = img_float
            img_alpha = None
        
        # Apply ambient lighting - make it more visible
        ambient_intensity = ambient_params.get('ambient_light', 0.2)
        ambient_color = ambient_params.get('ambient_color', '#404040')
        ambient_rgb = self._hex_to_rgb(ambient_color)
        
        # Apply ambient lighting as additive rather than multiplicative for better visibility
        ambient_contribution = np.zeros_like(img_rgb)
        for i, color_component in enumerate(ambient_rgb):
            ambient_contribution[:, :, i] = ambient_intensity * (color_component / 255.0)
        
        # Blend ambient with original image
        img_rgb = img_rgb * (1 - ambient_intensity) + ambient_contribution
        
        # Apply lighting map
        img_rgb = np.clip(img_rgb + lighting_map, 0, 1)
        
        # Apply shadows (only if enabled and shadow map exists)
        if shadow_map is not None and (shadow_params is None or shadow_params.get('enable_shadows', True)):
            shadow_strength = shadow_params.get('shadow_darkness', 0.7) if shadow_params else 0.7
            # Apply shadows as darkening, not as bright spots
            shadow_map_3d = np.stack([shadow_map] * 3, axis=2)
            img_rgb = img_rgb * (1 - shadow_map_3d * shadow_strength)
        
        # Apply post-processing
        brightness_boost = ambient_params.get('brightness_boost', 1.0)
        contrast_boost = ambient_params.get('contrast_boost', 1.0)
        
        if brightness_boost != 1.0:
            img_rgb *= brightness_boost
        
        if contrast_boost != 1.0:
            img_rgb = np.clip((img_rgb - 0.5) * contrast_boost + 0.5, 0, 1)
        
        # Recombine with alpha if present
        if has_alpha:
            result = np.concatenate([img_rgb, img_alpha], axis=2)
        else:
            result = img_rgb
        
        return (result * 255).astype(np.uint8)
    
    def _hex_to_rgb(self, hex_color: str) -> Tuple[int, int, int]:
        """Convert hex color to RGB tuple."""
        hex_color = hex_color.lstrip('#')
        return tuple(int(hex_color[i:i+2], 16) for i in (0, 2, 4))

# Convenience functions for backward compatibility
def create_atmospheric_lighting_system(img_array: np.ndarray) -> AtmosphericLightingSystem:
    """Create an atmospheric lighting system for the given image."""
    return AtmosphericLightingSystem(img_array.shape)

def detect_light_sources_advanced(img_array: np.ndarray, 
                                brightness_threshold: int = 200,
                                min_area: int = 10,
                                max_area: int = 1000) -> List[LightSource]:
    """Advanced light source detection with multiple algorithms."""
    system = create_atmospheric_lighting_system(img_array)
    
    detection_params = {
        'brightness_threshold': brightness_threshold,
        'min_light_area': min_area,
        'max_light_area': max_area,
        'use_brightness_detection': True,
        'use_edge_detection': True,
        'use_color_detection': True,
        'use_template_matching': False,
        'merge_distance': 30
    }
    
    return system.detect_light_sources(img_array, detection_params)

