from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QTabWidget, QWidget,
    QComboBox, QColorDialog, QFormLayout, QDialogButtonBox, QLineEdit, QCheckBox,
    QRadioButton, QButtonGroup, QGroupBox, QSlider, QSpinBox, QFrame
)
from PySide6.QtGui import QColor, QPixmap, QImage, QPainter
from PySide6.QtCore import Qt, Signal, QTimer
from core.texture_utils import generate_block_texture_qimage, hex_to_qcolor, make_gradient_palette_qt
import random
import math

class BlockTextureDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.main_window = parent
        self.setWindowTitle("Block Texture Creator")
        self.resize(450, 500)
        self.setModal(True)
        
        # Store preview image
        self.preview_pixmap = None
        self.preview_timer = QTimer()
        self.preview_timer.setSingleShot(True)
        self.preview_timer.timeout.connect(self.update_preview)
        
        self._setup_ui()
        self._connect_signals()
        self.update_preview()

    def _setup_ui(self):
        layout = QVBoxLayout(self)
        
        # Create tab widget
        self.tab_widget = QTabWidget()
        
        # Block/Color Tab
        self.block_tab = QWidget()
        self._setup_block_tab()
        self.tab_widget.addTab(self.block_tab, "Block/Color")
        
        # Style Tab
        self.style_tab = QWidget()
        self._setup_style_tab()
        self.tab_widget.addTab(self.style_tab, "Style")
        
        # Animation Tab
        self.animation_tab = QWidget()
        self._setup_animation_tab()
        self.tab_widget.addTab(self.animation_tab, "Animation")
        
        layout.addWidget(self.tab_widget)
        
        # Area selection
        area_group = QGroupBox("Area")
        area_layout = QVBoxLayout(area_group)
        self.area_group = QButtonGroup()
        self.full_image_radio = QRadioButton("Full Image")
        self.selection_radio = QRadioButton("Selected Area")
        self.full_image_radio.setChecked(True)
        self.area_group.addButton(self.full_image_radio)
        self.area_group.addButton(self.selection_radio)
        area_layout.addWidget(self.full_image_radio)
        area_layout.addWidget(self.selection_radio)
        layout.addWidget(area_group)
        
        # Preview
        preview_group = QGroupBox("Preview")
        preview_layout = QVBoxLayout(preview_group)
        
        # Preview canvas
        self.preview_canvas = QLabel()
        self.preview_canvas.setMinimumSize(200, 200)
        self.preview_canvas.setMaximumSize(300, 300)
        self.preview_canvas.setAlignment(Qt.AlignCenter)
        self.preview_canvas.setStyleSheet("border: 1px solid #888; background: #333;")
        preview_layout.addWidget(self.preview_canvas)
        
        # Add canvas size info
        self.canvas_info_label = QLabel("Canvas: 32x32")
        self.canvas_info_label.setAlignment(Qt.AlignCenter)
        preview_layout.addWidget(self.canvas_info_label)
        
        layout.addWidget(preview_group)
        
        # Buttons
        button_layout = QHBoxLayout()
        self.ok_button = QPushButton("OK")
        self.cancel_button = QPushButton("Cancel")
        button_layout.addWidget(self.ok_button)
        button_layout.addWidget(self.cancel_button)
        layout.addLayout(button_layout)

    def _setup_block_tab(self):
        layout = QVBoxLayout(self.block_tab)
        
        # Color pickers
        color_group = QGroupBox("Colors")
        color_layout = QHBoxLayout(color_group)
        
        # Color 1
        color1_layout = QVBoxLayout()
        color1_layout.addWidget(QLabel("Color 1:"))
        self.color1_btn = QPushButton()
        self.color1_btn.setFixedSize(60, 30)
        self.color1_btn.clicked.connect(lambda: self.pick_color(1))
        color1_layout.addWidget(self.color1_btn)
        color_layout.addLayout(color1_layout)
        
        # Color 2
        color2_layout = QVBoxLayout()
        color2_layout.addWidget(QLabel("Color 2:"))
        self.color2_btn = QPushButton()
        self.color2_btn.setFixedSize(60, 30)
        self.color2_btn.clicked.connect(lambda: self.pick_color(2))
        color2_layout.addWidget(self.color2_btn)
        color_layout.addLayout(color2_layout)
        
        layout.addWidget(color_group)
        
        # Block size
        block_group = QGroupBox("Block Size")
        block_layout = QHBoxLayout(block_group)
        block_layout.addWidget(QLabel("Size:"))
        self.block_size_spin = QSpinBox()
        self.block_size_spin.setRange(1, 64)
        self.block_size_spin.setValue(8)
        block_layout.addWidget(self.block_size_spin)
        
        # Preset buttons
        for preset in [2, 4, 8, 16, 32]:
            btn = QPushButton(str(preset))
            btn.setFixedSize(30, 25)
            btn.clicked.connect(lambda checked, val=preset: self.block_size_spin.setValue(val))
            block_layout.addWidget(btn)
        
        block_layout.addStretch()
        layout.addWidget(block_group)
        
        # Opacity
        opacity_group = QGroupBox("Opacity")
        opacity_layout = QHBoxLayout(opacity_group)
        opacity_layout.addWidget(QLabel("Opacity:"))
        self.opacity_slider = QSlider(Qt.Horizontal)
        self.opacity_slider.setRange(0, 100)
        self.opacity_slider.setValue(100)
        self.opacity_label = QLabel("100%")
        opacity_layout.addWidget(self.opacity_slider)
        opacity_layout.addWidget(self.opacity_label)
        layout.addWidget(opacity_group)
        
        layout.addStretch()

    def _setup_style_tab(self):
        layout = QVBoxLayout(self.style_tab)
        
        # Style selection
        style_group = QGroupBox("Texture Style")
        style_layout = QVBoxLayout(style_group)
        
        self.style_combo = QComboBox()
        self.style_combo.addItems([
            "None",
            "Water",
            "Lava", 
            "Fire",
            "Smoke",
            "Fog",
            "Crystal",
            "Wind",
            "Portal"
        ])
        self.style_combo.setCurrentText("None")
        style_layout.addWidget(self.style_combo)
        
        layout.addWidget(style_group)
        
        # Style-specific parameters
        self.style_params_group = QGroupBox("Style Parameters")
        self.style_params_layout = QVBoxLayout(self.style_params_group)
        layout.addWidget(self.style_params_group)
        
        # Initialize style parameters
        self._setup_style_parameters()
        
        layout.addStretch()

    def _setup_animation_tab(self):
        layout = QVBoxLayout(self.animation_tab)
        
        # Animation toggle
        self.animate_checkbox = QCheckBox("Enable Animation")
        self.animate_checkbox.setChecked(False)
        layout.addWidget(self.animate_checkbox)
        
        # Animation parameters
        anim_group = QGroupBox("Animation Settings")
        anim_layout = QVBoxLayout(anim_group)
        
        # Frame count
        frame_layout = QHBoxLayout()
        frame_layout.addWidget(QLabel("Frames:"))
        self.frame_count_spin = QSpinBox()
        self.frame_count_spin.setRange(2, 16)
        self.frame_count_spin.setValue(4)
        frame_layout.addWidget(self.frame_count_spin)
        frame_layout.addStretch()
        anim_layout.addLayout(frame_layout)
        
        # Animation speed
        speed_layout = QHBoxLayout()
        speed_layout.addWidget(QLabel("Speed:"))
        self.anim_speed_slider = QSlider(Qt.Horizontal)
        self.anim_speed_slider.setRange(1, 10)
        self.anim_speed_slider.setValue(5)
        self.anim_speed_label = QLabel("5")
        speed_layout.addWidget(self.anim_speed_slider)
        speed_layout.addWidget(self.anim_speed_label)
        anim_layout.addLayout(speed_layout)
        
        layout.addWidget(anim_group)
        layout.addStretch()

    def _setup_style_parameters(self):
        # Clear existing parameters
        for i in reversed(range(self.style_params_layout.count())):
            child = self.style_params_layout.itemAt(i).widget()
            if child:
                child.deleteLater()
        
        current_style = self.style_combo.currentText()
        
        if current_style == "Water":
            self._add_water_parameters()
        elif current_style == "Lava":
            self._add_lava_parameters()
        elif current_style == "Fire":
            self._add_fire_parameters()
        elif current_style == "Smoke":
            self._add_smoke_parameters()
        elif current_style == "Fog":
            self._add_fog_parameters()
        elif current_style == "Crystal":
            self._add_crystal_parameters()
        elif current_style == "Wind":
            self._add_wind_parameters()
        elif current_style == "Portal":
            self._add_portal_parameters()

    def _add_water_parameters(self):
        # Wave intensity
        wave_layout = QHBoxLayout()
        wave_layout.addWidget(QLabel("Wave Intensity:"))
        self.water_wave_slider = QSlider(Qt.Horizontal)
        self.water_wave_slider.setRange(1, 10)
        self.water_wave_slider.setValue(5)
        self.water_wave_label = QLabel("5")
        self.water_wave_slider.valueChanged.connect(lambda v: self.water_wave_label.setText(str(v)))
        self.water_wave_slider.valueChanged.connect(self.schedule_preview_update)
        wave_layout.addWidget(self.water_wave_slider)
        wave_layout.addWidget(self.water_wave_label)
        self.style_params_layout.addLayout(wave_layout)
        
        # Depth
        depth_layout = QHBoxLayout()
        depth_layout.addWidget(QLabel("Depth:"))
        self.water_depth_slider = QSlider(Qt.Horizontal)
        self.water_depth_slider.setRange(1, 10)
        self.water_depth_slider.setValue(5)
        self.water_depth_label = QLabel("5")
        self.water_depth_slider.valueChanged.connect(lambda v: self.water_depth_label.setText(str(v)))
        self.water_depth_slider.valueChanged.connect(self.schedule_preview_update)
        depth_layout.addWidget(self.water_depth_slider)
        depth_layout.addWidget(self.water_depth_label)
        self.style_params_layout.addLayout(depth_layout)

    def _add_lava_parameters(self):
        # Heat intensity
        heat_layout = QHBoxLayout()
        heat_layout.addWidget(QLabel("Heat Intensity:"))
        self.lava_heat_slider = QSlider(Qt.Horizontal)
        self.lava_heat_slider.setRange(1, 10)
        self.lava_heat_slider.setValue(7)
        self.lava_heat_label = QLabel("7")
        self.lava_heat_slider.valueChanged.connect(lambda v: self.lava_heat_label.setText(str(v)))
        self.lava_heat_slider.valueChanged.connect(self.schedule_preview_update)
        heat_layout.addWidget(self.lava_heat_slider)
        heat_layout.addWidget(self.lava_heat_label)
        self.style_params_layout.addLayout(heat_layout)
        
        # Bubbling
        bubble_layout = QHBoxLayout()
        bubble_layout.addWidget(QLabel("Bubbling:"))
        self.lava_bubble_slider = QSlider(Qt.Horizontal)
        self.lava_bubble_slider.setRange(1, 10)
        self.lava_bubble_slider.setValue(5)
        self.lava_bubble_label = QLabel("5")
        self.lava_bubble_slider.valueChanged.connect(lambda v: self.lava_bubble_label.setText(str(v)))
        self.lava_bubble_slider.valueChanged.connect(self.schedule_preview_update)
        bubble_layout.addWidget(self.lava_bubble_slider)
        bubble_layout.addWidget(self.lava_bubble_label)
        self.style_params_layout.addLayout(bubble_layout)

    def _add_fire_parameters(self):
        # Flame intensity
        flame_layout = QHBoxLayout()
        flame_layout.addWidget(QLabel("Flame Intensity:"))
        self.fire_flame_slider = QSlider(Qt.Horizontal)
        self.fire_flame_slider.setRange(1, 10)
        self.fire_flame_slider.setValue(8)
        self.fire_flame_label = QLabel("8")
        self.fire_flame_slider.valueChanged.connect(lambda v: self.fire_flame_label.setText(str(v)))
        self.fire_flame_slider.valueChanged.connect(self.schedule_preview_update)
        flame_layout.addWidget(self.fire_flame_slider)
        flame_layout.addWidget(self.fire_flame_label)
        self.style_params_layout.addLayout(flame_layout)
        
        # Flickering
        flicker_layout = QHBoxLayout()
        flicker_layout.addWidget(QLabel("Flickering:"))
        self.fire_flicker_slider = QSlider(Qt.Horizontal)
        self.fire_flicker_slider.setRange(1, 10)
        self.fire_flicker_slider.setValue(6)
        self.fire_flicker_label = QLabel("6")
        self.fire_flicker_slider.valueChanged.connect(lambda v: self.fire_flicker_label.setText(str(v)))
        self.fire_flicker_slider.valueChanged.connect(self.schedule_preview_update)
        flicker_layout.addWidget(self.fire_flicker_slider)
        flicker_layout.addWidget(self.fire_flicker_label)
        self.style_params_layout.addLayout(flicker_layout)

    def _add_smoke_parameters(self):
        # Density
        density_layout = QHBoxLayout()
        density_layout.addWidget(QLabel("Density:"))
        self.smoke_density_slider = QSlider(Qt.Horizontal)
        self.smoke_density_slider.setRange(1, 10)
        self.smoke_density_slider.setValue(5)
        self.smoke_density_label = QLabel("5")
        self.smoke_density_slider.valueChanged.connect(lambda v: self.smoke_density_label.setText(str(v)))
        self.smoke_density_slider.valueChanged.connect(self.schedule_preview_update)
        density_layout.addWidget(self.smoke_density_slider)
        density_layout.addWidget(self.smoke_density_label)
        self.style_params_layout.addLayout(density_layout)
        
        # Drift
        drift_layout = QHBoxLayout()
        drift_layout.addWidget(QLabel("Drift:"))
        self.smoke_drift_slider = QSlider(Qt.Horizontal)
        self.smoke_drift_slider.setRange(1, 10)
        self.smoke_drift_slider.setValue(4)
        self.smoke_drift_label = QLabel("4")
        self.smoke_drift_slider.valueChanged.connect(lambda v: self.smoke_drift_label.setText(str(v)))
        self.smoke_drift_slider.valueChanged.connect(self.schedule_preview_update)
        drift_layout.addWidget(self.smoke_drift_slider)
        drift_layout.addWidget(self.smoke_drift_label)
        self.style_params_layout.addLayout(drift_layout)

    def _add_fog_parameters(self):
        # Thickness
        thickness_layout = QHBoxLayout()
        thickness_layout.addWidget(QLabel("Thickness:"))
        self.fog_thickness_slider = QSlider(Qt.Horizontal)
        self.fog_thickness_slider.setRange(1, 10)
        self.fog_thickness_slider.setValue(6)
        self.fog_thickness_label = QLabel("6")
        self.fog_thickness_slider.valueChanged.connect(lambda v: self.fog_thickness_label.setText(str(v)))
        self.fog_thickness_slider.valueChanged.connect(self.schedule_preview_update)
        thickness_layout.addWidget(self.fog_thickness_slider)
        thickness_layout.addWidget(self.fog_thickness_label)
        self.style_params_layout.addLayout(thickness_layout)
        
        # Movement
        movement_layout = QHBoxLayout()
        movement_layout.addWidget(QLabel("Movement:"))
        self.fog_movement_slider = QSlider(Qt.Horizontal)
        self.fog_movement_slider.setRange(1, 10)
        self.fog_movement_slider.setValue(3)
        self.fog_movement_label = QLabel("3")
        self.fog_movement_slider.valueChanged.connect(lambda v: self.fog_movement_label.setText(str(v)))
        self.fog_movement_slider.valueChanged.connect(self.schedule_preview_update)
        movement_layout.addWidget(self.fog_movement_slider)
        movement_layout.addWidget(self.fog_movement_label)
        self.style_params_layout.addLayout(movement_layout)

    def _add_crystal_parameters(self):
        # Sparkle
        sparkle_layout = QHBoxLayout()
        sparkle_layout.addWidget(QLabel("Sparkle:"))
        self.crystal_sparkle_slider = QSlider(Qt.Horizontal)
        self.crystal_sparkle_slider.setRange(1, 10)
        self.crystal_sparkle_slider.setValue(7)
        self.crystal_sparkle_label = QLabel("7")
        self.crystal_sparkle_slider.valueChanged.connect(lambda v: self.crystal_sparkle_label.setText(str(v)))
        self.crystal_sparkle_slider.valueChanged.connect(self.schedule_preview_update)
        sparkle_layout.addWidget(self.crystal_sparkle_slider)
        sparkle_layout.addWidget(self.crystal_sparkle_label)
        self.style_params_layout.addLayout(sparkle_layout)
        
        # Refraction
        refraction_layout = QHBoxLayout()
        refraction_layout.addWidget(QLabel("Refraction:"))
        self.crystal_refraction_slider = QSlider(Qt.Horizontal)
        self.crystal_refraction_slider.setRange(1, 10)
        self.crystal_refraction_slider.setValue(5)
        self.crystal_refraction_label = QLabel("5")
        self.crystal_refraction_slider.valueChanged.connect(lambda v: self.crystal_refraction_label.setText(str(v)))
        self.crystal_refraction_slider.valueChanged.connect(self.schedule_preview_update)
        refraction_layout.addWidget(self.crystal_refraction_slider)
        refraction_layout.addWidget(self.crystal_refraction_label)
        self.style_params_layout.addLayout(refraction_layout)

    def _add_wind_parameters(self):
        # Strength
        strength_layout = QHBoxLayout()
        strength_layout.addWidget(QLabel("Strength:"))
        self.wind_strength_slider = QSlider(Qt.Horizontal)
        self.wind_strength_slider.setRange(1, 10)
        self.wind_strength_slider.setValue(5)
        self.wind_strength_label = QLabel("5")
        self.wind_strength_slider.valueChanged.connect(lambda v: self.wind_strength_label.setText(str(v)))
        self.wind_strength_slider.valueChanged.connect(self.schedule_preview_update)
        strength_layout.addWidget(self.wind_strength_slider)
        strength_layout.addWidget(self.wind_strength_label)
        self.style_params_layout.addLayout(strength_layout)
        
        # Direction
        direction_layout = QHBoxLayout()
        direction_layout.addWidget(QLabel("Direction:"))
        self.wind_direction_slider = QSlider(Qt.Horizontal)
        self.wind_direction_slider.setRange(0, 360)
        self.wind_direction_slider.setValue(0)
        self.wind_direction_label = QLabel("0°")
        self.wind_direction_slider.valueChanged.connect(lambda v: self.wind_direction_label.setText(f"{v}°"))
        self.wind_direction_slider.valueChanged.connect(self.schedule_preview_update)
        direction_layout.addWidget(self.wind_direction_slider)
        direction_layout.addWidget(self.wind_direction_label)
        self.style_params_layout.addLayout(direction_layout)

    def _add_portal_parameters(self):
        # Energy intensity
        energy_layout = QHBoxLayout()
        energy_layout.addWidget(QLabel("Energy Intensity:"))
        self.portal_energy_slider = QSlider(Qt.Horizontal)
        self.portal_energy_slider.setRange(1, 10)
        self.portal_energy_slider.setValue(7)
        self.portal_energy_label = QLabel("7")
        self.portal_energy_slider.valueChanged.connect(lambda v: self.portal_energy_label.setText(str(v)))
        self.portal_energy_slider.valueChanged.connect(self.schedule_preview_update)
        energy_layout.addWidget(self.portal_energy_slider)
        energy_layout.addWidget(self.portal_energy_label)
        self.style_params_layout.addLayout(energy_layout)
        
        # Distortion
        distortion_layout = QHBoxLayout()
        distortion_layout.addWidget(QLabel("Distortion:"))
        self.portal_distortion_slider = QSlider(Qt.Horizontal)
        self.portal_distortion_slider.setRange(1, 10)
        self.portal_distortion_slider.setValue(5)
        self.portal_distortion_label = QLabel("5")
        self.portal_distortion_slider.valueChanged.connect(lambda v: self.portal_distortion_label.setText(str(v)))
        self.portal_distortion_slider.valueChanged.connect(self.schedule_preview_update)
        distortion_layout.addWidget(self.portal_distortion_slider)
        distortion_layout.addWidget(self.portal_distortion_label)
        self.style_params_layout.addLayout(distortion_layout)

    def _connect_signals(self):
        # Block size
        self.block_size_spin.valueChanged.connect(self.schedule_preview_update)
        
        # Opacity
        self.opacity_slider.valueChanged.connect(self._update_opacity_label)
        self.opacity_slider.valueChanged.connect(self.schedule_preview_update)
        
        # Style
        self.style_combo.currentTextChanged.connect(self._on_style_changed)
        
        # Animation
        self.animate_checkbox.toggled.connect(self.schedule_preview_update)
        self.frame_count_spin.valueChanged.connect(self.schedule_preview_update)
        self.anim_speed_slider.valueChanged.connect(self._update_anim_speed_label)
        self.anim_speed_slider.valueChanged.connect(self.schedule_preview_update)
        
        # Buttons
        self.ok_button.clicked.connect(self.accept)
        self.cancel_button.clicked.connect(self.reject)
        
        # Initialize colors
        self.color1 = "#FF0000"
        self.color2 = "#0000FF"
        self._update_color_buttons()

    def pick_color(self, color_idx):
        color = QColorDialog.getColor()
        if color.isValid():
            hex_color = color.name()
            if color_idx == 1:
                self.color1 = hex_color
            else:
                self.color2 = hex_color
            self._update_color_buttons()
            self.schedule_preview_update()

    def _update_color_buttons(self):
        self.color1_btn.setStyleSheet(f"background-color: {self.color1}; border: 1px solid #888;")
        self.color2_btn.setStyleSheet(f"background-color: {self.color2}; border: 1px solid #888;")

    def _update_opacity_label(self):
        value = self.opacity_slider.value()
        self.opacity_label.setText(f"{value}%")

    def _update_anim_speed_label(self):
        value = self.anim_speed_slider.value()
        self.anim_speed_label.setText(str(value))

    def _on_style_changed(self):
        self._setup_style_parameters()
        self.schedule_preview_update()

    def schedule_preview_update(self):
        self.preview_timer.start(100)  # 100ms debounce

    def update_preview(self):
        try:
            # Get parameters
            block_size = self.block_size_spin.value()
            opacity = self.opacity_slider.value()
            
            # Get actual image dimensions from state
            if self.main_window and hasattr(self.main_window, 'state'):
                canvas_width = self.main_window.state.width
                canvas_height = self.main_window.state.height
            else:
                # Fallback to a reasonable size
                canvas_width = canvas_height = 32
            
            # Update canvas info label
            self.canvas_info_label.setText(f"Canvas: {canvas_width}x{canvas_height}")
            
            # Get style parameters
            style_params = {}
            current_style = self.style_combo.currentText()
            if current_style == "Water":
                style_params = {
                    'water_wave': self.water_wave_slider.value(),
                    'water_depth': self.water_depth_slider.value()
                }
            elif current_style == "Lava":
                style_params = {
                    'lava_heat': self.lava_heat_slider.value(),
                    'lava_bubble': self.lava_bubble_slider.value()
                }
            elif current_style == "Fire":
                style_params = {
                    'fire_flame': self.fire_flame_slider.value(),
                    'fire_flicker': self.fire_flicker_slider.value()
                }
            elif current_style == "Smoke":
                style_params = {
                    'smoke_density': self.smoke_density_slider.value(),
                    'smoke_drift': self.smoke_drift_slider.value()
                }
            elif current_style == "Fog":
                style_params = {
                    'fog_thickness': self.fog_thickness_slider.value(),
                    'fog_movement': self.fog_movement_slider.value()
                }
            elif current_style == "Crystal":
                style_params = {
                    'crystal_sparkle': self.crystal_sparkle_slider.value(),
                    'crystal_refraction': self.crystal_refraction_slider.value()
                }
            elif current_style == "Wind":
                style_params = {
                    'wind_strength': self.wind_strength_slider.value(),
                    'wind_direction': self.wind_direction_slider.value()
                }
            elif current_style == "Portal":
                style_params = {
                    'portal_energy': self.portal_energy_slider.value(),
                    'portal_distortion': self.portal_distortion_slider.value()
                }
            
            # Generate preview texture using actual canvas dimensions
            texture = generate_block_texture_qimage(
                canvas_width, canvas_height, 
                [self.color1, self.color2], 
                block_size, 
                int(opacity * 255 / 100),
                current_style,
                style_params,
                0      # Single frame
            )
            
            # Convert to QPixmap
            self.preview_pixmap = QPixmap.fromImage(texture)
            
            # Scale to fit preview - use pixel-perfect scaling for crisp preview
            scaled_pixmap = self.preview_pixmap.scaled(
                self.preview_canvas.size(), 
                Qt.KeepAspectRatio, 
                Qt.FastTransformation
            )
            
            self.preview_canvas.setPixmap(scaled_pixmap)
            
        except Exception as e:
            print(f"Preview update error: {e}")
            self.preview_canvas.setText("Preview Error")

    def get_parameters(self):
        """Return the current parameters as a dictionary."""
        params = {
            "color1": self.color1,
            "color2": self.color2,
            "block_size": self.block_size_spin.value(),
            "opacity": self.opacity_slider.value(),
            "style": self.style_combo.currentText(),
            "animate": self.animate_checkbox.isChecked(),
            "anim_frames": self.frame_count_spin.value(),
            "anim_speed": self.anim_speed_slider.value(),
            "area": "selection" if self.selection_radio.isChecked() else "full"
        }
        
        # Add style-specific parameters
        current_style = self.style_combo.currentText()
        if current_style == "Water":
            params.update({
                "water_wave": self.water_wave_slider.value(),
                "water_depth": self.water_depth_slider.value()
            })
        elif current_style == "Lava":
            params.update({
                "lava_heat": self.lava_heat_slider.value(),
                "lava_bubble": self.lava_bubble_slider.value()
            })
        elif current_style == "Fire":
            params.update({
                "fire_flame": self.fire_flame_slider.value(),
                "fire_flicker": self.fire_flicker_slider.value()
            })
        elif current_style == "Smoke":
            params.update({
                "smoke_density": self.smoke_density_slider.value(),
                "smoke_drift": self.smoke_drift_slider.value()
            })
        elif current_style == "Fog":
            params.update({
                "fog_thickness": self.fog_thickness_slider.value(),
                "fog_movement": self.fog_movement_slider.value()
            })
        elif current_style == "Crystal":
            params.update({
                "crystal_sparkle": self.crystal_sparkle_slider.value(),
                "crystal_refraction": self.crystal_refraction_slider.value()
            })
        elif current_style == "Wind":
            params.update({
                "wind_strength": self.wind_strength_slider.value(),
                "wind_direction": self.wind_direction_slider.value()
            })
        elif current_style == "Portal":
            params.update({
                "portal_energy": self.portal_energy_slider.value(),
                "portal_distortion": self.portal_distortion_slider.value()
            })
        
        return params 