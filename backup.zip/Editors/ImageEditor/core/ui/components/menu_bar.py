"""
Menu Bar Component for Image Editor
Extracted from main_window.py for better modularity
"""

from PySide6.QtWidgets import QMenuBar
from PySide6.QtGui import QKeySequence
from core.settings import settings


class ImageEditorMenuBar:
    """Creates and configures the menu bar for the Image Editor"""
    
    def __init__(self, main_window):
        """
        Initialize menu bar for the given main window
        
        Args:
            main_window: MainWindow instance that will receive the menu bar
        """
        self.main_window = main_window
        self.menubar = None
        self.pixel_perfect_action = None
    
    def create_menu_bar(self):
        """Create and configure the menu bar"""
        self.menubar = QMenuBar(self.main_window)
        
        self._create_file_menu()
        self._create_edit_menu()
        self._create_view_menu()
        self._create_frame_menu()
        self._create_effects_menu()
        self._create_ai_menu()
        
        return self.menubar
    
    def _create_file_menu(self):
        """Create File menu"""
        file_menu = self.menubar.addMenu("File")
        
        # New action
        new_action = file_menu.addAction("New...")
        new_action.setShortcut("Ctrl+N")
        new_action.triggered.connect(self.main_window.new_canvas)
        
        file_menu.addSeparator()
        
        # Import submenu
        import_menu = file_menu.addMenu("Import")
        import_image_action = import_menu.addAction("Image...")
        import_image_action.triggered.connect(self.main_window.import_image)
        import_gif_action = import_menu.addAction("GIF...")
        import_gif_action.triggered.connect(self.main_window.import_gif)
        import_pgsprite_action = import_menu.addAction(".PgSprite...")
        import_pgsprite_action.triggered.connect(self.main_window.import_pgsprite)
        import_menu.addSeparator()
        import_sprite_sheet_action = import_menu.addAction("Sprite Sheet...")
        import_sprite_sheet_action.triggered.connect(self.main_window.import_sprite_sheet)
        
        # Export submenu
        export_menu = file_menu.addMenu("Export")
        export_image_action = export_menu.addAction("Image...")
        export_image_action.triggered.connect(self.main_window.export_image)
        export_gif_action = export_menu.addAction("GIF...")
        export_gif_action.triggered.connect(self.main_window.export_gif)
        export_pgsprite_action = export_menu.addAction(".PgSprite...")
        export_pgsprite_action.triggered.connect(self.main_window.export_pgsprite)
    
    def _create_edit_menu(self):
        """Create Edit menu"""
        edit_menu = self.menubar.addMenu("Edit")
        
        # Undo/Redo
        undo_action = edit_menu.addAction("Undo")
        undo_action.triggered.connect(self.main_window.undo)
        
        redo_action = edit_menu.addAction("Redo")
        redo_action.triggered.connect(self.main_window.redo)
        
        # Cut/Copy/Paste
        cut_action = edit_menu.addAction("Cut")
        cut_action.triggered.connect(self.main_window.canvas.cut_selection)
        
        copy_action = edit_menu.addAction("Copy")
        copy_action.triggered.connect(self.main_window.canvas.copy_selection)
        
        paste_action = edit_menu.addAction("Paste")
        paste_action.triggered.connect(self.main_window.canvas.paste_selection)
        
        edit_menu.addSeparator()
        crop_action = edit_menu.addAction("Crop...")
        crop_action.triggered.connect(self.main_window.crop_canvas)
        remove_blank_space_action = edit_menu.addAction("Remove Blank Space...")
        remove_blank_space_action.triggered.connect(self.main_window.remove_blank_space)
        edit_menu.addSeparator()
        preferences_action = edit_menu.addAction("Preferences...")
        preferences_action.triggered.connect(self.main_window.show_preferences_dialog)
    
    def _create_view_menu(self):
        """Create View menu"""
        view_menu = self.menubar.addMenu("View")
        composite_action = view_menu.addAction("Toggle Composite View")
        composite_action.setShortcut("Ctrl+Shift+C")
        composite_action.triggered.connect(self.main_window.toggle_composite_view)
        timeline_action = view_menu.addAction("Toggle Timeline")
        timeline_action.setShortcut("Ctrl+Shift+T")
        timeline_action.triggered.connect(self.main_window.toggle_timeline)
        view_menu.addSeparator()
        
        # Pixel-perfect filtering toggle (only for GPU canvas)
        self.pixel_perfect_action = view_menu.addAction("Pixel-Perfect Filtering")
        self.pixel_perfect_action.setCheckable(True)
        self.pixel_perfect_action.setChecked(settings.pixel_perfect_filtering)
        self.pixel_perfect_action.triggered.connect(self.main_window.toggle_pixel_perfect)
        # Disable if not using GPU canvas
        if not settings.use_gpu_canvas:
            self.pixel_perfect_action.setEnabled(False)
    
    def _create_frame_menu(self):
        """Create Frame menu"""
        frame_menu = self.menubar.addMenu("Frame")
        flip_h_action = frame_menu.addAction("Flip Frame Horizontal")
        flip_h_action.triggered.connect(self.main_window.flip_frame_horizontal)
        flip_v_action = frame_menu.addAction("Flip Frame Vertical")
        flip_v_action.triggered.connect(self.main_window.flip_frame_vertical)
        frame_menu.addSeparator()
        rotate_90_action = frame_menu.addAction("Rotate Frame 90°")
        rotate_90_action.triggered.connect(self.main_window.rotate_frame_90)
        rotate_180_action = frame_menu.addAction("Rotate Frame 180°")
        rotate_180_action.triggered.connect(self.main_window.rotate_frame_180)
        frame_menu.addSeparator()
        duplicate_frame_action = frame_menu.addAction("Duplicate Frame")
        duplicate_frame_action.triggered.connect(self.main_window.duplicate_frame)
        frame_menu.addSeparator()
        clear_frame_action = frame_menu.addAction("Clear Frame")
        clear_frame_action.triggered.connect(self.main_window.clear_frame)
    
    def _create_effects_menu(self):
        """Create Effects menu with all submenus"""
        effects_menu = self.menubar.addMenu("Effects")
        
        # --- Colour ---
        color_menu = effects_menu.addMenu("Colour")
        color_menu.addAction("Invert Colors").triggered.connect(self.main_window.effect_invert)
        color_menu.addAction("Greyscale").triggered.connect(self.main_window.effect_greyscale)
        color_menu.addAction("Fade").triggered.connect(self.main_window.effect_fade)
        color_menu.addAction("Opacity").triggered.connect(self.main_window.effect_opacity)
        color_menu.addAction("Saturation").triggered.connect(self.main_window.effect_saturation)
        color_menu.addAction("Colorize").triggered.connect(self.main_window.effect_colorize)
        color_menu.addAction("Posterize").triggered.connect(self.main_window.effect_posterize)
        
        # --- Filter ---
        filter_menu = effects_menu.addMenu("Filter")
        filter_menu.addAction("Brightness").triggered.connect(self.main_window.effect_brightness)
        filter_menu.addAction("Contrast").triggered.connect(self.main_window.effect_contrast)
        filter_menu.addSeparator()
        filter_menu.addAction("Blur").triggered.connect(self.main_window.effect_blur)
        filter_menu.addAction("Sharpen").triggered.connect(self.main_window.effect_sharpen)
        filter_menu.addAction("Motion Blur").triggered.connect(self.main_window.effect_motion_blur)
        filter_menu.addSeparator()
        filter_menu.addAction("Noise").triggered.connect(self.main_window.effect_noise)
        filter_menu.addAction("Pixelate").triggered.connect(self.main_window.effect_pixelate)
        filter_menu.addAction("Dither").triggered.connect(self.main_window.effect_dither)
        filter_menu.addSeparator()
        filter_menu.addAction("Emboss").triggered.connect(self.main_window.effect_emboss)
        filter_menu.addAction("Edge Detection").triggered.connect(self.main_window.effect_edge_detection)
        filter_menu.addAction("Oil Painting").triggered.connect(self.main_window.effect_oil_painting)
        filter_menu.addSeparator()
        filter_menu.addAction("Glow").triggered.connect(self.main_window.effect_glow)
        filter_menu.addAction("Vignette").triggered.connect(self.main_window.effect_vignette)
        filter_menu.addAction("Solarize").triggered.connect(self.main_window.effect_solarize)
        filter_menu.addSeparator()
        filter_menu.addAction("⭐ Image Enhancement").triggered.connect(self.main_window.effect_image_enhancement)
        filter_menu.addSeparator()
        filter_menu.addAction("Shader Bloom FX").triggered.connect(self.main_window.effect_shader_bloom)
        filter_menu.addAction("Palette Cycler").triggered.connect(self.main_window.effect_palette_cycler)
        filter_menu.addAction("Pixel Depth Mapper").triggered.connect(self.main_window.effect_pixel_depth)
        
        # --- Lighting ---
        lighting_menu = effects_menu.addMenu("Lighting")
        lighting_menu.addAction("Atmospheric Lighting").triggered.connect(self.main_window.effect_atmospheric_lighting)
        lighting_menu.addAction("Normal/Specular Map").triggered.connect(self.main_window.effect_normal_map)
        lighting_menu.addAction("Light Overlay").triggered.connect(self.main_window.effect_light_overlay)
        
        # --- Reshade ---
        reshade_menu = effects_menu.addMenu("Reshade")
        
        # Gaming submenu
        gaming_menu = reshade_menu.addMenu("Gaming")
        gaming_menu.addAction("Voxelize").triggered.connect(self.main_window.effect_voxelize)
        gaming_menu.addAction("Dream Diffuse").triggered.connect(self.main_window.effect_dream_diffuse)
        gaming_menu.addAction("VHS").triggered.connect(self.main_window.effect_vhs)
        gaming_menu.addAction("Posterizer").triggered.connect(self.main_window.effect_posterizer)
        
        # Visual Style submenu
        visual_style_menu = reshade_menu.addMenu("Visual Style")
        
        # Gamecube submenu
        gamecube_menu = visual_style_menu.addMenu("Gamecube")
        gamecube_menu.addAction("WindWaker").triggered.connect(self.main_window.effect_wind_waker)
        gamecube_menu.addAction("Ocarina of Time").triggered.connect(self.main_window.effect_ocarina_of_time)
        gamecube_menu.addAction("Luigi's Mansion").triggered.connect(self.main_window.effect_luigis_mansion)
        gamecube_menu.addAction("Eternal Darkness").triggered.connect(self.main_window.effect_eternal_darkness)
        gamecube_menu.addAction("Pokémon Colosseum").triggered.connect(self.main_window.effect_pokemon_colosseum)
        
        # Modern Nintendo submenu
        modern_nintendo_menu = visual_style_menu.addMenu("Modern Nintendo")
        modern_nintendo_menu.addAction("Mario Kart 8").triggered.connect(self.main_window.effect_mario_kart_8)
        
        # --- Generation ---
        generation_menu = effects_menu.addMenu("Generation")
        generation_menu.addAction("2D Map Generator").triggered.connect(self.main_window.effect_map_generator)
        generation_menu.addSeparator()
        texture_menu = generation_menu.addMenu("Texture Creation")
        texture_menu.addAction("2D Texture Creation").triggered.connect(self.main_window.effect_texture_2d)
        texture_menu.addAction("Advanced Atlas Editor").triggered.connect(self.main_window.open_advanced_atlas_dialog)
        generation_menu.addSeparator()
        generation_menu.addAction("Nine-Slice").triggered.connect(self.main_window.nine_slice_import)
        generation_menu.addAction("🎭 Character Creation").triggered.connect(self.main_window.open_character_creator)
        
        # --- Tools ---
        tools_menu = effects_menu.addMenu("Tools")
        tools_menu.addAction("Generate LOD").triggered.connect(self.main_window.effect_generate_lod)
        tools_menu.addSeparator()
        tools_menu.addAction("Mirror/Flip...").triggered.connect(self.main_window.effect_mirror_flip)
        tools_menu.addAction("Rotate...").triggered.connect(self.main_window.effect_rotate)
        tools_menu.addAction("Resize Selection...").triggered.connect(self.main_window.resize_selection_dialog)
        tools_menu.addSeparator()
        tools_menu.addAction("Separate to Layer...").triggered.connect(self.main_window.separate_selection_to_layer)
        tools_menu.addAction("Generate Tween...").triggered.connect(self.main_window.generate_tween_animation)
    
    def _create_ai_menu(self):
        """Create AI menu"""
        ai_menu = self.menubar.addMenu("AI")
        
        # Single AI Assistant option - opens unified dialog
        ai_assistant_action = ai_menu.addAction("AI Assistant...")
        ai_assistant_action.triggered.connect(self.main_window.ai_assistant)
        
        # Keep offline AI options separate (they don't use cloud AI)
        ai_menu.addSeparator()
        background_removal_ai_action = ai_menu.addAction("Background Removal (Offline AI)...")
        background_removal_ai_action.triggered.connect(self.main_window.ai_background_removal)
        background_removal_ai_action.setToolTip("Uses U²-Net model (offline, free, ~180 MB download on first use)")
        object_removal_ai_action = ai_menu.addAction("Object Removal (Offline AI)...")
        object_removal_ai_action.triggered.connect(self.main_window.ai_object_removal)
        object_removal_ai_action.setToolTip("Uses PatchMatch inpainting (offline, free)")
    
    def setup_shortcuts(self):
        """Setup keyboard shortcuts for tools and common actions"""
        from PySide6.QtGui import QKeySequence, QShortcut
        
        # Tool shortcuts - organized by category
        shortcuts = {
            # === BRUSHES ===
            'B': 'brush',           # Brush
            'P': 'pencil',          # Pencil
            'M': 'marker',          # Marker
            'C': 'calligraphy',     # Calligraphy
            'A': 'airbrush',        # Airbrush
            'L': 'line',            # Line
            
            # === TOOLS ===
            'E': 'eraser',          # Eraser
            'F': 'fill',            # Fill
            'I': 'eyedropper',      # Eyedropper
            'D': 'dither',          # Dither
            'G': 'gradient',        # Gradient
            
            # === SHAPES ===
            'R': 'rect',            # Rectangle
            'O': 'ellipse',         # Ellipse (O for Oval)
            'S': 'star',            # Star
            'Y': 'polygon',         # Polygon (Y for shape)
            
            # === SELECTIONS ===
            'V': 'region',          # Region select
            'W': 'magic_wand',      # Magic Wand
            'X': 'spray',           # Spray select
            
            # === EDITING ===
            'Delete': 'clear_selection',    # Clear selection
            
            # === FRAME CONTROL ===
            'Space': 'toggle_play',         # Play/Pause
            'Left': 'prev_frame',           # Previous frame
            'Right': 'next_frame',          # Next frame
            
            # === BRUSH SIZE ===
            '[': 'decrease_radius',         # Decrease brush size
            ']': 'increase_radius',         # Increase brush size
            '1': 'radius_1',               # Brush size 1
            '2': 'radius_2',               # Brush size 2
            '3': 'radius_3',               # Brush size 3
            '4': 'radius_4',               # Brush size 4
            '5': 'radius_5',               # Brush size 5
            '6': 'radius_6',               # Brush size 6
            '7': 'radius_7',               # Brush size 7
            '8': 'radius_8',               # Brush size 8
            '9': 'radius_9',               # Brush size 9
            '0': 'radius_10',              # Brush size 10
            
            # === ZOOM ===
            'Ctrl+Plus': 'zoom_in',        # Zoom in
            'Ctrl+Minus': 'zoom_out',      # Zoom out
            'Ctrl+0': 'zoom_reset',        # Reset zoom
            
            # === ADDITIONAL USEFUL SHORTCUTS ===
            'Ctrl+S': 'save',              # Save
            'Ctrl+O': 'open',              # Open
            'Ctrl+N': 'new',               # New
            'Ctrl+A': 'select_all',        # Select All
            'Escape': 'clear_selection',   # Clear selection (alternative)
            'Tab': 'toggle_panels',        # Toggle panels
        }
        
        self.main_window.shortcuts = {}
        for key, action in shortcuts.items():
            shortcut = QShortcut(QKeySequence(key), self.main_window)
            shortcut.activated.connect(lambda checked, a=action: self.main_window._handle_shortcut(a))
            self.main_window.shortcuts[action] = shortcut

