"""
Status Bar Component for Image Editor
Extracted from main_window.py for better modularity
"""

from PySide6.QtWidgets import QStatusBar, QLabel
from PySide6.QtCore import Signal


class ImageEditorStatusBar:
    """Creates and configures the status bar for the Image Editor"""
    
    def __init__(self, main_window):
        """
        Initialize status bar for the given main window
        
        Args:
            main_window: MainWindow instance that will receive the status bar
        """
        self.main_window = main_window
        self.status_bar = None
        self.tool_status = None
        self.position_status = None
        self.size_status = None
        self.zoom_status = None
    
    def create_status_bar(self):
        """Create and configure the status bar"""
        self.status_bar = self.main_window.statusBar()
        self.status_bar.setStyleSheet("background: #2d2d30; color: #cccccc; border-top: 1px solid #3e3e42;")
        
        # Create status labels
        self.tool_status = QLabel("Tool: Brush")
        self.position_status = QLabel("Position: 0, 0")
        self.size_status = QLabel("Size: 256x256")
        self.zoom_status = QLabel("Zoom: 100%")
        
        # Add to status bar
        self.status_bar.addWidget(self.tool_status)
        self.status_bar.addPermanentWidget(self.position_status)
        self.status_bar.addPermanentWidget(self.size_status)
        self.status_bar.addPermanentWidget(self.zoom_status)
        
        # Connect canvas mouse events to update position
        if hasattr(self.main_window, 'canvas') and self.main_window.canvas:
            if hasattr(self.main_window.canvas, 'mouse_position_changed'):
                self.main_window.canvas.mouse_position_changed.connect(self._update_position_status)
        
        return self.status_bar
    
    def _update_position_status(self, x, y):
        """Update position status when mouse moves over canvas"""
        if self.position_status:
            self.position_status.setText(f"Position: {x}, {y}")
    
    def update_tool(self, tool_name):
        """Update tool display in status bar"""
        if self.tool_status:
            self.tool_status.setText(f"Tool: {tool_name}")
    
    def update_size(self, width, height):
        """Update size display in status bar"""
        if self.size_status:
            self.size_status.setText(f"Size: {width}x{height}")
    
    def update_zoom(self, zoom_percent):
        """Update zoom display in status bar"""
        if self.zoom_status:
            self.zoom_status.setText(f"Zoom: {zoom_percent}%")

