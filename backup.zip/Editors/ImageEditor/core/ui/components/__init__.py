"""
UI Components for Image Editor
Reusable UI components extracted from main_window.py
"""


