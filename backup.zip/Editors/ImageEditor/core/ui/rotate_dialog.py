from PySide6.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, 
                               QRadioButton, QButtonGroup, QSlider, QSpinBox,
                               QDialogButtonBox, QWidget)
from PySide6.QtCore import Qt, Signal, QTimer
from PySide6.QtGui import QPixmap, QPainter, QPen, QBrush, QColor, QTransform, QImage
from PIL import Image
import numpy as np

class CheckerboardPreviewWidget(QLabel):
    """Preview widget with checkerboard background."""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumSize(300, 300)
        self.setAlignment(Qt.AlignCenter)
        self.setText("Preview")
        self.setStyleSheet("border: 1px solid #888;")
        self.preview_pixmap = None
        
    def setPixmap(self, pixmap):
        """Override setPixmap to store the pixmap and trigger repaint."""
        self.preview_pixmap = pixmap
        self.update()
        
    def paintEvent(self, event):
        """Override paint event to draw checkerboard background and preview image."""
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        
        # Get widget size
        width = self.width()
        height = self.height()
        
        # Draw checkerboard pattern
        checker_size = 8
        color1 = QColor(40, 40, 40)
        color2 = QColor(60, 60, 60)
        
        for y in range(0, height, checker_size):
            for x in range(0, width, checker_size):
                if (x // checker_size + y // checker_size) % 2 == 0:
                    painter.fillRect(x, y, checker_size, checker_size, color1)
                else:
                    painter.fillRect(x, y, checker_size, checker_size, color2)
        
        # Draw the preview image if available
        if self.preview_pixmap is not None:
            pixmap_rect = self.preview_pixmap.rect()
            widget_rect = self.rect()
            
            # Scale to fit while maintaining aspect ratio
            scaled_pixmap = self.preview_pixmap.scaled(
                widget_rect.size(), 
                Qt.KeepAspectRatio, 
                Qt.SmoothTransformation
            )
            
            # Center the scaled pixmap
            x = (widget_rect.width() - scaled_pixmap.width()) // 2
            y = (widget_rect.height() - scaled_pixmap.height()) // 2
            
            painter.drawPixmap(x, y, scaled_pixmap)
        else:
            # Draw text if no pixmap
            painter.setPen(QColor(200, 200, 200))
            painter.drawText(self.rect(), Qt.AlignCenter, self.text())

class RotateDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.parent_window = parent
        self.setWindowTitle("Rotate")
        self.setModal(True)
        self.resize(500, 450)
        
        # Store current image for preview
        self.current_image = None
        self._load_current_image()
        
        # Preview update timer for debouncing
        self.preview_timer = QTimer()
        self.preview_timer.setSingleShot(True)
        self.preview_timer.timeout.connect(self.update_preview)
        
        self.setup_ui()
        
        # Initial preview
        self.update_preview()
        
    def _load_current_image(self):
        """Load the current image from the editor."""
        try:
            from core.state import state
            lm = state.layer_manager
            layer = lm.get_current_layer()
            if layer is None:
                return
            
            frame_idx = lm.current_frame
            if frame_idx >= len(layer.frames):
                return
            
            frame = layer.get_frame(frame_idx)
            if frame.image is not None:
                # Convert PIL Image to numpy array for preview
                if isinstance(frame.image, Image.Image):
                    img_array = np.array(frame.image)
                    # Ensure we have a copy that's contiguous
                    self.current_image = np.ascontiguousarray(img_array.copy())
                else:
                    # Already a numpy array - make a contiguous copy
                    self.current_image = np.ascontiguousarray(frame.image.copy())
        except Exception as e:
            print(f"Error loading current image: {e}")
    
    def setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setSpacing(10)
        
        # Preview area (larger, more prominent)
        self.preview_label = CheckerboardPreviewWidget(self)
        layout.addWidget(self.preview_label)
        
        # Preset buttons (compact horizontal layout)
        preset_layout = QHBoxLayout()
        preset_layout.setSpacing(5)
        
        self.preset_group = QButtonGroup()
        
        presets = [
            ("90°", 90),
            ("180°", 180),
            ("270°", 270),
            ("-90°", -90),
            ("-270°", -270),
        ]
        
        for text, angle in presets:
            btn = QRadioButton(text)
            self.preset_group.addButton(btn, angle)
            preset_layout.addWidget(btn)
        
        # Custom angle option
        self.custom_rb = QRadioButton("Custom")
        self.preset_group.addButton(self.custom_rb, 999)  # Use unique ID
        preset_layout.addWidget(self.custom_rb)
        preset_layout.addStretch()
        
        layout.addLayout(preset_layout)
        
        # Custom angle controls (only shown when Custom is selected)
        angle_layout = QHBoxLayout()
        angle_layout.addWidget(QLabel("Angle:"))
        
        self.angle_slider = QSlider(Qt.Horizontal)
        self.angle_slider.setRange(-360, 360)
        self.angle_slider.setValue(0)
        self.angle_slider.setTickPosition(QSlider.TicksBelow)
        self.angle_slider.setTickInterval(90)
        angle_layout.addWidget(self.angle_slider)
        
        self.angle_spinbox = QSpinBox()
        self.angle_spinbox.setRange(-360, 360)
        self.angle_spinbox.setValue(0)
        self.angle_spinbox.setSuffix("°")
        self.angle_spinbox.setFixedWidth(80)
        angle_layout.addWidget(self.angle_spinbox)
        
        layout.addLayout(angle_layout)
        
        # Connect signals
        self.preset_group.buttonClicked.connect(self._on_preset_changed)
        self.angle_slider.valueChanged.connect(self.angle_spinbox.setValue)
        self.angle_slider.valueChanged.connect(self._on_angle_changed)
        self.angle_spinbox.valueChanged.connect(self._on_angle_changed)
        self.custom_rb.toggled.connect(self._on_custom_toggled)
        
        # Buttons
        button_box = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        button_box.accepted.connect(self.accept)
        button_box.rejected.connect(self.reject)
        layout.addWidget(button_box)
        
    def _on_preset_changed(self, button):
        """Handle preset button selection."""
        angle_id = self.preset_group.id(button)
        if angle_id != 999:  # Not custom
            # Block signals temporarily to avoid recursion
            self.angle_slider.blockSignals(True)
            self.angle_spinbox.blockSignals(True)
            
            self.angle_slider.setValue(angle_id)
            self.angle_spinbox.setValue(angle_id)
            
            self.angle_slider.blockSignals(False)
            self.angle_spinbox.blockSignals(False)
            
            self.update_preview()
        else:
            # Custom selected - ensure controls are enabled
            self.angle_slider.setEnabled(True)
            self.angle_spinbox.setEnabled(True)
    
    def _on_angle_changed(self, value):
        """Handle angle control change."""
        # When user manually changes angle, switch to custom mode
        if not self.custom_rb.isChecked():
            self.custom_rb.setChecked(True)
        
        # Debounce preview updates
        self.preview_timer.stop()
        self.preview_timer.start(50)  # Update after 50ms delay
    
    def _on_custom_toggled(self, checked):
        """Handle custom radio button toggle."""
        # Controls are always enabled, but this ensures they work when toggled
        pass
    
    def update_preview(self):
        """Update the preview with the actual image rotated."""
        if self.current_image is None:
            self.preview_label.setText("No image")
            return
        
        try:
            angle = self.get_angle()
            
            # Convert numpy array to PIL Image
            if len(self.current_image.shape) == 3 and self.current_image.shape[2] == 4:
                # RGBA
                pil_img = Image.fromarray(self.current_image, 'RGBA')
            elif len(self.current_image.shape) == 3:
                # RGB
                pil_img = Image.fromarray(self.current_image, 'RGB')
            else:
                # Grayscale
                pil_img = Image.fromarray(self.current_image, 'L')
            
            # Apply rotation
            if angle != 0:
                rotated_img = pil_img.rotate(-angle, expand=True, resample=Image.BICUBIC)
            else:
                rotated_img = pil_img
            
            # Convert back to numpy for display
            rotated_array = np.array(rotated_img)
            
            # Convert to QPixmap - ensure array is contiguous
            rotated_array = np.ascontiguousarray(rotated_array)
            
            if len(rotated_array.shape) == 2:
                # Grayscale - convert to RGB
                height, width = rotated_array.shape
                q_image = QImage(rotated_array.data, width, height, width, QImage.Format_Grayscale8)
            elif len(rotated_array.shape) == 3:
                height, width = rotated_array.shape[:2]
                if rotated_array.shape[2] == 4:
                    # RGBA
                    bytes_per_line = width * 4
                    q_image = QImage(rotated_array.data, width, height, bytes_per_line, QImage.Format_RGBA8888)
                else:
                    # RGB
                    bytes_per_line = width * 3
                    q_image = QImage(rotated_array.data, width, height, bytes_per_line, QImage.Format_RGB888)
            else:
                self.preview_label.setText("Invalid image format")
                return
            
            pixmap = QPixmap.fromImage(q_image)
            self.preview_label.setPixmap(pixmap)
            
        except Exception as e:
            import traceback
            traceback.print_exc()
            self.preview_label.setText(f"Preview Error: {str(e)}")
    
    def get_angle(self):
        """Get the current angle based on selection."""
        checked_id = self.preset_group.checkedId()
        if checked_id != 999:  # A preset is selected
            return checked_id
        else:
            # Custom angle
            return self.angle_spinbox.value()
        
    def get_parameters(self):
        """Get the selected parameters."""
        angle = self.get_angle()
        return {'angle': angle}