"""
AI Generation Dialogs for Gemini Integration
Includes base image generation, animation creation, and JSON editing
"""

from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QLineEdit,
    QSlider, QSpinBox, QComboBox, QTextEdit, QGroupBox, QFormLayout,
    QDialogButtonBox, QProgressBar, QCheckBox, QTabWidget, QWidget,
    QMessageBox, QTreeWidget, QTreeWidgetItem, QSplitter, QRadioButton,
    QButtonGroup, QScrollArea, QFrame
)
from PySide6.QtCore import Qt, Signal, QThread, QTimer
from PySide6.QtGui import QColor, QPainter, QPen, QBrush, QPixmap, QImage
import json
import numpy as np
from PIL import Image
import io
import base64
from typing import Optional, List, Dict, Any


class AIProgressDialog(QDialog):
    """Progress dialog for AI operations with cancel support."""
    
    progress_updated = Signal(str, int)  # message, percentage
    operation_complete = Signal(object)  # result data
    operation_failed = Signal(str)  # error message
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("AI Generation Progress")
        self.setModal(True)
        self.setMinimumWidth(400)
        
        layout = QVBoxLayout(self)
        
        self.status_label = QLabel("Initializing...")
        layout.addWidget(self.status_label)
        
        self.progress_bar = QProgressBar()
        self.progress_bar.setRange(0, 100)
        layout.addWidget(self.progress_bar)
        
        self.cancel_button = QPushButton("Cancel")
        self.cancel_button.clicked.connect(self.reject)
        layout.addWidget(self.cancel_button)
        
        self.worker_thread = None
        self.result = None
    
    def set_status(self, message: str, percentage: int = 0):
        """Update progress status."""
        self.status_label.setText(message)
        self.progress_bar.setValue(percentage)
    
    def set_worker_thread(self, thread: QThread):
        """Set the worker thread and connect signals."""
        self.worker_thread = thread
        thread.progress_updated.connect(self.set_status)
        thread.finished.connect(self.on_thread_finished)
        thread.error_occurred.connect(self.on_thread_error)
    
    def on_thread_finished(self):
        """Handle thread completion."""
        if self.worker_thread and hasattr(self.worker_thread, 'result'):
            self.result = self.worker_thread.result
            self.accept()
        else:
            self.reject()
    
    def on_thread_error(self, error_message: str):
        """Handle thread error."""
        QMessageBox.critical(self, "AI Generation Error", error_message)
        self.reject()


class AIBaseImageDialog(QDialog):
    """Dialog for generating base sprite image."""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("AI: Generate Base Sprite")
        self.setMinimumWidth(500)
        
        layout = QVBoxLayout(self)
        
        # Prompt input
        prompt_group = QGroupBox("Sprite Description")
        prompt_layout = QVBoxLayout()
        self.prompt_edit = QTextEdit()
        self.prompt_edit.setPlaceholderText("Describe the sprite you want to create...\nExample: 'A red dragon, pixel art style, facing right'")
        self.prompt_edit.setMaximumHeight(100)
        prompt_layout.addWidget(self.prompt_edit)
        prompt_group.setLayout(prompt_layout)
        layout.addWidget(prompt_group)
        
        # Theme and detail
        params_group = QGroupBox("Generation Parameters")
        params_layout = QFormLayout()
        
        self.theme_combo = QComboBox()
        self.theme_combo.addItems([
            "Medieval Fantasy", "Cyberpunk", "Sci-Fi", "Cartoon", 
            "Realistic", "Anime", "Retro", "Steampunk", "Horror"
        ])
        params_layout.addRow("Theme:", self.theme_combo)
        
        self.detail_slider = QSlider(Qt.Horizontal)
        self.detail_slider.setMinimum(1)
        self.detail_slider.setMaximum(10)
        self.detail_slider.setValue(7)
        self.detail_label = QLabel("7")
        detail_layout = QHBoxLayout()
        detail_layout.addWidget(self.detail_slider)
        detail_layout.addWidget(self.detail_label)
        self.detail_slider.valueChanged.connect(lambda v: self.detail_label.setText(str(v)))
        params_layout.addRow("Detail Level:", detail_layout)
        
        # Size
        size_layout = QHBoxLayout()
        self.width_spin = QSpinBox()
        self.width_spin.setMinimum(16)
        self.width_spin.setMaximum(512)
        self.width_spin.setValue(64)
        self.height_spin = QSpinBox()
        self.height_spin.setMinimum(16)
        self.height_spin.setMaximum(512)
        self.height_spin.setValue(64)
        size_layout.addWidget(QLabel("Width:"))
        size_layout.addWidget(self.width_spin)
        size_layout.addWidget(QLabel("Height:"))
        size_layout.addWidget(self.height_spin)
        params_layout.addRow("Size:", size_layout)
        
        params_group.setLayout(params_layout)
        layout.addWidget(params_group)
        
        # Options
        options_group = QGroupBox("Options")
        options_layout = QVBoxLayout()
        self.use_cache_checkbox = QCheckBox("Use Cache (faster, reuses previous results)")
        self.use_cache_checkbox.setChecked(True)
        options_layout.addWidget(self.use_cache_checkbox)
        options_group.setLayout(options_layout)
        layout.addWidget(options_group)
        
        # Buttons
        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)
    
    def get_parameters(self) -> dict:
        """Get dialog parameters."""
        return {
            'prompt': self.prompt_edit.toPlainText(),
            'theme': self.theme_combo.currentText(),
            'detail': self.detail_slider.value(),
            'size': (self.width_spin.value(), self.height_spin.value()),
            'use_cache': self.use_cache_checkbox.isChecked()
        }


class AIAnimationDialog(QDialog):
    """Dialog for generating animated sprite from base image."""
    
    def __init__(self, parent=None, base_image: np.ndarray = None):
        super().__init__(parent)
        self.setWindowTitle("AI: Generate Animation")
        self.setMinimumWidth(600)
        self.base_image = base_image
        
        layout = QVBoxLayout(self)
        
        # Animation type
        anim_group = QGroupBox("Animation Settings")
        anim_layout = QFormLayout()
        
        self.animation_type_combo = QComboBox()
        self.animation_type_combo.addItems([
            "walk_cycle", "run_cycle", "jump", "idle", "attack", 
            "wave", "dance", "fly", "swim", "custom"
        ])
        anim_layout.addRow("Animation Type:", self.animation_type_combo)
        
        self.frame_count_spin = QSpinBox()
        self.frame_count_spin.setMinimum(2)
        self.frame_count_spin.setMaximum(30)
        self.frame_count_spin.setValue(8)
        anim_layout.addRow("Number of Frames:", self.frame_count_spin)
        
        anim_group.setLayout(anim_layout)
        layout.addWidget(anim_group)
        
        # Generation mode
        mode_group = QGroupBox("Generation Mode")
        mode_layout = QVBoxLayout()
        
        self.mode_combo = QComboBox()
        self.mode_combo.addItems([
            "Base + Changes (Recommended)",
            "Cumulative Changes (Smooth Motion)"
        ])
        mode_layout.addWidget(self.mode_combo)
        
        mode_info = QLabel(
            "Base + Changes: Each frame copies base and applies only changes.\n"
            "Cumulative: Each frame builds on previous frame (smoother transitions)."
        )
        mode_info.setWordWrap(True)
        mode_info.setStyleSheet("color: #888; font-size: 10px;")
        mode_layout.addWidget(mode_info)
        mode_group.setLayout(mode_layout)
        layout.addWidget(mode_group)
        
        # Options
        options_group = QGroupBox("Options")
        options_layout = QVBoxLayout()
        
        self.refine_checkbox = QCheckBox("Two-Pass Refinement (improves smoothness)")
        self.refine_checkbox.setChecked(True)
        options_layout.addWidget(self.refine_checkbox)
        
        self.validate_diffs_checkbox = QCheckBox("Validate Frame Differences (skip redundant changes)")
        self.validate_diffs_checkbox.setChecked(True)
        options_layout.addWidget(self.validate_diffs_checkbox)
        
        self.use_cache_checkbox = QCheckBox("Use Cache")
        self.use_cache_checkbox.setChecked(True)
        options_layout.addWidget(self.use_cache_checkbox)
        
        options_group.setLayout(options_layout)
        layout.addWidget(options_group)
        
        # Buttons
        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)
    
    def get_parameters(self) -> dict:
        """Get dialog parameters."""
        return {
            'animation_type': self.animation_type_combo.currentText(),
            'frame_count': self.frame_count_spin.value(),
            'mode': 'base_changes' if self.mode_combo.currentIndex() == 0 else 'cumulative',
            'refine': self.refine_checkbox.isChecked(),
            'validate_diffs': self.validate_diffs_checkbox.isChecked(),
            'use_cache': self.use_cache_checkbox.isChecked()
        }


class AIJSONEditorDialog(QDialog):
    """Dialog for viewing and editing AI-generated JSON instructions."""
    
    def __init__(self, parent=None, json_data: dict = None):
        super().__init__(parent)
        self.setWindowTitle("AI: Edit JSON Instructions")
        self.setMinimumSize(800, 600)
        
        layout = QVBoxLayout(self)
        
        # Info label
        info_label = QLabel(
            "Edit the JSON instructions below. Changes will be applied when you click Apply."
        )
        info_label.setWordWrap(True)
        layout.addWidget(info_label)
        
        # JSON editor
        self.json_edit = QTextEdit()
        self.json_edit.setFontFamily("Courier")
        if json_data:
            self.json_edit.setPlainText(json.dumps(json_data, indent=2))
        layout.addWidget(self.json_edit)
        
        # Validation label
        self.validation_label = QLabel("")
        self.validation_label.setStyleSheet("color: green;")
        layout.addWidget(self.validation_label)
        
        # Validate button
        validate_btn = QPushButton("Validate JSON")
        validate_btn.clicked.connect(self.validate_json)
        layout.addWidget(validate_btn)
        
        # Buttons
        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.accepted.connect(self.on_accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)
        
        # Validate on text change
        self.json_edit.textChanged.connect(self.validate_json)
    
    def validate_json(self):
        """Validate JSON syntax."""
        try:
            json.loads(self.json_edit.toPlainText())
            self.validation_label.setText("✓ Valid JSON")
            self.validation_label.setStyleSheet("color: green;")
            return True
        except json.JSONDecodeError as e:
            self.validation_label.setText(f"✗ Invalid JSON: {str(e)}")
            self.validation_label.setStyleSheet("color: red;")
            return False
    
    def on_accept(self):
        """Handle accept - validate before closing."""
        if self.validate_json():
            self.accept()
        else:
            QMessageBox.warning(self, "Invalid JSON", "Please fix JSON errors before applying.")
    
    def get_json_data(self) -> Optional[dict]:
        """Get parsed JSON data."""
        try:
            return json.loads(self.json_edit.toPlainText())
        except json.JSONDecodeError:
            return None


class ChangePreviewWidget(QWidget):
    """Widget for previewing AI change regions as overlays."""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.base_image = None
        self.changes = []
        self.current_frame = 0
        self.show_overlay = True
    
    def set_base_image(self, image: np.ndarray):
        """Set base image for preview."""
        self.base_image = image
        self.update()
    
    def set_changes(self, changes: list):
        """Set change instructions."""
        self.changes = changes
        self.update()
    
    def set_current_frame(self, frame: int):
        """Set current frame to preview."""
        self.current_frame = frame
        self.update()
    
    def toggle_overlay(self, show: bool):
        """Toggle overlay visibility."""
        self.show_overlay = show
        self.update()
    
    def paintEvent(self, event):
        """Draw preview with change overlays."""
        from PySide6.QtGui import QPainter, QPen, QBrush, QColor, QPixmap, QImage
        
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        
        if self.base_image is None:
            painter.fillRect(self.rect(), QColor(240, 240, 240))
            painter.drawText(self.rect(), Qt.AlignCenter, "No image loaded")
            return
        
        # Convert numpy array to QPixmap
        h, w = self.base_image.shape[:2]
        q_image = QImage(self.base_image.data, w, h, w * 4, QImage.Format_RGBA8888)
        pixmap = QPixmap.fromImage(q_image)
        
        # Scale to fit widget
        scaled_pixmap = pixmap.scaled(self.size(), Qt.KeepAspectRatio, Qt.SmoothTransformation)
        x_offset = (self.width() - scaled_pixmap.width()) // 2
        y_offset = (self.height() - scaled_pixmap.height()) // 2
        
        painter.drawPixmap(x_offset, y_offset, scaled_pixmap)
        
        # Draw change overlays
        if self.show_overlay and self.changes and 0 <= self.current_frame < len(self.changes):
            scale_x = scaled_pixmap.width() / w
            scale_y = scaled_pixmap.height() / h
            
            frame_changes = self.changes[self.current_frame].get('changes', [])
            
            for change in frame_changes:
                change_type = change.get('type', '')
                
                if change_type == 'move_region':
                    # Draw source (red) and target (green)
                    source = change.get('source', {})
                    target = change.get('target', {})
                    
                    if source:
                        sx = x_offset + source.get('x', 0) * scale_x
                        sy = y_offset + source.get('y', 0) * scale_y
                        sw = source.get('w', 0) * scale_x
                        sh = source.get('h', 0) * scale_y
                        
                        painter.setPen(QPen(QColor(255, 0, 0, 200), 2))
                        painter.setBrush(QBrush(QColor(255, 0, 0, 50)))
                        painter.drawRect(int(sx), int(sy), int(sw), int(sh))
                    
                    if target:
                        tx = x_offset + target.get('x', 0) * scale_x
                        ty = y_offset + target.get('y', 0) * scale_y
                        tw = target.get('w', 0) * scale_x
                        th = target.get('h', 0) * scale_y
                        
                        painter.setPen(QPen(QColor(0, 255, 0, 200), 2))
                        painter.setBrush(QBrush(QColor(0, 255, 0, 50)))
                        painter.drawRect(int(tx), int(ty), int(tw), int(th))
                
                elif change_type == 'modify_pixels':
                    # Draw region (blue)
                    region = change.get('region', {})
                    if region:
                        rx = x_offset + region.get('x', 0) * scale_x
                        ry = y_offset + region.get('y', 0) * scale_y
                        rw = region.get('w', 0) * scale_x
                        rh = region.get('h', 0) * scale_y
                        
                        painter.setPen(QPen(QColor(0, 0, 255, 200), 2))
                        painter.setBrush(QBrush(QColor(0, 0, 255, 50)))
                        painter.drawRect(int(rx), int(ry), int(rw), int(rh))
                
                elif change_type == 'paint_pixels':
                    # Draw region (yellow)
                    region = change.get('region', {})
                    if region:
                        rx = x_offset + region.get('x', 0) * scale_x
                        ry = y_offset + region.get('y', 0) * scale_y
                        rw = region.get('w', 0) * scale_x
                        rh = region.get('h', 0) * scale_y
                        
                        painter.setPen(QPen(QColor(255, 255, 0, 200), 2))
                        painter.setBrush(QBrush(QColor(255, 255, 0, 50)))
                        painter.drawRect(int(rx), int(ry), int(rw), int(rh))


# ============================================================================
# NEW UNIFIED AI DIALOG SYSTEM
# ============================================================================

class CheckerboardPreviewWidget(QLabel):
    """Preview widget with checkerboard background like the main canvas."""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumSize(300, 200)
        self.setAlignment(Qt.AlignCenter)
        self.setText("Preview will appear here")
        self.setStyleSheet("border: 1px solid #888;")
        self.preview_pixmap = None
        
    def setPixmap(self, pixmap):
        """Override setPixmap to store the pixmap and trigger repaint."""
        self.preview_pixmap = pixmap
        self.update()  # Trigger repaint
        
    def paintEvent(self, event):
        """Override paint event to draw checkerboard background and preview image."""
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        
        # Get widget size
        width = self.width()
        height = self.height()
        
        # Draw checkerboard pattern
        checker_size = 8
        color1 = QColor(40, 40, 40)  # Dark gray
        color2 = QColor(60, 60, 60)  # Light gray
        
        for y in range(0, height, checker_size):
            for x in range(0, width, checker_size):
                # Alternate colors for checkerboard pattern
                if (x // checker_size + y // checker_size) % 2 == 0:
                    painter.fillRect(x, y, checker_size, checker_size, color1)
                else:
                    painter.fillRect(x, y, checker_size, checker_size, color2)
        
        # Draw the preview image if available
        if self.preview_pixmap:
            # Calculate position to center the image
            pixmap_rect = self.preview_pixmap.rect()
            widget_rect = self.rect()
            
            # Scale to fit while maintaining aspect ratio
            scaled_pixmap = self.preview_pixmap.scaled(
                widget_rect.size(), 
                Qt.KeepAspectRatio, 
                Qt.SmoothTransformation
            )
            
            # Center the scaled pixmap
            x = (widget_rect.width() - scaled_pixmap.width()) // 2
            y = (widget_rect.height() - scaled_pixmap.height()) // 2
            
            painter.drawPixmap(x, y, scaled_pixmap)
        else:
            # Draw text if no pixmap
            painter.setPen(QColor(200, 200, 200))
            painter.drawText(self.rect(), Qt.AlignCenter, self.text())


class AIRequestSpecDialog(QDialog):
    """Configuration dialog for AI request specification."""
    
    def __init__(self, parent=None, initial_type="Modify", initial_scope="current"):
        super().__init__(parent)
        self.setWindowTitle("Configure AI Request")
        self.setMinimumWidth(500)
        self.setModal(True)
        
        layout = QVBoxLayout(self)
        
        # Request Type
        type_group = QGroupBox("Request Type")
        type_layout = QVBoxLayout()
        self.type_combo = QComboBox()
        self.type_combo.addItems(["Generate", "Modify", "Analyze", "Animate"])
        if initial_type in ["Generate", "Modify", "Analyze", "Animate"]:
            self.type_combo.setCurrentText(initial_type)
        type_layout.addWidget(self.type_combo)
        type_group.setLayout(type_layout)
        layout.addWidget(type_group)
        
        # Scope
        scope_group = QGroupBox("Scope")
        scope_layout = QVBoxLayout()
        self.scope_group = QButtonGroup(self)
        
        self.scope_current = QRadioButton("Current Frame")
        self.scope_all = QRadioButton("All Frames")
        self.scope_selected = QRadioButton("Selected Frames")
        self.scope_new = QRadioButton("New Frame(s)")
        
        self.scope_group.addButton(self.scope_current, 0)
        self.scope_group.addButton(self.scope_all, 1)
        self.scope_group.addButton(self.scope_selected, 2)
        self.scope_group.addButton(self.scope_new, 3)
        
        # Set initial scope
        if initial_scope == "current":
            self.scope_current.setChecked(True)
        elif initial_scope == "all":
            self.scope_all.setChecked(True)
        elif initial_scope == "selected":
            self.scope_selected.setChecked(True)
        elif initial_scope == "new":
            self.scope_new.setChecked(True)
        else:
            self.scope_current.setChecked(True)
        
        scope_layout.addWidget(self.scope_current)
        scope_layout.addWidget(self.scope_all)
        scope_layout.addWidget(self.scope_selected)
        scope_layout.addWidget(self.scope_new)
        scope_group.setLayout(scope_layout)
        layout.addWidget(scope_group)
        
        # Additional Context (Optional)
        context_group = QGroupBox("Additional Context (Optional)")
        context_layout = QVBoxLayout()
        self.context_text = QTextEdit()
        self.context_text.setPlaceholderText("Specify style, theme, or other context (e.g., 'pixel art style', 'medieval fantasy theme')...")
        self.context_text.setMaximumHeight(80)
        context_layout.addWidget(self.context_text)
        context_group.setLayout(context_layout)
        layout.addWidget(context_group)
        
        # Advanced Options (Expandable)
        self.advanced_group = QGroupBox("Advanced Options")
        self.advanced_group.setCheckable(True)
        self.advanced_group.setChecked(False)
        advanced_layout = QFormLayout()
        
        self.detail_slider = QSlider(Qt.Horizontal)
        self.detail_slider.setMinimum(1)
        self.detail_slider.setMaximum(10)
        self.detail_slider.setValue(7)
        self.detail_label = QLabel("7")
        detail_layout = QHBoxLayout()
        detail_layout.addWidget(self.detail_slider)
        detail_layout.addWidget(self.detail_label)
        self.detail_slider.valueChanged.connect(lambda v: self.detail_label.setText(str(v)))
        advanced_layout.addRow("Detail Level:", detail_layout)
        
        self.quality_combo = QComboBox()
        self.quality_combo.addItems(["Low", "Medium", "High", "Ultra"])
        self.quality_combo.setCurrentText("Medium")
        advanced_layout.addRow("Quality:", self.quality_combo)
        
        self.use_cache_checkbox = QCheckBox("Use Cache")
        self.use_cache_checkbox.setChecked(True)
        advanced_layout.addRow("", self.use_cache_checkbox)
        
        self.advanced_group.setLayout(advanced_layout)
        layout.addWidget(self.advanced_group)
        
        # Buttons
        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)
    
    def get_specification(self) -> Dict[str, Any]:
        """Get request specification as dictionary."""
        scope_map = {
            0: "current",
            1: "all",
            2: "selected",
            3: "new"
        }
        
        return {
            'type': self.type_combo.currentText(),
            'scope': scope_map[self.scope_group.checkedId()],
            'context': self.context_text.toPlainText().strip(),
            'detail_level': self.detail_slider.value(),
            'quality': self.quality_combo.currentText().lower(),
            'use_cache': self.use_cache_checkbox.isChecked()
        }
    
    def validate(self) -> bool:
        """Validate that required fields are filled."""
        # All fields are optional or have defaults
        return True


class AIChatDialog(QDialog):
    """Main AI chat dialog with preview and frame controls."""
    
    def __init__(self, parent=None, request_spec: Optional[Dict[str, Any]] = None):
        super().__init__(parent)
        self.setWindowTitle("AI Assistant")
        self.setMinimumSize(800, 600)
        self.setModal(True)
        
        # Store request specification
        self.request_spec = request_spec or {
            'type': 'Modify',
            'scope': 'current',
            'context': '',
            'detail_level': 7,
            'quality': 'medium',
            'use_cache': True
        }
        
        # Chat history
        self.chat_history: List[Dict[str, str]] = []  # List of {'role': 'user'|'ai', 'message': str}
        
        # Preview data
        self.preview_data: Optional[np.ndarray] = None  # Single frame
        self.preview_frames: List[np.ndarray] = []  # Multiple frames
        self.current_preview_frame = 0
        self.is_playing = False
        self.playback_timer = QTimer()
        self.playback_timer.timeout.connect(self.on_playback_tick)
        self.playback_timer.setInterval(100)  # 100ms per frame
        
        # Processing state
        self.is_processing = False
        self.has_preview = False
        
        self.setup_ui()
        
        # Add initial greeting
        self.add_chat_message("ai", "Hello! I'm your AI assistant. Type your request below and I'll help you with your image editing.")
    
    def setup_ui(self):
        """Setup the dialog UI."""
        layout = QVBoxLayout(self)
        layout.setSpacing(10)
        layout.setContentsMargins(10, 10, 10, 10)
        
        # Splitter to separate chat and preview
        splitter = QSplitter(Qt.Vertical)
        
        # ====================================================================
        # CHAT AREA (Top Section)
        # ====================================================================
        chat_container = QWidget()
        chat_layout = QVBoxLayout(chat_container)
        chat_layout.setContentsMargins(0, 0, 0, 0)
        
        # Chat history area
        chat_history_group = QGroupBox("Chat History")
        chat_history_layout = QVBoxLayout()
        
        self.chat_widget = QTextEdit()
        self.chat_widget.setReadOnly(True)
        self.chat_widget.setMinimumHeight(200)
        self.chat_widget.setStyleSheet("""
            QTextEdit {
                background-color: #2b2b2b;
                color: #ffffff;
                border: 1px solid #555;
                border-radius: 4px;
                padding: 8px;
            }
        """)
        chat_history_layout.addWidget(self.chat_widget)
        chat_history_group.setLayout(chat_history_layout)
        chat_layout.addWidget(chat_history_group)
        
        # Input area
        input_group = QGroupBox("Send Request")
        input_layout = QHBoxLayout()
        
        self.input_field = QLineEdit()
        self.input_field.setPlaceholderText("Type your AI request (e.g., 'Make it brighter', 'Add a hat', 'Create 8-frame walk animation')...")
        self.input_field.returnPressed.connect(self.send_message)
        input_layout.addWidget(self.input_field)
        
        self.send_button = QPushButton("Send")
        self.send_button.clicked.connect(self.send_message)
        self.send_button.setFixedWidth(80)
        input_layout.addWidget(self.send_button)
        
        input_group.setLayout(input_layout)
        chat_layout.addWidget(input_group)
        
        chat_container.setLayout(chat_layout)
        splitter.addWidget(chat_container)
        
        # ====================================================================
        # PREVIEW AREA (Bottom Section)
        # ====================================================================
        preview_container = QWidget()
        preview_layout = QVBoxLayout(preview_container)
        preview_layout.setContentsMargins(0, 0, 0, 0)
        
        preview_group = QGroupBox("Preview")
        preview_group_layout = QVBoxLayout()
        
        # Preview widget
        self.preview_widget = CheckerboardPreviewWidget()
        self.preview_widget.setMinimumHeight(200)
        preview_group_layout.addWidget(self.preview_widget)
        
        # Frame controls (hidden by default)
        self.frame_controls_widget = QWidget()
        frame_controls_layout = QHBoxLayout()
        frame_controls_layout.setContentsMargins(5, 5, 5, 5)
        
        self.prev_frame_btn = QPushButton("◄")
        self.prev_frame_btn.setFixedSize(40, 30)
        self.prev_frame_btn.setToolTip("Previous frame")
        self.prev_frame_btn.clicked.connect(self.previous_frame)
        frame_controls_layout.addWidget(self.prev_frame_btn)
        
        self.play_btn = QPushButton("▶")
        self.play_btn.setFixedSize(40, 30)
        self.play_btn.setToolTip("Play animation")
        self.play_btn.clicked.connect(self.toggle_play)
        frame_controls_layout.addWidget(self.play_btn)
        
        self.pause_btn = QPushButton("⏸")
        self.pause_btn.setFixedSize(40, 30)
        self.pause_btn.setToolTip("Pause animation")
        self.pause_btn.clicked.connect(self.pause_animation)
        self.pause_btn.setEnabled(False)
        frame_controls_layout.addWidget(self.pause_btn)
        
        self.stop_btn = QPushButton("⏹")
        self.stop_btn.setFixedSize(40, 30)
        self.stop_btn.setToolTip("Stop animation")
        self.stop_btn.clicked.connect(self.stop_animation)
        frame_controls_layout.addWidget(self.stop_btn)
        
        self.next_frame_btn = QPushButton("►")
        self.next_frame_btn.setFixedSize(40, 30)
        self.next_frame_btn.setToolTip("Next frame")
        self.next_frame_btn.clicked.connect(self.next_frame)
        frame_controls_layout.addWidget(self.next_frame_btn)
        
        frame_controls_layout.addSpacing(10)
        
        self.frame_counter_label = QLabel("Frame 1/1")
        self.frame_counter_label.setAlignment(Qt.AlignCenter)
        self.frame_counter_label.setMinimumWidth(100)
        frame_controls_layout.addWidget(self.frame_counter_label)
        
        frame_controls_layout.addStretch()
        
        self.frame_controls_widget.setLayout(frame_controls_layout)
        self.frame_controls_widget.setVisible(False)  # Hidden by default
        preview_group_layout.addWidget(self.frame_controls_widget)
        
        preview_group.setLayout(preview_group_layout)
        preview_layout.addWidget(preview_group)
        
        preview_container.setLayout(preview_layout)
        splitter.addWidget(preview_container)
        
        # Set splitter proportions (60% chat, 40% preview)
        splitter.setSizes([400, 300])
        
        layout.addWidget(splitter)
        
        # ====================================================================
        # BUTTONS (Bottom)
        # ====================================================================
        buttons_layout = QHBoxLayout()
        buttons_layout.addStretch()
        
        self.accept_button = QPushButton("Accept")
        self.accept_button.setEnabled(False)  # Disabled until preview is ready
        self.accept_button.clicked.connect(self.apply_changes)
        self.accept_button.setMinimumWidth(100)
        buttons_layout.addWidget(self.accept_button)
        
        self.cancel_button = QPushButton("Cancel")
        self.cancel_button.clicked.connect(self.reject)
        self.cancel_button.setMinimumWidth(100)
        buttons_layout.addWidget(self.cancel_button)
        
        layout.addLayout(buttons_layout)
    
    def add_chat_message(self, role: str, message: str):
        """Add a message to the chat history."""
        self.chat_history.append({'role': role, 'message': message})
        
        # Format message for display
        if role == "user":
            formatted = f"<b style='color: #4a9eff;'>You:</b> {message}<br>"
        else:
            formatted = f"<b style='color: #4ade80;'>AI:</b> {message}<br>"
        
        # Append to chat widget
        self.chat_widget.append(formatted)
        
        # Auto-scroll to bottom
        scrollbar = self.chat_widget.verticalScrollBar()
        scrollbar.setValue(scrollbar.maximum())
    
    def send_message(self):
        """Send user message and trigger AI processing."""
        message = self.input_field.text().strip()
        if not message or self.is_processing:
            return
        
        # Add user message to chat
        self.add_chat_message("user", message)
        
        # Clear input
        self.input_field.clear()
        
        # Disable send button
        self.send_button.setEnabled(False)
        self.is_processing = True
        
        # Add "Processing..." message
        self.add_chat_message("ai", "Processing your request...")
        
        # TODO: Trigger AI processing
        # For now, simulate processing delay
        QTimer.singleShot(500, self.simulate_ai_response)
    
    def simulate_ai_response(self):
        """Simulate AI response (placeholder until AI integration is complete)."""
        # This is a placeholder - will be replaced with actual AI processing
        self.add_chat_message("ai", "AI processing not yet implemented. This is a placeholder response.")
        self.send_button.setEnabled(True)
        self.is_processing = False
    
    def update_preview(self, image: np.ndarray, frames: Optional[List[np.ndarray]] = None):
        """Update preview with image or frames."""
        if frames and len(frames) > 1:
            # Multiple frames
            self.preview_frames = frames
            self.preview_data = None
            self.current_preview_frame = 0
            self.update_preview_frame()
            self.toggle_frame_controls(True)
            self.update_frame_counter()
        else:
            # Single frame
            self.preview_data = image
            self.preview_frames = []
            self.current_preview_frame = 0
            self.update_preview_frame()
            self.toggle_frame_controls(False)
        
        self.has_preview = True
        self.accept_button.setEnabled(True)
    
    def update_preview_frame(self):
        """Update preview widget with current frame."""
        # Get current frame to display
        if self.preview_frames:
            frame = self.preview_frames[self.current_preview_frame]
        elif self.preview_data is not None:
            frame = self.preview_data
        else:
            return
        
        # Convert numpy array to QPixmap
        if len(frame.shape) == 3 and frame.shape[2] == 4:
            # RGBA
            h, w = frame.shape[:2]
            q_image = QImage(frame.data, w, h, w * 4, QImage.Format_RGBA8888)
        elif len(frame.shape) == 3:
            # RGB
            h, w = frame.shape[:2]
            q_image = QImage(frame.data, w, h, w * 3, QImage.Format_RGB888)
        else:
            # Grayscale
            h, w = frame.shape
            q_image = QImage(frame.data, w, h, w, QImage.Format_Grayscale8)
        
        pixmap = QPixmap.fromImage(q_image)
        self.preview_widget.setPixmap(pixmap)
    
    def toggle_frame_controls(self, visible: bool):
        """Show or hide frame controls based on frame count."""
        self.frame_controls_widget.setVisible(visible)
    
    def update_frame_counter(self):
        """Update frame counter label."""
        if self.preview_frames:
            total = len(self.preview_frames)
            current = self.current_preview_frame + 1
            self.frame_counter_label.setText(f"Frame {current}/{total}")
        else:
            self.frame_counter_label.setText("Frame 1/1")
    
    def previous_frame(self):
        """Navigate to previous frame."""
        if self.preview_frames and self.current_preview_frame > 0:
            self.current_preview_frame -= 1
            self.update_preview_frame()
            self.update_frame_counter()
            if self.is_playing:
                self.pause_animation()
    
    def next_frame(self):
        """Navigate to next frame."""
        if self.preview_frames and self.current_preview_frame < len(self.preview_frames) - 1:
            self.current_preview_frame += 1
            self.update_preview_frame()
            self.update_frame_counter()
            if self.is_playing:
                self.pause_animation()
    
    def toggle_play(self):
        """Start or resume animation playback."""
        if not self.preview_frames:
            return
        
        self.is_playing = True
        self.play_btn.setEnabled(False)
        self.pause_btn.setEnabled(True)
        self.playback_timer.start()
    
    def pause_animation(self):
        """Pause animation playback."""
        self.is_playing = False
        self.play_btn.setEnabled(True)
        self.pause_btn.setEnabled(False)
        self.playback_timer.stop()
    
    def stop_animation(self):
        """Stop animation and reset to first frame."""
        self.pause_animation()
        self.current_preview_frame = 0
        self.update_preview_frame()
        self.update_frame_counter()
    
    def on_playback_tick(self):
        """Handle animation playback tick."""
        if not self.preview_frames or not self.is_playing:
            return
        
        self.current_preview_frame = (self.current_preview_frame + 1) % len(self.preview_frames)
        self.update_preview_frame()
        self.update_frame_counter()
    
    def apply_changes(self):
        """Apply preview changes to Image Editor."""
        if not self.has_preview:
            return
        
        # TODO: Apply changes to Image Editor
        # This will be implemented when we integrate with the editor
        
        # For now, just accept
        self.accept()
    
    def closeEvent(self, event):
        """Handle dialog close event."""
        # Stop any playing animation
        if self.is_playing:
            self.pause_animation()
        super().closeEvent(event)
