from PySide6.QtWidgets import QWidget, QSizePolicy
from PySide6.QtCore import Qt, QPoint, Signal, QRect
from PySide6.QtGui import QPainter, QColor, QPen, QBrush, QImage, QGuiApplication, QPixmap
from core.settings import settings
from core.themes import get_theme
from core.state import state
import numpy as np
import math
import random

# Try to import scipy for advanced brush effects
try:
    from scipy.ndimage import gaussian_filter, convolve
    SCIPY_AVAILABLE = True
except ImportError:
    SCIPY_AVAILABLE = False
    print("Warning: scipy not available. Blur and sharpen brushes will not work.")

class CheckerboardCanvas(QWidget):
    # Signal for mouse position changes
    mouse_position_changed = Signal(int, int)
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.border_color = QColor(60, 60, 60)
        self.checker_size = 16
        self._theme = get_theme(settings.theme)
        self._custom_colors = getattr(settings, 'custom_colors', {})
        self.setMinimumSize(64, 64)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        # Enable keyboard focus so shortcuts work
        self.setFocusPolicy(Qt.StrongFocus)
        self.drawing = False
        self.last_pos = None
        
        # Zoom functionality
        self.zoom_level = 1.0
        self.min_zoom = 0.1
        self.max_zoom = 10.0
        self.zoom_step = 0.25
        self.pan_offset = QPoint(0, 0)
        self.panning = False
        
        # Performance optimization: Cache QImage and checkerboard pattern
        self._cached_qimage = None
        self._cached_image_hash = None
        self._checkerboard_pixmap = None
        self._checkerboard_size_cached = None
        self.last_pan_pos = None
        self.show_composite = False  # Toggle between individual layer and composite view
        self.current_image = None  # Current image being displayed
        
        # Grid rendering cache (store pre-calculated grid lines)
        self._grid_lines_cache = None
        self._grid_cache_key = None
        
        # Onion skin overlay cache (store pre-rendered overlay QImages)
        self._onion_skin_cache = {}  # Key: (frame_idx, layer_idx, overlay_type, color, opacity)
        
        # Update throttling (limit to 60 FPS max - prevents excessive repaints)
        self._pending_update = False
        self._update_timer = None
        from PySide6.QtCore import QTimer
        self._throttle_timer = QTimer()
        self._throttle_timer.setSingleShot(True)
        self._throttle_timer.timeout.connect(self._do_throttled_update)
        self._throttle_interval_ms = 16  # ~60 FPS
        
        # Selection state (simplified)
        self.selecting = False
        self.region_start = None  # For rectangle selection preview
        self.region_current = None  # Current rectangle endpoint
        self.brush_selecting = False  # For brush selection
        self.lasso_selecting = False
        self.lasso_points = []
        self.brush_selection_mode = 'replace'
        self.selection_action = 'replace'
        
        # Rigging state
        self.rig_dragging = False
        
        # Timer for marching ants animation
        from PySide6.QtCore import QTimer
        self.marching_ants_timer = QTimer()
        self.marching_ants_timer.timeout.connect(self._update_marching_ants)
        self.marching_ants_timer.start(50)  # 20 FPS
    
    def invalidate_caches(self):
        """Invalidate all caches (call when image data actually changes)"""
        self._cached_qimage = None
        self._cached_image_hash = None
        self._checkerboard_pixmap = None
        self._checkerboard_size_cached = None
        self._grid_lines_cache = None
        self._grid_cache_key = None
        self._onion_skin_cache.clear()  # Clear onion skin cache
        from core.state import state
        state.layer_manager.invalidate_composite_cache()
    
    def _do_throttled_update(self):
        """Perform the throttled update"""
        if self._pending_update:
            self._pending_update = False
            super().update()
    
    def _force_immediate_update(self):
        """Force immediate update (bypass throttling) - used for drawing operations"""
        self._pending_update = False
        if self._throttle_timer.isActive():
            self._throttle_timer.stop()
        # Invalidate QImage cache to force refresh
        self._cached_qimage = None
        self._cached_image_hash = None
        super().update()
    
    def update(self, rect=None):
        """
        Throttled update - limits updates to ~60 FPS to prevent excessive repaints.
        """
        self._pending_update = True
        if not self._throttle_timer.isActive():
            # First update - do it immediately
            self._pending_update = False
            if rect:
                super().update(rect)
            else:
                super().update()
            # Start throttle timer
            self._throttle_timer.start(self._throttle_interval_ms)
        # Subsequent updates within throttle interval will be batched

    def _get_scale(self):
        """Get current scale factor"""
        if not hasattr(self, 'current_image') or self.current_image is None:
            return 1.0
        h, w = self.current_image.shape[:2]
        widget_w, widget_h = self.width(), self.height()
        base_scale = min(widget_w / w, widget_h / h)
        return base_scale * self.zoom_level

    def _get_canvas_offset(self):
        """Get canvas offset for centering"""
        if not hasattr(self, 'current_image') or self.current_image is None:
            return 0, 0
        h, w = self.current_image.shape[:2]
        widget_w, widget_h = self.width(), self.height()
        base_scale = min(widget_w / w, widget_h / h)
        scale = base_scale * self.zoom_level
        draw_w = int(w * scale)
        draw_h = int(h * scale)
        offset_x = (widget_w - draw_w) // 2 + self.pan_offset.x()
        offset_y = (widget_h - draw_h) // 2 + self.pan_offset.y()
        return offset_x, offset_y

    def _widget_pos_to_image_coords(self, pos, snap=False, clamp=True):
        """Convert widget coordinates to image coordinates."""
        if not hasattr(self, 'current_image') or self.current_image is None:
            return 0, 0
        h, w = self.current_image.shape[:2]
        scale = self._get_scale()
        offset_x, offset_y = self._get_canvas_offset()
        x = (pos.x() - offset_x) / scale
        y = (pos.y() - offset_y) / scale
        if snap:
            x, y = self._snap_to_grid(x, y, 1)
        if clamp:
            x = max(0, min(w - 1, int(round(x))))
            y = max(0, min(h - 1, int(round(y))))
        else:
            x = int(round(x))
            y = int(round(y))
        return x, y

    def _image_coords_to_widget_pos(self, x, y):
        """Convert image coordinates to widget coordinates."""
        scale = self._get_scale()
        offset_x, offset_y = self._get_canvas_offset()
        screen_x = int(round(x * scale + offset_x))
        screen_y = int(round(y * scale + offset_y))
        return QPoint(screen_x, screen_y)

    def _maybe_snap_widget_pos(self, pos):
        """Return widget position snapped to the grid if enabled."""
        from core.state import state
        from core.state import state
        if not state.grid_snap:
            return pos
        # Snap to grid but allow positions adjacent to previous snapped point
        scale = self._get_scale()
        offset_x, offset_y = self._get_canvas_offset()
        x = (pos.x() - offset_x) / scale
        y = (pos.y() - offset_y) / scale
        grid_size = state.grid_size
        snapped_x = round(x / grid_size) * grid_size
        snapped_y = round(y / grid_size) * grid_size
        widget_x = snapped_x * scale + offset_x
        widget_y = snapped_y * scale + offset_y
        return QPoint(int(round(widget_x)), int(round(widget_y)))

    def _iter_line_points(self, x0, y0, x1, y1):
        """Yield integer points along a line from (x0,y0) to (x1,y1)."""
        dx = abs(x1 - x0)
        sx = 1 if x0 < x1 else -1
        dy = -abs(y1 - y0)
        sy = 1 if y0 < y1 else -1
        err = dx + dy
        while True:
            yield x0, y0
            if x0 == x1 and y0 == y1:
                break
            e2 = 2 * err
            if e2 >= dy:
                err += dy
                x0 += sx
            if e2 <= dx:
                err += dx
                y0 += sy

    def _draw_snapped_path(self, start_pos, end_pos, button):
        """Draw snapped path by stepping through snapped image coordinates."""
        start = self._widget_pos_to_image_coords(start_pos, snap=True, clamp=False)
        end = self._widget_pos_to_image_coords(end_pos, snap=True, clamp=False)
        first = True
        for px, py in self._iter_line_points(start[0], start[1], end[0], end[1]):
            widget_pos = self._image_coords_to_widget_pos(px, py)
            self._draw_at(widget_pos, button, apply_snap=False)

    def _update_marching_ants(self):
        """Update marching ants animation"""
        if state.selection_manager.has_selection():
            state.selection_manager.update_marching_ants()
            self.update()

    def wheelEvent(self, event):
        # Ctrl+scroll to zoom in/out
        if event.modifiers() & Qt.ControlModifier:
            if event.angleDelta().y() > 0:
                self.zoom_in()
            else:
                self.zoom_out()
            event.accept()
            return
        super().wheelEvent(event)

    def mousePressEvent(self, event):
        from core.state import state
        try:
            self.active_button = event.button()
            self.start_pos = event.pos()
            
            # Handle middle mouse button for panning
            if event.button() == Qt.MiddleButton:
                self.panning = True
                self.last_pan_pos = event.pos()
                self.setCursor(Qt.ClosedHandCursor)
                return
                
            # Move tool (left mouse button)
            if state.current_tool == 'move' and event.button() == Qt.LeftButton:
                self.panning = True
                self.last_pan_pos = event.pos()
                self.setCursor(Qt.ClosedHandCursor)
                return
            
            # Selection tools - Handle creating/modifying selections
            if event.button() == Qt.LeftButton and state.current_tool == 'region':
                snapped_pos = self._maybe_snap_widget_pos(event.pos())
                self.selection_action = 'replace'
                # Check if clicking inside existing selection without modifiers
                # If so, let the fallback handler deal with moving the selection
                if state.selection_manager.has_selection():
                    modifiers = event.modifiers()
                    ctrl_pressed = bool(modifiers & Qt.ControlModifier)
                    shift_pressed = bool(modifiers & Qt.ShiftModifier)
                    
                    # If no modifiers, check if clicking inside selection
                    if not ctrl_pressed and not shift_pressed:
                        scale = self._get_scale()
                        offset_x, offset_y = self._get_canvas_offset()
                        img_x = int((snapped_pos.x() - offset_x) / scale)
                        img_y = int((snapped_pos.y() - offset_y) / scale)
                        
                        if state.selection_manager.mask is not None:
                            h, w = state.selection_manager.mask.shape[:2]
                            if 0 <= img_y < h and 0 <= img_x < w:
                                if state.selection_manager.mask[img_y, img_x]:
                                    # Clicking inside selection - don't start new selection
                                    # Let the fallback handler move it
                                    pass
                                else:
                                    # Clicking outside - start new selection
                                    self.selection_action = 'replace'
                                    self.selecting = True
                                    self.region_start = snapped_pos
                                    self.region_current = snapped_pos
                                    self.update()
                                    return
                            else:
                                # Outside bounds - start new selection
                                self.selection_action = 'replace'
                                self.selecting = True
                                self.region_start = snapped_pos
                                self.region_current = snapped_pos
                                self.update()
                                return
                    else:
                        # Modifiers present - start new selection to add/subtract
                        # Shift = add/expand, Ctrl = subtract/redact
                        self.selection_action = 'add' if shift_pressed else 'subtract'
                        self.selecting = True
                        self.region_start = snapped_pos
                        self.region_current = snapped_pos
                        self.update()
                        return
                else:
                    # No existing selection - start new selection
                    modifiers = event.modifiers()
                    ctrl_pressed = bool(modifiers & Qt.ControlModifier)
                    shift_pressed = bool(modifiers & Qt.ShiftModifier)
                    # Shift = add/expand, Ctrl = subtract/redact
                    if shift_pressed:
                        self.selection_action = 'add'
                    elif ctrl_pressed:
                        self.selection_action = 'subtract'
                    else:
                        self.selection_action = 'replace'
                    self.selecting = True
                    self.region_start = snapped_pos
                    self.region_current = snapped_pos
                    self.update()
                    return
            elif event.button() == Qt.LeftButton and state.current_tool == 'magic_wand':
                # Magic wand tool
                scale = self._get_scale()
                offset_x, offset_y = self._get_canvas_offset()
                img_x = int((event.pos().x() - offset_x) / scale)
                img_y = int((event.pos().y() - offset_y) / scale)
                
                layer = state.layer_manager.get_current_layer()
                img = state.layer_manager.get_current_image() if layer and layer.visible else None
                if img is not None:
                    # Check modifiers
                    modifiers = event.modifiers()
                    ctrl_pressed = bool(modifiers & Qt.ControlModifier)
                    shift_pressed = bool(modifiers & Qt.ShiftModifier)
                    
                    # Create temp manager for new selection
                    from core.selection_manager import SimpleSelectionManager
                    temp_mgr = SimpleSelectionManager()
                    tolerance = state.magic_wand_tolerance if hasattr(state, 'magic_wand_tolerance') else 32
                    
                    if temp_mgr.select_magic_wand_opencv(img_x, img_y, img, tolerance):
                        # Shift = add/expand, Ctrl = subtract/redact
                        if shift_pressed:
                            # Add to selection
                            state.selection_manager.add_to_selection(temp_mgr.mask)
                        elif ctrl_pressed:
                            # Subtract from selection
                            state.selection_manager.subtract_from_selection(temp_mgr.mask)
                        else:
                            # Replace selection
                            state.selection_manager.mask = temp_mgr.mask
                            state.selection_manager._update_bounds()
                    self.update()
                return
            
            # Right-click to deselect area
            if event.button() == Qt.RightButton and state.selection_manager.has_selection():
                if hasattr(self, '_deselect_area'):
                    self._deselect_area(event.pos())
                return
            
            # Handle fill and eyedropper tools first (they don't need drawing state)
            if state.current_tool in ('fill', 'eyedropper'):
                snapped_pos = self._maybe_snap_widget_pos(event.pos())
                if state.current_tool == 'fill':
                    state.push_undo()
                    self._flood_fill(snapped_pos, event.button())
                    self.update()
                    return
                elif state.current_tool == 'eyedropper':
                    self._pick_color(snapped_pos, event.button())
                    self.update()
                    return
            
            # Handle drawing tools - check BEFORE selection transforms
            if event.button() == Qt.LeftButton or event.button() == Qt.RightButton:
                if state.current_tool in ('brush', 'pencil', 'marker', 'calligraphy', 'airbrush', 'eraser', 
                                         'gradient', 'dither', 'line', 'rect', 'ellipse', 'star', 'polygon'):
                    if state.current_tool in ('brush', 'pencil', 'marker', 'calligraphy', 'airbrush', 'eraser'):
                        state.push_undo()
                    elif state.current_tool in ('gradient', 'dither'):
                        state.push_undo()
                    elif state.current_tool == 'line':
                        state.push_undo()
                    elif state.current_tool in ('rect', 'ellipse'):
                        state.push_undo()
                    elif state.current_tool in ('star', 'polygon'):
                        state.push_undo()
                    
                    self.drawing = True
                    snapped_pos = self._maybe_snap_widget_pos(event.pos())
                    self.last_pos = snapped_pos
                    if state.current_tool == 'line':
                        self.line_preview = True
                        self.line_start = snapped_pos
                        self.line_end = snapped_pos
                    elif state.current_tool in ('rect', 'ellipse', 'star', 'polygon'):
                        self.shape_preview = True
                        self.shape_start = snapped_pos
                        self.shape_end = snapped_pos
                    else:
                        self._draw_at(snapped_pos, event.button(), apply_snap=False)
                    self.update()
                    return
            
            # Handle selection transform (move/resize) - FALLBACK for any tool
            # This is checked last so other tools take priority
            if event.button() == Qt.LeftButton and not self.drawing and state.selection_manager.has_selection():
                try:
                    scale = self._get_scale()
                    offset_x, offset_y = self._get_canvas_offset()
                    
                    # Convert screen position to image coordinates
                    screen_x = event.pos().x()
                    screen_y = event.pos().y()
                    img_x = (screen_x - offset_x) / scale
                    img_y = (screen_y - offset_y) / scale
                    
                    # Check if clicking on a resize handle
                    handle = state.selection_manager.get_handle_at_position(screen_x, screen_y, scale, offset_x, offset_y)
                    if handle is not None:
                        # Start resizing
                        state.push_undo()
                        state.selection_manager.is_resizing = True
                        state.selection_manager.resize_handle = handle
                        state.selection_manager.move_start_pos = (img_x, img_y)
                        bounds = state.selection_manager.get_selection_bounds()
                        if bounds:
                            state.selection_manager.move_start_bounds = bounds
                        self.setCursor(self._get_resize_cursor(handle))
                        self.update()
                        return
                    
                    # Check if clicking inside selection (for moving)
                    if state.selection_manager.mask is not None:
                        h, w = state.selection_manager.mask.shape[:2]
                        if 0 <= int(img_y) < h and 0 <= int(img_x) < w:
                            if state.selection_manager.mask[int(img_y), int(img_x)]:
                                # Start moving
                                state.push_undo()
                                layer = state.layer_manager.get_current_layer()
                                img = state.layer_manager.get_current_image() if layer and layer.visible else None
                                if img is not None:
                                    state.selection_manager._original_image = img.copy()
                                    if state.selection_manager.mask is not None:
                                        state.selection_manager._original_mask = state.selection_manager.mask.copy()
                                    elif hasattr(state.selection_manager, '_original_mask'):
                                        del state.selection_manager._original_mask
                                else:
                                    state.selection_manager._original_image = None
                                    if hasattr(state.selection_manager, '_original_mask'):
                                        del state.selection_manager._original_mask
                                state.selection_manager.is_moving = True
                                state.selection_manager.move_start_pos = (img_x, img_y)
                                bounds = state.selection_manager.get_selection_bounds()
                                if bounds:
                                    state.selection_manager.move_start_bounds = bounds
                                self.setCursor(Qt.SizeAllCursor)
                                self.update()
                                return
                except Exception:
                    pass  # Ignore selection transform errors
            
            self.update()
        except Exception as e:
            # Prevent infinite loops by catching all exceptions
            import traceback
            print(f"Error in mousePressEvent: {e}")
            print(traceback.format_exc())

    def _get_resize_cursor(self, handle):
        """Get appropriate cursor for resize handle"""
        from PySide6.QtGui import QCursor
        # Handle positions: 0=top-left, 1=top, 2=top-right, 3=right, 4=bottom-right, 5=bottom, 6=bottom-left, 7=left
        cursors = [
            Qt.SizeFDiagCursor,  # 0: top-left
            Qt.SizeVerCursor,    # 1: top
            Qt.SizeBDiagCursor,  # 2: top-right
            Qt.SizeHorCursor,    # 3: right
            Qt.SizeFDiagCursor,  # 4: bottom-right
            Qt.SizeVerCursor,    # 5: bottom
            Qt.SizeBDiagCursor,  # 6: bottom-left
            Qt.SizeHorCursor,    # 7: left
        ]
        return cursors[handle] if 0 <= handle < len(cursors) else Qt.ArrowCursor
    
    def mouseMoveEvent(self, event):
        from core.state import state
        try:
            # Handle rigging bone dragging
            if self.rig_dragging:
                try:
                    layer = state.layer_manager.get_current_layer()
                    if layer and layer.rig and layer.rig.selected_bone:
                        scale = self._get_scale()
                        offset_x, offset_y = self._get_canvas_offset()
                        
                        screen_x = event.pos().x()
                        screen_y = event.pos().y()
                        img_x = (screen_x - offset_x) / scale
                        img_y = (screen_y - offset_y) / scale
                        
                        if self.rig_drag_start:
                            start_x, start_y = self.rig_drag_start
                            bone = layer.rig.selected_bone
                            
                            # Calculate rotation based on drag
                            start_world = bone.get_start_world_pos()
                            start_vec = np.array([start_x - start_world[0], start_y - start_world[1]])
                            current_vec = np.array([img_x - start_world[0], img_y - start_world[1]])
                            
                            if np.linalg.norm(start_vec) > 0.1 and np.linalg.norm(current_vec) > 0.1:
                                # Calculate angle difference
                                import math
                                start_angle = math.atan2(start_vec[1], start_vec[0])
                                current_angle = math.atan2(current_vec[1], current_vec[0])
                                angle_diff = math.degrees(current_angle - start_angle)
                                
                                # Apply rotation
                                new_rotation = self.rig_drag_bone_start_rotation + angle_diff
                                bone.set_rotation(new_rotation)
                                self.update()
                        return
                except Exception:
                    self.rig_dragging = False  # Reset on error
                    return
            
            # Handle selection resizing
            if state.selection_manager.is_resizing and state.selection_manager.resize_handle is not None:
                try:
                    scale = self._get_scale()
                    offset_x, offset_y = self._get_canvas_offset()
                    
                    screen_x = event.pos().x()
                    screen_y = event.pos().y()
                    img_x = (screen_x - offset_x) / scale
                    img_y = (screen_y - offset_y) / scale
                    
                    if state.selection_manager.move_start_pos:
                        start_x, start_y = state.selection_manager.move_start_pos
                        dx = img_x - start_x
                        dy = img_y - start_y
                        
                        # Get current image
                        img = state.layer_manager.get_current_image()
                        if img is not None:
                            state.selection_manager.resize_selection(
                                state.selection_manager.resize_handle,
                                dx, dy, img.shape
                            )
                            self.update()
                    return
                except Exception:
                    state.selection_manager.is_resizing = False  # Reset on error
                    return
            
            # Handle selection moving
            if state.selection_manager.is_moving:
                try:
                    scale = self._get_scale()
                    offset_x, offset_y = self._get_canvas_offset()
                    
                    screen_x = event.pos().x()
                    screen_y = event.pos().y()
                    img_x = (screen_x - offset_x) / scale
                    img_y = (screen_y - offset_y) / scale
                    
                    if (
                        state.selection_manager.move_start_pos and
                        state.selection_manager.move_start_bounds and
                        hasattr(state.selection_manager, '_original_image') and
                        state.selection_manager._original_image is not None
                    ):
                        start_x, start_y = state.selection_manager.move_start_pos
                        total_dx = int(round(img_x - start_x))
                        total_dy = int(round(img_y - start_y))
                        
                        layer = state.layer_manager.get_current_layer()
                        img = state.layer_manager.get_current_image()
                        if img is not None:
                            # Restore original image before applying the new position
                            img[:] = state.selection_manager._original_image
                            
                            # Restore original selection mask for consistent movement
                            if hasattr(state.selection_manager, '_original_mask'):
                                state.selection_manager.mask = state.selection_manager._original_mask.copy()
                                state.selection_manager._update_bounds()
                            
                            orig_x1, orig_y1, orig_x2, orig_y2 = state.selection_manager.move_start_bounds
                            h, w = img.shape[:2]
                            
                            # Clamp movement to stay within image bounds
                            new_x1 = max(0, min(w - (orig_x2 - orig_x1), orig_x1 + total_dx))
                            new_y1 = max(0, min(h - (orig_y2 - orig_y1), orig_y1 + total_dy))
                            actual_dx = new_x1 - orig_x1
                            actual_dy = new_y1 - orig_y1
                            
                            src_y1 = max(0, orig_y1)
                            src_y2 = min(h, orig_y2)
                            src_x1 = max(0, orig_x1)
                            src_x2 = min(w, orig_x2)
                            
                            if src_y2 > src_y1 and src_x2 > src_x1:
                                # Extract selected region and mask from original data
                                selected_region = state.selection_manager._original_image[src_y1:src_y2, src_x1:src_x2].copy()
                                if hasattr(state.selection_manager, '_original_mask'):
                                    selected_mask = state.selection_manager._original_mask[src_y1:src_y2, src_x1:src_x2].copy()
                                else:
                                    selected_mask = state.selection_manager.mask[src_y1:src_y2, src_x1:src_x2].copy()
                                
                                # Clear original pixels that are actually opaque within the selection
                                opaque_pixels_to_clear = (selected_region[:, :, 3] > 0) & selected_mask
                                if np.any(opaque_pixels_to_clear):
                                    img[src_y1:src_y2, src_x1:src_x2][opaque_pixels_to_clear] = [0, 0, 0, 0]
                                
                                dst_x1 = max(0, new_x1)
                                dst_y1 = max(0, new_y1)
                                dst_x2 = min(w, dst_x1 + (src_x2 - src_x1))
                                dst_y2 = min(h, dst_y1 + (src_y2 - src_y1))
                                
                                if dst_x2 > dst_x1 and dst_y2 > dst_y1:
                                    dst_w = dst_x2 - dst_x1
                                    dst_h = dst_y2 - dst_y1
                                    src_h = src_y2 - src_y1
                                    src_w = src_x2 - src_x1
                                    
                                    if dst_h < src_h or dst_w < src_w:
                                        selected_region = selected_region[:dst_h, :dst_w]
                                        selected_mask = selected_mask[:dst_h, :dst_w]
                                    elif dst_h > src_h or dst_w > src_w:
                                        padded_region = np.zeros((dst_h, dst_w, 4), dtype=np.uint8)
                                        padded_mask = np.zeros((dst_h, dst_w), dtype=bool)
                                        padded_region[:src_h, :src_w] = selected_region
                                        padded_mask[:src_h, :src_w] = selected_mask
                                        selected_region = padded_region
                                        selected_mask = padded_mask
                                    
                                    dst_region = img[dst_y1:dst_y2, dst_x1:dst_x2]
                                    opaque_mask = (selected_region[:, :, 3] > 0) & selected_mask
                                    if np.any(opaque_mask):
                                        dst_region[opaque_mask] = selected_region[opaque_mask]
                                    
                                    # Move selection mask to the new position using the actual deltas
                                    if hasattr(state.selection_manager, '_original_mask'):
                                        state.selection_manager.mask = state.selection_manager._original_mask.copy()
                                    state.selection_manager.move_selection(actual_dx, actual_dy, img.shape)
                                    
                                    # Persist changes to the frame image
                                    frame = layer.get_frame(state.layer_manager.current_frame)
                                    frame.image = img
                                    
                                    self.update()
                    return
                except Exception:
                    state.selection_manager.is_moving = False  # Reset on error
                    return
            
            # Handle panning
            if self.panning and self.last_pan_pos:
                delta = event.pos() - self.last_pan_pos
                self.pan_offset += delta
                self.last_pan_pos = event.pos()
                self.update()
                return
            
            # Emit mouse position for status bar
            self._emit_mouse_position(event.pos())
            
            # Handle selection tools
            if self.selecting and state.current_tool == 'region':
                self.region_current = self._maybe_snap_widget_pos(event.pos())
                self.update()
                return
            
            # Handle drawing tools - this should work normally
            if self.drawing and (event.buttons() & (Qt.LeftButton | Qt.RightButton)):
                button = Qt.LeftButton if event.buttons() & Qt.LeftButton else Qt.RightButton
                if state.current_tool == 'line' and hasattr(self, 'line_preview') and self.line_preview:
                    self.line_end = self._maybe_snap_widget_pos(event.pos())
                    self.update()
                elif state.current_tool in ('rect', 'ellipse', 'star', 'polygon') and hasattr(self, 'shape_preview') and self.shape_preview:
                    self.shape_end = self._maybe_snap_widget_pos(event.pos())
                    self.update()
                else:
                    # Brush-style tools - OPTIMIZED: Batch drawing operations for performance
                    current_pos = event.pos()
                    if state.grid_snap:
                        if self.last_pos is not None:
                            self._draw_snapped_path(self.last_pos, current_pos, button)
                        else:
                            snapped_start = self._maybe_snap_widget_pos(current_pos)
                            self._draw_at(snapped_start, button, apply_snap=False)
                    else:
                        # PERFORMANCE FIX: Batch all points and draw in one operation
                        if self.last_pos is not None:
                            # Convert widget positions to image coordinates
                            start = self._widget_pos_to_image_coords(self.last_pos, snap=False, clamp=False)
                            end = self._widget_pos_to_image_coords(current_pos, snap=False, clamp=False)
                            # Collect all points first
                            points = list(self._iter_line_points(start[0], start[1], end[0], end[1]))
                            # Draw all points in batch (no updates between points)
                            self._draw_path_batched(points, button)
                        else:
                            # First point - just draw at current position
                            self._draw_at(current_pos, button, apply_snap=False)
                    self.last_pos = current_pos
                    # Force immediate update once at the end (bypass throttling for drawing)
                    self._force_immediate_update()
                    return
            
            self.update()
        except Exception as e:
            # Prevent infinite loops by catching all exceptions
            import traceback
            print(f"Error in mouseMoveEvent: {e}")
            print(traceback.format_exc())
            # Reset all dragging states on error
            if hasattr(state, 'selection_manager'):
                state.selection_manager.is_moving = False
                state.selection_manager.is_resizing = False

    def mouseReleaseEvent(self, event):
        from core.state import state
        try:
            # Handle selection transform end
            if state.selection_manager.is_resizing or state.selection_manager.is_moving:
                if state.selection_manager.is_resizing:
                    state.selection_manager.is_resizing = False
                    state.selection_manager.resize_handle = None
                if state.selection_manager.is_moving:
                    state.selection_manager.is_moving = False
                    if hasattr(state.selection_manager, '_original_image'):
                        del state.selection_manager._original_image
                    if hasattr(state.selection_manager, '_original_mask'):
                        del state.selection_manager._original_mask
                state.selection_manager.move_start_pos = None
                state.selection_manager.move_start_bounds = None
                self.setCursor(Qt.ArrowCursor)
                self.update()
                return
            
            # Handle panning end
            if event.button() == Qt.MiddleButton:
                self.panning = False
                self.last_pan_pos = None
                self.setCursor(Qt.ArrowCursor)
                return
                
            # Handle move tool end
            if state.current_tool == 'move' and event.button() == Qt.LeftButton:
                self.panning = False
                self.last_pan_pos = None
                self.setCursor(Qt.ArrowCursor)
                return
            
            # Handle selection tool release
            if self.selecting and state.current_tool == 'region' and event.button() == Qt.LeftButton:
                if self.region_start and self.region_current:
                    # Convert screen coordinates to image coordinates
                    scale = self._get_scale()
                    offset_x, offset_y = self._get_canvas_offset()
                    
                    img_x1 = int((self.region_start.x() - offset_x) / scale)
                    img_y1 = int((self.region_start.y() - offset_y) / scale)
                    img_x2 = int((self.region_current.x() - offset_x) / scale)
                    img_y2 = int((self.region_current.y() - offset_y) / scale)
                    
                    layer = state.layer_manager.get_current_layer()
                    img = state.layer_manager.get_current_image() if layer and layer.visible else None
                    if img is not None:
                        mode = getattr(self, 'selection_action', 'replace')
                        
                        if mode == 'add':
                            # Add to selection
                            h, w = img.shape[:2]
                            new_mask = np.zeros((h, w), dtype=bool)
                            x1, x2 = min(img_x1, img_x2), max(img_x1, img_x2)
                            y1, y2 = min(img_y1, img_y2), max(img_y1, img_y2)
                            x1, x2 = max(0, x1), min(w, x2)
                            y1, y2 = max(0, y1), min(h, y2)
                            if x2 > x1 and y2 > y1:
                                new_mask[y1:y2, x1:x2] = True
                                state.selection_manager.add_to_selection(new_mask)
                        elif mode == 'subtract':
                            # Subtract from selection
                            h, w = img.shape[:2]
                            subtract_mask = np.zeros((h, w), dtype=bool)
                            x1, x2 = min(img_x1, img_x2), max(img_x1, img_x2)
                            y1, y2 = min(img_y1, img_y2), max(img_y1, img_y2)
                            x1, x2 = max(0, x1), min(w, x2)
                            y1, y2 = max(0, y1), min(h, y2)
                            if x2 > x1 and y2 > y1:
                                subtract_mask[y1:y2, x1:x2] = True
                                state.selection_manager.subtract_from_selection(subtract_mask)
                        else:
                            # No modifiers: Replace selection
                            state.selection_manager.select_rect(img_x1, img_y1, img_x2, img_y2, img.shape)
                    
                self.selecting = False
                self.region_start = None
                self.region_current = None
                self.selection_action = 'replace'
                self.update()
                self.repaint()  # Force immediate repaint to show updated selection
                return
            elif self.brush_selecting and state.current_tool == 'spray' and event.button() == Qt.LeftButton:
                self.brush_selecting = False
                self.brush_selection_mode = 'replace'
                self.update()
                return
            
            # Handle drawing tool release
            if event.button() == Qt.LeftButton or event.button() == Qt.RightButton:
                if state.current_tool == 'line' and hasattr(self, 'line_preview') and self.line_preview:
                    self._draw_line(self.line_start, event.pos(), self.active_button)
                    self.line_preview = False
                elif state.current_tool in ('rect', 'ellipse') and hasattr(self, 'shape_preview') and self.shape_preview:
                    self._draw_shape(self.shape_start, event.pos(), self.active_button)
                    self.shape_preview = False
                elif state.current_tool in ('star', 'polygon') and hasattr(self, 'shape_preview') and self.shape_preview:
                    self._draw_shape(self.shape_start, event.pos(), self.active_button)
                    self.shape_preview = False
                self.drawing = False
                self.last_pos = None
                self.update()
                return
            
            self.update()
        except Exception as e:
            # Prevent infinite loops by catching all exceptions
            import traceback
            print(f"Error in mouseReleaseEvent: {e}")
            print(traceback.format_exc())
            # Reset all states on error
            self.drawing = False
            if hasattr(state, 'selection_manager'):
                state.selection_manager.is_moving = False
                state.selection_manager.is_resizing = False

    def clear_selection(self):
        from core.state import state
        state.selection_manager.clear_selection()
        self.selecting = False
        self.region_start = None
        self.region_current = None
        self.brush_selecting = False
        self.brush_selection_mode = 'replace'
        self.selection_action = 'replace'
        self.update()

    def keyPressEvent(self, event):
        from core.state import state
        if event.key() == Qt.Key_Escape:
            # Clear selection and update
            state.selection_manager.clear_selection()
            self.selecting = False
            self.region_start = None
            self.region_current = None
            self.brush_selecting = False
            self.update()
            event.accept()
            return
        elif event.key() == Qt.Key_Delete or event.key() == Qt.Key_Backspace:
            self._delete_selection()
            event.accept()
        elif event.modifiers() & Qt.ControlModifier and event.key() == Qt.Key_Z:
            # Undo
            if hasattr(self.parent(), 'undo'):
                self.parent().undo()
            event.accept()
        elif event.modifiers() & Qt.ControlModifier and event.key() == Qt.Key_Y:
            # Redo
            if hasattr(self.parent(), 'redo'):
                self.parent().redo()
            event.accept()
        elif event.modifiers() & Qt.ControlModifier and event.key() == Qt.Key_C:
            # Copy
            self.copy_selection()
            event.accept()
        elif event.modifiers() & Qt.ControlModifier and event.key() == Qt.Key_X:
            # Cut
            self.cut_selection()
            event.accept()
        elif event.modifiers() & Qt.ControlModifier and event.key() == Qt.Key_V:
            # Paste
            self.paste_selection()
            event.accept()
        elif event.modifiers() & Qt.ControlModifier and event.key() == Qt.Key_A:
            self.select_all()
            event.accept()
        elif event.key() == Qt.Key_Left:
            self.move_selection_by_keys(-1, 0)
            event.accept()
        elif event.key() == Qt.Key_Right:
            self.move_selection_by_keys(1, 0)
            event.accept()
        elif event.key() == Qt.Key_Up:
            self.move_selection_by_keys(0, -1)
            event.accept()
        elif event.key() == Qt.Key_Down:
            self.move_selection_by_keys(0, 1)
            event.accept()
        elif event.modifiers() & Qt.ControlModifier and event.key() == Qt.Key_Plus:
            self.zoom_in()
            event.accept()
        elif event.modifiers() & Qt.ControlModifier and event.key() == Qt.Key_Minus:
            self.zoom_out()
            event.accept()
        elif event.modifiers() & Qt.ControlModifier and event.key() == Qt.Key_0:
            self.zoom_reset()
            event.accept()
        else:
            super().keyPressEvent(event)


    def move_selection_by_keys(self, dx, dy):
        """Move selection by keyboard arrow keys"""
        from core.state import state
        if not state.selection_manager.has_selection():
            return
        layer = state.layer_manager.get_current_layer()
        img = state.layer_manager.get_current_image() if layer and layer.visible else None
        if img is not None:
            state.push_undo()
            if state.selection_manager.move_selection_by_keys(dx, dy, img.shape):
                self.update_current_image_from_selected_layer()
                self.update()

    def zoom_in(self):
        """Zoom in by one step - OPTIMIZED"""
        new_zoom = min(self.max_zoom, self.zoom_level + self.zoom_step)
        if new_zoom != self.zoom_level:
            self.zoom_level = new_zoom
            # Use dirty rectangles for zoom - mark entire viewport as dirty
            from core.state import state
            state.full_redraw_needed = True
            self.update()
            # Update status bar zoom display
            if hasattr(self.parent(), 'zoom_status'):
                self.parent().zoom_status.setText(f"Zoom: {int(self.zoom_level * 100)}%")

    def zoom_out(self):
        """Zoom out by one step - OPTIMIZED"""
        new_zoom = max(self.min_zoom, self.zoom_level - self.zoom_step)
        if new_zoom != self.zoom_level:
            self.zoom_level = new_zoom
            # Use dirty rectangles for zoom - mark entire viewport as dirty
            from core.state import state
            state.full_redraw_needed = True
            self.update()
            # Update status bar zoom display
            if hasattr(self.parent(), 'zoom_status'):
                self.parent().zoom_status.setText(f"Zoom: {int(self.zoom_level * 100)}%")

    def zoom_reset(self):
        """Reset zoom to 100%"""
        if self.zoom_level != 1.0:
            self.zoom_level = 1.0
            self.pan_offset = QPoint(0, 0)
            self.update()
            # Update status bar zoom display
            if hasattr(self.parent(), 'zoom_status'):
                self.parent().zoom_status.setText(f"Zoom: 100%")

    def _snap_to_grid(self, x, y, scale):
        from core.state import state
        if not state.grid_snap:
            return x, y
        grid_size = state.grid_size * scale
        if grid_size < 1:
            return x, y
        snapped_x = int(round(x / grid_size) * grid_size)
        snapped_y = int(round(y / grid_size) * grid_size)
        return snapped_x, snapped_y

    def _draw_at(self, pos, button, apply_snap=None):
        from core.state import state
        if apply_snap is None:
            apply_snap = state.grid_snap
        tool = state.current_tool
        # Get the current frame and its image
        current_frame = state.layer_manager.get_current_frame()
        img = current_frame.image  # Work directly with the frame's image
        if img is None:
            return
        h, w, ch = img.shape
        widget_w, widget_h = self.width(), self.height()
        base_scale = min(widget_w / w, widget_h / h)
        # Apply zoom to the scale
        scale = base_scale * self.zoom_level
        draw_w = int(w * scale)
        draw_h = int(h * scale)
        offset_x = (widget_w - draw_w) // 2 + self.pan_offset.x()
        offset_y = (widget_h - draw_h) // 2 + self.pan_offset.y()
        x = (pos.x() - offset_x) / scale
        y = (pos.y() - offset_y) / scale
        if apply_snap:
            x, y = self._snap_to_grid(x, y, 1)
        else:
            x, y = int(round(x)), int(round(y))
        x = int(round(x))
        y = int(round(y))
        r = state.current_radius
        
        # Handle single pixel case (radius 1)
        if r <= 1:
            if 0 <= x < w and 0 <= y < h:
                if tool == 'eraser':
                    img[y, x] = [0, 0, 0, 0]
                else:
                    if button == Qt.LeftButton:
                        color_hex = state.current_left_color
                    else:
                        color_hex = state.current_right_color
                    qcolor = QColor(color_hex)
                    color = [qcolor.red(), qcolor.green(), qcolor.blue(), 255]
                    img[y, x] = color
            # Calculate dirty region for single pixel
            state.mark_dirty_region(max(0, x-1), max(0, y-1), 3, 3)
            # Update the canvas to reflect changes (no copy needed - img is the reference)
            if self.current_image is not img:
                self.current_image = img
            self.update_dirty_regions()
            self._update_preview_box()
            return
        
        # Get color based on button
        if tool == 'eraser':
            color = [0, 0, 0, 0]
        else:
            if button == Qt.LeftButton:
                color_hex = state.current_left_color
            else:
                color_hex = state.current_right_color
            qcolor = QColor(color_hex)
            color = [qcolor.red(), qcolor.green(), qcolor.blue(), 255]
        
        # Apply different brush behaviors based on tool type
        if tool == 'brush':
            self._apply_brush_stroke(img, x, y, r, color, h, w)
        elif tool == 'pencil':
            self._apply_pencil_stroke(img, x, y, r, color, h, w)
        elif tool == 'marker':
            self._apply_marker_stroke(img, x, y, r, color, h, w)
        elif tool == 'calligraphy':
            self._apply_calligraphy_stroke(img, x, y, r, color, h, w)
        elif tool == 'airbrush':
            self._apply_airbrush_stroke(img, x, y, r, color, h, w)
        elif tool == 'eraser':
            self._apply_eraser_stroke(img, x, y, r, color, h, w)
        elif tool == 'gradient':
            self._apply_gradient_stroke(img, x, y, r, color, h, w)
        elif tool == 'dither':
            self._apply_dither_stroke(img, x, y, r, color, h, w)
        elif tool == 'blur':
            self._apply_blur_brush_stroke(img, x, y, r, color, h, w)
        elif tool == 'sharpen':
            self._apply_sharpen_brush_stroke(img, x, y, r, color, h, w)
        
        # Calculate dirty region based on brush position and radius
        dirty_x = max(0, x - r - 2)
        dirty_y = max(0, y - r - 2)
        dirty_w = min(w - dirty_x, (r + 2) * 2 + 1)
        dirty_h = min(h - dirty_y, (r + 2) * 2 + 1)
        
        # Mark dirty region in EditorState
        state.mark_dirty_region(dirty_x, dirty_y, dirty_w, dirty_h)
        
        # Update the canvas reference (no copy needed - img is already the current_image reference)
        # Only update current_image if it's not already the same reference
        if self.current_image is not img:
            self.current_image = img
        
        # CRITICAL FIX: Force immediate update when drawing (bypass throttling)
        # Invalidate QImage cache so changes are visible immediately
        self._cached_qimage = None
        self._cached_image_hash = None
        
        # Use partial update if canvas supports it, otherwise full update
        if hasattr(self, 'update_dirty_regions') and callable(getattr(self, 'update_dirty_regions')):
            self.update_dirty_regions()
        else:
            # Force immediate update for drawing operations
            self._force_immediate_update()
        self._update_preview_box()

    def _draw_path_batched(self, points, button):
        """
        PERFORMANCE OPTIMIZATION: Draw a path of points in batch.
        Draws all strokes first, then updates canvas once.
        This is much faster than calling _draw_at() for each point.
        """
        from core.state import state
        if not points:
            return
        
        tool = state.current_tool
        current_frame = state.layer_manager.get_current_frame()
        img = current_frame.image
        if img is None:
            return
        
        h, w = img.shape[:2]
        r = state.current_radius
        
        # Get color once
        if tool == 'eraser':
            color = [0, 0, 0, 0]
        else:
            if button == Qt.LeftButton:
                color_hex = state.current_left_color
            else:
                color_hex = state.current_right_color
            qcolor = QColor(color_hex)
            color = [qcolor.red(), qcolor.green(), qcolor.blue(), 255]
        
        # Collect all brush positions and calculate combined bounding box
        # PERFORMANCE: Skip points that are too close together (reduces redundant strokes)
        min_spacing = max(1, r // 3)  # Only draw if moved at least 1/3 of radius
        min_spacing_sq = min_spacing * min_spacing
        
        min_x, min_y = float('inf'), float('inf')
        max_x, max_y = float('-inf'), float('-inf')
        brush_points = []
        last_point = None
        
        for px, py in points:
            px, py = int(round(px)), int(round(py))
            if 0 <= px < w and 0 <= py < h:
                # Skip points that are too close together (optimization for large brushes)
                if last_point is not None:
                    dx = px - last_point[0]
                    dy = py - last_point[1]
                    dist_sq = dx * dx + dy * dy
                    if dist_sq < min_spacing_sq:
                        continue  # Skip this point, too close to previous
                
                brush_points.append((px, py))
                last_point = (px, py)
                min_x = min(min_x, px - r)
                max_x = max(max_x, px + r)
                min_y = min(min_y, py - r)
                max_y = max(max_y, py + r)
        
        if not brush_points:
            return
        
        # Clip bounding box to image bounds
        min_x = max(0, min_x)
        max_x = min(w, max_x + 1)
        min_y = max(0, min_y)
        max_y = min(h, max_y + 1)
        
        # For small radius or few points, use optimized point-by-point
        if r <= 3 or len(brush_points) <= 10:
            # Fast path: draw each point
            for px, py in brush_points:
                if tool == 'brush':
                    self._apply_brush_stroke(img, px, py, r, color, h, w)
                elif tool == 'pencil':
                    self._apply_pencil_stroke(img, px, py, r, color, h, w)
                elif tool == 'marker':
                    self._apply_marker_stroke(img, px, py, r, color, h, w)
                elif tool == 'calligraphy':
                    self._apply_calligraphy_stroke(img, px, py, r, color, h, w)
                elif tool == 'airbrush':
                    self._apply_airbrush_stroke(img, px, py, r, color, h, w)
                elif tool == 'eraser':
                    self._apply_eraser_stroke(img, px, py, r, color, h, w)
                elif tool == 'gradient':
                    self._apply_gradient_stroke(img, px, py, r, color, h, w)
                elif tool == 'dither':
                    self._apply_dither_stroke(img, px, py, r, color, h, w)
        else:
            # Optimized path: draw all strokes without updates
            # For large brushes, we can optimize further by creating a combined mask
            # But for now, just draw them all without updating
            for px, py in brush_points:
                if tool == 'brush':
                    self._apply_brush_stroke(img, px, py, r, color, h, w)
                elif tool == 'pencil':
                    self._apply_pencil_stroke(img, px, py, r, color, h, w)
                elif tool == 'marker':
                    self._apply_marker_stroke(img, px, py, r, color, h, w)
                elif tool == 'calligraphy':
                    self._apply_calligraphy_stroke(img, px, py, r, color, h, w)
                elif tool == 'airbrush':
                    self._apply_airbrush_stroke(img, px, py, r, color, h, w)
                elif tool == 'eraser':
                    self._apply_eraser_stroke(img, px, py, r, color, h, w)
                elif tool == 'gradient':
                    self._apply_gradient_stroke(img, px, py, r, color, h, w)
                elif tool == 'dither':
                    self._apply_dither_stroke(img, px, py, r, color, h, w)
        
        # Mark combined dirty region (single update)
        dirty_x = max(0, min_x - 2)
        dirty_y = max(0, min_y - 2)
        dirty_w = min(w - dirty_x, (max_x - min_x) + 4)
        dirty_h = min(h - dirty_y, (max_y - min_y) + 4)
        state.mark_dirty_region(dirty_x, dirty_y, dirty_w, dirty_h)
        
        # Update current_image reference
        if self.current_image is not img:
            self.current_image = img
        
        # Invalidate cache (will be updated when canvas refreshes)
        self._cached_qimage = None
        self._cached_image_hash = None

    def _apply_brush_stroke(self, img, x, y, r, color, h, w):
        """Apply brush stroke with soft edges - VECTORIZED for performance"""
        # Calculate bounds
        y_min = max(0, y - r)
        y_max = min(h, y + r + 1)
        x_min = max(0, x - r)
        x_max = min(w, x + r + 1)
        
        if y_min >= y_max or x_min >= x_max:
            return
        
        # Use NumPy for vectorized operations
        local_y, local_x = np.ogrid[y_min:y_max, x_min:x_max]
        dist = np.sqrt((local_x - x) ** 2 + (local_y - y) ** 2)
        mask = dist <= r
        
        if not np.any(mask):
            return
        
        # Soft edge calculation (vectorized)
        alpha = np.clip(1.0 - dist / r, 0, 1)
        
        # Extract region and blend
        region = img[y_min:y_max, x_min:x_max]
        src_color = np.array(color, dtype=np.float32)
        
        # Vectorized blending
        alpha_masked = alpha[mask]
        alpha_expanded = alpha_masked[:, np.newaxis]  # Shape: (N, 1)
        
        dst_colors = region[mask].astype(np.float32)  # Shape: (N, 4)
        blended = dst_colors * (1 - alpha_expanded) + src_color * alpha_expanded
        region[mask] = np.clip(blended, 0, 255).astype(np.uint8)

    def _apply_pencil_stroke(self, img, x, y, r, color, h, w):
        """Pencil with soft, semi-transparent edges (PIL-style opacity accumulation)"""
        opacity = getattr(state, 'current_opacity', 128)
        y_min = max(0, y - r)
        y_max = min(h, y + r + 1)
        x_min = max(0, x - r)
        x_max = min(w, x + r + 1)
        if y_min >= y_max or x_min >= x_max:
            return
        local_y, local_x = np.ogrid[y_min:y_max, x_min:x_max]
        dist = np.sqrt((local_x - x) ** 2 + (local_y - y) ** 2)
        mask = dist <= r
        alpha_factor = np.clip(1.0 - (dist / r) ** 1.5, 0, 1)
        src_alpha = (opacity / 255.0) * alpha_factor
        region = img[y_min:y_max, x_min:x_max]
        src_rgb = np.array(color[:3], dtype=np.float32)
        mask_idx = np.where(mask)
        dst_rgb = region[..., :3].astype(np.float32)
        dst_alpha = region[..., 3].astype(np.uint8)
        # Blend RGB using src_alpha
        out_rgb = dst_rgb[mask_idx] * (1 - src_alpha) + src_rgb * src_alpha
        # Set alpha to max(existing, stroke)
        out_alpha = np.maximum(dst_alpha[mask_idx], (src_alpha[mask_idx] * 255).astype(np.uint8))
        region[..., :3][mask] = np.clip(out_rgb, 0, 255).astype(np.uint8)
        region[..., 3][mask] = out_alpha

    def _apply_marker_stroke(self, img, x, y, r, color, h, w):
        """Marker with solid, opaque core and visible semi-transparent bleed (PIL-style opacity accumulation)"""
        opacity = getattr(state, 'current_opacity', 192)
        y_min = max(0, y - r)
        y_max = min(h, y + r + 1)
        x_min = max(0, x - r)
        x_max = min(w, x + r + 1)
        if y_min >= y_max or x_min >= x_max:
            return
        local_y, local_x = np.ogrid[y_min:y_max, x_min:x_max]
        dist = np.sqrt((local_x - x) ** 2 + (local_y - y) ** 2)
        core_mask = dist <= r * 0.7
        bleed_mask = (dist > r * 0.7) & (dist <= r * 1.2)
        region = img[y_min:y_max, x_min:x_max]
        src_rgb = np.array(color[:3], dtype=np.float32)
        # Core: set alpha to max(existing, stroke)
        mask_idx = np.where(core_mask)
        dst_rgb = region[..., :3].astype(np.float32)
        dst_alpha = region[..., 3].astype(np.uint8)
        out_rgb = dst_rgb[mask_idx] * (1 - opacity / 255.0) + src_rgb * (opacity / 255.0)
        out_alpha = np.maximum(dst_alpha[mask_idx], opacity)
        region[..., :3][core_mask] = np.clip(out_rgb, 0, 255).astype(np.uint8)
        region[..., 3][core_mask] = out_alpha
        # Bleed: semi-transparent, colored edge
        bleed_opacity = int(opacity * 0.4)
        mask_idx = np.where(bleed_mask)
        out_rgb = dst_rgb[mask_idx] * (1 - bleed_opacity / 255.0) + src_rgb * (bleed_opacity / 255.0)
        out_alpha = np.maximum(dst_alpha[mask_idx], bleed_opacity)
        region[..., :3][bleed_mask] = np.clip(out_rgb, 0, 255).astype(np.uint8)
        region[..., 3][bleed_mask] = out_alpha

    def _apply_calligraphy_stroke(self, img, x, y, r, color, h, w):
        """Apply calligraphy brush stroke with pressure simulation - VECTORIZED"""
        import math
        
        # Simulate pressure based on stroke speed (simplified)
        pressure = 0.8
        
        # Elliptical brush shape for calligraphy
        major_axis = int(r * pressure)
        minor_axis = int(r * 0.3)
        
        # Angle for calligraphy effect
        angle_rad = math.radians(45)
        cos_a = math.cos(angle_rad)
        sin_a = math.sin(angle_rad)
        
        # Calculate bounds
        y_min = max(0, y - major_axis)
        y_max = min(h, y + major_axis + 1)
        x_min = max(0, x - major_axis)
        x_max = min(w, x + major_axis + 1)
        
        if y_min >= y_max or x_min >= x_max:
            return
        
        # Vectorized ellipse mask
        local_y, local_x = np.ogrid[y_min:y_max, x_min:x_max]
        dx = local_x - x
        dy = local_y - y
        
        # Transform to elliptical coordinates
        tx = dx * cos_a - dy * sin_a
        ty = dx * sin_a + dy * cos_a
        
        # Ellipse mask
        ellipse_mask = (tx * tx) / (major_axis * major_axis) + (ty * ty) / (minor_axis * minor_axis) <= 1
        
        if not np.any(ellipse_mask):
            return
        
        # Distance-based alpha
        dist = np.sqrt(dx ** 2 + dy ** 2)
        alpha = np.clip(1.0 - dist / major_axis, 0, 1) * pressure
        
        # Extract region and blend
        region = img[y_min:y_max, x_min:x_max]
        src_color = np.array(color, dtype=np.float32)
        
        alpha_masked = alpha[ellipse_mask]
        alpha_expanded = alpha_masked[:, np.newaxis]
        
        dst_colors = region[ellipse_mask].astype(np.float32)
        blended = dst_colors * (1 - alpha_expanded) + src_color * alpha_expanded
        region[ellipse_mask] = np.clip(blended, 0, 255).astype(np.uint8)

    def _apply_airbrush_stroke(self, img, x, y, r, color, h, w):
        """Apply airbrush stroke with spray effect - VECTORIZED"""
        # Number of particles to spray (limited for performance)
        num_particles = min(int(r * r * 0.5), 500)  # Cap at 500 particles
        
        if num_particles <= 0:
            return
        
        # Generate random particles (vectorized)
        angles = np.random.uniform(0, 2 * math.pi, num_particles)
        distances = np.random.uniform(0, r, num_particles)
        
        dx = (distances * np.cos(angles)).astype(int)
        dy = (distances * np.sin(angles)).astype(int)
        
        nx = x + dx
        ny = y + dy
        
        # Filter valid coordinates
        valid = (nx >= 0) & (nx < w) & (ny >= 0) & (ny < h)
        nx_valid = nx[valid]
        ny_valid = ny[valid]
        
        if len(nx_valid) == 0:
            return
        
        # Random opacity for spray effect
        alphas = np.random.uniform(0.1, 0.8, len(nx_valid))
        
        # Blend colors (vectorized)
        src_color = np.array(color, dtype=np.float32)
        dst_colors = img[ny_valid, nx_valid].astype(np.float32)
        alpha_expanded = alphas[:, np.newaxis]
        
        blended = dst_colors * (1 - alpha_expanded) + src_color * alpha_expanded
        img[ny_valid, nx_valid] = np.clip(blended, 0, 255).astype(np.uint8)

    def _apply_gradient_stroke(self, img, x, y, r, color, h, w):
        """Apply gradient brush stroke - VECTORIZED"""
        y_min = max(0, y - r)
        y_max = min(h, y + r + 1)
        x_min = max(0, x - r)
        x_max = min(w, x + r + 1)
        
        if y_min >= y_max or x_min >= x_max:
            return
        
        # Vectorized gradient
        local_y, local_x = np.ogrid[y_min:y_max, x_min:x_max]
        dist = np.sqrt((local_x - x) ** 2 + (local_y - y) ** 2)
        mask = dist <= r
        
        if not np.any(mask):
            return
        
        # Gradient factor (0 at center, 1 at edge)
        t = dist / r
        t_masked = t[mask]
        t_expanded = t_masked[:, np.newaxis]
        
        # Extract region and blend
        region = img[y_min:y_max, x_min:x_max]
        src_color = np.array(color, dtype=np.float32)
        
        dst_colors = region[mask].astype(np.float32)
        gradient = dst_colors * (1 - t_expanded) + src_color * t_expanded
        region[mask] = np.clip(gradient, 0, 255).astype(np.uint8)

    def _apply_eraser_stroke(self, img, x, y, r, color, h, w):
        """Eraser sets all RGBA channels to 0 (fully transparent)"""
        y_min = max(0, y - r)
        y_max = min(h, y + r + 1)
        x_min = max(0, x - r)
        x_max = min(w, x + r + 1)
        if y_min >= y_max or x_min >= x_max:
            return
        local_y, local_x = np.ogrid[y_min:y_max, x_min:x_max]
        dist_sq = (local_x - x) ** 2 + (local_y - y) ** 2
        mask = dist_sq <= r ** 2
        region = img[y_min:y_max, x_min:x_max]
        # Set all RGBA channels to 0 where mask is True
        region[mask] = [0, 0, 0, 0]

    def _apply_dither_stroke(self, img, x, y, r, color, h, w):
        """Apply dither brush stroke - VECTORIZED"""
        y_min = max(0, y - r)
        y_max = min(h, y + r + 1)
        x_min = max(0, x - r)
        x_max = min(w, x + r + 1)
        
        if y_min >= y_max or x_min >= x_max:
            return
        
        # Vectorized dither
        local_y, local_x = np.ogrid[y_min:y_max, x_min:x_max]
        dist = np.sqrt((local_x - x) ** 2 + (local_y - y) ** 2)
        mask = dist <= r
        
        if not np.any(mask):
            return
        
        # Base alpha
        alpha_base = np.clip(1.0 - dist / r, 0, 1)
        
        # Add random noise for dithering (vectorized)
        noise = np.random.uniform(-0.3, 0.3, size=alpha_base.shape)
        alpha = np.clip(alpha_base + noise, 0, 1)
        
        # Extract region and blend
        region = img[y_min:y_max, x_min:x_max]
        src_color = np.array(color, dtype=np.float32)
        
        alpha_masked = alpha[mask]
        alpha_expanded = alpha_masked[:, np.newaxis]
        
        dst_colors = region[mask].astype(np.float32)
        blended = dst_colors * (1 - alpha_expanded) + src_color * alpha_expanded
        region[mask] = np.clip(blended, 0, 255).astype(np.uint8)

    def _apply_blur_brush_stroke(self, img, x, y, r, color, h, w):
        """Apply blur brush stroke"""
        if not SCIPY_AVAILABLE:
            print("Warning: scipy not available. Blur brush not working.")
            return
        
        # Create a mask for the brush area
        mask = np.zeros((h, w), dtype=bool)
        for dy in range(-r, r + 1):
            for dx in range(-r, r + 1):
                dist = (dx * dx + dy * dy) ** 0.5
                if dist <= r:
                    nx, ny = x + dx, y + dy
                    if 0 <= nx < w and 0 <= ny < h:
                        mask[ny, nx] = True
        
        # Apply gaussian blur to the masked area
        if mask.any():
            # Convert to float for processing
            img_float = img.astype(np.float32)
            
            # Apply blur to each channel
            for c in range(3):  # RGB channels only
                channel = img_float[:, :, c]
                blurred_channel = gaussian_filter(channel, sigma=1.0)
                channel[mask] = blurred_channel[mask]
            
            # Convert back to uint8
            img[:] = np.clip(img_float, 0, 255).astype(np.uint8)

    def _apply_sharpen_brush_stroke(self, img, x, y, r, color, h, w):
        """Apply sharpen brush stroke"""
        if not SCIPY_AVAILABLE:
            print("Warning: scipy not available. Sharpen brush not working.")
            return
        
        # Sharpening kernel
        kernel = np.array([
            [0, -1, 0],
            [-1, 5, -1],
            [0, -1, 0]
        ])
        
        # Create a mask for the brush area
        mask = np.zeros((h, w), dtype=bool)
        for dy in range(-r, r + 1):
            for dx in range(-r, r + 1):
                dist = (dx * dx + dy * dy) ** 0.5
                if dist <= r:
                    nx, ny = x + dx, y + dy
                    if 0 <= nx < w and 0 <= ny < h:
                        mask[ny, nx] = True
        
        # Apply sharpening to the masked area
        if mask.any():
            # Convert to float for processing
            img_float = img.astype(np.float32)
            
            # Apply sharpening to each channel
            for c in range(3):  # RGB channels only
                channel = img_float[:, :, c]
                sharpened_channel = convolve(channel, kernel, mode='constant', cval=0)
                channel[mask] = sharpened_channel[mask]
            
            # Convert back to uint8
            img[:] = np.clip(img_float, 0, 255).astype(np.uint8)

    def _draw_line(self, start, end, button):
        from core.state import state
        tool = state.current_tool
        if start is None or end is None:
            return
        
        # Convert screen coordinates to image coordinates
        img = state.layer_manager.get_current_image()
        if img is None:
            return
            
        h, w, ch = img.shape
        widget_w, widget_h = self.width(), self.height()
        base_scale = min(widget_w / w, widget_h / h)
        scale = base_scale * self.zoom_level
        draw_w = int(w * scale)
        draw_h = int(h * scale)
        offset_x = (widget_w - draw_w) // 2 + self.pan_offset.x()
        offset_y = (widget_h - draw_h) // 2 + self.pan_offset.y()
        
        x0 = int((start.x() - offset_x) / scale)
        y0 = int((start.y() - offset_y) / scale)
        x1 = int((end.x() - offset_x) / scale)
        y1 = int((end.y() - offset_y) / scale)

        x0, y0 = self._snap_to_grid(x0, y0, 1)
        x1, y1 = self._snap_to_grid(x1, y1, 1)
        
        # Clamp to image bounds
        x0 = max(0, min(x0, w-1))
        y0 = max(0, min(y0, h-1))
        x1 = max(0, min(x1, w-1))
        y1 = max(0, min(y1, h-1))
        
        x0, y0 = self._snap_to_grid(x0, y0, 1)
        x1, y1 = self._snap_to_grid(x1, y1, 1)
        
        # Get color based on button
        if button == Qt.LeftButton:
            color_hex = state.current_left_color
        else:
            color_hex = state.current_right_color
            
        qcolor = QColor(color_hex)
        color = [qcolor.red(), qcolor.green(), qcolor.blue(), 255]
        
        # Draw the line directly on the image
        thickness = max(1, state.current_radius // 4)  # Use radius to determine line thickness
        self._draw_line_on_image(img, x0, y0, x1, y1, color, thickness)
        
        # Mark dirty region (bounding box of line)
        x_min, x_max = min(x0, x1), max(x0, x1)
        y_min, y_max = min(y0, y1), max(y0, y1)
        padding = thickness + 2
        state.mark_dirty_region(
            max(0, x_min - padding), max(0, y_min - padding),
            min(w - max(0, x_min - padding), (x_max - x_min) + padding * 2 + 1),
            min(h - max(0, y_min - padding), (y_max - y_min) + padding * 2 + 1)
        )
        
        # Update the layer image
        self.update_current_image_from_selected_layer()
        self.update_dirty_regions()
        self._update_preview_box()

    def _draw_shape(self, start, end, button):
        from core.state import state
        tool = state.current_tool
        filled = state.shape_filled
        img = state.layer_manager.get_current_image()  # Always the current layer/frame
        if img is None:
            return
        h, w, ch = img.shape
        widget_w, widget_h = self.width(), self.height()
        base_scale = min(widget_w / w, widget_h / h)
        scale = base_scale * self.zoom_level
        draw_w = int(w * scale)
        draw_h = int(h * scale)
        offset_x = (widget_w - draw_w) // 2 + self.pan_offset.x()
        offset_y = (widget_h - draw_h) // 2 + self.pan_offset.y()
        x1 = int((start.x() - offset_x) / scale)
        y1 = int((start.y() - offset_y) / scale)
        x2 = int((end.x() - offset_x) / scale)
        y2 = int((end.y() - offset_y) / scale)
        x1, y1 = self._snap_to_grid(x1, y1, 1)
        x2, y2 = self._snap_to_grid(x2, y2, 1)
        r = state.current_radius
        if button == Qt.LeftButton:
            color_hex = state.current_left_color
        else:
            color_hex = state.current_right_color
        qcolor = QColor(color_hex)
        color = [qcolor.red(), qcolor.green(), qcolor.blue(), 255]
        # Calculate bounding box for dirty region
        x_min, x_max = min(x1, x2), max(x1, x2)
        y_min, y_max = min(y1, y2), max(y1, y2)
        padding = r + 2
        
        if tool == 'rect':
            self._draw_rect(img, x1, y1, x2, y2, color, r, filled)
        elif tool == 'ellipse':
            self._draw_ellipse(img, x1, y1, x2, y2, color, r, filled)
        elif tool == 'star':
            self._draw_star(img, x1, y1, x2, y2, color, r, filled)
        elif tool == 'polygon':
            self._draw_polygon(img, x1, y1, x2, y2, color, r, filled)
        elif tool == 'triangle':
            self._draw_triangle(img, x1, y1, x2, y2, color, r, filled)
        
        # Mark dirty region (bounding box of shape with padding)
        state.mark_dirty_region(
            max(0, x_min - padding), max(0, y_min - padding),
            min(w - max(0, x_min - padding), (x_max - x_min) + padding * 2 + 1),
            min(h - max(0, y_min - padding), (y_max - y_min) + padding * 2 + 1)
        )
        
        self.update_current_image_from_selected_layer()
        self.update_dirty_regions()
        self._update_preview_box()

    def _draw_rect(self, img, x1, y1, x2, y2, color, radius, filled):
        x_min, x_max = sorted([x1, x2])
        y_min, y_max = sorted([y1, y2])
        if filled:
            img[y_min:y_max+1, x_min:x_max+1, :] = color
        else:
            img[y_min:y_min+radius, x_min:x_max+1, :] = color
            img[y_max-radius+1:y_max+1, x_min:x_max+1, :] = color
            img[y_min:y_max+1, x_min:x_min+radius, :] = color
            img[y_min:y_max+1, x_max-radius+1:x_max+1, :] = color

    def _draw_ellipse(self, img, x1, y1, x2, y2, color, radius, filled):
        # Use exact same coordinate handling as rectangle - expand from starting point
        x_min, x_max = sorted([x1, x2])
        y_min, y_max = sorted([y1, y2])
        # Center the ellipse within the bounding box (like rectangle)
        cx = (x_min + x_max) // 2
        cy = (y_min + y_max) // 2
        rx = (x_max - x_min) // 2
        ry = (y_max - y_min) // 2
        yy, xx = np.ogrid[:img.shape[0], :img.shape[1]]
        ellipse_mask = ((xx - cx) ** 2) / (rx ** 2 + 1e-6) + ((yy - cy) ** 2) / (ry ** 2 + 1e-6)
        if filled:
            mask = ellipse_mask <= 1.0
            img[mask] = color
        else:
            mask = (ellipse_mask <= 1.0) & (ellipse_mask >= 1.0 - (radius / max(rx, ry, 1)))
            img[mask] = color
    
    def _draw_star(self, img, x1, y1, x2, y2, color, radius, filled):
        """Draw a 5-pointed star"""
        import math
        # Use exact same coordinate handling as rectangle - expand from starting point
        x_min, x_max = sorted([x1, x2])
        y_min, y_max = sorted([y1, y2])
        # Center the star within the bounding box (like rectangle)
        cx = (x_min + x_max) // 2
        cy = (y_min + y_max) // 2
        rx = (x_max - x_min) // 2
        ry = (y_max - y_min) // 2
        
        if min(rx, ry) < 5:
            return
        
        # Create a mask for the star
        yy, xx = np.ogrid[:img.shape[0], :img.shape[1]]
        
        # Generate star points - use both rx and ry to fill the entire bounding box
        points = []
        # Use the larger radius for outer points and scale inner points proportionally
        outer_radius_x = rx
        outer_radius_y = ry
        inner_radius_x = rx * 0.4
        inner_radius_y = ry * 0.4
        
        for i in range(10):
            angle = i * math.pi / 5
            if i % 2 == 0:
                # Outer points - use rx for x and ry for y
                x = cx + int(outer_radius_x * math.cos(angle))
                y = cy + int(outer_radius_y * math.sin(angle))
            else:
                # Inner points - use rx for x and ry for y
                x = cx + int(inner_radius_x * math.cos(angle))
                y = cy + int(inner_radius_y * math.sin(angle))
            points.append((x, y))
        
        # Create star mask
        star_mask = np.zeros(img.shape[:2], dtype=bool)
        
        if filled:
            # Fill the star by drawing triangles
            for i in range(0, 10, 2):
                # Create triangle from center to two outer points
                p1 = points[i]
                p2 = points[(i + 2) % 10]
                self._fill_triangle_mask(star_mask, cx, cy, p1[0], p1[1], p2[0], p2[1])
        else:
            # Draw star lines
            for i in range(len(points)):
                start = points[i]
                end = points[(i + 2) % len(points)]
                self._draw_line_mask(star_mask, start[0], start[1], end[0], end[1], radius)
        
        # Apply the mask
        img[star_mask] = color
    
    def _draw_polygon(self, img, x1, y1, x2, y2, color, radius, filled):
        """Draw a hexagon"""
        import math
        # Use exact same coordinate handling as rectangle - expand from starting point
        x_min, x_max = sorted([x1, x2])
        y_min, y_max = sorted([y1, y2])
        # Center the polygon within the bounding box (like rectangle)
        cx = (x_min + x_max) // 2
        cy = (y_min + y_max) // 2
        rx = (x_max - x_min) // 2
        ry = (y_max - y_min) // 2
        
        if min(rx, ry) < 5:
            return
        
        # Create a mask for the hexagon
        yy, xx = np.ogrid[:img.shape[0], :img.shape[1]]
        
        # Generate hexagon points - use both rx and ry to fill the entire bounding box
        points = []
        
        for i in range(6):
            angle = i * math.pi / 3
            # Use rx for x-coordinate and ry for y-coordinate to fill the entire bounding box
            x = cx + int(rx * math.cos(angle))
            y = cy + int(ry * math.sin(angle))
            points.append((x, y))
        
        # Create hexagon mask
        hex_mask = np.zeros(img.shape[:2], dtype=bool)
        
        if filled:
            # Fill the hexagon by drawing triangles from center
            for i in range(len(points)):
                p1 = points[i]
                p2 = points[(i + 1) % len(points)]
                self._fill_triangle_mask(hex_mask, cx, cy, p1[0], p1[1], p2[0], p2[1])
        else:
            # Draw hexagon lines
            for i in range(len(points)):
                start = points[i]
                end = points[(i + 1) % len(points)]
                self._draw_line_mask(hex_mask, start[0], start[1], end[0], end[1], radius)
        
        # Apply the mask
        img[hex_mask] = color
    
    def _draw_triangle(self, img, x1, y1, x2, y2, color, radius, filled):
        """Draw a triangle"""
        import math
        # Use exact same coordinate handling as rectangle - expand from starting point
        x_min, x_max = sorted([x1, x2])
        y_min, y_max = sorted([y1, y2])
        # Center the triangle within the bounding box (like rectangle)
        cx = (x_min + x_max) // 2
        cy = (y_min + y_max) // 2
        rx = (x_max - x_min) // 2
        ry = (y_max - y_min) // 2
        
        if min(rx, ry) < 5:
            return
        
        # Create a mask for the triangle
        triangle_mask = np.zeros(img.shape[:2], dtype=bool)
        
        # Generate triangle points (equilateral triangle)
        points = []
        radius_val = min(rx, ry)
        
        # Top point
        points.append((cx, cy - radius_val))
        # Bottom left point
        points.append((cx - int(radius_val * 0.866), cy + int(radius_val * 0.5)))
        # Bottom right point
        points.append((cx + int(radius_val * 0.866), cy + int(radius_val * 0.5)))
        
        if filled:
            # Fill the triangle
            self._fill_triangle_mask(triangle_mask, points[0][0], points[0][1], 
                                   points[1][0], points[1][1], 
                                   points[2][0], points[2][1])
        else:
            # Draw triangle lines
            for i in range(len(points)):
                start = points[i]
                end = points[(i + 1) % len(points)]
                self._draw_line_mask(triangle_mask, start[0], start[1], end[0], end[1], radius)
        
        # Apply the mask
        img[triangle_mask] = color
    
    def _draw_line_on_image(self, img, x1, y1, x2, y2, color, thickness):
        """Helper method to draw lines on image with thickness"""
        # Bresenham's line algorithm with thickness
        dx = abs(x2 - x1)
        dy = abs(y2 - y1)
        x, y = x1, y1
        sx = 1 if x1 < x2 else -1
        sy = 1 if y1 < y2 else -1
        
        if dx > dy:
            err = dx / 2.0
            while x != x2:
                # Draw thick line
                for i in range(-thickness//2, thickness//2 + 1):
                    for j in range(-thickness//2, thickness//2 + 1):
                        nx, ny = x + i, y + j
                        if 0 <= nx < img.shape[1] and 0 <= ny < img.shape[0]:
                            img[ny, nx] = color
                err -= dy
                if err < 0:
                    y += sy
                    err += dx
                x += sx
        else:
            err = dy / 2.0
            while y != y2:
                # Draw thick line
                for i in range(-thickness//2, thickness//2 + 1):
                    for j in range(-thickness//2, thickness//2 + 1):
                        nx, ny = x + i, y + j
                        if 0 <= nx < img.shape[1] and 0 <= ny < img.shape[0]:
                            img[ny, nx] = color
                err -= dx
                if err < 0:
                    x += sx
                    err += dy
                y += sy

    def _flood_fill(self, pos, button):
        from core.state import state
        img = state.layer_manager.get_current_image()  # Always the current layer/frame
        if img is None:
            return
        h, w, ch = img.shape
        widget_w, widget_h = self.width(), self.height()
        scale = min(widget_w / w, widget_h / h)
        draw_w = int(w * scale)
        draw_h = int(h * scale)
        offset_x = (widget_w - draw_w) // 2
        offset_y = (widget_h - draw_h) // 2
        x = int((pos.x() - offset_x) / scale)
        y = int((pos.y() - offset_y) / scale)
        x, y = self._snap_to_grid(x, y, 1)
        if x < 0 or x >= w or y < 0 or y >= h:
            return
        if button == Qt.LeftButton:
            color_hex = state.current_left_color
        else:
            color_hex = state.current_right_color
        qcolor = QColor(color_hex)
        fill_color = np.array([qcolor.red(), qcolor.green(), qcolor.blue(), 255], dtype=np.uint8)
        target_color = img[y, x].copy()
        if np.array_equal(target_color, fill_color):
            return
        
        # Check if there's an active selection
        if state.selection_manager.has_selection() and state.selection_manager.mask is not None:
            # Fill only within the selection mask
            selection_mask = state.selection_manager.mask
            mask_h, mask_w = selection_mask.shape
            
            # Get selection bounds
            bounds = state.selection_manager.get_selection_bounds()
            if bounds:
                sel_x1, sel_y1, sel_x2, sel_y2 = bounds
                
                # Check if the clicked point is within the selection
                if (sel_x1 <= x < sel_x2 and sel_y1 <= y < sel_y2):
                    # Calculate position within the selection mask
                    mask_x = x - sel_x1
                    mask_y = y - sel_y1
                    
                    if (0 <= mask_x < mask_w and 0 <= mask_y < mask_h and 
                        selection_mask[mask_y, mask_x] > 0):
                        # Use flood fill algorithm within the selection mask
                        stack = [(y, x)]
                        visited = set()
                        
                        while stack:
                            cy, cx = stack.pop()
                            if (cy, cx) in visited:
                                continue
                            visited.add((cy, cx))
                            
                            # Check if pixel is within image bounds
                            if 0 <= cy < h and 0 <= cx < w:
                                # Check if pixel matches target color
                                if np.array_equal(img[cy, cx], target_color):
                                    # Check if pixel is within selection bounds
                                    if (sel_x1 <= cx < sel_x2 and sel_y1 <= cy < sel_y2):
                                        # Check if pixel is within selection mask
                                        mask_cx = cx - sel_x1
                                        mask_cy = cy - sel_y1
                                        if (0 <= mask_cx < mask_w and 0 <= mask_cy < mask_h and
                                            selection_mask[mask_cy, mask_cx] > 0):
                                            # Fill the pixel
                                            img[cy, cx] = fill_color
                                            # Add neighboring pixels to stack
                                            for dy, dx in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
                                                stack.append((cy + dy, cx + dx))
        else:
            # No selection - use standard flood fill algorithm
            mask = np.all(img == target_color, axis=-1)
            stack = [(y, x)]
            while stack:
                cy, cx = stack.pop()
                if 0 <= cy < h and 0 <= cx < w and mask[cy, cx]:
                    img[cy, cx] = fill_color
                    mask[cy, cx] = False
                    stack.extend([(cy-1, cx), (cy+1, cx), (cy, cx-1), (cy, cx+1)])
        
        # CRITICAL FIX: Force immediate update for fill tool (like drawing tools)
        # Invalidate QImage cache so changes are visible immediately
        self._cached_qimage = None
        self._cached_image_hash = None
        
        # Force immediate update (bypass throttling) - same as drawing tools
        self._force_immediate_update()
        self._update_preview_box()

    def _pick_color(self, pos, button):
        from core.state import state
        img = state.layer_manager.get_current_image()  # Always the current layer/frame
        if img is None:
            return
        h, w, ch = img.shape
        widget_w, widget_h = self.width(), self.height()
        scale = min(widget_w / w, widget_h / h)
        draw_w = int(w * scale)
        draw_h = int(h * scale)
        offset_x = (widget_w - draw_w) // 2
        offset_y = (widget_h - draw_h) // 2
        x = int((pos.x() - offset_x) / scale)
        y = int((pos.y() - offset_y) / scale)
        x, y = self._snap_to_grid(x, y, 1)
        if x < 0 or x >= w or y < 0 or y >= h:
            return
        rgba = img[y, x]
        hex_color = '#{:02x}{:02x}{:02x}'.format(rgba[0], rgba[1], rgba[2])
        if button == Qt.LeftButton:
            state.set_left_color(hex_color)
        else:
            state.set_right_color(hex_color)
        # Optionally update color buttons in left panel
        if hasattr(self.parent(), 'left_panel'):
            self.parent().left_panel.update_color_buttons()

    def set_image_size(self, width, height):
        self.update()

    def set_canvas_size(self, width, height):
        self.update()
    
    def set_preview_box(self, preview_box):
        """Set a direct reference to the preview box for updates"""
        self.preview_box = preview_box
    
    def _draw_star_preview(self, painter, start, end):
        """Draw star preview"""
        import math
        # Use exact same coordinate handling as actual drawing - expand from starting point
        x_min, x_max = sorted([start.x(), end.x()])
        y_min, y_max = sorted([start.y(), end.y()])
        # Center the star within the bounding box (like rectangle)
        center_x = (x_min + x_max) // 2
        center_y = (y_min + y_max) // 2
        radius = min(x_max - x_min, y_max - y_min) // 2
        if radius < 5:
            return
        
        # Draw 5-pointed star
        points = []
        for i in range(10):
            angle = i * math.pi / 5
            if i % 2 == 0:
                r = radius
            else:
                r = radius * 0.4
            x = center_x + int(r * math.cos(angle))
            y = center_y + int(r * math.sin(angle))
            points.append(QPoint(x, y))
        
        for i in range(len(points)):
            painter.drawLine(points[i], points[(i + 2) % len(points)])
    
    def _draw_polygon_preview(self, painter, start, end):
        """Draw polygon preview (hexagon)"""
        import math
        # Use exact same coordinate handling as actual drawing - expand from starting point
        x_min, x_max = sorted([start.x(), end.x()])
        y_min, y_max = sorted([start.y(), end.y()])
        # Center the polygon within the bounding box (like rectangle)
        center_x = (x_min + x_max) // 2
        center_y = (y_min + y_max) // 2
        radius = min(x_max - x_min, y_max - y_min) // 2
        if radius < 5:
            return
        
        # Draw hexagon
        points = []
        for i in range(6):
            angle = i * math.pi / 3
            x = center_x + int(radius * math.cos(angle))
            y = center_y + int(radius * math.sin(angle))
            points.append(QPoint(x, y))
        
        for i in range(len(points)):
            painter.drawLine(points[i], points[(i + 1) % len(points)])
    
    def _draw_triangle_preview(self, painter, start, end):
        """Draw triangle preview"""
        import math
        # Use exact same coordinate handling as actual drawing - expand from starting point
        x_min, x_max = sorted([start.x(), end.x()])
        y_min, y_max = sorted([start.y(), end.y()])
        # Center the triangle within the bounding box (like rectangle)
        center_x = (x_min + x_max) // 2
        center_y = (y_min + y_max) // 2
        radius = min(x_max - x_min, y_max - y_min) // 2
        if radius < 5:
            return
        
        # Draw triangle (equilateral)
        points = []
        # Top point
        points.append(QPoint(center_x, center_y - radius))
        # Bottom left point
        points.append(QPoint(center_x - int(radius * 0.866), center_y + int(radius * 0.5)))
        # Bottom right point
        points.append(QPoint(center_x + int(radius * 0.866), center_y + int(radius * 0.5)))
        
        for i in range(len(points)):
            painter.drawLine(points[i], points[(i + 1) % len(points)])
    
    def update_dirty_regions(self):
        """
        Update only the dirty regions from EditorState using partial repaints.
        Converts image coordinates to widget coordinates and uses QWidget.update(QRect).
        CRITICAL: Forces immediate update when drawing (bypasses throttling).
        """
        from core.state import state
        if not state.has_dirty_regions():
            # No dirty regions, do full update
            self._force_immediate_update()
            return
        
        if not hasattr(self, 'current_image') or self.current_image is None:
            self._force_immediate_update()
            return
        
        # Get dirty rectangles from EditorState
        dirty_rects = state.get_dirty_rectangles()
        
        # If too many dirty regions, just do full update
        if state.full_redraw_needed or len(dirty_rects) > 20:
            self._force_immediate_update()
            state.clear_dirty_rectangles()
            return
        
        # Convert image coordinates to widget coordinates
        widget_rects = []
        h, w = self.current_image.shape[:2]
        widget_w, widget_h = self.width(), self.height()
        base_scale = min(widget_w / w, widget_h / h)
        scale = base_scale * self.zoom_level
        offset_x, offset_y = self._get_canvas_offset()
        
        for dirty_rect in dirty_rects:
            # Get image coordinates
            img_x = dirty_rect.x()
            img_y = dirty_rect.y()
            img_w = dirty_rect.width()
            img_h = dirty_rect.height()
            
            # Convert to widget coordinates
            widget_x = int(img_x * scale + offset_x)
            widget_y = int(img_y * scale + offset_y)
            widget_w_scaled = int(img_w * scale)
            widget_h_scaled = int(img_h * scale)
            
            # Add padding to ensure we don't miss edges
            padding = 2
            widget_rect = QRect(
                widget_x - padding, widget_y - padding,
                widget_w_scaled + padding * 2, widget_h_scaled + padding * 2
            )
            
            # Clamp to widget bounds
            widget_rect = widget_rect.intersected(QRect(0, 0, widget_w, widget_h))
            
            if not widget_rect.isEmpty():
                widget_rects.append(widget_rect)
        
        # Update each dirty region - FORCE IMMEDIATE UPDATE (bypass throttling for drawing)
        if widget_rects:
            for rect in widget_rects:
                # Force immediate update (bypass throttling)
                self._pending_update = False
                if self._throttle_timer.isActive():
                    self._throttle_timer.stop()
                super().update(rect)  # Partial repaint - bypass throttled update()
        else:
            # Force immediate update (bypass throttling)
            self._force_immediate_update()
        
        # Clear dirty rectangles after update
        state.clear_dirty_rectangles()
    
    def _update_preview_box(self):
        """Update the preview box when canvas content changes"""
        if hasattr(self, 'preview_box') and self.preview_box:
            self.preview_box.update()
        else:
            # Fallback: try to find the preview box in the parent widget hierarchy
            parent = self.parent()
            while parent:
                if hasattr(parent, 'preview_box'):
                    parent.preview_box.update()
                    break
                elif hasattr(parent, 'right_panel') and hasattr(parent.right_panel, 'preview_box'):
                    parent.right_panel.preview_box.update()
                    break
                parent = parent.parent()

    def _emit_mouse_position(self, pos):
        """Emit mouse position signal for status bar"""
        try:
            from core.state import state
            snap = state.grid_snap
            x, y = self._widget_pos_to_image_coords(pos, snap=snap, clamp=True)
            self.mouse_position_changed.emit(x, y)
        except:
            pass

    def set_theme(self, theme, custom_colors=None):
        self._theme = theme
        self._custom_colors = custom_colors or {}
        border = self._custom_colors.get('canvas_border', self._theme['canvas_border'])
        self.border_color = QColor(border)
        self.update()

    def _lasso_mask(self, points, w, h):
        """Create a mask for the lasso polygon"""
        import numpy as np
        from matplotlib.path import Path
        mask = np.zeros((h, w), dtype=bool)
        if len(points) < 3:
            return mask
        
        # Convert points to relative coordinates for Path
        if points:
            x0, y0 = points[0]
            poly = [(x - x0, y - y0) for x, y in points]
            grid = np.indices((h, w)).transpose(1,2,0).reshape(-1,2)
            path = Path(poly)
            mask_flat = path.contains_points(grid)
            mask = mask_flat.reshape((h, w))
        
        return mask

    def _handle_selection_click(self, pos):
        """Handle selection tool clicks - simplified"""
        from core.state import state
        tool = state.current_tool
        
        # Start new selection based on tool
        if tool == 'region':
            self._start_region_selection(pos)
        elif tool == 'magic_wand':
            self._start_magic_wand_selection(pos)
        elif tool == 'spray':
            self._start_brush_selection(pos)
    
    def _start_region_selection(self, pos):
        """Start region (rectangular) selection - simplified (no QRubberBand)"""
        pos = self._maybe_snap_widget_pos(pos)
        modifiers = QGuiApplication.keyboardModifiers()
        if modifiers & Qt.ShiftModifier:
            self.selection_action = 'subtract'
        elif modifiers & Qt.ControlModifier:
            self.selection_action = 'add'
        else:
            self.selection_action = 'replace'
        self.selecting = True
        self.region_start = pos
        self.region_current = pos
    
    def _start_magic_wand_selection(self, pos, tolerance=32):
        """Start magic wand selection using OpenCV (fast)"""
        pos = self._maybe_snap_widget_pos(pos)
        from core.state import state
        layer = state.layer_manager.get_current_layer()
        img = state.layer_manager.get_current_image() if layer and layer.visible else None
        if img is None:
            return
        
        modifiers = QGuiApplication.keyboardModifiers()
        ctrl_pressed = bool(modifiers & Qt.ControlModifier)
        shift_pressed = bool(modifiers & Qt.ShiftModifier)
        
        # Convert screen coordinates to image coordinates
        scale = self._get_scale()
        offset_x, offset_y = self._get_canvas_offset()
        x = int((pos.x() - offset_x) / scale)
        y = int((pos.y() - offset_y) / scale)
        
        # Try OpenCV first, fallback to Python
        from core.selection_manager import SimpleSelectionManager
        temp_mgr = SimpleSelectionManager()
        if temp_mgr.select_magic_wand_opencv(x, y, img, tolerance):
            # Shift = add/expand, Ctrl = subtract/redact
            if shift_pressed:
                state.selection_manager.add_to_selection(temp_mgr.mask)
            elif ctrl_pressed:
                state.selection_manager.subtract_from_selection(temp_mgr.mask)
            else:
                state.selection_manager.mask = temp_mgr.mask
                state.selection_manager._update_bounds()
        
        # Set focus so keyboard shortcuts work
        self.setFocus()
        self.update()
    
    def _start_brush_selection(self, pos):
        """Start brush selection (replaces spray)"""
        pos = self._maybe_snap_widget_pos(pos)
        self.brush_selecting = True
        from core.state import state
        modifiers = QGuiApplication.keyboardModifiers()
        # Shift = add/expand, Ctrl = subtract/redact
        if modifiers & Qt.ShiftModifier:
            self.brush_selection_mode = 'add'
        elif modifiers & Qt.ControlModifier:
            self.brush_selection_mode = 'subtract'
        else:
            self.brush_selection_mode = 'replace'
            if state.selection_manager.has_selection():
                state.selection_manager.clear_selection()
        self._continue_brush_selection(pos)
    
    def _continue_brush_selection(self, pos):
        """Continue brush selection while mouse is moving"""
        pos = self._maybe_snap_widget_pos(pos)
        from core.state import state
        if not self.brush_selecting:
            return
        
        layer = state.layer_manager.get_current_layer()
        img = state.layer_manager.get_current_image() if layer and layer.visible else None
        if img is None:
            return
        
        # Convert screen coordinates to image coordinates
        scale = self._get_scale()
        offset_x, offset_y = self._get_canvas_offset()
        x = int((pos.x() - offset_x) / scale)
        y = int((pos.y() - offset_y) / scale)
        
        # Use brush radius from state
        radius = state.current_radius
        mode = getattr(self, 'brush_selection_mode', 'replace')
        add = mode != 'subtract'
        
        state.selection_manager.brush_select(x, y, radius, img.shape, add=add)
        self.update()
    
    
    def cut_selection(self):
        """Cut the current selection to clipboard"""
        from core.state import state
        if not state.selection_manager.has_selection():
            return False
        # Copy first, then delete
        if not self.copy_selection():
            return False
        state.push_undo()
        if state.selection_manager.delete_selection(state.layer_manager):
            self.update_current_image_from_selected_layer()
            # Clear selection after cut
            state.selection_manager.clear_selection()
            self.selecting = False
            self.region_start = None
            self.region_current = None
            self.update()
            return True
        return False
    
    def copy_selection(self):
        """Copy the current selection to clipboard"""
        from core.state import state
        if not state.selection_manager.has_selection():
            return False
        
        layer = state.layer_manager.get_current_layer()
        if not layer or not layer.visible:
            return False
        
        image = state.layer_manager.get_current_image()
        if image is None:
            return False
        
        bounds = state.selection_manager.get_selection_bounds()
        if bounds:
            x1, y1, x2, y2 = bounds
            # Store in state for paste (simple clipboard)
            state.clipboard_image = image[y1:y2, x1:x2].copy()
            state.clipboard_mask = state.selection_manager.mask[y1:y2, x1:x2].copy() if state.selection_manager.mask is not None else None
            state.clipboard_bounds = (x1, y1, x2, y2)
            return True
        return False
    
    def paste_selection(self):
        """Paste from clipboard to current position"""
        from core.state import state
        if not hasattr(state, 'clipboard_image') or state.clipboard_image is None:
            return False
        
        layer = state.layer_manager.get_current_layer()
        if not layer or not layer.visible:
            return False
        
        image = state.layer_manager.get_current_image()
        if image is None:
            return False
        
        state.push_undo()
        
        h, w = image.shape[:2]
        ch, cw = state.clipboard_image.shape[:2]
        
        # Paste at current selection bounds if exists, else at (0,0)
        bounds = state.selection_manager.get_selection_bounds()
        if bounds:
            paste_x, paste_y = bounds[0], bounds[1]
        else:
            paste_x, paste_y = 0, 0
        
        # Calculate paste bounds
        x1 = max(0, paste_x)
        y1 = max(0, paste_y)
        x2 = min(w, x1 + cw)
        y2 = min(h, y1 + ch)
        
        if x2 <= x1 or y2 <= y1:
            return False
        
        # Calculate source bounds
        src_x1 = max(0, -paste_x)
        src_y1 = max(0, -paste_y)
        src_x2 = src_x1 + (x2 - x1)
        src_y2 = src_y1 + (y2 - y1)
        
        # Paste the image
        if state.clipboard_mask is not None:
            mask_region = state.clipboard_mask[src_y1:src_y2, src_x1:src_x2]
            img_region = state.clipboard_image[src_y1:src_y2, src_x1:src_x2]
            existing_region = image[y1:y2, x1:x2]
            blended = existing_region.copy()
            blended[mask_region] = img_region[mask_region]
            image[y1:y2, x1:x2] = blended
            
            # Set selection to pasted area
            state.selection_manager.select_rect(x1, y1, x2, y2, image.shape)
        else:
            image[y1:y2, x1:x2] = state.clipboard_image[src_y1:src_y2, src_x1:src_x2]
            state.selection_manager.select_rect(x1, y1, x2, y2, image.shape)
        
        state.layer_manager.update_current_layer()
        self.update_current_image_from_selected_layer()
        self.update()
        return True
    
    def clear_selection(self):
        """Clear the current selection"""
        from core.state import state
        state.selection_manager.clear_selection()
        self.selecting = False
        self.region_start = None
        self.region_current = None
        self.brush_selecting = False
        self.update()
    
    def select_all(self):
        """Select the entire canvas"""
        from core.state import state
        layer = state.layer_manager.get_current_layer()
        if not layer or not layer.visible:
            return
        
        image = state.layer_manager.get_current_image()
        if image is None:
            return
        
        h, w = image.shape[:2]
        state.selection_manager.select_rect(0, 0, w, h, image.shape)
        self.update()
    
    def _delete_selection(self):
        """Delete the selected area (called from keyboard shortcut)"""
        from core.state import state
        if not state.selection_manager.has_selection():
            return
        layer = state.layer_manager.get_current_layer()
        img = state.layer_manager.get_current_image() if layer.visible else None
        if img is not None:
            state.push_undo()
            state.selection_manager.delete_selection(state.layer_manager)
            self.update_current_image_from_selected_layer()
            # Clear selection after delete
            state.selection_manager.clear_selection()
            self.selecting = False
            self.region_start = None
            self.region_current = None
            self.update()
    
    
    def _deselect_area(self, pos):
        """Deselect area at position (right-click) - simplified"""
        pos = self._maybe_snap_widget_pos(pos)
        from core.state import state
        if not state.selection_manager.has_selection():
            return
        
        # Convert screen coordinates to image coordinates
        scale = self._get_scale()
        offset_x, offset_y = self._get_canvas_offset()
        x = int((pos.x() - offset_x) / scale)
        y = int((pos.y() - offset_y) / scale)
        
        if state.selection_manager.mask is not None:
            h, w = state.selection_manager.mask.shape
            if 0 <= x < w and 0 <= y < h:
                # Remove this pixel from selection
                state.selection_manager.mask[y, x] = False
                # If no pixels left, clear selection
                if not np.any(state.selection_manager.mask):
                    state.selection_manager.clear_selection()
                else:
                    state.selection_manager._update_bounds()
        
        self.update()

    def lasso_select(self, points):
        """Lasso selection using polygon points"""
        from core.state import state
        layer = state.layer_manager.get_current_layer()
        img = state.layer_manager.get_current_image()
        if img is None or layer is None:
            return
        
        h, w = img.shape[:2]
        
        # Convert screen points to image coordinates
        scale = self._get_scale()
        offset_x, offset_y = self._get_canvas_offset()
        
        image_points = []
        for point in points:
            x = int((point.x() - offset_x) / scale)
            y = int((point.y() - offset_y) / scale)
            if 0 <= x < w and 0 <= y < h:
                image_points.append((x, y))
        
        if len(image_points) < 3:
            return
        
        # Use simplified selection manager
        state.selection_manager.lasso_select(image_points, img.shape)
        self.update()

    def select_all(self):
        """Select the entire image"""
        from core.state import state
        layer = state.layer_manager.get_current_layer()
        img = state.layer_manager.get_current_image()
        if img is None or layer is None:
            return
        
        state.selection_manager.select_all(img.shape)
        self.update()

    def invert_selection(self):
        """Invert the current selection"""
        from core.state import state
        layer = state.layer_manager.get_current_layer()
        img = state.layer_manager.get_current_image()
        if img is None:
            return
        state.selection_manager.invert_selection(img.shape)
        self.update()

    def expand_selection(self, pixels=1):
        """Expand selection by specified number of pixels"""
        from core.state import state
        state.selection_manager.expand_selection(pixels)
        self.update()

    def contract_selection(self, pixels=1):
        """Contract selection by specified number of pixels"""
        from core.state import state
        state.selection_manager.contract_selection(pixels)
        self.update()

    def update_current_image_from_selected_layer(self):
        # Ensure required attributes exist (safety check)
        if not hasattr(self, 'current_image'):
            self.current_image = None
        
        # PERFORMANCE: Only copy if the reference changed
        current_frame = state.layer_manager.get_current_frame()
        if current_frame and current_frame.image is not None:
            # Check if image reference changed (avoid unnecessary copy)
            if not hasattr(self, 'current_image') or self.current_image is not current_frame.image:
                self.current_image = current_frame.image
                # Invalidate QImage cache when image changes
                self._cached_qimage = None
                self._cached_image_hash = None
            self.update()  # Use update() instead of repaint() - allows Qt to optimize
        else:
            if self.current_image is not None:
                self.current_image = None
                self._cached_qimage = None
                self._cached_image_hash = None
                self.update()
        # Update the preview box when the current image changes
        self._update_preview_box()

    def on_undo_redo(self):
        self.update_current_image_from_selected_layer()
        self.update()
        self._update_preview_box()

    def paintEvent(self, event):
        super().paintEvent(event)
        from core.state import state
        painter = QPainter(self)
        try:
            # Ensure required attributes exist (safety check)
            if not hasattr(self, 'show_composite'):
                self.show_composite = False
            if not hasattr(self, 'current_image'):
                self.current_image = None
                
            w, h = self.width(), self.height()
            lm = state.layer_manager
            frame_idx = lm.current_frame
            
            # Choose between individual layer view and composite view
            if self.show_composite:
                # Show composite of all visible layers in depth order
                img = lm.composite_layers(frame_idx)
            else:
                # Show only the current layer during editing
                current_layer = lm.get_current_layer()
                img = state.layer_manager.get_current_image() if current_layer.visible else None

            # Draw outer background (outside the image area) using theme color
            outer_bg = self._custom_colors.get('canvas_outer_bg', self._theme.get('canvas_outer_bg', '#23272e'))
            painter.fillRect(0, 0, w, h, QColor(outer_bg))
            
            # Initialize variables for later use (in case img is None)
            scale = 1.0
            offset_x = 0
            offset_y = 0
            draw_w = 0
            draw_h = 0
            ih = 0
            iw = 0
            
            # Draw checkerboard background only inside the image area
            # PERFORMANCE: Use cached checkerboard pattern
            if img is not None:
                ih, iw, ch = img.shape
                base_scale = min(w / iw, h / ih)
                scale = base_scale * self.zoom_level
                draw_w = int(iw * scale)
                draw_h = int(ih * scale)
                offset_x = (w - draw_w) // 2 + self.pan_offset.x()
                offset_y = (h - draw_h) // 2 + self.pan_offset.y()
                checker_size = int(self.checker_size * self.zoom_level)
                
                # Generate or reuse cached checkerboard pattern
                if (self._checkerboard_pixmap is None or 
                    self._checkerboard_size_cached != checker_size):
                    # Create checkerboard pattern pixmap
                    pattern_size = max(checker_size * 2, 32)  # At least 2x2 pattern
                    self._checkerboard_pixmap = QPixmap(pattern_size, pattern_size)
                    checker_painter = QPainter(self._checkerboard_pixmap)
                    color1 = QColor("#ffffff")
                    color2 = QColor("#b0b0b0")
                    for py in range(0, pattern_size, checker_size):
                        for px in range(0, pattern_size, checker_size):
                            if ((px // checker_size) + (py // checker_size)) % 2 == 0:
                                checker_painter.fillRect(px, py, checker_size, checker_size, color1)
                            else:
                                checker_painter.fillRect(px, py, checker_size, checker_size, color2)
                    checker_painter.end()
                    self._checkerboard_size_cached = checker_size
                
                # Draw tiled checkerboard pattern
                if self._checkerboard_pixmap:
                    for ty in range(offset_y, offset_y + draw_h, self._checkerboard_pixmap.height()):
                        for tx in range(offset_x, offset_x + draw_w, self._checkerboard_pixmap.width()):
                            painter.drawPixmap(tx, ty, self._checkerboard_pixmap)
            # Draw the image (either current layer or composite)
            if img is not None:
                # Variables already set above, but recalculate to be sure
                ih, iw, ch = img.shape
                base_scale = min(w / iw, h / ih)
                scale = base_scale * self.zoom_level
                draw_w = int(iw * scale)
                draw_h = int(ih * scale)
                offset_x = (w - draw_w) // 2 + self.pan_offset.x()
                offset_y = (h - draw_h) // 2 + self.pan_offset.y()
                # PERFORMANCE: Cache QImage - only recreate when image data changes
                # Use image id and scale as cache key (faster than hashing entire image)
                image_id = id(img)
                scale_key = (draw_w, draw_h, scale)
                
                if (self._cached_qimage is None or 
                    self._cached_image_hash != image_id or
                    not hasattr(self, '_cached_scale_hash') or
                    self._cached_scale_hash != scale_key):
                    # Create QImage from NumPy array (only when needed)
                    bytes_per_line = ch * iw
                    img_copy = np.ascontiguousarray(img)
                    qimg = QImage(img_copy.data, iw, ih, bytes_per_line, QImage.Format_RGBA8888)
                    if scale != 1.0:
                        qimg = qimg.scaled(draw_w, draw_h, Qt.KeepAspectRatio, Qt.FastTransformation)
                    self._cached_qimage = qimg
                    self._cached_image_hash = image_id
                    self._cached_scale_hash = scale_key
                
                # Use cached QImage
                if self._cached_qimage:
                    painter.drawImage(offset_x, offset_y, self._cached_qimage)
                # Draw a visible border around the image area
                accent = self._custom_colors.get('accent', self._theme['accent'])
                border_pen = QPen(QColor(accent), 3)
                painter.setPen(border_pen)
                painter.drawRect(offset_x, offset_y, draw_w-1, draw_h-1)

            # --- Onion Skin Overlay Rendering (draw overlays ON TOP of current frame) ---
            onion_skin_toggle = getattr(self, 'onion_skin_master_toggle', None)
            if onion_skin_toggle is not None:
                onion_skin_enabled = onion_skin_toggle.isChecked()
            else:
                onion_skin_enabled = False
            if onion_skin_enabled and img is not None:
                ih, iw, ch = img.shape
                base_scale = min(w / iw, h / ih)
                scale = base_scale * self.zoom_level
                draw_w = int(iw * scale)
                draw_h = int(ih * scale)
                offset_x = (w - draw_w) // 2 + self.pan_offset.x()
                offset_y = (h - draw_h) // 2 + self.pan_offset.y()
                def draw_onion_overlay(src_img, color_hex, opacity, visible, label=None):
                    """PERFORMANCE: Cached onion skin overlay rendering"""
                    if src_img is None or not visible or opacity == 0:
                        return
                    
                    # Cache key based on image ID, color, opacity, and scale
                    img_id = id(src_img)
                    cache_key = (img_id, color_hex, opacity, draw_w, draw_h, scale)
                    
                    # Check cache
                    if cache_key in self._onion_skin_cache:
                        cached_qimg = self._onion_skin_cache[cache_key]
                        painter.drawImage(offset_x, offset_y, cached_qimg)
                        return
                    
                    # Cache miss - generate overlay
                    qcolor = QColor(color_hex)
                    color = np.array([qcolor.red(), qcolor.green(), qcolor.blue()], dtype=np.uint8)
                    arr = src_img.copy()
                    arr[..., 0] = color[0]  # R
                    arr[..., 1] = color[1]  # G
                    arr[..., 2] = color[2]  # B
                    arr[..., 3] = (arr[..., 3].astype(np.float32) * (opacity / 255.0)).astype(np.uint8)
                    qimg = QImage(arr.data, iw, ih, ch * iw, QImage.Format_RGBA8888)
                    if scale != 1.0:
                        qimg = qimg.scaled(draw_w, draw_h, Qt.KeepAspectRatio, Qt.FastTransformation)
                    
                    # Store in cache (limit cache size to prevent memory issues)
                    if len(self._onion_skin_cache) > 50:
                        # Clear oldest entries (simple FIFO)
                        keys_to_remove = list(self._onion_skin_cache.keys())[:10]
                        for key in keys_to_remove:
                            del self._onion_skin_cache[key]
                    
                    self._onion_skin_cache[cache_key] = qimg
                    painter.drawImage(offset_x, offset_y, qimg)
                
                # Get current layer for onion skin settings
                current_layer = lm.get_current_layer()
                
                # --- Current Layer Onion Skin (prev/next only) ---
                settings = current_layer.onion_skin_settings
                # Previous Frame (if enabled and exists)
                if settings['prev']['visible'] and frame_idx > 0:
                    prev_img = current_layer.get_frame(frame_idx - 1).image
                    draw_onion_overlay(prev_img, settings['prev']['color'], settings['prev']['opacity'], True, label='current-prev')
                # Next Frame (if enabled and exists)
                if settings['next']['visible'] and frame_idx < len(current_layer.frames) - 1:
                    next_img = current_layer.get_frame(frame_idx + 1).image
                    draw_onion_overlay(next_img, settings['next']['color'], settings['next']['opacity'], True, label='current-next')
                # --- Other Layers Onion Skin (prev, current, next) ---
                for idx, layer in enumerate(lm.layers):
                    if idx == lm.current_layer or not layer.visible:
                        continue
                    oset = layer.onion_skin_settings
                    # Previous Frame
                    if oset['prev']['visible'] and frame_idx > 0:
                        prev_img = layer.get_frame(frame_idx - 1).image
                        draw_onion_overlay(prev_img, oset['prev']['color'], oset['prev']['opacity'], True, label=f'other-{idx}-prev')
                    # Current Frame
                    if oset['current']['visible']:
                        curr_img = layer.get_frame(frame_idx).image
                        draw_onion_overlay(curr_img, oset['current']['color'], oset['current']['opacity'], True, label=f'other-{idx}-current')
                    # Next Frame
                    if oset['next']['visible'] and frame_idx < len(layer.frames) - 1:
                        next_img = layer.get_frame(frame_idx + 1).image
                        draw_onion_overlay(next_img, oset['next']['color'], oset['next']['opacity'], True, label=f'other-{idx}-next')

            # --- Draw grid overlay if enabled ---
            # Determine grid settings (global or per-layer)
            use_global = getattr(state, 'global_grid', False)
            layer = lm.get_current_layer()
            if use_global:
                grid_visible = getattr(state, 'grid_visible', False)
                grid_size = getattr(state, 'grid_size', 16)
                grid_color = getattr(state, 'grid_color', '#888888')
                grid_rot = getattr(state, 'grid_rotation', 0)
            else:
                grid_visible = getattr(layer, 'grid_visible', None)
                if grid_visible is None:
                    grid_visible = getattr(state, 'grid_visible', False)
                grid_size = getattr(layer, 'grid_size', None)
                if grid_size is None:
                    grid_size = getattr(state, 'grid_size', 16)
                grid_color = getattr(layer, 'grid_color', None)
                if grid_color is None:
                    grid_color = getattr(state, 'grid_color', '#888888')
                grid_rot = getattr(layer, 'grid_rotation', None)
                if grid_rot is None:
                    grid_rot = getattr(state, 'grid_rotation', 0)
            if grid_visible and img is not None:
                # PERFORMANCE: Cache grid lines - only recalculate when grid/zoom/pan changes
                grid_cache_key = (grid_size, grid_rot, grid_color, scale, offset_x, offset_y, draw_w, draw_h, iw, ih)
                
                if (self._grid_lines_cache is None or self._grid_cache_key != grid_cache_key):
                    # Cache miss - calculate grid lines
                    from math import radians, cos, sin
                    angle = radians(grid_rot)
                    cos_a = cos(angle)
                    sin_a = sin(angle)
                    
                    cx = offset_x + draw_w / 2
                    cy = offset_y + draw_h / 2
                    
                    vertical_lines = []
                    horizontal_lines = []
                    
                    # Pre-calculate vertical lines
                    for x in range(0, iw+1, grid_size):
                        x0 = int(x * scale) + offset_x
                        y1, y2 = offset_y, offset_y + draw_h
                        x0r1 = cos_a * (x0 - cx) - sin_a * (y1 - cy) + cx
                        y0r1 = sin_a * (x0 - cx) + cos_a * (y1 - cy) + cy
                        x0r2 = cos_a * (x0 - cx) - sin_a * (y2 - cy) + cx
                        y0r2 = sin_a * (x0 - cx) + cos_a * (y2 - cy) + cy
                        vertical_lines.append((int(x0r1), int(y0r1), int(x0r2), int(y0r2)))
                    
                    # Pre-calculate horizontal lines
                    for y in range(0, ih+1, grid_size):
                        y0 = int(y * scale) + offset_y
                        x1, x2 = offset_x, offset_x + draw_w
                        x0r1 = cos_a * (x1 - cx) - sin_a * (y0 - cy) + cx
                        y0r1 = sin_a * (x1 - cx) + cos_a * (y0 - cy) + cy
                        x0r2 = cos_a * (x2 - cx) - sin_a * (y0 - cy) + cx
                        y0r2 = sin_a * (x2 - cx) + cos_a * (y0 - cy) + cy
                        horizontal_lines.append((int(x0r1), int(y0r1), int(x0r2), int(y0r2)))
                    
                    # Store in cache
                    self._grid_lines_cache = (vertical_lines, horizontal_lines)
                    self._grid_cache_key = grid_cache_key
                
                # Use cached grid lines
                pen = QPen(QColor(grid_color), 1)
                painter.setPen(pen)
                vertical_lines, horizontal_lines = self._grid_lines_cache
                
                # Draw cached vertical lines
                for x0r1, y0r1, x0r2, y0r2 in vertical_lines:
                    painter.drawLine(x0r1, y0r1, x0r2, y0r2)
                
                # Draw cached horizontal lines
                for x0r1, y0r1, x0r2, y0r2 in horizontal_lines:
                    painter.drawLine(x0r1, y0r1, x0r2, y0r2)
            # Draw overlays (selection, guides, etc.) as before
            # (Keep all overlay/selection drawing logic unchanged)
            if hasattr(self, 'line_preview') and self.line_preview:
                # Use the correct button color for line preview
                color = state.current_left_color if self.active_button == Qt.LeftButton else state.current_right_color
                pen = QPen(QColor(color), max(1, state.current_radius), Qt.SolidLine)
                painter.setPen(pen)
                painter.drawLine(self.line_start, self.line_end)
            # Draw rectangle selection preview
            if self.selecting and self.region_start and self.region_current:
                # Ensure scale and offsets are available for preview
                if img is None:
                    preview_scale = self._get_scale()
                    preview_offset_x, preview_offset_y = self._get_canvas_offset()
                else:
                    preview_scale = scale
                    preview_offset_x = offset_x
                    preview_offset_y = offset_y
                selection_color_hex = self._custom_colors.get('selection_outline', self._theme.get('accent', '#61afef'))
                selection_color = QColor(selection_color_hex)
                state.selection_manager.draw_rectangle_preview(
                    painter, self.region_start, self.region_current, preview_scale, preview_offset_x, preview_offset_y, selection_color
                )
            
            if hasattr(self, 'shape_preview') and self.shape_preview:
                # Use the correct button color for shape preview
                color = state.current_left_color if self.active_button == Qt.LeftButton else state.current_right_color
                pen = QPen(QColor(color), max(1, state.current_radius), Qt.SolidLine)
                painter.setPen(pen)
                if state.current_tool == 'rect':
                    painter.drawRect(self.shape_start.x(), self.shape_start.y(), self.shape_end.x() - self.shape_start.x(), self.shape_end.y() - self.shape_start.y())
                elif state.current_tool == 'ellipse':
                    painter.drawEllipse(self.shape_start.x(), self.shape_start.y(), self.shape_end.x() - self.shape_start.x(), self.shape_end.y() - self.shape_start.y())
                elif state.current_tool == 'star':
                    # Use exact same coordinate handling as ellipse preview
                    x_min, x_max = sorted([self.shape_start.x(), self.shape_end.x()])
                    y_min, y_max = sorted([self.shape_start.y(), self.shape_end.y()])
                    center_x = (x_min + x_max) // 2
                    center_y = (y_min + y_max) // 2
                    radius = min(x_max - x_min, y_max - y_min) // 2
                    if radius >= 5:
                        # Draw 5-pointed star - use both width and height to fill the entire bounding box
                        import math
                        points = []
                        width = x_max - x_min
                        height = y_max - y_min
                        outer_radius_x = width // 2
                        outer_radius_y = height // 2
                        inner_radius_x = outer_radius_x * 0.4
                        inner_radius_y = outer_radius_y * 0.4
                        
                        for i in range(10):
                            angle = i * math.pi / 5
                            if i % 2 == 0:
                                # Outer points - use width/2 for x and height/2 for y
                                x = center_x + int(outer_radius_x * math.cos(angle))
                                y = center_y + int(outer_radius_y * math.sin(angle))
                            else:
                                # Inner points - use width/2 for x and height/2 for y
                                x = center_x + int(inner_radius_x * math.cos(angle))
                                y = center_y + int(inner_radius_y * math.sin(angle))
                            points.append(QPoint(x, y))
                        
                        for i in range(len(points)):
                            painter.drawLine(points[i], points[(i + 2) % len(points)])
                elif state.current_tool == 'polygon':
                    # Use exact same coordinate handling as ellipse preview
                    x_min, x_max = sorted([self.shape_start.x(), self.shape_end.x()])
                    y_min, y_max = sorted([self.shape_start.y(), self.shape_end.y()])
                    center_x = (x_min + x_max) // 2
                    center_y = (y_min + y_max) // 2
                    radius = min(x_max - x_min, y_max - y_min) // 2
                    if radius >= 5:
                        # Draw hexagon - use both width and height to fill the entire bounding box
                        import math
                        points = []
                        width = x_max - x_min
                        height = y_max - y_min
                        for i in range(6):
                            angle = i * math.pi / 3
                            # Use width/2 for x and height/2 for y to fill the entire bounding box
                            x = center_x + int((width // 2) * math.cos(angle))
                            y = center_y + int((height // 2) * math.sin(angle))
                            points.append(QPoint(x, y))
                        
                        for i in range(len(points)):
                            painter.drawLine(points[i], points[(i + 1) % len(points)])
                elif state.current_tool == 'triangle':
                    # Use exact same coordinate handling as ellipse preview
                    x_min, x_max = sorted([self.shape_start.x(), self.shape_end.x()])
                    y_min, y_max = sorted([self.shape_start.y(), self.shape_end.y()])
                    center_x = (x_min + x_max) // 2
                    center_y = (y_min + y_max) // 2
                    radius = min(x_max - x_min, y_max - y_min) // 2
                    if radius >= 5:
                        # Draw triangle (equilateral)
                        import math
                        points = []
                        # Top point
                        points.append(QPoint(center_x, center_y - radius))
                        # Bottom left point
                        points.append(QPoint(center_x - int(radius * 0.866), center_y + int(radius * 0.5)))
                        # Bottom right point
                        points.append(QPoint(center_x + int(radius * 0.866), center_y + int(radius * 0.5)))
                        
                        for i in range(len(points)):
                            painter.drawLine(points[i], points[(i + 1) % len(points)])
            # Draw selection overlay using selection manager
            # Draw selection using selection manager (simplified system)
            scale = self._get_scale()
            offset_x, offset_y = self._get_canvas_offset()
            
            # Draw selection overlay with improved visuals and handles
            if state.selection_manager.has_selection():
                # Get selection color from settings/theme
                selection_color_hex = self._custom_colors.get('selection_outline', self._theme.get('accent', '#61afef'))
                selection_color = QColor(selection_color_hex)
                # Show handles unless we're currently transforming
                show_handles = not (state.selection_manager.is_moving or state.selection_manager.is_resizing)
                state.selection_manager.draw_selection_overlay(painter, scale, offset_x, offset_y, selection_color, show_handles)
        finally:
            if painter.isActive():
                painter.end()
        
    def force_layer_frame_switch(self):
        # Clear all drawing state
        self.drawing = False
        self.last_pos = None
        state.selection_manager.clear_selection()
        self.selecting = False
        self.region_start = None
        self.region_current = None
        self.brush_selecting = False
        self.lasso_selecting = False
        self.lasso_points = []
        self.line_preview = False
        self.shape_preview = False
        
        # Force a complete image refresh
        self.current_image = None
        self.update_current_image_from_selected_layer()
        self.update()
        self.repaint()
        self._update_preview_box()

    def toggle_composite_view(self):
        """Toggle between individual layer view and composite view."""
        self.show_composite = not self.show_composite
        self.update()

    def _fill_triangle(self, img, x1, y1, x2, y2, x3, y3, color):
        """Fill a triangle using barycentric coordinates"""
        # Find bounding box
        min_x = max(0, min(x1, x2, x3))
        max_x = min(img.shape[1] - 1, max(x1, x2, x3))
        min_y = max(0, min(y1, y2, y3))
        max_y = min(img.shape[0] - 1, max(y1, y2, y3))
        
        # Barycentric coordinates
        def barycentric(x, y):
            denominator = ((y2 - y3) * (x1 - x3) + (x3 - x2) * (y1 - y3))
            if denominator == 0:
                return False, 0, 0, 0
            w1 = ((y2 - y3) * (x - x3) + (x3 - x2) * (y - y3)) / denominator
            w2 = ((y3 - y1) * (x - x3) + (x1 - x3) * (y - y3)) / denominator
            w3 = 1.0 - w1 - w2
            return True, w1, w2, w3
        
        # Fill triangle
        for y in range(min_y, max_y + 1):
            for x in range(min_x, max_x + 1):
                valid, w1, w2, w3 = barycentric(x, y)
                if valid and w1 >= 0 and w2 >= 0 and w3 >= 0:
                    img[y, x] = color

    def _fill_triangle_mask(self, mask, x1, y1, x2, y2, x3, y3):
        """Fill a triangle in a boolean mask"""
        # Find bounding box
        min_x = max(0, min(x1, x2, x3))
        max_x = min(mask.shape[1] - 1, max(x1, x2, x3))
        min_y = max(0, min(y1, y2, y3))
        max_y = min(mask.shape[0] - 1, max(y1, y2, y3))
        
        # Barycentric coordinates
        def barycentric(x, y):
            denominator = ((y2 - y3) * (x1 - x3) + (x3 - x2) * (y1 - y3))
            if denominator == 0:
                return False, 0, 0, 0
            w1 = ((y2 - y3) * (x - x3) + (x3 - x2) * (y - y3)) / denominator
            w2 = ((y3 - y1) * (x - x3) + (x1 - x3) * (y - y3)) / denominator
            w3 = 1.0 - w1 - w2
            return True, w1, w2, w3
        
        # Fill triangle in mask
        for y in range(min_y, max_y + 1):
            for x in range(min_x, max_x + 1):
                valid, w1, w2, w3 = barycentric(x, y)
                if valid and w1 >= 0 and w2 >= 0 and w3 >= 0:
                    mask[y, x] = True

    def _draw_line_mask(self, mask, x1, y1, x2, y2, thickness):
        """Draw a line in a boolean mask with thickness"""
        # Bresenham's line algorithm with thickness
        dx = abs(x2 - x1)
        dy = abs(y2 - y1)
        x, y = x1, y1
        sx = 1 if x1 < x2 else -1
        sy = 1 if y1 < y2 else -1
        
        if dx > dy:
            err = dx / 2.0
            while x != x2:
                # Draw thick line
                for i in range(-thickness//2, thickness//2 + 1):
                    for j in range(-thickness//2, thickness//2 + 1):
                        nx, ny = x + i, y + j
                        if 0 <= nx < mask.shape[1] and 0 <= ny < mask.shape[0]:
                            mask[ny, nx] = True
                err -= dy
                if err < 0:
                    y += sy
                    err += dx
                x += sx
        else:
            err = dy / 2.0
            while y != y2:
                # Draw thick line
                for i in range(-thickness//2, thickness//2 + 1):
                    for j in range(-thickness//2, thickness//2 + 1):
                        nx, ny = x + i, y + j
                        if 0 <= nx < mask.shape[1] and 0 <= ny < mask.shape[0]:
                            mask[ny, nx] = True
                err -= dx
                if err < 0:
                    x += sx
                    err += dy
                y += sy

class PreviewBox(QWidget):
    def __init__(self, parent=None, width=160, height=120):
        super().__init__(parent)
        self.setFixedSize(width, height)
        self.border_color = QColor(60, 60, 60)
        self.checker_size = 8
        self._theme = get_theme(settings.theme)
        self._custom_colors = getattr(settings, 'custom_colors', {})
        self.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)

    def set_theme(self, theme, custom_colors=None):
        self._theme = theme
        self._custom_colors = custom_colors or {}
        border = self._custom_colors.get('canvas_border', self._theme['canvas_border'])
        self.border_color = QColor(border)
        self.update()

    def paintEvent(self, event):
        painter = QPainter(self)
        w, h = self.width(), self.height()
        # Fill background with theme panel color
        panel_bg = self._custom_colors.get('panel', self._theme['panel'])
        painter.fillRect(0, 0, w, h, QColor(panel_bg))
        lm = state.layer_manager
        frame_idx = lm.current_frame
        
        # Always show composite in preview box for final result
        composite = lm.composite_layers(frame_idx)
        
        if composite is not None:
            ih, iw, ch = composite.shape
            scale = min((w-8) / iw, (h-8) / ih)  # 4px padding each side
            draw_w = int(iw * scale)
            draw_h = int(ih * scale)
            offset_x = (w - draw_w) // 2
            offset_y = (h - draw_h) // 2
            # Draw checkerboard only in image area
            checker_size = self.checker_size
            color1 = QColor("#ffffff")
            color2 = QColor("#b0b0b0")
            for y in range(offset_y, offset_y + draw_h, checker_size):
                for x in range(offset_x, offset_x + draw_w, checker_size):
                    if ((x // checker_size) + (y // checker_size)) % 2 == 0:
                        painter.fillRect(x, y, checker_size, checker_size, color1)
                    else:
                        painter.fillRect(x, y, checker_size, checker_size, color2)
            bytes_per_line = ch * iw
            qimg = QImage(composite.data, iw, ih, bytes_per_line, QImage.Format_RGBA8888)
            if scale != 1.0:
                qimg = qimg.scaled(draw_w, draw_h, Qt.KeepAspectRatio, Qt.FastTransformation)
            painter.drawImage(offset_x, offset_y, qimg)
            # Draw a border around the image area
            border_color = self._custom_colors.get('accent', self._theme['accent'])
            pen = QPen(QColor(border_color), 2)
            painter.setPen(pen)
            painter.drawRect(offset_x, offset_y, draw_w-1, draw_h-1)
        else:
            # No image, just draw border for clarity
            border_color = self._custom_colors.get('accent', self._theme['accent'])
            pen = QPen(QColor(border_color), 2)
            painter.setPen(pen)
            painter.drawRect(3, 3, w-7, h-7)
