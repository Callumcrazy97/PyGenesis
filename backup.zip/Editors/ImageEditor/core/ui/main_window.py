from PySide6.QtWidgets import QMainWindow, QWidget, QHBoxLayout, QVBoxLayout, QMenuBar, QFileDialog, QLabel, QPushButton, QSizePolicy, QSpacerItem, QDialog, QMessageBox
from PySide6.QtCore import Qt
from PySide6.QtGui import QAction, QShortcut, QKeySequence
from ui.dialogs import PreferencesDialog
from ui.dialogs import MergeReplaceDialog, UnifiedEffectDialog, EFFECT_REGISTRY, OriginSelectionDialog
from ui.character_creator_dialog import CharacterCreatorDialog
from services.effect_processor import EffectProcessor

from core.settings import settings
from core.themes import get_theme, THEMES
from core.state import state
from Core.Debug import debug
from ui.preview import CheckerboardCanvas
# Canvas_2D is imported lazily when GPU canvas is enabled to avoid import errors
from ui.panels.left_panel import LeftPanel
from ui.panels.right_panel import RightPanel
from ui.timeline import TimelineWidget
import os
import json
import datetime

# Import heavy modules - but they only load when this module is imported
# Since Image Editor is now loaded asynchronously in SpriteEditor, this doesn't block
import numpy as np
import cv2
from PIL import Image

LEFT_PANEL_WIDTH = 120
RIGHT_PANEL_WIDTH = 200

class MapAnimationSystem:
    """Biome-specific animation system for 2D maps."""
    
    def __init__(self):
        self.biome_animation_rules = {
            'Ocean': {
                'water_animations': ['shoreline_waves', 'ocean_currents'],
                'land_animations': ['coastal_foam'],
                'weather_animations': ['rain_effects', 'fog_effects']
            },
            'Desert': {
                'sand_animations': ['sand_dunes'],
                'oasis_animations': ['wind_sway'],
                'weather_animations': ['fog_effects']
            },
            'Forest': {
                'tree_animations': ['wind_sway'],
                'ground_animations': ['wind_sway'],
                'weather_animations': ['rain_effects', 'fog_effects']
            },
            'Snow': {
                'snow_animations': ['snow_drift'],
                'wind_animations': ['wind_sway'],
                'weather_animations': ['fog_effects']
            },
            'Jungle': {
                'tree_animations': ['wind_sway'],
                'ground_animations': ['wind_sway'],
                'weather_animations': ['rain_effects', 'fog_effects']
            },
            'Minecraft': {
                'water_animations': ['shoreline_waves'],
                'land_animations': ['wind_sway'],
                'weather_animations': ['rain_effects']
            },
            'Island': {
                'water_animations': ['shoreline_waves', 'ocean_currents'],
                'land_animations': ['wind_sway'],
                'weather_animations': ['rain_effects', 'fog_effects']
            },
            'Continental': {
                'water_animations': ['shoreline_waves'],
                'land_animations': ['wind_sway'],
                'weather_animations': ['rain_effects', 'fog_effects']
            },
            'Archipelago': {
                'water_animations': ['shoreline_waves', 'ocean_currents'],
                'land_animations': ['wind_sway'],
                'weather_animations': ['rain_effects', 'fog_effects']
            }
        }
    
    def get_available_animations(self, map_type, base_map):
        """Get animations available for this biome and map."""
        # Get biome-specific rules
        biome_animations = self.biome_animation_rules.get(map_type, {})
        
        # Detect features in the map
        features = self._detect_features(base_map, map_type)
        
        # Filter animations based on detected features
        available = {}
        for category, animations in biome_animations.items():
            for animation in animations:
                if self._is_animation_applicable(animation, features, map_type):
                    available[animation] = {
                        'name': self._get_animation_display_name(animation),
                        'description': self._get_animation_description(animation),
                        'pixel_count': self._count_animation_pixels(animation, features)
                    }
        
        return available
    
    def _detect_features(self, base_map, map_type):
        """Detect specific features for localized animation."""
        img_array = np.array(base_map)
        h, w = img_array.shape[:2]
        
        features = {}
        
        # Detect water areas
        water_mask = self._get_water_pixels(img_array)
        features['water_areas'] = water_mask
        
        # Detect land areas
        land_mask = self._get_land_pixels(img_array)
        features['land_areas'] = land_mask
        
        # Detect shorelines (water-land boundaries)
        if np.any(water_mask) and np.any(land_mask):
            features['shorelines'] = self._detect_shorelines(water_mask, land_mask)
        
        # Detect forest/grass areas (green pixels)
        green_mask = self._get_green_pixels(img_array)
        features['vegetation_areas'] = green_mask
        
        # Detect sand areas (yellow/brown pixels)
        sand_mask = self._get_sand_pixels(img_array)
        features['sand_areas'] = sand_mask
        
        # Detect snow areas (white/light pixels)
        snow_mask = self._get_snow_pixels(img_array)
        features['snow_areas'] = snow_mask
        
        return features
    
    def _get_water_pixels(self, img_array):
        """Detect water pixels (blue tones)."""
        # Convert to HSV for better color detection
        hsv = self._rgb_to_hsv(img_array)
        # Water typically has high saturation and blue hue
        water_mask = (hsv[:, :, 0] > 0.4) & (hsv[:, :, 0] < 0.7) & (hsv[:, :, 1] > 0.3)
        return water_mask
    
    def _get_land_pixels(self, img_array):
        """Detect land pixels (non-water)."""
        water_mask = self._get_water_pixels(img_array)
        return ~water_mask
    
    def _get_green_pixels(self, img_array):
        """Detect vegetation pixels (green tones)."""
        hsv = self._rgb_to_hsv(img_array)
        # Green vegetation has green hue
        green_mask = (hsv[:, :, 0] > 0.2) & (hsv[:, :, 0] < 0.4) & (hsv[:, :, 1] > 0.2)
        return green_mask
    
    def _get_sand_pixels(self, img_array):
        """Detect sand pixels (yellow/brown tones)."""
        hsv = self._rgb_to_hsv(img_array)
        # Sand has yellow/brown hue
        sand_mask = (hsv[:, :, 0] > 0.05) & (hsv[:, :, 0] < 0.2) & (hsv[:, :, 1] > 0.1)
        return sand_mask
    
    def _get_snow_pixels(self, img_array):
        """Detect snow pixels (white/light tones)."""
        hsv = self._rgb_to_hsv(img_array)
        # Snow has low saturation and high value
        snow_mask = (hsv[:, :, 1] < 0.2) & (hsv[:, :, 2] > 0.8)
        return snow_mask
    
    def _detect_shorelines(self, water_mask, land_mask):
        """Detect water-land boundaries with wiggle room."""
        # Simple dilation using numpy (avoid scipy dependency)
        # Find boundaries by dilating water mask
        shoreline = self._dilate_mask(water_mask, iterations=1) & land_mask
        
        # Add wiggle room (2-3 pixels)
        shoreline = self._dilate_mask(shoreline, iterations=2)
        
        return shoreline
    
    def _dilate_mask(self, mask, iterations=1):
        """Simple dilation using numpy operations."""
        result = mask.copy()
        for _ in range(iterations):
            # Create shifted versions
            shifted_up = np.roll(result, -1, axis=0)
            shifted_down = np.roll(result, 1, axis=0)
            shifted_left = np.roll(result, -1, axis=1)
            shifted_right = np.roll(result, 1, axis=1)
            
            # Combine with original
            result = result | shifted_up | shifted_down | shifted_left | shifted_right
            
            # Handle edges
            result[0, :] = result[0, :] | result[1, :]  # Top edge
            result[-1, :] = result[-1, :] | result[-2, :]  # Bottom edge
            result[:, 0] = result[:, 0] | result[:, 1]  # Left edge
            result[:, -1] = result[:, -1] | result[:, -2]  # Right edge
        
        return result
    
    def _rgb_to_hsv(self, rgb_array):
        """Convert RGB array to HSV."""
        # Simple RGB to HSV conversion
        r, g, b = rgb_array[:, :, 0], rgb_array[:, :, 1], rgb_array[:, :, 2]
        r, g, b = r / 255.0, g / 255.0, b / 255.0
        
        max_val = np.maximum(np.maximum(r, g), b)
        min_val = np.minimum(np.minimum(r, g), b)
        diff = max_val - min_val
        
        # Hue
        h = np.zeros_like(max_val)
        # Avoid division by zero
        valid_diff = diff > 0
        h[valid_diff & (max_val == r)] = (60 * ((g[valid_diff & (max_val == r)] - b[valid_diff & (max_val == r)]) / diff[valid_diff & (max_val == r)]) + 360) % 360
        h[valid_diff & (max_val == g)] = 60 * ((b[valid_diff & (max_val == g)] - r[valid_diff & (max_val == g)]) / diff[valid_diff & (max_val == g)]) + 120
        h[valid_diff & (max_val == b)] = 60 * ((r[valid_diff & (max_val == b)] - g[valid_diff & (max_val == b)]) / diff[valid_diff & (max_val == b)]) + 240
        h[diff == 0] = 0
        h = h / 360.0
        
        # Saturation
        s = np.where(max_val == 0, 0, np.where(valid_diff, diff / max_val, 0))
        
        # Value
        v = max_val
        
        return np.stack([h, s, v], axis=2)
    
    def _is_animation_applicable(self, animation, features, map_type):
        """Check if animation is applicable to detected features."""
        if animation == 'shoreline_waves':
            return 'shorelines' in features and np.any(features['shorelines'])
        elif animation == 'ocean_currents':
            return 'water_areas' in features and np.any(features['water_areas'])
        elif animation == 'wind_sway':
            return ('vegetation_areas' in features and np.any(features['vegetation_areas'])) or \
                   ('land_areas' in features and np.any(features['land_areas']))
        elif animation == 'sand_dunes':
            return 'sand_areas' in features and np.any(features['sand_areas'])
        elif animation == 'snow_drift':
            return 'snow_areas' in features and np.any(features['snow_areas'])
        elif animation in ['rain_effects', 'fog_effects']:
            return True  # Weather effects can apply to any map
        return False
    
    def _get_animation_display_name(self, animation):
        """Get display name for animation."""
        names = {
            'shoreline_waves': 'Shoreline Waves',
            'ocean_currents': 'Ocean Currents',
            'wind_sway': 'Wind Sway',
            'sand_dunes': 'Sand Dunes',
            'snow_drift': 'Snow Drift',
            'rain_effects': 'Rain Effects',
            'fog_effects': 'Fog Effects'
        }
        return names.get(animation, animation.title())
    
    def _get_animation_description(self, animation):
        """Get description for animation."""
        descriptions = {
            'shoreline_waves': 'Animate water edges with wave effects',
            'ocean_currents': 'Subtle water movement in deep areas',
            'wind_sway': 'Trees and grass moving in wind',
            'sand_dunes': 'Shifting sand patterns',
            'snow_drift': 'Snow movement and drift effects',
            'rain_effects': 'Rain overlay animation',
            'fog_effects': 'Fog and mist effects'
        }
        return descriptions.get(animation, 'Animation effect')
    
    def _count_animation_pixels(self, animation, features):
        """Count pixels that will be affected by animation."""
        if animation == 'shoreline_waves' and 'shorelines' in features:
            return np.sum(features['shorelines'])
        elif animation == 'ocean_currents' and 'water_areas' in features:
            return np.sum(features['water_areas'])
        elif animation == 'wind_sway' and 'vegetation_areas' in features:
            return np.sum(features['vegetation_areas'])
        elif animation == 'sand_dunes' and 'sand_areas' in features:
            return np.sum(features['sand_areas'])
        elif animation == 'snow_drift' and 'snow_areas' in features:
            return np.sum(features['snow_areas'])
        elif animation in ['rain_effects', 'fog_effects']:
            # Weather effects affect entire map
            return features.get('water_areas', np.array([])).size if features.get('water_areas') is not None else 0
        return 0

def build_global_stylesheet(theme, custom_colors):
    text_color = custom_colors.get('text', theme['text'])
    accent = custom_colors.get('accent', theme['accent'])
    panel_bg = custom_colors.get('panel', theme['panel'])
    bg = custom_colors.get('background', theme['background'])
    return f'''
        QMainWindow, QWidget, QMenuBar, QMenu, QDialog, QLabel, QPushButton, QComboBox, QTabWidget, QFrame {{
            color: {text_color};
            background: {panel_bg};
        }}
        QDialog {{ background: {panel_bg}; }}
        QMenuBar {{ background: {panel_bg}; }}
        QMenu {{ background: {panel_bg}; }}
        QPushButton {{ background: {panel_bg}; color: {text_color}; }}
        QComboBox {{ background: {panel_bg}; color: {text_color}; }}
        QTabWidget::pane {{ background: {panel_bg}; }}
        QFrame {{ background: {panel_bg}; }}
        QMainWindow {{ background: {bg}; }}
        QPushButton:focus {{ border: 1px solid {accent}; }}
    '''

class TitleBar(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.parent = parent
        layout = QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)
        layout.addSpacerItem(QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum))
        self.setLayout(layout)


class MainWindow(QMainWindow):
    def __init__(self, parent=None, embedded_mode=False, app=None):
        super().__init__(parent)
        self.embedded_mode = embedded_mode
        self.app = app
        self.setWindowTitle("Modular Pixel Art Editor")
        
        # Initialize animation system
        self.animation_system = MapAnimationSystem()
        
        if not embedded_mode:
            self.setGeometry(100, 100, 900, 700)
        
        self._setup_layout()
        
        # Always setup menu and status bar regardless of embedded mode
        self._setup_menu()
        self._setup_status_bar()
        
        self.apply_theme()
    
    def get_central_widget(self):
        """Get the central widget for embedding in other applications"""
        return self.centralWidget()
    
    def set_embedded_mode(self, embedded=True):
        """Set embedded mode - but keep all functionality"""
        self.embedded_mode = embedded
        # Don't hide anything - keep full functionality regardless of mode

    def show_merge_replace_dialog(self):
        dlg = MergeReplaceDialog(self)
        if dlg.exec() == QDialog.Accepted:
            return dlg.get_mode()
        return None

    def force_canvas_and_preview_refresh(self):
        """Force a full refresh of the canvas and preview box."""
        if hasattr(self, 'canvas') and self.canvas:
            self.canvas.update_current_image_from_selected_layer()
            self.canvas.update()
        if hasattr(self, 'right_panel') and hasattr(self.right_panel, 'preview_box'):
            self.right_panel.preview_box.update()

    def _setup_menu(self):
        """Setup menu bar using component"""
        from ui.components.menu_bar import ImageEditorMenuBar
        menu_bar_component = ImageEditorMenuBar(self)
        menubar = menu_bar_component.create_menu_bar()
        self.pixel_perfect_action = menu_bar_component.pixel_perfect_action
        self.setMenuBar(menubar)
        menu_bar_component.setup_shortcuts()
    
    def flip_frame_horizontal(self):
        """Flip current frame horizontally for all layers"""
        self._apply_frame_transform_to_all_layers(lambda img: np.fliplr(img))
    
    def flip_frame_vertical(self):
        """Flip current frame vertically for all layers"""
        self._apply_frame_transform_to_all_layers(lambda img: np.flipud(img))
    
    def rotate_frame_90(self):
        """Rotate current frame 90° clockwise for all layers"""
        self._apply_frame_transform_to_all_layers(lambda img: np.rot90(img, k=-1))
    
    def rotate_frame_180(self):
        """Rotate current frame 180° for all layers"""
        self._apply_frame_transform_to_all_layers(lambda img: np.rot90(img, k=2))
    
    def duplicate_frame(self):
        """Duplicate current frame for all layers"""
        lm = state.layer_manager
        if not lm.layers:
            return
        
        # Push undo state
        state.history.push_undo()
        
        frame_idx = lm.current_frame
        
        # Duplicate frame in all layers
        for layer in lm.layers:
            if 0 <= frame_idx < len(layer.frames):
                frame = layer.get_frame(frame_idx)
                # Create new frame with same image using deepcopy
                new_frame = frame.__deepcopy__(None)
                # Insert after current frame
                layer.frames.insert(frame_idx + 1, new_frame)
                # Create history for new frame
                from core.history import HistoryManager
                layer.frame_histories[frame_idx + 1] = HistoryManager(state, max_undo=10)
        
        # Update frame histories indices for frames after the inserted one
        for layer in lm.layers:
            # Shift frame history indices
            new_histories = {}
            for old_idx, history in layer.frame_histories.items():
                if old_idx > frame_idx:
                    new_histories[old_idx + 1] = history
                elif old_idx <= frame_idx:
                    new_histories[old_idx] = history
            layer.frame_histories = new_histories
        
        # Refresh timeline
        if hasattr(self, 'timeline'):
            self.timeline._update_timeline()
        
        # Refresh canvas
        self.force_canvas_and_preview_refresh()
    
    def clear_frame(self):
        """Clear current frame for all layers"""
        lm = state.layer_manager
        if not lm.layers:
            return
        
        # Push undo state
        state.history.push_undo()
        
        frame_idx = lm.current_frame
        
        # Clear frame in all layers
        for layer in lm.layers:
            if 0 <= frame_idx < len(layer.frames):
                frame = layer.get_frame(frame_idx)
                # Clear to transparent
                frame.image = np.zeros_like(frame.image)
        
        # Refresh canvas
        self.force_canvas_and_preview_refresh()
    
    def _apply_frame_transform_to_all_layers(self, transform_func):
        """Apply a transformation function to current frame in all layers"""
        lm = state.layer_manager
        if not lm.layers:
            return
        
        # Push undo state
        state.history.push_undo()
        
        frame_idx = lm.current_frame
        
        # Apply transformation to all layers' current frame
        for layer in lm.layers:
            if 0 <= frame_idx < len(layer.frames):
                frame = layer.get_frame(frame_idx)
                if frame.image is not None and frame.image.size > 0:
                    # Apply transformation
                    frame.image = transform_func(frame.image.copy())
        
        # Refresh canvas
        self.force_canvas_and_preview_refresh()
    
    def resize_selection_dialog(self):
        """Open dialog to resize selection"""
        from PySide6.QtWidgets import QDialog, QVBoxLayout, QLabel, QSpinBox, QDialogButtonBox, QHBoxLayout
        from core.state import state
        
        if not state.selection_manager.has_selection():
            QMessageBox.information(self, "No Selection", "Please select an area first.")
            return
        
        bounds = state.selection_manager.get_selection_bounds()
        if not bounds:
            return
        
        x1, y1, x2, y2 = bounds
        current_width = x2 - x1
        current_height = y2 - y1
        
        dialog = QDialog(self)
        dialog.setWindowTitle("Resize Selection")
        layout = QVBoxLayout(dialog)
        
        # Width
        width_layout = QHBoxLayout()
        width_layout.addWidget(QLabel("Width:"))
        width_spin = QSpinBox()
        width_spin.setMinimum(1)
        width_spin.setMaximum(10000)
        width_spin.setValue(current_width)
        width_layout.addWidget(width_spin)
        layout.addLayout(width_layout)
        
        # Height
        height_layout = QHBoxLayout()
        height_layout.addWidget(QLabel("Height:"))
        height_spin = QSpinBox()
        height_spin.setMinimum(1)
        height_spin.setMaximum(10000)
        height_spin.setValue(current_height)
        height_layout.addWidget(height_spin)
        layout.addLayout(height_layout)
        
        # Buttons
        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.accepted.connect(dialog.accept)
        buttons.rejected.connect(dialog.reject)
        layout.addWidget(buttons)
        
        if dialog.exec() == QDialog.Accepted:
            new_width = width_spin.value()
            new_height = height_spin.value()
            
            # Calculate new bounds (centered on original)
            center_x = (x1 + x2) / 2
            center_y = (y1 + y2) / 2
            new_x1 = int(center_x - new_width / 2)
            new_y1 = int(center_y - new_height / 2)
            new_x2 = int(center_x + new_width / 2)
            new_y2 = int(center_y + new_height / 2)
            
            # Get image dimensions
            img = state.layer_manager.get_current_image()
            if img is not None:
                h, w = img.shape[:2]
                # Clamp to image bounds
                new_x1 = max(0, min(w, new_x1))
                new_y1 = max(0, min(h, new_y1))
                new_x2 = max(0, min(w, new_x2))
                new_y2 = max(0, min(h, new_y2))
                
                state.push_undo()
                state.selection_manager.select_rect(new_x1, new_y1, new_x2, new_y2, img.shape)
                self.force_canvas_and_preview_refresh()
    
    def separate_selection_to_layer(self):
        """Separate selected object to its own layer with frame tracking"""
        from PySide6.QtWidgets import QDialog, QVBoxLayout, QLabel, QDialogButtonBox, QRadioButton, QButtonGroup, QCheckBox
        from core.state import state
        from core.smart_layer_separation import SmartLayerSeparator
        
        if not state.selection_manager.has_selection():
            QMessageBox.information(self, "No Selection", "Please select an object first.")
            return
        
        # Get current frame image
        img = state.layer_manager.get_current_image()
        if img is None:
            QMessageBox.warning(self, "No Image", "No image in current frame.")
            return
        
        # Dialog for frame options
        dialog = QDialog(self)
        dialog.setWindowTitle("Separate to Layer")
        layout = QVBoxLayout(dialog)
        
        layout.addWidget(QLabel("Apply to:"))
        
        frame_group = QButtonGroup()
        current_frame_radio = QRadioButton("Current Frame Only")
        current_frame_radio.setChecked(True)
        frame_group.addButton(current_frame_radio, 0)
        layout.addWidget(current_frame_radio)
        
        all_frames_radio = QRadioButton("All Frames")
        frame_group.addButton(all_frames_radio, 1)
        layout.addWidget(all_frames_radio)
        
        future_frames_radio = QRadioButton("Future Frames (from current)")
        frame_group.addButton(future_frames_radio, 2)
        layout.addWidget(future_frames_radio)
        
        previous_frames_radio = QRadioButton("Previous Frames (to current)")
        frame_group.addButton(previous_frames_radio, 3)
        layout.addWidget(previous_frames_radio)
        
        layout.addWidget(QLabel(""))  # Spacer
        
        fill_gap_checkbox = QCheckBox("Fill gap left by object (inpaint)")
        fill_gap_checkbox.setChecked(True)
        layout.addWidget(fill_gap_checkbox)
        
        track_object_checkbox = QCheckBox("Track object across frames")
        track_object_checkbox.setChecked(True)
        layout.addWidget(track_object_checkbox)
        
        # Buttons
        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.accepted.connect(dialog.accept)
        buttons.rejected.connect(dialog.reject)
        layout.addWidget(buttons)
        
        if dialog.exec() != QDialog.Accepted:
            return
        
        # Get options
        frame_option = frame_group.checkedId()
        fill_gap = fill_gap_checkbox.isChecked()
        track_object = track_object_checkbox.isChecked()
        
        # Initialize separator
        separator = SmartLayerSeparator()
        
        # Detect object from selection
        selection_mask = state.selection_manager.mask
        template = separator.detect_object_in_selection(img, selection_mask)
        
        if template is None:
            QMessageBox.warning(self, "Error", "Failed to extract object from selection.")
            return
        
        # Push undo
        state.push_undo()
        
        # Create new layer
        current_layer = state.layer_manager.get_current_layer()
        new_layer = state.layer_manager.add_layer(
            state.width, state.height, state,
            name=f"Separated Object {len(state.layer_manager.layers) + 1}"
        )
        
        # Determine which frames to process
        current_frame_idx = state.layer_manager.current_frame
        total_frames = len(current_layer.frames)
        
        if frame_option == 0:  # Current frame only
            frame_indices = [current_frame_idx]
        elif frame_option == 1:  # All frames
            frame_indices = list(range(total_frames))
        elif frame_option == 2:  # Future frames
            frame_indices = list(range(current_frame_idx, total_frames))
        elif frame_option == 3:  # Previous frames
            frame_indices = list(range(0, current_frame_idx + 1))
        else:
            frame_indices = [current_frame_idx]
        
        # Process each frame
        previous_position = None
        for frame_idx in frame_indices:
            # Get frame image
            frame_img = current_layer.get_frame(frame_idx).image
            if frame_img is None:
                continue
            
            # Track object if enabled
            if track_object and previous_position is not None:
                position = separator.track_object_in_frame(frame_img, previous_position)
            elif frame_idx == current_frame_idx:
                # Use original selection bounds for current frame
                bounds = state.selection_manager.get_selection_bounds()
                if bounds:
                    x1, y1, x2, y2 = bounds
                    position = (x1, y1, x2 - x1, y2 - y1, 1.0)
                else:
                    position = None
            else:
                # First frame - use template matching
                position = separator.track_object_in_frame(frame_img, None)
            
            if position is None:
                # Object not found in this frame - skip
                continue
            
            # Extract object
            obj_image, obj_mask = separator.extract_object_from_frame(frame_img, position)
            
            if obj_image is not None:
                # Paste to new layer
                new_frame = new_layer.get_frame(frame_idx)
                if new_frame.image is None:
                    new_frame.image = np.zeros_like(frame_img)
                
                x, y, w, h = position[:4]
                # Ensure bounds are valid
                h_img, w_img = new_frame.image.shape[:2]
                x = max(0, min(w_img - w, x))
                y = max(0, min(h_img - h, y))
                w = min(w, w_img - x)
                h = min(h, h_img - y)
                
                if w > 0 and h > 0:
                    # Resize object if needed
                    if obj_image.shape[0] != h or obj_image.shape[1] != w:
                        obj_image = cv2.resize(obj_image, (w, h), interpolation=cv2.INTER_LINEAR)
                        if obj_mask is not None:
                            obj_mask = cv2.resize(obj_mask.astype(np.uint8), (w, h), interpolation=cv2.INTER_NEAREST).astype(bool)
                    
                    # Composite object onto new layer (with alpha)
                    if len(obj_image.shape) == 3 and obj_image.shape[2] == 4:
                        alpha = obj_image[:, :, 3:4] / 255.0
                        rgb = obj_image[:, :, :3]
                    elif obj_mask is not None:
                        alpha = obj_mask.astype(np.float32)[:, :, np.newaxis]
                        rgb = obj_image[:, :, :3] if len(obj_image.shape) == 3 else obj_image
                    else:
                        alpha = np.ones((h, w, 1), dtype=np.float32)
                        rgb = obj_image[:, :, :3] if len(obj_image.shape) == 3 else obj_image
                    
                    # Blend
                    region = new_frame.image[y:y+h, x:x+w]
                    if len(region.shape) == 3:
                        if region.shape[2] == 4:
                            region_rgb = region[:, :, :3]
                            region_alpha = region[:, :, 3:4] / 255.0
                        else:
                            region_rgb = region
                            region_alpha = np.ones((h, w, 1), dtype=np.float32)
                    else:
                        region_rgb = region
                        region_alpha = np.ones((h, w, 1), dtype=np.float32)
                    
                    # Composite
                    composite_alpha = alpha + region_alpha * (1 - alpha)
                    composite_rgb = (rgb * alpha + region_rgb * region_alpha * (1 - alpha)) / np.maximum(composite_alpha, 0.001)
                    
                    if len(new_frame.image.shape) == 3 and new_frame.image.shape[2] == 4:
                        new_frame.image[y:y+h, x:x+w, :3] = composite_rgb.astype(np.uint8)
                        new_frame.image[y:y+h, x:x+w, 3] = (composite_alpha * 255).astype(np.uint8).squeeze()
                    else:
                        new_frame.image[y:y+h, x:x+w] = composite_rgb.astype(np.uint8)
                
                # Fill gap in original layer if enabled
                if fill_gap:
                    gap_mask = np.zeros((frame_img.shape[0], frame_img.shape[1]), dtype=bool)
                    gap_mask[y:y+h, x:x+w] = obj_mask if obj_mask is not None else True
                    filled_img = separator.fill_gap_in_frame(frame_img, gap_mask)
                    current_layer.get_frame(frame_idx).image = filled_img
                
                # Update previous position for tracking
                previous_position = position
        
        # Refresh UI
        self.force_canvas_and_preview_refresh()
        QMessageBox.information(self, "Success", f"Object separated to new layer '{new_layer.name}'")
    
    def generate_tween_animation(self):
        """Auto-generate tween animation: select area, move it, generate tween over N frames"""
        from PySide6.QtWidgets import QDialog, QVBoxLayout, QLabel, QSpinBox, QDialogButtonBox, QHBoxLayout, QRadioButton, QButtonGroup
        from core.state import state
        
        if not state.selection_manager.has_selection():
            QMessageBox.information(self, "No Selection", "Please select an area first.")
            return
        
        # Get source position (current selection bounds)
        source_bounds = state.selection_manager.get_selection_bounds()
        if not source_bounds:
            return
        
        x1, y1, x2, y2 = source_bounds
        source_center_x = (x1 + x2) / 2
        source_center_y = (y1 + y2) / 2
        
        # Dialog for tween options
        dialog = QDialog(self)
        dialog.setWindowTitle("Generate Tween Animation")
        layout = QVBoxLayout(dialog)
        
        layout.addWidget(QLabel("Move the selection to the target position, then click OK."))
        layout.addWidget(QLabel("Source position: ({:.0f}, {:.0f})".format(source_center_x, source_center_y)))
        
        layout.addWidget(QLabel(""))  # Spacer
        
        layout.addWidget(QLabel("Number of frames:"))
        frames_spin = QSpinBox()
        frames_spin.setMinimum(2)
        frames_spin.setMaximum(1000)
        frames_spin.setValue(10)
        layout.addWidget(frames_spin)
        
        layout.addWidget(QLabel(""))  # Spacer
        
        layout.addWidget(QLabel("Apply to:"))
        frame_group = QButtonGroup()
        current_frame_radio = QRadioButton("Current Frame Only")
        current_frame_radio.setChecked(True)
        frame_group.addButton(current_frame_radio, 0)
        layout.addWidget(current_frame_radio)
        
        all_frames_radio = QRadioButton("All Frames")
        frame_group.addButton(all_frames_radio, 1)
        layout.addWidget(all_frames_radio)
        
        future_frames_radio = QRadioButton("Future Frames (from current)")
        frame_group.addButton(future_frames_radio, 2)
        layout.addWidget(future_frames_radio)
        
        previous_frames_radio = QRadioButton("Previous Frames (to current)")
        frame_group.addButton(previous_frames_radio, 3)
        layout.addWidget(previous_frames_radio)
        
        # Buttons
        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.accepted.connect(dialog.accept)
        buttons.rejected.connect(dialog.reject)
        layout.addWidget(buttons)
        
        if dialog.exec() != QDialog.Accepted:
            return
        
        # Get target position (current selection bounds after user moved it)
        target_bounds = state.selection_manager.get_selection_bounds()
        if not target_bounds:
            return
        
        tx1, ty1, tx2, ty2 = target_bounds
        target_center_x = (tx1 + tx2) / 2
        target_center_y = (ty1 + ty2) / 2
        
        num_frames = frames_spin.value()
        frame_option = frame_group.checkedId()
        
        # Calculate which frames to process
        current_frame_idx = state.layer_manager.current_frame
        total_frames = len(state.layer_manager.get_current_layer().frames)
        
        if frame_option == 0:  # Current frame only
            frame_indices = [current_frame_idx]
        elif frame_option == 1:  # All frames
            frame_indices = list(range(total_frames))
        elif frame_option == 2:  # Future frames
            frame_indices = list(range(current_frame_idx, total_frames))
        elif frame_option == 3:  # Previous frames
            frame_indices = list(range(0, current_frame_idx + 1))
        else:
            frame_indices = [current_frame_idx]
        
        # Push undo
        state.push_undo()
        
        # Generate tween for each frame
        for frame_idx in frame_indices:
            # Calculate interpolation factor for this frame
            if len(frame_indices) > 1:
                frame_range = frame_indices[-1] - frame_indices[0]
                if frame_range > 0:
                    t = (frame_idx - frame_indices[0]) / frame_range
                else:
                    t = 0.0
            else:
                t = 0.0
            
            # Linear interpolation
            interp_x = source_center_x + (target_center_x - source_center_x) * t
            interp_y = source_center_y + (target_center_y - source_center_y) * t
            
            # Calculate offset needed
            offset_x = interp_x - source_center_x
            offset_y = interp_y - source_center_y
            
            # Move selection for this frame
            # Note: This is a simplified approach - in a full implementation,
            # you'd want to transform the actual image content, not just the selection
            # For now, we'll create keyframes for rigging if a rig exists
            layer = state.layer_manager.get_current_layer()
            if layer.rig and layer.rig.selected_bone:
                # Use rigging system for animation
                if layer.rig_animation is None:
                    from core.rigging import RigAnimation
                    layer.rig_animation = RigAnimation(layer.rig)
                
                # Set keyframe with interpolated position
                # This is a placeholder - full implementation would transform the image
                layer.rig_animation.add_keyframe(frame_idx)
        
        QMessageBox.information(self, "Tween Generated", f"Tween animation generated over {num_frames} frames.")
        self.force_canvas_and_preview_refresh()
    
    def _setup_shortcuts(self):
        """Setup keyboard shortcuts for tools and common actions"""
        from PySide6.QtGui import QKeySequence, QShortcut
        
        # Tool shortcuts - organized by category
        shortcuts = {
            # === BRUSHES ===
            'B': 'brush',           # Brush
            'P': 'pencil',          # Pencil
            'M': 'marker',          # Marker
            'C': 'calligraphy',     # Calligraphy
            'A': 'airbrush',        # Airbrush
            'L': 'line',            # Line
            
            # === TOOLS ===
            'E': 'eraser',          # Eraser
            'F': 'fill',            # Fill
            'I': 'eyedropper',      # Eyedropper
            'D': 'dither',          # Dither
            'G': 'gradient',        # Gradient
            
            # === SHAPES ===
            'R': 'rect',            # Rectangle
            'O': 'ellipse',         # Ellipse (O for Oval)
            'S': 'star',            # Star
            'Y': 'polygon',         # Polygon (Y for shape)
            
            # === SELECTIONS ===
            'V': 'region',          # Region select
            'W': 'magic_wand',      # Magic Wand
            'X': 'spray',           # Spray select
            
            # === EDITING ===
            'Delete': 'clear_selection',    # Clear selection
            
            # === FRAME CONTROL ===
            'Space': 'toggle_play',         # Play/Pause
            'Left': 'prev_frame',           # Previous frame
            'Right': 'next_frame',          # Next frame
            
            # === BRUSH SIZE ===
            '[': 'decrease_radius',         # Decrease brush size
            ']': 'increase_radius',         # Increase brush size
            '1': 'radius_1',               # Brush size 1
            '2': 'radius_2',               # Brush size 2
            '3': 'radius_3',               # Brush size 3
            '4': 'radius_4',               # Brush size 4
            '5': 'radius_5',               # Brush size 5
            '6': 'radius_6',               # Brush size 6
            '7': 'radius_7',               # Brush size 7
            '8': 'radius_8',               # Brush size 8
            '9': 'radius_9',               # Brush size 9
            '0': 'radius_10',              # Brush size 10
            
            # === ZOOM ===
            'Ctrl+Plus': 'zoom_in',        # Zoom in
            'Ctrl+Minus': 'zoom_out',      # Zoom out
            'Ctrl+0': 'zoom_reset',        # Reset zoom
            
            # === ADDITIONAL USEFUL SHORTCUTS ===
            'Ctrl+S': 'save',              # Save
            'Ctrl+O': 'open',              # Open
            'Ctrl+N': 'new',               # New
            'Ctrl+A': 'select_all',        # Select All
            'Escape': 'clear_selection',   # Clear selection (alternative)
            'Tab': 'toggle_panels',        # Toggle panels
        }
        
        self.shortcuts = {}
        for key, action in shortcuts.items():
            shortcut = QShortcut(QKeySequence(key), self)
            shortcut.activated.connect(lambda checked, a=action: self._handle_shortcut(a))
            self.shortcuts[action] = shortcut

    def _handle_shortcut(self, action):
        """Handle keyboard shortcuts"""
        # === BRUSHES ===
        if action in ['brush', 'pencil', 'marker', 'calligraphy', 'airbrush', 'line']:
            self.left_panel.select_tool(action)
            
        # === TOOLS ===
        elif action in ['eraser', 'fill', 'eyedropper', 'dither', 'gradient']:
            self.left_panel.select_tool(action)
            
        # === SHAPES ===
        elif action in ['rect', 'ellipse', 'star', 'polygon']:
            self.left_panel.select_shape_tool(action)
            
        # === SELECTIONS ===
        elif action in ['region', 'magic_wand', 'spray']:
            self.left_panel.select_selection_tool(action)
            
        # === EDITING ===
        elif action == 'cut_selection':
            self.canvas.cut_selection()
        elif action == 'copy_selection':
            self.canvas.copy_selection()
        elif action == 'paste_selection':
            self.canvas.paste_selection()
        elif action == 'clear_selection':
            self.canvas.clear_selection()
        elif action == 'undo':
            self.undo()
        elif action == 'redo':
            self.redo()
            
        # === FRAME CONTROL ===
        elif action == 'toggle_play':
            self.right_panel.toggle_play()
        elif action == 'prev_frame':
            self.right_panel.prev_frame()
        elif action == 'next_frame':
            self.right_panel.next_frame()
            
        # === BRUSH SIZE ===
        elif action == 'decrease_radius':
            self.left_panel.decrease_radius()
        elif action == 'increase_radius':
            self.left_panel.increase_radius()
        elif action.startswith('radius_'):
            radius = int(action.split('_')[1])
            if 1 <= radius <= 10:
                from core.state import state
                state.current_radius = radius
                self.left_panel.radius_input.setText(str(radius))
                self.left_panel.brush_preview.update()
                
        # === ZOOM ===
        elif action == 'zoom_in':
            self.left_panel.zoom_in()
        elif action == 'zoom_out':
            self.left_panel.zoom_out()
        elif action == 'zoom_reset':
            self.left_panel.zoom_reset()
            
        # === ADDITIONAL SHORTCUTS ===
        elif action == 'save':
            self.save_project()
        elif action == 'open':
            self.open_project()
        elif action == 'new':
            self.new_project()
        elif action == 'select_all':
            self.canvas.select_all()
        elif action == 'toggle_panels':
            self.toggle_panels()

    def save_project(self):
        """Save the current project."""
        # Placeholder - implement actual save functionality
        print("Save project (not implemented yet)")

    def open_project(self):
        """Open a project."""
        # Placeholder - implement actual open functionality
        print("Open project (not implemented yet)")

    def new_project(self):
        """Create a new project."""
        # Placeholder - implement actual new project functionality
        print("New project (not implemented yet)")

    def toggle_panels(self):
        """Toggle panel visibility."""
        # Placeholder - implement panel toggling
        print("Toggle panels (not implemented yet)")

    def _setup_status_bar(self):
        """Setup status bar using component"""
        from ui.components.status_bar import ImageEditorStatusBar
        status_bar_component = ImageEditorStatusBar(self)
        statusbar = status_bar_component.create_status_bar()
        self.status_bar = statusbar
        self.status_bar_component = status_bar_component  # Store reference for updates
        # Store label references for backward compatibility
        self.tool_status = status_bar_component.tool_status
        self.position_status = status_bar_component.position_status
        self.size_status = status_bar_component.size_status
        self.zoom_status = status_bar_component.zoom_status
    
    def _update_position_status(self, x, y):
        """Update position status when mouse moves over canvas"""
        if self.status_bar_component:
            self.status_bar_component._update_position_status(x, y)

    def show_preferences_dialog(self):
        dlg = PreferencesDialog(self)
        if dlg.exec():
            self.apply_theme()

    def new_canvas(self):
        """Create a new canvas with the NewImageDialog."""
        from ui.dialogs import NewImageDialog
        dlg = NewImageDialog(self)
        if dlg.exec() == 0:  # User cancelled
            return
        
        width, height = dlg.get_size()
        
        # Clear current state
        state.set_size(width, height)
        
        # Clear all layers and create a new background layer
        if hasattr(self, 'canvas') and self.canvas:
            self.canvas.set_image_size(width, height)
            self.canvas.update()
        
        # Force refresh of all panels
        self.force_canvas_and_preview_refresh()

    def apply_theme(self):
        theme = get_theme(settings.theme)
        custom_colors = getattr(settings, 'custom_colors', {})
        self.setStyleSheet(build_global_stylesheet(theme, custom_colors))
        self.left_panel.update_theme(theme, custom_colors)
        self.right_panel.update_theme(theme, custom_colors)
        self.canvas.set_theme(theme, custom_colors)

    def _setup_layout(self):
        central_widget = QWidget(self)
        v_layout = QVBoxLayout(central_widget)
        v_layout.setContentsMargins(0, 0, 0, 0)
        v_layout.setSpacing(0)
        # Add custom title bar
        self.title_bar = TitleBar(self)
        v_layout.addWidget(self.title_bar)
        # Existing main layout
        h_layout = QHBoxLayout()
        h_layout.setContentsMargins(0, 0, 0, 0)
        h_layout.setSpacing(0)
        self.left_panel = LeftPanel(self)
        h_layout.addWidget(self.left_panel)
        
        # Choose canvas implementation based on settings
        if settings.use_gpu_canvas:
            try:
                # Use GPU-accelerated Canvas_2D (lazy import)
                from Core.Rendering.Canvas_2D import Canvas_2D
                self.canvas = Canvas_2D(self)
                # Set pixel-perfect filtering from settings
                self.canvas.set_pixel_perfect(settings.pixel_perfect_filtering)
                # Add compatibility methods that integrate with the layer system
                self._setup_gpu_canvas_compatibility()
                debug("Using GPU-accelerated Canvas_2D")
            except Exception as e:
                debug(f"Failed to initialize GPU canvas, falling back to CheckerboardCanvas: {e}")
                import traceback
                traceback.print_exc()
                # Fall back to traditional canvas
                self.canvas = CheckerboardCanvas(self)
        else:
            # Use traditional QPainter-based CheckerboardCanvas
            self.canvas = CheckerboardCanvas(self)
        
        self.left_panel.canvas = self.canvas  # Give left panel direct canvas reference
        h_layout.addWidget(self.canvas, 1)
        self.right_panel = RightPanel(self, canvas=self.canvas, app=self.app)
        h_layout.addWidget(self.right_panel)
        
        # Connect canvas to state for selection clearing on tool change
        from core.state import state
        state._canvas_ref = self.canvas
        v_layout.addLayout(h_layout)
        
        # Add timeline
        self.timeline = TimelineWidget(self)
        self.timeline.setVisible(False)  # Hidden by default
        v_layout.addWidget(self.timeline)
        
        self.setCentralWidget(central_widget)
        # Ensure onion skin toggle is accessible from canvas
        self.canvas.onion_skin_master_toggle = self.right_panel.onion_skin_master_toggle
        
        # Connect timeline signals
        self.timeline.frame_selected.connect(self._on_frame_selected)
        self.timeline.frame_navigated.connect(self._on_frame_navigated)
        self.timeline.layer_selected.connect(self._on_layer_selected)
    
    def _setup_gpu_canvas_compatibility(self):
        """Setup compatibility layer for GPU canvas to work with existing code"""
        from core.state import state
        
        # Override update_current_image_from_selected_layer to actually work
        original_method = self.canvas.update_current_image_from_selected_layer
        def update_image():
            current_frame = state.layer_manager.get_current_frame()
            if current_frame and current_frame.image is not None:
                # PERFORMANCE: Only copy if reference changed (avoid unnecessary copies)
                image = current_frame.image
                if self.canvas.current_image is not image:
                    # Use dirty rectangles if available, otherwise full update
                    if state.has_dirty_regions() and hasattr(self.canvas, 'update_dirty_regions'):
                        # Store the image reference (no copy needed)
                        self.canvas.current_image = image
                        # Update dirty regions with partial texture updates
                        self.canvas.update_dirty_regions()
                    else:
                        # Full image update (still needs to upload to GPU, so copy is acceptable)
                        self.canvas.set_image(image.copy())
            else:
                self.canvas.set_image(None)
            
            # Update selection mask
            if state.selection_manager.has_selection():
                self.canvas.set_selection_mask(state.selection_manager.mask)
            else:
                self.canvas.set_selection_mask(None)
            
            # Update preview box
            if hasattr(self.canvas, '_update_preview_box'):
                self.canvas._update_preview_box()
        
        self.canvas.update_current_image_from_selected_layer = update_image
        
        # Override selection methods to delegate to state
        def cut_selection():
            # TODO: Implement GPU canvas selection cutting
            debug("GPU Canvas: cut_selection not yet implemented")
        
        def copy_selection():
            # TODO: Implement GPU canvas selection copying
            debug("GPU Canvas: copy_selection not yet implemented")
        
        def paste_selection():
            # TODO: Implement GPU canvas selection pasting
            debug("GPU Canvas: paste_selection not yet implemented")
        
        def select_all():
            # TODO: Implement GPU canvas select all
            debug("GPU Canvas: select_all not yet implemented")
        
        def clear_selection():
            state.selection_manager.clear_selection()
            self.canvas.set_selection_mask(None)
            self.canvas.update()
        
        self.canvas.cut_selection = cut_selection
        self.canvas.copy_selection = copy_selection
        self.canvas.paste_selection = paste_selection
        self.canvas.select_all = select_all
        self.canvas.clear_selection = clear_selection
        
        # Connect mouse position signal
        self.canvas.mouse_position_changed.connect(self._update_position_status)
        
        # Initialize with current image
        update_image()
    
    def toggle_timeline(self):
        """Toggle timeline visibility"""
        self.timeline.setVisible(not self.timeline.isVisible())
        if self.timeline.isVisible():
            # Update timeline with all layers
            all_layers = state.layer_manager.layers
            self.timeline.set_layers(all_layers)
            self.timeline.set_current_frame(state.layer_manager.current_frame)
    
    def _on_frame_selected(self, frame_index):
        """Handle frame selection from timeline - navigate to the selected frame"""
        # Navigate to the frame when clicked
        state.layer_manager.current_frame = frame_index
        # Force a complete frame switch to ensure proper image loading
        self.canvas.force_layer_frame_switch()
        self.right_panel.update_frame_label()
        self.timeline.set_current_frame(frame_index)
    
    def _on_frame_navigated(self, frame_index):
        """Handle frame navigation from timeline"""
        state.layer_manager.current_frame = frame_index
        # Force a complete frame switch to ensure proper image loading
        self.canvas.force_layer_frame_switch()
        self.right_panel.update_frame_label()
        self.timeline.set_current_frame(frame_index)
    
    def _on_layer_selected(self, layer_index):
        """Handle layer selection from timeline"""
        if 0 <= layer_index < len(state.layer_manager.layers):
            state.layer_manager.current_layer = layer_index
            self.canvas.update_current_image_from_selected_layer()
            self.canvas.update()
            self.right_panel.update_frame_label()
            self.right_panel.layers_list.update_tabs()

    def undo(self):
        """Undo the last action"""
        from core.state import state
        state.undo()
        self.canvas.on_undo_redo()
        self.left_panel.update_color_buttons()
        self.right_panel.update_frame_label()
    
    def redo(self):
        """Redo the last undone action"""
        from core.state import state
        state.redo()
        self.canvas.on_undo_redo()
        self.left_panel.update_color_buttons()
        self.right_panel.update_frame_label()
    
    def cut_selection(self):
        """Cut the current selection to clipboard"""
        if hasattr(self, 'canvas') and self.canvas:
            self.canvas.cut_selection()
    
    def copy_selection(self):
        """Copy the current selection to clipboard"""
        if hasattr(self, 'canvas') and self.canvas:
            self.canvas.copy_selection()
    
    def paste_selection(self):
        """Paste from clipboard to current position"""
        if hasattr(self, 'canvas') and self.canvas:
            self.canvas.paste_selection()

    def import_image(self):
        file_path, _ = QFileDialog.getOpenFileName(self, "Import Image", "", "Image Files (*.png *.jpg *.jpeg *.bmp)")
        if not file_path:
            return
        
        # Use PIL for initial import to properly handle transparency
        from PIL import Image
        pil_img = Image.open(file_path)
        
        # Convert to RGBA to ensure we have alpha channel
        if pil_img.mode != 'RGBA':
            pil_img = pil_img.convert('RGBA')
        
        # Convert to numpy array (this gives us RGBA format)
        img = np.array(pil_img)
        
        h, w = img.shape[:2]
        state.history.push_undo()
        # Replace first layer, first frame
        layer = state.layer_manager.get_current_layer()
        frame = layer.get_frame(0)
        frame.image = img.copy()
        state.width = w
        state.height = h
        self.canvas.set_image_size(w, h)
        self.canvas.update()

    def import_sprite_sheet(self):
        """Import a sprite sheet and auto-slice it into frames with tags"""
        from PySide6.QtWidgets import QFileDialog, QDialog
        from ui.sprite_sheet_importer import SpriteSheetImporterDialog
        
        file_path, _ = QFileDialog.getOpenFileName(
            self, "Import Sprite Sheet", "", 
            "Image Files (*.png *.jpg *.jpeg *.bmp);;All Files (*)"
        )
        if not file_path:
            return
        
        # Show import dialog
        dialog = SpriteSheetImporterDialog(self, image_path=file_path)
        if dialog.exec() != QDialog.Accepted:
            return
        
        # Get results (dict with 'frames', 'output_mode', 'grid_info')
        dialog_result = dialog.get_results()
        if not dialog_result or not dialog_result.get('frames'):
            return
        
        frames = dialog_result['frames']
        output_mode = dialog_result.get('output_mode', 'one_per_frame')
        grid_info = dialog_result.get('grid_info')
        
        # Push undo state
        state.history.push_undo()
        
        # Get current layer
        layer = state.layer_manager.get_current_layer()
        current_frame_idx = state.layer_manager.current_frame
        
        if output_mode == 'one_per_frame':
            # Create one frame per sprite
            start_frame_idx = len(layer.frames)
            
            # Determine canvas size from frames
            max_width = max([f['width'] for f in frames]) if frames else 32
            max_height = max([f['height'] for f in frames]) if frames else 32
            
            # Update canvas size to accommodate largest frame
            state.width = max_width
            state.height = max_height
            self.canvas.set_image_size(max_width, max_height)
            
            # Add all frames to layer
            for result in frames:
                # Create new frame
                layer.add_frame(result['width'], result['height'], state)
                frame_idx = len(layer.frames) - 1
                frame = layer.get_frame(frame_idx)
                
                # Set image
                frame.image = result['image'].copy()
                
                # Set tag
                frame.tags = [result['tag']]
                
                # Store grid metadata in layer (for first frame of batch)
                if frame_idx == start_frame_idx and grid_info:
                    is_grid = dialog.grid_radio.isChecked()
                    if is_grid:
                        layer.grid_metadata = {
                            "mode": "sprite_sheet",
                            "cell_width": grid_info.get('cell_w'),
                            "cell_height": grid_info.get('cell_h'),
                            "frames_per_row": grid_info.get('cols'),
                            "alignment": "center" if dialog.center_frames_check.isChecked() else "top"
                        }
                    else:
                        layer.grid_metadata = {
                            "mode": "sprite_sheet",
                            "cell_width": grid_info.get('cell_w') if grid_info else None,
                            "cell_height": grid_info.get('cell_h') if grid_info else None,
                            "frames_per_row": grid_info.get('cols') if grid_info else None,
                            "alignment": "top"
                        }
            
            # Update current frame to first new frame
            state.layer_manager.current_frame = start_frame_idx
        
        else:  # single_sheet mode
            # Create a single frame with all sprites arranged in a grid
            if not frames:
                return
            
            # Calculate grid layout
            num_sprites = len(frames)
            # Use grid_info if available, otherwise calculate
            if grid_info:
                cols = grid_info.get('cols', int(np.ceil(np.sqrt(num_sprites))))
                cell_w = grid_info.get('cell_w', max([f['width'] for f in frames]))
                cell_h = grid_info.get('cell_h', max([f['height'] for f in frames]))
            else:
                cols = int(np.ceil(np.sqrt(num_sprites)))
                cell_w = max([f['width'] for f in frames])
                cell_h = max([f['height'] for f in frames])
            
            rows = (num_sprites + cols - 1) // cols
            
            # Create canvas for grid
            canvas_w = cols * cell_w
            canvas_h = rows * cell_h
            canvas = np.zeros((canvas_h, canvas_w, 4), dtype=np.uint8)
            
            # Place sprites in grid
            for i, result in enumerate(frames):
                row = i // cols
                col = i % cols
                x = col * cell_w
                y = row * cell_h
                
                sprite = result['image']
                sh, sw = sprite.shape[:2]
                
                # Center sprite in its cell if needed
                x_offset = (cell_w - sw) // 2
                y_offset = (cell_h - sh) // 2
                
                y_end = min(y + y_offset + sh, canvas_h)
                x_end = min(x + x_offset + sw, canvas_w)
                y_src_end = y_end - (y + y_offset)
                x_src_end = x_end - (x + x_offset)
                
                if y_src_end > 0 and x_src_end > 0:
                    if sprite.shape[2] == 4:
                        # Blend with alpha
                        alpha = sprite[:y_src_end, :x_src_end, 3:4] / 255.0
                        canvas[y+y_offset:y_end, x+x_offset:x_end, :3] = (
                            canvas[y+y_offset:y_end, x+x_offset:x_end, :3] * (1 - alpha) +
                            sprite[:y_src_end, :x_src_end, :3] * alpha
                        ).astype(np.uint8)
                        canvas[y+y_offset:y_end, x+x_offset:x_end, 3] = np.maximum(
                            canvas[y+y_offset:y_end, x+x_offset:x_end, 3],
                            sprite[:y_src_end, :x_src_end, 3]
                        )
                    else:
                        canvas[y+y_offset:y_end, x+x_offset:x_end, :3] = sprite[:y_src_end, :x_src_end, :3]
            
            # Replace current frame or create new one
            frame = layer.get_frame(current_frame_idx)
            frame.image = canvas.copy()
            
            # Update canvas size
            state.width = canvas_w
            state.height = canvas_h
            self.canvas.set_image_size(canvas_w, canvas_h)
            
            # Store grid metadata
            if grid_info:
                layer.grid_metadata = {
                    "mode": "sprite_sheet",
                    "cell_width": cell_w,
                    "cell_height": cell_h,
                    "frames_per_row": cols,
                    "alignment": "center"
                }
        
        # Update timeline
        if hasattr(self, 'timeline') and self.timeline:
            self.timeline.set_layers(state.layer_manager.layers)
            self.timeline.set_current_frame(state.layer_manager.current_frame)
        
        # Update UI
        self.canvas.update()
        if hasattr(self, 'right_panel'):
            self.right_panel.update_frame_label()
    
    def nine_slice_import(self):
        """Nine-Slice: Slice the current canvas image"""
        print("DEBUG: nine_slice_import() called")
        try:
            from ui.nine_slice_importer import NineSliceDialog
            from PySide6.QtWidgets import QMessageBox, QDialog
            
            # Get current composite image from all visible layers
            lm = state.layer_manager
            frame_idx = lm.current_frame
            
            print(f"DEBUG: Current frame index: {frame_idx}, Layers: {len(lm.layers) if lm.layers else 0}")
            
            # Check if we have any layers/frames
            if not lm.layers or len(lm.layers) == 0:
                print("DEBUG: No layers found")
                QMessageBox.warning(self, "No Image", 
                                  "Please open or create an image first before using Nine-Slice.")
                return
            
            # Get composite of all visible layers for current frame
            try:
                composite = lm.composite_layers(frame_idx)
                print(f"DEBUG: Composite shape: {composite.shape if composite is not None else 'None'}")
                if composite is None or composite.size == 0:
                    print("DEBUG: Composite is None or empty")
                    QMessageBox.warning(self, "No Image Data", 
                                      "Current frame has no image data.")
                    return
            except Exception as e:
                print(f"DEBUG: Error getting composite: {e}")
                import traceback
                traceback.print_exc()
                QMessageBox.critical(self, "Error", 
                                   f"Failed to get current image: {str(e)}")
                return
            
            print("DEBUG: Creating NineSliceDialog")
            # Create dialog with current image
            dialog = NineSliceDialog(self, image_array=composite)
            print("DEBUG: Showing dialog")
            if dialog.exec() == QDialog.Accepted:
                print("DEBUG: Dialog accepted")
                result = dialog.get_results()
                print(f"DEBUG: Dialog result: {result}")
                if result:
                    print("DEBUG: Applying nine slice result")
                    self.apply_nine_slice(result)
                else:
                    print("DEBUG: No result from dialog")
            else:
                print("DEBUG: Dialog rejected")
        except Exception as e:
            print(f"DEBUG: Error in nine_slice_import: {e}")
            import traceback
            traceback.print_exc()
            from PySide6.QtWidgets import QMessageBox
            QMessageBox.critical(self, "Error", 
                               f"Failed to open Nine-Slice dialog: {str(e)}")
    
    def apply_nine_slice(self, result):
        """Apply the Nine-Slice import results"""
        if not result or not result.get('frames'):
            return
        
        # Push undo state
        state.history.push_undo()
        
        layer = state.layer_manager.get_current_layer()
        sprites = result['frames']
        mode = result['mode']
        frame_option = result['frame_option']
        specific_frame = result['specific_frame']
        
        # Get standardized canvas dimensions from result
        canvas_width = result.get('canvas_width', result['sprite_size'][0])
        canvas_height = result.get('canvas_height', result['sprite_size'][1])
        
        import numpy as np
        
        # Verify all sprites are the correct size
        print(f"Applying Nine-Slice: {len(sprites)} sprites, canvas: {canvas_width}×{canvas_height}")
        for idx, sprite in enumerate(sprites):
            sh, sw = sprite.shape[:2]
            print(f"  Sprite {idx}: {sw}×{sh}")
            if sw != canvas_width or sh != canvas_height:
                print(f"  WARNING: Sprite {idx} size mismatch!")
        
        if mode == 'separate_frames':
            # Create one frame per sprite
            current_frame_idx = state.layer_manager.current_frame
            
            if frame_option == 'current':
                # Replace current frame with first sprite, then insert rest after
                insert_start = current_frame_idx
            elif frame_option == 'end':
                # Append at end
                insert_start = len(layer.frames)
            else:  # specific
                # Insert starting at specific frame
                insert_start = specific_frame
            
            # Process first sprite (replace or insert at start position)
            if insert_start < len(layer.frames) and frame_option == 'current':
                # Replace current frame
                frame = layer.get_frame(insert_start)
                frame.image = sprites[0].copy()
                print(f"Replaced frame {insert_start} with sprite 0")
                remaining_sprites = sprites[1:]
                insert_pos = insert_start + 1
            else:
                # Insert all sprites starting at position
                remaining_sprites = sprites
                insert_pos = insert_start
            
            # Insert remaining sprites as new frames
            for i, sprite in enumerate(remaining_sprites):
                from layers.layer import Frame
                # Get sprite dimensions (should all be same)
                sh, sw = sprite.shape[:2]
                new_frame = Frame(sw, sh)
                new_frame.image = sprite.copy()
                new_frame.tags = []
                new_frame.color_code = None
                
                # Insert at calculated position
                if insert_pos >= len(layer.frames):
                    layer.frames.append(new_frame)
                    print(f"Appended sprite {i} as frame {len(layer.frames)-1}")
                else:
                    layer.frames.insert(insert_pos, new_frame)
                    print(f"Inserted sprite {i} at frame {insert_pos}")
                insert_pos += 1
            
            # Update current frame to first new frame
            state.layer_manager.current_frame = insert_start
            
            # Update state dimensions and canvas to match sprite size
            state.width = canvas_width
            state.height = canvas_height
            if hasattr(self, 'canvas'):
                self.canvas.set_image_size(canvas_width, canvas_height)
            
            print(f"Updated canvas to {canvas_width}×{canvas_height}, current frame: {insert_start}")
        
        else:  # single_frame_grid
            # Place all sprites on one frame in a grid
            sprite_w, sprite_h = result['sprite_size']
            current_frame_idx = state.layer_manager.current_frame
            
            # Calculate grid layout
            num_sprites = len(sprites)
            cols = int(np.ceil(np.sqrt(num_sprites)))
            rows = (num_sprites + cols - 1) // cols
            
            # Create canvas for grid
            canvas_w = cols * sprite_w
            canvas_h = rows * sprite_h
            canvas = np.zeros((canvas_h, canvas_w, 4), dtype=np.uint8)
            
            # Place sprites in grid
            for i, sprite in enumerate(sprites):
                row = i // cols
                col = i % cols
                x = col * sprite_w
                y = row * sprite_h
                
                # Center sprite in its cell if needed
                sh, sw = sprite.shape[:2]
                x_offset = (sprite_w - sw) // 2
                y_offset = (sprite_h - sh) // 2
                
                y_end = min(y + y_offset + sh, canvas_h)
                x_end = min(x + x_offset + sw, canvas_w)
                y_src_end = y_end - (y + y_offset)
                x_src_end = x_end - (x + x_offset)
                
                if y_src_end > 0 and x_src_end > 0:
                    if sprite.shape[2] == 4:
                        # Blend with alpha
                        alpha = sprite[:y_src_end, :x_src_end, 3:4] / 255.0
                        canvas[y+y_offset:y_end, x+x_offset:x_end, :3] = (
                            canvas[y+y_offset:y_end, x+x_offset:x_end, :3] * (1 - alpha) +
                            sprite[:y_src_end, :x_src_end, :3] * alpha
                        ).astype(np.uint8)
                        canvas[y+y_offset:y_end, x+x_offset:x_end, 3] = np.maximum(
                            canvas[y+y_offset:y_end, x+x_offset:x_end, 3],
                            sprite[:y_src_end, :x_src_end, 3]
                        )
                    else:
                        canvas[y+y_offset:y_end, x+x_offset:x_end, :3] = sprite[:y_src_end, :x_src_end, :3]
            
            # Determine target frame
            if frame_option == 'replace_current':
                target_frame_idx = current_frame_idx
                frame = layer.get_frame(target_frame_idx)
                frame.image = canvas.copy()
            elif frame_option == 'new_frame':
                from layers.layer import Frame
                ch, cw = canvas.shape[:2]
                new_frame = Frame(cw, ch)
                new_frame.image = canvas.copy()
                new_frame.tags = []
                new_frame.color_code = None
                layer.frames.append(new_frame)
                target_frame_idx = len(layer.frames) - 1
            else:  # specific
                target_frame_idx = specific_frame
                if target_frame_idx >= len(layer.frames):
                    # Create frame if it doesn't exist
                    from layers.layer import Frame
                    ch, cw = canvas.shape[:2]
                    new_frame = Frame(cw, ch)
                    new_frame.image = canvas.copy()
                    new_frame.tags = []
                    new_frame.color_code = None
                    layer.frames.append(new_frame)
                    target_frame_idx = len(layer.frames) - 1
                else:
                    frame = layer.get_frame(target_frame_idx)
                    frame.image = canvas.copy()
            
            # Update canvas size
            state.width = canvas_w
            state.height = canvas_h
            self.canvas.set_image_size(canvas_w, canvas_h)
            
            # Update current frame
            state.layer_manager.current_frame = target_frame_idx
        
        # Force complete UI refresh
        self.force_canvas_and_preview_refresh()
        
        # Update timeline
        if hasattr(self, 'timeline'):
            self.timeline._update_timeline()
        
        # Refresh right panel
        if hasattr(self, 'right_panel'):
            self.right_panel.update_frame_label()
        
        print(f"Nine-Slice import complete: {len(sprites)} sprites imported")
    
    def _get_bounding_box(self, image_array):
        """Get bounding box of non-blank content in image"""
        if image_array is None or image_array.size == 0:
            return None
        
        h, w = image_array.shape[:2]
        
        # Create mask of non-blank pixels
        if len(image_array.shape) == 3:
            if image_array.shape[2] == 4:
                # Use alpha channel - non-transparent pixels
                mask = image_array[:, :, 3] > 10
            else:
                # Check if any channel has content
                mask = np.any(image_array > 10, axis=2)
        else:
            mask = image_array > 10
        
        if not np.any(mask):
            return None  # Entire image is blank
        
        # Find bounding box
        rows = np.any(mask, axis=1)
        cols = np.any(mask, axis=0)
        
        if not np.any(rows) or not np.any(cols):
            return None
        
        y_min, y_max = np.where(rows)[0][[0, -1]]
        x_min, x_max = np.where(cols)[0][[0, -1]]
        
        return (x_min, y_min, x_max + 1, y_max + 1)
    
    def _position_image_with_origin(self, image, target_width, target_height, origin):
        """Position an image within a target canvas based on origin"""
        h, w = image.shape[:2]
        
        # Calculate position based on origin
        if origin == "top-left":
            x_offset = 0
            y_offset = 0
        elif origin == "top-center":
            x_offset = (target_width - w) // 2
            y_offset = 0
        elif origin == "top-right":
            x_offset = target_width - w
            y_offset = 0
        elif origin == "center-left":
            x_offset = 0
            y_offset = (target_height - h) // 2
        elif origin == "center":
            x_offset = (target_width - w) // 2
            y_offset = (target_height - h) // 2
        elif origin == "center-right":
            x_offset = target_width - w
            y_offset = (target_height - h) // 2
        elif origin == "bottom-left":
            x_offset = 0
            y_offset = target_height - h
        elif origin == "bottom-center":
            x_offset = (target_width - w) // 2
            y_offset = target_height - h
        elif origin == "bottom-right":
            x_offset = target_width - w
            y_offset = target_height - h
        else:
            x_offset = 0
            y_offset = 0
        
        # Create new canvas
        result = np.zeros((target_height, target_width, 4), dtype=np.uint8)
        
        # Place image
        y_end = min(y_offset + h, target_height)
        x_end = min(x_offset + w, target_width)
        y_src_end = y_end - y_offset
        x_src_end = x_end - x_offset
        
        if y_src_end > 0 and x_src_end > 0 and y_offset >= 0 and x_offset >= 0:
            if image.shape[2] == 4:
                # Blend with alpha
                alpha = image[:y_src_end, :x_src_end, 3:4] / 255.0
                result[y_offset:y_end, x_offset:x_end, :3] = (
                    result[y_offset:y_end, x_offset:x_end, :3] * (1 - alpha) +
                    image[:y_src_end, :x_src_end, :3] * alpha
                ).astype(np.uint8)
                result[y_offset:y_end, x_offset:x_end, 3] = np.maximum(
                    result[y_offset:y_end, x_offset:x_end, 3],
                    image[:y_src_end, :x_src_end, 3]
                )
            else:
                result[y_offset:y_end, x_offset:x_end, :3] = image[:y_src_end, :x_src_end, :3]
        
        return result
    
    def crop_canvas(self):
        """Crop canvas to remove blank space on sides"""
        # Push undo state
        state.history.push_undo()
        
        layer = state.layer_manager.get_current_layer()
        current_frame_idx = state.layer_manager.current_frame
        frame = layer.get_frame(current_frame_idx)
        
        # Get bounding box of non-blank content
        bbox = self._get_bounding_box(frame.image)
        if bbox is None:
            QMessageBox.information(self, "Crop", "No content found to crop.")
            return
        
        x_min, y_min, x_max, y_max = bbox
        
        # Crop the image
        cropped = frame.image[y_min:y_max, x_min:x_max].copy()
        
        # Ask for origin
        dialog = OriginSelectionDialog(self)
        if dialog.exec() != QDialog.Accepted:
            state.history.pop_undo()  # Cancel operation
            return
        
        origin = dialog.get_origin()
        
        # Check if single frame or multi-frame
        is_single_frame = len(layer.frames) == 1
        
        if is_single_frame:
            # Resize canvas to cropped size
            new_width = x_max - x_min
            new_height = y_max - y_min
            frame.image = cropped.copy()
            state.width = new_width
            state.height = new_height
            self.canvas.set_image_size(new_width, new_height)
        else:
            # Don't resize canvas, just crop the frame
            # Position cropped content based on origin
            new_image = self._position_image_with_origin(
                cropped, state.width, state.height, origin
            )
            frame.image = new_image
        
        # Update UI
        self.canvas.update()
        if hasattr(self, 'right_panel'):
            self.right_panel.update_frame_label()
    
    def _remove_blank_space_from_frame(self, image_array):
        """Remove blank space by removing all blank rows and columns, compacting the image"""
        if image_array is None or image_array.size == 0:
            return image_array
        
        h, w = image_array.shape[:2]
        
        # Create mask of non-blank pixels
        # For RGBA images, check alpha channel
        if len(image_array.shape) == 3:
            if image_array.shape[2] == 4:
                # Use alpha channel - non-transparent pixels (alpha > threshold)
                # Lower threshold to catch near-transparent pixels
                mask = image_array[:, :, 3] > 5
            else:
                # RGB or other - check if any channel has significant content
                mask = np.any(image_array > 5, axis=2)
        else:
            mask = image_array > 5
        
        if not np.any(mask):
            return image_array  # Entire image is blank
        
        # Find ALL blank rows (rows where pixels are effectively blank/transparent)
        # Use numpy operations for efficiency
        # Check each row - if less than 0.1% of pixels are non-blank, consider it blank
        # This handles cases with noise or edge artifacts, and is more sensitive to detect blank areas
        row_content_ratio = np.sum(mask, axis=1).astype(np.float32) / w  # Ratio of non-blank pixels per row
        blank_rows = np.where(row_content_ratio < 0.001)[0]  # Rows with < 0.1% content
        
        # Find ALL blank columns (columns where pixels are effectively blank/transparent)
        col_content_ratio = np.sum(mask, axis=0).astype(np.float32) / h  # Ratio of non-blank pixels per column
        blank_cols = np.where(col_content_ratio < 0.001)[0]  # Columns with < 0.1% content
        
        # Debug: print detected blank rows/cols
        print(f"DEBUG Remove Blank Space: Found {len(blank_rows)} blank rows, {len(blank_cols)} blank cols")
        if len(blank_rows) > 0:
            print(f"DEBUG: First 20 blank rows: {blank_rows[:20]}")
        if len(blank_cols) > 0:
            print(f"DEBUG: First 20 blank cols: {blank_cols[:20]}")
        
        # Also check a sample of row content ratios for debugging
        if len(blank_rows) == 0 and h > 0:
            # Check some sample rows to see their content ratios
            sample_indices = [h//4, h//2, 3*h//4]
            for idx in sample_indices:
                if idx < h:
                    ratio = row_content_ratio[idx]
                    print(f"DEBUG: Row {idx} has {ratio*100:.2f}% content")
        
        # If no blank rows or columns found, return original
        if len(blank_rows) == 0 and len(blank_cols) == 0:
            return image_array
        
        # Remove blank rows and columns
        # Create arrays of indices to keep (all indices NOT in blank_rows/blank_cols)
        keep_rows = np.array([y for y in range(h) if y not in blank_rows])
        keep_cols = np.array([x for x in range(w) if x not in blank_cols])
        
        if len(keep_rows) == 0 or len(keep_cols) == 0:
            return image_array  # All rows or columns would be removed
        
        # Extract only the rows and columns we want to keep
        # This automatically compacts the image by removing gaps
        # Use advanced indexing to select specific rows and columns
        if len(image_array.shape) == 3:
            # For 3D array (height, width, channels)
            # First select the rows, then select the columns from the result
            compacted = image_array[keep_rows, :, :][:, keep_cols, :]
        else:
            # For 2D array - use np.ix_ for proper mesh indexing
            compacted = image_array[np.ix_(keep_rows, keep_cols)]
        
        return compacted
    
    def remove_blank_space(self):
        """Remove blank space by removing all blank rows and columns, compacting the image"""
        layer = state.layer_manager.get_current_layer()
        current_frame_idx = state.layer_manager.current_frame
        frame = layer.get_frame(current_frame_idx)
        
        # Check if there's blank space first, before pushing undo
        compacted = self._remove_blank_space_from_frame(frame.image)
        
        if compacted is None or compacted.shape == frame.image.shape:
            QMessageBox.information(self, "Remove Blank Space", "No blank space found to remove.")
            return
        
        # Ask for origin before committing changes
        dialog = OriginSelectionDialog(self)
        if dialog.exec() != QDialog.Accepted:
            return
        
        # Now push undo since we're proceeding with the operation
        state.history.push_undo()
        
        origin = dialog.get_origin()
        
        # Check if single frame or multi-frame
        is_single_frame = len(layer.frames) == 1
        
        if is_single_frame:
            # Resize canvas to compacted size
            new_height, new_width = compacted.shape[:2]
            frame.image = compacted.copy()
            state.width = new_width
            state.height = new_height
            self.canvas.set_image_size(new_width, new_height)
        else:
            # Don't resize canvas, just position compacted content
            new_image = self._position_image_with_origin(
                compacted, state.width, state.height, origin
            )
            frame.image = new_image
        
        # Update UI
        self.canvas.update()
        if hasattr(self, 'right_panel'):
            self.right_panel.update_frame_label()
    
    def export_image(self):
        file_path, _ = QFileDialog.getSaveFileName(self, "Export Image", "", "PNG Files (*.png)")
        if not file_path:
            return
        # Composite all visible layers for current frame
        lm = state.layer_manager
        frame_idx = lm.current_frame
        composite = None
        for layer in lm.layers:
            if not layer.visible:
                continue
            img = layer.get_frame(frame_idx).image
            if composite is None:
                composite = img.copy()
            else:
                alpha = img[..., 3:4] / 255.0
                composite[..., :3] = (1 - alpha) * composite[..., :3] + alpha * img[..., :3]
                composite[..., 3:4] = np.maximum(composite[..., 3:4], img[..., 3:4])
        if composite is not None:
            # Use PIL for export to properly handle transparency
            from PIL import Image
            pil_img = Image.fromarray(composite.astype(np.uint8), mode="RGBA")
            pil_img.save(file_path)

    def import_gif(self):
        file_path, _ = QFileDialog.getOpenFileName(self, "Import GIF", "", "GIF Files (*.gif)")
        if not file_path:
            return
        gif = Image.open(file_path)
        frames = []
        try:
            while True:
                frame = gif.convert("RGBA")
                arr = np.array(frame)
                frames.append(arr)
                gif.seek(gif.tell() + 1)
        except EOFError:
            pass
        if not frames:
            return
        state.history.push_undo()
        # Replace all frames in all layers with GIF frames (single layer)
        lm = state.layer_manager
        w, h = frames[0].shape[1], frames[0].shape[0]
        for layer in lm.layers:
            layer.frames = []
        lm.layers = [lm.layers[0]]  # Keep only first layer
        layer = lm.layers[0]
        layer.frames = []
        for arr in frames:
            from layers.layer import Frame
            f = Frame(w, h)
            f.image = arr.copy()
            layer.frames.append(f)
        lm.current_frame = 0
        state.width = w
        state.height = h
        self.canvas.set_image_size(w, h)
        self.canvas.update()
        self.right_panel.update_frame_label()

    def export_gif(self):
        file_path, _ = QFileDialog.getSaveFileName(self, "Export GIF", "", "GIF Files (*.gif)")
        if not file_path:
            return
        lm = state.layer_manager
        n_frames = len(lm.layers[0].frames)
        frames = []
        for frame_idx in range(n_frames):
            composite = None
            for layer in lm.layers:
                if not layer.visible:
                    continue
                img = layer.get_frame(frame_idx).image
                if composite is None:
                    composite = img.copy()
                else:
                    alpha = img[..., 3:4] / 255.0
                    composite[..., :3] = (1 - alpha) * composite[..., :3] + alpha * img[..., :3]
                    composite[..., 3:4] = np.maximum(composite[..., 3:4], img[..., 3:4])
            if composite is not None:
                pil_img = Image.fromarray(composite.astype(np.uint8), mode="RGBA")
                frames.append(pil_img)
        if frames:
            frames[0].save(file_path, save_all=True, append_images=frames[1:], duration=100, loop=0, disposal=2)

    def import_pgsprite(self):
        file_path, _ = QFileDialog.getOpenFileName(self, "Import .PgSprite", "", "PgSprite Files (*.pgsprite)")
        if not file_path:
            return
        
        from core.pgsprite_io import pgsprite_io
        if pgsprite_io.import_pgsprite(file_path, state):
            self.canvas.set_image_size(state.width, state.height)
            self.canvas.update()
            self.right_panel.update_frame_label()
            # Update timeline if visible
            if hasattr(self, 'timeline') and self.timeline.isVisible():
                current_layer = state.layer_manager.get_current_layer()
                self.timeline.set_layer(current_layer)
                self.timeline.set_current_frame(state.layer_manager.current_frame)
        else:
            QMessageBox.warning(self, "Import Error", "Failed to import .PgSprite file")

    def export_pgsprite(self):
        file_path, _ = QFileDialog.getSaveFileName(self, "Export .PgSprite", "", "PgSprite Files (*.pgsprite)")
        if not file_path:
            return
        
        from core.pgsprite_io import pgsprite_io
        if pgsprite_io.export_pgsprite(file_path, state):
            QMessageBox.information(self, "Export Success", "Project exported successfully!")
        else:
            QMessageBox.warning(self, "Export Error", "Failed to export .PgSprite file")

    # --- Effect Stubs ---
    def effect_invert(self):
        self._apply_unified_effect('invert')

    def effect_brightness(self):
        print("DEBUG: effect_brightness called")
        self._apply_unified_effect('brightness')

    def effect_contrast(self):
        self._apply_unified_effect('contrast')

    def effect_greyscale(self):
        self._apply_unified_effect('greyscale')
    
    # ==================== AI Methods ====================
    
    def _check_ai_requirements(self, required_packages: list = None) -> bool:
        """
        Check if AI requirements are installed.
        Returns True if all requirements are met, False otherwise.
        If packages are missing, directs user to Extension Manager.
        Uses the same Python executable as Extension Manager for consistency.
        """
        from core.ai_requirements import RequirementChecker
        from PySide6.QtWidgets import QMessageBox
        
        if required_packages is None:
            required_packages = ['google-generativeai']
        
        # Get Python executable from venv_manager (same as Extension Manager uses)
        python_exe = None
        try:
            # Try to get venv_manager from app
            if hasattr(self, 'app') and self.app and hasattr(self.app, 'venv_manager'):
                venv_manager = self.app.venv_manager
                if venv_manager:
                    python_exe = venv_manager.get_python_executable()
        except Exception:
            pass
        
        # Fallback to sys.executable if venv_manager not available
        if python_exe is None:
            import sys
            python_exe = sys.executable
        
        # Check for missing packages using the same Python executable as Extension Manager
        missing = []
        missing_display_names = []
        for pkg in required_packages:
            # Use the same Python executable that Extension Manager uses
            is_installed, _ = RequirementChecker.check_package(pkg, python_exe)
            if not is_installed:
                missing.append(pkg)
                display_name = RequirementChecker.get_package_display_name(pkg)
                missing_display_names.append(display_name)
        
        if missing:
            # Refresh import cache first (in case it was just installed)
            import importlib
            importlib.invalidate_caches()
            
            # Re-check packages after cache refresh (with same Python executable)
            still_missing = []
            still_missing_display = []
            for pkg in missing:
                is_installed, _ = RequirementChecker.check_package(pkg, python_exe)
                if not is_installed:
                    still_missing.append(pkg)
                    display_name = RequirementChecker.get_package_display_name(pkg)
                    still_missing_display.append(display_name)
            
            if still_missing:
                # Show message directing user to Extension Manager
                package_list = ", ".join(still_missing_display)
                QMessageBox.information(
                    self, "Package Required",
                    f"The following package(s) are required for this feature:\n\n"
                    f"{package_list}\n\n"
                    f"Please install them via Extension Manager:\n\n"
                    f"1. Go to: Tools → Extension Manager\n"
                    f"2. Search for: {', '.join(still_missing)}\n"
                    f"3. Click Install for each package\n\n"
                    f"After installing, you may need to restart PyGenesis."
                )
                return False
        
        return True
    
    def _get_ai_api_key(self) -> tuple:
        """
        Get AI API key from PyGenesis Preferences.
        Returns: (api_key, provider_name) or (None, None) if not configured
        """
        # Try to get from main app settings
        provider = None
        api_key = None
        
        if hasattr(self, 'app') and self.app and hasattr(self.app, 'settings'):
            provider = self.app.settings.get("AI_Provider", "")
            api_key = self.app.settings.get("AI_API_Key", "")
        
        # Fallback: try QApplication instance
        if not api_key:
            from PySide6.QtWidgets import QApplication
            app = QApplication.instance()
            if app and hasattr(app, 'settings'):
                provider = app.settings.get("AI_Provider", "")
                api_key = app.settings.get("AI_API_Key", "")
        
        # If no key, show instructions
        if not api_key or not api_key.strip():
            self._show_ai_key_instructions()
            return None, None
        
        return api_key.strip(), provider
    
    def _show_ai_key_instructions(self):
        """Show instructions for getting an AI API key."""
        from PySide6.QtWidgets import QMessageBox
        
        msg = QMessageBox(self)
        msg.setWindowTitle("AI API Key Required")
        msg.setIcon(QMessageBox.Information)
        msg.setText(
            "To use AI features, you need to configure an API key.\n\n"
            "How to set up:\n"
            "1. Go to: File → Preferences → AI tab\n"
            "2. Select your AI provider (Gemini, ChatGPT, etc.)\n"
            "3. Enter your API key\n"
            "4. Click OK to save\n\n"
            "Getting API keys:\n"
            "• Gemini: https://aistudio.google.com/app/apikey\n"
            "• ChatGPT: https://platform.openai.com/api-keys\n"
            "• Claude: https://console.anthropic.com/\n\n"
            "Note: You are responsible for any charges from your selected provider."
        )
        msg.exec()
    
    def ai_assistant(self):
        """Open unified AI Assistant dialog."""
        from ui.ai_dialogs import AIRequestSpecDialog, AIChatDialog
        
        # Check if AI is configured
        api_key, provider = self._get_ai_api_key()
        if not api_key:
            # _get_ai_api_key already shows instructions if key is missing
            return
        
        # First show request specification dialog
        spec_dialog = AIRequestSpecDialog(self)
        if spec_dialog.exec() != QDialog.Accepted:
            return
        
        # Get specification
        request_spec = spec_dialog.get_specification()
        
        # Open chat dialog with specification
        chat_dialog = AIChatDialog(self, request_spec)
        if chat_dialog.exec() == QDialog.Accepted:
            # Changes will be applied by the dialog
            pass
    
    def ai_generate_base_sprite(self):
        """Generate base sprite using Gemini."""
        from ui.ai_dialogs import AIBaseImageDialog, AIProgressDialog
        from core.gemini_client import GeminiClient
        from core.ai_worker_threads import BaseImageWorkerThread
        from core.state import state
        
        # Check requirements
        if not self._check_ai_requirements(['google-generativeai']):
            return
        
        # Get API key from preferences
        api_key, provider = self._get_ai_api_key()
        if not api_key:
            return  # User cancelled or not configured
        
        # Check if provider is Gemini (currently only Gemini is supported)
        if provider and "Gemini" not in provider:
            QMessageBox.warning(self, "Provider Not Supported", 
                              f"Currently only Gemini is supported for this feature.\n"
                              f"Please select 'Gemini (Google)' in Preferences → AI tab.")
            return
        
        try:
            gemini_client = GeminiClient(api_key)
        except Exception as e:
            QMessageBox.critical(self, "Gemini Error", f"Failed to initialize Gemini client: {str(e)}")
            return
        
        # Show dialog
        dialog = AIBaseImageDialog(self)
        if dialog.exec() != QDialog.Accepted:
            return
        
        params = dialog.get_parameters()
        
        # Show progress dialog
        progress_dlg = AIProgressDialog(self)
        worker = BaseImageWorkerThread(
            gemini_client, params['prompt'], params['theme'], 
            params['detail'], params['size'], params['use_cache']
        )
        progress_dlg.set_worker_thread(worker)
        worker.start()
        
        if progress_dlg.exec() == QDialog.Accepted and worker.result is not None:
            # Add base image to current frame
            layer = state.layer_manager.get_current_layer()
            frame = layer.get_frame(state.layer_manager.current_frame)
            frame.image = worker.result
            self._force_complete_refresh()
    
    def ai_generate_animation(self):
        """Generate animated sprite from base image."""
        from ui.ai_dialogs import AIAnimationDialog, AIProgressDialog, AIJSONEditorDialog, ChangePreviewWidget
        from core.gemini_client import GeminiClient
        from core.ai_worker_threads import AnimationWorkerThread
        from core.state import state
        from core.ai_helpers import generate_frames_parallel, apply_cumulative_changes
        
        # Check requirements
        if not self._check_ai_requirements(['google-generativeai']):
            return
        
        # Get API key from preferences
        api_key, provider = self._get_ai_api_key()
        if not api_key:
            return  # User cancelled or not configured
        
        # Check if provider is Gemini
        if provider and "Gemini" not in provider:
            QMessageBox.warning(self, "Provider Not Supported", 
                              f"Currently only Gemini is supported for this feature.\n"
                              f"Please select 'Gemini (Google)' in Preferences → AI tab.")
            return
        
        # Get current image as base
        layer = state.layer_manager.get_current_layer()
        frame = layer.get_frame(state.layer_manager.current_frame)
        base_image = frame.image
        
        if base_image is None or base_image.size == 0:
            QMessageBox.warning(self, "No Base Image", 
                              "Please create or select a base sprite image first.")
            return
        
        try:
            gemini_client = GeminiClient(api_key)
        except Exception as e:
            QMessageBox.critical(self, "Gemini Error", f"Failed to initialize Gemini client: {str(e)}")
            return
        
        # Show dialog
        dialog = AIAnimationDialog(self, base_image)
        if dialog.exec() != QDialog.Accepted:
            return
        
        params = dialog.get_parameters()
        
        # Show progress dialog
        progress_dlg = AIProgressDialog(self)
        worker = AnimationWorkerThread(
            gemini_client, base_image, params['animation_type'],
            params['frame_count'], params['mode'], params['refine'],
            params['validate_diffs'], params['use_cache']
        )
        progress_dlg.set_worker_thread(worker)
        worker.start()
        
        if progress_dlg.exec() == QDialog.Accepted and worker.result:
            frames = worker.result['frames']
            changes_data = worker.result['changes_data']
            
            # Option to edit JSON before applying
            edit_dlg = AIJSONEditorDialog(self, changes_data)
            if edit_dlg.exec() == QDialog.Accepted:
                edited_data = edit_dlg.get_json_data()
                if edited_data:
                    # Regenerate frames with edited data
                    all_changes = [f.get('changes', []) for f in edited_data.get('frames', [])]
                    if params['mode'] == 'cumulative':
                        frames = apply_cumulative_changes(base_image, all_changes)
                    else:
                        from core.ai_helpers import generate_frames_parallel
                        frames = generate_frames_parallel(base_image, all_changes, 
                                                         validate_diffs=params['validate_diffs'])
            
            # Add frames to layer
            current_frame_count = len(layer.frames)
            for i, frame_image in enumerate(frames):
                if i == 0:
                    # Replace current frame
                    frame.image = frame_image
                else:
                    # Add new frames
                    state.layer_manager.add_frame()
                    new_frame = layer.get_frame(current_frame_count + i - 1)
                    new_frame.image = frame_image
            
            self._force_complete_refresh()
    
    def ai_generate_texture_pack(self):
        """Generate texture pack using Gemini + Atlas Manager."""
        QMessageBox.information(self, "Coming Soon", 
                               "Texture pack generation will be implemented soon.\n\n"
                               "This will use Gemini to generate block textures and\n"
                               "automatically create a texture atlas.")
    
    def ai_detect_skeleton(self):
        """Detect 2D skeleton/anchors from sprite."""
        from ui.ai_dialogs import AIProgressDialog
        from core.gemini_client import GeminiClient
        from core.ai_worker_threads import AnchorDetectionWorkerThread
        from core.state import state
        
        # Check requirements
        if not self._check_ai_requirements(['google-generativeai']):
            return
        
        # Get API key from preferences
        api_key, provider = self._get_ai_api_key()
        if not api_key:
            return  # User cancelled or not configured
        
        # Check if provider is Gemini
        if provider and "Gemini" not in provider:
            QMessageBox.warning(self, "Provider Not Supported", 
                              f"Currently only Gemini is supported for this feature.\n"
                              f"Please select 'Gemini (Google)' in Preferences → AI tab.")
            return
        
        layer = state.layer_manager.get_current_layer()
        frame = layer.get_frame(state.layer_manager.current_frame)
        base_image = frame.image
        
        if base_image is None:
            QMessageBox.warning(self, "No Image", "Please select a sprite frame first.")
            return
        
        try:
            gemini_client = GeminiClient(api_key)
        except Exception as e:
            QMessageBox.critical(self, "Gemini Error", f"Failed to initialize Gemini client: {str(e)}")
            return
        
        progress_dlg = AIProgressDialog(self)
        worker = AnchorDetectionWorkerThread(gemini_client, base_image)
        progress_dlg.set_worker_thread(worker)
        worker.start()
        
        if progress_dlg.exec() == QDialog.Accepted and worker.result:
            anchors = worker.result
            # Display anchors (future: show in overlay or save to file)
            QMessageBox.information(self, "Anchors Detected", 
                                  f"Detected {len(anchors)} anchor points:\n" +
                                  "\n".join(f"{name}: ({data.get('x', 0)}, {data.get('y', 0)})" 
                                           for name, data in anchors.items()))
    
    def ai_analyze_sprite(self):
        """Analyze sprite structure and suggest improvements."""
        QMessageBox.information(self, "Coming Soon", 
                               "Sprite analysis will provide suggestions for\n"
                               "improving animation smoothness and structure.")
    
    def ai_upscale(self):
        """AI-powered upscaling (better than current upscale)."""
        QMessageBox.information(self, "Coming Soon", 
                               "AI upscaling will use Gemini or free libraries\n"
                               "for higher quality upscaling.")
    
    def ai_background_removal(self):
        """Interactive background removal using grabCut algorithm."""
        from core.state import state
        from PySide6.QtWidgets import QMessageBox, QDialog
        from ui.background_removal_dialog import BackgroundRemovalDialog
        
        layer = state.layer_manager.get_current_layer()
        frame = layer.get_frame(state.layer_manager.current_frame)
        image = frame.image
        
        if image is None:
            QMessageBox.warning(self, "No Image", "Please select an image first.")
            return
        
        # Open dialog
        dialog = BackgroundRemovalDialog(image, self)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            result = dialog.get_result()
            if result is not None:
                # Apply result to frame
                frame.image = result
                self._force_complete_refresh()
                QMessageBox.information(self, "Success", "Background removed successfully!")
            else:
                QMessageBox.warning(self, "Error", "Failed to process image.")
    
    def ai_object_removal(self):
        """AI-powered object removal using offline PatchMatch inpainting."""
        from core.state import state
        from PySide6.QtWidgets import QMessageBox, QProgressDialog
        from PySide6.QtCore import Qt
        import numpy as np
        import cv2
        import sys
        from pathlib import Path
        
        layer = state.layer_manager.get_current_layer()
        frame = layer.get_frame(state.layer_manager.current_frame)
        image = frame.image
        
        if image is None:
            QMessageBox.warning(self, "No Image", "Please select an image first.")
            return
        
        # Check if there's a selection
        if not state.selection_manager.has_selection():
            QMessageBox.information(
                self, "Selection Required",
                "Please select the object you want to remove first.\n\n"
                "1. Use the Selection tool (rectangular or magic wand)\n"
                "2. Select the area containing the object\n"
                "3. Then use AI → Enhancement → Object Removal"
            )
            return
        
        # Get selection mask
        selection_mask = state.selection_manager.mask
        if selection_mask is None:
            QMessageBox.warning(self, "No Selection", "Selection mask is invalid.")
            return
        
        # Convert boolean mask to uint8 (255 = remove, 0 = keep)
        mask_uint8 = (selection_mask.astype(np.uint8) * 255)
        
        # Ensure venv site-packages is in sys.path
        # First, try to add Core to path if needed
        project_root = Path(__file__).parent.parent.parent.parent
        if str(project_root) not in sys.path:
            sys.path.insert(0, str(project_root))
        
        try:
            from Core.VenvManager import VenvManager
            venv_manager = VenvManager()
            if venv_manager.venv_exists():
                venv_manager.activate_venv()
        except Exception:
            # If venv_manager not available, try to add venv path manually
            venv_path = Path.home() / ".pygenesis" / "venv"
            if sys.platform == "win32":
                site_packages = venv_path / "Lib" / "site-packages"
            else:
                site_packages = venv_path / "lib" / f"python{sys.version_info.major}.{sys.version_info.minor}" / "site-packages"
            
            if site_packages.exists():
                site_packages_str = str(site_packages)
                if site_packages_str not in sys.path:
                    sys.path.insert(0, site_packages_str)
        
        # Try to use pypatchmatch (better quality)
        use_patchmatch = False
        try:
            from pypatchmatch import inpaint
            use_patchmatch = True
        except ImportError:
            # Fallback to OpenCV inpainting
            pass
        
        # Show progress
        progress = QProgressDialog(
            "Removing object with AI (offline)...", None, 0, 0, self
        )
        progress.setWindowModality(Qt.WindowModality.WindowModal)
        progress.setCancelButton(None)
        progress.show()
        progress.setValue(0)
        
        try:
            # Convert RGBA to BGR for OpenCV/pypatchmatch
            if image.shape[2] == 4:  # RGBA
                image_bgr = cv2.cvtColor(image, cv2.COLOR_RGBA2BGR)
            else:  # RGB
                image_bgr = cv2.cvtColor(image, cv2.COLOR_RGB2BGR)
            
            if use_patchmatch:
                # Use PatchMatch inpainting (better quality)
                result_bgr = inpaint(image_bgr, mask_uint8, patch_size=9)
            else:
                # Fallback to OpenCV inpainting
                result_bgr = cv2.inpaint(image_bgr, mask_uint8, 3, cv2.INPAINT_TELEA)
            
            # Convert back to RGBA
            if image.shape[2] == 4:  # Original was RGBA
                result = cv2.cvtColor(result_bgr, cv2.COLOR_BGR2RGBA)
                # Preserve original alpha channel where mask is not applied
                result[:, :, 3] = image[:, :, 3]
            else:  # Original was RGB
                result = cv2.cvtColor(result_bgr, cv2.COLOR_BGR2RGB)
                # Add alpha channel
                alpha = np.ones((result.shape[0], result.shape[1], 1), dtype=result.dtype) * 255
                result = np.concatenate([result, alpha], axis=2)
            
            # Apply result to frame
            frame.image = result
            self._force_complete_refresh()
            
            # Clear selection
            state.selection_manager.clear_selection()
            
            progress.close()
            method_used = "PatchMatch" if use_patchmatch else "OpenCV"
            QMessageBox.information(
                self, "Success",
                f"Object removed successfully using {method_used} inpainting (offline)!"
            )
            
        except Exception as e:
            progress.close()
            QMessageBox.warning(
                self, "Error",
                f"An error occurred while removing object:\n\n{str(e)}\n\n"
                f"Tip: For better results, install 'pypatchmatch' via Extension Manager."
            )
    
    def ai_generate_animation_frames(self):
        """Generate animation frames (Jump, Run, Walk, Sit, Crawl, etc.) from base sprite."""
        from core.state import state
        from core.ai_image_operations import AIImageOperations
        from PySide6.QtWidgets import (QMessageBox, QDialog, QVBoxLayout, QHBoxLayout,
                                      QLabel, QComboBox, QPushButton, QSpinBox)
        import numpy as np
        
        layer = state.layer_manager.get_current_layer()
        frame = layer.get_frame(state.layer_manager.current_frame)
        image = frame.image
        
        if image is None:
            QMessageBox.warning(self, "No Image", "Please select a base sprite first.")
            return
        
        # Get AI API key
        api_key, provider = self._get_ai_api_key()
        if not api_key or not provider:
            return
        
        # Check if provider supports animation generation
        if provider not in ["Gemini (Google)"]:
            QMessageBox.warning(
                self, "Provider Not Supported",
                f"{provider} does not support animation generation.\n\n"
                "Please use Gemini for animation generation."
            )
            return
        
        # Create dialog for animation settings
        dialog = QDialog(self)
        dialog.setWindowTitle("Generate Animation Frames")
        dialog.setModal(True)
        layout = QVBoxLayout(dialog)
        
        # Animation type
        layout.addWidget(QLabel("Animation Type:"))
        animation_combo = QComboBox()
        animation_combo.addItems([
            "Jump", "Run", "Walk", "Sit", "Crawl", "Idle", "Attack", "Defend",
            "Fall", "Climb", "Swim", "Fly", "Dance", "Wave", "Point"
        ])
        layout.addWidget(animation_combo)
        
        # Frame count
        layout.addWidget(QLabel("Number of Frames:"))
        frame_spin = QSpinBox()
        frame_spin.setRange(2, 16)
        frame_spin.setValue(8)
        layout.addWidget(frame_spin)
        
        # Buttons
        button_layout = QHBoxLayout()
        ok_button = QPushButton("Generate")
        ok_button.clicked.connect(dialog.accept)
        cancel_button = QPushButton("Cancel")
        cancel_button.clicked.connect(dialog.reject)
        button_layout.addWidget(ok_button)
        button_layout.addWidget(cancel_button)
        layout.addLayout(button_layout)
        
        if dialog.exec() != QDialog.Accepted:
            return
        
        animation_type = animation_combo.currentText().lower()
        frame_count = frame_spin.value()
        
        # Show progress
        from PySide6.QtWidgets import QProgressDialog
        from PySide6.QtCore import Qt
        progress = QProgressDialog(f"Generating {frame_count} {animation_type} frames...", None, 0, 0, self)
        progress.setWindowModality(Qt.WindowModality.WindowModal)
        progress.setCancelButton(None)
        progress.show()
        progress.setValue(0)
        
        try:
            # Initialize AI operations
            ai_ops = AIImageOperations(provider, api_key)
            
            # Generate frames
            frames = ai_ops.generate_animation_frames(image, animation_type, frame_count)
            
            if frames is None or len(frames) == 0:
                progress.close()
                QMessageBox.warning(
                    self, "Generation Failed",
                    "Failed to generate animation frames. Please try again."
                )
                return
            
            # Add frames to the layer
            current_frame_idx = state.layer_manager.current_frame
            for i, frame_img in enumerate(frames):
                if i == 0:
                    # Replace current frame with first generated frame
                    frame.image = frame_img
                else:
                    # Insert new frames after current frame
                    new_frame = layer.create_frame()
                    new_frame.image = frame_img
                    layer.frames.insert(current_frame_idx + i, new_frame)
            
            # Update frame count
            state.layer_manager.current_frame = current_frame_idx
            self._force_complete_refresh()
            
            progress.close()
            QMessageBox.information(
                self, "Success",
                f"Generated {len(frames)} {animation_type} animation frames!"
            )
            
        except Exception as e:
            progress.close()
            # Check for quota exceeded error
            from core.ai_image_operations import AIQuotaExceededError
            if isinstance(e, AIQuotaExceededError):
                retry_msg = ""
                if e.retry_after:
                    retry_msg = f"\n\nPlease wait {int(e.retry_after)} seconds before retrying."
                QMessageBox.warning(
                    self, "API Quota Exceeded",
                    str(e) + retry_msg
                )
            else:
                QMessageBox.warning(
                    self, "Error",
                    f"An error occurred while generating animation:\n\n{str(e)}"
                )
    
    def ai_image_to_3d(self):
        """Convert 2D image to 3D model."""
        QMessageBox.information(self, "Coming Soon", 
                               "Image to 3D conversion will:\n"
                               "1. Generate depth map using Gemini\n"
                               "2. Create 3D mesh\n"
                               "3. Generate OBJ + MTL files\n"
                               "4. Add to project automatically")
    
    def ai_sprite_to_3d(self):
        """Convert multi-view sprite to 3D model."""
        QMessageBox.information(self, "Coming Soon", 
                               "Sprite to 3D will analyze multiple views\n"
                               "and reconstruct a 3D model.")
    
    def _force_complete_refresh(self):
        """Force complete UI refresh after effects."""
        from PySide6.QtCore import QTimer, QCoreApplication
        
        # Clear cached image to force fresh load
        if hasattr(self.canvas, 'current_image'):
            delattr(self.canvas, 'current_image')
        
        # Force layer system refresh
        self.canvas.update_current_image_from_selected_layer()
        
        # Force canvas refresh
        if hasattr(self.canvas, 'force_layer_frame_switch'):
            self.canvas.force_layer_frame_switch()
        
        self.canvas.update()
        self.canvas.repaint()
        
        # Force Qt event processing
        QCoreApplication.processEvents()
        
        # Multiple delayed refreshes to ensure proper update
        QTimer.singleShot(0, lambda: self.canvas.repaint())
        QTimer.singleShot(10, lambda: self.canvas.repaint())
        QTimer.singleShot(50, lambda: self.canvas.repaint())
        
        # Update preview panel if it exists
        if hasattr(self, 'right_panel') and hasattr(self.right_panel, 'preview_box'):
            self.right_panel.preview_box.update()
            self.right_panel.preview_box.repaint()
        
        # Force canvas to redraw entire area
        self.canvas.update(self.canvas.rect())
    
    def _apply_greyscale_to_frame(self, frame_idx, selection_option="entire"):
        """Apply greyscale effect to a specific frame using PIL for correct conversion."""
        from PIL import Image
        import numpy as np
        lm = state.layer_manager
        layer = lm.get_current_layer()
        frame = layer.get_frame(frame_idx)
        img = frame.image
        if img is None:
            return
        
        if selection_option == "selection":
            # Get selection from selection manager
            if state.selection_manager.has_selection():
                bounds = state.selection_manager.get_selection_bounds()
                if bounds:
                    x1, y1, x2, y2 = bounds
                    # Ensure coordinates are within bounds
                    h, w = img.shape[:2]
                    x1, y1 = max(0, min(x1, w-1)), max(0, min(y1, h-1))
                    x2, y2 = max(0, min(x2, w-1)), max(0, min(y2, h-1))
                    
                    if x1 < x2 and y1 < y2:
                        if state.selection_manager.selection_mask is not None:
                            # Apply effect to masked selection
                            mask_region = state.selection_manager.selection_mask[y1:y2, x1:x2]
                            selected_region = img[y1:y2, x1:x2].copy()
                            
                            # Convert selected region to greyscale
                            pil_region = Image.fromarray(selected_region, mode='RGBA')
                            l_region = pil_region.convert('L')
                            a_region = pil_region.getchannel('A')
                            l_region.putalpha(a_region)
                            greyscale_region = l_region.convert('RGBA')
                            greyscale_array = np.array(greyscale_region)
                            
                            # Apply only to masked pixels
                            selected_region[mask_region] = greyscale_array[mask_region]
                            img[y1:y2, x1:x2] = selected_region
                        else:
                            # Apply effect to rectangular selection
                            selected_region = img[y1:y2, x1:x2]
                            
                            # Convert selected region to greyscale
                            pil_region = Image.fromarray(selected_region, mode='RGBA')
                            l_region = pil_region.convert('L')
                            a_region = pil_region.getchannel('A')
                            l_region.putalpha(a_region)
                            greyscale_region = l_region.convert('RGBA')
                            
                            # Put greyscale region back into image
                            img[y1:y2, x1:x2] = np.array(greyscale_region)
        else:
            # Apply greyscale to entire image
            pil_img = Image.fromarray(img, mode='RGBA')
            l_img = pil_img.convert('L')
            a = pil_img.getchannel('A')
            l_img.putalpha(a)
            out = l_img.convert('RGBA')
            frame.image = np.array(out)

    def effect_fade(self):
        self._apply_unified_effect('fade')

    def effect_opacity(self):
        self._apply_unified_effect('opacity')

    def effect_blur(self):
        self._apply_unified_effect('blur')

    def effect_sharpen(self):
        self._apply_unified_effect('sharpen')

    def effect_noise(self):
        self._apply_unified_effect('noise')

    def effect_map_generator(self):
        self._apply_unified_effect('map_generator')

    def effect_texture_2d(self):
        self._apply_unified_effect('texture_2d')

    def effect_pixelate(self):
        self._apply_unified_effect('pixelate')

    def effect_dither(self):
        self._apply_unified_effect('dither')

    def effect_vignette(self):
        print("DEBUG: effect_vignette called")
        print(f"DEBUG: 'vignette' in EFFECT_REGISTRY: {'vignette' in EFFECT_REGISTRY}")
        self._apply_unified_effect('vignette')
    
    def effect_saturation(self):
        self._apply_unified_effect('saturation')
    
    def effect_posterize(self):
        self._apply_unified_effect('posterize')
    
    def effect_emboss(self):
        self._apply_unified_effect('emboss')
    
    def effect_edge_detection(self):
        self._apply_unified_effect('edge_detection')
    
    def effect_colorize(self):
        self._apply_unified_effect('colorize')
    
    def effect_oil_painting(self):
        self._apply_unified_effect('oil_painting')
    
    def effect_glow(self):
        self._apply_unified_effect('glow')
    
    def effect_solarize(self):
        self._apply_unified_effect('solarize')
    
    def effect_image_enhancement(self):
        self._apply_unified_effect('image_enhancement')
    
    def effect_quality_enhancement(self):
        self._apply_unified_effect('quality_enhancement')
    
    def effect_upscale(self):
        self._apply_unified_effect('upscale')
    
    def effect_motion_blur(self):
        self._apply_unified_effect('motion_blur')
    
    def effect_shader_bloom(self):
        self._apply_unified_effect('shader_bloom')
    
    def effect_palette_cycler(self):
        self._apply_unified_effect('palette_cycler')
    
    def effect_pixel_depth(self):
        self._apply_unified_effect('pixel_depth')
    
    def effect_hd_crisp(self):
        self._apply_unified_effect('hd_crisp')
    
    # Reshade Gaming - placeholders
    def effect_voxelize(self):
        print("Voxelize - Coming soon!")
        from PySide6.QtWidgets import QMessageBox
        QMessageBox.information(self, "Coming Soon", "Voxelize effect will be implemented soon!")
    
    def effect_dream_diffuse(self):
        print("Dream Diffuse - Coming soon!")
        from PySide6.QtWidgets import QMessageBox
        QMessageBox.information(self, "Coming Soon", "Dream Diffuse effect will be implemented soon!")
    
    def effect_vhs(self):
        print("VHS - Coming soon!")
        from PySide6.QtWidgets import QMessageBox
        QMessageBox.information(self, "Coming Soon", "VHS effect will be implemented soon!")
    
    def effect_posterizer(self):
        print("Posterizer - Coming soon!")
        from PySide6.QtWidgets import QMessageBox
        QMessageBox.information(self, "Coming Soon", "Posterizer effect will be implemented soon!")
    
    # Reshade Lighting
    def effect_normal_map(self):
        print("Normal/Specular Map - Coming soon!")
        from PySide6.QtWidgets import QMessageBox
        QMessageBox.information(self, "Coming Soon", "Normal/Specular Map effect will be implemented soon!")
    
    def effect_light_overlay(self):
        print("Light Overlay - Coming soon!")
        from PySide6.QtWidgets import QMessageBox
        QMessageBox.information(self, "Coming Soon", "Light Overlay effect will be implemented soon!")

    def effect_atmospheric_lighting(self):
        """Apply Atmospheric Lighting effect."""
        print("DEBUG: effect_atmospheric_lighting called")
        try:
            self._apply_unified_effect('atmospheric_lighting')
        except Exception as e:
            print(f"DEBUG: Error in effect_atmospheric_lighting: {e}")
            import traceback
            traceback.print_exc()

    def effect_wind_waker(self):
        """Apply Wind Waker style effect."""
        print("DEBUG: effect_wind_waker called")
        try:
            self._apply_unified_effect('wind_waker')
        except Exception as e:
            print(f"DEBUG: Error in effect_wind_waker: {e}")
            import traceback
            traceback.print_exc()

    def effect_ocarina_of_time(self):
        """Apply Ocarina of Time N64-style effect."""
        print("DEBUG: effect_ocarina_of_time called")
        try:
            self._apply_unified_effect('ocarina_of_time')
        except Exception as e:
            print(f"DEBUG: Error in effect_ocarina_of_time: {e}")
            import traceback
            traceback.print_exc()

    def effect_luigis_mansion(self):
        """Apply Luigi's Mansion atmospheric effect."""
        print("DEBUG: effect_luigis_mansion called")
        try:
            self._apply_unified_effect('luigis_mansion')
        except Exception as e:
            print(f"DEBUG: Error in effect_luigis_mansion: {e}")
            import traceback
            traceback.print_exc()

    def effect_eternal_darkness(self):
        """Apply Eternal Darkness sanity effect."""
        print("DEBUG: effect_eternal_darkness called")
        try:
            self._apply_unified_effect('eternal_darkness')
        except Exception as e:
            print(f"DEBUG: Error in effect_eternal_darkness: {e}")
            import traceback
            traceback.print_exc()

    def effect_pokemon_colosseum(self):
        """Apply Pokémon Colosseum cinematic battle effect."""
        print("DEBUG: effect_pokemon_colosseum called")
        try:
            self._apply_unified_effect('pokemon_colosseum')
        except Exception as e:
            print(f"DEBUG: Error in effect_pokemon_colosseum: {e}")
            import traceback
            traceback.print_exc()

    def effect_mario_kart_8(self):
        """Apply Mario Kart 8 vibrant, polished effect."""
        print("DEBUG: effect_mario_kart_8 called")
        try:
            self._apply_unified_effect('mario_kart_8')
        except Exception as e:
            print(f"DEBUG: Error in effect_mario_kart_8: {e}")
            import traceback
            traceback.print_exc()


    def effect_generate_lod(self):
        """Apply LOD generation effect."""
        self._apply_unified_effect('generate_lod')
    



    def effect_mirror_flip(self):
        """Apply mirror/flip transformation with dialog."""
        from ui.mirror_flip_dialog import MirrorFlipDialog
        
        dialog = MirrorFlipDialog(self)
        if dialog.exec() == QDialog.Accepted:
            params = dialog.get_parameters()
            self._apply_mirror_flip_effect(params)

    def effect_rotate(self):
        """Apply rotation transformation with dialog."""
        from ui.rotate_dialog import RotateDialog
        
        dialog = RotateDialog(self)
        if dialog.exec() == QDialog.Accepted:
            params = dialog.get_parameters()
            self._apply_rotate_effect(params)

    def _apply_unified_effect(self, effect_type):
        """Apply a unified effect using the UnifiedEffectDialog system."""
        from PySide6.QtWidgets import QMessageBox
        
        debug(f"DEBUG: _apply_unified_effect called with effect_type: {effect_type}")
        
        # Check if effect exists in registry
        if effect_type not in EFFECT_REGISTRY:
            debug(f"DEBUG: Effect '{effect_type}' not found in registry")
            QMessageBox.warning(self, "Effect Error", f"Effect '{effect_type}' not found in registry.")
            return
        
        # Get current image for validation
        lm = state.layer_manager
        layer = lm.get_current_layer()
        frame_idx = lm.current_frame
        frame = layer.get_frame(frame_idx)
        img = frame.image
        if img is None:
            QMessageBox.warning(self, "Effect Error", "No image to apply effect to.")
            return
        
        # Show unified effect dialog
        dlg = None
        try:
            debug(f"DEBUG: Creating UnifiedEffectDialog for {effect_type}")
            dlg = UnifiedEffectDialog(effect_type, self)
            debug(f"DEBUG: Dialog created successfully")
            
            # Set preview image
            dlg.preview_image = img.copy()
            # Update preview immediately
            dlg.update_preview()
            debug(f"DEBUG: Preview updated, about to show dialog")
        except Exception as e:
            print(f"Error creating UnifiedEffectDialog: {e}")
            import traceback
            traceback.print_exc()
            QMessageBox.critical(self, "Dialog Error", f"Failed to create effect dialog: {str(e)}")
            return
        
        if dlg is None:
            debug("DEBUG: Dialog is None, returning")
            return
        
        debug(f"DEBUG: About to show dialog with exec()")
        if dlg.exec() != QDialog.Accepted:
            debug(f"DEBUG: Dialog rejected or closed")
            return
        debug(f"DEBUG: Dialog accepted, proceeding with effect application")
        
        frame_option = dlg.get_frame_option()
        selection_option = dlg.get_selection_option()
        parameters = dlg.get_parameters()
        frame_count = dlg.get_frame_count()
        merge_replace_mode = dlg.get_merge_replace_mode()
        export_options = dlg.get_export_options()
        
        # Handle LOD export functionality
        if effect_type == 'generate_lod' and parameters.get('export_only', False):
            self._handle_lod_export(frame_option, selection_option, parameters, frame_count, export_options)
            return
        
        # Handle animated texture creation (2D Texture Creation with Animated mode)
        if effect_type == 'texture_2d' and parameters.get('texture_mode') == 'Animated':
            # Get number of frames from parameters
            animation_frames = parameters.get('animation_frames', 4)
            self._handle_animated_texture_creation(parameters, "create_frames", selection_option, merge_replace_mode, animation_frames)
            return
        
        # Push undo before applying effect
        state.push_undo()
        
        # Debug output
        debug(f"DEBUG: Applying effect '{effect_type}' with parameters: {parameters}")
        debug(f"DEBUG: Frame option: {frame_option}, Selection option: {selection_option}")
        debug(f"DEBUG: Merge/Replace mode: {merge_replace_mode}")
        
        # Apply effect based on frame option
        if frame_option == "current":
            # Apply to current frame only
            if merge_replace_mode == "replace":
                self._apply_effect_to_frame(effect_type, frame_idx, selection_option, parameters)
            else:
                self._apply_effect_to_frame_merge(effect_type, frame_idx, selection_option, parameters)
        elif frame_option == "all":
            # Apply to all existing frames
            for i in range(len(layer.frames)):
                if merge_replace_mode == "replace":
                    self._apply_effect_to_frame(effect_type, i, selection_option, parameters)
                else:
                    self._apply_effect_to_frame_merge(effect_type, i, selection_option, parameters)
        elif frame_option == "previous":
            # Apply over previous frames with animation
            self._apply_effect_over_frames(effect_type, frame_idx, selection_option, parameters, frame_count, "previous", merge_replace_mode)
        elif frame_option == "future":
            # Apply over future frames with animation
            self._apply_effect_over_frames(effect_type, frame_idx, selection_option, parameters, frame_count, "future", merge_replace_mode)
        elif frame_option == "create_frames":
            # Apply over future frames with animation (same as future)
            self._apply_effect_over_frames(effect_type, frame_idx, selection_option, parameters, frame_count, "future", merge_replace_mode)
        
        # Force complete UI refresh
        self._force_complete_refresh()
    
    def _apply_effect_to_frame(self, effect_type, frame_idx, selection_option, parameters):
        """Apply a specific effect to a frame."""
        lm = state.layer_manager
        layer = lm.get_current_layer()
        frame = layer.get_frame(frame_idx)
        img = frame.image
        if img is None:
            return
        
        # Get the area to apply effect to
        if selection_option == "selection":
            if state.selection_manager.has_selection():
                bounds = state.selection_manager.get_selection_bounds()
                if bounds:
                    x1, y1, x2, y2 = bounds
                    h, w = img.shape[:2]
                    x1, y1 = max(0, min(x1, w-1)), max(0, min(y1, h-1))
                    x2, y2 = max(0, min(x2, w-1)), max(0, min(y2, h-1))
                    
                    if x1 < x2 and y1 < y2:
                        if state.selection_manager.selection_mask is not None:
                            # Apply effect to masked selection
                            mask_region = state.selection_manager.selection_mask[y1:y2, x1:x2]
                            selected_region = img[y1:y2, x1:x2].copy()
                            processed_region = self._process_effect(effect_type, selected_region, parameters)
                            
                            # Apply only to masked pixels
                            selected_region[mask_region] = processed_region[mask_region]
                            img[y1:y2, x1:x2] = selected_region
                        else:
                            # Apply effect to rectangular selection
                            selected_region = img[y1:y2, x1:x2]
                            processed_region = self._process_effect(effect_type, selected_region, parameters)
                            img[y1:y2, x1:x2] = processed_region
                else:
                    # No selection, apply to entire image
                    frame.image = self._process_effect(effect_type, img, parameters)
            else:
                # No selection, apply to entire image
                frame.image = self._process_effect(effect_type, img, parameters)
        else:
            # Apply to entire image
            frame.image = self._process_effect(effect_type, img, parameters)
    
    def _process_effect(self, effect_type, img, parameters):
        """Process an image with a specific effect - delegates to EffectProcessor service."""
        from services.effect_processor import EffectProcessor
        
        # Use service for effects that don't need state/UI access
        # Complex effects that need state remain as local methods
        if effect_type in ['texture_atlas']:
            # These need state access, use local method
            return self._apply_texture_atlas_effect(parameters)
        elif effect_type in ['map_generator', 'texture_2d', 'generate_lod']:
            # These need state access, use local methods
            from PIL import Image
            pil_img = Image.fromarray(img, mode='RGBA')
            if effect_type == 'map_generator':
                return self._apply_map_generator_effect(pil_img, parameters)
            elif effect_type == 'texture_2d':
                return self._apply_texture_2d_effect(pil_img, parameters)
            elif effect_type == 'generate_lod':
                return self._apply_generate_lod_effect(pil_img, parameters)
        
        # Delegate to service for all other effects
        processor = EffectProcessor()
        return processor.process_effect(effect_type, img, parameters)
    
    def _apply_image_enhancement(self, pil_img, parameters):
        """Apply combined image enhancement effect - delegates to dialogs implementation."""
        # Import the dialog class to use its methods
        from ui.dialogs import UnifiedEffectDialog
        temp_dlg = UnifiedEffectDialog('image_enhancement', None)
        return temp_dlg._apply_image_enhancement_effect(pil_img, parameters)
    
    def _apply_torch_lighting_effect(self, pil_img, parameters):
        """Apply Torch Lighting effect based on Wind Waker baseline with manual light control."""
        from PIL import Image, ImageEnhance, ImageFilter
        import numpy as np
        import cv2
        
        # Get parameters with defaults
        use_defaults = parameters.get('use_defaults', True)
        auto_detect_lights = parameters.get('auto_detect_lights', False)
        light_x = parameters.get('light_x', 25)  # Percentage
        light_y = parameters.get('light_y', 50)  # Percentage
        torch_radius = parameters.get('torch_radius', 80)
        torch_intensity = parameters.get('torch_intensity', 1.8)
        torch_warmth = parameters.get('torch_warmth', 1.8)
        torch_cold = parameters.get('torch_cold', 1.0)
        ambient_light = parameters.get('ambient_light', 0.3)
        ambient_light_color = parameters.get('ambient_light_color', '#FFE4B5')
        torch_color = parameters.get('torch_color', '#FF8C00')
        enable_shadows = parameters.get('enable_shadows', True)
        shadow_softness = parameters.get('shadow_softness', 1.5)
        shadow_darkness = parameters.get('shadow_darkness', 0.7)
        shadow_length = parameters.get('shadow_length', 120)
        flicker_amount = parameters.get('flicker_amount', 15)
        contrast_boost = parameters.get('contrast_boost', 1.2)
        brightness_boost = parameters.get('brightness_boost', 1.1)
        style_preset = parameters.get('style_preset', 'Medieval Torch')
        
        # Apply preset if using defaults
        if use_defaults and style_preset != 'Custom':
            if style_preset == 'Medieval Torch':
                torch_radius = 80
                torch_intensity = 1.8
                torch_warmth = 1.8
                torch_cold = 1.0
                ambient_light = 0.3
                shadow_softness = 1.5
                shadow_darkness = 0.7
                flicker_amount = 15
                contrast_boost = 1.2
                brightness_boost = 1.1
            elif style_preset == 'Campfire':
                torch_radius = 120
                torch_intensity = 2.2
                torch_warmth = 2.2
                torch_cold = 0.8
                ambient_light = 0.4
                shadow_softness = 2.0
                shadow_darkness = 0.6
                flicker_amount = 25
                contrast_boost = 1.3
                brightness_boost = 1.2
            elif style_preset == 'Candle':
                torch_radius = 60
                torch_intensity = 1.2
                torch_warmth = 1.5
                torch_cold = 1.2
                ambient_light = 0.2
                shadow_softness = 1.0
                shadow_darkness = 0.8
                flicker_amount = 8
                contrast_boost = 1.1
                brightness_boost = 1.0
            elif style_preset == 'Magic Flame':
                torch_radius = 100
                torch_intensity = 2.5
                torch_warmth = 2.0
                torch_cold = 0.7
                ambient_light = 0.5
                shadow_softness = 2.5
                shadow_darkness = 0.5
                flicker_amount = 30
                contrast_boost = 1.4
                brightness_boost = 1.3
        
        # Convert PIL to numpy for processing
        img_array = np.array(pil_img)
        height, width = img_array.shape[:2]
        
        # Step 1: Determine light position
        if auto_detect_lights:
            # Try to find existing light sources
            light_sources = self._detect_light_sources_advanced(img_array, 180, 5, 20)
            if not light_sources:
                # Use manual position as fallback
                light_x_px = int(width * light_x / 100)
                light_y_px = int(height * light_y / 100)
                light_sources = [(light_x_px, light_y_px)]
        else:
            # Use manual position
            light_x_px = int(width * light_x / 100)
            light_y_px = int(height * light_y / 100)
            light_sources = [(light_x_px, light_y_px)]
        
        # Step 2: Start with Wind Waker baseline (bright and vibrant)
        # Pre-brighten the image
        img_array = np.clip(img_array * 1.3, 0, 255).astype(np.uint8)
        
        # Step 3: Create simple lighting map (no complex detection)
        lighting_map = self._create_simple_lighting_map(img_array, light_sources, torch_radius, torch_intensity)
        
        # Step 4: Apply torch color and warmth/cold
        lighting_map = self._apply_torch_color_simple(lighting_map, torch_color, torch_warmth, torch_cold)
        
        # Step 5: Add flickering
        if flicker_amount > 0:
            lighting_map = self._add_simple_flicker(lighting_map, flicker_amount)
        
        # Step 6: Apply lighting to image
        result = self._apply_simple_lighting(img_array, lighting_map, ambient_light, ambient_light_color)
        
        # Step 7: Apply brightness and contrast boost
        result = self._apply_brightness_contrast(result, brightness_boost, contrast_boost)
        
        # Step 8: Add simple shadows if enabled
        if enable_shadows:
            result = self._add_simple_shadows(result, light_sources, shadow_length, shadow_softness, shadow_darkness)
        
        return result
    
    def _apply_atmospheric_lighting_effect(self, pil_img, parameters):
        """Apply Atmospheric Lighting effect - delegates to dialogs implementation."""
        from ui.dialogs import UnifiedEffectDialog
        # Create a temporary dialog instance to use the atmospheric lighting method
        dialog = UnifiedEffectDialog('atmospheric_lighting', self)
        return dialog._apply_atmospheric_lighting_effect(pil_img, parameters)
    
    def _apply_wind_waker_effect(self, pil_img, parameters):
        """Apply Wind Waker style effect - delegates to dialogs implementation."""
        from ui.dialogs import UnifiedEffectDialog
        # Create a temporary dialog instance to use the wind waker method
        dialog = UnifiedEffectDialog('wind_waker', self)
        return dialog._apply_wind_waker_effect(pil_img, parameters)
    
    def _apply_ocarina_of_time_effect(self, pil_img, parameters):
        """Apply Ocarina of Time effect - delegates to dialogs implementation."""
        from ui.dialogs import UnifiedEffectDialog
        # Create a temporary dialog instance to use the ocarina of time method
        dialog = UnifiedEffectDialog('ocarina_of_time', self)
        return dialog._apply_ocarina_of_time_effect(pil_img, parameters)
    
    def _apply_luigis_mansion_effect(self, pil_img, parameters):
        """Apply Luigi's Mansion effect - delegates to dialogs implementation."""
        from ui.dialogs import UnifiedEffectDialog
        # Create a temporary dialog instance to use the luigi's mansion method
        dialog = UnifiedEffectDialog('luigis_mansion', self)
        return dialog._apply_luigis_mansion_effect(pil_img, parameters)
    
    def _apply_eternal_darkness_effect(self, pil_img, parameters):
        """Apply Eternal Darkness effect - delegates to dialogs implementation."""
        from ui.dialogs import UnifiedEffectDialog
        # Create a temporary dialog instance to use the eternal darkness method
        dialog = UnifiedEffectDialog('eternal_darkness', self)
        return dialog._apply_eternal_darkness_effect(pil_img, parameters)
    
    def _apply_pokemon_colosseum_effect(self, pil_img, parameters):
        """Apply Pokémon Colosseum effect - delegates to dialogs implementation."""
        from ui.dialogs import UnifiedEffectDialog
        # Create a temporary dialog instance to use the pokemon colosseum method
        dialog = UnifiedEffectDialog('pokemon_colosseum', self)
        return dialog._apply_pokemon_colosseum_effect(pil_img, parameters)
    
    def _apply_mario_kart_8_effect(self, pil_img, parameters):
        """Apply Mario Kart 8 effect - delegates to dialogs implementation."""
        from ui.dialogs import UnifiedEffectDialog
        # Create a temporary dialog instance to use the mario kart 8 method
        dialog = UnifiedEffectDialog('mario_kart_8', self)
        return dialog._apply_mario_kart_8_effect(pil_img, parameters)
    
    def _apply_color_vibrancy(self, img_array, vibrancy):
        """Apply color vibrancy boost for more colorful Wind Waker effect."""
        import numpy as np
        
        # Convert to float for processing
        img_float = img_array.astype(np.float32) / 255.0
        
        # Apply vibrancy boost to each channel
        for i in range(3):  # RGB channels
            channel = img_float[:, :, i]
            # Boost mid-tones more than highlights and shadows
            boosted = channel * vibrancy
            # Apply a curve that preserves highlights
            boosted = np.clip(boosted, 0, 1)
            img_float[:, :, i] = boosted
        
        return (img_float * 255).astype(np.uint8)
    
    # Simple Torch Lighting Helper Methods
    def _create_simple_lighting_map(self, img_array, light_sources, radius, intensity):
        """Create simple lighting map based on Wind Waker baseline."""
        import numpy as np
        
        height, width = img_array.shape[:2]
        lighting_map = np.zeros((height, width), dtype=np.float32)
        
        for light_x, light_y in light_sources:
            # Create distance map from light source
            y, x = np.ogrid[:height, :width]
            distance = np.sqrt((x - light_x)**2 + (y - light_y)**2)
            
            # Simple falloff
            light_strength = intensity / (1 + (distance / radius)**2)
            light_strength = np.clip(light_strength, 0, 1)
            
            # Add to lighting map
            lighting_map = np.maximum(lighting_map, light_strength)
        
        return lighting_map
    
    def _apply_torch_color_simple(self, lighting_map, torch_color, warmth, cold):
        """Apply torch color with warmth and cold controls."""
        import numpy as np
        
        # Convert hex color to RGB
        torch_rgb = tuple(int(torch_color[i:i+2], 16) for i in (1, 3, 5))
        
        # Create colored lighting map
        colored_lighting = np.zeros((lighting_map.shape[0], lighting_map.shape[1], 3), dtype=np.float32)
        
        # Apply color with warmth and cold
        for i, color_component in enumerate(torch_rgb):
            if i == 0:  # Red channel - warmth increases, cold decreases
                warmth_factor = warmth
                cold_factor = 1.0 / cold
            elif i == 1:  # Green channel - moderate effect
                warmth_factor = 1.0 + (warmth - 1.0) * 0.7
                cold_factor = 1.0 + (1.0 / cold - 1.0) * 0.7
            else:  # Blue channel - warmth decreases, cold increases
                warmth_factor = 1.0 - (warmth - 1.0) * 0.3
                cold_factor = cold
            
            final_factor = (warmth_factor + cold_factor) / 2
            colored_lighting[:, :, i] = lighting_map * (color_component / 255.0) * final_factor
        
        return colored_lighting
    
    def _add_simple_flicker(self, lighting_map, flicker_amount):
        """Add simple flickering effect."""
        import numpy as np
        
        if len(lighting_map.shape) == 3:  # Colored lighting
            flicker = np.random.normal(1.0, flicker_amount / 100.0, lighting_map.shape[:2])
            flicker = np.clip(flicker, 0.8, 1.2)
            flickered = lighting_map * flicker[:, :, np.newaxis]
        else:  # Grayscale lighting
            flicker = np.random.normal(1.0, flicker_amount / 100.0, lighting_map.shape)
            flicker = np.clip(flicker, 0.8, 1.2)
            flickered = lighting_map * flicker
        
        return np.clip(flickered, 0, 1)
    
    def _apply_simple_lighting(self, img_array, lighting_map, ambient_light, ambient_color):
        """Apply simple lighting with ambient color."""
        import numpy as np
        
        # Convert image to float
        img_float = img_array.astype(np.float32) / 255.0
        
        # Apply ambient light with color
        ambient_rgb = tuple(int(ambient_color[i:i+2], 16) for i in (1, 3, 5))
        for i, color_component in enumerate(ambient_rgb):
            img_float[:, :, i] = img_float[:, :, i] * ambient_light * (color_component / 255.0)
        
        # Apply lighting map
        if len(lighting_map.shape) == 3:  # Colored lighting
            for i in range(3):
                img_float[:, :, i] = np.clip(img_float[:, :, i] + lighting_map[:, :, i], 0, 1)
        else:  # Grayscale lighting
            for i in range(3):
                img_float[:, :, i] = np.clip(img_float[:, :, i] + lighting_map, 0, 1)
        
        return (img_float * 255).astype(np.uint8)
    
    def _apply_brightness_contrast(self, img_array, brightness_boost, contrast_boost):
        """Apply brightness and contrast boost."""
        import numpy as np
        
        # Convert to float
        img_float = img_array.astype(np.float32) / 255.0
        
        # Apply brightness
        img_float = img_float * brightness_boost
        
        # Apply contrast
        img_float = np.clip((img_float - 0.5) * contrast_boost + 0.5, 0, 1)
        
        return (img_float * 255).astype(np.uint8)
    
    def _add_simple_shadows(self, img_array, light_sources, shadow_length, shadow_softness, shadow_darkness):
        """Add simple shadows based on light sources."""
        import numpy as np
        import cv2
        
        if not light_sources:
            return img_array
        
        height, width = img_array.shape[:2]
        result = img_array.copy().astype(np.float32)
        
        # Create simple shadow mask
        shadow_mask = np.ones((height, width), dtype=np.float32)
        
        for light_x, light_y in light_sources:
            # Create distance-based shadow
            y, x = np.ogrid[:height, :width]
            distance = np.sqrt((x - light_x)**2 + (y - light_y)**2)
            
            # Shadow gets darker with distance
            shadow_strength = 1.0 - (distance / shadow_length)
            shadow_strength = np.clip(shadow_strength, 0, 1)
            
            # Apply softness
            if shadow_softness > 1.0:
                kernel_size = int(shadow_softness * 5)
                if kernel_size % 2 == 0:
                    kernel_size += 1
                shadow_strength = cv2.GaussianBlur(shadow_strength, (kernel_size, kernel_size), shadow_softness)
            
            # Apply to shadow mask
            shadow_mask = np.minimum(shadow_mask, 1.0 - (shadow_strength * shadow_darkness))
        
        # Apply shadows
        for i in range(3):
            result[:, :, i] = result[:, :, i] * shadow_mask
        
        return np.clip(result, 0, 255).astype(np.uint8)
    
    def _apply_cel_shading(self, img_array, levels, contrast):
        """Apply cel shading by reducing color levels."""
        import numpy as np
        
        # Convert to grayscale for cel shading calculation
        gray = np.dot(img_array[...,:3], [0.299, 0.587, 0.114])
        
        # Apply contrast
        gray = np.clip((gray - 128) * contrast + 128, 0, 255)
        
        # Quantize to cel levels
        step = 255 / (levels - 1)
        gray_quantized = np.round(gray / step) * step
        
        # Create cel shading mask
        cel_mask = gray_quantized / 255.0
        
        # Apply cel shading to each color channel
        result = img_array.copy()
        for i in range(3):  # RGB channels
            result[..., i] = result[..., i] * cel_mask
        
        return result
    
    def _apply_gentle_cel_shading(self, img_array, levels, contrast):
        """Apply gentle cel shading that preserves brightness and vibrancy."""
        import numpy as np
        
        # Convert to grayscale for cel shading calculation
        gray = np.dot(img_array[...,:3], [0.299, 0.587, 0.114])
        
        # Apply gentle contrast (less aggressive)
        gray = np.clip((gray - 128) * contrast + 128, 0, 255)
        
        # Quantize to cel levels but preserve more brightness
        step = 255 / (levels - 1)
        gray_quantized = np.round(gray / step) * step
        
        # Create gentle cel shading mask (preserve more of original brightness)
        cel_mask = (gray_quantized / 255.0) * 0.7 + 0.3  # Keep at least 30% of original
        
        # Apply cel shading to each color channel
        result = img_array.copy()
        for i in range(3):  # RGB channels
            result[..., i] = np.clip(result[..., i] * cel_mask + result[..., i] * 0.2, 0, 255)
        
        return result
    
    def _detect_light_sources_advanced(self, img_array, brightness_threshold, color_sensitivity, min_light_size):
        """Advanced light source detection using professional computer vision techniques."""
        import numpy as np
        import cv2
        
        height, width = img_array.shape[:2]
        light_sources = []
        
        # Method 1: Brightness-based detection
        gray = cv2.cvtColor(img_array, cv2.COLOR_RGBA2GRAY)
        
        # Use adaptive thresholding for better detection
        adaptive_thresh = cv2.adaptiveThreshold(gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 11, 2)
        
        # Find bright spots above threshold
        bright_mask = gray > brightness_threshold
        
        # Combine with adaptive threshold
        combined_mask = cv2.bitwise_and(bright_mask.astype(np.uint8) * 255, adaptive_thresh)
        
        # Morphological operations to clean up the mask
        kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5))
        combined_mask = cv2.morphologyEx(combined_mask, cv2.MORPH_CLOSE, kernel)
        combined_mask = cv2.morphologyEx(combined_mask, cv2.MORPH_OPEN, kernel)
        
        # Find contours
        contours, _ = cv2.findContours(combined_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        
        for contour in contours:
            area = cv2.contourArea(contour)
            if area > min_light_size:
                # Get center and calculate brightness
                M = cv2.moments(contour)
                if M["m00"] != 0:
                    cx = int(M["m10"] / M["m00"])
                    cy = int(M["m01"] / M["m00"])
                    
                    # Calculate average brightness in the region
                    mask = np.zeros(gray.shape, dtype=np.uint8)
                    cv2.fillPoly(mask, [contour], 255)
                    mean_brightness = cv2.mean(gray, mask)[0]
                    
                    if mean_brightness > brightness_threshold:
                        light_sources.append((cx, cy, mean_brightness))
        
        # Method 2: Color-based detection for warm colors
        if len(light_sources) < 2:  # If we don't have enough bright sources
            hsv = cv2.cvtColor(img_array, cv2.COLOR_RGBA2RGB)
            hsv = cv2.cvtColor(hsv, cv2.COLOR_RGB2HSV)
            
            # Define warm color ranges (orange, yellow, red)
            lower_warm1 = np.array([0, 100, 100])      # Red
            upper_warm1 = np.array([10, 255, 255])
            lower_warm2 = np.array([10, 100, 100])     # Orange
            upper_warm2 = np.array([30, 255, 255])
            lower_warm3 = np.array([30, 100, 100])     # Yellow
            upper_warm3 = np.array([60, 255, 255])
            
            # Create combined warm color mask
            warm_mask1 = cv2.inRange(hsv, lower_warm1, upper_warm1)
            warm_mask2 = cv2.inRange(hsv, lower_warm2, upper_warm2)
            warm_mask3 = cv2.inRange(hsv, lower_warm3, upper_warm3)
            warm_mask = cv2.bitwise_or(warm_mask1, cv2.bitwise_or(warm_mask2, warm_mask3))
            
            # Apply sensitivity adjustment
            if color_sensitivity < 5:
                warm_mask = cv2.erode(warm_mask, np.ones((3, 3), np.uint8), iterations=1)
            elif color_sensitivity > 5:
                warm_mask = cv2.dilate(warm_mask, np.ones((3, 3), np.uint8), iterations=1)
            
            # Find contours of warm areas
            contours, _ = cv2.findContours(warm_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            
            for contour in contours:
                area = cv2.contourArea(contour)
                if area > min_light_size * 1.5:  # Larger minimum for color detection
                    M = cv2.moments(contour)
                    if M["m00"] != 0:
                        cx = int(M["m10"] / M["m00"])
                        cy = int(M["m01"] / M["m00"])
                        
                        # Calculate color intensity
                        mask = np.zeros(hsv.shape[:2], dtype=np.uint8)
                        cv2.fillPoly(mask, [contour], 255)
                        mean_saturation = cv2.mean(hsv[:, :, 1], mask)[0]
                        mean_value = cv2.mean(hsv[:, :, 2], mask)[0]
                        
                        if mean_saturation > 100 and mean_value > 150:
                            light_sources.append((cx, cy, mean_value))
        
        # Remove duplicates and sort by brightness
        unique_sources = []
        for source in light_sources:
            x, y, brightness = source
            # Check if this source is too close to existing ones
            too_close = False
            for existing in unique_sources:
                ex, ey, _ = existing
                distance = np.sqrt((x - ex)**2 + (y - ey)**2)
                if distance < min_light_size:
                    too_close = True
                    break
            if not too_close:
                unique_sources.append(source)
        
        # Sort by brightness and return top sources
        unique_sources.sort(key=lambda x: x[2], reverse=True)
        return [(x, y) for x, y, _ in unique_sources[:3]]  # Return top 3 light sources
    
    def _detect_objects_advanced(self, img_array, edge_threshold_low, edge_threshold_high, min_object_size):
        """Advanced object detection using professional edge detection and contour analysis."""
        import numpy as np
        import cv2
        
        # Convert to grayscale
        gray = cv2.cvtColor(img_array, cv2.COLOR_RGBA2GRAY)
        
        # Apply Gaussian blur to reduce noise
        blurred = cv2.GaussianBlur(gray, (5, 5), 0)
        
        # Use Canny edge detection with adjustable thresholds
        edges = cv2.Canny(blurred, edge_threshold_low, edge_threshold_high)
        
        # Morphological operations to connect nearby edges
        kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3))
        edges = cv2.morphologyEx(edges, cv2.MORPH_CLOSE, kernel)
        
        # Dilate to make edges more prominent
        edges = cv2.dilate(edges, kernel, iterations=1)
        
        # Find contours
        contours, _ = cv2.findContours(edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        
        objects = []
        for contour in contours:
            area = cv2.contourArea(contour)
            if area > min_object_size:
                # Get bounding rectangle
                x, y, w, h = cv2.boundingRect(contour)
                
                # Calculate additional properties
                perimeter = cv2.arcLength(contour, True)
                if perimeter > 0:
                    circularity = 4 * np.pi * area / (perimeter * perimeter)
                else:
                    circularity = 0
                
                # Calculate aspect ratio
                aspect_ratio = float(w) / h if h > 0 else 0
                
                # Calculate solidity (area / convex hull area)
                hull = cv2.convexHull(contour)
                hull_area = cv2.contourArea(hull)
                solidity = float(area) / hull_area if hull_area > 0 else 0
                
                objects.append({
                    'contour': contour,
                    'bbox': (x, y, w, h),
                    'center': (x + w//2, y + h//2),
                    'area': area,
                    'perimeter': perimeter,
                    'circularity': circularity,
                    'aspect_ratio': aspect_ratio,
                    'solidity': solidity
                })
        
        # Sort objects by area (largest first)
        objects.sort(key=lambda x: x['area'], reverse=True)
        
        return objects[:10]  # Return top 10 largest objects
    
    def _find_fallback_light_position(self, img_array):
        """Intelligent fallback for light position when no sources are detected."""
        import numpy as np
        import cv2
        
        height, width = img_array.shape[:2]
        
        # Analyze image to find the best fallback position
        gray = cv2.cvtColor(img_array, cv2.COLOR_RGBA2GRAY)
        
        # Find the brightest region
        min_val, max_val, min_loc, max_loc = cv2.minMaxLoc(gray)
        
        # If there's a reasonably bright area, use it
        if max_val > 100:
            return [max_loc]
        
        # Otherwise, use rule of thirds positioning
        # Try positions that would make sense for torch placement
        candidates = [
            (width // 3, height // 3),           # Top-left third
            (2 * width // 3, height // 3),       # Top-right third
            (width // 3, 2 * height // 3),       # Bottom-left third
            (2 * width // 3, 2 * height // 3),   # Bottom-right third
            (width // 2, height // 2),           # Center
        ]
        
        # Find the brightest candidate position
        best_pos = candidates[0]
        best_brightness = 0
        
        for x, y in candidates:
            # Sample a small area around the candidate
            x1, y1 = max(0, x-20), max(0, y-20)
            x2, y2 = min(width, x+20), min(height, y+20)
            region = gray[y1:y2, x1:x2]
            
            if region.size > 0:
                avg_brightness = np.mean(region)
                if avg_brightness > best_brightness:
                    best_brightness = avg_brightness
                    best_pos = (x, y)
        
        return [best_pos]
    
    def _create_professional_lighting_map(self, img_array, light_sources, radius, intensity, falloff_exponent):
        """Create professional lighting map with realistic falloff and multiple light sources."""
        import numpy as np
        
        height, width = img_array.shape[:2]
        lighting_map = np.zeros((height, width), dtype=np.float32)
        
        for light_x, light_y in light_sources:
            # Create distance map from light source
            y, x = np.ogrid[:height, :width]
            distance = np.sqrt((x - light_x)**2 + (y - light_y)**2)
            
            # Create realistic falloff with configurable exponent
            # Use inverse power law: I = I0 / (1 + (d/r)^n)
            normalized_distance = distance / radius
            light_strength = intensity / (1 + normalized_distance**falloff_exponent)
            
            # Apply smooth falloff curve
            light_strength = np.clip(light_strength, 0, 1)
            
            # Add to lighting map (use maximum to combine multiple lights)
            lighting_map = np.maximum(lighting_map, light_strength)
        
        # Normalize the final lighting map
        if lighting_map.max() > 0:
            lighting_map = lighting_map / lighting_map.max()
        
        return lighting_map
    
    def _apply_torch_color_advanced(self, lighting_map, torch_color, warmth):
        """Apply professional torch color and warmth with advanced color temperature control."""
        import numpy as np
        
        # Convert hex color to RGB
        torch_rgb = tuple(int(torch_color[i:i+2], 16) for i in (1, 3, 5))
        
        # Create colored lighting map
        colored_lighting = np.zeros((lighting_map.shape[0], lighting_map.shape[1], 3), dtype=np.float32)
        
        # Apply color with warmth adjustment
        for i, color_component in enumerate(torch_rgb):
            # Apply warmth as a multiplier that affects different channels differently
            if i == 0:  # Red channel - warmth increases red
                warmth_factor = warmth
            elif i == 1:  # Green channel - moderate warmth
                warmth_factor = 1.0 + (warmth - 1.0) * 0.7
            else:  # Blue channel - warmth decreases blue (cooler)
                warmth_factor = 1.0 - (warmth - 1.0) * 0.3
            
            colored_lighting[:, :, i] = lighting_map * (color_component / 255.0) * warmth_factor
        
        return colored_lighting
    
    def _add_realistic_flicker(self, lighting_map, flicker_amount):
        """Add realistic flickering effect with temporal variation."""
        import numpy as np
        
        # Create more realistic flicker pattern
        if len(lighting_map.shape) == 3:  # Colored lighting (height, width, 3)
            # Create flicker with spatial variation
            flicker = np.random.normal(1.0, flicker_amount / 200.0, lighting_map.shape[:2])
            # Add some spatial correlation to make it more realistic
            flicker = cv2.GaussianBlur(flicker, (5, 5), 1.0)
            flicker = np.clip(flicker, 0.7, 1.3)  # More conservative range
            flickered = lighting_map * flicker[:, :, np.newaxis]
        else:  # Grayscale lighting (height, width)
            flicker = np.random.normal(1.0, flicker_amount / 200.0, lighting_map.shape)
            flicker = cv2.GaussianBlur(flicker, (5, 5), 1.0)
            flicker = np.clip(flicker, 0.7, 1.3)
            flickered = lighting_map * flicker
        
        return np.clip(flickered, 0, 1)
    
    def _create_professional_shadow_map(self, img_array, light_sources, objects, shadow_length, shadow_softness, shadow_offset):
        """Create professional shadow map with realistic shadow casting."""
        import numpy as np
        import cv2
        
        height, width = img_array.shape[:2]
        shadow_map = np.ones((height, width), dtype=np.float32)
        
        for light_x, light_y in light_sources:
            for obj in objects:
                # Get object properties
                obj_x, obj_y = obj['center']
                obj_w, obj_h = obj['bbox'][2], obj['bbox'][3]
                
                # Calculate shadow direction (from light to object)
                dx = obj_x - light_x
                dy = obj_y - light_y
                distance = np.sqrt(dx**2 + dy**2)
                
                if distance > 0:
                    # Normalize direction
                    dx /= distance
                    dy /= distance
                    
                    # Add offset to make shadows more realistic
                    offset_x = dx * shadow_offset
                    offset_y = dy * shadow_offset
                    
                    # Create shadow area
                    shadow_start_x = obj_x + offset_x
                    shadow_start_y = obj_y + offset_y
                    shadow_end_x = shadow_start_x + dx * shadow_length
                    shadow_end_y = shadow_start_y + dy * shadow_length
                    
                    # Create shadow mask
                    shadow_mask = np.zeros((height, width), dtype=np.uint8)
                    
                    # Draw shadow as an ellipse with realistic proportions
                    shadow_center = (int(shadow_end_x), int(shadow_end_y))
                    shadow_size = (int(obj_w * 1.2), int(obj_h * 1.2))
                    
                    cv2.ellipse(shadow_mask, shadow_center, shadow_size, 0, 0, 360, 255, -1)
                    
                    # Apply professional softness with multiple blur passes
                    if shadow_softness > 1.0:
                        kernel_size = int(shadow_softness * 8)
                        if kernel_size % 2 == 0:
                            kernel_size += 1
                        shadow_mask = cv2.GaussianBlur(shadow_mask, (kernel_size, kernel_size), shadow_softness)
                    
                    # Convert to float and apply to shadow map
                    shadow_strength = shadow_mask.astype(np.float32) / 255.0
                    shadow_map = np.minimum(shadow_map, 1.0 - shadow_strength)
        
        return shadow_map
    
    def _apply_professional_shadows(self, lighting_map, shadow_map, shadow_darkness):
        """Apply professional shadows with realistic blending."""
        import numpy as np
        
        if len(lighting_map.shape) == 3:  # Colored lighting
            shadow_factor = 1.0 - (shadow_map * shadow_darkness)
            shadow_factor = shadow_factor[:, :, np.newaxis]
            return lighting_map * shadow_factor
        else:  # Grayscale lighting
            shadow_factor = 1.0 - (shadow_map * shadow_darkness)
            return lighting_map * shadow_factor
    
    def _apply_professional_lighting(self, img_array, lighting_map, ambient_light, contrast_boost):
        """Apply professional lighting with advanced blending modes."""
        import numpy as np
        
        # Convert image to float
        img_float = img_array.astype(np.float32) / 255.0
        
        # Apply ambient light
        img_float = img_float * ambient_light
        
        # Apply lighting map with professional blending
        if len(lighting_map.shape) == 3:  # Colored lighting
            # Use screen blending for more realistic light addition
            for i in range(3):
                img_float[:, :, i] = 1.0 - (1.0 - img_float[:, :, i]) * (1.0 - lighting_map[:, :, i])
        else:  # Grayscale lighting
            for i in range(3):
                img_float[:, :, i] = 1.0 - (1.0 - img_float[:, :, i]) * (1.0 - lighting_map)
        
        # Apply contrast boost
        img_float = np.clip((img_float - 0.5) * contrast_boost + 0.5, 0, 1)
        
        # Convert back to uint8
        return (img_float * 255).astype(np.uint8)
    
    def _add_rim_lighting(self, img_array, light_sources, torch_color):
        """Add rim lighting effect for professional look."""
        import numpy as np
        import cv2
        
        if not light_sources:
            return img_array
        
        # Convert to grayscale for edge detection
        gray = cv2.cvtColor(img_array, cv2.COLOR_RGBA2GRAY)
        
        # Find edges
        edges = cv2.Canny(gray, 50, 150)
        
        # Dilate edges to create rim
        kernel = np.ones((3, 3), np.uint8)
        rim_mask = cv2.dilate(edges, kernel, iterations=2)
        
        # Apply rim lighting
        result = img_array.copy().astype(np.float32)
        torch_rgb = tuple(int(torch_color[i:i+2], 16) for i in (1, 3, 5))
        
        rim_factor = 0.1  # Subtle rim lighting
        for i, color_component in enumerate(torch_rgb):
            result[:, :, i] = np.clip(result[:, :, i] + rim_mask * (color_component / 255.0) * rim_factor, 0, 255)
        
        return result.astype(np.uint8)
    
    def _add_professional_atmosphere(self, img_array, density, torch_color, light_sources):
        """Add professional atmospheric effects."""
        import numpy as np
        
        if density == 0:
            return img_array
        
        height, width = img_array.shape[:2]
        
        # Create atmospheric overlay
        atmosphere = np.zeros((height, width, 3), dtype=np.float32)
        torch_rgb = tuple(int(torch_color[i:i+2], 16) for i in (1, 3, 5))
        
        # Add subtle atmospheric tint
        for i, color_component in enumerate(torch_rgb):
            atmosphere[:, :, i] = (color_component / 255.0) * (density / 100.0) * 0.05
        
        # Apply atmospheric effect
        img_float = img_array.astype(np.float32) / 255.0
        img_float[:, :, :3] = np.clip(img_float[:, :, :3] + atmosphere, 0, 1)
        
        return (img_float * 255).astype(np.uint8)
    
    def _create_shadow_map(self, img_array, light_sources, objects, shadow_length, softness):
        """Create shadow map based on objects and light sources."""
        import numpy as np
        import cv2
        
        height, width = img_array.shape[:2]
        shadow_map = np.ones((height, width), dtype=np.float32)
        
        for light_x, light_y in light_sources:
            for obj in objects:
                # Get object center and size
                obj_x, obj_y = obj['center']
                obj_w, obj_h = obj['bbox'][2], obj['bbox'][3]
                
                # Calculate shadow direction (from light to object)
                dx = obj_x - light_x
                dy = obj_y - light_y
                distance = np.sqrt(dx**2 + dy**2)
                
                if distance > 0:
                    # Normalize direction
                    dx /= distance
                    dy /= distance
                    
                    # Create shadow area
                    shadow_start_x = obj_x + dx * (obj_w // 2)
                    shadow_start_y = obj_y + dy * (obj_h // 2)
                    shadow_end_x = shadow_start_x + dx * shadow_length
                    shadow_end_y = shadow_start_y + dy * shadow_length
                    
                    # Create shadow mask
                    shadow_mask = np.zeros((height, width), dtype=np.uint8)
                    
                    # Draw shadow as an ellipse
                    shadow_center = (int(shadow_end_x), int(shadow_end_y))
                    shadow_size = (int(obj_w * 1.5), int(obj_h * 1.5))
                    
                    cv2.ellipse(shadow_mask, shadow_center, shadow_size, 0, 0, 360, 255, -1)
                    
                    # Apply softness (blur)
                    if softness > 1.0:
                        kernel_size = int(softness * 10)
                        if kernel_size % 2 == 0:
                            kernel_size += 1
                        shadow_mask = cv2.GaussianBlur(shadow_mask, (kernel_size, kernel_size), softness)
                    
                    # Convert to float and apply to shadow map
                    shadow_strength = shadow_mask.astype(np.float32) / 255.0
                    shadow_map = np.minimum(shadow_map, 1.0 - shadow_strength)
        
        return shadow_map
    
    def _apply_shadows(self, lighting_map, shadow_map, shadow_darkness):
        """Apply shadows to the lighting map."""
        import numpy as np
        
        if len(lighting_map.shape) == 3:  # Colored lighting
            shadow_factor = 1.0 - (shadow_map * shadow_darkness)
            shadow_factor = shadow_factor[:, :, np.newaxis]
            return lighting_map * shadow_factor
        else:  # Grayscale lighting
            shadow_factor = 1.0 - (shadow_map * shadow_darkness)
            return lighting_map * shadow_factor
    
    def _apply_lighting_to_image(self, img_array, lighting_map, ambient_light):
        """Apply the lighting map to the original image."""
        import numpy as np
        
        # Convert image to float
        img_float = img_array.astype(np.float32) / 255.0
        
        # Apply ambient light
        img_float = img_float * ambient_light
        
        # Apply lighting map
        if len(lighting_map.shape) == 3:  # Colored lighting
            # Add colored lighting to each channel
            for i in range(3):
                img_float[:, :, i] = np.clip(img_float[:, :, i] + lighting_map[:, :, i], 0, 1)
        else:  # Grayscale lighting
            # Apply lighting to all channels
            for i in range(3):
                img_float[:, :, i] = np.clip(img_float[:, :, i] + lighting_map, 0, 1)
        
        # Convert back to uint8
        return (img_float * 255).astype(np.uint8)
    
    def _add_atmospheric_effects(self, img_array, density, torch_color):
        """Add atmospheric effects like smoke or haze."""
        import numpy as np
        
        if density == 0:
            return img_array
        
        # Create atmospheric overlay
        height, width = img_array.shape[:2]
        atmosphere = np.zeros((height, width, 3), dtype=np.float32)
        
        # Convert torch color to RGB
        torch_rgb = tuple(int(torch_color[i:i+2], 16) for i in (1, 3, 5))
        
        # Create subtle atmospheric tint
        for i, color_component in enumerate(torch_rgb):
            atmosphere[:, :, i] = (color_component / 255.0) * (density / 100.0) * 0.1
        
        # Apply atmospheric effect
        img_float = img_array.astype(np.float32) / 255.0
        img_float[:, :, :3] = np.clip(img_float[:, :, :3] + atmosphere, 0, 1)
        
        return (img_float * 255).astype(np.uint8)
    
    def _apply_vibrant_cel_shading(self, img_array, levels, contrast, shadow_intensity, highlight_intensity):
        """Apply vibrant cel shading that preserves brightness and creates Wind Waker style."""
        import numpy as np
        
        # Convert to grayscale for cel shading calculation
        gray = np.dot(img_array[...,:3], [0.299, 0.587, 0.114])
        
        # Apply gentle contrast
        gray = np.clip((gray - 128) * contrast + 128, 0, 255)
        
        # Quantize to cel levels
        step = 255 / (levels - 1)
        gray_quantized = np.round(gray / step) * step
        
        # Create vibrant cel shading mask
        cel_mask = gray_quantized / 255.0
        
        # Apply cel shading with vibrant enhancement
        result = img_array.copy()
        for i in range(3):  # RGB channels
            # Apply cel shading
            shaded = result[..., i] * cel_mask
            
            # Enhance highlights and preserve shadows
            enhanced = np.where(
                cel_mask > 0.7,  # Highlight areas
                np.clip(shaded * highlight_intensity, 0, 255),
                np.where(
                    cel_mask < 0.3,  # Shadow areas
                    np.clip(shaded * shadow_intensity, 0, 255),
                    shaded  # Mid-tones unchanged
                )
            )
            result[..., i] = enhanced
        
        return result
    
    def _reduce_colors_vibrantly(self, pil_img, levels):
        """Reduce colors while preserving vibrancy for Wind Waker style."""
        from PIL import Image
        
        # Use more colors to preserve vibrancy
        actual_levels = max(levels, 12)  # Minimum 12 colors for vibrancy
        
        # Convert to P mode with reduced palette
        img_p = pil_img.convert('P', palette=Image.ADAPTIVE, colors=actual_levels)
        
        # Convert back to RGBA
        return img_p.convert('RGBA')
    
    def _add_bold_outlines(self, pil_img, width, color, method):
        """Add bold, clean outlines for Wind Waker style."""
        import cv2
        import numpy as np
        from PIL import Image
        
        # Convert PIL to numpy
        img_array = np.array(pil_img)
        
        # Convert to grayscale for edge detection
        gray = cv2.cvtColor(img_array, cv2.COLOR_RGBA2GRAY)
        
        # Apply edge detection
        if method == 'Sobel':
            edges = cv2.Sobel(gray, cv2.CV_64F, 1, 1, ksize=3)
            edges = np.abs(edges)
        elif method == 'Canny':
            edges = cv2.Canny(gray, 30, 100)  # Lower thresholds for cleaner edges
        else:  # Laplacian
            edges = cv2.Laplacian(gray, cv2.CV_64F)
            edges = np.abs(edges)
        
        # Threshold edges (lower threshold for cleaner outlines)
        edges = (edges > 20).astype(np.uint8) * 255
        
        # Dilate edges to make them bolder
        kernel = np.ones((width, width), np.uint8)
        edges = cv2.dilate(edges, kernel, iterations=1)
        
        # Convert outline color to RGB
        color_rgb = tuple(int(color[i:i+2], 16) for i in (1, 3, 5))
        
        # Create outline mask
        outline_mask = edges > 0
        
        # Apply bold outlines
        result = img_array.copy()
        result[outline_mask] = [*color_rgb, 255]  # Set outline color with full alpha
        
        return Image.fromarray(result, mode='RGBA')
    
    def _reduce_colors(self, pil_img, levels):
        """Reduce color palette to specified number of levels."""
        from PIL import Image
        
        # Convert to P mode with reduced palette
        img_p = pil_img.convert('P', palette=Image.ADAPTIVE, colors=levels)
        
        # Convert back to RGBA
        return img_p.convert('RGBA')
    
    def _reduce_colors_lightly(self, pil_img, levels):
        """Reduce colors lightly to preserve vibrancy."""
        from PIL import Image
        
        # Use more colors to preserve vibrancy
        actual_levels = max(levels, 16)  # Minimum 16 colors
        
        # Convert to P mode with reduced palette
        img_p = pil_img.convert('P', palette=Image.ADAPTIVE, colors=actual_levels)
        
        # Convert back to RGBA
        return img_p.convert('RGBA')
    
    def _apply_dithering(self, pil_img, method):
        """Apply very subtle dithering to reduce banding without darkening the image."""
        from PIL import Image
        import numpy as np
        
        if method == 'Floyd-Steinberg':
            # Very subtle dithering - barely noticeable
            img_array = np.array(pil_img)
            h, w = img_array.shape[:2]
            
            # Apply extremely light dithering matrix
            dither_matrix = np.array([
                [0, 1, 0, 1],
                [1, 0, 1, 0],
                [0, 1, 0, 1],
                [1, 0, 1, 0]
            ]) / 16.0  # Even smaller divisor for very light effect
            
            for y in range(h):
                for x in range(w):
                    for c in range(3):  # RGB channels
                        old_pixel = img_array[y, x, c]
                        # Very subtle adjustment - only for extreme mid-tones
                        adjustment = dither_matrix[y % 4, x % 4] * 1  # Minimal adjustment
                        # Only apply to pixels that are very close to 128 (mid-tone)
                        if abs(old_pixel - 128) < 10:  # Only affect pixels very close to mid-tone
                            new_pixel = np.clip(old_pixel + adjustment, 0, 255)
                        else:
                            new_pixel = old_pixel  # Keep original for all other tones
                        img_array[y, x, c] = new_pixel
            
            return Image.fromarray(img_array, mode='RGBA')
        elif method == 'Ordered':
            # Very subtle ordered dithering
            img_array = np.array(pil_img)
            h, w = img_array.shape[:2]
            
            # Extremely light dithering pattern
            dither_matrix = np.array([
                [0, 0.5, 0, 0.5],
                [0.5, 0, 0.5, 0],
                [0, 0.5, 0, 0.5],
                [0.5, 0, 0.5, 0]
            ]) / 8.0
            
            for y in range(h):
                for x in range(w):
                    for c in range(3):  # RGB channels
                        old_pixel = img_array[y, x, c]
                        # Extremely subtle dithering - barely visible
                        adjustment = dither_matrix[y % 4, x % 4] * 0.5  # Very small adjustment
                        # Only apply to very specific mid-tone ranges
                        if 120 < old_pixel < 136:  # Very narrow range around mid-tone
                            new_pixel = np.clip(old_pixel + adjustment, 0, 255)
                        else:
                            new_pixel = old_pixel  # Keep original for all other tones
                        img_array[y, x, c] = new_pixel
            
            return Image.fromarray(img_array, mode='RGBA')
        
        return pil_img
    
    def _add_outlines(self, pil_img, width, color, method):
        """Add outlines to the image."""
        import cv2
        import numpy as np
        from PIL import Image
        
        # Convert PIL to numpy
        img_array = np.array(pil_img)
        
        # Convert to grayscale for edge detection
        gray = cv2.cvtColor(img_array, cv2.COLOR_RGBA2GRAY)
        
        # Apply edge detection
        if method == 'Sobel':
            edges = cv2.Sobel(gray, cv2.CV_64F, 1, 1, ksize=3)
            edges = np.abs(edges)
        elif method == 'Canny':
            edges = cv2.Canny(gray, 50, 150)
        else:  # Laplacian
            edges = cv2.Laplacian(gray, cv2.CV_64F)
            edges = np.abs(edges)
        
        # Threshold edges
        edges = (edges > 30).astype(np.uint8) * 255
        
        # Dilate edges to make them thicker
        kernel = np.ones((width, width), np.uint8)
        edges = cv2.dilate(edges, kernel, iterations=1)
        
        # Convert outline color to RGB
        color_rgb = tuple(int(color[i:i+2], 16) for i in (1, 3, 5))
        
        # Create outline mask
        outline_mask = edges > 0
        
        # Apply outlines
        result = img_array.copy()
        result[outline_mask] = [*color_rgb, 255]  # Set outline color with full alpha
        
        return Image.fromarray(result, mode='RGBA')
    
    
    def _apply_lighting_effect(self, img_array, lighting_type, tint_r, tint_g, tint_b, 
                              intensity, glow_radius, animate_glow, h, w, preserve_colors=True):
        """Apply lighting effects like torch glow, sunlight, etc."""
        import numpy as np
        import math
        
        # Create glow mask based on lighting type
        if lighting_type == 'Torch Glow':
            # Create circular glow from center
            center_x, center_y = w // 2, h // 2
            y, x = np.ogrid[:h, :w]
            distance = np.sqrt((x - center_x)**2 + (y - center_y)**2)
            max_distance = min(w, h) * glow_radius * 0.5
            glow_mask = np.clip(1.0 - (distance / max_distance), 0, 1)
            
            # Add flickering for torch effect
            if animate_glow:
                flicker = 0.8 + 0.4 * math.sin(distance * 0.1)  # Flickering pattern
                glow_mask *= flicker
            
        elif lighting_type == 'Sunlight':
            # Create directional light from top-left
            y, x = np.ogrid[:h, :w]
            angle = np.arctan2(y, x) + math.pi/4  # 45 degree angle
            glow_mask = np.clip(np.cos(angle) * 0.5 + 0.5, 0, 1)
            
        elif lighting_type == 'Moonlight':
            # Soft blue glow from center
            center_x, center_y = w // 2, h // 2
            y, x = np.ogrid[:h, :w]
            distance = np.sqrt((x - center_x)**2 + (y - center_y)**2)
            max_distance = min(w, h) * glow_radius * 0.7
            glow_mask = np.clip(1.0 - (distance / max_distance), 0, 1)
            # Make it more blue
            tint_r = int(tint_r * 0.7)
            tint_g = int(tint_g * 0.8) 
            tint_b = int(tint_b * 1.2)
            
        elif lighting_type == 'Neon Glow':
            # Create multiple bright spots
            glow_mask = np.zeros((h, w))
            for i in range(3):
                center_x = w * (0.2 + i * 0.3)
                center_y = h * (0.3 + i * 0.2)
                y, x = np.ogrid[:h, :w]
                distance = np.sqrt((x - center_x)**2 + (y - center_y)**2)
                spot = np.exp(-distance / (min(w, h) * 0.1))
                glow_mask += spot
            glow_mask = np.clip(glow_mask, 0, 1)
            
        else:  # Candle Light
            # Small, warm glow from center
            center_x, center_y = w // 2, h // 2
            y, x = np.ogrid[:h, :w]
            distance = np.sqrt((x - center_x)**2 + (y - center_y)**2)
            max_distance = min(w, h) * glow_radius * 0.3
            glow_mask = np.exp(-distance / (max_distance * 0.5))
        
        # Apply glow effect
        glow_mask = glow_mask[:, :, np.newaxis]
        
        if preserve_colors:
            # Blend with original colors
            for i in range(3):
                img_array[:,:,i] = np.clip(
                    img_array[:,:,i] * (1 - intensity) + 
                    img_array[:,:,i] * glow_mask[:,:,0] * intensity * (tint_r if i == 0 else tint_g if i == 1 else tint_b) / 255.0,
                    0, 255
                )
        else:
            # Apply tinted glow
            for i in range(3):
                tint_val = tint_r if i == 0 else tint_g if i == 1 else tint_b
                img_array[:,:,i] = np.clip(
                    img_array[:,:,i] * (1 - intensity * glow_mask[:,:,0]) + 
                    tint_val * intensity * glow_mask[:,:,0],
                    0, 255
                )
        
        return img_array
    
    def _apply_artistic_style(self, img_array, art_style, intensity, contrast, h, w):
        """Apply artistic styles like 8-bit, anime, etc."""
        import numpy as np
        
        if art_style == '8-bit Pixel':
            # Reduce to 16 colors and pixelate
            # Quantize colors
            img_array = (img_array // 16) * 16
            # Add dithering
            for y in range(0, h-1, 2):
                for x in range(0, w-1, 2):
                    if (x + y) % 4 == 0:  # Checkerboard dithering
                        img_array[y:y+2, x:x+2] = (img_array[y:y+2, x:x+2] // 32) * 32
            
        elif art_style == '16-bit SNES':
            # Smooth gradients with more colors
            img_array = (img_array // 8) * 8
            # Add subtle dithering
            noise = np.random.randint(-8, 8, img_array.shape)
            img_array = np.clip(img_array + noise, 0, 255)
            
        elif art_style == 'Anime Cel':
            # Cel shading with flat colors and bold outlines
            # Reduce to fewer colors
            img_array = (img_array // 32) * 32
            # Increase contrast for bold look
            img_array = np.clip(img_array * 1.3, 0, 255)
            
        elif art_style == 'Watercolor':
            # Soft, bleeding effect
            # Blur slightly
            from scipy import ndimage
            for i in range(3):
                img_array[:,:,i] = ndimage.gaussian_filter(img_array[:,:,i], sigma=1.0)
            # Reduce saturation
            gray = np.dot(img_array[...,:3], [0.299, 0.587, 0.114])
            for i in range(3):
                img_array[:,:,i] = np.clip(img_array[:,:,i] * 0.7 + gray * 0.3, 0, 255)
                
        elif art_style == 'Oil Painting':
            # Thick brushstrokes effect
            # Reduce colors and add texture
            img_array = (img_array // 16) * 16
            # Add noise for texture
            noise = np.random.randint(-16, 16, img_array.shape)
            img_array = np.clip(img_array + noise, 0, 255)
        
        return img_array

    def _apply_mirror_flip_effect(self, parameters):
        """Apply mirror/flip effect based on dialog parameters."""
        horizontal = parameters.get('horizontal', False)
        vertical = parameters.get('vertical', False)
        
        if not horizontal and not vertical:
            return  # No transformation needed
            
        # Get current layer and frame
        lm = state.layer_manager
        if lm.current_layer_index >= len(lm.layers):
            return
            
        layer = lm.layers[lm.current_layer_index]
        if layer.current_frame >= len(layer.frames):
            return
            
        frame = layer.get_frame(layer.current_frame)
        if frame.image is None:
            return
            
        # Apply transformation
        pil_img = frame.image
        if horizontal and vertical:
            # Both - equivalent to 180° rotation
            pil_img = pil_img.transpose(Image.ROTATE_180)
        elif horizontal:
            # Horizontal flip
            pil_img = pil_img.transpose(Image.FLIP_LEFT_RIGHT)
        elif vertical:
            # Vertical flip
            pil_img = pil_img.transpose(Image.FLIP_TOP_BOTTOM)
            
        # Update the frame
        frame.image = pil_img
        
        # Refresh the canvas
        self.force_canvas_and_preview_refresh()

    def _apply_rotate_effect(self, parameters):
        """Apply rotation effect based on dialog parameters."""
        from PIL import Image
        import numpy as np
        
        angle = parameters.get('angle', 0)
        
        if angle == 0:
            return  # No transformation needed
            
        # Get current layer and frame
        lm = state.layer_manager
        layer = lm.get_current_layer()
        if layer is None:
            return
            
        frame_idx = lm.current_frame
        if frame_idx >= len(layer.frames):
            return
            
        frame = layer.get_frame(frame_idx)
        if frame.image is None:
            return
            
        # Push undo state before rotation
        state.push_undo()
        
        # Convert numpy array to PIL Image
        img_array = frame.image
        if len(img_array.shape) == 3 and img_array.shape[2] == 4:
            # RGBA
            pil_img = Image.fromarray(img_array, 'RGBA')
        elif len(img_array.shape) == 3:
            # RGB
            pil_img = Image.fromarray(img_array, 'RGB')
        else:
            # Grayscale
            pil_img = Image.fromarray(img_array, 'L')
            
        # Apply rotation
        rotated_pil = pil_img.rotate(-angle, expand=True, resample=Image.BICUBIC)  # Negative for clockwise
        
        # Convert back to numpy array
        rotated_array = np.array(rotated_pil)
        
        # If rotation changed dimensions, we may need to update canvas size
        # For now, just update the frame image
        frame.image = rotated_array
        
        # If rotation expanded the image (expand=True), we might need to update canvas size
        # This would be handled in a future enhancement
        # For now, the rotated image is stored in the frame
        
        # Refresh the canvas
        self.force_canvas_and_preview_refresh()
    
    def _fast_ordered_dither(self, img_array, intensity):
        """Fast ordered dithering using Bayer matrix - vectorized."""
        height, width = img_array.shape[:2]
        
        # Calculate levels
        max_levels = 256
        min_levels = 4
        levels = max(min_levels, int(max_levels * (1 - intensity * 0.9)))
        
        # 4x4 Bayer matrix (smaller and faster than 8x8)
        bayer = np.array([
            [ 0,  8,  2, 10],
            [12,  4, 14,  6],
            [ 3, 11,  1,  9],
            [15,  7, 13,  5]
        ]) / 16.0
        
        # Create tile grid
        y_tile = np.arange(height) % 4
        x_tile = np.arange(width) % 4
        Y_tile, X_tile = np.meshgrid(y_tile, x_tile, indexing='ij')
        
        # Get thresholds for all pixels at once
        thresholds = bayer[Y_tile, X_tile]
        
        # Quantize
        step = 256 / levels
        result = np.round(img_array / step) * step
        
        # Apply dither threshold
        thresholds_3d = thresholds[:, :, np.newaxis]
        noise = thresholds_3d * 2 - 1  # Map 0-1 to -1 to 1
        result = result + noise * step * 0.5 * intensity
        
        return np.clip(result, 0, 255).astype(np.uint8)
    
    def _fast_random_dither(self, img_array, intensity):
        """Fast random dithering - vectorized."""
        height, width = img_array.shape[:2]
        
        # Calculate levels
        max_levels = 256
        min_levels = 4
        levels = max(min_levels, int(max_levels * (1 - intensity * 0.9)))
        
        # Generate noise
        np.random.seed(42)
        noise = np.random.uniform(-1, 1, (height, width, 3)) * intensity * 32
        
        # Quantize
        step = 256 / levels
        result = np.round(img_array / step) * step
        
        # Apply noise
        result = result + noise
        
        return np.clip(result, 0, 255).astype(np.uint8)
    
    def _pixelate_blocks(self, img_array, block_size):
        """Create pixelated blocks by averaging colors."""
        height, width = img_array.shape[:2]
        result = img_array.copy()
        
        for y in range(0, height, block_size):
            for x in range(0, width, block_size):
                # Get block bounds
                y_end = min(y + block_size, height)
                x_end = min(x + block_size, width)
                
                # Calculate average color for this block
                block = img_array[y:y_end, x:x_end]
                avg_color = np.mean(block, axis=(0, 1))
                
                # Apply average color to entire block
                result[y:y_end, x:x_end] = avg_color
        
        return result
    
    def _quantize_minecraft_style(self, img_array, palette_rgb):
        """Quantize colors to Minecraft-style palette."""
        height, width = img_array.shape[:2]
        result = img_array.copy()
        
        # Minecraft-style color mapping
        minecraft_colors = {
            'dirt': [139, 69, 19],      # Brown
            'stone': [128, 128, 128],   # Gray
            'grass': [34, 139, 34],     # Green
            'water': [0, 0, 255],       # Blue
            'sand': [244, 164, 96],     # Tan
            'wood': [160, 82, 45],      # Brown
            'leaves': [0, 100, 0],      # Dark green
            'coal': [64, 64, 64],       # Dark gray
            'gold': [255, 215, 0],      # Gold
            'iron': [192, 192, 192],    # Silver
        }
        
        palette_rgb.extend(minecraft_colors.values())
        
        for y in range(height):
            for x in range(width):
                pixel = img_array[y, x]
                # Find closest color in palette
                closest_color = self._find_closest_color(pixel, palette_rgb)
                result[y, x] = closest_color
        
        return result
    
    def _quantize_retro_style(self, img_array, palette_rgb):
        """Quantize colors to retro/8-bit style."""
        height, width = img_array.shape[:2]
        result = img_array.copy()
        
        # Retro color palette (8-bit style)
        retro_colors = [
            [0, 0, 0],        # Black
            [255, 255, 255],  # White
            [255, 0, 0],      # Red
            [0, 255, 0],      # Green
            [0, 0, 255],      # Blue
            [255, 255, 0],    # Yellow
            [255, 0, 255],    # Magenta
            [0, 255, 255],    # Cyan
            [128, 128, 128],  # Gray
            [255, 128, 0],    # Orange
            [128, 0, 128],    # Purple
            [0, 128, 128],    # Teal
        ]
        
        palette_rgb.extend(retro_colors)
        
        for y in range(height):
            for x in range(width):
                pixel = img_array[y, x]
                # Find closest color in palette
                closest_color = self._find_closest_color(pixel, palette_rgb)
                result[y, x] = closest_color
        
        return result
    
    def _quantize_custom_palette(self, img_array, palette_rgb):
        """Quantize colors to custom palette."""
        height, width = img_array.shape[:2]
        result = img_array.copy()
        
        for y in range(height):
            for x in range(width):
                pixel = img_array[y, x]
                # Find closest color in custom palette
                closest_color = self._find_closest_color(pixel, palette_rgb)
                result[y, x] = closest_color
        
        return result
    
    def _find_closest_color(self, pixel, palette_rgb):
        """Find the closest color in the palette to the given pixel."""
        min_distance = float('inf')
        closest_color = [0, 0, 0]
        
        for color in palette_rgb:
            # Calculate Euclidean distance in RGB space
            distance = np.sqrt(np.sum((pixel[:3] - color) ** 2))
            if distance < min_distance:
                min_distance = distance
                closest_color = color
        
        return closest_color
    
    def _apply_map_generator_effect(self, pil_img, parameters):
        """Apply 2D map generation effect with enhanced elevation features - optimized version."""
        print(f"DEBUG: _apply_map_generator_effect called with parameters: {parameters}")
        import random
        import math
        
        # Get parameters
        scale = parameters.get('scale', 0.05)
        detail = parameters.get('detail', 4)
        map_type = parameters.get('map_type', 'Minecraft')
        biome_variation = parameters.get('biome_variation', 0.3)
        seed = parameters.get('seed', 12345)
        temperature = parameters.get('temperature', 0.5)
        humidity = parameters.get('humidity', 0.5)
        
        # Performance optimization: reduce detail for very large images
        w, h = pil_img.size
        total_pixels = w * h
        if total_pixels > 2000000:  # 2MP+ (e.g., 1920x1080)
            # Reduce detail octaves for large images to maintain performance
            if detail > 4:
                detail = max(3, detail - 1)
                # Also reduce scale slightly to compensate
                scale = scale * 1.1
        
        # New elevation parameters
        elevation_intensity = parameters.get('elevation_intensity', 100) / 100.0
        mountain_height = parameters.get('mountain_height', 100) / 100.0
        hill_prominence = parameters.get('hill_prominence', 100) / 100.0
        sea_level = parameters.get('sea_level', 30) / 100.0
        elevation_mode = parameters.get('elevation_mode', 'Normal')
        show_contours = parameters.get('show_contours', False)
        contour_spacing = parameters.get('contour_spacing', 15) / 100.0
        
        # Color definitions
        colors = {
            'deep_water': parameters.get('deep_water_color', '#000080'),
            'shallow_water': parameters.get('shallow_water_color', '#4169E1'),
            'sand': parameters.get('sand_color', '#F4A460'),
            'grass': parameters.get('grass_color', '#228B22'),
            'forest': parameters.get('forest_color', '#228B22'),
            'mountain': parameters.get('mountain_color', '#8B4513'),
            'snow': parameters.get('snow_color', '#FFFFFF'),
            'desert': parameters.get('desert_color', '#DEB887'),
            'contour': parameters.get('contour_color', '#000000')
        }
        
        def hex_to_rgb(hex_color):
            """Convert hex color to RGB tuple."""
            hex_color = hex_color.lstrip('#')
            return tuple(int(hex_color[i:i+2], 16) for i in (0, 2, 4))
        
        # Vectorized noise functions
        def vectorized_noise(x, y):
            """Vectorized coherent noise function."""
            n = (x * 73856093 + y * 19349663 + seed).astype(np.int64) & 0x7fffffff
            n = (n << 13) ^ n
            return ((n * (n * n * 15731 + 789221) + 1376312589) & 0x7fffffff) / 0x7fffffff
        
        def vectorized_smooth_noise(x, y):
            """Vectorized smooth noise using bilinear interpolation."""
            x_int = np.floor(x).astype(int)
            y_int = np.floor(y).astype(int)
            x_frac = x - x_int
            y_frac = y - y_int
            
            v1 = vectorized_noise(x_int, y_int)
            v2 = vectorized_noise(x_int + 1, y_int)
            v3 = vectorized_noise(x_int, y_int + 1)
            v4 = vectorized_noise(x_int + 1, y_int + 1)
            
            i1 = v1 * (1 - x_frac) + v2 * x_frac
            i2 = v3 * (1 - x_frac) + v4 * x_frac
            return i1 * (1 - y_frac) + i2 * y_frac
        
        def vectorized_fractal_noise(x, y, octaves, persistence):
            """Vectorized fractal noise for realistic terrain."""
            total = np.zeros_like(x)
            frequency = 1.0
            amplitude = 1.0
            max_value = 0
            
            for i in range(octaves):
                total += vectorized_smooth_noise(x * frequency, y * frequency) * amplitude
                max_value += amplitude
                amplitude *= persistence
                frequency *= 2
            
            return np.clip(total / max_value, 0, 1)
        
        # Generate map
        w, h = pil_img.size
        img_array = np.array(pil_img)
        
        # Set random seed
        random.seed(seed)
        
        # Create coordinate grids
        x_coords, y_coords = np.meshgrid(np.arange(w), np.arange(h))
        nx_coords = x_coords * scale
        ny_coords = y_coords * scale
        
        # Generate base height using vectorized fractal noise
        base_height = vectorized_fractal_noise(nx_coords, ny_coords, detail, 0.5)
        
        # Generate additional noise layers for more 3D-like terrain
        detail_noise = vectorized_fractal_noise(nx_coords * 4, ny_coords * 4, 2, 0.3) * 0.2
        ridge_noise = vectorized_fractal_noise(nx_coords * 8, ny_coords * 8, 1, 0.2) * 0.1
        
        # Combine noise layers for more realistic terrain
        height = base_height + detail_noise + ridge_noise
        
        # Apply elevation intensity scaling
        height = (height - 0.5) * elevation_intensity + 0.5
        height = np.clip(height, 0, 1)
        
        # Apply map type specific modifications
        if map_type == "Island":
            # Vectorized island factor calculation
            center_x, center_y = w / 2, h / 2
            max_dist = math.sqrt(center_x**2 + center_y**2)
            dist = np.sqrt((x_coords - center_x)**2 + (y_coords - center_y)**2)
            island_factors = np.maximum(0, 1 - dist / max_dist)
            height *= island_factors
        elif map_type == "Archipelago":
            # Vectorized archipelago calculation
            island_centers = [(w * 0.2, h * 0.2), (w * 0.8, h * 0.8), (w * 0.8, h * 0.2), (w * 0.2, h * 0.8)]
            island_factor = np.zeros_like(height)
            for center_x, center_y in island_centers:
                dist = np.sqrt((x_coords - center_x)**2 + (y_coords - center_y)**2)
                island_factor = np.maximum(island_factor, np.maximum(0, 1 - dist / (w * 0.15)))
            height *= island_factor
        elif map_type == "Desert":
            # Vectorized desert modifications
            height = height * 0.7 + 0.1
            dune_noise = vectorized_fractal_noise(nx_coords * 3, ny_coords * 3, 3, 0.4) * 0.3
            height += dune_noise
        elif map_type == "Snow":
            # Vectorized snow modifications
            height = height * 0.8 + 0.2
            snow_noise = vectorized_fractal_noise(nx_coords * 2, ny_coords * 2, 2, 0.5) * 0.4
            height += snow_noise
        elif map_type == "Jungle":
            # Vectorized jungle modifications
            height = height * 0.6 + 0.2
            jungle_noise = vectorized_fractal_noise(nx_coords * 5, ny_coords * 5, 4, 0.3) * 0.3
            height += jungle_noise
        elif map_type == "Ocean":
            # Vectorized ocean modifications
            height = height * 0.5
            ocean_noise = vectorized_fractal_noise(nx_coords * 2, ny_coords * 2, 3, 0.4) * 0.3
            height += ocean_noise
        
        # Generate biome variation
        biome_noise = vectorized_fractal_noise(nx_coords * 2, ny_coords * 2, 2, 0.5)
        moisture_noise = vectorized_fractal_noise(nx_coords * 3, ny_coords * 3, 2, 0.4)
        
        # Create color map using vectorized operations
        color_map = np.zeros((h, w, 3), dtype=np.uint8)
        
        # Vectorized terrain type determination
        if map_type == "Ocean":
            # Ocean floor biomes
            deep_water_mask = height < 0.2
            shallow_water_mask = (height >= 0.2) & (height < 0.4)
            underwater_plains_mask = (height >= 0.4) & (height < 0.6)
            underwater_mountains_mask = height >= 0.6
            
            color_map[deep_water_mask] = hex_to_rgb(colors['deep_water'])
            color_map[shallow_water_mask] = hex_to_rgb(colors['shallow_water'])
            color_map[underwater_plains_mask] = hex_to_rgb('#2F4F4F')
            color_map[underwater_mountains_mask] = hex_to_rgb('#4682B4')
            
        elif map_type == "Desert":
            # Desert biomes
            sand_mask = height < 0.3
            desert_plains_mask = (height >= 0.3) & (height < 0.6)
            oasis_mask = desert_plains_mask & (moisture_noise > 0.7)
            desert_mountains_mask = height >= 0.6
            
            color_map[sand_mask] = hex_to_rgb(colors['sand'])
            color_map[desert_plains_mask] = hex_to_rgb(colors['desert'])
            color_map[oasis_mask] = hex_to_rgb('#8FBC8F')
            color_map[desert_mountains_mask] = hex_to_rgb('#CD853F')
            
        elif map_type == "Snow":
            # Snow biomes
            snow_mask = height < 0.4
            snow_plains_mask = (height >= 0.4) & (height < 0.7)
            frozen_lakes_mask = snow_plains_mask & (moisture_noise > 0.6)
            ice_mountains_mask = height >= 0.7
            
            color_map[snow_mask] = hex_to_rgb(colors['snow'])
            color_map[snow_plains_mask] = hex_to_rgb('#F0F8FF')
            color_map[frozen_lakes_mask] = hex_to_rgb('#87CEEB')
            color_map[ice_mountains_mask] = hex_to_rgb('#B0C4DE')
            
        elif map_type == "Jungle":
            # Jungle biomes
            jungle_low_mask = height < 0.3
            jungle_plains_mask = (height >= 0.3) & (height < 0.6)
            dense_jungle_mask = jungle_plains_mask & (moisture_noise > 0.5)
            jungle_mountains_mask = height >= 0.6
            
            color_map[jungle_low_mask] = hex_to_rgb('#228B22')
            color_map[jungle_plains_mask] = hex_to_rgb('#32CD32')
            color_map[dense_jungle_mask] = hex_to_rgb('#006400')
            color_map[jungle_mountains_mask] = hex_to_rgb('#556B2F')
            
        else:
            # Standard terrain (Minecraft, Island, Continental, etc.) with elevation controls
            # Calculate elevation thresholds based on parameters
            deep_water_threshold = sea_level * 0.5
            shallow_water_threshold = sea_level
            sand_threshold = sea_level + 0.1
            grass_threshold = sea_level + 0.3
            hill_threshold = sea_level + 0.4 + (0.3 * hill_prominence)
            mountain_threshold = sea_level + 0.6 + (0.3 * mountain_height)
            snow_threshold = sea_level + 0.8 + (0.2 * mountain_height)
            
            deep_water_mask = height < deep_water_threshold
            shallow_water_mask = (height >= deep_water_threshold) & (height < shallow_water_threshold)
            sand_mask = (height >= shallow_water_threshold) & (height < sand_threshold)
            grass_mask = (height >= sand_threshold) & (height < grass_threshold) & (biome_noise <= 0.6)
            forest_mask = (height >= sand_threshold) & (height < grass_threshold) & (biome_noise > 0.6)
            hills_mask = (height >= grass_threshold) & (height < hill_threshold)
            mountains_mask = (height >= hill_threshold) & (height < mountain_threshold)
            snow_mask = height >= snow_threshold
            
            color_map[deep_water_mask] = hex_to_rgb(colors['deep_water'])
            color_map[shallow_water_mask] = hex_to_rgb(colors['shallow_water'])
            color_map[sand_mask] = hex_to_rgb(colors['sand'])
            color_map[grass_mask] = hex_to_rgb(colors['grass'])
            color_map[forest_mask] = hex_to_rgb(colors['forest'])
            color_map[hills_mask] = hex_to_rgb('#8B7355')
            color_map[mountains_mask] = hex_to_rgb(colors['mountain'])
            color_map[snow_mask] = hex_to_rgb(colors['snow'])
        
        # Handle elevation modes
        if elevation_mode == 'Height Map':
            # Convert height to grayscale for height map visualization
            height_normalized = (height * 255).astype(np.uint8)
            color_map = np.stack([height_normalized] * 3, axis=2)
        elif elevation_mode == 'Contour Lines':
            # Generate contour lines
            contour_color_rgb = hex_to_rgb(colors['contour'])
            contour_thickness = 1
            
            # Create contour lines at regular intervals
            contour_levels = np.arange(0, 1, contour_spacing)
            for level in contour_levels:
                # Find pixels close to the contour level
                contour_mask = np.abs(height - level) < 0.02
                color_map[contour_mask] = contour_color_rgb
        
        # Add contour lines overlay if enabled
        if show_contours and elevation_mode == 'Normal':
            contour_color_rgb = hex_to_rgb(colors['contour'])
            contour_thickness = 1
            
            # Create contour lines at regular intervals
            contour_levels = np.arange(0, 1, contour_spacing)
            for level in contour_levels:
                # Find pixels close to the contour level
                contour_mask = np.abs(height - level) < 0.02
                # Only draw contours on land (not water)
                land_mask = height > sea_level
                final_contour_mask = contour_mask & land_mask
                color_map[final_contour_mask] = contour_color_rgb
        
        # Apply temperature and humidity effects with gradual transitions
        # Temperature effects - gradual snow coverage based on height and temperature
        if temperature < 0.5:  # Cold to moderate
            # Calculate snow probability based on temperature and height
            snow_probability = (0.5 - temperature) * 2.0  # 0 at 0.5 temp, 1 at 0 temp
            snow_height_threshold = 0.4 + (0.5 - temperature) * 0.4  # Lower threshold for colder temps
            
            # Apply snow to high elevations with probability
            high_elevation_mask = height > snow_height_threshold
            snow_mask = high_elevation_mask & (np.random.random(height.shape) < snow_probability)
            color_map[snow_mask] = hex_to_rgb(colors['snow'])
            
            # Gradual transition to snow for very cold temperatures
            if temperature < 0.2:
                cold_plains_mask = (height > 0.3) & (height < snow_height_threshold)
                color_map[cold_plains_mask] = hex_to_rgb('#E6E6FA')  # Light lavender for cold plains
                
        elif temperature > 0.6:  # Hot to very hot
            # Calculate desert probability based on temperature and humidity
            desert_probability = (temperature - 0.6) * 2.5  # 0 at 0.6 temp, 1 at 1.0 temp
            humidity_factor = max(0, 1 - humidity)  # Higher humidity reduces desert probability
            
            # Apply desert to low elevations with probability
            low_elevation_mask = (height < 0.6) & (height > 0.2)
            desert_mask = low_elevation_mask & (np.random.random(height.shape) < desert_probability * humidity_factor)
            color_map[desert_mask] = hex_to_rgb(colors['desert'])
            
            # Gradual transition to arid conditions
            if temperature > 0.8 and humidity < 0.4:
                arid_mask = (height < 0.5) & (height > 0.2)
                color_map[arid_mask] = hex_to_rgb('#DEB887')  # Burlywood for arid plains
        
        # Add 3D-like shading based on height and slope (simplified for speed)
        # Calculate gradient for shading
        grad_x = np.gradient(height, axis=1)
        grad_y = np.gradient(height, axis=0)
        slope = np.sqrt(grad_x**2 + grad_y**2)
        shade_factor = 1.0 - slope * 0.3
        shade_factor = np.clip(shade_factor, 0.7, 1.3)
        
        # Apply shading
        shade_factor_3d = np.stack([shade_factor] * 3, axis=2)
        color_map = np.clip(color_map * shade_factor_3d, 0, 255).astype(np.uint8)
        
        # Set the result
        img_array[:, :, :3] = color_map
        img_array[:, :, 3] = 255  # Full alpha
        
        # Apply animations if enabled
        if parameters.get('enable_animations', False):
            img_array = self._apply_map_animations(img_array, parameters, map_type)
        
        return img_array
    
    def _apply_map_animations(self, img_array, parameters, map_type):
        """Apply biome-specific animations to the map."""
        # Get animation parameters
        animation_speed = parameters.get('animation_speed', 'Medium')
        frame_index = parameters.get('frame_index', 0)
        total_frames = parameters.get('total_frames', 8)
        
        # Convert to PIL Image for processing
        pil_img = Image.fromarray(img_array, mode='RGBA')
        
        # Apply each enabled animation
        if parameters.get('shoreline_waves', False):
            pil_img = self._apply_shoreline_waves(pil_img, frame_index, total_frames, animation_speed)
        
        if parameters.get('ocean_currents', False):
            pil_img = self._apply_ocean_currents(pil_img, frame_index, total_frames, animation_speed)
        
        if parameters.get('wind_sway', False):
            pil_img = self._apply_wind_sway(pil_img, frame_index, total_frames, animation_speed)
        
        if parameters.get('sand_dunes', False):
            pil_img = self._apply_sand_dunes(pil_img, frame_index, total_frames, animation_speed)
        
        if parameters.get('snow_drift', False):
            pil_img = self._apply_snow_drift(pil_img, frame_index, total_frames, animation_speed)
        
        if parameters.get('rain_effects', False):
            pil_img = self._apply_rain_effects(pil_img, frame_index, total_frames, animation_speed)
        
        if parameters.get('fog_effects', False):
            pil_img = self._apply_fog_effects(pil_img, frame_index, total_frames, animation_speed)
        
        # Convert back to numpy array
        return np.array(pil_img)
    
    def _apply_shoreline_waves(self, pil_img, frame_index, total_frames, speed):
        """Apply shoreline wave animation - foamy water washing up on beach."""
        img_array = np.array(pil_img)
        h, w = img_array.shape[:2]
        
        # Step 1: Detect deep water, shallow water, and sand
        deep_water_mask = self._detect_deep_water_simple(img_array)
        shallow_water_mask = self._detect_shallow_water(img_array)
        sand_mask = self._detect_sand_areas(img_array)
        
        # DEBUG: Print detailed detection stats
        print(f"DEBUG DETECTION: Map size: {h}x{w}")
        print(f"DEBUG DETECTION: Deep water pixels: {np.sum(deep_water_mask)} ({np.sum(deep_water_mask)/(h*w)*100:.1f}%)")
        print(f"DEBUG DETECTION: Shallow water pixels: {np.sum(shallow_water_mask)} ({np.sum(shallow_water_mask)/(h*w)*100:.1f}%)")
        print(f"DEBUG DETECTION: Sand pixels: {np.sum(sand_mask)} ({np.sum(sand_mask)/(h*w)*100:.1f}%)")
        
        if not np.any(shallow_water_mask) or not np.any(sand_mask) or not np.any(deep_water_mask):
            print("DEBUG DETECTION: One or more terrain types not detected!")
            return pil_img
        
        # Step 2: Find ocean shorelines (shallow water connected to deep water, meeting sand)
        ocean_shorelines = self._find_ocean_shorelines(shallow_water_mask, deep_water_mask, sand_mask)
        
        # DEBUG: Print detection results
        print(f"DEBUG SHORELINE: Deep water pixels: {np.sum(deep_water_mask)}, Shallow water: {np.sum(shallow_water_mask)}, Sand: {np.sum(sand_mask)}, Ocean shorelines: {np.sum(ocean_shorelines)}")
        
        if not np.any(ocean_shorelines):
            print("DEBUG SHORELINE: No ocean shorelines detected!")
            return pil_img
        
        # Step 3: Calculate wave phase
        wave_phase = (frame_index / total_frames) * 2 * np.pi
        speed_multiplier = {'Slow': 0.5, 'Medium': 1.0, 'Fast': 2.0}.get(speed, 1.0)
        wave_phase *= speed_multiplier
        
        # Step 4: For each shoreline pixel, determine wave direction and apply foam
        for y in range(h):
            for x in range(w):
                if ocean_shorelines[y, x]:
                    # Determine flow direction (from water to sand)
                    flow_direction = self._get_wave_flow_direction(x, y, sand_mask, shallow_water_mask)
                    
                    if flow_direction is None:
                        continue
                    
                    dx, dy = flow_direction
                    
                    # Calculate wave progress (0 to 1)
                    wave_progress = (np.sin(wave_phase + x * 0.05 + y * 0.05) + 1) / 2
                    
                    # Apply foam effect as wave washes up (3-5 pixels from water onto sand)
                    if wave_progress > 0.5:  # Wave is washing up
                        foam_distance = int((wave_progress - 0.5) * 10)  # 0 to 5 pixels
                        
                        for distance in range(foam_distance):
                            foam_x = x + dx * distance
                            foam_y = y + dy * distance
                            
                            # Check bounds
                            if foam_x < 0 or foam_x >= w or foam_y < 0 or foam_y >= h:
                                break
                            
                            # Apply white foam to sand pixels
                            if sand_mask[foam_y, foam_x] or (distance < 2 and shallow_water_mask[foam_y, foam_x]):
                                original_color = img_array[foam_y, foam_x]
                                
                                # Foam color (white with blue tint)
                                foam_color = np.array([240, 250, 255, 255])
                                
                                # Intensity decreases with distance
                                foam_intensity = 0.7 * (1 - distance / 5.0)
                                
                                # Blend
                                new_color = original_color * (1 - foam_intensity) + foam_color * foam_intensity
                                img_array[foam_y, foam_x] = new_color.astype(np.uint8)
        
        return Image.fromarray(img_array, mode='RGBA')
    
    def _detect_deep_water_simple(self, img_array):
        """Detect deep water (dark blue pixels)."""
        h, w = img_array.shape[:2]
        deep_water_mask = np.zeros((h, w), dtype=bool)
        
        for y in range(h):
            for x in range(w):
                pixel_color = img_array[y, x]
                r, g, b = pixel_color[0], pixel_color[1], pixel_color[2]
                
                # Deep water is dark blue
                brightness = (int(r) + int(g) + int(b)) / 3  # Convert to int to avoid overflow
                is_blue = b > r and b > g
                is_dark = brightness < 100
                
                if is_blue and is_dark:
                    deep_water_mask[y, x] = True
        
        return deep_water_mask
    
    def _find_ocean_shorelines(self, shallow_water_mask, deep_water_mask, sand_mask):
        """Find shorelines where shallow water (connected to deep water) meets sand - OPTIMIZED."""
        h, w = shallow_water_mask.shape
        ocean_shoreline_mask = np.zeros((h, w), dtype=bool)
        
        # STEP 1: Mark shallow water within 10 pixels of deep water as "ocean water"
        # This is MUCH faster than checking each shallow water pixel individually
        ocean_water_mask = np.zeros((h, w), dtype=bool)
        
        # For each deep water pixel, mark shallow water in 10-pixel radius
        deep_y, deep_x = np.where(deep_water_mask)
        
        print(f"DEBUG: Processing {len(deep_y)} deep water pixels for ocean detection")
        
        for dy, dx in zip(deep_y, deep_x):
            y_min, y_max = max(0, dy-10), min(h, dy+11)
            x_min, x_max = max(0, dx-10), min(w, dx+11)
            region = shallow_water_mask[y_min:y_max, x_min:x_max]
            ocean_water_mask[y_min:y_max, x_min:x_max] |= region
        
        print(f"DEBUG: Ocean water pixels marked: {np.sum(ocean_water_mask)}")
        
        # STEP 2: Find ocean water pixels adjacent to sand (much faster with array slicing)
        for y in range(1, h-1):
            for x in range(1, w-1):
                if ocean_water_mask[y, x]:
                    # Check 3x3 neighborhood for sand
                    if np.any(sand_mask[y-1:y+2, x-1:x+2]):
                        ocean_shoreline_mask[y, x] = True
        
        return ocean_shoreline_mask
    
    def _is_connected_to_deep_water(self, x, y, shallow_water_mask, deep_water_mask, radius=10):
        """Check if a shallow water pixel connects to deep water within radius."""
        h, w = shallow_water_mask.shape
        
        # Simple radius check for deep water
        for dy in range(-radius, radius + 1):
            for dx in range(-radius, radius + 1):
                check_x, check_y = x + dx, y + dy
                if (0 <= check_x < w and 0 <= check_y < h and 
                    deep_water_mask[check_y, check_x]):
                    return True
        
        return False
    
    def _get_wave_flow_direction(self, x, y, sand_mask, shallow_water_mask):
        """Determine which direction the wave flows (from water onto sand)."""
        h, w = sand_mask.shape
        
        # Check all 8 directions to find where sand is
        directions = [
            (0, -1),  # up
            (1, -1),  # up-right
            (1, 0),   # right
            (1, 1),   # down-right
            (0, 1),   # down
            (-1, 1),  # down-left
            (-1, 0),  # left
            (-1, -1)  # up-left
        ]
        
        # Count sand pixels in each direction
        sand_counts = []
        for dx, dy in directions:
            count = 0
            for distance in range(1, 5):  # Check 4 pixels in this direction
                check_x, check_y = x + dx * distance, y + dy * distance
                if check_x < 0 or check_x >= w or check_y < 0 or check_y >= h:
                    break
                if sand_mask[check_y, check_x]:
                    count += 1
            sand_counts.append(count)
        
        # Find direction with most sand
        if max(sand_counts) > 0:
            max_index = sand_counts.index(max(sand_counts))
            return directions[max_index]
        
        return None
    
    def _detect_shallow_water(self, img_array):
        """Detect shallow water areas (lighter blue pixels)."""
        h, w = img_array.shape[:2]
        shallow_water_mask = np.zeros((h, w), dtype=bool)
        
        for y in range(h):
            for x in range(w):
                pixel_color = img_array[y, x]
                r, g, b = pixel_color[0], pixel_color[1], pixel_color[2]
                
                # Shallow water is typically lighter blue (higher brightness)
                brightness = (int(r) + int(g) + int(b)) / 3  # Convert to int to avoid overflow
                
                # Check if it's blue-ish and bright enough to be shallow water
                is_blue = b > r and b > g and (b - r) > 20 and (b - g) > 20
                is_shallow = brightness > 100 and brightness < 180  # Lighter than deep water
                
                if is_blue and is_shallow:
                    shallow_water_mask[y, x] = True
        
        return shallow_water_mask
    
    def _detect_sand_areas(self, img_array):
        """Detect sand areas (orange/yellow pixels)."""
        h, w = img_array.shape[:2]
        sand_mask = np.zeros((h, w), dtype=bool)
        
        for y in range(h):
            for x in range(w):
                pixel_color = img_array[y, x]
                r, g, b = pixel_color[0], pixel_color[1], pixel_color[2]
                
                # Sand is typically orange/yellow (high red, medium green, low blue)
                is_sand = r > 150 and g > 100 and b < 100 and r > g and r > b
                
                if is_sand:
                    sand_mask[y, x] = True
        
        return sand_mask
    
    def _find_shallow_water_sand_boundary(self, shallow_water_mask, sand_mask):
        """Find the exact boundary between shallow water and sand."""
        h, w = shallow_water_mask.shape
        boundary_mask = np.zeros((h, w), dtype=bool)
        
        # Find pixels that are shallow water AND adjacent to sand
        for y in range(h):
            for x in range(w):
                if shallow_water_mask[y, x]:
                    # Check if this shallow water pixel is adjacent to sand
                    is_adjacent_to_sand = False
                    for dy in range(-1, 2):
                        for dx in range(-1, 2):
                            check_x, check_y = x + dx, y + dy
                            if (0 <= check_x < w and 0 <= check_y < h and 
                                sand_mask[check_y, check_x]):
                                is_adjacent_to_sand = True
                                break
                        if is_adjacent_to_sand:
                            break
                    
                    if is_adjacent_to_sand:
                        boundary_mask[y, x] = True
        
        return boundary_mask
    
    def _apply_ocean_currents(self, pil_img, frame_index, total_frames, speed):
        """Apply ocean current animation - only to deep water areas."""
        img_array = np.array(pil_img)
        h, w = img_array.shape[:2]
        
        # Detect water pixels
        water_mask = self.animation_system._get_water_pixels(img_array)
        
        if not np.any(water_mask):
            return pil_img
        
        # Detect deep water areas (darker blue pixels, away from shorelines)
        deep_water_mask = self._detect_deep_water(img_array, water_mask)
        
        if not np.any(deep_water_mask):
            return pil_img
        
        # Generate current pattern
        current_phase = (frame_index / total_frames) * 2 * np.pi
        speed_multiplier = {'Slow': 0.3, 'Medium': 0.6, 'Fast': 1.0}.get(speed, 0.6)
        current_phase *= speed_multiplier
        
        # Apply subtle current effects ONLY to deep water pixels
        for y in range(h):
            for x in range(w):
                if deep_water_mask[y, x]:  # Only deep water areas
                    # Calculate current intensity
                    current_intensity = 0.03 + 0.02 * np.sin(current_phase + x * 0.03 + y * 0.03)
                    
                    # Apply subtle color variation for ocean currents
                    original_color = img_array[y, x]
                    # Create a slightly different blue for current effect
                    current_color = np.array([0, 30, 80, 255])  # Darker blue for currents
                    
                    # Blend with original color
                    new_color = original_color * (1 - current_intensity) + current_color * current_intensity
                    img_array[y, x] = new_color.astype(np.uint8)
        
        return Image.fromarray(img_array, mode='RGBA')
    
    def _detect_deep_water(self, img_array, water_mask):
        """Detect deep water areas (darker blue, away from shorelines)."""
        h, w = img_array.shape[:2]
        deep_water_mask = np.zeros_like(water_mask, dtype=bool)
        
        # Get water pixels
        water_pixels = np.where(water_mask)
        
        for y, x in zip(water_pixels[0], water_pixels[1]):
            # Check if this is deep water (darker blue, away from edges)
            pixel_color = img_array[y, x]
            r, g, b = pixel_color[0], pixel_color[1], pixel_color[2]
            
            # Deep water is typically darker blue (lower brightness)
            brightness = (r + g + b) / 3
            
            # Check if it's away from shorelines (not near land)
            is_away_from_shore = self._is_away_from_shoreline(img_array, x, y, water_mask)
            
            # Deep water criteria: darker blue AND away from shore
            if brightness < 120 and is_away_from_shore:  # Darker than 120 brightness
                deep_water_mask[y, x] = True
        
        return deep_water_mask
    
    def _is_away_from_shoreline(self, img_array, x, y, water_mask):
        """Check if a pixel is away from shorelines (in deep water)."""
        h, w = img_array.shape[:2]
        
        # Check a small radius around the pixel
        radius = 3
        for dy in range(-radius, radius + 1):
            for dx in range(-radius, radius + 1):
                check_x, check_y = x + dx, y + dy
                
                # Skip if out of bounds
                if check_x < 0 or check_x >= w or check_y < 0 or check_y >= h:
                    continue
                
                # If we find a non-water pixel nearby, this might be near shoreline
                if not water_mask[check_y, check_x]:
                    return False
        
        return True
    
    def _apply_wind_sway(self, pil_img, frame_index, total_frames, speed):
        """Apply wind sway animation to vegetation."""
        img_array = np.array(pil_img)
        h, w = img_array.shape[:2]
        
        # Detect vegetation pixels
        vegetation_mask = self.animation_system._get_green_pixels(img_array)
        
        if not np.any(vegetation_mask):
            return pil_img
        
        # Generate wind pattern
        wind_phase = (frame_index / total_frames) * 2 * np.pi
        speed_multiplier = {'Slow': 0.4, 'Medium': 0.8, 'Fast': 1.2}.get(speed, 0.8)
        wind_phase *= speed_multiplier
        
        # Apply wind effects to vegetation pixels
        for y in range(h):
            for x in range(w):
                if vegetation_mask[y, x]:
                    # Calculate wind intensity
                    wind_intensity = 0.03 + 0.02 * np.sin(wind_phase + x * 0.08 + y * 0.08)
                    
                    # Apply subtle color variation for movement effect
                    original_color = img_array[y, x]
                    wind_color = np.array([0, 100, 0, 255])  # Slightly different green
                    
                    # Blend with original color
                    new_color = original_color * (1 - wind_intensity) + wind_color * wind_intensity
                    img_array[y, x] = new_color.astype(np.uint8)
        
        return Image.fromarray(img_array, mode='RGBA')
    
    def _apply_sand_dunes(self, pil_img, frame_index, total_frames, speed):
        """Apply sand dune movement animation."""
        img_array = np.array(pil_img)
        h, w = img_array.shape[:2]
        
        # Detect sand pixels
        sand_mask = self.animation_system._get_sand_pixels(img_array)
        
        if not np.any(sand_mask):
            return pil_img
        
        # Generate dune movement pattern
        dune_phase = (frame_index / total_frames) * 2 * np.pi
        speed_multiplier = {'Slow': 0.2, 'Medium': 0.4, 'Fast': 0.6}.get(speed, 0.4)
        dune_phase *= speed_multiplier
        
        # Apply dune effects to sand pixels
        for y in range(h):
            for x in range(w):
                if sand_mask[y, x]:
                    # Calculate dune intensity
                    dune_intensity = 0.04 + 0.03 * np.sin(dune_phase + x * 0.06 + y * 0.06)
                    
                    # Apply subtle color variation
                    original_color = img_array[y, x]
                    dune_color = np.array([200, 180, 100, 255])  # Slightly different sand color
                    
                    # Blend with original color
                    new_color = original_color * (1 - dune_intensity) + dune_color * dune_intensity
                    img_array[y, x] = new_color.astype(np.uint8)
        
        return Image.fromarray(img_array, mode='RGBA')
    
    def _apply_snow_drift(self, pil_img, frame_index, total_frames, speed):
        """Apply snow drift animation."""
        img_array = np.array(pil_img)
        h, w = img_array.shape[:2]
        
        # Detect snow pixels
        snow_mask = self.animation_system._get_snow_pixels(img_array)
        
        if not np.any(snow_mask):
            return pil_img
        
        # Generate snow drift pattern
        snow_phase = (frame_index / total_frames) * 2 * np.pi
        speed_multiplier = {'Slow': 0.3, 'Medium': 0.6, 'Fast': 0.9}.get(speed, 0.6)
        snow_phase *= speed_multiplier
        
        # Apply snow effects
        for y in range(h):
            for x in range(w):
                if snow_mask[y, x]:
                    # Calculate snow intensity
                    snow_intensity = 0.02 + 0.02 * np.sin(snow_phase + x * 0.07 + y * 0.07)
                    
                    # Apply subtle color variation
                    original_color = img_array[y, x]
                    snow_color = np.array([240, 240, 255, 255])  # Slightly blue-tinted snow
                    
                    # Blend with original color
                    new_color = original_color * (1 - snow_intensity) + snow_color * snow_intensity
                    img_array[y, x] = new_color.astype(np.uint8)
        
        return Image.fromarray(img_array, mode='RGBA')
    
    def _apply_rain_effects(self, pil_img, frame_index, total_frames, speed):
        """Apply rain overlay animation."""
        img_array = np.array(pil_img)
        h, w = img_array.shape[:2]
        
        # Generate rain pattern
        rain_phase = (frame_index / total_frames) * 2 * np.pi
        speed_multiplier = {'Slow': 0.5, 'Medium': 1.0, 'Fast': 1.5}.get(speed, 1.0)
        rain_phase *= speed_multiplier
        
        # Create rain overlay
        rain_overlay = np.zeros_like(img_array)
        rain_intensity = 0.1  # Light rain effect
        
        for y in range(h):
            for x in range(w):
                # Create rain streaks
                rain_value = 0.1 * np.sin(rain_phase + x * 0.2 + y * 0.1)
                if rain_value > 0.05:
                    rain_overlay[y, x] = [100, 150, 200, 100]  # Light blue rain
        
        # Blend rain overlay with original image
        img_array = img_array * (1 - rain_intensity) + rain_overlay * rain_intensity
        img_array = np.clip(img_array, 0, 255).astype(np.uint8)
        
        return Image.fromarray(img_array, mode='RGBA')
    
    def _apply_fog_effects(self, pil_img, frame_index, total_frames, speed):
        """Apply fog overlay animation."""
        img_array = np.array(pil_img)
        h, w = img_array.shape[:2]
        
        # Generate fog pattern
        fog_phase = (frame_index / total_frames) * 2 * np.pi
        speed_multiplier = {'Slow': 0.3, 'Medium': 0.6, 'Fast': 0.9}.get(speed, 0.6)
        fog_phase *= speed_multiplier
        
        # Create fog overlay
        fog_overlay = np.zeros_like(img_array)
        fog_intensity = 0.15  # Moderate fog effect
        
        for y in range(h):
            for x in range(w):
                # Create fog patches
                fog_value = 0.1 * np.sin(fog_phase + x * 0.05 + y * 0.05)
                if fog_value > 0.02:
                    fog_overlay[y, x] = [200, 200, 200, 80]  # Light gray fog
        
        # Blend fog overlay with original image
        img_array = img_array * (1 - fog_intensity) + fog_overlay * fog_intensity
        img_array = np.clip(img_array, 0, 255).astype(np.uint8)
        
        return Image.fromarray(img_array, mode='RGBA')
    
    def _apply_texture_2d_effect(self, pil_img, parameters):
        """Apply 2D texture creation effect."""
        from core.texture_utils import generate_block_texture_qimage
        
        # Get parameters
        texture_type = parameters.get('texture_type', 'None')
        block_size = parameters.get('block_size', 4)
        opacity = parameters.get('opacity', 255)
        color1 = parameters.get('color1', '#8B4513')
        color2 = parameters.get('color2', '#A0522D')
        seed = parameters.get('seed', 42)
        use_custom_size = parameters.get('use_custom_size', False)
        custom_width = parameters.get('custom_width', 64)
        custom_height = parameters.get('custom_height', 64)
        # Try to get values from textboxes if available, otherwise use sliders
        custom_width_text = parameters.get('custom_width_text', str(custom_width))
        custom_height_text = parameters.get('custom_height_text', str(custom_height))
        try:
            custom_width = int(custom_width_text)
            custom_height = int(custom_height_text)
        except ValueError:
            pass  # Use slider values if text parsing fails
        
        use_custom_position = parameters.get('use_custom_position', False)
        position_x = parameters.get('position_x', 0)
        position_y = parameters.get('position_y', 0)
        # Try to get values from textboxes if available, otherwise use sliders
        position_x_text = parameters.get('position_x_text', str(position_x))
        position_y_text = parameters.get('position_y_text', str(position_y))
        try:
            position_x = int(position_x_text)
            position_y = int(position_y_text)
        except ValueError:
            pass  # Use slider values if text parsing fails
        texture_mode = parameters.get('texture_mode', 'Static')
        animation_speed = parameters.get('animation_speed', 5)
        
        # Get canvas dimensions
        canvas_width, canvas_height = pil_img.size
        
        # Determine texture dimensions
        if use_custom_size:
            texture_width = custom_width
            texture_height = custom_height
        else:
            texture_width = canvas_width
            texture_height = canvas_height
        
        # Get animation parameters
        keep_other_data = parameters.get('keep_other_data', True)
        animation_speed = parameters.get('animation_speed', 5)
        
        # Determine if we should use animation (for Static mode, only animate if texture_type supports it)
        # For Animated mode, this is handled separately in _handle_animated_texture_creation
        if texture_mode == 'Animated' and texture_type != 'None':
            # Use the texture type as animation type
            anim_type = texture_type
        else:
            anim_type = None
        
        # Generate texture
        texture = generate_block_texture_qimage(
            texture_width, texture_height, [color1, color2], block_size, opacity, 
            texture_type, None, 0, seed
        )
        
        # Convert QImage to numpy array
        texture_array = self._qimage_to_numpy(texture)
        
        # If using custom position, create a canvas-sized result and place texture at position
        if use_custom_position:
            # Start with the original image (preserve existing content)
            result = np.array(pil_img)
            
            # Calculate position bounds
            end_x = min(position_x + texture_width, canvas_width)
            end_y = min(position_y + texture_height, canvas_height)
            start_x = max(position_x, 0)
            start_y = max(position_y, 0)
            
            # Calculate texture bounds
            tex_start_x = max(0, -position_x)
            tex_start_y = max(0, -position_y)
            tex_end_x = min(texture_width, canvas_width - position_x)
            tex_end_y = min(texture_height, canvas_height - position_y)
            
            # Copy texture to result at specified position (overlay on existing content)
            if tex_end_x > tex_start_x and tex_end_y > tex_start_y:
                texture_region = texture_array[tex_start_y:tex_end_y, tex_start_x:tex_end_x]
                result[start_y:end_y, start_x:end_x] = texture_region
            
            return result
        else:
            # If not using custom position, return the texture as-is
            return texture_array
    
    def _create_animated_texture_frames(self, parameters, canvas_width, canvas_height, frame_count):
        """Create multiple frames for animated texture."""
        from core.texture_utils import generate_block_texture_qimage
        
        # Get parameters
        texture_type = parameters.get('texture_type', 'None')
        block_size = parameters.get('block_size', 4)
        opacity = parameters.get('opacity', 255)
        color1 = parameters.get('color1', '#8B4513')
        color2 = parameters.get('color2', '#A0522D')
        seed = parameters.get('seed', 42)
        use_custom_size = parameters.get('use_custom_size', False)
        custom_width = parameters.get('custom_width', 64)
        custom_height = parameters.get('custom_height', 64)
        use_custom_position = parameters.get('use_custom_position', False)
        position_x = parameters.get('position_x', 0)
        position_y = parameters.get('position_y', 0)
        keep_other_data = parameters.get('keep_other_data', True)
        animation_speed = parameters.get('animation_speed', 5)
        
        # Parse text values
        custom_width_text = parameters.get('custom_width_text', str(custom_width))
        custom_height_text = parameters.get('custom_height_text', str(custom_height))
        position_x_text = parameters.get('position_x_text', str(position_x))
        position_y_text = parameters.get('position_y_text', str(position_y))
        
        try:
            custom_width = int(custom_width_text)
            custom_height = int(custom_height_text)
            position_x = int(position_x_text)
            position_y = int(position_y_text)
        except ValueError:
            pass
        
        # Determine texture dimensions
        if use_custom_size:
            texture_width = custom_width
            texture_height = custom_height
        else:
            texture_width = canvas_width
            texture_height = canvas_height
        
        # Create the specified number of frames for animation
        frames = []
        
        # Calculate proper time step based on animation speed
        # Speed 1-10 maps to different step sizes for noticeable variation
        speed_multipliers = {
            1: 0.5,   # Very slow
            2: 0.8,
            3: 1.0,
            4: 1.5,
            5: 2.0,   # Medium (default)
            6: 3.0,
            7: 4.0,
            8: 5.0,
            9: 7.0,
            10: 10.0  # Very fast
        }
        time_step = speed_multipliers.get(animation_speed, 2.0)
        
        for frame_idx in range(frame_count):
            # Calculate animation time with proper spacing for visible variation
            # For Minecraft-style lava, we need significant time differences between frames
            animation_time = frame_idx * time_step
            
            # Generate texture with animation frame
            # Note: generate_block_texture_qimage expects frame_idx (integer) for spatial animation
            # but we pass animation_time (float) which is used as time_factor in the noise calculations
            texture = generate_block_texture_qimage(
                texture_width, texture_height, [color1, color2], block_size, opacity, 
                texture_type, None, animation_time, seed  # Pass animation_time as frame_idx parameter
            )
            
            # Convert QImage to numpy array - ensure we get a proper copy to preserve quality
            texture_array = self._qimage_to_numpy(texture)
            
            # Ensure we're working with uint8 to preserve quality
            if texture_array.dtype != np.uint8:
                texture_array = texture_array.astype(np.uint8)
            
            # Create result frame
            if use_custom_position:
                # Start with transparent canvas (existing data will be handled by the calling function)
                result = np.zeros((canvas_height, canvas_width, 4), dtype=np.uint8)
                
                # Calculate position bounds
                end_x = min(position_x + texture_width, canvas_width)
                end_y = min(position_y + texture_height, canvas_height)
                start_x = max(position_x, 0)
                start_y = max(position_y, 0)
                
                # Calculate texture bounds
                tex_start_x = max(0, -position_x)
                tex_start_y = max(0, -position_y)
                tex_end_x = min(texture_width, canvas_width - position_x)
                tex_end_y = min(texture_height, canvas_height - position_y)
                
                # Copy texture to result at specified position
                if tex_end_x > tex_start_x and tex_end_y > tex_start_y:
                    texture_region = texture_array[tex_start_y:tex_end_y, tex_start_x:tex_end_x]
                    result[start_y:end_y, start_x:end_x] = texture_region
                
                frames.append(result)
            else:
                # If not using custom position, return the texture as-is
                frames.append(texture_array)
        
        return frames
    
    def _handle_animated_texture_creation(self, parameters, frame_option, selection_option, merge_replace_mode, frame_count):
        """Handle animated texture creation by creating multiple frames."""
        lm = state.layer_manager
        layer = lm.get_current_layer()
        current_frame = lm.current_frame
        
        # Get canvas dimensions
        canvas_width = state.width
        canvas_height = state.height
        
        # Add mode to parameters from dialog
        parameters['mode'] = merge_replace_mode
        mode = parameters.get('mode', 'replace')  # Get mode from dialog
        keep_other_data = parameters.get('keep_other_data', True)
        
        # Determine if we should merge based on mode, not just keep_other_data
        should_merge = (mode == 'merge') and keep_other_data
        
        # Create animated frames with the specified count
        animated_frames = self._create_animated_texture_frames(parameters, canvas_width, canvas_height, frame_count)
        
        # Push undo before making changes
        state.push_undo()
        
        # Handle different frame options
        if frame_option == "current":
            # Replace current frame with first animated frame
            frame = layer.get_frame(current_frame)
            if should_merge and frame.image is not None:
                # Merge with existing content
                existing_image = frame.image.copy()
                # Overlay the animated texture on existing content
                animated_frames[0] = self._merge_images(existing_image, animated_frames[0])
            frame.image = animated_frames[0]
            
        elif frame_option == "all":
            # Replace all existing frames with animated frames
            num_frames = min(len(animated_frames), len(layer.frames))
            for i in range(num_frames):
                frame = layer.get_frame(i)
                if should_merge and frame.image is not None:
                    # Merge with existing content
                    existing_image = frame.image.copy()
                    animated_frames[i] = self._merge_images(existing_image, animated_frames[i])
                frame.image = animated_frames[i]
            
            # Add additional frames if needed
            for i in range(len(layer.frames), len(animated_frames)):
                layer.add_frame(canvas_width, canvas_height, state)
                new_frame = layer.get_frame(len(layer.frames) - 1)
                new_frame.image = animated_frames[i]
                
        elif frame_option == "previous":
            # Add animated frames before current frame
            for i, animated_frame in enumerate(animated_frames):
                if should_merge and current_frame > 0:
                    # Try to get existing content from previous frame
                    prev_frame = layer.get_frame(current_frame - 1)
                    if prev_frame.image is not None:
                        existing_image = prev_frame.image.copy()
                        animated_frame = self._merge_images(existing_image, animated_frame)
                
                # Insert frame by adding it and then moving it to the right position
                layer.add_frame(canvas_width, canvas_height, state)
                new_frame = layer.get_frame(len(layer.frames) - 1)
                new_frame.image = animated_frame
                
                # Move the frame to the correct position
                # We need to reorder the frames list
                frames_list = layer.frames
                new_frame_obj = frames_list.pop()  # Remove the last frame
                frames_list.insert(current_frame + i, new_frame_obj)  # Insert at desired position
                
        elif frame_option == "future" or frame_option == "create_frames":
            # For "create_frames", replace current frame with first animated frame, then add the rest
            if frame_option == "create_frames":
                # Replace current frame with first animated frame
                frame = layer.get_frame(current_frame)
                if should_merge and frame.image is not None:
                    existing_image = frame.image.copy()
                    animated_frames[0] = self._merge_images(existing_image, animated_frames[0])
                frame.image = animated_frames[0]
                
                # Add remaining frames after current frame
                for i in range(1, len(animated_frames)):
                    animated_frame = animated_frames[i]
                    
                    # Add new frame at the end
                    layer.add_frame(canvas_width, canvas_height, state)
                    new_frame = layer.get_frame(len(layer.frames) - 1)
                    
                    # Merge if needed
                    if should_merge and i < len(layer.frames) - 1:
                        existing_frame = layer.get_frame(current_frame + i)
                        if existing_frame.image is not None:
                            existing_image = existing_frame.image.copy()
                            animated_frame = self._merge_images(existing_image, animated_frame)
                    
                    new_frame.image = animated_frame
                    
                    # Move the frame to the correct position (right after current frame)
                    frames_list = layer.frames
                    new_frame_obj = frames_list.pop()
                    frames_list.insert(current_frame + i, new_frame_obj)
            else:
                # Original "future" behavior - add all frames after current frame
                for i, animated_frame in enumerate(animated_frames):
                    if should_merge and current_frame < len(layer.frames) - 1:
                        # Try to get existing content from next frame
                        next_frame = layer.get_frame(current_frame + 1)
                        if next_frame.image is not None:
                            existing_image = next_frame.image.copy()
                            animated_frame = self._merge_images(existing_image, animated_frame)
                    
                    # Insert frame by adding it and then moving it to the right position
                    layer.add_frame(canvas_width, canvas_height, state)
                    new_frame = layer.get_frame(len(layer.frames) - 1)
                    new_frame.image = animated_frame
                    
                    # Move the frame to the correct position
                    frames_list = layer.frames
                    new_frame_obj = frames_list.pop()  # Remove the last frame
                    frames_list.insert(current_frame + i + 1, new_frame_obj)  # Insert at desired position
        
        # Force complete UI refresh
        self._force_complete_refresh()

    def _apply_texture_atlas_effect(self, parameters):
        """Apply texture atlas creation effect."""
        from core.atlas_manager import AtlasManager
        
        # Get parameters
        grid_size = parameters.get('grid_size', 32)
        block_size = parameters.get('block_size', 8)
        num_frames = parameters.get('num_frames', 1)
        primary_color = parameters.get('primary_color', '#8B4513')
        secondary_color = parameters.get('secondary_color', '#A0522D')
        style = parameters.get('style', 'block')
        animated = parameters.get('animated', False)
        animation_type = parameters.get('animation_type', 'Water')
        ores = parameters.get('ores', False)
        num_ores = parameters.get('num_ores', 2)
        ore_color = parameters.get('ore_color', '#FFD700')
        
        # Get frame index for animation (0-based)
        frame_index = parameters.get('frame_index', 0)
        
        # Configure atlas manager
        atlas_manager = state.atlas_manager
        atlas_manager.push_undo()
        atlas_manager.set_grid_size(grid_size)
        atlas_manager.num_frames = num_frames
        
        # Update all cells with new parameters
        for cell in atlas_manager.grid_cells:
            # Only update cells that don't have individual settings
            if not getattr(cell, '_individual_settings', False):
                cell.primary_color = primary_color
                cell.secondary_color = secondary_color
                cell.style = style
                cell.block_size = block_size
                cell.animated = animated
                cell.ores = ores
                cell.num_ores = num_ores
                cell.ore_color = ore_color
        
        # Generate atlas image for specific frame
        atlas_image = atlas_manager.generate_atlas_image(frame_index)
        
        if atlas_image:
            # Convert QImage to numpy array
            atlas_array = self._qimage_to_numpy(atlas_image)
            return atlas_array
        else:
            # Return empty image if no atlas generated
            return np.zeros((state.height, state.width, 4), dtype=np.uint8)
    
    def _apply_generate_lod_effect(self, pil_img, parameters):
        """Apply LOD (Level of Detail) generation effect."""
        from PIL import Image, ImageFilter
        
        # Get parameters
        lod_level = parameters.get('lod_level', 2)
        method = parameters.get('method', 'Box Downsample')
        preserve_alpha = parameters.get('preserve_alpha', True)
        export_only = parameters.get('export_only', False)
        
        # Calculate new dimensions
        original_width, original_height = pil_img.size
        new_width = max(1, original_width // lod_level)
        new_height = max(1, original_height // lod_level)
        
        # Apply different downsampling methods
        if method == 'Box Downsample':
            # Simple box downsampling
            resized_img = pil_img.resize((new_width, new_height), Image.Resampling.BOX)
        elif method == 'Gaussian Blur':
            # Apply Gaussian blur then resize
            blurred_img = pil_img.filter(ImageFilter.GaussianBlur(radius=lod_level * 0.5))
            resized_img = blurred_img.resize((new_width, new_height), Image.Resampling.LANCZOS)
        elif method == 'Bilinear':
            # Bilinear interpolation
            resized_img = pil_img.resize((new_width, new_height), Image.Resampling.BILINEAR)
        elif method == 'Nearest Neighbor':
            # Nearest neighbor (pixelated)
            resized_img = pil_img.resize((new_width, new_height), Image.Resampling.NEAREST)
        else:
            # Default to box downsampling
            resized_img = pil_img.resize((new_width, new_height), Image.Resampling.BOX)
        
        # Handle alpha channel
        if preserve_alpha and resized_img.mode == 'RGBA':
            # Ensure alpha channel is preserved
            pass  # Already handled by PIL
        elif not preserve_alpha and resized_img.mode == 'RGBA':
            # Convert to RGB if alpha preservation is disabled
            resized_img = resized_img.convert('RGB')
        
        # If export_only is True, we'll handle the export in the dialog
        # For now, just return the processed image
        return np.array(resized_img)


    def _qimage_to_numpy(self, qimage):
        """Convert QImage to numpy array."""
        from PySide6.QtGui import QImage
        if qimage.format() != QImage.Format_RGBA8888:
            qimage = qimage.convertToFormat(QImage.Format_RGBA8888)
        
        width = qimage.width()
        height = qimage.height()
        
        # Get the image data as bytes
        ptr = qimage.bits()
        arr = np.frombuffer(ptr, np.uint8).reshape((height, width, 4))
        
        # Ensure we have a copy to avoid memory issues
        return arr.copy()

    def _apply_effect_over_frames(self, effect_type, start_frame_idx, selection_option, parameters, frame_count, direction, merge_replace_mode):
        """Apply effect over multiple frames with interpolation."""
        print(f"DEBUG: _apply_effect_over_frames called - effect: {effect_type}, frames: {frame_count}, direction: {direction}")
        lm = state.layer_manager
        layer = lm.get_current_layer()
        
        # Get the base image for interpolation
        base_frame = layer.get_frame(start_frame_idx)
        base_img = base_frame.image.copy()
        
        # Determine frame range based on direction
        if direction == "previous":
            # Apply to frames before current frame
            start_frame = max(0, start_frame_idx - frame_count + 1)
            end_frame = start_frame_idx + 1
            frame_indices = list(range(start_frame, end_frame))
        else:  # future
            # Apply to frames after current frame
            start_frame = start_frame_idx
            # Only create the exact number of frames requested
            end_frame = start_frame_idx + frame_count
            frame_indices = list(range(start_frame, end_frame))
            
            # Create new frames if needed (only the exact number requested)
            current_frame_count = len(layer.frames)
            if end_frame > current_frame_count:
                frames_to_add = end_frame - current_frame_count
                for i in range(frames_to_add):
                    layer.add_frame(state.width, state.height, state)
        
        # Apply effect with different intensities over frames
        for i, frame_idx in enumerate(frame_indices):
            progress = i / (len(frame_indices) - 1) if len(frame_indices) > 1 else 0
            
            # Create interpolated parameters
            interpolated_params = self._interpolate_parameters(parameters, progress, effect_type)
            
            # For texture atlas effects, use the frame index directly
            if effect_type == 'texture_atlas':
                interpolated_params['frame_index'] = i
            
            # Apply effect to this frame
            if merge_replace_mode == "replace":
                # Replace the frame content
                self._apply_effect_to_frame(effect_type, frame_idx, selection_option, interpolated_params)
            else:  # merge
                # Merge with existing frame content
                self._apply_effect_to_frame_merge(effect_type, frame_idx, selection_option, interpolated_params)
    
    def _interpolate_parameters(self, parameters, progress, effect_type):
        """Interpolate parameters based on progress (0.0 to 1.0)."""
        interpolated = {}
        
        for key, value in parameters.items():
            if isinstance(value, (int, float)):
                # For numeric parameters, use the original value for most effects
                # Only apply interpolation for specific effects that need it
                if effect_type == 'fade' and key == 'intensity':
                    # For fade, interpolate intensity from 0 to target value
                    interpolated[key] = value * progress
                elif effect_type in ['texture_2d', 'map_generator'] and key in ['intensity', 'opacity']:
                    # For texture effects, use full intensity on all frames
                    interpolated[key] = value
                elif effect_type == 'texture_2d' and 'portal' in str(parameters.get('style', '')).lower():
                    # For portal effects, use full intensity on all frames (no fade)
                    interpolated[key] = value
                else:
                    # For other effects, use the original value
                    interpolated[key] = value
            elif isinstance(value, str) and value.startswith('#'):
                # For colors, use the target color directly (no interpolation needed for fade)
                interpolated[key] = value
            else:
                # For other types, use the original value
                interpolated[key] = value
        
        # For texture atlas effects, add frame index based on progress
        if effect_type == 'texture_atlas':
            num_frames = parameters.get('num_frames', 1)
        
        # For map generator animations, add frame information
        if effect_type == 'map_generator' and parameters.get('enable_animations', False):
            # Add frame index and total frames for animation
            total_frames = parameters.get('total_frames', 8)
            frame_index = int(progress * (total_frames - 1)) if total_frames > 1 else 0
            interpolated['frame_index'] = frame_index
            interpolated['total_frames'] = total_frames
        
        return interpolated
    
    def _apply_effect_to_frame_merge(self, effect_type, frame_idx, selection_option, parameters):
        """Apply effect to a frame and merge with existing content."""
        lm = state.layer_manager
        layer = lm.get_current_layer()
        frame = layer.get_frame(frame_idx)
        img = frame.image
        if img is None:
            return
        
        # Get the area to apply effect to
        if selection_option == "selection":
            if state.selection_manager.has_selection():
                bounds = state.selection_manager.get_selection_bounds()
                if bounds:
                    x1, y1, x2, y2 = bounds
                    h, w = img.shape[:2]
                    x1, y1 = max(0, min(x1, w-1)), max(0, min(y1, h-1))
                    x2, y2 = max(0, min(x2, w-1)), max(0, min(y2, h-1))
                    
                    if x1 < x2 and y1 < y2:
                        if state.selection_manager.selection_mask is not None:
                            # Apply effect to masked selection and merge
                            mask_region = state.selection_manager.selection_mask[y1:y2, x1:x2]
                            selected_region = img[y1:y2, x1:x2].copy()
                            processed_region = self._process_effect(effect_type, selected_region, parameters)
                            
                            # Merge only masked pixels
                            merged_region = self._merge_images(selected_region, processed_region)
                            selected_region[mask_region] = merged_region[mask_region]
                            img[y1:y2, x1:x2] = selected_region
                        else:
                            # Apply effect to rectangular selection and merge
                            selected_region = img[y1:y2, x1:x2].copy()
                            processed_region = self._process_effect(effect_type, selected_region, parameters)
                            
                            # Merge the processed region with original
                            merged_region = self._merge_images(selected_region, processed_region)
                            img[y1:y2, x1:x2] = merged_region
                else:
                    # No selection, merge with entire image
                    processed_img = self._process_effect(effect_type, img, parameters)
                    frame.image = self._merge_images(img, processed_img)
            else:
                # No selection, merge with entire image
                processed_img = self._process_effect(effect_type, img, parameters)
                frame.image = self._merge_images(img, processed_img)
        else:
            # Merge with entire image
            processed_img = self._process_effect(effect_type, img, parameters)
            frame.image = self._merge_images(img, processed_img)
    
    def _merge_images(self, original, processed):
        """Merge original and processed images using alpha blending."""
        from PIL import Image
        import numpy as np
        
        # Convert to PIL images for blending
        original_pil = Image.fromarray(original, mode='RGBA')
        processed_pil = Image.fromarray(processed, mode='RGBA')
        
        # Blend the images (50% original, 50% processed)
        merged = Image.blend(original_pil, processed_pil, 0.5)
        
        return np.array(merged)
    

    
    def apply_image_to_canvas(self, image):
        """Apply a single image to the current canvas."""
        lm = state.layer_manager
        layer = lm.get_current_layer()
        frame = layer.get_frame(lm.current_frame)
        frame.image = image
        self._force_complete_refresh()

    def open_advanced_atlas_dialog(self):
        from ui.texture_atlas_dialog import TextureAtlasDialog
        dlg = TextureAtlasDialog(self)
        dlg.exec()

    def open_character_creator(self):
        """Open the character creator dialog"""
        dialog = CharacterCreatorDialog(self)
        dialog.exec()

    def toggle_pixel_perfect(self):
        """Toggle pixel-perfect filtering mode"""
        if not hasattr(self, 'canvas') or not hasattr(self.canvas, 'set_pixel_perfect'):
            return
        
        # Toggle the setting
        settings.pixel_perfect_filtering = self.pixel_perfect_action.isChecked()
        settings.save()
        
        # Apply to canvas if using GPU canvas
        if hasattr(self.canvas, 'set_pixel_perfect'):
            self.canvas.set_pixel_perfect(settings.pixel_perfect_filtering)
    
    def toggle_composite_view(self):
        """Toggle between individual layer view and composite view."""
        if hasattr(self, 'canvas') and self.canvas:
            self.canvas.toggle_composite_view()
    
    def _handle_lod_export(self, frame_option, selection_option, parameters, frame_count, export_options):
        """Handle LOD export functionality."""
        from PySide6.QtWidgets import QMessageBox
        from PIL import Image
        import os
        
        if not export_options:
            QMessageBox.warning(self, "Export Error", "No export options specified.")
            return
        
        export_format = export_options.get('format', 'PNG')
        export_path = export_options.get('path', '')
        
        # Get the processed LOD image
        lm = state.layer_manager
        layer = lm.get_current_layer()
        frame_idx = lm.current_frame
        frame = layer.get_frame(frame_idx)
        img = frame.image
        if img is None:
            QMessageBox.warning(self, "Export Error", "No image to export.")
            return
        
        # Process the image with LOD effect
        processed_img = self._process_effect('generate_lod', img, parameters)
        
        # Convert to PIL Image for export
        pil_img = Image.fromarray(processed_img, mode='RGBA')
        
        # Determine export path if not specified
        if not export_path:
            # Generate default path
            base_name = f"lod_level_{parameters.get('lod_level', 2)}"
            if export_format == ".PgSprite":
                export_path = f"{base_name}.pgsprite"
            elif export_format == "GIF":
                export_path = f"{base_name}.gif"
            elif export_format == "JPG":
                export_path = f"{base_name}.jpg"
            else:  # PNG
                export_path = f"{base_name}.png"
        
        try:
            # Export based on format
            if export_format == ".PgSprite":
                # Export as .PgSprite format
                from core import pgsprite_io
                if pgsprite_io.export_pgsprite(export_path, state):
                    QMessageBox.information(self, "Export Success", f"LOD exported as .PgSprite: {export_path}")
                else:
                    QMessageBox.warning(self, "Export Error", "Failed to export .PgSprite file")
            elif export_format == "GIF":
                # Export as GIF
                pil_img.save(export_path, 'GIF')
                QMessageBox.information(self, "Export Success", f"LOD exported as GIF: {export_path}")
            elif export_format == "JPG":
                # Export as JPG (convert to RGB first)
                if pil_img.mode == 'RGBA':
                    rgb_img = Image.new('RGB', pil_img.size, (255, 255, 255))
                    rgb_img.paste(pil_img, mask=pil_img.split()[-1])
                    rgb_img.save(export_path, 'JPEG', quality=95)
                else:
                    pil_img.save(export_path, 'JPEG', quality=95)
                QMessageBox.information(self, "Export Success", f"LOD exported as JPG: {export_path}")
            else:  # PNG
                # Export as PNG
                pil_img.save(export_path, 'PNG')
                QMessageBox.information(self, "Export Success", f"LOD exported as PNG: {export_path}")
                
        except Exception as e:
            QMessageBox.warning(self, "Export Error", f"Failed to export LOD: {str(e)}")
    
    def get_effects_menu_structure(self):
        """Get the Effects menu structure for external use"""
        try:
            menubar = self.menuBar()
            effects_menu = None
            
            # Find the Effects menu
            for action in menubar.actions():
                if action.menu() and action.menu().title() == "Effects":
                    effects_menu = action.menu()
                    break
            
            if not effects_menu:
                return None
            
            # Extract menu structure data instead of returning Qt objects
            menu_data = self._extract_menu_data(effects_menu)
            return menu_data
            
        except Exception as e:
            print(f"Error getting Effects menu structure: {e}")
            return None
    
    def get_edit_menu_structure(self):
        """Get the Edit menu structure for external use"""
        try:
            menubar = self.menuBar()
            edit_menu = None
            
            # Find the Edit menu
            for action in menubar.actions():
                if action.menu() and action.menu().title() == "Edit":
                    edit_menu = action.menu()
                    break
            
            if not edit_menu:
                return None
            
            # Extract menu structure data instead of returning Qt objects
            menu_data = self._extract_menu_data(edit_menu)
            return menu_data
            
        except Exception as e:
            print(f"Error getting Edit menu structure: {e}")
            return None
    
    def _extract_menu_data(self, menu):
        """Extract menu structure data from a QMenu"""
        menu_data = {
            'title': menu.title(),
            'actions': []
        }
        
        for action in menu.actions():
            if action.isSeparator():
                menu_data['actions'].append({'type': 'separator'})
            elif action.menu():
                # This is a submenu
                submenu_data = self._extract_menu_data(action.menu())
                menu_data['actions'].append({
                    'type': 'submenu',
                    'text': action.text(),
                    'menu': submenu_data
                })
            else:
                # This is a regular action
                # Extract method name from the connected slot
                method_name = self._get_action_method_name(action)
                menu_data['actions'].append({
                    'type': 'action',
                    'text': action.text(),
                    'shortcut': action.shortcut().toString() if action.shortcut() else '',
                    'enabled': action.isEnabled(),
                    'method_name': method_name
                })
        
        return menu_data
    
    def _get_action_method_name(self, action):
        """Extract the method name connected to an action"""
        # Just use the mapping directly - we don't need to check receivers
        return self._map_action_to_method(action.text())
    
    def _map_action_to_method(self, action_text):
        """Map action text to method name"""
        # This is a simple mapping - in a real implementation you might want
        # a more sophisticated approach, but this covers our current effects
        mapping = {
            # Edit menu actions
            "Undo": "undo",
            "Redo": "redo",
            "Cut": "cut_selection",
            "Copy": "copy_selection",
            "Paste": "paste_selection",
            "Crop...": "crop_canvas",
            "Remove Blank Space...": "remove_blank_space",
            # Import menu actions
            "Sprite Sheet...": "import_sprite_sheet",
            # Effects menu actions
            "Invert Colors": "effect_invert",
            "Greyscale": "effect_greyscale", 
            "Fade": "effect_fade",
            "Opacity": "effect_opacity",
            "Brightness": "effect_brightness",
            "Contrast": "effect_contrast",
            "Blur": "effect_blur",
            "Sharpen": "effect_sharpen",
            "Noise": "effect_noise",
            "Pixelate": "effect_pixelate",
            "Dither": "effect_dither",
            "Vignette": "effect_vignette",
            "Saturation": "effect_saturation",
            "Posterize": "effect_posterize",
            "Emboss": "effect_emboss",
            "Edge Detection": "effect_edge_detection",
            "Colorize": "effect_colorize",
            "Oil Painting": "effect_oil_painting",
            "Glow": "effect_glow",
            "Solarize": "effect_solarize",
            "⭐ Image Enhancement": "effect_image_enhancement",
            "⭐ Quality Enhancement": "effect_quality_enhancement",
            "Upscale": "effect_upscale",
            "Motion Blur": "effect_motion_blur",
            "Shader Bloom FX": "effect_shader_bloom",
            "Palette Cycler": "effect_palette_cycler",
            "Pixel Depth Mapper": "effect_pixel_depth",
            "2D Map Generator": "effect_map_generator",
            "2D Texture Creation": "effect_texture_2d",
            "Nine-Slice": "nine_slice_import",
            "Advanced Atlas Editor": "open_advanced_atlas_dialog",
            "🎭 Character Creation": "open_character_creator",
            "Generate LOD": "effect_generate_lod",
            "Mirror/Flip...": "effect_mirror_flip",
            "Rotate...": "effect_rotate",
            "Atmospheric Lighting": "effect_atmospheric_lighting",
            "WindWaker": "effect_wind_waker",
            "Ocarina of Time": "effect_ocarina_of_time",
            "Luigi's Mansion": "effect_luigis_mansion",
            "Eternal Darkness": "effect_eternal_darkness",
            "Pokémon Colosseum": "effect_pokemon_colosseum",
            "Mario Kart 8": "effect_mario_kart_8"
        }
        return mapping.get(action_text)
