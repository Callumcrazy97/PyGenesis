"""Sprite Sheet Importer Dialog

Provides UI for importing sprite sheets with auto-slicing, background removal,
and frame centering.
"""

from PySide6.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
                               QSpinBox, QCheckBox, QRadioButton, QButtonGroup, QGroupBox,
                               QColorDialog, QMessageBox, QScrollArea, QWidget, QFrame)
from PySide6.QtCore import Qt
from PySide6.QtGui import QColor, QPixmap, QPainter, QImage, QPen
from PIL import Image
import numpy as np
import cv2


class SpriteSheetPreviewWidget(QWidget):
    """Custom widget for displaying sprite sheet with grid overlay"""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumSize(600, 400)
        self.sheet_image = None  # Original sheet as numpy array
        self.processed_image = None  # Processed image with background removed
        self.grid_info = None  # {'cell_w': int, 'cell_h': int, 'cols': int, 'rows': int, 'auto_detected': bool}
        self.frames_data = []  # List of detected frames
        self.scale = 1.0
        self.image_offset_x = 0
        self.image_offset_y = 0
        
    def set_image(self, image_array):
        """Set the sprite sheet image"""
        self.sheet_image = image_array
        self.processed_image = image_array.copy() if image_array is not None else None
        self.update()
    
    def set_grid_info(self, grid_info):
        """Set grid information for overlay"""
        self.grid_info = grid_info
        self.update()
    
    def set_frames_data(self, frames_data):
        """Set detected frames data"""
        self.frames_data = frames_data
        self.update()
    
    def paintEvent(self, event):
        """Paint the sprite sheet with grid overlay"""
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing, False)
        
        # Fill background
        painter.fillRect(self.rect(), QColor(240, 240, 240))
        
        if self.processed_image is None:
            return
        
        # Calculate scaling to fit image in widget
        img_h, img_w = self.processed_image.shape[:2]
        widget_w = self.width()
        widget_h = self.height()
        
        scale_x = widget_w / img_w
        scale_y = widget_h / img_h
        scale = min(scale_x, scale_y, 1.0)  # Don't scale up
        
        scaled_w = int(img_w * scale)
        scaled_h = int(img_h * scale)
        
        # Center the image
        x_offset = (widget_w - scaled_w) // 2
        y_offset = (widget_h - scaled_h) // 2
        
        # Store scale and offset for grid drawing
        self.scale = scale
        self.image_offset_x = x_offset
        self.image_offset_y = y_offset
        
        # Convert numpy array to QImage using PIL for safety
        try:
            # Convert numpy array to PIL Image
            if len(self.processed_image.shape) == 3:
                if self.processed_image.shape[2] == 4:
                    pil_img = Image.fromarray(self.processed_image, 'RGBA')
                elif self.processed_image.shape[2] == 3:
                    pil_img = Image.fromarray(self.processed_image, 'RGB')
                else:
                    pil_img = Image.fromarray(self.processed_image[:, :, 0], 'L')
            else:
                pil_img = Image.fromarray(self.processed_image, 'L')
            
            # Convert PIL to QImage
            pil_img = pil_img.convert('RGBA')
            img_bytes = pil_img.tobytes('raw', 'RGBA')
            qimg = QImage(img_bytes, img_w, img_h, QImage.Format_RGBA8888)
            
            # Draw the image
            pixmap = QPixmap.fromImage(qimg)
            scaled_pixmap = pixmap.scaled(scaled_w, scaled_h, Qt.KeepAspectRatio, Qt.SmoothTransformation)
            painter.drawPixmap(x_offset, y_offset, scaled_pixmap)
        except Exception as e:
            # Fallback: draw error message
            painter.setPen(QColor(255, 0, 0))
            painter.drawText(x_offset, y_offset + 20, f"Error rendering image: {e}")
        
        # Draw grid overlay if grid_info is available
        if self.grid_info:
            pen = QPen(QColor(255, 0, 0, 180), 2)  # Semi-transparent red
            painter.setPen(pen)
            
            cell_w = self.grid_info.get('cell_w', 0)
            cell_h = self.grid_info.get('cell_h', 0)
            cols = self.grid_info.get('cols', 0)
            rows = self.grid_info.get('rows', 0)
            
            if cell_w > 0 and cell_h > 0:
                # Draw vertical lines (grid cell boundaries)
                for col in range(cols + 1):
                    x = self.image_offset_x + int(col * cell_w * self.scale)
                    painter.drawLine(x, self.image_offset_y, x, self.image_offset_y + scaled_h)
                
                # Draw horizontal lines (grid cell boundaries)
                for row in range(rows + 1):
                    y = self.image_offset_y + int(row * cell_h * self.scale)
                    painter.drawLine(self.image_offset_x, y, self.image_offset_x + scaled_w, y)
        
        # Draw bounding boxes around detected frames (for auto-detect mode)
        if self.grid_info and self.grid_info.get('auto_detected', False) and self.frames_data:
            pen = QPen(QColor(0, 255, 0, 200), 2)  # Semi-transparent green for auto-detected
            painter.setPen(pen)
            
            for frame_data in self.frames_data:
                if len(frame_data) >= 4:
                    if len(frame_data) == 6:
                        frame, x, y, w, h, tag = frame_data
                    else:
                        frame, x, y, w, h = frame_data
                    
                    # Scale coordinates using stored scale and offset
                    rect_x = self.image_offset_x + int(x * self.scale)
                    rect_y = self.image_offset_y + int(y * self.scale)
                    rect_w = int(w * self.scale)
                    rect_h = int(h * self.scale)
                    
                    # Draw rectangle
                    painter.drawRect(rect_x, rect_y, rect_w, rect_h)


class SpriteSheetImporterDialog(QDialog):
    def __init__(self, parent=None, image_path=None):
        super().__init__(parent)
        self.image_path = image_path
        self.sheet_image = None
        self.frames_data = []  # List of (numpy_array, x, y, w, h, tag) tuples
        self.bg_tolerance = 10  # Default tolerance for background removal
        
        self.setWindowTitle("Import Sprite Sheet")
        self.setModal(True)
        self.resize(800, 600)
        
        if image_path:
            self.load_image(image_path)
        
        # Initialize grid_info before setup_ui
        self.grid_info = None
        self.setup_ui()
        if self.sheet_image is not None:
            # Set initial image in preview
            self.preview_widget.set_image(self.sheet_image)
            self.preview_slice()
    
    def setup_ui(self):
        layout = QVBoxLayout(self)
        
        # Options group
        options_group = QGroupBox("Slice Options")
        options_layout = QVBoxLayout()
        
        # Slice method selection
        method_layout = QHBoxLayout()
        method_layout.addWidget(QLabel("Method:"))
        
        self.method_group = QButtonGroup(self)
        self.grid_radio = QRadioButton("Grid (uniform size)")
        self.auto_radio = QRadioButton("Auto-detect (varied size)")
        self.method_group.addButton(self.grid_radio, 0)
        self.method_group.addButton(self.auto_radio, 1)
        self.grid_radio.setChecked(True)
        self.method_group.buttonClicked.connect(self.on_method_changed)
        
        method_layout.addWidget(self.grid_radio)
        method_layout.addWidget(self.auto_radio)
        method_layout.addStretch()
        options_layout.addLayout(method_layout)
        
        # Grid options
        grid_layout = QHBoxLayout()
        grid_layout.addWidget(QLabel("Columns:"))
        self.cols_spin = QSpinBox()
        self.cols_spin.setRange(1, 100)
        self.cols_spin.setValue(4)
        self.cols_spin.valueChanged.connect(self.preview_slice)
        grid_layout.addWidget(self.cols_spin)
        
        grid_layout.addWidget(QLabel("Rows:"))
        self.rows_spin = QSpinBox()
        self.rows_spin.setRange(1, 100)
        self.rows_spin.setValue(4)
        self.rows_spin.valueChanged.connect(self.preview_slice)
        grid_layout.addWidget(self.rows_spin)
        
        options_layout.addLayout(grid_layout)
        
        # Background removal group
        bg_group = QGroupBox("Background Removal")
        bg_layout = QVBoxLayout()
        
        # Enable checkbox
        self.remove_bg_check = QCheckBox("Remove background color")
        self.remove_bg_check.toggled.connect(self.on_bg_removal_toggled)
        bg_layout.addWidget(self.remove_bg_check)
        
        # Color selection
        color_layout = QHBoxLayout()
        color_layout.addWidget(QLabel("Color:"))
        
        self.bg_color_button = QPushButton("Pick Color")
        self.bg_color_button.setEnabled(False)
        self.bg_color_button.clicked.connect(self.pick_bg_color)
        self.bg_color = None
        self.bg_color_preview = QFrame()
        self.bg_color_preview.setFixedSize(30, 20)
        self.bg_color_preview.setStyleSheet("background-color: #ffffff; border: 1px solid #000000;")
        self.bg_color_preview.setEnabled(False)
        color_layout.addWidget(self.bg_color_preview)
        color_layout.addWidget(self.bg_color_button)
        color_layout.addStretch()
        bg_layout.addLayout(color_layout)
        
        # Auto-detect option
        self.auto_detect_bg_check = QCheckBox("Auto-detect (top-left pixel)")
        self.auto_detect_bg_check.setChecked(True)
        self.auto_detect_bg_check.setEnabled(False)
        self.auto_detect_bg_check.toggled.connect(self.on_auto_bg_toggled)
        bg_layout.addWidget(self.auto_detect_bg_check)
        
        # Tolerance control
        tolerance_layout = QHBoxLayout()
        tolerance_layout.addWidget(QLabel("Tolerance:"))
        self.tolerance_spin = QSpinBox()
        self.tolerance_spin.setRange(0, 255)
        self.tolerance_spin.setValue(10)
        self.tolerance_spin.setEnabled(False)
        self.tolerance_spin.valueChanged.connect(self.on_tolerance_changed)
        tolerance_layout.addWidget(self.tolerance_spin)
        tolerance_layout.addWidget(QLabel("(0-255, higher = more colors removed)"))
        tolerance_layout.addStretch()
        bg_layout.addLayout(tolerance_layout)
        
        bg_group.setLayout(bg_layout)
        options_layout.addWidget(bg_group)
        
        # Center frames
        self.center_frames_check = QCheckBox("Center frames in canvas")
        self.center_frames_check.setChecked(True)
        self.center_frames_check.toggled.connect(self.preview_slice)
        options_layout.addWidget(self.center_frames_check)
        
        # Output mode selection
        output_mode_group = QGroupBox("Output Mode")
        output_mode_layout = QVBoxLayout()
        
        self.output_mode_group = QButtonGroup(self)
        self.single_sheet_radio = QRadioButton("Single Sheet (reorganize into grid)")
        self.one_per_frame_radio = QRadioButton("One Per Frame (extract each sprite)")
        self.output_mode_group.addButton(self.single_sheet_radio, 0)
        self.output_mode_group.addButton(self.one_per_frame_radio, 1)
        self.one_per_frame_radio.setChecked(True)  # Default to one per frame
        self.output_mode_group.buttonClicked.connect(self.preview_slice)
        
        output_mode_layout.addWidget(self.single_sheet_radio)
        output_mode_layout.addWidget(self.one_per_frame_radio)
        output_mode_group.setLayout(output_mode_layout)
        options_layout.addWidget(output_mode_group)
        
        options_group.setLayout(options_layout)
        layout.addWidget(options_group)
        
        # Preview area with grid overlay
        preview_label = QLabel("Preview:")
        layout.addWidget(preview_label)
        
        # Create custom preview widget that can draw grid overlay
        self.preview_widget = SpriteSheetPreviewWidget()
        self.preview_widget.setMinimumHeight(400)
        self.preview_widget.setMinimumWidth(600)
        self.preview_widget.setStyleSheet("border: 1px solid #ccc; background-color: #f0f0f0;")
        
        scroll = QScrollArea()
        scroll.setWidget(self.preview_widget)
        scroll.setWidgetResizable(True)
        layout.addWidget(scroll)
        
        # Keep QLabel reference for backward compatibility (not used anymore)
        self.preview_area = None
        
        # Status label
        self.status_label = QLabel("Ready to slice")
        layout.addWidget(self.status_label)
        
        # Buttons
        button_layout = QHBoxLayout()
        button_layout.addStretch()
        
        self.apply_button = QPushButton("Import")
        self.apply_button.clicked.connect(self.accept)
        button_layout.addWidget(self.apply_button)
        
        cancel_button = QPushButton("Cancel")
        cancel_button.clicked.connect(self.reject)
        button_layout.addWidget(cancel_button)
        
        layout.addLayout(button_layout)
    
    def load_image(self, image_path):
        """Load the sprite sheet image and auto-crop blank space"""
        try:
            pil_img = Image.open(image_path)
            if pil_img.mode != 'RGBA':
                pil_img = pil_img.convert('RGBA')
            self.sheet_image = np.array(pil_img)
            
            # Auto-crop blank space from edges before processing
            self.sheet_image = self.crop_blank_edges(self.sheet_image)
            
            # Set initial image in preview widget if it exists
            if hasattr(self, 'preview_widget') and self.preview_widget:
                self.preview_widget.set_image(self.sheet_image)
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to load image: {e}")
            self.sheet_image = None
    
    def crop_blank_edges(self, image_array):
        """Remove blank/transparent edges from image"""
        if image_array is None or image_array.size == 0:
            return image_array
        
        h, w = image_array.shape[:2]
        
        # Create mask of non-blank pixels
        if len(image_array.shape) == 3:
            if image_array.shape[2] == 4:
                # Use alpha channel - non-transparent pixels
                mask = image_array[:, :, 3] > 10
            else:
                # Check if any channel has content
                mask = np.any(image_array > 10, axis=2)
        else:
            mask = image_array > 10
        
        if not np.any(mask):
            return image_array  # Entire image is blank
        
        # Find bounding box
        rows = np.any(mask, axis=1)
        cols = np.any(mask, axis=0)
        
        if not np.any(rows) or not np.any(cols):
            return image_array
        
        y_min, y_max = np.where(rows)[0][[0, -1]]
        x_min, x_max = np.where(cols)[0][[0, -1]]
        
        # Crop to content
        cropped = image_array[y_min:y_max+1, x_min:x_max+1]
        return cropped
    
    def on_method_changed(self, button):
        """Handle method selection change"""
        is_grid = button == self.grid_radio
        self.cols_spin.setEnabled(is_grid)
        self.rows_spin.setEnabled(is_grid)
        self.preview_slice()
    
    def on_bg_removal_toggled(self, checked):
        """Handle background removal checkbox"""
        self.bg_color_button.setEnabled(checked)
        self.bg_color_preview.setEnabled(checked)
        self.auto_detect_bg_check.setEnabled(checked)
        self.tolerance_spin.setEnabled(checked)
        if checked and self.auto_detect_bg_check.isChecked():
            self.auto_detect_background()
        self.preview_slice()
    
    def on_tolerance_changed(self, value):
        """Handle tolerance value change"""
        self.bg_tolerance = value
        self.preview_slice()
    
    def on_auto_bg_toggled(self, checked):
        """Handle auto-detect background checkbox"""
        if checked:
            self.auto_detect_background()
        self.preview_slice()
    
    def auto_detect_background(self):
        """Auto-detect background color from top-left pixel"""
        if self.sheet_image is not None:
            self.bg_color = tuple(self.sheet_image[0, 0, :3])  # RGB from top-left pixel
            # Update color preview
            color = QColor(*self.bg_color)
            self.bg_color_preview.setStyleSheet(
                f"background-color: rgb({color.red()}, {color.green()}, {color.blue()}); "
                f"border: 1px solid #000000;"
            )
    
    def pick_bg_color(self):
        """Open color picker for background color"""
        if self.bg_color:
            initial_color = QColor(*self.bg_color)
        else:
            initial_color = QColor(255, 255, 255)
        
        color = QColorDialog.getColor(initial_color, self, "Select Background Color")
        if color.isValid():
            self.bg_color = (color.red(), color.green(), color.blue())
            # Update color preview
            self.bg_color_preview.setStyleSheet(
                f"background-color: rgb({color.red()}, {color.green()}, {color.blue()}); "
                f"border: 1px solid #000000;"
            )
            self.auto_detect_bg_check.setChecked(False)
            self.preview_slice()
    
    def preview_slice(self):
        """Preview the slicing results"""
        if self.sheet_image is None:
            return
        
        # Perform slicing
        self.frames_data = []
        
        if self.grid_radio.isChecked():
            self.slice_grid()
        else:
            self.slice_auto()
        
        # Update preview
        self.update_preview()
        
        # Update status
        self.status_label.setText(f"Found {len(self.frames_data)} frames")
    
    def slice_grid(self):
        """Slice using uniform grid"""
        h, w = self.sheet_image.shape[:2]
        cols = self.cols_spin.value()
        rows = self.rows_spin.value()
        
        cell_w = w // cols
        cell_h = h // rows
        
        # Store grid info for preview
        self.grid_info = {
            'cell_w': cell_w,
            'cell_h': cell_h,
            'cols': cols,
            'rows': rows,
            'auto_detected': False
        }
        
        # Create processed image with background removed for preview
        processed_img = self.sheet_image.copy()
        if self.remove_bg_check.isChecked() and self.bg_color:
            # Apply background removal to entire image for preview
            for row in range(rows):
                for col in range(cols):
                    x = col * cell_w
                    y = row * cell_h
                    cell = processed_img[y:y+cell_h, x:x+cell_w]
                    processed_cell = self.remove_background(cell, self.bg_color, self.bg_tolerance)
                    processed_img[y:y+cell_h, x:x+cell_w] = processed_cell
        
        # Update preview widget
        self.preview_widget.set_image(processed_img)
        self.preview_widget.set_grid_info(self.grid_info)
        
        for row in range(rows):
            for col in range(cols):
                x = col * cell_w
                y = row * cell_h
                frame = self.sheet_image[y:y+cell_h, x:x+cell_w].copy()
                
                # Remove background if enabled
                if self.remove_bg_check.isChecked() and self.bg_color:
                    frame = self.remove_background(frame, self.bg_color, self.bg_tolerance)
                
                # Find actual bounds (non-transparent/non-bg area)
                frame, x_offset, y_offset = self.crop_to_content(frame)
                
                # Center in cell if option is enabled
                if self.center_frames_check.isChecked():
                    frame = self.center_frame(frame, cell_w, cell_h)
                    x_offset = x
                    y_offset = y
                else:
                    x_offset = x + x_offset
                    y_offset = y + y_offset
                
                if frame.size > 0:  # Only add non-empty frames
                    # Generate tag for this frame (row_col format)
                    tag = f"row_{row}_col_{col}"
                    self.frames_data.append((frame, x_offset, y_offset, frame.shape[1], frame.shape[0], tag))
        
        # Update preview with frames data
        self.preview_widget.set_frames_data(self.frames_data)
    
    def slice_auto(self):
        """Auto-detect sprite boundaries and analyze spacing"""
        h, w = self.sheet_image.shape[:2]
        
        # Create processed image with background removed
        processed_img = self.sheet_image.copy()
        if self.remove_bg_check.isChecked() and self.bg_color:
            processed_img = self.remove_background(processed_img, self.bg_color, self.bg_tolerance)
        
        # Convert to grayscale for edge detection
        if len(processed_img.shape) == 3:
            if processed_img.shape[2] == 4:
                # Use alpha channel for detection
                gray = processed_img[:, :, 3]
            else:
                gray = cv2.cvtColor(processed_img[:, :, :3], cv2.COLOR_RGB2GRAY)
        else:
            gray = processed_img
        
        # Apply threshold to find sprites
        _, thresh = cv2.threshold(gray, 1, 255, cv2.THRESH_BINARY)
        
        # Find contours
        contours, _ = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        
        # Extract bounding boxes
        bounding_boxes = []
        for contour in contours:
            x, y, w_box, h_box = cv2.boundingRect(contour)
            if w_box < 5 or h_box < 5:  # Skip very small regions
                continue
            bounding_boxes.append((x, y, w_box, h_box))
        
        # Analyze spacing between sprites to detect grid
        if len(bounding_boxes) > 1:
            # Sort bounding boxes by position (top to bottom, left to right)
            sorted_boxes = sorted(bounding_boxes, key=lambda b: (b[1], b[0]))  # Sort by y then x
            
            # Calculate typical sprite size
            widths = [w for x, y, w, h in sorted_boxes]
            heights = [h for x, y, w, h in sorted_boxes]
            avg_w = int(np.median(widths)) if widths else 0
            avg_h = int(np.median(heights)) if heights else 0
            
            # Analyze horizontal spacing - look at gaps between sprites in same row
            horizontal_gaps = []
            for i in range(len(sorted_boxes) - 1):
                x1, y1, w1, h1 = sorted_boxes[i]
                x2, y2, w2, h2 = sorted_boxes[i + 1]
                
                # Check if they're in the same approximate row (within tolerance)
                if abs(y1 - y2) < avg_h * 0.5:  # Same row if y difference is less than half sprite height
                    # Calculate gap between end of sprite1 and start of sprite2
                    gap = x2 - (x1 + w1)
                    if gap > 0:  # Only positive gaps
                        horizontal_gaps.append(gap)
            
            # Analyze vertical spacing - look at gaps between sprites in same column
            vertical_gaps = []
            # Sort by x first to find columns
            sorted_by_x = sorted(bounding_boxes, key=lambda b: (b[0], b[1]))
            for i in range(len(sorted_by_x) - 1):
                x1, y1, w1, h1 = sorted_by_x[i]
                x2, y2, w2, h2 = sorted_by_x[i + 1]
                
                # Check if they're in the same approximate column
                if abs(x1 - x2) < avg_w * 0.5:  # Same column if x difference is less than half sprite width
                    gap = y2 - (y1 + h1)
                    if gap > 0:
                        vertical_gaps.append(gap)
            
            # Calculate typical spacing (use median of gaps)
            from collections import Counter
            x_spacing = int(np.median(horizontal_gaps)) if horizontal_gaps else 0
            y_spacing = int(np.median(vertical_gaps)) if vertical_gaps else 0
            
            # If no gaps found, try analyzing the image directly for spacing
            if x_spacing == 0 or y_spacing == 0:
                # Analyze the processed image for transparent/empty regions
                # This finds the spacing by looking at empty areas
                if len(processed_img.shape) == 3 and processed_img.shape[2] == 4:
                    alpha = processed_img[:, :, 3]
                    # Find columns/rows that are mostly transparent (spacing)
                    transparent_cols = np.all(alpha < 10, axis=0)  # Columns with no content
                    transparent_rows = np.all(alpha < 10, axis=1)  # Rows with no content
                    
                    # Find typical spacing width
                    if np.any(transparent_cols):
                        # Calculate spacing by finding consecutive transparent columns
                        spacing_widths = []
                        in_spacing = False
                        spacing_start = 0
                        for x in range(w):
                            if transparent_cols[x]:
                                if not in_spacing:
                                    spacing_start = x
                                    in_spacing = True
                            else:
                                if in_spacing:
                                    spacing_widths.append(x - spacing_start)
                                    in_spacing = False
                        if spacing_widths:
                            x_spacing = int(np.median(spacing_widths))
                    
                    if np.any(transparent_rows):
                        # Calculate spacing by finding consecutive transparent rows
                        spacing_heights = []
                        in_spacing = False
                        spacing_start = 0
                        for y in range(h):
                            if transparent_rows[y]:
                                if not in_spacing:
                                    spacing_start = y
                                    in_spacing = True
                            else:
                                if in_spacing:
                                    spacing_heights.append(y - spacing_start)
                                    in_spacing = False
                        if spacing_heights:
                            y_spacing = int(np.median(spacing_heights))
            
            # Estimate grid dimensions
            if x_spacing > 0 and y_spacing > 0 and avg_w > 0 and avg_h > 0:
                # Estimate cell size (sprite + spacing)
                cell_w = avg_w + x_spacing
                cell_h = avg_h + y_spacing
                
                # Estimate grid dimensions
                cols = max(1, w // cell_w) if cell_w > 0 else 1
                rows = max(1, h // cell_h) if cell_h > 0 else 1
                
                # Store grid info for preview
                self.grid_info = {
                    'cell_w': cell_w,
                    'cell_h': cell_h,
                    'cols': cols,
                    'rows': rows,
                    'auto_detected': True
                }
            else:
                self.grid_info = None
        else:
            self.grid_info = None
        
        # Extract frames
        for x, y, w_box, h_box in bounding_boxes:
            frame = self.sheet_image[y:y+h_box, x:x+w_box].copy()
            
            # Remove background if enabled
            if self.remove_bg_check.isChecked() and self.bg_color:
                frame = self.remove_background(frame, self.bg_color, self.bg_tolerance)
            
            # Crop to content
            frame, x_offset, y_offset = self.crop_to_content(frame)
            x_actual = x + x_offset
            y_actual = y + y_offset
            
            if frame.size > 0:
                # Generate tag for auto-detected frames
                tag = f"auto_{len(self.frames_data)}"
                self.frames_data.append((frame, x_actual, y_actual, frame.shape[1], frame.shape[0], tag))
        
        # Sort by position (top to bottom, left to right)
        self.frames_data.sort(key=lambda f: (f[2], f[1]))  # Sort by y then x
        
        # Re-tag sorted frames
        for i, frame_data in enumerate(self.frames_data):
            # Update tag to reflect sorted order
            frame_data_list = list(frame_data)
            frame_data_list[5] = f"auto_{i}"  # Update tag
            self.frames_data[i] = tuple(frame_data_list)
        
        # Update preview widget
        self.preview_widget.set_image(processed_img)
        self.preview_widget.set_grid_info(self.grid_info)
        self.preview_widget.set_frames_data(self.frames_data)
    
    def remove_background(self, frame, bg_color, tolerance=10):
        """Remove background color with tolerance"""
        if len(frame.shape) == 2:
            return frame
        
        bg_mask = np.ones((frame.shape[0], frame.shape[1]), dtype=bool)
        for i, bg_val in enumerate(bg_color[:3]):  # RGB only
            channel = frame[:, :, i]
            mask = np.abs(channel.astype(int) - bg_val) <= tolerance
            bg_mask = bg_mask & mask
        
        # Set masked pixels to transparent
        result = frame.copy()
        if result.shape[2] == 4:  # Has alpha
            result[bg_mask, 3] = 0
        else:
            # Add alpha channel
            alpha = np.ones((result.shape[0], result.shape[1]), dtype=np.uint8) * 255
            alpha[bg_mask] = 0
            result = np.dstack([result, alpha])
        
        return result
    
    def crop_to_content(self, frame):
        """Crop frame to actual content, removing empty edges"""
        if len(frame.shape) == 2:
            # Grayscale
            mask = frame > 0
        else:
            # Color with alpha
            if frame.shape[2] == 4:
                mask = frame[:, :, 3] > 0  # Use alpha channel
            else:
                mask = np.any(frame > 0, axis=2)  # Any non-zero pixel
        
        if not np.any(mask):
            return frame, 0, 0
        
        # Find bounding box
        rows = np.any(mask, axis=1)
        cols = np.any(mask, axis=0)
        
        if not np.any(rows) or not np.any(cols):
            return frame, 0, 0
        
        y_min, y_max = np.where(rows)[0][[0, -1]]
        x_min, x_max = np.where(cols)[0][[0, -1]]
        
        cropped = frame[y_min:y_max+1, x_min:x_max+1]
        return cropped, x_min, y_min
    
    def center_frame(self, frame, target_w, target_h):
        """Center frame in target dimensions"""
        fh, fw = frame.shape[:2]
        
        # Create new centered frame
        centered = np.zeros((target_h, target_w, frame.shape[2]), dtype=frame.dtype)
        
        # Calculate position to center
        x_offset = (target_w - fw) // 2
        y_offset = (target_h - fh) // 2
        
        # Place frame in center
        y_end = min(y_offset + fh, target_h)
        x_end = min(x_offset + fw, target_w)
        
        y_src_end = y_end - y_offset
        x_src_end = x_end - x_offset
        
        if y_src_end > 0 and x_src_end > 0:
            centered[y_offset:y_end, x_offset:x_end] = frame[:y_src_end, :x_src_end]
        
        return centered
    
    def update_preview(self):
        """Update preview display - now handled by preview widget"""
        # Preview is now handled by the custom preview widget
        # Just ensure it's updated
        if hasattr(self, 'preview_widget') and self.preview_widget:
            self.preview_widget.update()
    
    def get_results(self):
        """Return the sliced frame data with tags and output mode"""
        results = []
        for frame_data in self.frames_data:
            if len(frame_data) == 6:
                frame, x, y, w, h, tag = frame_data
            else:
                # Legacy format - generate tag
                frame, x, y, w, h = frame_data
                tag = f"frame_{len(results)}"
            
            results.append({
                'image': frame,
                'x': x,
                'y': y,
                'width': w,
                'height': h,
                'tag': tag
            })
        
        # Determine output mode
        output_mode = 'one_per_frame' if self.one_per_frame_radio.isChecked() else 'single_sheet'
        
        return {
            'frames': results,
            'output_mode': output_mode,
            'grid_info': self.grid_info
        }

# Check for cv2 availability
try:
    import cv2
    CV2_AVAILABLE = True
except ImportError:
    CV2_AVAILABLE = False

