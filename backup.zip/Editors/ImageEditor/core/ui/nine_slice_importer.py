"""Sprite Sheet Importer Dialog

Industry-standard sprite sheet importer with:
- Background removal with tolerance and live preview
- Automatic sprite detection and cropping
- Bounding box visualization
- Multiple output modes (sprite sheet or individual frames)
"""

from PySide6.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
                               QSpinBox, QCheckBox, QRadioButton, QButtonGroup, QGroupBox,
                               QColorDialog, QMessageBox, QScrollArea, QWidget, QSlider)
from PySide6.QtCore import Qt, QRect
from PySide6.QtGui import QColor, QPixmap, QPainter, QImage, QPen
from PIL import Image
import numpy as np

# Check for cv2 availability
try:
    import cv2
    CV2_AVAILABLE = True
except ImportError:
    CV2_AVAILABLE = False


class NineSliceDialog(QDialog):
    def __init__(self, parent=None, image_path=None, image_array=None):
        super().__init__(parent)
        self.image_path = image_path
        self.image_array = image_array
        self.original_image = None  # Original image (RGBA numpy array)
        self.processed_image = None  # Image after background removal
        self.sprite_bboxes = []  # List of (x, y, w, h) tuples for each sprite
        self.frames_data = []  # List of (numpy_array, x, y, w, h) tuples
        self.bg_color = None  # Current background color (R, G, B)
        self.tolerance = 30  # Background removal tolerance
        self.standard_canvas_width = 0  # Standardized canvas width for all sprites
        self.standard_canvas_height = 0  # Standardized canvas height for all sprites
        
        # Results structure:
        # {
        #   'mode': 'separate_frames' or 'single_frame_grid',
        #   'frame_option': 'current', 'end', 'specific',
        #   'specific_frame': int (if frame_option is 'specific'),
        #   'frames': [...],  # List of extracted sprite arrays
        #   'background_color': (r, g, b),
        #   'sprite_size': (w, h)
        # }
        
        self.setWindowTitle("Sprite Sheet Importer")
        self.setModal(True)
        self.resize(900, 800)
        
        if image_array is not None:
            # Use provided image array directly
            # Ensure it's RGBA format
            if len(image_array.shape) == 2:
                # Grayscale - convert to RGBA
                self.original_image = np.dstack([image_array, image_array, image_array, np.full_like(image_array, 255)])
            elif image_array.shape[2] == 3:
                # RGB - add alpha channel
                self.original_image = np.dstack([image_array, np.full((image_array.shape[0], image_array.shape[1]), 255, dtype=np.uint8)])
            else:
                # Already RGBA
                self.original_image = image_array.copy()
        elif image_path:
            self.load_image(image_path)
        
        self.setup_ui()
        
        # Initialize workflow if image loaded
        if self.original_image is not None:
            self.process_workflow()
    
    def setup_ui(self):
        layout = QVBoxLayout(self)
        
        # Step 1: Background Removal
        bg_group = QGroupBox("Step 1: Background Removal")
        bg_layout = QVBoxLayout()
        
        # Auto-detect vs manual color
        color_layout = QHBoxLayout()
        self.auto_detect_bg_check = QCheckBox("Auto-detect (top-left pixel)")
        self.auto_detect_bg_check.setChecked(True)
        self.auto_detect_bg_check.toggled.connect(self.on_auto_bg_toggled)
        color_layout.addWidget(self.auto_detect_bg_check)
        
        self.bg_color_button = QPushButton("Pick Color")
        self.bg_color_button.setEnabled(False)
        self.bg_color_button.clicked.connect(self.pick_bg_color)
        color_layout.addWidget(self.bg_color_button)
        
        self.bg_color_display = QLabel("●")
        self.bg_color_display.setStyleSheet("color: #FF00FF; font-size: 24px;")
        color_layout.addWidget(self.bg_color_display)
        color_layout.addStretch()
        bg_layout.addLayout(color_layout)
        
        # Tolerance slider
        tolerance_layout = QHBoxLayout()
        tolerance_layout.addWidget(QLabel("Tolerance:"))
        self.tolerance_slider = QSlider(Qt.Horizontal)
        self.tolerance_slider.setRange(0, 100)
        self.tolerance_slider.setValue(30)
        self.tolerance_slider.setTickPosition(QSlider.TicksBelow)
        self.tolerance_slider.setTickInterval(10)
        self.tolerance_slider.valueChanged.connect(self.on_tolerance_changed)
        tolerance_layout.addWidget(self.tolerance_slider)
        self.tolerance_label = QLabel("30")
        self.tolerance_label.setMinimumWidth(30)
        tolerance_layout.addWidget(self.tolerance_label)
        bg_layout.addLayout(tolerance_layout)
        
        bg_group.setLayout(bg_layout)
        layout.addWidget(bg_group)
        
        # Step 2: Output Mode
        options_group = QGroupBox("Step 2: Output Mode")
        options_layout = QVBoxLayout()
        
        mode_layout = QHBoxLayout()
        mode_layout.addWidget(QLabel("Output:"))
        
        self.mode_group = QButtonGroup(self)
        self.single_frame_radio = QRadioButton("Sprite Sheet (one frame)")
        self.separate_frames_radio = QRadioButton("One Sprite Per Frame")
        self.mode_group.addButton(self.single_frame_radio, 0)
        self.mode_group.addButton(self.separate_frames_radio, 1)
        self.separate_frames_radio.setChecked(True)  # Default
        self.mode_group.buttonClicked.connect(self.on_mode_changed)
        
        mode_layout.addWidget(self.single_frame_radio)
        mode_layout.addWidget(self.separate_frames_radio)
        mode_layout.addStretch()
        options_layout.addLayout(mode_layout)
        
        # Frame options (shown based on mode)
        self.frame_options_group = QGroupBox("Frame Options")
        self.frame_options_layout = QVBoxLayout()
        
        # For separate frames mode
        self.separate_frame_options = QWidget()
        separate_layout = QVBoxLayout(self.separate_frame_options)
        separate_layout.setContentsMargins(0, 0, 0, 0)
        
        self.separate_frame_group = QButtonGroup(self)
        self.start_current_radio = QRadioButton("Start from current frame")
        self.start_end_radio = QRadioButton("Start from end (append all)")
        self.start_specific_radio = QRadioButton("Start from specific frame:")
        self.separate_frame_group.addButton(self.start_current_radio, 0)
        self.separate_frame_group.addButton(self.start_end_radio, 1)
        self.separate_frame_group.addButton(self.start_specific_radio, 2)
        self.start_current_radio.setChecked(True)
        
        specific_layout = QHBoxLayout()
        specific_layout.addWidget(self.start_specific_radio)
        self.specific_frame_spin = QSpinBox()
        self.specific_frame_spin.setRange(0, 1000)
        self.specific_frame_spin.setValue(0)
        self.specific_frame_spin.setEnabled(False)
        self.start_specific_radio.toggled.connect(lambda checked: self.specific_frame_spin.setEnabled(checked))
        specific_layout.addWidget(self.specific_frame_spin)
        specific_layout.addStretch()
        
        separate_layout.addWidget(self.start_current_radio)
        separate_layout.addWidget(self.start_end_radio)
        separate_layout.addLayout(specific_layout)
        
        # For single frame mode
        self.single_frame_options = QWidget()
        single_layout = QVBoxLayout(self.single_frame_options)
        single_layout.setContentsMargins(0, 0, 0, 0)
        
        self.single_frame_group = QButtonGroup(self)
        self.replace_current_radio = QRadioButton("Replace current frame")
        self.new_frame_radio = QRadioButton("Place on new frame")
        self.place_specific_radio = QRadioButton("Place on specific frame:")
        self.single_frame_group.addButton(self.replace_current_radio, 0)
        self.single_frame_group.addButton(self.new_frame_radio, 1)
        self.single_frame_group.addButton(self.place_specific_radio, 2)
        self.replace_current_radio.setChecked(True)
        
        place_specific_layout = QHBoxLayout()
        place_specific_layout.addWidget(self.place_specific_radio)
        self.place_frame_spin = QSpinBox()
        self.place_frame_spin.setRange(0, 1000)
        self.place_frame_spin.setValue(0)
        self.place_frame_spin.setEnabled(False)
        self.place_specific_radio.toggled.connect(lambda checked: self.place_frame_spin.setEnabled(checked))
        place_specific_layout.addWidget(self.place_frame_spin)
        place_specific_layout.addStretch()
        
        single_layout.addWidget(self.replace_current_radio)
        single_layout.addWidget(self.new_frame_radio)
        single_layout.addLayout(place_specific_layout)
        
        # Add both options to frame options layout
        self.frame_options_layout.addWidget(self.separate_frame_options)
        self.frame_options_layout.addWidget(self.single_frame_options)
        self.frame_options_group.setLayout(self.frame_options_layout)
        options_layout.addWidget(self.frame_options_group)
        
        # Background color detection
        bg_layout = QHBoxLayout()
        self.auto_detect_bg_check = QCheckBox("Auto-detect background color (uses top-left pixel)")
        self.auto_detect_bg_check.setChecked(True)
        self.auto_detect_bg_check.toggled.connect(self.on_auto_bg_toggled)
        bg_layout.addWidget(self.auto_detect_bg_check)
        
        self.bg_color_button = QPushButton("Manual Color")
        self.bg_color_button.setEnabled(False)
        self.bg_color_button.clicked.connect(self.pick_bg_color)
        bg_layout.addWidget(self.bg_color_button)
        bg_layout.addStretch()
        
        options_layout.addLayout(bg_layout)
        
        options_group.setLayout(options_layout)
        layout.addWidget(options_group)
        
        # Detection info
        self.info_label = QLabel("Detecting sprites...")
        self.info_label.setStyleSheet("font-weight: bold; padding: 5px; background-color: #3a3a3a;")
        layout.addWidget(self.info_label)
        
        # Preview area with bounding boxes
        preview_label = QLabel("Preview (with bounding boxes):")
        layout.addWidget(preview_label)
        
        self.preview_area = QLabel()
        self.preview_area.setMinimumHeight(300)
        self.preview_area.setAlignment(Qt.AlignCenter)
        self.preview_area.setStyleSheet("border: 2px solid #555; background-color: #2a2a2a;")
        
        scroll = QScrollArea()
        scroll.setWidget(self.preview_area)
        scroll.setWidgetResizable(True)
        layout.addWidget(scroll)
        
        # Status label
        self.status_label = QLabel("Ready")
        self.status_label.setStyleSheet("padding: 5px;")
        layout.addWidget(self.status_label)
        
        # Buttons
        button_layout = QHBoxLayout()
        button_layout.addStretch()
        
        self.apply_button = QPushButton("Import Sprites")
        self.apply_button.clicked.connect(self.accept)
        self.apply_button.setEnabled(False)
        button_layout.addWidget(self.apply_button)
        
        cancel_button = QPushButton("Cancel")
        cancel_button.clicked.connect(self.reject)
        button_layout.addWidget(cancel_button)
        
        layout.addLayout(button_layout)
        
        # Initialize frame options visibility
        self.on_mode_changed()
    
    def load_image(self, image_path):
        """Load the sprite sheet image (PIL only for import)"""
        try:
            pil_img = Image.open(image_path)
            if pil_img.mode != 'RGBA':
                pil_img = pil_img.convert('RGBA')
            self.original_image = np.array(pil_img)
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to load image: {e}")
            self.original_image = None
    
    def on_mode_changed(self):
        """Handle output mode change"""
        is_separate = self.separate_frames_radio.isChecked()
        self.separate_frame_options.setVisible(is_separate)
        self.single_frame_options.setVisible(not is_separate)
    
    def on_auto_bg_toggled(self, checked):
        """Handle auto-detect background checkbox"""
        self.bg_color_button.setEnabled(not checked)
        if self.original_image is not None:
            self.process_workflow()
    
    def on_tolerance_changed(self, value):
        """Handle tolerance slider change"""
        self.tolerance = value
        self.tolerance_label.setText(str(value))
        if self.original_image is not None:
            self.process_workflow()
    
    def auto_detect_background(self):
        """Step 1a: Auto-detect background color from top-left pixel"""
        if self.original_image is not None:
            # Get top-left pixel RGB
            bg_color = tuple(self.original_image[0, 0, :3])
            return bg_color
        return None
    
    def pick_bg_color(self):
        """Step 1b: Manual background color selection"""
        current_bg = self.auto_detect_background()
        if current_bg:
            initial_color = QColor(*current_bg)
        else:
            initial_color = QColor(255, 0, 255)  # Magenta default
        
        color = QColorDialog.getColor(initial_color, self)
        if color.isValid():
            self.bg_color = (color.red(), color.green(), color.blue())
            self.auto_detect_bg_check.setChecked(False)
            self.update_bg_color_display()
            self.process_workflow()
    
    def update_bg_color_display(self):
        """Update background color display indicator"""
        if self.bg_color:
            r, g, b = self.bg_color
            self.bg_color_display.setStyleSheet(f"color: rgb({r},{g},{b}); font-size: 24px;")
    
    def process_workflow(self):
        """Execute the complete sprite detection workflow"""
        if self.original_image is None:
            return
        
        try:
            # Step 1: Determine background color
            if self.auto_detect_bg_check.isChecked():
                self.bg_color = self.auto_detect_background()
            
            if self.bg_color is None:
                return
            
            self.update_bg_color_display()
            
            # Step 2: Remove background with tolerance
            self.processed_image = self.remove_background_with_tolerance(
                self.original_image, self.bg_color, self.tolerance
            )
            
            # Step 3: Auto crop entire image
            cropped_image = self.auto_crop_image(self.processed_image)
            
            # Step 4: Detect sprite bounding boxes
            self.sprite_bboxes = self.detect_sprite_bboxes(cropped_image)
            
            if not self.sprite_bboxes:
                self.info_label.setText("⚠ No sprites detected. Adjust tolerance or check background color.")
                self.status_label.setText("No sprites found")
                self.apply_button.setEnabled(False)
                self.preview_area.setText("No sprites detected")
                return
            
            # Step 5: Extract sprites from bounding boxes
            self.frames_data = self.extract_sprites_from_bboxes(cropped_image, self.sprite_bboxes)
            
            # Display sprite information
            if self.frames_data:
                # Verify all sprites have same dimensions (they should!)
                widths = [sprite.shape[1] for sprite, _, _, _, _ in self.frames_data]
                heights = [sprite.shape[0] for sprite, _, _, _, _ in self.frames_data]
                
                all_same_width = len(set(widths)) == 1
                all_same_height = len(set(heights)) == 1
                
                canvas_w = self.standard_canvas_width
                canvas_h = self.standard_canvas_height
                
                if all_same_width and all_same_height:
                    self.info_label.setText(
                        f"✓ Background: RGB{self.bg_color} | "
                        f"Tolerance: {self.tolerance} | "
                        f"Canvas: {canvas_w}×{canvas_h}px (standardized) | "
                        f"Sprites: {len(self.frames_data)}"
                    )
                else:
                    # This shouldn't happen, but show warning if it does
                    self.info_label.setText(
                        f"⚠ Warning: Inconsistent sprite sizes detected! | "
                        f"Target: {canvas_w}×{canvas_h}px | "
                        f"Sprites: {len(self.frames_data)}"
                    )
                
                self.status_label.setText(f"Ready to import {len(self.frames_data)} sprites (all {canvas_w}×{canvas_h}px)")
                self.apply_button.setEnabled(True)
            
            # Step 6: Update preview with bounding boxes
            self.update_preview_with_bboxes(cropped_image)
            
        except Exception as e:
            self.status_label.setText(f"Error: {str(e)}")
            self.info_label.setText("⚠ Processing failed")
            self.apply_button.setEnabled(False)
    
    def remove_background_with_tolerance(self, image, bg_color, tolerance):
        """Step 2: Remove background pixels with tolerance"""
        result = image.copy()
        h, w = result.shape[:2]
        
        # Create mask for pixels that match background color within tolerance
        bg_mask = np.ones((h, w), dtype=bool)
        for i, bg_val in enumerate(bg_color[:3]):
            channel = result[:, :, i]
            mask = np.abs(channel.astype(int) - bg_val) <= tolerance
            bg_mask = bg_mask & mask
        
        # Set alpha to 0 for background pixels
        result[bg_mask, 3] = 0
        
        return result
    
    def auto_crop_image(self, image):
        """Step 3: Automatically crop image to content bounds"""
        # Find rows and columns with non-transparent pixels
        alpha = image[:, :, 3]
        has_content = alpha > 0
        
        if not np.any(has_content):
            return image  # No content, return as-is
        
        rows = np.any(has_content, axis=1)
        cols = np.any(has_content, axis=0)
        
        y_min = np.argmax(rows)
        y_max = len(rows) - np.argmax(rows[::-1])
        x_min = np.argmax(cols)
        x_max = len(cols) - np.argmax(cols[::-1])
        
        return image[y_min:y_max, x_min:x_max].copy()
    
    def detect_sprite_bboxes(self, image):
        """Step 4: Detect bounding boxes for each sprite using connected components"""
        alpha = image[:, :, 3]
        
        if CV2_AVAILABLE:
            # Use OpenCV connected components for accurate detection
            non_transparent = (alpha > 0).astype(np.uint8) * 255
            num_labels, labels, stats, centroids = cv2.connectedComponentsWithStats(
                non_transparent, connectivity=8
            )
            
            bboxes = []
            for label_id in range(1, num_labels):  # Skip background (label 0)
                x = int(stats[label_id, cv2.CC_STAT_LEFT])
                y = int(stats[label_id, cv2.CC_STAT_TOP])
                w = int(stats[label_id, cv2.CC_STAT_WIDTH])
                h = int(stats[label_id, cv2.CC_STAT_HEIGHT])
                area = int(stats[label_id, cv2.CC_STAT_AREA])
                
                # Filter out very small sprites (likely noise)
                if area > 4:  # At least 5 pixels
                    bboxes.append((x, y, w, h))
            
            # Check for touching sprites and split them if needed
            bboxes = self.split_touching_sprites(bboxes, alpha)
            
            # Sort properly: top-to-bottom, left-to-right by grouping into rows
            bboxes = self.sort_sprites_by_position(bboxes)
            
            return bboxes
        else:
            # Fallback: Simple grid-based detection (less accurate)
            has_content = alpha > 0
            
            if not np.any(has_content):
                return []
            
            # Find continuous regions manually
            rows = np.any(has_content, axis=1)
            cols = np.any(has_content, axis=0)
            
            # Simple approach: treat entire image as one sprite if no CV2
            if np.any(rows) and np.any(cols):
                y_min = np.argmax(rows)
                y_max = len(rows) - np.argmax(rows[::-1])
                x_min = np.argmax(cols)
                x_max = len(cols) - np.argmax(cols[::-1])
                return [(x_min, y_min, x_max - x_min, y_max - y_min)]
            
            return []
    
    def split_touching_sprites(self, bboxes, alpha_channel):
        """Detect and split sprites that are touching each other"""
        if len(bboxes) < 2:
            return bboxes
        
        # Calculate median dimensions to detect outliers
        widths = [w for x, y, w, h in bboxes]
        heights = [h for x, y, w, h in bboxes]
        
        median_w = np.median(widths)
        median_h = np.median(heights)
        
        split_bboxes = []
        
        for x, y, w, h in bboxes:
            # Check if this bbox is significantly wider than median (likely touching sprites)
            if w > median_w * 1.8:  # 80% wider than median
                # Split horizontally by finding gaps in columns
                sprite_region = alpha_channel[y:y+h, x:x+w]
                col_density = np.sum(sprite_region > 0, axis=0)
                
                # Find columns with low density (gaps between sprites)
                threshold = np.max(col_density) * 0.1  # 10% threshold
                gaps = np.where(col_density < threshold)[0]
                
                if len(gaps) > 0:
                    # Find the middle gap to split
                    mid_point = w // 2
                    middle_gaps = gaps[np.abs(gaps - mid_point) < w * 0.3]  # Within 30% of middle
                    
                    if len(middle_gaps) > 0:
                        split_x = x + int(np.median(middle_gaps))
                        
                        # Create two bboxes
                        left_w = split_x - x
                        right_w = w - left_w
                        
                        if left_w > 5 and right_w > 5:  # Valid split
                            split_bboxes.append((x, y, left_w, h))
                            split_bboxes.append((split_x, y, right_w, h))
                            continue
            
            # Check if significantly taller than median (vertically touching sprites)
            elif h > median_h * 1.8:
                # Split vertically by finding gaps in rows
                sprite_region = alpha_channel[y:y+h, x:x+w]
                row_density = np.sum(sprite_region > 0, axis=1)
                
                # Find rows with low density
                threshold = np.max(row_density) * 0.1
                gaps = np.where(row_density < threshold)[0]
                
                if len(gaps) > 0:
                    mid_point = h // 2
                    middle_gaps = gaps[np.abs(gaps - mid_point) < h * 0.3]
                    
                    if len(middle_gaps) > 0:
                        split_y = y + int(np.median(middle_gaps))
                        
                        top_h = split_y - y
                        bottom_h = h - top_h
                        
                        if top_h > 5 and bottom_h > 5:
                            split_bboxes.append((x, y, w, top_h))
                            split_bboxes.append((x, split_y, w, bottom_h))
                            continue
            
            # No split needed, keep original
            split_bboxes.append((x, y, w, h))
        
        # Don't re-sort here - will be sorted later with proper row grouping
        return split_bboxes
    
    def sort_sprites_by_position(self, bboxes):
        """Sort sprites in proper reading order: top-to-bottom, left-to-right"""
        if not bboxes:
            return bboxes
        
        # Group sprites into rows based on Y overlap
        rows = []
        sorted_by_y = sorted(bboxes, key=lambda b: b[1])  # Sort by Y first
        
        for bbox in sorted_by_y:
            x, y, w, h = bbox
            bbox_center_y = y + h // 2
            
            # Try to find an existing row this sprite belongs to
            placed = False
            for row in rows:
                # Check if this sprite's center Y is within any existing sprite's Y range in this row
                for existing_x, existing_y, existing_w, existing_h in row:
                    existing_center_y = existing_y + existing_h // 2
                    # If centers are within 50% of average height, consider them same row
                    avg_height = (h + existing_h) / 2
                    if abs(bbox_center_y - existing_center_y) < avg_height * 0.5:
                        row.append(bbox)
                        placed = True
                        break
                if placed:
                    break
            
            # If not placed in existing row, create new row
            if not placed:
                rows.append([bbox])
        
        # Sort sprites within each row by X coordinate (left to right)
        for row in rows:
            row.sort(key=lambda b: b[0])
        
        # Flatten rows into final sorted list
        sorted_bboxes = []
        for row in rows:
            sorted_bboxes.extend(row)
        
        return sorted_bboxes
    
    def extract_sprites_from_bboxes(self, image, bboxes):
        """Step 5: Extract individual sprites, crop them tight, and prepare for standardization"""
        if not bboxes:
            return []
        
        # Extract and crop all sprites to their tight bounds
        cropped_sprites = []
        for x, y, w, h in bboxes:
            # Extract sprite region from original bounding box
            sprite = image[y:y+h, x:x+w].copy()
            
            # Crop to tight bounds (remove any remaining transparent pixels)
            tight_sprite = self.auto_crop_image(sprite)
            
            # Store cropped sprite with original position metadata
            cropped_sprites.append({
                'sprite': tight_sprite,
                'width': tight_sprite.shape[1],
                'height': tight_sprite.shape[0],
                'orig_x': x,
                'orig_y': y
            })
        
        # Find maximum dimensions across ALL sprites
        max_width = max(s['width'] for s in cropped_sprites)
        max_height = max(s['height'] for s in cropped_sprites)
        
        # Store standardized dimensions for later use
        self.standard_canvas_width = max_width
        self.standard_canvas_height = max_height
        
        # Create standardized sprites: each centered in canvas of same size
        standardized_sprites = []
        for sprite_data in cropped_sprites:
            # Center this sprite in the standardized canvas
            centered = self.center_sprite_in_canvas(
                sprite_data['sprite'], 
                max_width, 
                max_height
            )
            
            # CRITICAL: Verify this sprite has correct dimensions
            actual_h, actual_w = centered.shape[:2]
            if actual_h != max_height or actual_w != max_width:
                print(f"ERROR: Sprite has wrong size! Expected {max_width}x{max_height}, got {actual_w}x{actual_h}")
                # Force correct size
                centered = np.zeros((max_height, max_width, 4), dtype=np.uint8)
            
            # Store with metadata
            standardized_sprites.append((
                centered,
                sprite_data['orig_x'],
                sprite_data['orig_y'],
                max_width,  # All sprites now have same width
                max_height  # All sprites now have same height
            ))
        
        # Final verification: Check ALL sprites have same dimensions
        if standardized_sprites:
            first_h, first_w = standardized_sprites[0][0].shape[:2]
            all_match = all(s[0].shape[0] == first_h and s[0].shape[1] == first_w for s in standardized_sprites)
            if not all_match:
                print("WARNING: Not all standardized sprites have the same dimensions!")
                for idx, (sprite, _, _, _, _) in enumerate(standardized_sprites):
                    print(f"  Sprite {idx}: {sprite.shape[1]}x{sprite.shape[0]}")
        
        return standardized_sprites
    
    def center_sprite_in_canvas(self, sprite, canvas_w, canvas_h):
        """Center a sprite within a standardized canvas size - ALWAYS returns exactly canvas_w x canvas_h"""
        # Ensure we have integer dimensions
        canvas_w = int(canvas_w)
        canvas_h = int(canvas_h)
        
        # Create blank transparent canvas of EXACT size requested
        canvas = np.zeros((canvas_h, canvas_w, 4), dtype=np.uint8)
        
        if sprite is None or sprite.size == 0:
            return canvas
        
        sprite_h, sprite_w = sprite.shape[:2]
        
        # If sprite is too large, we need to scale it down to fit
        if sprite_w > canvas_w or sprite_h > canvas_h:
            print(f"WARNING: Sprite {sprite_w}x{sprite_h} is larger than canvas {canvas_w}x{canvas_h}, will be clipped")
            # Clip to canvas size
            sprite = sprite[:min(sprite_h, canvas_h), :min(sprite_w, canvas_w)]
            sprite_h, sprite_w = sprite.shape[:2]
        
        # Calculate centering offsets
        offset_x = (canvas_w - sprite_w) // 2
        offset_y = (canvas_h - sprite_h) // 2
        
        # Ensure we don't go out of bounds
        offset_x = max(0, min(offset_x, canvas_w - sprite_w))
        offset_y = max(0, min(offset_y, canvas_h - sprite_h))
        
        # Place sprite in center of canvas
        try:
            canvas[offset_y:offset_y+sprite_h, offset_x:offset_x+sprite_w] = sprite
        except Exception as e:
            print(f"ERROR placing sprite in canvas: {e}")
            print(f"  Canvas: {canvas_w}x{canvas_h}, Sprite: {sprite_w}x{sprite_h}, Offset: ({offset_x},{offset_y})")
        
        # VERIFY the canvas is exactly the right size
        actual_h, actual_w = canvas.shape[:2]
        if actual_h != canvas_h or actual_w != canvas_w:
            print(f"ERROR: Canvas size mismatch! Expected {canvas_w}x{canvas_h}, got {actual_w}x{actual_h}")
        
        return canvas
    
    def update_preview_with_bboxes(self, cropped_image):
        """Step 6: Update preview showing sprites with bounding boxes"""
        if cropped_image is None or not self.sprite_bboxes:
            self.preview_area.setText("No preview available")
            return
        
        # Create preview image with bounding boxes drawn
        preview_img = cropped_image.copy()
        h, w = preview_img.shape[:2]
        
        # Convert to RGB for display (with checkerboard for transparency)
        display_img = np.ones((h, w, 3), dtype=np.uint8) * 128  # Gray background
        
        # Create checkerboard pattern
        checker_size = 8
        for y in range(0, h, checker_size):
            for x in range(0, w, checker_size):
                if ((x // checker_size) + (y // checker_size)) % 2 == 0:
                    display_img[y:min(y+checker_size, h), x:min(x+checker_size, w)] = 180
                else:
                    display_img[y:min(y+checker_size, h), x:min(x+checker_size, w)] = 100
        
        # Blend image onto checkerboard
        alpha = preview_img[:, :, 3:4] / 255.0
        display_img = (display_img * (1 - alpha) + preview_img[:, :, :3] * alpha).astype(np.uint8)
        
        # Convert to QImage
        bytes_per_line = display_img.shape[1] * 3
        qimg = QImage(display_img.data, w, h, bytes_per_line, QImage.Format_RGB888)
        
        # Draw bounding boxes on QPixmap
        pixmap = QPixmap.fromImage(qimg)
        painter = QPainter(pixmap)
        
        # Draw bounding boxes
        pen = QPen(QColor(0, 255, 0), 2)  # Green boxes
        painter.setPen(pen)
        
        for idx, (x, y, bbox_w, bbox_h) in enumerate(self.sprite_bboxes):
            painter.drawRect(x, y, bbox_w, bbox_h)
            
            # Draw sprite number
            painter.drawText(x + 2, y + 12, str(idx + 1))
        
        painter.end()
        
        # Scale pixmap to fit preview area while maintaining aspect ratio
        scaled_pixmap = pixmap.scaled(
            self.preview_area.width() - 10,
            self.preview_area.height() - 10,
            Qt.KeepAspectRatio,
            Qt.SmoothTransformation
        )
        
        self.preview_area.setPixmap(scaled_pixmap)
    
    
    def get_results(self):
        """Return the sprite import results with standardized sprites"""
        if not self.frames_data:
            return None
        
        # Extract sprite arrays (all should be standardized to same size)
        raw_sprites = [sprite for sprite, _, _, _, _ in self.frames_data]
        
        # Use the stored standardized dimensions
        canvas_width = self.standard_canvas_width
        canvas_height = self.standard_canvas_height
        
        # CRITICAL: Ensure ALL sprites are exactly the same size
        # Re-standardize if needed (this is a safety check)
        standardized_sprites = []
        for sprite in raw_sprites:
            h, w = sprite.shape[:2]
            
            if h == canvas_height and w == canvas_width:
                # Perfect, already correct size
                standardized_sprites.append(sprite)
            else:
                # Wrong size - re-standardize it
                print(f"WARNING: Sprite has wrong size {w}x{h}, re-standardizing to {canvas_width}x{canvas_height}")
                # Crop the sprite tight first
                cropped = self.auto_crop_image(sprite)
                # Then center it in the correct canvas
                recentered = self.center_sprite_in_canvas(cropped, canvas_width, canvas_height)
                standardized_sprites.append(recentered)
        
        # Final validation: Verify all sprites are exactly the same size
        if standardized_sprites:
            first_shape = standardized_sprites[0].shape
            all_match = all(s.shape == first_shape for s in standardized_sprites)
            
            if all_match:
                print(f"✓ SUCCESS: All {len(standardized_sprites)} sprites are {canvas_width}×{canvas_height}px")
            else:
                print("✗ ERROR: Sprites still have different sizes after standardization:")
                for idx, s in enumerate(standardized_sprites):
                    print(f"    Sprite {idx}: {s.shape[1]}×{s.shape[0]}px")
        
        sprites = standardized_sprites
        
        # Determine output mode and frame option
        if self.separate_frames_radio.isChecked():
            mode = 'separate_frames'
            if self.start_current_radio.isChecked():
                frame_option = 'current'
                specific_frame = 0
            elif self.start_end_radio.isChecked():
                frame_option = 'end'
                specific_frame = 0
            else:  # start_specific_radio
                frame_option = 'specific'
                specific_frame = self.specific_frame_spin.value()
        else:  # single_frame_grid
            mode = 'single_frame_grid'
            if self.replace_current_radio.isChecked():
                frame_option = 'replace_current'
                specific_frame = 0
            elif self.new_frame_radio.isChecked():
                frame_option = 'new_frame'
                specific_frame = 0
            else:  # place_specific_radio
                frame_option = 'specific'
                specific_frame = self.place_frame_spin.value()
        
        return {
            'mode': mode,
            'frame_option': frame_option,
            'specific_frame': specific_frame,
            'frames': sprites,  # All sprites are standardized to same canvas size
            'background_color': self.bg_color,
            'sprite_size': (canvas_width, canvas_height),  # Standardized dimensions
            'tolerance': self.tolerance,
            'canvas_width': canvas_width,  # Explicit canvas dimensions
            'canvas_height': canvas_height
        }

