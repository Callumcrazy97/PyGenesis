from PySide6.QtWidgets import (QWidget, QHBoxLayout, QVBoxLayout, QPushButton, 
                               QLabel, QScrollArea, QFrame, QMenu, QColorDialog,
                               QInputDialog, QMessageBox, QCheckBox, QComboBox, QSlider, QSizePolicy)
from PySide6.QtCore import Qt, Signal, QTimer, QRect, QPoint
from PySide6.QtGui import QPainter, QColor, QPen, QBrush, QFont, QPixmap, QImage, QWheelEvent, QPolygon
import numpy as np
from core.state import state
from Core.Debug import debug

# Try to import cv2 for better thumbnail scaling
try:
    import cv2
    CV2_AVAILABLE = True
except ImportError:
    CV2_AVAILABLE = False

class ScrollableTimelineContainer(QWidget):
    """Container widget that forwards mouse wheel events to scroll area"""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.scroll_area = None
        # Ensure container maintains minimum size for frames (96px height + padding)
        self.setMinimumHeight(96)
        self.setMaximumHeight(96)
    
    def wheelEvent(self, event: QWheelEvent):
        """Forward wheel events to the scroll area for horizontal scrolling"""
        if self.scroll_area:
            # Convert vertical wheel delta to horizontal scroll
            delta = event.angleDelta().y()
            if delta != 0:
                # Get current scroll position
                scrollbar = self.scroll_area.horizontalScrollBar()
                if scrollbar:
                    # Scroll horizontally based on wheel delta
                    # Use Shift modifier for vertical scrolling (default), otherwise horizontal
                    if event.modifiers() & Qt.ShiftModifier:
                        # Normal vertical scrolling (if we wanted vertical)
                        super().wheelEvent(event)
                    else:
                        # Horizontal scrolling with mouse wheel
                        current_value = scrollbar.value()
                        scroll_amount = delta // 8  # Adjust scroll sensitivity
                        scrollbar.setValue(current_value - scroll_amount)
                        event.accept()
                        return
        
        # Fallback to default behavior
        super().wheelEvent(event)

class FrameBox(QFrame):
    """Individual frame box in the timeline"""
    
    clicked = Signal(int, bool, bool)  # frame index, ctrl_pressed, shift_pressed
    double_clicked = Signal(int)  # frame index
    right_clicked = Signal(int, object)  # frame index, position
    drag_started = Signal(int)  # frame index when drag starts
    
    def __init__(self, frame_index, frame, parent=None):
        super().__init__(parent)
        self.frame_index = frame_index
        self.frame = frame
        self.selected = False
        self.hovered = False
        # Size reduced by 20%: 112px wide, 96px tall (from 140x120)
        self.setFixedSize(112, 96)
        self.setFrameStyle(QFrame.Box)
        self.setCursor(Qt.PointingHandCursor)
        
        # Generate thumbnail
        self.thumbnail = self._generate_thumbnail()
    
    def _generate_thumbnail(self):
        """Generate thumbnail from frame image - CACHED for performance"""
        if self.frame.image is None:
            return None
        
        # PERFORMANCE: Check cache - only regenerate if frame image changed
        img_id = id(self.frame.image)
        if hasattr(self, '_thumbnail_cache_key') and self._thumbnail_cache_key == img_id and hasattr(self, '_cached_thumbnail'):
            return self._cached_thumbnail
        
        # Resize image to thumbnail size - larger thumbnails to fill frame box
        # Frame box is 112x96, leave room for borders and frame number (about 88x70)
        h, w = self.frame.image.shape[:2]
        target_w, target_h = 88, 70  # Target thumbnail size (reduced by 20%)
        scale = min(target_w / w, target_h / h)
        new_w, new_h = int(w * scale), int(h * scale)
        
        # Use cv2 for high-quality scaling if available, otherwise fallback to simple scaling
        if CV2_AVAILABLE:
            # Frame image format: numpy array with shape (H, W, C) where C is 3 (RGB) or 4 (RGBA)
            if len(self.frame.image.shape) == 3:
                if self.frame.image.shape[2] == 4:  # RGBA
                    # Extract RGB channels (assume frame.image is RGB format, not BGR)
                    img_rgb = self.frame.image[:, :, :3]
                    # cv2 expects BGR, so convert RGB to BGR
                    img_bgr = cv2.cvtColor(img_rgb, cv2.COLOR_RGB2BGR)
                    # Resize using cv2 (high quality interpolation)
                    thumbnail_bgr = cv2.resize(img_bgr, (new_w, new_h), interpolation=cv2.INTER_AREA)
                    # Convert back to RGB
                    thumbnail_rgb = cv2.cvtColor(thumbnail_bgr, cv2.COLOR_BGR2RGB)
                    # Create RGBA thumbnail with alpha channel
                    thumbnail = np.zeros((new_h, new_w, 4), dtype=np.uint8)
                    thumbnail[:, :, :3] = thumbnail_rgb
                    thumbnail[:, :, 3] = 255  # Full opacity
                elif self.frame.image.shape[2] == 3:  # RGB
                    # Convert RGB to BGR for cv2
                    img_bgr = cv2.cvtColor(self.frame.image, cv2.COLOR_RGB2BGR)
                    # Resize using cv2
                    thumbnail_bgr = cv2.resize(img_bgr, (new_w, new_h), interpolation=cv2.INTER_AREA)
                    # Convert back to RGB
                    thumbnail = cv2.cvtColor(thumbnail_bgr, cv2.COLOR_BGR2RGB)
                else:
                    # Other format, just resize directly
                    thumbnail = cv2.resize(self.frame.image, (new_w, new_h), interpolation=cv2.INTER_AREA)
            else:
                # Grayscale
                thumbnail = cv2.resize(self.frame.image, (new_w, new_h), interpolation=cv2.INTER_AREA)
        else:
            # Fallback: simple nearest-neighbor scaling
            thumbnail = np.zeros((new_h, new_w, 4), dtype=np.uint8)
            for y in range(new_h):
                for x in range(new_w):
                    src_x = min(int(x / scale), w - 1)
                    src_y = min(int(y / scale), h - 1)
                    thumbnail[y, x] = self.frame.image[src_y, src_x]
        
        # Cache the thumbnail
        self._cached_thumbnail = thumbnail
        self._thumbnail_cache_key = img_id
        
        return thumbnail
    
    def paintEvent(self, event):
        painter = QPainter(self)
        
        # Background with border thickness
        border_thickness = 3
        inner_rect = self.rect().adjusted(border_thickness, border_thickness, -border_thickness, -border_thickness)
        
        # Fill background with frame color or default
        if self.frame.color_code:
            # Color by tag - fill entire box
            color = QColor(self.frame.color_code)
            painter.fillRect(self.rect(), color)
        else:
            painter.fillRect(self.rect(), QColor("#ffffff"))
        
        # Draw selection highlight background
        if self.selected:
            # Fill with semi-transparent blue background for selected frames
            highlight_color = QColor(44, 90, 160, 80)  # Blue with transparency
            painter.fillRect(self.rect(), highlight_color)
            # Draw thicker, brighter border for selected frames
            painter.setPen(QPen(QColor("#2c5aa0"), border_thickness + 2))
        else:
            painter.setPen(QPen(QColor("#cccccc"), border_thickness))
        painter.drawRect(self.rect().adjusted(border_thickness//2, border_thickness//2, -border_thickness//2, -border_thickness//2))
        
        # Draw hover effect
        if self.hovered and not self.selected:
            hover_color = QColor(200, 200, 200, 60)  # Light gray with transparency
            painter.fillRect(self.rect(), hover_color)
        
        # Draw keyframe indicator if this frame has a keyframe
        try:
            from core.state import state
            layer = state.layer_manager.get_current_layer() if hasattr(state, 'layer_manager') else None
            if layer and layer.rig_animation:
                keyframe = layer.rig_animation.get_keyframe_at(self.frame_index)
                if keyframe:
                    # Draw diamond indicator at top-right
                    keyframe_color = QColor(255, 200, 0)  # Yellow/orange
                    painter.setBrush(QBrush(keyframe_color))
                    painter.setPen(QPen(QColor(0, 0, 0), 1))
                    # Draw diamond shape
                    center_x = self.width() - 8
                    center_y = 8
                    size = 6
                    points = [
                        QPoint(center_x, center_y - size),  # Top
                        QPoint(center_x + size, center_y),  # Right
                        QPoint(center_x, center_y + size),  # Bottom
                        QPoint(center_x - size, center_y)   # Left
                    ]
                    painter.drawPolygon(QPolygon(points))
        except:
            pass
        
        # Draw frame preview thumbnail in the center
        if self.thumbnail is not None:
            # Calculate preview position (centered horizontally, top portion of box)
            preview_w, preview_h = self.thumbnail.shape[1], self.thumbnail.shape[0]
            preview_x = (self.width() - preview_w) // 2
            preview_y = 5  # Top area for thumbnail, leaving room for frame number at bottom
            
            # Ensure the array is contiguous and convert to QImage
            thumbnail_contiguous = np.ascontiguousarray(self.thumbnail)
            if thumbnail_contiguous.shape[2] == 4:  # RGBA
                qimage = QImage(thumbnail_contiguous.data, preview_w, preview_h, preview_w * 4, QImage.Format_RGBA8888)
            else:  # RGB
                qimage = QImage(thumbnail_contiguous.data, preview_w, preview_h, preview_w * 3, QImage.Format_RGB888)
            
            # Draw the preview
            painter.drawImage(preview_x, preview_y, qimage)
        
        # Frame number at bottom - clearly visible beneath thumbnail
        frame_num_height = 18
        text_rect = QRect(0, self.height() - frame_num_height, self.width(), frame_num_height)
        painter.fillRect(text_rect, QColor("#2c5aa0"))  # Blue background for frame number
        painter.setPen(QColor("#ffffff"))
        painter.setFont(QFont("Arial", 10, QFont.Bold))  # Font size adjusted for smaller frame
        frame_num_text = f"#{self.frame_index}"
        painter.drawText(text_rect, Qt.AlignCenter, frame_num_text)
        
        # Also draw frame number in top-right corner for extra visibility
        corner_rect = QRect(self.width() - 25, 2, 23, 15)
        corner_bg = QColor("#000000")
        corner_bg.setAlpha(200)  # Semi-transparent black background
        painter.fillRect(corner_rect, corner_bg)
        painter.setPen(QColor("#ffffff"))
        painter.setFont(QFont("Arial", 8, QFont.Bold))
        painter.drawText(corner_rect, Qt.AlignCenter, str(self.frame_index))
        
        # Tags at top-left (small indicator)
        if self.frame.tags:
            tag_text = ", ".join(self.frame.tags[:1])  # Show first tag as small indicator
            if len(self.frame.tags) > 1:
                tag_text += "+"
            painter.setPen(QColor("#ffffff"))
            painter.setFont(QFont("Arial", 6))  # Slightly smaller font for reduced frame size
            tag_bg_rect = QRect(2, 2, 40, 10)  # Smaller tag indicator
            painter.fillRect(tag_bg_rect, QColor("#666666"))
            painter.drawText(tag_bg_rect, Qt.AlignCenter, tag_text)
    
    def mousePressEvent(self, event):
        """Handle mouse press - prepare for click or drag"""
        if event.button() == Qt.LeftButton:
            # Store press info but don't emit click yet (wait to see if it's a drag)
            self.press_modifiers = event.modifiers()
            self.drag_start_pos = event.position()
            self.dragging = False
        elif event.button() == Qt.RightButton:
            self.right_clicked.emit(self.frame_index, event.globalPos())
        super().mousePressEvent(event)
    
    def mouseDoubleClickEvent(self, event):
        if event.button() == Qt.LeftButton:
            self.double_clicked.emit(self.frame_index)
    
    def enterEvent(self, event):
        self.hovered = True
        self.update()
    
    def leaveEvent(self, event):
        self.hovered = False
        self.update()
    
    def mouseMoveEvent(self, event):
        """Handle mouse move - start drag when moved enough"""
        if hasattr(self, 'drag_start_pos') and self.drag_start_pos:
            distance = ((event.position().x() - self.drag_start_pos.x()) ** 2 + 
                       (event.position().y() - self.drag_start_pos.y()) ** 2) ** 0.5
            if distance > 5:  # Start dragging after 5 pixels movement
                if not self.dragging:
                    self.dragging = True
                    self.drag_started.emit(self.frame_index)
        super().mouseMoveEvent(event)
    
    def mouseReleaseEvent(self, event):
        """Handle mouse release - emit click if not dragged"""
        if event.button() == Qt.LeftButton:
            # Only emit click signal if we didn't drag
            if not self.dragging and hasattr(self, 'press_modifiers'):
                ctrl_pressed = bool(self.press_modifiers & Qt.ControlModifier)
                shift_pressed = bool(self.press_modifiers & Qt.ShiftModifier)
                self.clicked.emit(self.frame_index, ctrl_pressed, shift_pressed)
            
            # Clean up
            if hasattr(self, 'drag_start_pos'):
                self.drag_start_pos = None
            if hasattr(self, 'press_modifiers'):
                self.press_modifiers = None
            self.dragging = False
        
        super().mouseReleaseEvent(event)

class TimelineWidget(QWidget):
    """Main timeline widget"""
    
    frame_selected = Signal(int)  # frame index
    frame_navigated = Signal(int)  # frame index
    layer_selected = Signal(int)  # layer index
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.current_layer = None
        self.current_layer_index = 0
        self.current_frame_index = 0
        self.frame_boxes = []
        self.scroll_position = 0
        self.selected_frames = set()  # Multi-selection support
        self.last_clicked_frame = None  # For shift-click range selection
        self.color_by_tag = False  # Color coding by tag option
        self.all_layers = []  # All available layers
        
        # For drag-and-drop reordering
        self.drag_start_index = None
        self.drag_in_progress = False
        self.drag_target_index = None
        
        # Enable keyboard focus so shortcuts work
        self.setFocusPolicy(Qt.StrongFocus)
        
        # Playback state
        self.is_playing = False
        self.playback_timer = None
        self.current_playback_tag = None
        
        # Setup keyboard shortcuts
        self._setup_keyboard_shortcuts()
        self.playback_frames = []
        self.playback_index = 0
        
        self._setup_ui()
        self._connect_signals()
    
    def _setup_ui(self):
        """Setup the timeline UI"""
        layout = QVBoxLayout(self)
        # Set maximum height for the entire timeline widget
        self.setMaximumHeight(160)  # Adjusted for smaller frames
        
        # Header
        header_layout = QHBoxLayout()
        header_layout.setSpacing(4)  # Increased spacing between header elements
        
        # Layer selector
        self.layer_label = QLabel("Layer:")
        self.layer_label.setStyleSheet("font-weight: bold; font-size: 12px;")
        header_layout.addWidget(self.layer_label)
        
        self.layer_combo = QComboBox()
        self.layer_combo.setStyleSheet("font-size: 12px; min-width: 120px;")
        self.layer_combo.setToolTip("Select layer to view in timeline")
        self.layer_combo.currentIndexChanged.connect(self._on_layer_changed)
        header_layout.addWidget(self.layer_combo)
        
        header_layout.addStretch()
        
        # Color coding options
        self.color_by_tag_checkbox = QCheckBox("Color by Tag")
        self.color_by_tag_checkbox.setToolTip("Color frame boxes based on their tags")
        self.color_by_tag_checkbox.setStyleSheet("font-size: 12px;")
        self.color_by_tag_checkbox.toggled.connect(self._toggle_color_by_tag)
        header_layout.addWidget(self.color_by_tag_checkbox)
        
        # Navigation buttons
        self.prev_btn = QPushButton("←")
        self.prev_btn.setFixedSize(30, 25)
        self.prev_btn.setToolTip("Previous Frame")
        header_layout.addWidget(self.prev_btn)
        
        self.next_btn = QPushButton("→")
        self.next_btn.setFixedSize(30, 25)
        self.next_btn.setToolTip("Next Frame")
        header_layout.addWidget(self.next_btn)
        
        # Frame operations
        self.add_frame_btn = QPushButton("+")
        self.add_frame_btn.setFixedSize(30, 25)
        self.add_frame_btn.setToolTip("Add Frame")
        header_layout.addWidget(self.add_frame_btn)
        
        self.delete_frame_btn = QPushButton("×")
        self.delete_frame_btn.setFixedSize(30, 25)
        self.delete_frame_btn.setToolTip("Delete Frame")
        header_layout.addWidget(self.delete_frame_btn)
        
        layout.addLayout(header_layout)
        
        # Playback controls row
        playback_layout = QHBoxLayout()
        playback_layout.setSpacing(4)
        
        # Play/Pause button
        self.play_pause_btn = QPushButton("▶️")
        self.play_pause_btn.setFixedSize(30, 25)
        self.play_pause_btn.setToolTip("Play/Pause Animation")
        self.play_pause_btn.setCheckable(True)
        playback_layout.addWidget(self.play_pause_btn)
        
        # Stop button
        self.stop_btn = QPushButton("⏹️")
        self.stop_btn.setFixedSize(30, 25)
        self.stop_btn.setToolTip("Stop Animation")
        playback_layout.addWidget(self.stop_btn)
        
        # Play Tag dropdown
        self.play_tag_label = QLabel("Play Tag:")
        self.play_tag_label.setStyleSheet("font-size: 11px;")
        playback_layout.addWidget(self.play_tag_label)
        
        self.play_tag_combo = QComboBox()
        self.play_tag_combo.setStyleSheet("font-size: 11px; min-width: 100px;")
        self.play_tag_combo.setToolTip("Select tag to play animation")
        self.play_tag_combo.addItem("All Frames")
        playback_layout.addWidget(self.play_tag_combo)
        
        # Loop checkbox
        self.loop_checkbox = QCheckBox("Loop")
        self.loop_checkbox.setStyleSheet("font-size: 11px;")
        self.loop_checkbox.setToolTip("Loop animation")
        self.loop_checkbox.setChecked(True)
        playback_layout.addWidget(self.loop_checkbox)
        
        # Speed slider
        self.speed_label = QLabel("Speed:")
        self.speed_label.setStyleSheet("font-size: 11px;")
        playback_layout.addWidget(self.speed_label)
        
        self.speed_slider = QSlider(Qt.Horizontal)
        self.speed_slider.setRange(25, 400)  # 0.25x to 4x
        self.speed_slider.setValue(100)  # 1x speed
        self.speed_slider.setFixedWidth(80)
        self.speed_slider.setToolTip("Animation speed (0.25x to 4x)")
        playback_layout.addWidget(self.speed_slider)
        
        self.speed_value_label = QLabel("1.0x")
        self.speed_value_label.setStyleSheet("font-size: 11px; min-width: 35px;")
        playback_layout.addWidget(self.speed_value_label)
        
        playback_layout.addStretch()
        
        layout.addLayout(playback_layout)
        
        # Timeline area
        self.scroll_area = QScrollArea()
        self.scroll_area.setWidgetResizable(False)  # Disable resize to allow proper scrolling
        self.scroll_area.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)  # Show when content exceeds width
        self.scroll_area.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.scroll_area.setFixedHeight(106)  # Height to accommodate 96px tall frames with padding
        # Make scrollbar more visible and ensure mouse wheel works
        self.scroll_area.setStyleSheet("""
            QScrollBar:horizontal {
                border: 1px solid #555;
                background: #2d2d30;
                height: 16px;
            }
            QScrollBar::handle:horizontal {
                background: #505050;
                min-width: 20px;
                border-radius: 2px;
            }
            QScrollBar::handle:horizontal:hover {
                background: #606060;
            }
            QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal {
                background: #2d2d30;
                width: 16px;
            }
            QScrollBar::add-line:horizontal:hover, QScrollBar::sub-line:horizontal:hover {
                background: #3d3d40;
            }
        """)
        
        self.timeline_container = ScrollableTimelineContainer()
        # Set minimum height to accommodate frame boxes (96px tall) with padding
        self.timeline_container.setMinimumHeight(96)
        self.timeline_container.setMaximumHeight(96)  # Fixed height
        self.timeline_layout = QHBoxLayout(self.timeline_container)
        self.timeline_layout.setSpacing(6)  # Spacing between frames
        self.timeline_layout.setContentsMargins(5, 5, 5, 5)  # Padding around timeline
        # Remove addStretch() so frames align to the left
        self.timeline_layout.setSizeConstraint(QHBoxLayout.SetMinimumSize)  # Don't shrink items
        
        self.scroll_area.setWidget(self.timeline_container)
        layout.addWidget(self.scroll_area)
        
        # Store reference to scroll area for mouse wheel handling
        self.timeline_container.scroll_area = self.scroll_area
    
    def _connect_signals(self):
        """Connect signal handlers"""
        self.prev_btn.clicked.connect(self._prev_frame)
        self.next_btn.clicked.connect(self._next_frame)
        self.add_frame_btn.clicked.connect(self._add_frame)
        self.delete_frame_btn.clicked.connect(self._delete_frame)
        
        # Playback controls
        self.play_pause_btn.clicked.connect(self._toggle_playback)
        self.stop_btn.clicked.connect(self._stop_playback)
        self.play_tag_combo.currentTextChanged.connect(self._on_play_tag_changed)
        self.speed_slider.valueChanged.connect(self._on_speed_changed)
    
    def _toggle_color_by_tag(self, enabled):
        """Toggle color coding by tag"""
        self.color_by_tag = enabled
        self._update_timeline()
    
    def _get_tag_color_for_frame(self, frame_index):
        """Get color for a specific frame based on tag spanning logic"""
        if not self.color_by_tag or not self.current_layer:
            return None
        
        # Find the most recent tag before or at this frame
        current_tag = None
        for i in range(frame_index, -1, -1):  # Look backwards from current frame
            if i < len(self.current_layer.frames) and self.current_layer.frames[i].tags:
                current_tag = self.current_layer.frames[i].tags[0]  # Use first tag
                break
        
        if not current_tag:
            return None
        
        # Generate color based on tag
        tag_hash = hash(current_tag)
        colors = [
            "#ff6b6b", "#4ecdc4", "#45b7d1", "#96ceb4", "#feca57",
            "#ff9ff3", "#54a0ff", "#5f27cd", "#00d2d3", "#ff9f43"
        ]
        return colors[abs(tag_hash) % len(colors)]
    
    def set_layers(self, layers):
        """Set all available layers and update the timeline"""
        self.all_layers = layers
        self._update_layer_combo()
        
        # Set current layer if available
        if layers and self.current_layer_index < len(layers):
            self.current_layer = layers[self.current_layer_index]
        elif layers:
            self.current_layer = layers[0]
            self.current_layer_index = 0
        else:
            self.current_layer = None
            self.current_layer_index = 0
        
        self.selected_frames.clear()
        self.last_clicked_frame = None
        self._update_timeline()
        
        # Debug: Verify tags and colors are present after update
        if self.current_layer:
            frames_with_tags = [i for i, f in enumerate(self.current_layer.frames) if hasattr(f, 'tags') and f.tags]
            frames_with_colors = [i for i, f in enumerate(self.current_layer.frames) if hasattr(f, 'color_code') and f.color_code]
            debug(f"DEBUG Timeline.set_layers: {len(self.current_layer.frames)} frames, {len(frames_with_tags)} with tags, {len(frames_with_colors)} with colors")
            if frames_with_tags:
                sample_frame = self.current_layer.frames[frames_with_tags[0]]
                debug(f"DEBUG Timeline.set_layers: Sample frame {frames_with_tags[0]} has tags: {sample_frame.tags}")
            if frames_with_colors:
                sample_frame = self.current_layer.frames[frames_with_colors[0]]
                debug(f"DEBUG Timeline.set_layers: Sample frame {frames_with_colors[0]} has color: {sample_frame.color_code}")
    
    def set_layer(self, layer):
        """Set the current layer for timeline display (backward compatibility)"""
        if layer in self.all_layers:
            self.current_layer_index = self.all_layers.index(layer)
            self.current_layer = layer
            self._update_layer_combo()
            self.selected_frames.clear()
            self.last_clicked_frame = None
            self._update_timeline()
    
    def _update_layer_combo(self):
        """Update the layer combo box with current layers"""
        self.layer_combo.clear()
        for i, layer in enumerate(self.all_layers):
            self.layer_combo.addItem(f"{layer.name} ({len(layer.frames)} frames)", i)
        
        # Set current selection
        if self.current_layer_index < len(self.all_layers):
            self.layer_combo.setCurrentIndex(self.current_layer_index)
    
    def _on_layer_changed(self, index):
        """Handle layer selection change"""
        if 0 <= index < len(self.all_layers):
            self.current_layer_index = index
            self.current_layer = self.all_layers[index]
            self.selected_frames.clear()
            self.last_clicked_frame = None
            # Reset playback state when layer changes
            self._stop_playback()
            self._update_timeline()
            self.layer_selected.emit(index)
    
    def _update_timeline(self):
        """Update the timeline display"""
        # Clear existing frame boxes
        for box in self.frame_boxes:
            self.timeline_layout.removeWidget(box)
            box.deleteLater()
        self.frame_boxes.clear()
        
        if not self.current_layer:
            # Set minimum width when no frames
            self.timeline_container.setMinimumWidth(0)
            return
        
        # Debug: Check what frame data we have
        if self.current_layer.frames:
            sample_frame = self.current_layer.frames[0]
            has_tags_attr = hasattr(sample_frame, 'tags')
            has_color_attr = hasattr(sample_frame, 'color_code')
            debug(f"DEBUG Timeline._update_timeline: Frame 0 has tags attr: {has_tags_attr}, color attr: {has_color_attr}")
            if has_tags_attr:
                debug(f"DEBUG Timeline._update_timeline: Frame 0 tags: {sample_frame.tags}")
            if has_color_attr:
                debug(f"DEBUG Timeline._update_timeline: Frame 0 color: {sample_frame.color_code}")
        
        # Create frame boxes
        frame_width = 112  # Width of each frame box (reduced by 20%)
        frame_spacing = 6  # Spacing between frames
        total_width = 0
        
        for i, frame in enumerate(self.current_layer.frames):
            frame_box = FrameBox(i, frame, self.timeline_container)
            # Ensure frame boxes maintain their size and don't shrink
            frame_box.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
            frame_box.clicked.connect(self._frame_clicked)
            frame_box.double_clicked.connect(self._frame_double_clicked)
            frame_box.right_clicked.connect(self._frame_right_clicked)
            frame_box.drag_started.connect(self._on_frame_drag_started)
            
            # Apply color coding by tag if enabled (but preserve manually set colors)
            if self.color_by_tag and not frame.color_code:
                # Only apply tag-based color if frame doesn't already have a manually set color
                tag_color = self._get_tag_color_for_frame(i)
                if tag_color:
                    frame.color_code = tag_color
            
            self.timeline_layout.insertWidget(i, frame_box)
            self.frame_boxes.append(frame_box)
            total_width += frame_width + frame_spacing
        
        # Set minimum width on container to enable scrolling when needed
        # Add some padding
        total_width += 10
        self.timeline_container.setMinimumWidth(total_width)
        self.timeline_container.updateGeometry()
        
        # Update selection
        self._update_selection()
        self._update_play_tag_combo()
    
    def _update_selection(self):
        """Update frame selection display"""
        for i, box in enumerate(self.frame_boxes):
            box.selected = (i in self.selected_frames or i == self.current_frame_index)
            box.update()
    
    def _frame_clicked(self, frame_index, ctrl_pressed, shift_pressed):
        """Handle frame click with multi-selection support"""
        # Ensure boolean values are properly converted (Qt signals sometimes pass integers)
        ctrl_pressed = bool(ctrl_pressed)
        shift_pressed = bool(shift_pressed)
        
        debug(f"DEBUG Timeline: Frame {frame_index} clicked, ctrl={ctrl_pressed}, shift={shift_pressed}, last={self.last_clicked_frame}, selected={list(self.selected_frames)}")
        
        if ctrl_pressed:
            # Ctrl+click: toggle selection
            if frame_index in self.selected_frames:
                self.selected_frames.remove(frame_index)
                debug(f"DEBUG: Removed frame {frame_index} from selection")
            else:
                self.selected_frames.add(frame_index)
                debug(f"DEBUG: Added frame {frame_index} to selection")
            self.last_clicked_frame = frame_index
            # Don't change current_frame_index for ctrl+click
        elif shift_pressed:
            # Shift+click: range selection
            if self.last_clicked_frame is not None and self.last_clicked_frame != frame_index:
                # Range selection from last clicked frame to current frame
                start = min(self.last_clicked_frame, frame_index)
                end = max(self.last_clicked_frame, frame_index)
                self.selected_frames.clear()  # Clear previous selection first
                for i in range(start, end + 1):
                    self.selected_frames.add(i)
                debug(f"DEBUG: Shift-click range {start}-{end}, selected {len(self.selected_frames)} frames")
            else:
                # First click with shift or shift-clicking same frame - just select this frame
                if self.last_clicked_frame is None:
                    self.selected_frames.clear()
                self.selected_frames.add(frame_index)
                debug(f"DEBUG: Shift-click without previous click, selected frame {frame_index}")
            self.last_clicked_frame = frame_index  # Always update last clicked for next shift-click
            # Set current_frame_index to the start of the range for consistency
            if self.selected_frames:
                self.current_frame_index = min(self.selected_frames)
        else:
            # Normal click: single selection
            self.selected_frames.clear()
            self.selected_frames.add(frame_index)
            self.last_clicked_frame = frame_index  # IMPORTANT: Set last_clicked_frame for future shift-clicks
            self.current_frame_index = frame_index
            debug(f"DEBUG: Normal click, selected frame {frame_index}")
        
        print(f"DEBUG: Final selection: {list(self.selected_frames)}, current_frame={self.current_frame_index}")
        self._update_selection()
        # Only emit frame_selected, not frame_navigated for single click
        self.frame_selected.emit(frame_index)
    
    def _frame_double_clicked(self, frame_index):
        """Handle frame double click - navigate to frame"""
        self.current_frame_index = frame_index
        self.selected_frames.clear()
        self.selected_frames.add(frame_index)
        self.last_clicked_frame = frame_index
        self._update_selection()
        # Double click navigates to the frame
        self.frame_navigated.emit(frame_index)
    
    def _frame_right_clicked(self, frame_index, global_pos):
        """Handle frame right click - show context menu"""
        self._show_frame_context_menu(frame_index, global_pos)
    
    def _show_frame_context_menu(self, frame_index, global_pos):
        """Show context menu for frame operations"""
        if not self.current_layer or frame_index >= len(self.current_layer.frames):
            return
        
        menu = QMenu(self)
        
        # Frame operations
        copy_action = menu.addAction("Copy Frame")
        cut_action = menu.addAction("Cut Frame")
        paste_action = menu.addAction("Paste Frame")
        # Enable paste only if we have a copied frame
        paste_action.setEnabled(hasattr(state, 'clipboard_frame') and state.clipboard_frame is not None)
        delete_action = menu.addAction("Delete Frame")
        
        menu.addSeparator()
        
        # Multi-selection operations
        if len(self.selected_frames) > 1:
            copy_selected_action = menu.addAction(f"Copy {len(self.selected_frames)} Frames")
            delete_selected_action = menu.addAction(f"Delete {len(self.selected_frames)} Frames")
            menu.addSeparator()
        
        # Tag operations
        # Get all frames that will be affected (selected frames or just the clicked frame)
        affected_frames = sorted(self.selected_frames) if len(self.selected_frames) > 1 else [frame_index]
        
        # Collect all unique tags from affected frames
        all_tags = set()
        for idx in affected_frames:
            if idx < len(self.current_layer.frames):
                frame = self.current_layer.frames[idx]
                if hasattr(frame, 'tags') and frame.tags:
                    all_tags.update(frame.tags)
        all_tags = sorted(list(all_tags))  # Sort for consistent menu display
        
        # Store tag actions for later lookup
        tag_actions = {}  # tag_name -> QAction
        
        if len(self.selected_frames) > 1:
            add_tag_action = menu.addAction("Tag Selected Range...")
            if all_tags:
                # Create submenu for removing tags
                remove_tag_menu = menu.addMenu("Remove Tag")
                for tag in all_tags:
                    tag_action = remove_tag_menu.addAction(tag)
                    tag_actions[tag] = tag_action
            else:
                remove_tag_menu = None
            clear_tag_action = menu.addAction("Clear All Tags from Selected")
            single_frame_mode = False
        else:
            add_tag_action = menu.addAction("Add Tag...")
            if all_tags:
                # Create submenu for removing tags
                remove_tag_menu = menu.addMenu("Remove Tag")
                for tag in all_tags:
                    tag_action = remove_tag_menu.addAction(tag)
                    tag_actions[tag] = tag_action
            else:
                remove_tag_action = menu.addAction("Remove Tag...")  # Fallback dialog if no tags
                remove_tag_menu = None
            clear_tag_action = None
            single_frame_mode = True
        
        menu.addSeparator()
        
        # Color coding - adapt menu text for single vs multiple selection
        if len(self.selected_frames) > 1:
            set_color_action = menu.addAction(f"Set Color for {len(self.selected_frames)} Frames...")
            clear_color_action = menu.addAction(f"Clear Color from {len(self.selected_frames)} Frames")
        else:
            set_color_action = menu.addAction("Set Color...")
            clear_color_action = menu.addAction("Clear Color")
        
        # Execute menu
        action = menu.exec(global_pos)
        
        if action == copy_action:
            self._copy_frame(frame_index)
        elif action == cut_action:
            self._cut_frame(frame_index)
        elif action == paste_action:
            self._paste_frame(frame_index)
        elif action == delete_action:
            self._delete_frame_at_index(frame_index)
        elif len(self.selected_frames) > 1:
            if action == copy_selected_action:
                self._copy_selected_frames()
            elif action == delete_selected_action:
                self._delete_selected_frames()
            elif action == add_tag_action:
                self._add_tag_to_selection()
            elif action == clear_tag_action:
                self._clear_tag_from_selection()
            elif action in tag_actions.values():
                # Tag removal from submenu for multiple frames
                selected_tag = None
                for tag, tag_action in tag_actions.items():
                    if action == tag_action:
                        selected_tag = tag
                        break
                if selected_tag:
                    self._remove_tag_from_selection(selected_tag)
            elif action == set_color_action:
                # Set color for all selected frames
                self._set_color_for_selection()
            elif action == clear_color_action:
                # Clear color for all selected frames
                self._clear_color_for_selection()
        elif action == add_tag_action:
            self._add_tag(frame_index)
        elif action in tag_actions.values():
            # Single frame tag removal from submenu
            selected_tag = None
            for tag, tag_action in tag_actions.items():
                if action == tag_action:
                    selected_tag = tag
                    break
            if selected_tag:
                self._remove_tag_by_name(frame_index, selected_tag)
        elif 'remove_tag_action' in locals() and remove_tag_action and action == remove_tag_action:
            # Fallback: show dialog if submenu wasn't created
            self._remove_tag(frame_index)
        elif action == set_color_action:
            self._set_frame_color(frame_index)
        elif action == clear_color_action:
            self._clear_frame_color(frame_index)
    
    def _copy_selected_frames(self):
        """Copy all selected frames"""
        if not self.selected_frames:
            return
        
        # Store selected frames in clipboard
        selected_frames_data = []
        for frame_index in sorted(self.selected_frames):
            if frame_index < len(self.current_layer.frames):
                frame = self.current_layer.frames[frame_index]
                selected_frames_data.append({
                    'image': frame.image.copy(),
                    'tags': frame.tags.copy(),
                    'color_code': frame.color_code
                })
        
        state.clipboard_frames = selected_frames_data
    
    def _delete_selected_frames(self):
        """Delete all selected frames"""
        if not self.selected_frames or len(self.current_layer.frames) <= 1:
            return
        
        # Confirm deletion
        reply = QMessageBox.question(
            self, "Delete Frames", 
            f"Are you sure you want to delete {len(self.selected_frames)} frames?",
            QMessageBox.Yes | QMessageBox.No
        )
        
        if reply == QMessageBox.Yes:
            # Delete frames in reverse order to maintain indices
            for frame_index in sorted(self.selected_frames, reverse=True):
                if frame_index < len(self.current_layer.frames):
                    del self.current_layer.frames[frame_index]
            
            # Update timeline
            self.selected_frames.clear()
            self.last_clicked_frame = None
            self._update_timeline()
            
            # Adjust current frame index
            if self.current_frame_index >= len(self.current_layer.frames):
                self.current_frame_index = len(self.current_layer.frames) - 1
            
            self._update_selection()
            self.frame_navigated.emit(self.current_frame_index)
    
    def _prev_frame(self):
        """Navigate to previous frame"""
        if self.current_layer and self.current_frame_index > 0:
            self.current_frame_index -= 1
            self._update_selection()
            self.frame_navigated.emit(self.current_frame_index)
    
    def _next_frame(self):
        """Navigate to next frame"""
        if self.current_layer and self.current_frame_index < len(self.current_layer.frames) - 1:
            self.current_frame_index += 1
            self._update_selection()
            self.frame_navigated.emit(self.current_frame_index)
    
    def _add_frame(self):
        """Add new frame"""
        if not self.current_layer:
            return
        
        # Add frame to layer
        self.current_layer.add_frame(state.width, state.height, state)
        
        # Update timeline
        self._update_timeline()
        
        # Select new frame
        new_frame_index = len(self.current_layer.frames) - 1
        self.current_frame_index = new_frame_index
        self._update_selection()
        self.frame_navigated.emit(new_frame_index)
    
    def _delete_frame(self):
        """Delete current frame"""
        if self.current_layer and len(self.current_layer.frames) > 1:
            self._delete_frame_at_index(self.current_frame_index)
    
    def _delete_frame_at_index(self, frame_index):
        """Delete frame at specific index"""
        if not self.current_layer or frame_index >= len(self.current_layer.frames):
            return
        
        # Confirm deletion
        reply = QMessageBox.question(
            self, "Delete Frame", 
            f"Are you sure you want to delete frame {frame_index}?",
            QMessageBox.Yes | QMessageBox.No
        )
        
        if reply == QMessageBox.Yes:
            # Remove frame
            del self.current_layer.frames[frame_index]
            
            # Update timeline
            self._update_timeline()
            
            # Adjust current frame index
            if self.current_frame_index >= len(self.current_layer.frames):
                self.current_frame_index = len(self.current_layer.frames) - 1
            
            self._update_selection()
            self.frame_navigated.emit(self.current_frame_index)
    
    def _copy_frame(self, frame_index):
        """Copy frame to clipboard"""
        if not self.current_layer or frame_index >= len(self.current_layer.frames):
            return
        
        # Store frame data in clipboard
        frame = self.current_layer.frames[frame_index]
        state.clipboard_frame = {
            'image': frame.image.copy(),
            'tags': frame.tags.copy(),
            'color_code': frame.color_code
        }
    
    def _paste_frame(self, frame_index=None):
        """Paste frame from clipboard"""
        if not state.clipboard_frame:
            return
        
        if frame_index is None:
            frame_index = self.current_frame_index
        
        if not self.current_layer:
            return
        
        # Push undo state
        state.history.push_undo()
        
        # Create new frame from clipboard
        clipboard = state.clipboard_frame
        clipboard_image = clipboard['image']
        
        # Get dimensions from clipboard image
        h, w = clipboard_image.shape[:2]
        
        # Create new frame object with proper dimensions
        from layers.layer import Frame
        pasted_frame = Frame(w, h)
        pasted_frame.image = clipboard_image.copy()
        pasted_frame.tags = clipboard.get('tags', []).copy() if clipboard.get('tags') else []
        pasted_frame.color_code = clipboard.get('color_code')
        
        # Insert after current frame
        self.current_layer.frames.insert(frame_index + 1, pasted_frame)
        
        self.current_frame_index = frame_index + 1
        self._update_timeline()
        self.frame_selected.emit(self.current_frame_index)
    
    def _cut_frame(self, frame_index):
        """Cut frame to clipboard"""
        if not self.current_layer or frame_index >= len(self.current_layer.frames):
            return
        
        # Push undo state
        state.history.push_undo()
        
        self._copy_frame(frame_index)
        self._delete_frame_at_index(frame_index)
    
    def _setup_keyboard_shortcuts(self):
        """Setup keyboard shortcuts for timeline operations"""
        from PySide6.QtGui import QShortcut, QKeySequence
        
        # Copy (Ctrl+C) - only active when timeline has focus
        copy_shortcut = QShortcut(QKeySequence("Ctrl+C"), self)
        copy_shortcut.setContext(Qt.WidgetWithChildrenShortcut)
        copy_shortcut.activated.connect(self._handle_copy_shortcut)
        
        # Cut (Ctrl+X) - only active when timeline has focus
        cut_shortcut = QShortcut(QKeySequence("Ctrl+X"), self)
        cut_shortcut.setContext(Qt.WidgetWithChildrenShortcut)
        cut_shortcut.activated.connect(self._handle_cut_shortcut)
        
        # Paste (Ctrl+V) - only active when timeline has focus
        paste_shortcut = QShortcut(QKeySequence("Ctrl+V"), self)
        paste_shortcut.setContext(Qt.WidgetWithChildrenShortcut)
        paste_shortcut.activated.connect(self._handle_paste_shortcut)
        
        # Undo (Ctrl+Z) - only active when timeline has focus
        undo_shortcut = QShortcut(QKeySequence("Ctrl+Z"), self)
        undo_shortcut.setContext(Qt.WidgetWithChildrenShortcut)
        undo_shortcut.activated.connect(self._handle_undo_shortcut)
        
        # Redo (Ctrl+Y) - only active when timeline has focus
        redo_shortcut = QShortcut(QKeySequence("Ctrl+Y"), self)
        redo_shortcut.setContext(Qt.WidgetWithChildrenShortcut)
        redo_shortcut.activated.connect(self._handle_redo_shortcut)
    
    def _handle_copy_shortcut(self):
        """Handle Ctrl+C shortcut"""
        if self.selected_frames:
            # Copy all selected frames
            self._copy_selected_frames()
        elif self.current_layer and self.current_frame_index < len(self.current_layer.frames):
            # Copy current frame
            self._copy_frame(self.current_frame_index)
    
    def _handle_cut_shortcut(self):
        """Handle Ctrl+X shortcut"""
        if self.selected_frames:
            # Cut all selected frames (multi-frame cut)
            selected_list = sorted(self.selected_frames)
            state.history.push_undo()
            for frame_idx in reversed(selected_list):
                if frame_idx < len(self.current_layer.frames):
                    self._cut_frame(frame_idx)
            self.selected_frames.clear()
            self._update_timeline()
        elif self.current_layer and self.current_frame_index < len(self.current_layer.frames):
            # Cut current frame
            self._cut_frame(self.current_frame_index)
    
    def _handle_paste_shortcut(self):
        """Handle Ctrl+V shortcut"""
        if state.clipboard_frame:
            self._paste_frame()
    
    def _handle_undo_shortcut(self):
        """Handle Ctrl+Z shortcut"""
        if hasattr(state.history, 'undo') and state.history.can_undo():
            state.history.undo()
            self._update_timeline()
            # Update canvas if available
            if hasattr(self, 'parent') and hasattr(self.parent(), 'canvas'):
                self.parent().canvas.update()
    
    def _handle_redo_shortcut(self):
        """Handle Ctrl+Y shortcut"""
        if hasattr(state.history, 'redo') and state.history.can_redo():
            state.history.redo()
            self._update_timeline()
            # Update canvas if available
            if hasattr(self, 'parent') and hasattr(self.parent(), 'canvas'):
                self.parent().canvas.update()
    
    def _on_frame_drag_started(self, frame_index):
        """Handle frame drag start"""
        self.drag_start_index = frame_index
        self.drag_in_progress = True
        self.setCursor(Qt.ClosedHandCursor)
    
    def mouseMoveEvent(self, event):
        """Handle mouse movement during frame drag"""
        if self.drag_in_progress and self.drag_start_index is not None:
            # Find which frame box we're over
            for i, frame_box in enumerate(self.frame_boxes):
                frame_rect = frame_box.geometry()
                if frame_rect.contains(event.position().toPoint() + self.scroll_area.mapToGlobal(self.scroll_area.pos()) - self.mapToGlobal(self.pos())):
                    if i != self.drag_start_index:
                        self.drag_target_index = i
                        self._update_timeline()  # Update visual feedback
                    break
        super().mouseMoveEvent(event)
    
    def mouseReleaseEvent(self, event):
        """Handle mouse release - complete drag-and-drop reorder"""
        if self.drag_in_progress and self.drag_start_index is not None:
            if self.drag_target_index is not None and self.drag_target_index != self.drag_start_index:
                # Reorder frames
                state.history.push_undo()
                frames = self.current_layer.frames
                frame_to_move = frames.pop(self.drag_start_index)
                insert_index = self.drag_target_index
                if insert_index > self.drag_start_index:
                    insert_index -= 1  # Adjust if moving forward
                frames.insert(insert_index, frame_to_move)
                
                # Update current frame index
                self.current_frame_index = insert_index
                self._update_timeline()
                self.frame_selected.emit(self.current_frame_index)
            
            # Reset drag state
            self.drag_in_progress = False
            self.drag_start_index = None
            self.drag_target_index = None
            self.setCursor(Qt.ArrowCursor)
        
        super().mouseReleaseEvent(event)
    
    def _add_tag(self, frame_index):
        """Add tag to frame"""
        if not self.current_layer or frame_index >= len(self.current_layer.frames):
            return
        
        tag, ok = QInputDialog.getText(self, "Add Tag", "Enter tag name:")
        if ok and tag:
            frame = self.current_layer.frames[frame_index]
            if tag not in frame.tags:
                frame.tags.append(tag)
                self._update_timeline()

    def _add_tag_to_selection(self):
        """Add tag to all selected frames (range tagging)."""
        if not self.current_layer or not self.selected_frames:
            return
        tag, ok = QInputDialog.getText(self, "Tag Selected Range", "Enter tag name:")
        if ok and tag:
            for i in sorted(self.selected_frames):
                if i < len(self.current_layer.frames):
                    frame = self.current_layer.frames[i]
                    if tag not in frame.tags:
                        frame.tags.append(tag)
            self._update_timeline()
    
    def _remove_tag(self, frame_index):
        """Remove tag from frame (shows dialog)"""
        if not self.current_layer or frame_index >= len(self.current_layer.frames):
            return
        
        frame = self.current_layer.frames[frame_index]
        if not hasattr(frame, 'tags') or not frame.tags:
            return
        
        tag, ok = QInputDialog.getItem(self, "Remove Tag", "Select tag to remove:", frame.tags, 0, False)
        if ok and tag:
            if tag in frame.tags:
                frame.tags.remove(tag)
                self._update_timeline()
    
    def _remove_tag_by_name(self, frame_index, tag_name):
        """Remove a specific tag from a frame by name"""
        if not self.current_layer or frame_index >= len(self.current_layer.frames):
            return
        
        frame = self.current_layer.frames[frame_index]
        if hasattr(frame, 'tags') and tag_name in frame.tags:
            frame.tags.remove(tag_name)
            self._update_timeline()
    
    def _remove_tag_from_selection(self, tag_name):
        """Remove a specific tag from all selected frames"""
        if not self.current_layer or not self.selected_frames:
            return
        
        for idx in sorted(self.selected_frames):
            if idx < len(self.current_layer.frames):
                frame = self.current_layer.frames[idx]
                if hasattr(frame, 'tags') and tag_name in frame.tags:
                    frame.tags.remove(tag_name)
        
        self._update_timeline()

    def _clear_tag_from_selection(self):
        """Remove a tag from all selected frames."""
        if not self.current_layer or not self.selected_frames:
            return
        # Collect tags present in selection
        tag_set = []
        seen = set()
        for i in sorted(self.selected_frames):
            if i < len(self.current_layer.frames):
                for t in self.current_layer.frames[i].tags:
                    if t not in seen:
                        seen.add(t)
                        tag_set.append(t)
        if not tag_set:
            return
        tag, ok = QInputDialog.getItem(self, "Clear Tag from Selected", "Select tag to remove from selection:", tag_set, 0, False)
        if ok and tag:
            for i in sorted(self.selected_frames):
                if i < len(self.current_layer.frames):
                    frame = self.current_layer.frames[i]
                    if tag in frame.tags:
                        frame.tags.remove(tag)
            self._update_timeline()
    
    def _set_frame_color(self, frame_index):
        """Set frame color code for a single frame"""
        if not self.current_layer or frame_index >= len(self.current_layer.frames):
            return
        
        color = QColorDialog.getColor()
        if color.isValid():
            frame = self.current_layer.frames[frame_index]
            frame.color_code = color.name()
            self._update_timeline()
    
    def _set_color_for_selection(self):
        """Set frame color code for all selected frames"""
        if not self.current_layer or not self.selected_frames:
            return
        
        color = QColorDialog.getColor()
        if color.isValid():
            color_name = color.name()
            for idx in sorted(self.selected_frames):
                if idx < len(self.current_layer.frames):
                    frame = self.current_layer.frames[idx]
                    frame.color_code = color_name
            self._update_timeline()
    
    def _clear_frame_color(self, frame_index):
        """Clear frame color code for a single frame"""
        if not self.current_layer or frame_index >= len(self.current_layer.frames):
            return
        
        frame = self.current_layer.frames[frame_index]
        frame.color_code = None
        self._update_timeline()
    
    def _clear_color_for_selection(self):
        """Clear frame color code for all selected frames"""
        if not self.current_layer or not self.selected_frames:
            return
        
        for idx in sorted(self.selected_frames):
            if idx < len(self.current_layer.frames):
                frame = self.current_layer.frames[idx]
                frame.color_code = None
        self._update_timeline()
    
    def set_current_frame(self, frame_index):
        """Set current frame from external source"""
        if self.current_layer and 0 <= frame_index < len(self.current_layer.frames):
            self.current_frame_index = frame_index
            self._update_selection()
    
    def refresh_timeline(self):
        """Refresh the timeline display - call this when frames are modified externally"""
        if self.current_layer:
            self._update_timeline()
            # Update playback frames when timeline is refreshed
            self._setup_playback_frames()
    
    # Playback methods
    def _toggle_playback(self):
        """Toggle play/pause state"""
        if self.is_playing:
            self._pause_playback()
        else:
            self._start_playback()
    
    def _start_playback(self):
        """Start animation playback"""
        if not self.current_layer or not self.current_layer.frames:
            return
        
        # Setup playback frames based on selected tag
        self._setup_playback_frames()
        
        # Don't start if no frames to play
        if not self.playback_frames:
            return
        
        self.is_playing = True
        self.play_pause_btn.setText("⏸️")
        self.play_pause_btn.setChecked(True)
        
        # Start timer
        if not self.playback_timer:
            from PySide6.QtCore import QTimer
            self.playback_timer = QTimer()
            self.playback_timer.timeout.connect(self._playback_step)
        
        speed = self.speed_slider.value() / 100.0
        interval = int(1000 / speed)  # Convert to milliseconds
        self.playback_timer.start(interval)
    
    def _pause_playback(self):
        """Pause animation playback"""
        self.is_playing = False
        self.play_pause_btn.setText("▶️")
        self.play_pause_btn.setChecked(False)
        
        if self.playback_timer:
            self.playback_timer.stop()
    
    def _stop_playback(self):
        """Stop animation playback"""
        self._pause_playback()
        self.playback_index = 0
        if self.playback_frames:
            self.frame_navigated.emit(self.playback_frames[0])
    
    def _setup_playback_frames(self):
        """Setup which frames to play based on selected tag"""
        if not self.current_layer:
            self.playback_frames = []
            debug(f"DEBUG: No current layer, setting empty playback frames")
            return
        
        selected_tag = self.play_tag_combo.currentText()
        print(f"DEBUG: Setting up playback frames for tag '{selected_tag}'")
        
        if selected_tag == "All Frames":
            # Play all frames
            self.playback_frames = list(range(len(self.current_layer.frames)))
            debug(f"DEBUG: Playing all frames: {self.playback_frames}")
        else:
            # Play only frames with the selected tag
            self.playback_frames = []
            for i, frame in enumerate(self.current_layer.frames):
                if frame.tags and selected_tag in frame.tags:
                    self.playback_frames.append(i)
            debug(f"DEBUG: Playing frames with tag '{selected_tag}': {self.playback_frames}")
        
        # If no frames found for the selected tag, stop playback
        if not self.playback_frames:
            debug(f"DEBUG: No frames found for tag '{selected_tag}', stopping playback")
            self._stop_playback()
            return
        
        # Start from current frame if it's in the playback list
        if self.current_frame_index in self.playback_frames:
            self.playback_index = self.playback_frames.index(self.current_frame_index)
        else:
            self.playback_index = 0
        print(f"DEBUG: Playback index set to {self.playback_index}")
    
    def _playback_step(self):
        """Step to next frame in playback"""
        if not self.playback_frames:
            return
        
        self.playback_index += 1
        
        # Handle looping
        if self.playback_index >= len(self.playback_frames):
            if self.loop_checkbox.isChecked():
                self.playback_index = 0
            else:
                self._stop_playback()
                return
        
        # Navigate to the frame
        frame_index = self.playback_frames[self.playback_index]
        self.frame_navigated.emit(frame_index)
    
    def _on_play_tag_changed(self, tag_name):
        """Handle play tag selection change"""
        print(f"DEBUG: Play tag changed to '{tag_name}'")
        self.current_playback_tag = tag_name if tag_name != "All Frames" else None
        
        # If currently playing, restart playback with new tag
        was_playing = self.is_playing
        if was_playing:
            debug(f"DEBUG: Was playing, stopping playback")
            self._stop_playback()
        
        # Always update playback frames when tag changes
        self._setup_playback_frames()
        print(f"DEBUG: Playback frames set to {self.playback_frames}")
        
        # Restart playback if it was playing before
        if was_playing and self.playback_frames:
            debug(f"DEBUG: Restarting playback")
            self._start_playback()
    
    def _on_speed_changed(self, value):
        """Handle speed slider change"""
        speed = value / 100.0
        self.speed_value_label.setText(f"{speed:.1f}x")
        
        # Update timer interval if playing
        if self.is_playing and self.playback_timer:
            interval = int(1000 / speed)
            self.playback_timer.start(interval)
    
    def _update_play_tag_combo(self):
        """Update the play tag combo box with available tags"""
        if not self.current_layer:
            return
        
        # Temporarily block signals to prevent unwanted callbacks
        self.play_tag_combo.blockSignals(True)
        
        current_text = self.play_tag_combo.currentText()
        self.play_tag_combo.clear()
        self.play_tag_combo.addItem("All Frames")
        
        # Collect all unique tags
        tags = set()
        for frame in self.current_layer.frames:
            for t in frame.tags:
                if t:
                    tags.add(t)
        
        # Add tags to combo box
        for tag in sorted(tags):
            self.play_tag_combo.addItem(tag)
        
        # Restore selection if possible
        index = self.play_tag_combo.findText(current_text)
        if index >= 0:
            self.play_tag_combo.setCurrentIndex(index)
        
        # Re-enable signals
        self.play_tag_combo.blockSignals(False) 