from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QTabWidget, QWidget,
    QComboBox, QColorDialog, QFormLayout, QDialogButtonBox, QLineEdit, QCheckBox,
    QRadioButton, QButtonGroup, QGroupBox, QSlider, QSpinBox, QFrame, QScrollArea,
    QMenu, QMessageBox, QListWidget, QListWidgetItem, QSplitter, QButtonGroup,
    QGridLayout, QSpacerItem, QSizePolicy, QMainWindow
)
from PySide6.QtGui import QColor, QPixmap, QImage, QPainter, QPen, QBrush, QDrag
from PySide6.QtCore import Qt, Signal, QTimer, QRect, QMimeData, QPoint
from core.atlas_manager import AtlasManager, AtlasCell
from core.texture_utils import generate_block_texture_qimage
from core.state import state
import numpy as np
import time

class DraggableGridListWidget(QListWidget):
    """List widget that supports drag and drop reordering of grids."""
    
    grid_reordered = Signal(int, int)  # Emits old_index, new_index
    grid_double_clicked = Signal(int)  # Emits cell index when double-clicked
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setDragDropMode(QListWidget.InternalMove)
        self.setAcceptDrops(True)
        self.setDragEnabled(True)
        self.setDropIndicatorShown(True)
        
    def startDrag(self, actions):
        """Store the starting index when drag begins."""
        self._drag_start_index = self.currentRow()
        super().startDrag(actions)
    
    def dropEvent(self, event):
        """Handle drop and calculate new index."""
        super().dropEvent(event)
        self._drop_index = self.currentRow()
        if hasattr(self, '_drag_start_index') and self._drag_start_index != self._drop_index:
            self.grid_reordered.emit(self._drag_start_index, self._drop_index)
    
    def mouseDoubleClickEvent(self, event):
        """Handle double-click to open grid settings."""
        if event.button() == Qt.LeftButton:
            current_row = self.currentRow()
            if current_row >= 0:
                self.grid_double_clicked.emit(current_row)
        super().mouseDoubleClickEvent(event)

class GridPreviewWidget(QWidget):
    """Widget for previewing a single grid cell with animation controls."""
    
    def __init__(self, atlas_manager, cell_index, parent=None):
        super().__init__(parent)
        self.atlas_manager = atlas_manager
        self.cell_index = cell_index
        self.current_frame = 0
        self.is_playing = False
        self.setMinimumSize(200, 200)
        self.setMaximumSize(300, 300)
        
        # Animation timer
        self.animation_timer = QTimer()
        self.animation_timer.timeout.connect(self.next_frame)
        
        self.setup_ui()
        self.update_preview()
    
    def setup_ui(self):
        """Setup the preview UI with controls."""
        layout = QVBoxLayout(self)
        
        # Preview area
        self.preview_label = QLabel()
        self.preview_label.setAlignment(Qt.AlignCenter)
        self.preview_label.setStyleSheet("border: 1px solid #888; background: #333;")
        layout.addWidget(self.preview_label)
        
        # Controls
        controls_layout = QHBoxLayout()
        
        self.play_btn = QPushButton("▶")
        self.play_btn.setFixedSize(30, 30)
        self.play_btn.clicked.connect(self.toggle_play)
        controls_layout.addWidget(self.play_btn)
        
        self.prev_btn = QPushButton("⏮")
        self.prev_btn.setFixedSize(30, 30)
        self.prev_btn.clicked.connect(self.prev_frame)
        controls_layout.addWidget(self.prev_btn)
        
        self.next_btn = QPushButton("⏭")
        self.next_btn.setFixedSize(30, 30)
        self.next_btn.clicked.connect(self.next_frame)
        controls_layout.addWidget(self.next_btn)
        
        self.frame_label = QLabel("Frame: 1")
        controls_layout.addWidget(self.frame_label)
        
        controls_layout.addStretch()
        layout.addLayout(controls_layout)
    
    def update_preview(self):
        """Update the preview image."""
        if self.cell_index >= len(self.atlas_manager.grid_cells):
            return
            
        cell = self.atlas_manager.grid_cells[self.cell_index]
        
        # Generate texture for current frame
        texture = self.atlas_manager.generate_cell_texture(self.cell_index, self.current_frame)
        if texture:
            # Scale to fit preview
            scaled_texture = texture.scaled(
                self.preview_label.size(), 
                Qt.KeepAspectRatio, 
                Qt.SmoothTransformation
            )
            self.preview_label.setPixmap(QPixmap.fromImage(scaled_texture))
        
        # Update frame label and animation controls visibility
        if cell.animated:
            total_frames = max(1, self.atlas_manager.num_frames)
            self.frame_label.setText(f"Frame: {self.current_frame + 1}/{total_frames}")
            self.play_btn.setVisible(True)
            self.prev_btn.setVisible(True)
            self.next_btn.setVisible(True)
            self.frame_label.setVisible(True)
        else:
            self.frame_label.setText("Static")
            self.play_btn.setVisible(False)
            self.prev_btn.setVisible(False)
            self.next_btn.setVisible(False)
            self.frame_label.setVisible(False)
    
    def toggle_play(self):
        """Toggle animation playback."""
        self.is_playing = not self.is_playing
        if self.is_playing:
            self.play_btn.setText("⏸")
            self.animation_timer.start(200)  # 5 FPS
        else:
            self.play_btn.setText("▶")
            self.animation_timer.stop()
    
    def next_frame(self):
        """Go to next frame."""
        total_frames = max(1, self.atlas_manager.num_frames)
        self.current_frame = (self.current_frame + 1) % total_frames
        self.update_preview()
    
    def prev_frame(self):
        """Go to previous frame."""
        total_frames = max(1, self.atlas_manager.num_frames)
        self.current_frame = (self.current_frame - 1) % total_frames
        self.update_preview()
    
    def set_cell_index(self, cell_index):
        """Set the cell index to preview."""
        self.cell_index = cell_index
        self.current_frame = 0
        self.update_preview()

class GridSettingsDialog(QDialog):
    """Dialog for editing individual grid settings."""
    
    def __init__(self, atlas_manager, cell_index, parent=None):
        super().__init__(parent)
        self.atlas_manager = atlas_manager
        self.cell_index = cell_index
        self.setWindowTitle(f"Grid Settings - {atlas_manager.grid_cells[cell_index].name}")
        self.setModal(True)
        self.resize(400, 500)
        self.setup_ui()
        self.update_from_cell()
    
    def setup_ui(self):
        """Setup the grid settings UI."""
        layout = QVBoxLayout(self)
        
        # Create tab widget
        self.tab_widget = QTabWidget()
        
        # Grid Options tab
        self.options_widget = self.create_options_tab()
        self.tab_widget.addTab(self.options_widget, "Grid Options")
        
        # Grid Preview tab
        self.preview_widget = GridPreviewWidget(self.atlas_manager, self.cell_index)
        self.tab_widget.addTab(self.preview_widget, "Grid Preview")
        
        layout.addWidget(self.tab_widget)
        
        # Buttons
        button_layout = QHBoxLayout()
        button_layout.addStretch()
        
        ok_btn = QPushButton("OK")
        ok_btn.clicked.connect(self.accept)
        button_layout.addWidget(ok_btn)
        
        cancel_btn = QPushButton("Cancel")
        cancel_btn.clicked.connect(self.reject)
        button_layout.addWidget(cancel_btn)
        
        layout.addLayout(button_layout)
    
    def create_options_tab(self):
        """Create the grid options tab."""
        widget = QWidget()
        layout = QVBoxLayout(widget)
        
        # Name
        name_layout = QHBoxLayout()
        name_layout.addWidget(QLabel("Name:"))
        self.name_edit = QLineEdit()
        name_layout.addWidget(self.name_edit)
        layout.addLayout(name_layout)
        
        # Colors
        color_group = QGroupBox("Colors")
        color_layout = QFormLayout(color_group)
        
        self.primary_color_btn = QPushButton()
        self.primary_color_btn.setFixedSize(60, 25)
        self.primary_color_btn.clicked.connect(lambda: self.pick_color('primary'))
        color_layout.addRow("Primary Color:", self.primary_color_btn)
        
        self.secondary_color_btn = QPushButton()
        self.secondary_color_btn.setFixedSize(60, 25)
        self.secondary_color_btn.clicked.connect(lambda: self.pick_color('secondary'))
        color_layout.addRow("Secondary Color:", self.secondary_color_btn)
        
        layout.addWidget(color_group)
        
        # Block Size
        block_group = QGroupBox("Block Settings")
        block_layout = QFormLayout(block_group)
        
        self.block_size_spin = QSpinBox()
        self.block_size_spin.setRange(1, 32)
        self.block_size_spin.setValue(8)
        self.block_size_spin.valueChanged.connect(self.on_block_size_changed)
        block_layout.addRow("Block Size:", self.block_size_spin)
        
        layout.addWidget(block_group)
        
        # Style and Animation
        style_group = QGroupBox("Style & Animation")
        style_layout = QFormLayout(style_group)
        
        self.style_combo = QComboBox()
        self.style_combo.addItems([
            'Air', 'None', 'Water', 'Lava', 'Fire', 'Smoke', 'Fog', 'Crystal', 'Wind', 'Portal'
        ])
        self.style_combo.currentTextChanged.connect(self.on_style_changed)
        style_layout.addRow("Style:", self.style_combo)
        
        self.animated_check = QCheckBox("Animated")
        self.animated_check.toggled.connect(self.on_animated_changed)
        style_layout.addRow(self.animated_check)
        
        layout.addWidget(style_group)
        
        # Ores (for applicable styles)
        ore_group = QGroupBox("Ores")
        ore_layout = QFormLayout(ore_group)
        
        self.ores_check = QCheckBox("Add Ores")
        self.ores_check.toggled.connect(self.on_ores_changed)
        ore_layout.addRow(self.ores_check)
        
        self.num_ores_spin = QSpinBox()
        self.num_ores_spin.setRange(1, 10)
        self.num_ores_spin.setValue(2)
        self.num_ores_spin.valueChanged.connect(self.on_num_ores_changed)
        ore_layout.addRow("Number of Ores:", self.num_ores_spin)
        
        self.ore_color_btn = QPushButton()
        self.ore_color_btn.setFixedSize(60, 25)
        self.ore_color_btn.clicked.connect(lambda: self.pick_color('ore'))
        ore_layout.addRow("Ore Color:", self.ore_color_btn)
        
        layout.addWidget(ore_group)
        
        layout.addStretch()
        return widget
    
    def on_style_changed(self, style_name):
        """Handle style change."""
        # Update cell data
        if self.cell_index < len(self.atlas_manager.grid_cells):
            cell = self.atlas_manager.grid_cells[self.cell_index]
            cell.style = style_name
            cell._individual_settings = True
    
    def on_animated_changed(self, checked):
        """Handle animated checkbox change."""
        if self.cell_index < len(self.atlas_manager.grid_cells):
            cell = self.atlas_manager.grid_cells[self.cell_index]
            cell.animated = checked
            cell._individual_settings = True
            # Update timer state in the main atlas preview widget
            if hasattr(self.parent(), 'main_preview'):
                self.parent().main_preview.update_timer_state()
    
    def on_block_size_changed(self, value):
        """Handle block size change."""
        if self.cell_index < len(self.atlas_manager.grid_cells):
            cell = self.atlas_manager.grid_cells[self.cell_index]
            cell.block_size = value
            cell._individual_settings = True
    
    def on_ores_changed(self, checked):
        """Handle ores checkbox change."""
        if self.cell_index < len(self.atlas_manager.grid_cells):
            cell = self.atlas_manager.grid_cells[self.cell_index]
            cell.ores = checked
            cell._individual_settings = True
    
    def on_num_ores_changed(self, value):
        """Handle number of ores change."""
        if self.cell_index < len(self.atlas_manager.grid_cells):
            cell = self.atlas_manager.grid_cells[self.cell_index]
            cell.num_ores = value
            cell._individual_settings = True
    
    def pick_color(self, color_type):
        """Open color picker for the specified color type."""
        if self.cell_index >= len(self.atlas_manager.grid_cells):
            return
            
        cell = self.atlas_manager.grid_cells[self.cell_index]
        
        if color_type == 'primary':
            current_color = QColor(cell.primary_color)
            color = QColorDialog.getColor(current_color, self, "Pick Primary Color")
            if color.isValid():
                cell.primary_color = color.name()
                self.primary_color_btn.setStyleSheet(f"background-color: {color.name()}; border: 1px solid #888;")
                cell._individual_settings = True
        elif color_type == 'secondary':
            current_color = QColor(cell.secondary_color)
            color = QColorDialog.getColor(current_color, self, "Pick Secondary Color")
            if color.isValid():
                cell.secondary_color = color.name()
                self.secondary_color_btn.setStyleSheet(f"background-color: {color.name()}; border: 1px solid #888;")
                cell._individual_settings = True
        elif color_type == 'ore':
            current_color = QColor(cell.ore_color)
            color = QColorDialog.getColor(current_color, self, "Pick Ore Color")
            if color.isValid():
                cell.ore_color = color.name()
                self.ore_color_btn.setStyleSheet(f"background-color: {color.name()}; border: 1px solid #888;")
                cell._individual_settings = True
    
    def update_from_cell(self):
        """Update UI from cell data."""
        if self.cell_index >= len(self.atlas_manager.grid_cells):
            return
            
        cell = self.atlas_manager.grid_cells[self.cell_index]
        
        # Update name
        self.name_edit.setText(cell.name)
        
        # Update colors
        self.primary_color_btn.setStyleSheet(f"background-color: {cell.primary_color}; border: 1px solid #888;")
        self.secondary_color_btn.setStyleSheet(f"background-color: {cell.secondary_color}; border: 1px solid #888;")
        self.ore_color_btn.setStyleSheet(f"background-color: {cell.ore_color}; border: 1px solid #888;")
        
        # Handle style mapping for backward compatibility
        style_mapping = {
            'block': 'None',
            'minecraft': 'None', 
            'retro': 'None',
            'Static Block': 'None',
            'Static Minecraft': 'None',
            'Static Retro': 'None',
            'Static Dirt': 'None',
            'Static Stone': 'None',
            'Static Grass': 'None'
        }
        
        display_style = style_mapping.get(cell.style, cell.style)
        index = self.style_combo.findText(display_style)
        if index >= 0:
            self.style_combo.setCurrentIndex(index)
        else:
            # If not found, default to None
            index = self.style_combo.findText('None')
            if index >= 0:
                self.style_combo.setCurrentIndex(index)
        
        self.block_size_spin.setValue(cell.block_size)
        self.animated_check.setChecked(cell.animated)
        self.ores_check.setChecked(cell.ores)
        self.num_ores_spin.setValue(cell.num_ores)
    
    def accept(self):
        """Apply changes and close."""
        if self.cell_index < len(self.atlas_manager.grid_cells):
            cell = self.atlas_manager.grid_cells[self.cell_index]
            cell.name = self.name_edit.text()
            cell._individual_settings = True
        super().accept()

class AtlasOptionsDialog(QDialog):
    """Dialog for atlas-wide options."""
    
    def __init__(self, atlas_manager, parent=None):
        super().__init__(parent)
        self.atlas_manager = atlas_manager
        self.setWindowTitle("Atlas Options")
        self.setModal(True)
        self.setup_ui()
    
    def setup_ui(self):
        """Setup the atlas options UI."""
        layout = QVBoxLayout(self)
        
        # Total Frames
        frames_group = QGroupBox("Animation")
        frames_layout = QFormLayout(frames_group)
        
        self.total_frames_spin = QSpinBox()
        self.total_frames_spin.setRange(1, 32)
        self.total_frames_spin.setValue(self.atlas_manager.num_frames)
        frames_layout.addRow("Total Frames:", self.total_frames_spin)
        
        layout.addWidget(frames_group)
        
        # Grid Size
        grid_group = QGroupBox("Grid Settings")
        grid_layout = QFormLayout(grid_group)
        
        self.grid_size_spin = QSpinBox()
        self.grid_size_spin.setRange(8, 128)
        self.grid_size_spin.setValue(self.atlas_manager.grid_size)
        grid_layout.addRow("Grid Size:", self.grid_size_spin)
        
        layout.addWidget(grid_group)
        
        # Buttons
        button_layout = QHBoxLayout()
        button_layout.addStretch()
        
        ok_btn = QPushButton("OK")
        ok_btn.clicked.connect(self.accept)
        button_layout.addWidget(ok_btn)
        
        cancel_btn = QPushButton("Cancel")
        cancel_btn.clicked.connect(self.reject)
        button_layout.addWidget(cancel_btn)
        
        layout.addLayout(button_layout)
    
    def accept(self):
        """Apply changes and close."""
        self.atlas_manager.num_frames = self.total_frames_spin.value()
        self.atlas_manager.set_grid_size(self.grid_size_spin.value())
        super().accept()

class MainAtlasPreviewWidget(QWidget):
    """Main atlas preview widget with grid management."""
    
    cell_selected = Signal(int)  # Emits cell index when clicked
    cell_double_clicked = Signal(int)  # Emits cell index when double-clicked
    
    def __init__(self, atlas_manager, parent=None):
        super().__init__(parent)
        self.atlas_manager = atlas_manager
        self.selected_cells = set()
        self.setMinimumSize(500, 400)
        self.setMouseTracking(True)
        
        # Update timer for real-time preview
        self.update_timer = QTimer()
        self.update_timer.timeout.connect(self.update)
        # Only start timer if there are animated cells
        self._check_and_start_timer()
    
    def paintEvent(self, event):
        """Paint the atlas preview with grid cells."""
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        
        # Fill background
        painter.fillRect(self.rect(), QColor(50, 50, 50))
        
        if not self.atlas_manager.grid_cells:
            return
        
        # Calculate scale to fit all cells
        max_x = max(cell.x + cell.width for cell in self.atlas_manager.grid_cells)
        max_y = max(cell.y + cell.height for cell in self.atlas_manager.grid_cells)
        
        scale_x = (self.width() - 20) / max_x if max_x > 0 else 1
        scale_y = (self.height() - 20) / max_y if max_y > 0 else 1
        scale = min(scale_x, scale_y, 1.0)  # Don't scale up
        
        # Center the grid
        offset_x = (self.width() - max_x * scale) / 2
        offset_y = (self.height() - max_y * scale) / 2
        
        # Draw each cell
        for i, cell in enumerate(self.atlas_manager.grid_cells):
            # Calculate scaled rectangle
            rect = QRect(
                int(cell.x * scale + offset_x),
                int(cell.y * scale + offset_y),
                int(cell.width * scale),
                int(cell.height * scale)
            )
            
            # Skip drawing for Air cells (invisible)
            if cell.style == 'Air':
                # Just draw border and name
                pass
            else:
                # Generate cell texture - use frame 0 for static cells, animated frame for animated cells
                if cell.animated:
                    # For animated cells, use a frame index that changes over time
                    frame_index = int(time.time() * 10) % max(1, self.atlas_manager.num_frames)
                    texture = self.atlas_manager.generate_cell_texture(i, frame_index)
                else:
                    # For static cells, always use frame 0
                    texture = self.atlas_manager.generate_cell_texture(i, 0)
                if texture:
                    # Scale texture to fit cell
                    scaled_texture = texture.scaled(rect.size(), Qt.KeepAspectRatio, Qt.SmoothTransformation)
                    painter.drawPixmap(rect, QPixmap.fromImage(scaled_texture))
            
            # Draw cell border
            if i in self.selected_cells:
                pen = QPen(QColor(0, 255, 0), 2)
            else:
                pen = QPen(QColor(255, 255, 255), 1)
            painter.setPen(pen)
            painter.drawRect(rect)
            
            # Draw cell name
            painter.setPen(QColor(255, 255, 255))
            painter.drawText(rect, Qt.AlignCenter, cell.name)
            
            # Draw animation indicator for animated cells
            if cell.animated:
                # Draw a small animated indicator in the top-right corner
                indicator_size = min(rect.width(), rect.height()) // 6
                indicator_rect = QRect(
                    rect.right() - indicator_size - 2,
                    rect.top() + 2,
                    indicator_size,
                    indicator_size
                )
                
                # Animate the indicator color
                anim_color = QColor(0, 255, 0, 150 + int(100 * (time.time() * 2) % 1))
                painter.fillRect(indicator_rect, anim_color)
                painter.setPen(QColor(255, 255, 255))
                painter.drawText(indicator_rect, Qt.AlignCenter, "▶")
    
    def mousePressEvent(self, event):
        """Handle mouse clicks for cell selection."""
        if event.button() == Qt.LeftButton:
            cell_index = self._get_cell_at_pos(event.pos())
            if cell_index is not None:
                if event.modifiers() & Qt.ControlModifier:
                    # Multi-select
                    if cell_index in self.selected_cells:
                        self.selected_cells.remove(cell_index)
                    else:
                        self.selected_cells.add(cell_index)
                else:
                    # Single select
                    self.selected_cells.clear()
                    self.selected_cells.add(cell_index)
                    self.cell_selected.emit(cell_index)
                self.update()
    
    def mouseDoubleClickEvent(self, event):
        """Handle double-clicks for cell editing."""
        if event.button() == Qt.LeftButton:
            cell_index = self._get_cell_at_pos(event.pos())
            if cell_index is not None:
                self.cell_double_clicked.emit(cell_index)
    
    def _check_and_start_timer(self):
        """Check if there are animated cells and start/stop timer accordingly."""
        has_animated_cells = any(cell.animated for cell in self.atlas_manager.grid_cells)
        if has_animated_cells:
            if not self.update_timer.isActive():
                self.update_timer.start(100)  # Update every 100ms
        else:
            if self.update_timer.isActive():
                self.update_timer.stop()
    
    def update_timer_state(self):
        """Update timer state when cells are modified."""
        self._check_and_start_timer()
    
    def _get_cell_at_pos(self, pos):
        """Get cell index at the given position."""
        if not self.atlas_manager.grid_cells:
            return None
        
        # Calculate scale to fit all cells
        max_x = max(cell.x + cell.width for cell in self.atlas_manager.grid_cells)
        max_y = max(cell.y + cell.height for cell in self.atlas_manager.grid_cells)
        
        scale_x = (self.width() - 20) / max_x if max_x > 0 else 1
        scale_y = (self.height() - 20) / max_y if max_y > 0 else 1
        scale = min(scale_x, scale_y, 1.0)
        
        # Center the grid
        offset_x = (self.width() - max_x * scale) / 2
        offset_y = (self.height() - max_y * scale) / 2
        
        # Check each cell
        for i, cell in enumerate(self.atlas_manager.grid_cells):
            rect = QRect(
                int(cell.x * scale + offset_x),
                int(cell.y * scale + offset_y),
                int(cell.width * scale),
                int(cell.height * scale)
            )
            if rect.contains(pos):
                return i
        return None

class TextureAtlasDialog(QDialog):
    """Main texture atlas dialog with new layout."""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.main_window = parent
        self.atlas_manager = state.atlas_manager
        self.current_cell_index = -1
        self.has_unsaved_changes = False
        
        self.setWindowTitle("Advanced Texture Atlas Editor")
        self.setModal(False)
        self.resize(1000, 700)
        
        self.setup_ui()
        self.connect_signals()
        self.update_grid_list()
    
    def setup_ui(self):
        """Setup the main UI layout."""
        layout = QVBoxLayout(self)
        
        # Top toolbar
        toolbar = QHBoxLayout()
        
        self.add_grid_btn = QPushButton("Add Grid")
        self.add_grid_btn.clicked.connect(self.add_grid)
        toolbar.addWidget(self.add_grid_btn)
        
        self.delete_grid_btn = QPushButton("Delete Grid")
        self.delete_grid_btn.clicked.connect(self.delete_grid)
        toolbar.addWidget(self.delete_grid_btn)
        
        self.atlas_options_btn = QPushButton("Atlas Options")
        self.atlas_options_btn.clicked.connect(self.open_atlas_options)
        toolbar.addWidget(self.atlas_options_btn)
        
        toolbar.addStretch()
        
        self.save_btn = QPushButton("Save")
        self.save_btn.clicked.connect(self.save_changes)
        toolbar.addWidget(self.save_btn)
        
        self.apply_btn = QPushButton("Apply To Canvas")
        self.apply_btn.clicked.connect(self.apply_atlas_to_layer_and_close)
        toolbar.addWidget(self.apply_btn)
        
        self.ok_btn = QPushButton("OK")
        self.ok_btn.clicked.connect(self.accept)
        toolbar.addWidget(self.ok_btn)
        
        layout.addLayout(toolbar)
        
        # Main content area
        content_splitter = QSplitter(Qt.Horizontal)
        
        # Left side - Main atlas preview
        left_widget = QWidget()
        left_layout = QVBoxLayout(left_widget)
        
        left_layout.addWidget(QLabel("Main Atlas Preview:"))
        
        self.main_preview = MainAtlasPreviewWidget(self.atlas_manager)
        left_layout.addWidget(self.main_preview)
        
        content_splitter.addWidget(left_widget)
        
        # Right side - Grid list only
        right_widget = QWidget()
        right_layout = QVBoxLayout(right_widget)
        
        # Grid list
        right_layout.addWidget(QLabel("Grids (Double-click to edit):"))
        
        self.grid_list = DraggableGridListWidget()
        right_layout.addWidget(self.grid_list)
        
        content_splitter.addWidget(right_widget)
        
        # Set splitter proportions
        content_splitter.setSizes([700, 300])
        
        layout.addWidget(content_splitter)
        
        # Status bar
        self.status_label = QLabel("Ready")
        layout.addWidget(self.status_label)
    
    def connect_signals(self):
        """Connect all signals."""
        self.main_preview.cell_selected.connect(self.on_cell_selected)
        self.main_preview.cell_double_clicked.connect(self.open_grid_settings)
        self.grid_list.grid_reordered.connect(self.on_grid_reordered)
        self.grid_list.grid_double_clicked.connect(self.open_grid_settings)
    
    def update_grid_list(self):
        """Update the grid list widget."""
        self.grid_list.clear()
        for i, cell in enumerate(self.atlas_manager.grid_cells):
            # Add animation indicator to the name
            anim_indicator = " [ANIMATED]" if cell.animated else ""
            item = QListWidgetItem(f"{i+1}. {cell.name}{anim_indicator}")
            self.grid_list.addItem(item)
    
    def on_cell_selected(self, cell_index):
        """Handle cell selection from main preview."""
        self.current_cell_index = cell_index
        self.grid_list.setCurrentRow(cell_index)
    
    def open_grid_settings(self, cell_index):
        """Open grid settings dialog for the specified cell."""
        if cell_index >= len(self.atlas_manager.grid_cells):
            return
            
        dialog = GridSettingsDialog(self.atlas_manager, cell_index, self)
        if dialog.exec() == QDialog.Accepted:
            self.mark_changes_unsaved()
            self.update_grid_list()  # Update list in case name changed
    
    def on_grid_reordered(self, old_index, new_index):
        """Handle grid reordering."""
        if old_index != new_index:
            # Reorder the cells in the atlas manager
            cells = self.atlas_manager.grid_cells
            cell = cells.pop(old_index)
            cells.insert(new_index, cell)
            self.mark_changes_unsaved()
    
    def add_grid(self):
        """Add a new grid."""
        if self.atlas_manager.add_cell():
            self.update_grid_list()
            self.main_preview.update()
            self.main_preview.update_timer_state()  # Update timer state
            self.mark_changes_unsaved()
    
    def delete_grid(self):
        """Delete the currently selected grid."""
        current_row = self.grid_list.currentRow()
        if current_row >= 0:
            self.atlas_manager.remove_cell(current_row)
            self.update_grid_list()
            self.main_preview.update()
            self.main_preview.update_timer_state()  # Update timer state
            self.current_cell_index = -1
            self.mark_changes_unsaved()
    
    def open_atlas_options(self):
        """Open the atlas options dialog."""
        dialog = AtlasOptionsDialog(self.atlas_manager, self)
        if dialog.exec() == QDialog.Accepted:
            self.mark_changes_unsaved()
    
    def mark_changes_unsaved(self):
        """Mark that there are unsaved changes."""
        self.has_unsaved_changes = True
        self.update_window_title()
        self.status_label.setText("Changes made - use 'Save' to save changes or 'Apply To Canvas' to apply to layers")
        self.status_label.setStyleSheet("color: #FFA500; font-style: italic;")
    
    def mark_changes_saved(self):
        """Mark that changes have been saved."""
        self.has_unsaved_changes = False
        self.update_window_title()
        self.status_label.setText("Ready")
        self.status_label.setStyleSheet("")
    
    def update_window_title(self):
        """Update window title to show unsaved changes."""
        base_title = "Advanced Texture Atlas Editor"
        if self.has_unsaved_changes:
            self.setWindowTitle(f"{base_title} *")
        else:
            self.setWindowTitle(base_title)
    
    def closeEvent(self, event):
        """Handle close event with unsaved changes check."""
        if self.has_unsaved_changes:
            reply = QMessageBox.question(
                self, "Unsaved Changes",
                "You have unsaved changes. Do you want to save them before closing?",
                QMessageBox.Save | QMessageBox.Discard | QMessageBox.Cancel
            )
            
            if reply == QMessageBox.Save:
                # Save changes (same as Save button)
                self.save_changes()
                event.accept()
            elif reply == QMessageBox.Discard:
                event.accept()
            else:
                event.ignore()
        else:
            event.accept()
    
    def save_changes(self):
        """Save changes without applying to canvas and keep dialog open."""
        self.mark_changes_saved()
        QMessageBox.information(self, "Saved", "Changes saved successfully!")
    
    def apply_atlas_to_layer_and_close(self):
        """Apply atlas to canvas, save changes, and close dialog."""
        # First save changes
        self.save_changes()
        
        # Then apply to canvas
        self.apply_atlas_to_layer()
        
        # Close the dialog
        super().accept()
    
    def accept(self):
        """Handle OK button click - close dialog without saving."""
        super().accept()
    
    def apply_atlas_to_layer(self):
        """Apply the atlas to the current layer with animation support."""
        if not self.main_window:
            return
            
        # Get layer manager and current layer
        lm = state.layer_manager
        layer = lm.get_current_layer()
        current_frame_idx = lm.current_frame
        
        # Get number of frames from atlas manager
        num_frames = self.atlas_manager.num_frames
        
        # Create new frames if needed
        current_frame_count = len(layer.frames)
        frames_added = 0
        if num_frames > current_frame_count:
            frames_to_add = num_frames - current_frame_count
            for i in range(frames_to_add):
                layer.add_frame(state.width, state.height, state)
                frames_added += 1
        
        # Apply atlas to each frame
        frames_updated = 0
        for frame_idx in range(len(layer.frames)):
            # Only cycle through atlas frames if there are animated cells
            # For static-only atlases, always use frame 0
            has_animated_cells = any(cell.animated for cell in self.atlas_manager.grid_cells)
            if has_animated_cells:
                atlas_frame_idx = frame_idx % num_frames  # Cycle through atlas frames
            else:
                atlas_frame_idx = 0  # Always use frame 0 for static-only atlases
            atlas_image = self.atlas_manager.generate_atlas_image(atlas_frame_idx)
            
            if atlas_image:
                # Convert QImage to numpy array using temporary file
                from PIL import Image
                import tempfile
                import os
                
                with tempfile.NamedTemporaryFile(suffix='.png', delete=False) as tmp_file:
                    atlas_image.save(tmp_file.name, 'PNG')
                    tmp_path = tmp_file.name
                
                try:
                    pil_image = Image.open(tmp_path)
                    arr = np.array(pil_image)
                finally:
                    if os.path.exists(tmp_path):
                        os.unlink(tmp_path)
                
                # Apply to this frame
                frame = layer.get_frame(frame_idx)
                frame.image = arr
                frames_updated += 1
        
        # Refresh UI
        self.main_window.force_canvas_and_preview_refresh()
        
        # Show success message
        message = f"Atlas applied successfully!\n"
        if frames_added > 0:
            message += f"• Created {frames_added} new frame(s)\n"
        message += f"• Updated {frames_updated} frame(s)\n"
        message += f"• Total frames in layer: {len(layer.frames)}"
        
        QMessageBox.information(self, "Atlas Applied", message)
        
        # Update status
        self.status_label.setText(f"Atlas applied to canvas - {frames_updated} frames updated")
        self.status_label.setStyleSheet("color: #4CAF50; font-style: italic;")
        
        # Reset status after 3 seconds
        QTimer.singleShot(3000, lambda: self.status_label.setText("Ready") if not self.has_unsaved_changes else None) 