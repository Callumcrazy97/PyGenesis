from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QLabel, QPushButton, QTabWidget, QWidget, QHBoxLayout,
    QComboBox, QColorDialog, QFormLayout, QDialogButtonBox, QLineEdit, QListWidget, QListWidgetItem, QCheckBox, QInputDialog, QRadioButton, QButtonGroup, QGroupBox, QScrollArea, QSlider, QSpinBox, QTextEdit, QSizePolicy
)
from PySide6.QtGui import QColor, QPixmap, QImage, QPainter, QFont
from PySide6.QtCore import Qt, Signal, QTimer
from core.settings import settings
from core.themes import THEMES
from Core.Debug import debug
import json
import os
import collections
import numpy as np

# Import extracted dialogs
from ui.dialogs.preview_widgets import LeftPanelPreviewWidget, RightPanelPreviewWidget, CheckerboardPreviewWidget
from ui.dialogs.preferences_dialog import PreferencesDialog
from ui.dialogs.new_image_dialog import NewImageDialog
from ui.dialogs.merge_replace_dialog import MergeReplaceDialog
from ui.dialogs.parameter_widgets import (
    ParameterWidget, SliderWidget, DoubleSliderWidget, ColorPickerWidget,
    DropdownWidget, CheckboxWidget, TextBoxWidget, ColorListWidget
)

# Keep constants for backward compatibility
CUSTOM_PRESET_FILE = os.path.expanduser("~/.pixel_editor_custom_theme.json")
LEFT_PANEL_PRESETS_FILE = os.path.expanduser("~/.pixel_editor_left_panel_presets.json")

# Legacy classes - now imported from submodules
# All classes are now imported from their respective modules above
# This file is kept for backward compatibility but will be gradually phased out

# Note: The following classes have been moved to separate modules:
# - LeftPanelPreviewWidget, RightPanelPreviewWidget, CheckerboardPreviewWidget -> ui.dialogs.preview_widgets
# - PreferencesDialog -> ui.dialogs.preferences_dialog
# - NewImageDialog -> ui.dialogs.new_image_dialog
# - MergeReplaceDialog -> ui.dialogs.merge_replace_dialog
# - ParameterWidget and subclasses -> ui.dialogs.parameter_widgets

# All dialogs have been extracted to separate modules:
# - UnifiedEffectDialog, EFFECT_REGISTRY, helper functions -> ui.dialogs.effect_dialog
# - OriginSelectionDialog -> ui.dialogs.origin_dialog

# Import UnifiedEffectDialog and EFFECT_REGISTRY from the extracted module
from ui.dialogs.effect_dialog import UnifiedEffectDialog, EFFECT_REGISTRY
