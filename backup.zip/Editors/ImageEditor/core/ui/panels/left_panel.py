from PySide6.QtWidgets import QFrame, QVBoxLayout, QLabel, QWidget, QPushButton, QHBoxLayout, QColorDialog, QCheckBox, QToolButton, QSizePolicy, QGridLayout, QLineEdit, QSlider, QScrollArea
from PySide6.QtGui import QPainter, QColor, QPen, QBrush
from core.settings import settings
from core.themes import get_theme
from PySide6.QtCore import Qt, QPoint
from ui.tooltips import attach_tooltip
from core.state import state

class BrushPreviewWidget(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedSize(80, 40)
        self.setMinimumSize(80, 40)
        self.setMaximumSize(80, 40)
        
    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        
        # Draw background
        painter.fillRect(self.rect(), QColor(40, 40, 40))
        
        # Draw checkerboard pattern
        checker_size = 4
        for y in range(0, self.height(), checker_size * 2):
            for x in range(0, self.width(), checker_size * 2):
                painter.fillRect(x, y, checker_size, checker_size, QColor(60, 60, 60))
                painter.fillRect(x + checker_size, y + checker_size, checker_size, checker_size, QColor(60, 60, 60))
        
        # Get current tool and radius
        tool = state.current_tool
        radius = state.current_radius
        
        # Calculate center and scale
        center_x = self.width() // 2
        center_y = self.height() // 2
        scale = min(self.width(), self.height()) / 20  # Scale factor for preview
        
        # Draw brush preview based on tool type
        if tool in ['brush', 'pencil', 'marker', 'calligraphy', 'airbrush', 'blur', 'sharpen', 'eraser']:
            # Get current color
            if tool == 'eraser':
                color = QColor(255, 255, 255, 100)  # Semi-transparent white for eraser
            else:
                color = QColor(state.current_left_color)
            
            # Draw brush circle
            if tool == 'calligraphy':
                # Elliptical brush for calligraphy
                painter.setPen(QPen(color, 1))
                painter.setBrush(QBrush(color))
                painter.drawEllipse(center_x - int(radius * scale * 1.2), 
                                  center_y - int(radius * scale * 0.8),
                                  int(radius * scale * 2.4), 
                                  int(radius * scale * 1.6))
            else:
                # Circular brush for other tools
                painter.setPen(QPen(color, 1))
                painter.setBrush(QBrush(color))
                painter.drawEllipse(center_x - int(radius * scale), 
                                  center_y - int(radius * scale),
                                  int(radius * scale * 2), 
                                  int(radius * scale * 2))
            
            # Add tool-specific indicators
            if tool == 'pencil':
                # Add soft edge indicator
                painter.setPen(QPen(QColor(200, 200, 200), 1, Qt.DashLine))
                painter.drawEllipse(center_x - int(radius * scale * 1.2), 
                                  center_y - int(radius * scale * 1.2),
                                  int(radius * scale * 2.4), 
                                  int(radius * scale * 2.4))
            elif tool == 'marker':
                # Add bleed indicator
                painter.setPen(QPen(QColor(150, 150, 150), 1, Qt.DotLine))
                painter.drawEllipse(center_x - int(radius * scale * 1.2), 
                                  center_y - int(radius * scale * 1.2),
                                  int(radius * scale * 2.4), 
                                  int(radius * scale * 2.4))
            elif tool == 'airbrush':
                # Add spray effect indicator
                painter.setPen(QPen(QColor(100, 100, 100), 1))
                for i in range(3):
                    angle = i * 2.094  # 120 degrees
                    x = center_x + int(radius * scale * 0.8 * (i % 2 - 0.5))
                    y = center_y + int(radius * scale * 0.8 * (i % 2 - 0.5))
                    painter.drawPoint(x, y)
            elif tool == 'blur':
                # Add blur effect indicator
                painter.setPen(QPen(QColor(150, 150, 150), 1, Qt.DashLine))
                painter.drawEllipse(center_x - int(radius * scale * 1.1), 
                                  center_y - int(radius * scale * 1.1),
                                  int(radius * scale * 2.2), 
                                  int(radius * scale * 2.2))
            elif tool == 'sharpen':
                # Add sharpen effect indicator
                painter.setPen(QPen(QColor(200, 200, 200), 1, Qt.DotLine))
                painter.drawEllipse(center_x - int(radius * scale * 0.9), 
                                  center_y - int(radius * scale * 0.9),
                                  int(radius * scale * 1.8), 
                                  int(radius * scale * 1.8))
        
        # Draw border
        painter.setPen(QPen(QColor(100, 100, 100), 1))
        painter.drawRect(self.rect().adjusted(0, 0, -1, -1))

class CollapsibleSection(QWidget):
    def __init__(self, title, content_widget, parent=None):
        super().__init__(parent)
        self.toggle_button = QPushButton(title, self)
        self.toggle_button.setCheckable(True)
        self.toggle_button.setChecked(True)
        self.toggle_button.clicked.connect(self.toggle_content)
        self.toggle_button.setStyleSheet('''
            QPushButton {
                font-weight: bold;
                font-size: 15px;
                background: #2e3346;
                color: #fff;
                border: 1px solid #444b6a;
                border-bottom: 2px solid #7aa2f7;
                border-radius: 6px 6px 0 0;
                padding: 8px 12px;
                text-align: left;
            }
            QPushButton:checked {
                background: #414868;
            }
        ''')
        self.content_widget = content_widget
        self.content_widget.setVisible(True)
        self.content_widget.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Minimum)
        self.content_widget.setMaximumHeight(self.content_widget.sizeHint().height())
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)
        layout.addWidget(self.toggle_button)
        layout.addWidget(self.content_widget)
    def toggle_content(self):
        if self.toggle_button.isChecked():
            self.content_widget.setVisible(True)
            self.content_widget.setMaximumHeight(self.content_widget.sizeHint().height())
        else:
            self.content_widget.setVisible(False)
            self.content_widget.setMaximumHeight(0)

class LeftPanel(QFrame):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.full_width = 240
        self.folded_width = 24
        self.canvas = None  # Will be set by main window
        self.setFixedWidth(self.full_width)
        self.setFrameShape(QFrame.StyledPanel)
        self.folded = False
        h_layout = QHBoxLayout(self)
        h_layout.setContentsMargins(0, 0, 0, 0)
        h_layout.setSpacing(0)
        # Main content
        self.content_widget = QWidget(self)
        self.content_layout = QVBoxLayout(self.content_widget)
        self.content_layout.setContentsMargins(0, 0, 0, 0)
        self.content_layout.setSpacing(0)
        self.content_layout.setAlignment(Qt.AlignTop)
        self.sections = {}  # Section name -> CollapsibleSection
        self.section_icons = {}  # Section name -> list of (icon_name, widget)
        # Current Tool header
        tool_content = QWidget(self)
        tool_layout = QVBoxLayout(tool_content)
        self.current_tool_label = QLabel("Name: Brush", self)
        tool_layout.addWidget(self.current_tool_label)
        
        # Brush preview widget
        self.brush_preview = BrushPreviewWidget(self)
        tool_layout.addWidget(self.brush_preview)
        
        radius_row = QHBoxLayout()
        radius_row.setContentsMargins(0, 0, 0, 0)
        radius_row.setSpacing(4)
        radius_label = QLabel("Radius:", self)
        radius_label.setFixedWidth(50)
        radius_row.addWidget(radius_label)
        
        # Custom number input with buttons
        radius_input_container = QWidget()
        radius_input_layout = QHBoxLayout(radius_input_container)
        radius_input_layout.setContentsMargins(0, 0, 0, 0)
        radius_input_layout.setSpacing(2)
        
        self.radius_minus_btn = QPushButton("-", self)
        self.radius_minus_btn.setFixedSize(20, 20)
        self.radius_minus_btn.pressed.connect(self.decrease_radius)
        self.radius_minus_btn.setAutoRepeat(True)
        self.radius_minus_btn.setAutoRepeatDelay(200)
        self.radius_minus_btn.setAutoRepeatInterval(100)
        radius_input_layout.addWidget(self.radius_minus_btn)
        
        self.radius_input = QLineEdit(str(state.current_radius), self)
        self.radius_input.setFixedWidth(40)
        self.radius_input.setAlignment(Qt.AlignCenter)
        self.radius_input.textChanged.connect(self.on_radius_text_changed)
        radius_input_layout.addWidget(self.radius_input)
        
        self.radius_plus_btn = QPushButton("+", self)
        self.radius_plus_btn.setFixedSize(20, 20)
        self.radius_plus_btn.pressed.connect(self.increase_radius)
        self.radius_plus_btn.setAutoRepeat(True)
        self.radius_plus_btn.setAutoRepeatDelay(200)
        self.radius_plus_btn.setAutoRepeatInterval(100)
        radius_input_layout.addWidget(self.radius_plus_btn)
        
        radius_row.addWidget(radius_input_container)
        radius_row.addStretch()
        tool_layout.addLayout(radius_row)

        # Opacity slider
        opacity_row = QHBoxLayout()
        opacity_row.setContentsMargins(0, 0, 0, 0)
        opacity_row.setSpacing(4)
        opacity_label = QLabel("Opacity:", self)
        opacity_label.setFixedWidth(60)
        opacity_row.addWidget(opacity_label)
        self.opacity_slider = QSlider(Qt.Horizontal, self)
        self.opacity_slider.setMinimum(10)
        self.opacity_slider.setMaximum(255)
        self.opacity_slider.setValue(getattr(state, 'current_opacity', 255))
        self.opacity_slider.setFixedWidth(100)
        self.opacity_slider.valueChanged.connect(self.on_opacity_changed)
        opacity_row.addWidget(self.opacity_slider)
        self.opacity_value_label = QLabel(str(self.opacity_slider.value()), self)
        self.opacity_value_label.setFixedWidth(30)
        opacity_row.addWidget(self.opacity_value_label)
        tool_layout.addLayout(opacity_row)

        tool_section = CollapsibleSection("Current Tool", tool_content, self)
        self.sections["Current Tool"] = tool_section
        self.content_layout.addWidget(tool_section)
        self.tool_buttons = {}
        # Brushes section
        brushes_content = QWidget(self)
        brushes_layout = QGridLayout(brushes_content)
        brushes = [
            ("🖌️ Brush", "brush"),
            ("✏️ Pencil", "pencil"),
            ("🖍️ Marker", "marker"),
            ("✒️ Calligraphy", "calligraphy"),
            ("💨 Airbrush", "airbrush"),
            ("🔍 Blur", "blur"),
            ("⚡ Sharpen", "sharpen"),
            ("📏 Line", "line"),
        ]
        self.section_icons["Brushes"] = []
        for i, (label, tool) in enumerate(brushes):
            btn = QToolButton(self)
            btn.setText(label.split()[0])
            btn.setToolTip(label)
            btn.clicked.connect(lambda _, t=tool: self.select_tool(t))
            attach_tooltip(btn, label)
            brushes_layout.addWidget(btn, i // 2, i % 2)
            self.tool_buttons[tool] = btn
            self.section_icons["Brushes"].append((label, btn))
        brushes_section = CollapsibleSection("Brushes", brushes_content, self)
        self.sections["Brushes"] = brushes_section
        self.content_layout.addWidget(brushes_section)
        # Tools section
        tools_content = QWidget(self)
        tools_layout = QGridLayout(tools_content)
        tools = [
            ("🧽 Eraser", "eraser"),
            ("🪣 Fill", "fill"),
            ("🧲 Eyedropper", "eyedropper"),
            ("🖍️ Gradient", "gradient"),
            ("🖍️ Dither", "dither"),
        ]
        self.section_icons["Tools"] = []
        for i, (label, tool) in enumerate(tools):
            btn = QToolButton(self)
            btn.setText(label.split()[0])
            btn.setToolTip(label)
            btn.clicked.connect(lambda _, t=tool: self.select_tool(t))
            attach_tooltip(btn, label)
            tools_layout.addWidget(btn, i // 2, i % 2)
            self.tool_buttons[tool] = btn
            self.section_icons["Tools"].append((label, btn))
        tools_section = CollapsibleSection("Tools", tools_content, self)
        self.sections["Tools"] = tools_section
        self.content_layout.addWidget(tools_section)
        self.shape_buttons = {}
        # Shapes section (with filled/hollow toggle)
        shapes_content = QWidget(self)
        shapes_layout = QGridLayout(shapes_content)
        shapes = [
            ("▭ Rect", "rect"),
            ("◯ Ellipse", "ellipse"),
            ("🔺 Polygon", "polygon"),
            ("⭐ Star", "star"),
        ]
        self.section_icons["Shapes"] = []
        for i, (label, tool) in enumerate(shapes):
            btn = QToolButton(self)
            btn.setText(label.split()[0])
            btn.setToolTip(label)
            btn.clicked.connect(lambda _, t=tool: self.select_shape_tool(t))
            attach_tooltip(btn, label)
            shapes_layout.addWidget(btn, i // 2, i % 2)
            self.shape_buttons[tool] = btn
            self.section_icons["Shapes"].append((label, btn))
        # Filled/hollow toggle
        self.filled_toggle = QPushButton("Filled", self)
        self.filled_toggle.setCheckable(True)
        self.filled_toggle.setChecked(True)
        self.filled_toggle.clicked.connect(self.toggle_filled)
        attach_tooltip(self.filled_toggle, "Toggle filled/hollow shape")
        shapes_layout.addWidget(self.filled_toggle, 2, 0, 1, 2)
        shapes_section = CollapsibleSection("Shapes", shapes_content, self)
        self.sections["Shapes"] = shapes_section
        self.content_layout.addWidget(shapes_section)
        self.selection_buttons = {}
        # Selections section
        selections_content = QWidget(self)
        selections_layout = QGridLayout(selections_content)
        selections = [
            ("⬚", "region"),
            ("🪄", "magic_wand"),
            ("🎨", "spray"),
        ]
        for i, (emoji, tool) in enumerate(selections):
            btn = QToolButton(self)
            btn.setText(emoji)
            btn.setToolTip(tool.replace('_', ' ').title())
            btn.clicked.connect(lambda _, t=tool: self.select_selection_tool(t))
            attach_tooltip(btn, tool.replace('_', ' ').title())
            selections_layout.addWidget(btn, i // 2, i % 2)
            self.selection_buttons[tool] = btn
        selections_section = CollapsibleSection("Selections", selections_content, self)
        self.sections["Selections"] = selections_section
        self.content_layout.addWidget(selections_section)
        # Colour header
        colour_content = QWidget(self)
        colour_layout = QVBoxLayout(colour_content)
        left_btn = QPushButton("Left Colour", self)
        right_btn = QPushButton("Right Colour", self)
        self.left_btn = left_btn
        self.right_btn = right_btn
        self.update_color_buttons()
        left_btn.clicked.connect(self.pick_left_color)
        right_btn.clicked.connect(self.pick_right_color)
        attach_tooltip(left_btn, "Left Colour")
        attach_tooltip(right_btn, "Right Colour")
        colour_layout.addWidget(left_btn)
        colour_layout.addWidget(right_btn)
        
        # Color history
        self.color_history = []
        self.max_history = 8
        self.color_history_widget = QWidget(self)
        self.color_history_layout = QGridLayout(self.color_history_widget)
        self.color_history_layout.setContentsMargins(0, 0, 0, 0)
        self.color_history_layout.setSpacing(2)
        self.color_history_buttons = []
        self.update_color_history()
        colour_layout.addWidget(self.color_history_widget)
        colour_section = CollapsibleSection("Colour", colour_content, self)
        self.sections["Colour"] = colour_section
        self.content_layout.addWidget(colour_section)
        
        # Zoom section
        zoom_content = QWidget(self)
        zoom_layout = QVBoxLayout(zoom_content)
        
        # Zoom controls
        zoom_row = QHBoxLayout()
        zoom_row.setContentsMargins(0, 0, 0, 0)
        zoom_row.setSpacing(4)
        zoom_label = QLabel("Zoom:", self)
        zoom_label.setFixedWidth(50)
        zoom_row.addWidget(zoom_label)
        
        # Custom zoom input with buttons
        zoom_input_container = QWidget()
        zoom_input_layout = QHBoxLayout(zoom_input_container)
        zoom_input_layout.setContentsMargins(0, 0, 0, 0)
        zoom_input_layout.setSpacing(2)
        
        self.zoom_minus_btn = QPushButton("-", self)
        self.zoom_minus_btn.setFixedSize(20, 20)
        self.zoom_minus_btn.pressed.connect(self.zoom_out)
        self.zoom_minus_btn.setAutoRepeat(True)
        self.zoom_minus_btn.setAutoRepeatDelay(200)
        self.zoom_minus_btn.setAutoRepeatInterval(100)
        zoom_input_layout.addWidget(self.zoom_minus_btn)
        
        self.zoom_input = QLineEdit("100%", self)
        self.zoom_input.setFixedWidth(50)
        self.zoom_input.setAlignment(Qt.AlignCenter)
        self.zoom_input.textChanged.connect(self.on_zoom_text_changed)
        zoom_input_layout.addWidget(self.zoom_input)
        
        self.zoom_plus_btn = QPushButton("+", self)
        self.zoom_plus_btn.setFixedSize(20, 20)
        self.zoom_plus_btn.pressed.connect(self.zoom_in)
        self.zoom_plus_btn.setAutoRepeat(True)
        self.zoom_plus_btn.setAutoRepeatDelay(200)
        self.zoom_plus_btn.setAutoRepeatInterval(100)
        zoom_input_layout.addWidget(self.zoom_plus_btn)
        
        zoom_row.addWidget(zoom_input_container)
        zoom_row.addStretch()
        zoom_layout.addLayout(zoom_row)
        
        # Zoom reset button
        zoom_reset_btn = QPushButton("Reset Zoom", self)
        zoom_reset_btn.clicked.connect(self.zoom_reset)
        attach_tooltip(zoom_reset_btn, "Reset zoom to 100%")
        zoom_layout.addWidget(zoom_reset_btn)
        
        zoom_section = CollapsibleSection("Zoom", zoom_content, self)
        self.sections["Zoom"] = zoom_section
        self.content_layout.addWidget(zoom_section)
        
        grid_content = QWidget(self)
        grid_layout = QVBoxLayout(grid_content)
        grid_toggle = QPushButton("Grid Toggle", self)
        grid_toggle.setCheckable(True)
        grid_toggle.setChecked(state.grid_visible)
        grid_toggle.clicked.connect(self.toggle_grid)
        attach_tooltip(grid_toggle, "Toggle grid visibility")
        grid_layout.addWidget(grid_toggle)
        global_toggle = QCheckBox("Global Grid", self)
        attach_tooltip(global_toggle, "Use grid for all layers")
        grid_layout.addWidget(global_toggle)
        global_toggle.setChecked(state.global_grid)
        global_toggle.toggled.connect(self.toggle_global_grid)
        grid_size_row = QHBoxLayout()
        grid_size_row.setContentsMargins(0, 0, 0, 0)
        grid_size_row.setSpacing(4)
        grid_size_label = QLabel("Grid Size:", self)
        grid_size_label.setFixedWidth(70)
        grid_size_row.addWidget(grid_size_label)
        
        # Custom grid size input with buttons
        grid_size_container = QWidget()
        grid_size_input_layout = QHBoxLayout(grid_size_container)
        grid_size_input_layout.setContentsMargins(0, 0, 0, 0)
        grid_size_input_layout.setSpacing(2)
        
        self.grid_size_minus_btn = QPushButton("-", self)
        self.grid_size_minus_btn.setFixedSize(20, 20)
        self.grid_size_minus_btn.pressed.connect(self.decrease_grid_size)
        self.grid_size_minus_btn.setAutoRepeat(True)
        self.grid_size_minus_btn.setAutoRepeatDelay(200)
        self.grid_size_minus_btn.setAutoRepeatInterval(100)
        grid_size_input_layout.addWidget(self.grid_size_minus_btn)
        
        self.grid_size_input = QLineEdit(str(state.grid_size), self)
        self.grid_size_input.setFixedWidth(40)
        self.grid_size_input.setAlignment(Qt.AlignCenter)
        self.grid_size_input.textChanged.connect(self.on_grid_size_text_changed)
        grid_size_input_layout.addWidget(self.grid_size_input)
        
        self.grid_size_plus_btn = QPushButton("+", self)
        self.grid_size_plus_btn.setFixedSize(20, 20)
        self.grid_size_plus_btn.pressed.connect(self.increase_grid_size)
        self.grid_size_plus_btn.setAutoRepeat(True)
        self.grid_size_plus_btn.setAutoRepeatDelay(200)
        self.grid_size_plus_btn.setAutoRepeatInterval(100)
        grid_size_input_layout.addWidget(self.grid_size_plus_btn)
        
        grid_size_row.addWidget(grid_size_container)
        grid_size_row.addStretch()
        grid_layout.addLayout(grid_size_row)
        grid_rot_row = QHBoxLayout()
        grid_rot_row.setContentsMargins(0, 0, 0, 0)
        grid_rot_row.setSpacing(4)
        grid_rot_label = QLabel("Grid Rotation:", self)
        grid_rot_label.setFixedWidth(90)
        grid_rot_row.addWidget(grid_rot_label)
        
        # Custom grid rotation input with buttons
        grid_rot_container = QWidget()
        grid_rot_input_layout = QHBoxLayout(grid_rot_container)
        grid_rot_input_layout.setContentsMargins(0, 0, 0, 0)
        grid_rot_input_layout.setSpacing(2)
        
        self.grid_rot_minus_btn = QPushButton("-", self)
        self.grid_rot_minus_btn.setFixedSize(20, 20)
        self.grid_rot_minus_btn.pressed.connect(self.decrease_grid_rotation)
        self.grid_rot_minus_btn.setAutoRepeat(True)
        self.grid_rot_minus_btn.setAutoRepeatDelay(200)
        self.grid_rot_minus_btn.setAutoRepeatInterval(100)
        grid_rot_input_layout.addWidget(self.grid_rot_minus_btn)
        
        self.grid_rot_input = QLineEdit(str(state.grid_rotation), self)
        self.grid_rot_input.setFixedWidth(40)
        self.grid_rot_input.setAlignment(Qt.AlignCenter)
        self.grid_rot_input.textChanged.connect(self.on_grid_rotation_text_changed)
        grid_rot_input_layout.addWidget(self.grid_rot_input)
        
        self.grid_rot_plus_btn = QPushButton("+", self)
        self.grid_rot_plus_btn.setFixedSize(20, 20)
        self.grid_rot_plus_btn.pressed.connect(self.increase_grid_rotation)
        self.grid_rot_plus_btn.setAutoRepeat(True)
        self.grid_rot_plus_btn.setAutoRepeatDelay(200)
        self.grid_rot_plus_btn.setAutoRepeatInterval(100)
        grid_rot_input_layout.addWidget(self.grid_rot_plus_btn)
        
        grid_rot_row.addWidget(grid_rot_container)
        grid_rot_row.addStretch()
        grid_layout.addLayout(grid_rot_row)
        grid_colour_btn = QPushButton("Grid Colour", self)
        grid_colour_btn.setStyleSheet(f"background: {state.grid_color}; color: #222; border: 1px solid #888;")
        grid_colour_btn.clicked.connect(self.pick_grid_color)
        attach_tooltip(grid_colour_btn, "Grid Colour")
        grid_layout.addWidget(grid_colour_btn)
        snap_toggle = QCheckBox("Snap to Grid", self)
        snap_toggle.setChecked(state.grid_snap)
        snap_toggle.toggled.connect(self.toggle_grid_snap)
        attach_tooltip(snap_toggle, "Snap drawing to grid intersections")
        grid_layout.addWidget(snap_toggle)
        grid_section = CollapsibleSection("Grid", grid_content, self)
        self.sections["Grid"] = grid_section
        self.content_layout.addWidget(grid_section)
        # Wrap content_widget in a scroll area
        scroll_area = QScrollArea(self)
        scroll_area.setWidgetResizable(True)
        scroll_area.setWidget(self.content_widget)
        scroll_area.setMinimumHeight(0)
        scroll_area.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        scroll_area.setFrameShape(QFrame.NoFrame)
        h_layout.addWidget(scroll_area)
        self.fold_btn = QPushButton("⮞", self)
        self.fold_btn.setFixedWidth(self.folded_width)
        self.fold_btn.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Expanding)
        self.fold_btn.clicked.connect(self.toggle_fold)
        attach_tooltip(self.fold_btn, "Fold/Unfold Panel")
        h_layout.addWidget(self.fold_btn)
        self._theme = get_theme(settings.theme)
        self._custom_colors = getattr(settings, 'custom_colors', {})
        self.update_theme(self._theme, self._custom_colors)

    def toggle_filled(self):
        if self.filled_toggle.isChecked():
            self.filled_toggle.setText("Filled")
            state.shape_filled = True
        else:
            self.filled_toggle.setText("Hollow")
            state.shape_filled = False

    def update_theme(self, theme, custom_colors=None):
        custom_colors = custom_colors or {}
        panel_color = custom_colors.get('panel', theme['panel'])
        border_color = custom_colors.get('border', theme['border'])
        self.setStyleSheet(f"background: {panel_color}; border: 1px solid {border_color};")

    def toggle_fold(self):
        if not self.folded:
            self.setFixedWidth(self.folded_width)
            self.content_widget.hide()
            self.fold_btn.setText("⮜")
            self.folded = True
        else:
            self.setFixedWidth(self.full_width)
            self.content_widget.show()
            self.fold_btn.setText("⮞")
            self.folded = False 

    def on_radius_text_changed(self, text):
        try:
            value = int(text)
            if 1 <= value <= 64:
                state.current_radius = value
                self.brush_preview.update()  # Update brush preview
            else:
                # Reset to valid range if out of bounds
                if value < 1:
                    self.radius_input.setText("1")
                    state.current_radius = 1
                elif value > 64:
                    self.radius_input.setText("64")
                    state.current_radius = 64
                self.brush_preview.update()
        except ValueError:
            # Reset to current value if invalid input
            self.radius_input.setText(str(state.current_radius))
    
    def increase_radius(self):
        current = state.current_radius
        if current < 64:
            state.current_radius = current + 1
            self.radius_input.setText(str(state.current_radius))
            self.brush_preview.update()  # Update brush preview
    
    def decrease_radius(self):
        current = state.current_radius
        if current > 1:
            state.current_radius = current - 1
            self.radius_input.setText(str(state.current_radius))
            self.brush_preview.update()  # Update brush preview 

    def update_color_buttons(self):
        self.left_btn.setStyleSheet(f"background: {state.current_left_color}; color: #222; border: 1px solid #888;")
        self.right_btn.setStyleSheet(f"background: {state.current_right_color}; color: #222; border: 1px solid #888;")

    def pick_left_color(self):
        color = QColorDialog.getColor()
        if color.isValid():
            state.set_left_color(color.name())
            self.update_color_buttons()
            self.add_color_to_history(color.name())

    def pick_right_color(self):
        color = QColorDialog.getColor()
        if color.isValid():
            state.set_right_color(color.name())
            self.update_color_buttons()
            self.add_color_to_history(color.name())

    def add_color_to_history(self, color_hex):
        """Add a color to the history, removing duplicates and maintaining max size"""
        if color_hex in self.color_history:
            self.color_history.remove(color_hex)
        self.color_history.insert(0, color_hex)
        if len(self.color_history) > self.max_history:
            self.color_history = self.color_history[:self.max_history]
        self.update_color_history()

    def update_color_history(self):
        """Update the color history buttons"""
        # Clear existing buttons
        for btn in self.color_history_buttons:
            btn.deleteLater()
        self.color_history_buttons.clear()
        
        # Create new buttons
        for i, color_hex in enumerate(self.color_history):
            btn = QPushButton("", self)
            btn.setFixedSize(20, 20)
            btn.setStyleSheet(f"background: {color_hex}; border: 1px solid #888;")
            btn.clicked.connect(lambda _, c=color_hex: self.select_color_from_history(c))
            attach_tooltip(btn, f"Color: {color_hex}")
            self.color_history_layout.addWidget(btn, i // 4, i % 4)
            self.color_history_buttons.append(btn)

    def select_color_from_history(self, color_hex):
        """Select a color from history as the left color"""
        state.current_left_color = color_hex
        self.update_color_buttons()
        self.brush_preview.update()  # Update brush preview 

    def select_tool(self, tool):
        state.set_tool(tool)
        self.update_tool_highlight()
        self.update_current_tool_label()
        self.brush_preview.update()  # Update brush preview

    def update_tool_highlight(self):
        for t, btn in self.tool_buttons.items():
            if t == state.current_tool:
                btn.setStyleSheet("background: #61afef; color: #fff; border: 2px solid #007acc; border-radius: 6px;")
            else:
                btn.setStyleSheet("") 

    def select_shape_tool(self, tool):
        state.set_tool(tool)
        self.update_shape_highlight()
        self.update_tool_highlight()
        self.update_current_tool_label()

    def update_shape_highlight(self):
        for t, btn in self.shape_buttons.items():
            if t == state.current_tool:
                btn.setStyleSheet("background: #61afef; color: #fff; border: 2px solid #007acc; border-radius: 6px;")
            else:
                btn.setStyleSheet("") 

    def select_selection_tool(self, tool):
        state.set_tool(tool)
        self.update_selection_highlight()
        self.update_tool_highlight()
        self.update_current_tool_label()

    def update_selection_highlight(self):
        for t, btn in self.selection_buttons.items():
            if t == state.current_tool:
                btn.setStyleSheet("background: #61afef; color: #fff; border: 2px solid #007acc; border-radius: 6px;")
            else:
                btn.setStyleSheet("") 
    
    def update_current_tool_label(self):
        """Update the current tool name display"""
        tool_names = {
            'brush': 'Brush',
            'pencil': 'Pencil', 
            'eraser': 'Eraser',
            'marker': 'Marker',
            'calligraphy': 'Calligraphy',
            'airbrush': 'Airbrush',
            'line': 'Line',
            'rect': 'Rectangle',
            'ellipse': 'Ellipse',
            'star': 'Star',
            'polygon': 'Polygon',
            'fill': 'Fill',
            'eyedropper': 'Eyedropper',
            'region': 'Region',
            'magic_wand': 'Magic Wand',
            'spray': 'Spray'
        }
        tool_name = tool_names.get(state.current_tool, state.current_tool.title())
        self.current_tool_label.setText(f"Name: {tool_name}")

    def toggle_grid(self, checked):
        state.set_grid_visible(checked)
        # Update canvas immediately - use direct reference if available
        canvas = self.canvas or self._get_canvas()
        if canvas:
            canvas.update()
            canvas.repaint()  # Force immediate repaint
        else:
            # Fallback: find via parent
            parent = self.parent()
            while parent:
                if hasattr(parent, 'force_canvas_and_preview_refresh'):
                    parent.force_canvas_and_preview_refresh()
                    break
                if hasattr(parent, 'canvas'):
                    parent.canvas.update()
                    parent.canvas.repaint()
                    break
                parent = parent.parent()

    def _get_canvas(self):
        """Helper method to find the canvas"""
        parent = self.parent()
        while parent:
            if hasattr(parent, 'canvas'):
                return parent.canvas
            parent = parent.parent()
        return None
    
    def on_grid_size_text_changed(self, text):
        try:
            value = int(text)
            if 1 <= value <= 128:
                state.grid_size = value
                canvas = self._get_canvas()
                if canvas:
                    canvas.update()
            else:
                # Reset to valid range if out of bounds
                if value < 1:
                    self.grid_size_input.setText("1")
                    state.grid_size = 1
                elif value > 128:
                    self.grid_size_input.setText("128")
                    state.grid_size = 128
                canvas = self._get_canvas()
                if canvas:
                    canvas.update()
        except ValueError:
            # Reset to current value if invalid input
            self.grid_size_input.setText(str(state.grid_size))
    
    def increase_grid_size(self):
        current = state.grid_size
        if current < 128:
            state.grid_size = current + 1
            self.grid_size_input.setText(str(state.grid_size))
            canvas = self._get_canvas()
            if canvas:
                canvas.update()
    
    def decrease_grid_size(self):
        current = state.grid_size
        if current > 1:
            state.grid_size = current - 1
            self.grid_size_input.setText(str(state.grid_size))
            canvas = self._get_canvas()
            if canvas:
                canvas.update()
    
    def on_grid_rotation_text_changed(self, text):
        try:
            value = int(text)
            if 0 <= value <= 359:
                state.grid_rotation = value
                canvas = self._get_canvas()
                if canvas:
                    canvas.update()
            else:
                # Reset to valid range if out of bounds
                if value < 0:
                    self.grid_rot_input.setText("0")
                    state.grid_rotation = 0
                elif value > 359:
                    self.grid_rot_input.setText("359")
                    state.grid_rotation = 359
                canvas = self._get_canvas()
                if canvas:
                    canvas.update()
        except ValueError:
            # Reset to current value if invalid input
            self.grid_rot_input.setText(str(state.grid_rotation))
    
    def increase_grid_rotation(self):
        current = state.grid_rotation
        if current < 359:
            state.grid_rotation = current + 1
            self.grid_rot_input.setText(str(state.grid_rotation))
            canvas = self._get_canvas()
            if canvas:
                canvas.update()
    
    def decrease_grid_rotation(self):
        current = state.grid_rotation
        if current > 0:
            state.grid_rotation = current - 1
            self.grid_rot_input.setText(str(state.grid_rotation))
            canvas = self._get_canvas()
            if canvas:
                canvas.update()

    def pick_grid_color(self):
        color = QColorDialog.getColor()
        if color.isValid():
            state.set_grid_color(color.name())
            # Find the main window to get canvas
            parent = self.parent()
            while parent:
                if hasattr(parent, 'canvas'):
                    parent.canvas.update()
                    break
                parent = parent.parent() 

    def toggle_grid_snap(self, checked):
        state.set_grid_snap(checked)

    def toggle_global_grid(self, checked):
        state.global_grid = checked
        # Find the main window to get canvas
        parent = self.parent()
        while parent:
            if hasattr(parent, 'force_canvas_and_preview_refresh'):
                parent.force_canvas_and_preview_refresh()
                break
            elif hasattr(parent, 'canvas'):
                parent.canvas.update()
                break
            parent = parent.parent()

    def zoom_in(self):
        """Zoom in the canvas"""
        canvas = self._get_canvas()
        if canvas:
            canvas.zoom_in()
            self.zoom_input.setText(f"{int(canvas.zoom_level * 100)}%")

    def zoom_out(self):
        """Zoom out the canvas"""
        canvas = self._get_canvas()
        if canvas:
            canvas.zoom_out()
            self.zoom_input.setText(f"{int(canvas.zoom_level * 100)}%")

    def zoom_reset(self):
        """Reset zoom to 100%"""
        canvas = self._get_canvas()
        if canvas:
            canvas.zoom_reset()
            self.zoom_input.setText("100%")

    def on_zoom_text_changed(self, text):
        """Handle manual zoom input"""
        try:
            # Remove % sign and convert to float
            zoom_text = text.replace('%', '').strip()
            zoom_value = float(zoom_text) / 100.0
            canvas = self._get_canvas()
            if canvas and 0.1 <= zoom_value <= 10.0:
                canvas.zoom_level = zoom_value
                canvas.pan_offset = QPoint(0, 0)  # Reset pan when manually setting zoom
                canvas.update()
                # Update status bar zoom display
                if hasattr(self.parent(), 'zoom_status'):
                    self.parent().zoom_status.setText(f"Zoom: {int(zoom_value * 100)}%")
            else:
                # Reset to valid range if out of bounds
                if zoom_value < 0.1:
                    self.zoom_input.setText("10%")
                    if canvas:
                        canvas.zoom_level = 0.1
                        canvas.update()
                elif zoom_value > 10.0:
                    self.zoom_input.setText("1000%")
                    if canvas:
                        canvas.zoom_level = 10.0
                        canvas.update()
        except ValueError:
            # Reset to current zoom if invalid input
            canvas = self._get_canvas()
            if canvas:
                self.zoom_input.setText(f"{int(canvas.zoom_level * 100)}%")
        self.parent().canvas.update() 

    def on_opacity_changed(self, value):
        state.current_opacity = value
        self.opacity_value_label.setText(str(value))
        # Update brush preview to reflect new opacity
        self.brush_preview.update() 

    def apply_section_layout(self, section_names):
        # Remove all sections from layout
        for section in self.sections.values():
            self.content_layout.removeWidget(section)
            section.setParent(None)
        # Add only those in section_names, in order
        for name in section_names:
            section = self.sections.get(name)
            if section:
                self.content_layout.addWidget(section) 

    def apply_icon_layout(self, section, icon_layout):
        # icon_layout: list of (icon_name, checked)
        if section not in self.section_icons:
            return
        icon_widgets = dict(self.section_icons[section])
        # Hide all first
        for _, btn in self.section_icons[section]:
            btn.hide()
        # Re-add in order and show/hide
        parent_layout = self.sections[section].content_widget.layout()
        # Remove all widgets from layout
        for i in reversed(range(parent_layout.count())):
            item = parent_layout.itemAt(i)
            w = item.widget()
            if w:
                parent_layout.removeWidget(w)
        # Add in new order
        for icon_name, checked in icon_layout:
            btn = icon_widgets.get(icon_name)
            if btn:
                parent_layout.addWidget(btn)
                if checked:
                    btn.show()
                else:
                    btn.hide() 

    def wheelEvent(self, event):
        if self.rect().contains(event.position().toPoint()):
            return super().wheelEvent(event) 