from PySide6.QtWidgets import QFrame, QVBoxLayout, QLabel, QPushButton, QWidget, QHBoxLayout, QInputDialog, QSizePolicy, QLineEdit, QSlider, QScrollArea, QTabWidget, QColorDialog, QCheckBox, QHBoxLayout, QLabel
from core.settings import settings
from core.themes import get_theme
from core.state import state
from PySide6.QtCore import Qt
from ui.preview import PreviewBox
from ui.tooltips import attach_tooltip

# If CollapsibleSection is not defined here, import it from left_panel.py
# from ui.panels.left_panel import CollapsibleSection

# If defined here, update as follows:
class CollapsibleSection(QWidget):
    def __init__(self, title, content_widget, parent=None, subtab=False):
        super().__init__(parent)
        self.toggle_button = QPushButton(title, self)
        self.toggle_button.setCheckable(True)
        self.toggle_button.setChecked(True)
        self.toggle_button.clicked.connect(self.toggle_content)
        if subtab:
            self.toggle_button.setStyleSheet('''
                QPushButton {
                    font-weight: normal;
                    font-size: 12px;
                    background: #35394a;
                    color: #e0e0e0;
                    border: 1px solid #444b6a;
                    border-radius: 4px 4px 0 0;
                    padding: 4px 8px;
                    text-align: left;
                }
                QPushButton:checked {
                    background: #414868;
                }
            ''')
        else:
            self.toggle_button.setStyleSheet('''
                QPushButton {
                    font-weight: bold;
                    font-size: 15px;
                    background: #2e3346;
                    color: #fff;
                    border: 1px solid #444b6a;
                    border-bottom: 2px solid #7aa2f7;
                    border-radius: 6px 6px 0 0;
                    padding: 8px 12px;
                    text-align: left;
                }
                QPushButton:checked {
                    background: #414868;
                }
            ''')
        self.content_widget = content_widget
        self.content_widget.setVisible(True)
        self.content_widget.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Minimum)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)
        layout.addWidget(self.toggle_button)
        layout.addWidget(self.content_widget)
    def toggle_content(self):
        if self.toggle_button.isChecked():
            self.content_widget.setVisible(True)
        else:
            self.content_widget.setVisible(False)

class LayerTab(QPushButton):
    def __init__(self, layer, index, is_selected, highlight_color, parent=None):
        super().__init__(layer.name, parent)
        self.layer = layer
        self.index = index
        self.is_selected = is_selected
        self.highlight_color = highlight_color
        self.setFixedHeight(32)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        self.setCheckable(True)
        self.setChecked(is_selected)
        self.setCursor(Qt.PointingHandCursor)
        self.update_style()
        self.clicked.connect(self.on_clicked)
        self.setContextMenuPolicy(Qt.CustomContextMenu)
        self.customContextMenuRequested.connect(self.show_context_menu)

    def update_style(self):
        if self.is_selected:
            self.setStyleSheet(f"border: 2px solid {self.highlight_color}; border-radius: 6px; background: #444;")
        else:
            self.setStyleSheet("border: none; background: #222;")

    def set_selected(self, selected):
        self.is_selected = selected
        self.setChecked(selected)
        self.update_style()

    def on_clicked(self):
        self.parent().select_layer(self.index)

    def mouseDoubleClickEvent(self, event):
        if event.button() == Qt.LeftButton:
            self.parent().switch_to_layer(self.index)
        super().mouseDoubleClickEvent(event)

    def show_context_menu(self, pos):
        from PySide6.QtWidgets import QMenu, QInputDialog
        menu = QMenu(self)
        vis_action = menu.addAction("Hide" if self.layer.visible else "Show")
        del_action = menu.addAction("Delete")
        add_action = menu.addAction("Add Layer")
        rename_action = menu.addAction("Rename")
        depth_action = menu.addAction("Set Depth...")
        action = menu.exec_(self.mapToGlobal(pos))
        if action == vis_action:
            self.layer.visible = not self.layer.visible
            self.parent().update_tabs()
            self.parent().canvas.update()
        elif action == del_action:
            self.parent().delete_layer(self.index)
        elif action == add_action:
            self.parent().add_layer()
        elif action == rename_action:
            self.parent().rename_layer(self.index)
        elif action == depth_action:
            lm = state.layer_manager
            max_depth = len(lm.layers) - 1
            new_depth, ok = QInputDialog.getInt(self, "Set Layer Depth", f"Depth (0=Back, {max_depth}=Front):", value=self.index, min=0, max=max_depth)
            if ok and new_depth != self.index:
                layer = lm.layers.pop(self.index)
                lm.layers.insert(new_depth, layer)
                self.parent().selected_index = new_depth
                state.layer_manager.current_layer = new_depth
                self.parent().update_tabs()
                self.parent().canvas.update()

class LayersList(QWidget):
    def __init__(self, highlight_color, canvas, parent=None):
        super().__init__(parent)
        self.highlight_color = highlight_color
        self.canvas = canvas
        self.layout = QVBoxLayout(self)
        self.layout.setContentsMargins(0, 0, 0, 0)
        self.layout.setSpacing(4)
        btn_row = QHBoxLayout()
        self.add_btn = QPushButton("Add")
        self.add_btn.clicked.connect(self.add_layer)
        self.delete_btn = QPushButton("Delete")
        self.delete_btn.clicked.connect(self.delete_selected_layer)
        self.rename_btn = QPushButton("Rename")
        self.rename_btn.clicked.connect(self.rename_selected_layer)
        self.vis_btn = QPushButton("Hide")
        self.vis_btn.clicked.connect(self.toggle_visibility_selected_layer)
        self.depth_btn = QPushButton("Depth")
        self.depth_btn.clicked.connect(self.set_selected_layer_depth_dialog)
        btn_row.addWidget(self.add_btn)
        btn_row.addWidget(self.delete_btn)
        btn_row.addWidget(self.rename_btn)
        btn_row.addWidget(self.vis_btn)
        btn_row.addWidget(self.depth_btn)
        self.layout.addLayout(btn_row)
        self.tabs = []
        self.selected_index = state.layer_manager.current_layer
        self.update_tabs()

    def update_tabs(self):
        for tab in self.tabs:
            self.layout.removeWidget(tab)
            tab.deleteLater()
        self.tabs = []
        lm = state.layer_manager
        if self.selected_index >= len(lm.layers):
            self.selected_index = len(lm.layers) - 1
        for i, layer in enumerate(lm.layers):
            tab = LayerTab(layer, i, i == self.selected_index, self.highlight_color, self)
            self.layout.addWidget(tab, alignment=Qt.AlignTop)
            self.tabs.append(tab)
        self.delete_btn.setEnabled(len(lm.layers) > 1)
        self.vis_btn.setText("Hide" if lm.layers[self.selected_index].visible else "Show")

    def select_layer(self, index):
        self.selected_index = index
        state.layer_manager.current_layer = index
        self.update_tabs()
        # Always call parent RightPanel's refresh after selection change
        parent = self.parent()
        while parent and not hasattr(parent, 'force_canvas_and_preview_refresh'):
            parent = parent.parent()
        if parent and hasattr(parent, 'force_canvas_and_preview_refresh'):
            parent.force_canvas_and_preview_refresh()

    def switch_to_layer(self, index):
        self.select_layer(index)

    def delete_selected_layer(self):
        self.delete_layer(self.selected_index)

    def delete_layer(self, index):
        lm = state.layer_manager
        if len(lm.layers) > 1:
            del lm.layers[index]
            if self.selected_index >= len(lm.layers):
                self.selected_index = len(lm.layers) - 1
            state.layer_manager.current_layer = self.selected_index
            self.update_tabs()
            parent = self.parent()
            while parent and not hasattr(parent, 'force_canvas_and_preview_refresh'):
                parent = parent.parent()
            if parent and hasattr(parent, 'force_canvas_and_preview_refresh'):
                parent.force_canvas_and_preview_refresh()

    def add_layer(self):
        state.layer_manager.add_layer()
        self.selected_index = len(state.layer_manager.layers) - 1
        state.layer_manager.current_layer = self.selected_index
        self.update_tabs()
        parent = self.parent()
        while parent and not hasattr(parent, 'force_canvas_and_preview_refresh'):
            parent = parent.parent()
        if parent and hasattr(parent, 'force_canvas_and_preview_refresh'):
            parent.force_canvas_and_preview_refresh()

    def rename_selected_layer(self):
        self.rename_layer(self.selected_index)

    def rename_layer(self, index):
        lm = state.layer_manager
        layer = lm.layers[index]
        new_name, ok = QInputDialog.getText(self, "Rename Layer", "Layer name:", text=layer.name)
        if ok and new_name:
            layer.name = new_name
            self.update_tabs()

    def toggle_visibility_selected_layer(self):
        lm = state.layer_manager
        layer = lm.layers[self.selected_index]
        layer.visible = not layer.visible
        self.update_tabs()
        parent = self.parent()
        while parent and not hasattr(parent, 'force_canvas_and_preview_refresh'):
            parent = parent.parent()
        if parent and hasattr(parent, 'force_canvas_and_preview_refresh'):
            parent.force_canvas_and_preview_refresh()

    def set_highlight_color(self, color):
        self.highlight_color = color
        self.update_tabs()

    def set_selected_layer_depth_dialog(self):
        lm = state.layer_manager
        idx = self.selected_index
        layer = lm.layers[idx]
        new_depth, ok = QInputDialog.getInt(self, "Set Layer Depth", "Depth (any integer, lower=back, higher=front):", value=layer.depth)
        if ok and new_depth != layer.depth:
            layer.depth = new_depth
            lm.sort_layers()
            # After sorting, update selected_index to the new position of this layer
            for i, lyr in enumerate(lm.layers):
                if lyr is layer:
                    self.selected_index = i
                    state.layer_manager.current_layer = i
                    self.update_tabs()
                    parent = self.parent()
                    while parent and not hasattr(parent, 'force_canvas_and_preview_refresh'):
                        parent = parent.parent()
                    if parent and hasattr(parent, 'force_canvas_and_preview_refresh'):
                        parent.force_canvas_and_preview_refresh()
                    break

class RightPanel(QFrame):
    def __init__(self, parent=None, canvas=None, app=None):
        super().__init__(parent)
        self.app = app
        self._theme = get_theme(settings.theme)
        self._custom_colors = getattr(settings, 'custom_colors', {})
        self.full_width = 260
        self.folded_width = 24
        self.setFixedWidth(self.full_width)
        self.setFrameShape(QFrame.StyledPanel)
        self.folded = False
        self.is_playing = False
        self.play_timer = None
        self.canvas = canvas
        self.sections = {} # Dictionary to store CollapsibleSection instances
        h_layout = QHBoxLayout(self)
        h_layout.setContentsMargins(0, 0, 0, 0)
        h_layout.setSpacing(0)
        self.fold_btn = QPushButton("⮞", self)
        self.fold_btn.setFixedWidth(self.folded_width)
        self.fold_btn.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Expanding)
        self.fold_btn.clicked.connect(self.toggle_fold)
        attach_tooltip(self.fold_btn, "Fold/Unfold Panel")
        h_layout.addWidget(self.fold_btn)
        self.content_widget = QWidget(self)
        self.content_layout = QVBoxLayout(self.content_widget)
        self.content_layout.setContentsMargins(8, 8, 8, 8)
        self.content_layout.setSpacing(4)
        self.content_layout.setAlignment(Qt.AlignTop)
        
        # --- Frames Section (merged Preview + Frames) ---
        frames_content = QWidget(self)
        frames_layout = QVBoxLayout(frames_content)
        # Preview box
        self.preview_box = PreviewBox(self)
        frames_layout.addWidget(self.preview_box)
        
        # Connect canvas to preview box for updates
        if self.canvas:
            self.canvas.set_preview_box(self.preview_box)
        # Play/Pause, frame number, speed controls
        play_row = QHBoxLayout()
        self.play_btn = QPushButton('Play', self)
        self.play_btn.setCheckable(True)
        self.play_btn.clicked.connect(self.toggle_play)
        play_row.addWidget(self.play_btn)
        self.frame_label = QLabel('Frame: 1', self)
        play_row.addWidget(self.frame_label)
        self.speed_label = QLabel('Speed:', self)
        play_row.addWidget(self.speed_label)
        self.speed_slider = QSlider(Qt.Horizontal, self)
        self.speed_slider.setMinimum(1)
        self.speed_slider.setMaximum(60)
        
        # Get default FPS from preferences
        default_fps = 5  # Default fallback
        if self.app and hasattr(self.app, 'settings'):
            default_fps = self.app.settings.get("Default_Sprite_FPS", 5)
        
        self.speed_slider.setValue(default_fps)
        self.speed_slider.setMaximumWidth(100)
        self.speed_slider.valueChanged.connect(self.on_speed_slider_changed)
        self.speed_value_label = QLabel(str(self.speed_slider.value()), self)
        play_row.addWidget(self.speed_slider)
        play_row.addWidget(self.speed_value_label)
        frames_layout.addLayout(play_row)
        # Frame controls row
        frame_ctrl_row = QHBoxLayout()
        self.prev_frame_btn = QPushButton('<<', self)  # Previous frame - clear text
        self.next_frame_btn = QPushButton('>>', self)  # Next frame - clear text
        self.add_frame_btn = QPushButton('+', self)   # Add frame - plus sign
        self.delete_frame_btn = QPushButton('X', self)  # Delete frame - X symbol
        self.copy_frame_btn = QPushButton('C', self)  # Copy frame - C for copy
        self.toggle_timeline_btn = QPushButton('T', self)  # Timeline - T for timeline
        self.prev_frame_btn.clicked.connect(self.prev_frame)
        self.next_frame_btn.clicked.connect(self.next_frame)
        self.add_frame_btn.clicked.connect(self.add_frame)
        self.delete_frame_btn.clicked.connect(self.delete_frame)
        self.copy_frame_btn.clicked.connect(self.copy_frame)
        self.toggle_timeline_btn.clicked.connect(self._toggle_timeline)
        
        # Add tooltips for clarity
        attach_tooltip(self.prev_frame_btn, "Previous Frame")
        attach_tooltip(self.next_frame_btn, "Next Frame")
        attach_tooltip(self.add_frame_btn, "Add New Frame")
        attach_tooltip(self.delete_frame_btn, "Delete Current Frame")
        attach_tooltip(self.copy_frame_btn, "Copy Current Frame")
        attach_tooltip(self.toggle_timeline_btn, "Toggle Timeline View")
        frame_ctrl_row.addWidget(self.prev_frame_btn)
        frame_ctrl_row.addWidget(self.next_frame_btn)
        frame_ctrl_row.addWidget(self.add_frame_btn)
        frame_ctrl_row.addWidget(self.delete_frame_btn)
        frame_ctrl_row.addWidget(self.copy_frame_btn)
        frame_ctrl_row.addWidget(self.toggle_timeline_btn)
        frames_layout.addLayout(frame_ctrl_row)
        frames_section = CollapsibleSection('Frames', frames_content, self)
        frames_section.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Minimum)
        frames_content.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Minimum)
        # Ensure Frames section is expanded by default to show preview box
        frames_section.toggle_button.setChecked(True)
        frames_content.setVisible(True)
        self.sections['Frames'] = frames_section
        self.content_layout.addWidget(frames_section)

        # --- Restore Layers Section ---
        layers_content = QWidget(self)
        layers_layout = QVBoxLayout(layers_content)
        self.layers_list = LayersList(self.get_highlight_color(), self.canvas, layers_content)
        # Patch add_layer, delete_layer, and rename_layer to refresh onion skin UI
        orig_add_layer = self.layers_list.add_layer
        orig_delete_layer = self.layers_list.delete_layer
        orig_rename_layer = self.layers_list.rename_layer
        def add_layer_and_refresh(*args, **kwargs):
            result = orig_add_layer(*args, **kwargs)
            self._update_current_layer_controls()
            self._refresh_other_layers_section(onion_skin_content, onion_skin_layout)
            self._refresh_timeline()
            return result
        def delete_layer_and_refresh(*args, **kwargs):
            result = orig_delete_layer(*args, **kwargs)
            self._update_current_layer_controls()
            self._refresh_other_layers_section(onion_skin_content, onion_skin_layout)
            self._refresh_timeline()
            return result
        def rename_layer_and_refresh(*args, **kwargs):
            result = orig_rename_layer(*args, **kwargs)
            self._refresh_other_layers_section(onion_skin_content, onion_skin_layout)
            self._refresh_timeline()
            return result
        self.layers_list.add_layer = add_layer_and_refresh
        self.layers_list.delete_layer = delete_layer_and_refresh
        self.layers_list.rename_layer = rename_layer_and_refresh
        scroll_area = QScrollArea(layers_content)
        scroll_area.setWidgetResizable(True)
        scroll_area.setWidget(self.layers_list)
        scroll_area.setMaximumHeight(400)
        scroll_area.setFrameShape(QFrame.NoFrame)
        scroll_area.setMinimumHeight(0)
        scroll_area.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Minimum)
        # Dynamically set minimum height to fit content, but never more than max
        def update_scroll_area_height():
            from core.state import state
            n_layers = len(state.layer_manager.layers)
            min_height = min(400, max(0, n_layers * 36 + 8))  # 32px per button + 4px spacing + 8px padding
            scroll_area.setMinimumHeight(min_height)
        update_scroll_area_height()
        # Also update when layers change
        self.layers_list.update_tabs = lambda orig=self.layers_list.update_tabs: (orig(), update_scroll_area_height())
        layers_layout.addWidget(scroll_area)
        layers_section = CollapsibleSection("Layers", layers_content, self)
        layers_section.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Minimum)
        layers_content.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Minimum)
        self.sections["Layers"] = layers_section
        self.content_layout.addWidget(layers_section)

        # --- Onion Skin Section ---
        onion_skin_content = QWidget(self)
        onion_skin_content.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Minimum)
        onion_skin_layout = QVBoxLayout(onion_skin_content)
        onion_skin_layout.setContentsMargins(0, 0, 0, 0)
        onion_skin_layout.setSpacing(4)
        # Master visibility toggle
        self.onion_skin_master_toggle = QCheckBox("Enable Onion Skin", onion_skin_content)
        self.onion_skin_master_toggle.setChecked(True)
        self.onion_skin_master_toggle.stateChanged.connect(self.canvas.update)
        onion_skin_layout.addWidget(self.onion_skin_master_toggle)

        # --- Current Layer CollapsibleSection (as sub-tab INSIDE Onion Skin) ---
        current_layer_content = QWidget(onion_skin_content)
        current_layer_layout = QVBoxLayout(current_layer_content)
        current_layer_layout.setContentsMargins(2, 2, 2, 2)
        current_layer_layout.setSpacing(2)
        # Previous Frame controls
        self.prev_row = QHBoxLayout()
        self.prev_row.setContentsMargins(0, 0, 0, 0)
        self.prev_row.setSpacing(2)
        self.prev_visible = QCheckBox("Prev Frame", current_layer_content)
        self.prev_color_btn = QPushButton("Color", current_layer_content)
        self.prev_color_btn.clicked.connect(lambda: self._pick_onion_color(self.prev_color_btn))
        self.prev_opacity_slider = QSlider(Qt.Horizontal, current_layer_content)
        self.prev_opacity_slider.setMinimum(0)
        self.prev_opacity_slider.setMaximum(255)
        self.prev_row.addWidget(self.prev_visible)
        self.prev_row.addWidget(self.prev_color_btn)
        self.prev_row.addWidget(QLabel("Opacity:"))
        self.prev_row.addWidget(self.prev_opacity_slider)
        current_layer_layout.addLayout(self.prev_row)
        # Next Frame controls
        self.next_row = QHBoxLayout()
        self.next_row.setContentsMargins(0, 0, 0, 0)
        self.next_row.setSpacing(2)
        self.next_visible = QCheckBox("Next Frame", current_layer_content)
        self.next_color_btn = QPushButton("Color", current_layer_content)
        self.next_color_btn.clicked.connect(lambda: self._pick_onion_color(self.next_color_btn))
        self.next_opacity_slider = QSlider(Qt.Horizontal, current_layer_content)
        self.next_opacity_slider.setMinimum(0)
        self.next_opacity_slider.setMaximum(255)
        self.next_row.addWidget(self.next_visible)
        self.next_row.addWidget(self.next_color_btn)
        self.next_row.addWidget(QLabel("Opacity:"))
        self.next_row.addWidget(self.next_opacity_slider)
        current_layer_layout.addLayout(self.next_row)
        current_layer_content.setLayout(current_layer_layout)
        self.current_layer_section = CollapsibleSection("Current Layer", current_layer_content, onion_skin_content, subtab=True)
        self.current_layer_section.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Minimum)
        onion_skin_layout.addWidget(self.current_layer_section)

        # --- Other Layers CollapsibleSection (as sub-tab INSIDE Onion Skin) ---
        self.other_layers_sections = []
        self._refresh_other_layers_section(onion_skin_content, onion_skin_layout)

        # Onion Skin is a single main section
        onion_skin_section = CollapsibleSection("Onion Skin", onion_skin_content, self)
        onion_skin_section.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Minimum)
        onion_skin_content.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Minimum)
        self.sections["Onion Skin"] = onion_skin_section
        self.content_layout.addWidget(onion_skin_section)
        self.content_layout.setAlignment(Qt.AlignTop)
        self.content_widget.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        h_layout.addWidget(self.content_widget)
        # Connect to layer selection changes
        self._connect_layer_selection()
        self._update_current_layer_controls()

    def update_theme(self, theme, custom_colors=None):
        custom_colors = custom_colors or {}
        panel_color = custom_colors.get('panel', theme['panel'])
        border_color = custom_colors.get('border', theme['border'])
        self.setStyleSheet(f"background: {panel_color}; border: 1px solid {border_color};")
        if hasattr(self, 'layers_list'):
            self.layers_list.set_highlight_color(self.get_highlight_color())
    def get_highlight_color(self):
        return settings.custom_colors.get('selection_outline', self._theme.get('accent', '#61afef'))
    def toggle_fold(self):
        if not self.folded:
            self.setFixedWidth(self.folded_width)
            self.content_widget.hide()
            self.fold_btn.setText("⮜")
            self.folded = True
        else:
            self.setFixedWidth(self.full_width)
            self.content_widget.show()
            self.fold_btn.setText("⮞")
            self.folded = False 

    def update_frame_label(self):
        lm = state.layer_manager
        total = len(lm.layers[0].frames) if lm.layers else 1
        idx = lm.current_frame + 1
        self.frame_label.setText(f"Frame: {idx}")
        self.preview_box.update()

    def _clear_canvas_overlays(self):
        if self.canvas:
            # Clear overlays and selection state
            state.selection_manager.clear_selection()
            self.canvas.selecting = False
            self.canvas.lasso_selecting = False
            self.canvas.lasso_points = []
            self.canvas.line_preview = False
            self.canvas.shape_preview = False
            self.canvas.drawing = False
            self.canvas.last_pos = None
            self.canvas.magic_wand_mask = None

    def force_canvas_and_preview_refresh(self):
        if self.canvas:
            self.canvas.force_layer_frame_switch()
            self.canvas.update()
            self.canvas._update_preview_box()
        if hasattr(self, 'preview_box') and self.preview_box:
            self.preview_box.update()

    def add_frame(self):
        state.layer_manager.add_frame()
        self.update_frame_label()
        self._clear_canvas_overlays()
        self.layers_list.update_tabs()
        self._refresh_timeline()
        parent = self.parent()
        while parent and not hasattr(parent, 'force_canvas_and_preview_refresh'):
            parent = parent.parent()
        if parent and hasattr(parent, 'force_canvas_and_preview_refresh'):
            parent.force_canvas_and_preview_refresh()

    def delete_frame(self):
        lm = state.layer_manager
        if lm.layers and len(lm.layers[0].frames) > 1:
            for layer in lm.layers:
                del layer.frames[lm.current_frame]
            if lm.current_frame >= len(lm.layers[0].frames):
                lm.current_frame = len(lm.layers[0].frames) - 1
            self.update_frame_label()
            self._clear_canvas_overlays()
            self.layers_list.update_tabs()
            self._refresh_timeline()
            parent = self.parent()
            while parent and not hasattr(parent, 'force_canvas_and_preview_refresh'):
                parent = parent.parent()
            if parent and hasattr(parent, 'force_canvas_and_preview_refresh'):
                parent.force_canvas_and_preview_refresh()

    def copy_frame(self):
        lm = state.layer_manager
        for layer in lm.layers:
            frame = layer.get_frame(lm.current_frame)
            import copy
            new_frame = copy.deepcopy(frame)
            layer.frames.insert(lm.current_frame + 1, new_frame)
        self.update_frame_label()
        self._clear_canvas_overlays()
        self.layers_list.update_tabs()
        self._refresh_timeline()
        parent = self.parent()
        while parent and not hasattr(parent, 'force_canvas_and_preview_refresh'):
            parent = parent.parent()
        if parent and hasattr(parent, 'force_canvas_and_preview_refresh'):
            parent.force_canvas_and_preview_refresh()

    def prev_frame(self):
        lm = state.layer_manager
        if lm.current_frame > 0:
            lm.current_frame -= 1
            self.update_frame_label()
            self._clear_canvas_overlays()
            self.layers_list.update_tabs()
            # Force a complete frame switch to ensure proper image loading
            if self.canvas:
                self.canvas.force_layer_frame_switch()
            parent = self.parent()
            while parent and not hasattr(parent, 'force_canvas_and_preview_refresh'):
                parent = parent.parent()
            if parent and hasattr(parent, 'force_canvas_and_preview_refresh'):
                parent.force_canvas_and_preview_refresh()

    def next_frame(self):
        lm = state.layer_manager
        total = len(lm.layers[0].frames) if lm.layers else 1
        if lm.current_frame < total - 1:
            lm.current_frame += 1
            self.update_frame_label()
            self._clear_canvas_overlays()
            self.layers_list.update_tabs()
            # Force a complete frame switch to ensure proper image loading
            if self.canvas:
                self.canvas.force_layer_frame_switch()
            parent = self.parent()
            while parent and not hasattr(parent, 'force_canvas_and_preview_refresh'):
                parent = parent.parent()
            if parent and hasattr(parent, 'force_canvas_and_preview_refresh'):
                parent.force_canvas_and_preview_refresh()

    def toggle_play(self):
        from PySide6.QtCore import QTimer
        if not self.is_playing:
            self.is_playing = True
            self.play_btn.setText("⏸")
            self.play_timer = QTimer(self)
            self.play_timer.timeout.connect(self.play_next_frame)
            # Use the current speed setting
            speed = self.speed_slider.value()
            interval = int(1000 / speed)  # Convert FPS to milliseconds
            self.play_timer.start(interval)
        else:
            self.is_playing = False
            self.play_btn.setText("▶")
            if self.play_timer:
                self.play_timer.stop()
                self.play_timer = None

    def play_next_frame(self):
        lm = state.layer_manager
        total = len(lm.layers[0].frames) if lm.layers else 1
        if lm.current_frame < total - 1:
            lm.current_frame += 1
        else:
            lm.current_frame = 0
        self.update_frame_label()
        # Always update preview box during animation playback
        self.preview_box.update()
        if self.canvas:
            self.canvas.update()
            # Force a complete repaint
            self.canvas.repaint()
    
    def on_speed_text_changed(self, text):
        """Handle animation speed text changes"""
        try:
            value = float(text)
            if 1.0 <= value <= 60.0:
                if self.is_playing and self.play_timer:
                    # Update the timer interval when speed changes
                    interval = int(1000 / value)  # Convert FPS to milliseconds
                    self.play_timer.setInterval(interval)
            else:
                # Reset to valid range if out of bounds
                if value < 1.0:
                    self.speed_input.setText("1.0")
                elif value > 60.0:
                    self.speed_input.setText("60.0")
        except ValueError:
            # Reset to default if invalid input
            self.speed_input.setText("12.0")
    
    def increase_speed(self):
        try:
            current = float(self.speed_input.text())
            if current < 60.0:
                new_speed = current + 1.0
                self.speed_input.setText(str(new_speed))
                if self.is_playing and self.play_timer:
                    interval = int(1000 / new_speed)
                    self.play_timer.setInterval(interval)
        except ValueError:
            # Reset to default if invalid input
            self.speed_input.setText("12.0")
    
    def decrease_speed(self):
        try:
            current = float(self.speed_input.text())
            if current > 1.0:
                new_speed = current - 1.0
                self.speed_input.setText(str(new_speed))
                if self.is_playing and self.play_timer:
                    interval = int(1000 / new_speed)
                    self.play_timer.setInterval(interval)
        except ValueError:
            # Reset to default if invalid input
            self.speed_input.setText("12.0")

    def on_speed_slider_changed(self, value):
        self.speed_value_label.setText(str(value))
        # Optionally update animation speed live
        if self.is_playing and self.play_timer:
            interval = int(1000 / value)
            self.play_timer.setInterval(interval) 

    def wheelEvent(self, event):
        if self.rect().contains(event.position().toPoint()):
            return super().wheelEvent(event) 

    def _toggle_current_layer_controls(self):
        expanded = self.current_layer_toggle.isChecked()
        self.current_layer_controls.setVisible(expanded)

    def _update_current_layer_controls(self):
        lm = state.layer_manager
        idx = lm.current_layer
        layer = lm.layers[idx]
        settings = layer.onion_skin_settings
        # Prev
        self.prev_visible.setChecked(settings['prev']['visible'])
        self.prev_color_btn.setStyleSheet(f"background: {settings['prev']['color']};")
        self.prev_opacity_slider.setValue(settings['prev']['opacity'])
        # Next
        self.next_visible.setChecked(settings['next']['visible'])
        self.next_color_btn.setStyleSheet(f"background: {settings['next']['color']};")
        self.next_opacity_slider.setValue(settings['next']['opacity'])
        # Connect signals to update settings
        self.prev_visible.stateChanged.connect(lambda v: self._set_onion_setting(layer, 'prev', 'visible', bool(v)))
        self.prev_opacity_slider.valueChanged.connect(lambda v: self._set_onion_setting(layer, 'prev', 'opacity', v))
        self.next_visible.stateChanged.connect(lambda v: self._set_onion_setting(layer, 'next', 'visible', bool(v)))
        self.next_opacity_slider.valueChanged.connect(lambda v: self._set_onion_setting(layer, 'next', 'opacity', v))

    def _set_onion_setting(self, layer, which, key, value):
        layer.onion_skin_settings[which][key] = value
        # Update canvas to show onion skin changes
        if hasattr(self, 'canvas') and self.canvas:
            self.canvas.update()

    def _pick_onion_color(self, btn):
        color = QColorDialog.getColor()
        if color.isValid():
            btn.setStyleSheet(f"background: {color.name()};")
            lm = state.layer_manager
            idx = lm.current_layer
            layer = lm.layers[idx]
            if btn == self.prev_color_btn:
                layer.onion_skin_settings['prev']['color'] = color.name()
            elif btn == self.next_color_btn:
                layer.onion_skin_settings['next']['color'] = color.name()
            # Update canvas to show onion skin changes
            if hasattr(self, 'canvas') and self.canvas:
                self.canvas.update()

    def _refresh_other_layers_section(self, onion_skin_content, onion_skin_layout):
        # Remove old sections if exist
        if hasattr(self, 'other_layers_sections') and self.other_layers_sections:
            for section in self.other_layers_sections:
                onion_skin_layout.removeWidget(section)
                section.setParent(None)
            self.other_layers_sections = []
        else:
            self.other_layers_sections = []
        lm = state.layer_manager
        for idx, layer in enumerate(lm.layers):
            if idx == lm.current_layer:
                continue
            other_layer_content = QWidget(onion_skin_content)
            other_layer_layout = QVBoxLayout(other_layer_content)
            other_layer_layout.setContentsMargins(2, 2, 2, 2)
            other_layer_layout.setSpacing(2)
            # Previous Frame
            prev_row = QHBoxLayout()
            prev_row.setContentsMargins(0, 0, 0, 0)
            prev_row.setSpacing(2)
            prev_cb = QCheckBox("Prev Frame", other_layer_content)
            prev_cb.setChecked(layer.onion_skin_settings['prev']['visible'])
            prev_color_btn = QPushButton("Color", other_layer_content)
            prev_color_btn.setStyleSheet(f"background: {layer.onion_skin_settings['prev']['color']};")
            prev_color_btn.clicked.connect(lambda _, btn=prev_color_btn, lyr=layer: self._pick_other_onion_color(btn, lyr, 'prev'))
            prev_opacity_slider = QSlider(Qt.Horizontal, other_layer_content)
            prev_opacity_slider.setMinimum(0)
            prev_opacity_slider.setMaximum(255)
            prev_opacity_slider.setValue(layer.onion_skin_settings['prev']['opacity'])
            prev_cb.stateChanged.connect(lambda v, lyr=layer: self._set_onion_setting(lyr, 'prev', 'visible', bool(v)))
            prev_opacity_slider.valueChanged.connect(lambda v, lyr=layer: self._set_onion_setting(lyr, 'prev', 'opacity', v))
            prev_row.addWidget(prev_cb)
            prev_row.addWidget(prev_color_btn)
            prev_row.addWidget(QLabel("Opacity:"))
            prev_row.addWidget(prev_opacity_slider)
            other_layer_layout.addLayout(prev_row)
            # Current Frame
            curr_row = QHBoxLayout()
            curr_row.setContentsMargins(0, 0, 0, 0)
            curr_row.setSpacing(2)
            curr_cb = QCheckBox("Current Frame", other_layer_content)
            curr_cb.setChecked(layer.onion_skin_settings['current']['visible'])
            curr_color_btn = QPushButton("Color", other_layer_content)
            curr_color_btn.setStyleSheet(f"background: {layer.onion_skin_settings['current']['color']};")
            curr_color_btn.clicked.connect(lambda _, btn=curr_color_btn, lyr=layer: self._pick_other_onion_color(btn, lyr, 'current'))
            curr_opacity_slider = QSlider(Qt.Horizontal, other_layer_content)
            curr_opacity_slider.setMinimum(0)
            curr_opacity_slider.setMaximum(255)
            curr_opacity_slider.setValue(layer.onion_skin_settings['current']['opacity'])
            curr_cb.stateChanged.connect(lambda v, lyr=layer: self._set_onion_setting(lyr, 'current', 'visible', bool(v)))
            curr_opacity_slider.valueChanged.connect(lambda v, lyr=layer: self._set_onion_setting(lyr, 'current', 'opacity', v))
            curr_row.addWidget(curr_cb)
            curr_row.addWidget(curr_color_btn)
            curr_row.addWidget(QLabel("Opacity:"))
            curr_row.addWidget(curr_opacity_slider)
            other_layer_layout.addLayout(curr_row)
            # Next Frame
            next_row = QHBoxLayout()
            next_row.setContentsMargins(0, 0, 0, 0)
            next_row.setSpacing(2)
            next_cb = QCheckBox("Next Frame", other_layer_content)
            next_cb.setChecked(layer.onion_skin_settings['next']['visible'])
            next_color_btn = QPushButton("Color", other_layer_content)
            next_color_btn.setStyleSheet(f"background: {layer.onion_skin_settings['next']['color']};")
            next_color_btn.clicked.connect(lambda _, btn=next_color_btn, lyr=layer: self._pick_other_onion_color(btn, lyr, 'next'))
            next_opacity_slider = QSlider(Qt.Horizontal, other_layer_content)
            next_opacity_slider.setMinimum(0)
            next_opacity_slider.setMaximum(255)
            next_opacity_slider.setValue(layer.onion_skin_settings['next']['opacity'])
            next_cb.stateChanged.connect(lambda v, lyr=layer: self._set_onion_setting(lyr, 'next', 'visible', bool(v)))
            next_opacity_slider.valueChanged.connect(lambda v, lyr=layer: self._set_onion_setting(lyr, 'next', 'opacity', v))
            next_row.addWidget(next_cb)
            next_row.addWidget(next_color_btn)
            next_row.addWidget(QLabel("Opacity:"))
            next_row.addWidget(next_opacity_slider)
            other_layer_layout.addLayout(next_row)
            other_layer_content.setLayout(other_layer_layout)
            section = CollapsibleSection(layer.name, other_layer_content, onion_skin_content, subtab=True)
            section.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Minimum)
            onion_skin_layout.addWidget(section)
            self.other_layers_sections.append(section) 

    def _pick_other_onion_color(self, btn, layer, which):
        color = QColorDialog.getColor()
        if color.isValid():
            btn.setStyleSheet(f"background: {color.name()};")
            layer.onion_skin_settings[which]['color'] = color.name()
            # Update canvas to show onion skin changes
            if hasattr(self, 'canvas') and self.canvas:
                self.canvas.update()

    def _connect_layer_selection(self):
        # Connect to layer selection changes
        self.layers_list.select_layer = self._on_layer_selected

    def _on_layer_selected(self, index):
        state.layer_manager.current_layer = index
        self.layers_list.selected_index = index
        self.layers_list.update_tabs()
        self._update_current_layer_controls()
        self._refresh_other_layers_section(self.sections["Onion Skin"].content_widget, self.sections["Onion Skin"].content_widget.layout())
        parent = self.parent()
        while parent and not hasattr(parent, 'force_canvas_and_preview_refresh'):
            parent = parent.parent()
        if parent and hasattr(parent, 'force_canvas_and_preview_refresh'):
            parent.force_canvas_and_preview_refresh() 
    
    def _refresh_timeline(self):
        """Refresh the timeline if it exists"""
        main_window = self.window()
        if hasattr(main_window, 'timeline') and main_window.timeline:
            # Update timeline with all layers
            all_layers = state.layer_manager.layers
            main_window.timeline.set_layers(all_layers)
    
    def _toggle_timeline(self):
        """Toggle timeline visibility"""
        # First try to find embedded editor (SpriteEditor scenario)
        # Traverse up to find IntegratedImageEditor
        widget = self
        while widget:
            # Check if this is IntegratedImageEditor with main_editor
            if hasattr(widget, 'main_editor') and widget.main_editor:
                if hasattr(widget.main_editor, 'toggle_timeline'):
                    widget.main_editor.toggle_timeline()
                    return
            # Check if this widget has toggle_timeline directly
            if hasattr(widget, 'toggle_timeline'):
                widget.toggle_timeline()
                return
            # Check if parent is MainWindow
            from ui.main_window import MainWindow
            parent = widget.parent()
            if parent and isinstance(parent, MainWindow):
                parent.toggle_timeline()
                return
            widget = parent
        
        # Fallback: get main window via canvas if available
        main_window = self.window()
        if hasattr(main_window, 'toggle_timeline'):
            main_window.toggle_timeline() 