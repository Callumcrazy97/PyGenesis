import sys
import os
import random
import math
from PySide6.QtWidgets import (QDialog, QWidget, QVBoxLayout, 
                               QHBoxLayout, QGridLayout, QLabel, QPushButton, 
                               QComboBox, QSlider, QSpinBox, QGroupBox, QScrollArea,
                               QFrame, QSplitter, QTextEdit, QLineEdit, QCheckBox,
                               QColorDialog, QMenu)
from PySide6.QtCore import Qt, QTimer, QRect
from PySide6.QtGui import QPixmap, QPainter, QColor, QFont, QPalette, QImage

from core.texture_utils import generate_block_texture_qimage, hex_to_qcolor

# Color name mapping dictionary
COLOR_NAMES = {
    # Skin tones
    '#FFDBB4': 'Light Peach', '#F1C27D': 'Peach', '#E0AC69': 'Golden Tan', 
    '#C68642': 'Medium Tan', '#8D5524': 'Dark Tan', '#5D4037': 'Brown', '#3E2723': 'Dark Brown',
    
    # Hair colors
    '#8B4513': 'Saddle Brown', '#654321': 'Dark Brown', '#2F1B14': 'Black', 
    '#A0522D': 'Sienna', '#CD853F': 'Peru', '#DAA520': 'Goldenrod', 
    '#F4A460': 'Sandy Brown', '#DEB887': 'Burlywood', '#F5DEB3': 'Wheat', '#FFE4B5': 'Moccasin',
    
    # Eye colors
    '#4A90E2': 'Blue', '#87CEEB': 'Sky Blue', '#4682B4': 'Steel Blue', 
    '#1E90FF': 'Dodger Blue', '#00BFFF': 'Deep Sky Blue', '#40E0D0': 'Turquoise', 
    '#20B2AA': 'Light Sea Green', '#48D1CC': 'Medium Turquoise', '#00CED1': 'Dark Turquoise', '#008B8B': 'Dark Cyan',
    
    # Clothing colors - Reds
    '#FF6B6B': 'Light Red', '#FF8E8E': 'Pink Red', '#FFB6C1': 'Light Pink', 
    '#FF69B4': 'Hot Pink', '#FF1493': 'Deep Pink', '#DC143C': 'Crimson', 
    '#B22222': 'Fire Brick', '#8B0000': 'Dark Red', '#FF4500': 'Orange Red', '#FF6347': 'Tomato',
    
    # Clothing colors - Yellows/Oranges
    '#FFD700': 'Gold', '#FFA500': 'Orange', '#FF8C00': 'Dark Orange', 
    '#FF7F50': 'Coral', '#FF6347': 'Tomato',
    
    # Clothing colors - Greens
    '#32CD32': 'Lime Green', '#90EE90': 'Light Green', '#98FB98': 'Pale Green', 
    '#00FF7F': 'Spring Green', '#00FA9A': 'Medium Spring Green',
    
    # Clothing colors - Blues
    '#191970': 'Midnight Blue', '#4169E1': 'Royal Blue', '#1E90FF': 'Dodger Blue', 
    '#00BFFF': 'Deep Sky Blue', '#87CEEB': 'Sky Blue', '#4682B4': 'Steel Blue', 
    '#6495ED': 'Cornflower Blue', '#B0C4DE': 'Light Steel Blue', '#F0F8FF': 'Alice Blue', '#E6E6FA': 'Lavender',
    
    # Clothing colors - Grays/Whites/Blacks
    '#FFFFFF': 'White', '#F5F5F5': 'White Smoke', '#DCDCDC': 'Gainsboro', 
    '#C0C0C0': 'Silver', '#A9A9A9': 'Dark Gray', '#808080': 'Gray', 
    '#696969': 'Dim Gray', '#2F2F2F': 'Dark Gray', '#1C1C1C': 'Very Dark Gray', '#000000': 'Black'
}

def get_color_name(hex_color):
    """Get the readable name for a hex color"""
    return COLOR_NAMES.get(hex_color.upper(), hex_color)

def get_hex_from_name(color_name):
    """Get the hex color from a readable name"""
    for hex_val, name in COLOR_NAMES.items():
        if name.lower() == color_name.lower():
            return hex_val
    return None

class ColorSelectorWidget(QWidget):
    def __init__(self, initial_color="#FF0000", parent=None):
        super().__init__(parent)
        self.current_color = initial_color
        self.color_index = 0
        
        # Preset colors for different categories
        self.preset_colors = {
            'skin': ['#FFDBB4', '#F1C27D', '#E0AC69', '#C68642', '#8D5524', '#5D4037', '#3E2723'],
            'hair': ['#8B4513', '#654321', '#2F1B14', '#A0522D', '#CD853F', '#DAA520', '#F4A460', '#DEB887', '#F5DEB3', '#FFE4B5'],
            'eyes': ['#4A90E2', '#87CEEB', '#4682B4', '#1E90FF', '#00BFFF', '#40E0D0', '#20B2AA', '#48D1CC', '#00CED1', '#008B8B'],
            'clothing': ['#FF6B6B', '#FF8E8E', '#FFB6C1', '#FF69B4', '#FF1493', '#DC143C', '#B22222', '#8B0000', '#FF4500', '#FF6347',
                        '#FFD700', '#FFA500', '#FF8C00', '#FF7F50', '#FF6347', '#32CD32', '#90EE90', '#98FB98', '#00FF7F', '#00FA9A',
                        '#191970', '#4169E1', '#1E90FF', '#00BFFF', '#87CEEB', '#4682B4', '#6495ED', '#B0C4DE', '#F0F8FF', '#E6E6FA',
                        '#FFFFFF', '#F5F5F5', '#DCDCDC', '#C0C0C0', '#A9A9A9', '#808080', '#696969', '#2F2F2F', '#1C1C1C', '#000000']
        }
        
        self.setup_ui()
        
    def setup_ui(self):
        layout = QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(5)
        
        # Color preview button
        self.color_button = QPushButton()
        self.color_button.setFixedSize(30, 25)
        self.color_button.clicked.connect(self.show_color_picker)
        self.color_button.setToolTip("Click to open color picker")
        self.update_color_button()
        layout.addWidget(self.color_button)
        
        # Color dropdown
        self.color_combo = QComboBox()
        self.color_combo.setFixedWidth(120)  # Increased width for color names
        self.color_combo.currentTextChanged.connect(self.on_color_selected)
        self.color_combo.setToolTip("Select from preset colors")
        layout.addWidget(self.color_combo)
        
        # Hex input field
        self.hex_edit = QLineEdit()
        self.hex_edit.setFixedWidth(80)
        self.hex_edit.setMaxLength(7)
        self.hex_edit.setPlaceholderText("#RRGGBB")
        self.hex_edit.textChanged.connect(self.on_hex_changed)
        self.hex_edit.setToolTip("Enter hex color code (e.g., #FF0000)")
        layout.addWidget(self.hex_edit)
        
        # Set initial values
        self.update_color_list()
        self.hex_edit.setText(self.current_color)
        
        # Enable mouse wheel events
        self.setFocusPolicy(Qt.StrongFocus)
        self.setToolTip("Scroll mouse wheel to cycle through colors")
        
        # Enable mouse tracking for hover events
        self.setMouseTracking(True)
        
    def update_color_button(self):
        """Update the color button to show current color"""
        color = QColor(self.current_color)
        if not color.isValid():
            color = QColor("#FF0000")
            
        # Create a pixmap with the current color
        pixmap = QPixmap(28, 23)
        pixmap.fill(color)
        
        # Draw a border
        painter = QPainter(pixmap)
        painter.setPen(QColor("#666666"))
        painter.drawRect(0, 0, 27, 22)
        painter.end()
        
        self.color_button.setIcon(pixmap)
        
    def update_color_list(self):
        """Update the dropdown with appropriate preset colors"""
        # Block signals during the entire update to prevent recursion
        self.color_combo.blockSignals(True)
        
        self.color_combo.clear()
        
        # Determine which preset category to use based on current color
        category = self.determine_color_category()
        colors = self.preset_colors.get(category, self.preset_colors['clothing'])
        
        for color in colors:
            color_name = get_color_name(color)
            self.color_combo.addItem(color_name, color)  # Store hex as data
            
        # Set current color if it exists in the list
        current_found = False
        for i in range(self.color_combo.count()):
            if self.color_combo.itemData(i) == self.current_color:
                self.color_combo.setCurrentIndex(i)
                current_found = True
                break
                
        # If not found in the current category, add it to the list and select it
        if not current_found:
            color_name = get_color_name(self.current_color)
            self.color_combo.addItem(color_name, self.current_color)
            self.color_combo.setCurrentIndex(self.color_combo.count() - 1)
            
        # Unblock signals after the update is complete
        self.color_combo.blockSignals(False)
            
    def determine_color_category(self):
        """Determine which color category the current color belongs to"""
        color = QColor(self.current_color)
        if not color.isValid():
            return 'clothing'
            
        # Get RGB values for more accurate detection
        r, g, b = color.red(), color.green(), color.blue()
        
        # Try to get HSV values, but handle potential errors
        try:
            h, s, v = color.getHsv()
        except:
            # Fallback: estimate saturation and value from RGB
            max_val = max(r, g, b)
            min_val = min(r, g, b)
            if max_val == 0:
                s, v = 0, 0
            else:
                v = max_val
                s = ((max_val - min_val) / max_val) * 255 if max_val > 0 else 0
        
        # Skin tones: warm colors with low-medium saturation
        if (r > g and r > b) and s < 60 and 80 < v < 220:
            return 'skin'
        # Hair tones: browns, blacks, blondes (low-medium saturation, low-medium value)
        elif s < 70 and v < 160:
            return 'hair'
        # Eye colors: blues, greens, browns (medium-high saturation, medium value)
        elif s > 60 and 80 < v < 200:
            return 'eyes'
        else:
            return 'clothing'
            
    def show_color_picker(self):
        """Show the color picker dialog"""
        color = QColor(self.current_color)
        if not color.isValid():
            color = QColor("#FF0000")
            
        new_color = QColorDialog.getColor(color, self, "Choose Color")
        if new_color.isValid():
            self.set_color(new_color.name().upper())
            
    def on_color_selected(self, color_text):
        """Handle color selection from dropdown"""
        # Get the hex value from the combo box data
        current_index = self.color_combo.currentIndex()
        if current_index >= 0:
            hex_color = self.color_combo.itemData(current_index)
            if hex_color and hex_color != self.current_color:
                self.set_color(hex_color)
            
    def on_hex_changed(self, hex_text):
        """Handle manual hex input"""
        if hex_text.startswith('#') and len(hex_text) == 7:
            color = QColor(hex_text)
            if color.isValid():
                self.set_color(hex_text.upper())
                
    def set_color(self, color):
        """Set the current color and update UI"""
        if color != self.current_color:
            self.current_color = color
            self.update_color_button()
            
            # Block hex edit signals temporarily to prevent recursion
            self.hex_edit.blockSignals(True)
            
            self.update_color_list()
            self.hex_edit.setText(color)
            
            self.hex_edit.blockSignals(False)
            
            # Emit signal or call callback
            if hasattr(self, 'color_changed_callback'):
                self.color_changed_callback(color)
                
    def get_color(self):
        """Get the current color"""
        return self.current_color
        
    def wheelEvent(self, event):
        """Handle mouse wheel to cycle through colors"""
        category = self.determine_color_category()
        colors = self.preset_colors.get(category, self.preset_colors['clothing'])
        
        if colors:
            # Find current color in the list
            try:
                current_index = colors.index(self.current_color)
            except ValueError:
                current_index = 0
                
            # Cycle to next/previous color based on wheel direction
            if event.angleDelta().y() > 0:  # Scroll up
                current_index = (current_index - 1) % len(colors)
            else:  # Scroll down
                current_index = (current_index + 1) % len(colors)
                
            # Set the new color
            new_color = colors[current_index]
            self.set_color(new_color)
            
        event.accept()
        
    def set_color_changed_callback(self, callback):
        """Set the callback function for color changes"""
        self.color_changed_callback = callback
        
    def enterEvent(self, event):
        """Handle mouse enter event"""
        self.setFocus()
        
    def leaveEvent(self, event):
        """Handle mouse leave event"""
        self.clearFocus()

class CharacterCreatorDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("🎭 Character Creator")
        self.setGeometry(100, 100, 1400, 900)
        
        # Character data
        self.character_data = {
            'name': 'Character',
            'gender': 'Male',
            'height': 170,
            'weight': 70,
            'skin_color': '#FFDBB4',
            'eye_color': '#4A90E2',
            'eye_style': 'Normal',
            'hair_color': '#8B4513',
            'hair_style': 'Short',
            'facial_hair': 'None',
            'facial_hair_color': '#654321',
            'clothing': {
                'shirt': 'T-Shirt',
                'jacket': 'None',
                'pants': 'Jeans',
                'shoes': 'Sneakers',
                'hat': 'None',
                'shirt_color': '#FF6B6B',
                'pants_color': '#191970',
                'shoes_color': '#FFFFFF',
                'accessories': []
            },
            'texture_seed': 42  # Consistent seed for texture generation
        }
        
        # 3D View settings
        self.view_angle = 0  # 0=front, 90=right, 180=back, 270=left
        self.zoom_level = 1.0
        self.pan_x = 0
        self.pan_y = 0
        self.last_mouse_pos = None
        
        # Performance optimization: cache for character images
        self._cached_character_image = None
        self._cached_mugshot_image = None
        self._last_character_hash = None
        
        self.setup_ui()
        
        # Initialize custom dimensions based on current canvas size
        self.initialize_custom_dimensions()
        
        # Defer the initial preview update to prevent slow opening
        QTimer.singleShot(100, self.update_character_preview)
        
    def setup_ui(self):
        # Main layout
        main_layout = QVBoxLayout(self)
        
        # Create splitter for resizable panels
        splitter = QSplitter(Qt.Horizontal)
        main_layout.addWidget(splitter)
        
        # Left panel - Character preview
        self.preview_panel = self.create_preview_panel()
        splitter.addWidget(self.preview_panel)
        
        # Right panel - Controls
        self.controls_panel = self.create_controls_panel()
        splitter.addWidget(self.controls_panel)
        
        # Bottom panel - Actions
        self.actions_panel = self.create_actions_panel()
        main_layout.addWidget(self.actions_panel)
        
        # Set splitter proportions
        splitter.setSizes([800, 600])
        
    def create_preview_panel(self):
        panel = QWidget()
        layout = QVBoxLayout(panel)
        
        # Title
        title = QLabel("🎭 Character Preview")
        title.setFont(QFont("Arial", 16, QFont.Bold))
        title.setAlignment(Qt.AlignCenter)
        layout.addWidget(title)
        
        # Character display area
        self.character_display = QLabel()
        self.character_display.setMinimumSize(400, 600)
        self.character_display.setStyleSheet("""
            QLabel {
                border: 2px solid #666;
                border-radius: 10px;
                background: #f0f0f0;
            }
        """)
        self.character_display.setAlignment(Qt.AlignCenter)
        layout.addWidget(self.character_display)
        
        # Mugshot display
        mugshot_title = QLabel("📸 Mugshot")
        mugshot_title.setFont(QFont("Arial", 12, QFont.Bold))
        mugshot_title.setAlignment(Qt.AlignCenter)
        layout.addWidget(mugshot_title)
        
        self.mugshot_display = QLabel()
        self.mugshot_display.setFixedSize(200, 200)
        self.mugshot_display.setStyleSheet("""
            QLabel {
                border: 2px solid #666;
                border-radius: 10px;
                background: #f0f0f0;
            }
        """)
        self.mugshot_display.setAlignment(Qt.AlignCenter)
        layout.addWidget(self.mugshot_display)
        
        # View controls
        view_layout = QHBoxLayout()
        
        front_btn = QPushButton("Front")
        front_btn.clicked.connect(lambda: self.set_view_angle(0))
        view_layout.addWidget(front_btn)
        
        back_btn = QPushButton("Back")
        back_btn.clicked.connect(lambda: self.set_view_angle(180))
        view_layout.addWidget(back_btn)
        
        left_btn = QPushButton("Left")
        left_btn.clicked.connect(lambda: self.set_view_angle(270))
        view_layout.addWidget(left_btn)
        
        right_btn = QPushButton("Right")
        right_btn.clicked.connect(lambda: self.set_view_angle(90))
        view_layout.addWidget(right_btn)
        
        layout.addLayout(view_layout)
        
        # Zoom controls
        zoom_layout = QHBoxLayout()
        
        zoom_in_btn = QPushButton("Zoom In")
        zoom_in_btn.clicked.connect(self.zoom_in)
        zoom_layout.addWidget(zoom_in_btn)
        
        zoom_out_btn = QPushButton("Zoom Out")
        zoom_out_btn.clicked.connect(self.zoom_out)
        zoom_layout.addWidget(zoom_out_btn)
        
        reset_btn = QPushButton("Reset View")
        reset_btn.clicked.connect(self.reset_view)
        zoom_layout.addWidget(reset_btn)
        
        layout.addLayout(zoom_layout)
        
        # Enable mouse events for panning
        self.character_display.mousePressEvent = self.on_mouse_press
        self.character_display.mouseMoveEvent = self.on_mouse_move
        self.character_display.wheelEvent = self.on_wheel
        
        return panel
        
    def create_controls_panel(self):
        panel = QWidget()
        layout = QVBoxLayout(panel)
        
        # Scroll area for controls
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        
        controls_widget = QWidget()
        controls_layout = QVBoxLayout(controls_widget)
        
        # Basic Info Group
        basic_group = self.create_basic_info_group()
        controls_layout.addWidget(basic_group)
        
        # Appearance Group
        appearance_group = self.create_appearance_group()
        controls_layout.addWidget(appearance_group)
        
        # Hair & Face Group
        hair_face_group = self.create_hair_face_group()
        controls_layout.addWidget(hair_face_group)
        
        # Clothing Group
        clothing_group = self.create_clothing_group()
        controls_layout.addWidget(clothing_group)
        
        controls_layout.addStretch()
        
        scroll.setWidget(controls_widget)
        layout.addWidget(scroll)
        
        return panel
        
    def create_basic_info_group(self):
        group = QGroupBox("Basic Info")
        layout = QGridLayout(group)
        
        # Name
        layout.addWidget(QLabel("Name:"), 0, 0)
        self.name_edit = QLineEdit(self.character_data['name'])
        self.name_edit.textChanged.connect(self.on_name_changed)
        layout.addWidget(self.name_edit, 0, 1)
        
        # Gender
        layout.addWidget(QLabel("Gender:"), 1, 0)
        self.gender_combo = QComboBox()
        self.gender_combo.addItems(['Male', 'Female'])
        self.gender_combo.setCurrentText(self.character_data['gender'])
        self.gender_combo.currentTextChanged.connect(self.on_gender_changed)
        layout.addWidget(self.gender_combo, 1, 1)
        
        # Height
        layout.addWidget(QLabel("Height (cm):"), 2, 0)
        self.height_spin = QSpinBox()
        self.height_spin.setRange(120, 220)
        self.height_spin.setValue(self.character_data['height'])
        self.height_spin.valueChanged.connect(self.on_height_changed)
        layout.addWidget(self.height_spin, 2, 1)
        
        # Weight
        layout.addWidget(QLabel("Weight (kg):"), 3, 0)
        self.weight_spin = QSpinBox()
        self.weight_spin.setRange(40, 150)
        self.weight_spin.setValue(self.character_data['weight'])
        self.weight_spin.valueChanged.connect(self.on_weight_changed)
        layout.addWidget(self.weight_spin, 3, 1)
        
        return group
        
    def create_appearance_group(self):
        group = QGroupBox("Appearance")
        layout = QGridLayout(group)
        
        # Skin Color
        layout.addWidget(QLabel("Skin Color:"), 0, 0)
        self.skin_color_edit = ColorSelectorWidget(self.character_data['skin_color'])
        self.skin_color_edit.color_changed_callback = self.on_skin_color_changed
        layout.addWidget(self.skin_color_edit, 0, 1)
        
        # Eye Color
        layout.addWidget(QLabel("Eye Color:"), 1, 0)
        self.eye_color_edit = ColorSelectorWidget(self.character_data['eye_color'])
        self.eye_color_edit.color_changed_callback = self.on_eye_color_changed
        layout.addWidget(self.eye_color_edit, 1, 1)
        
        # Eye Style
        layout.addWidget(QLabel("Eye Style:"), 2, 0)
        self.eye_style_combo = QComboBox()
        self.eye_style_combo.addItems(['Normal', 'Narrow', 'Wide', 'Squint', 'Round'])
        self.eye_style_combo.setCurrentText(self.character_data['eye_style'])
        self.eye_style_combo.currentTextChanged.connect(self.on_eye_style_changed)
        layout.addWidget(self.eye_style_combo, 2, 1)
        
        return group
        
    def create_hair_face_group(self):
        group = QGroupBox("Hair & Face")
        layout = QGridLayout(group)
        
        # Hair Color
        layout.addWidget(QLabel("Hair Color:"), 0, 0)
        self.hair_color_edit = ColorSelectorWidget(self.character_data['hair_color'])
        self.hair_color_edit.color_changed_callback = self.on_hair_color_changed
        layout.addWidget(self.hair_color_edit, 0, 1)
        
        # Hair Style
        layout.addWidget(QLabel("Hair Style:"), 1, 0)
        self.hair_style_combo = QComboBox()
        self.hair_style_combo.addItems(['Short', 'Long', 'Spiky', 'Wavy', 'Curly', 'Bald'])
        self.hair_style_combo.setCurrentText(self.character_data['hair_style'])
        self.hair_style_combo.currentTextChanged.connect(self.on_hair_style_changed)
        layout.addWidget(self.hair_style_combo, 1, 1)
        
        # Facial Hair
        layout.addWidget(QLabel("Facial Hair:"), 2, 0)
        self.facial_hair_combo = QComboBox()
        self.facial_hair_combo.addItems(['None', 'Stubble', 'Moustache', 'Beard', 'Goatee'])
        self.facial_hair_combo.setCurrentText(self.character_data['facial_hair'])
        self.facial_hair_combo.currentTextChanged.connect(self.on_facial_hair_changed)
        layout.addWidget(self.facial_hair_combo, 2, 1)
        
        # Facial Hair Color
        layout.addWidget(QLabel("Facial Hair Color:"), 3, 0)
        self.facial_hair_color_edit = ColorSelectorWidget(self.character_data['facial_hair_color'])
        self.facial_hair_color_edit.color_changed_callback = self.on_facial_hair_color_changed
        layout.addWidget(self.facial_hair_color_edit, 3, 1)
        
        return group
        
    def create_clothing_group(self):
        group = QGroupBox("Clothing")
        layout = QGridLayout(group)
        
        # Shirt
        layout.addWidget(QLabel("Shirt:"), 0, 0)
        self.shirt_combo = QComboBox()
        self.shirt_combo.addItems(['T-Shirt', 'Shirt', 'Tank Top', 'Sweater', 'Dress'])
        self.shirt_combo.setCurrentText(self.character_data['clothing']['shirt'])
        self.shirt_combo.currentTextChanged.connect(self.on_shirt_changed)
        layout.addWidget(self.shirt_combo, 0, 1)
        
        # Jacket
        layout.addWidget(QLabel("Jacket:"), 1, 0)
        self.jacket_combo = QComboBox()
        self.jacket_combo.addItems(['None', 'Jacket', 'Coat', 'Hoodie'])
        self.jacket_combo.setCurrentText(self.character_data['clothing']['jacket'])
        self.jacket_combo.currentTextChanged.connect(self.on_jacket_changed)
        layout.addWidget(self.jacket_combo, 1, 1)
        
        # Pants
        layout.addWidget(QLabel("Pants:"), 2, 0)
        self.pants_combo = QComboBox()
        self.pants_combo.addItems(['Jeans', 'Shorts', 'Pants', 'Leggings', 'Skirt'])
        self.pants_combo.setCurrentText(self.character_data['clothing']['pants'])
        self.pants_combo.currentTextChanged.connect(self.on_pants_changed)
        layout.addWidget(self.pants_combo, 2, 1)
        
        # Shoes
        layout.addWidget(QLabel("Shoes:"), 3, 0)
        self.shoes_combo = QComboBox()
        self.shoes_combo.addItems(['Sneakers', 'Boots', 'Shoes', 'Sandals', 'Barefoot'])
        self.shoes_combo.setCurrentText(self.character_data['clothing']['shoes'])
        self.shoes_combo.currentTextChanged.connect(self.on_shoes_changed)
        layout.addWidget(self.shoes_combo, 3, 1)
        
        # Hat
        layout.addWidget(QLabel("Hat:"), 4, 0)
        self.hat_combo = QComboBox()
        self.hat_combo.addItems(['None', 'Cap', 'Hat', 'Helmet'])
        self.hat_combo.setCurrentText(self.character_data['clothing']['hat'])
        self.hat_combo.currentTextChanged.connect(self.on_hat_changed)
        layout.addWidget(self.hat_combo, 4, 1)
        
        # Shirt Color
        layout.addWidget(QLabel("Shirt Color:"), 5, 0)
        self.shirt_color_edit = ColorSelectorWidget(self.character_data['clothing']['shirt_color'])
        self.shirt_color_edit.color_changed_callback = self.on_shirt_color_changed
        layout.addWidget(self.shirt_color_edit, 5, 1)
        
        # Pants Color
        layout.addWidget(QLabel("Pants Color:"), 6, 0)
        self.pants_color_edit = ColorSelectorWidget(self.character_data['clothing']['pants_color'])
        self.pants_color_edit.color_changed_callback = self.on_pants_color_changed
        layout.addWidget(self.pants_color_edit, 6, 1)
        
        # Shoes Color
        layout.addWidget(QLabel("Shoes Color:"), 7, 0)
        self.shoes_color_edit = ColorSelectorWidget(self.character_data['clothing']['shoes_color'])
        self.shoes_color_edit.color_changed_callback = self.on_shoes_color_changed
        layout.addWidget(self.shoes_color_edit, 7, 1)
        
        return group
        
    def create_actions_panel(self):
        panel = QWidget()
        layout = QHBoxLayout(panel)
        
        # Randomize button
        randomize_btn = QPushButton("🎲 Randomize Character")
        randomize_btn.clicked.connect(self.randomize_character)
        layout.addWidget(randomize_btn)
        
        layout.addStretch()
        
        # Custom dimensions group
        dim_group = QWidget()
        dim_layout = QHBoxLayout(dim_group)
        dim_layout.setContentsMargins(0, 0, 0, 0)
        
        dim_layout.addWidget(QLabel("Custom Size:"))
        
        # Width spinbox
        self.custom_width_spin = QSpinBox()
        self.custom_width_spin.setRange(16, 2048)
        self.custom_width_spin.setValue(400)
        self.custom_width_spin.setSuffix(" W")
        self.custom_width_spin.setFixedWidth(80)
        dim_layout.addWidget(self.custom_width_spin)
        
        # Height spinbox
        self.custom_height_spin = QSpinBox()
        self.custom_height_spin.setRange(16, 2048)
        self.custom_height_spin.setValue(600)
        self.custom_height_spin.setSuffix(" H")
        self.custom_height_spin.setFixedWidth(80)
        dim_layout.addWidget(self.custom_height_spin)
        
        layout.addWidget(dim_group)
        
        # Apply to Canvas button
        apply_btn = QPushButton("✅ Apply to Canvas")
        apply_btn.clicked.connect(self.apply_to_canvas)
        layout.addWidget(apply_btn)
        
        # Cancel button
        cancel_btn = QPushButton("❌ Cancel")
        cancel_btn.clicked.connect(self.reject)
        layout.addWidget(cancel_btn)
        
        return panel 
        
    def initialize_custom_dimensions(self):
        """Initialize custom dimensions based on current canvas size"""
        try:
            from core.state import state
            if hasattr(state, 'width') and hasattr(state, 'height'):
                # Set custom dimensions to match current canvas
                self.custom_width_spin.setValue(state.width)
                self.custom_height_spin.setValue(state.height)
        except Exception as e:
            print(f"Could not initialize custom dimensions: {e}")
            # Keep default values (400x600)
        
    # Event handlers
    def on_name_changed(self, text):
        self.character_data['name'] = text
        self._clear_cache()
        self.update_character_preview()
        
    def on_gender_changed(self, text):
        self.character_data['gender'] = text
        self._clear_cache()
        self.update_character_preview()
        
    def on_height_changed(self, value):
        self.character_data['height'] = value
        self._clear_cache()
        self.update_character_preview()
        
    def on_weight_changed(self, value):
        self.character_data['weight'] = value
        self._clear_cache()
        self.update_character_preview()
        
    def on_skin_color_changed(self, color):
        self.character_data['skin_color'] = color
        self._clear_cache()
        self.update_character_preview()
        
    def on_eye_color_changed(self, color):
        self.character_data['eye_color'] = color
        self._clear_cache()
        self.update_character_preview()
        
    def on_eye_style_changed(self, style):
        self.character_data['eye_style'] = style
        self._clear_cache()
        self.update_character_preview()
        
    def on_hair_color_changed(self, color):
        self.character_data['hair_color'] = color
        self._clear_cache()
        self.update_character_preview()
        
    def on_hair_style_changed(self, style):
        self.character_data['hair_style'] = style
        self._clear_cache()
        self.update_character_preview()
        
    def on_facial_hair_changed(self, style):
        self.character_data['facial_hair'] = style
        self._clear_cache()
        self.update_character_preview()
        
    def on_facial_hair_color_changed(self, color):
        self.character_data['facial_hair_color'] = color
        self._clear_cache()
        self.update_character_preview()
        
    def on_jacket_changed(self, jacket):
        self.character_data['clothing']['jacket'] = jacket
        self._clear_cache()
        self.update_character_preview()
        
    def on_shirt_changed(self, shirt):
        self.character_data['clothing']['shirt'] = shirt
        self._clear_cache()
        self.update_character_preview()
        
    def on_pants_changed(self, pants):
        self.character_data['clothing']['pants'] = pants
        self._clear_cache()
        self.update_character_preview()
        
    def on_shoes_changed(self, shoes):
        self.character_data['clothing']['shoes'] = shoes
        self._clear_cache()
        self.update_character_preview()
        
    def on_hat_changed(self, hat):
        self.character_data['clothing']['hat'] = hat
        self._clear_cache()
        self.update_character_preview()
        
    def on_shirt_color_changed(self, color):
        self.character_data['clothing']['shirt_color'] = color
        self._clear_cache()
        self.update_character_preview()
        
    def on_pants_color_changed(self, color):
        self.character_data['clothing']['pants_color'] = color
        self._clear_cache()
        self.update_character_preview()
        
    def on_shoes_color_changed(self, color):
        self.character_data['clothing']['shoes_color'] = color
        self._clear_cache()
        self.update_character_preview()
        
    def set_view_angle(self, angle):
        self.view_angle = angle
        self._clear_cache()
        self.update_character_preview()
        
    def zoom_in(self):
        self.zoom_level = min(3.0, self.zoom_level * 1.2)
        self._clear_cache()
        self.update_character_preview()
        
    def zoom_out(self):
        self.zoom_level = max(0.3, self.zoom_level / 1.2)
        self._clear_cache()
        self.update_character_preview()
        
    def reset_view(self):
        self.zoom_level = 1.0
        self.pan_x = 0
        self.pan_y = 0
        self.view_angle = 0
        self._clear_cache()
        self.update_character_preview()
        
    def on_mouse_press(self, event):
        if event.button() == Qt.LeftButton:
            self.last_mouse_pos = event.pos()
            
    def on_mouse_move(self, event):
        if self.last_mouse_pos and event.buttons() & Qt.LeftButton:
            delta = event.pos() - self.last_mouse_pos
            self.pan_x += delta.x()
            self.pan_y += delta.y()
            self.last_mouse_pos = event.pos()
            
            # Update immediately for smooth performance during dragging
            self.update_character_preview()
            
    def on_wheel(self, event):
        if event.angleDelta().y() > 0:
            self.zoom_in()
        else:
            self.zoom_out()
        
        # Update preview immediately for zoom operations
        self.update_character_preview()
            
    def randomize_character(self):
        # Randomize character data
        self.character_data['name'] = f"Character_{random.randint(1000, 9999)}"
        self.character_data['gender'] = random.choice(['Male', 'Female'])
        self.character_data['height'] = random.randint(150, 190)
        self.character_data['weight'] = random.randint(50, 100)
        self.character_data['skin_color'] = random.choice(['#FFDBB4', '#F1C27D', '#E0AC69', '#C68642', '#8D5524'])
        self.character_data['eye_color'] = random.choice(['#4A90E2', '#8B4513', '#228B22', '#FFD700', '#FF69B4'])
        self.character_data['eye_style'] = random.choice(['Normal', 'Narrow', 'Wide', 'Squint', 'Round'])
        self.character_data['hair_color'] = random.choice(['#8B4513', '#000000', '#FFD700', '#FF69B4', '#4169E1'])
        self.character_data['hair_style'] = random.choice(['Short', 'Long', 'Spiky', 'Wavy', 'Curly', 'Bald'])
        self.character_data['facial_hair'] = random.choice(['None', 'Stubble', 'Moustache', 'Beard', 'Goatee'])
        self.character_data['facial_hair_color'] = random.choice(['#654321', '#8B4513', '#000000'])
        self.character_data['clothing']['shirt'] = random.choice(['T-Shirt', 'Shirt', 'Tank Top', 'Sweater', 'Dress'])
        self.character_data['clothing']['jacket'] = random.choice(['None', 'Jacket', 'Coat', 'Hoodie'])
        self.character_data['clothing']['pants'] = random.choice(['Jeans', 'Shorts', 'Pants', 'Leggings', 'Skirt'])
        self.character_data['clothing']['shoes'] = random.choice(['Sneakers', 'Boots', 'Shoes', 'Sandals', 'Barefoot'])
        self.character_data['clothing']['hat'] = random.choice(['None', 'Cap', 'Hat', 'Helmet'])
        self.character_data['clothing']['shirt_color'] = random.choice(['#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4', '#FFEAA7'])
        self.character_data['clothing']['pants_color'] = random.choice(['#191970', '#2F4F4F', '#8B4513', '#000000'])
        self.character_data['clothing']['shoes_color'] = random.choice(['#FFFFFF', '#000000', '#8B4513', '#FFD700'])
        self.character_data['texture_seed'] = random.randint(1, 10000)
        
        self._clear_cache()
        self.update_ui_from_data()
        self.update_character_preview()
        
    def update_ui_from_data(self):
        # Update UI controls to match character data
        self.name_edit.setText(self.character_data['name'])
        self.gender_combo.setCurrentText(self.character_data['gender'])
        self.height_spin.setValue(self.character_data['height'])
        self.weight_spin.setValue(self.character_data['weight'])
        self.skin_color_edit.set_color(self.character_data['skin_color'])
        self.eye_color_edit.set_color(self.character_data['eye_color'])
        self.eye_style_combo.setCurrentText(self.character_data['eye_style'])
        self.hair_color_edit.set_color(self.character_data['hair_color'])
        self.hair_style_combo.setCurrentText(self.character_data['hair_style'])
        self.facial_hair_combo.setCurrentText(self.character_data['facial_hair'])
        self.facial_hair_color_edit.set_color(self.character_data['facial_hair_color'])
        self.shirt_combo.setCurrentText(self.character_data['clothing']['shirt'])
        self.jacket_combo.setCurrentText(self.character_data['clothing']['jacket'])
        self.pants_combo.setCurrentText(self.character_data['clothing']['pants'])
        self.shoes_combo.setCurrentText(self.character_data['clothing']['shoes'])
        self.hat_combo.setCurrentText(self.character_data['clothing']['hat'])
        self.shirt_color_edit.set_color(self.character_data['clothing']['shirt_color'])
        self.pants_color_edit.set_color(self.character_data['clothing']['pants_color'])
        self.shoes_color_edit.set_color(self.character_data['clothing']['shoes_color'])
        
    def update_character_preview(self):
        # Use QTimer to defer the update and prevent blocking the UI
        if hasattr(self, '_update_timer'):
            self._update_timer.stop()
        else:
            self._update_timer = QTimer()
            self._update_timer.setSingleShot(True)
            self._update_timer.timeout.connect(self._perform_update)
        
        self._update_timer.start(10)  # Reduced delay for better responsiveness
        
    def _perform_update(self):
        """Actually perform the character preview update"""
        try:
            # Only update if the dialog is visible
            if not self.isVisible():
                return
            
            # Check if we can use cached images
            current_hash = self._get_character_hash()
            if (self._cached_character_image and self._cached_mugshot_image and 
                self._last_character_hash == current_hash):
                # Use cached images
                pixmap = QPixmap.fromImage(self._cached_character_image)
                self.character_display.setPixmap(pixmap)
                mugshot_pixmap = QPixmap.fromImage(self._cached_mugshot_image)
                self.mugshot_display.setPixmap(mugshot_pixmap)
                return
                
            # Generate new character image
            character_image = self.generate_character_image()
            mugshot_image = self.generate_mugshot_image()
            
            # Cache the images
            self._cached_character_image = character_image
            self._cached_mugshot_image = mugshot_image
            self._last_character_hash = current_hash
            
            # Display character
            pixmap = QPixmap.fromImage(character_image)
            self.character_display.setPixmap(pixmap)
            
            # Display mugshot
            mugshot_pixmap = QPixmap.fromImage(mugshot_image)
            self.mugshot_display.setPixmap(mugshot_pixmap)
        except Exception as e:
            print(f"Error updating character preview: {e}")
        
    def generate_character_image(self, target_width=None, target_height=None):
        # Draw directly at target dimensions instead of scaling down
        # Use target dimensions if specified, otherwise use a reasonable default
        if target_width is not None and target_height is not None:
            width = target_width
            height = target_height
        else:
            # Default size if no target specified
            width = 400
            height = 600
        
        # Create QImage with transparent background at target size
        image = QImage(width, height, QImage.Format_ARGB32)
        image.fill(Qt.transparent)
        
        painter = QPainter(image)
        painter.setRenderHint(QPainter.Antialiasing)
        
        # Calculate character dimensions based on target size
        # Scale character proportions to fit within the target dimensions
        max_character_height = int(height * 0.9)  # Leave 10% padding
        max_character_width = int(width * 0.8)    # Leave 20% padding for arms
        
        # Base character proportions (height:width ratio)
        character_ratio = 2.5  # Character is 2.5x taller than wide
        
        # Calculate actual character size that fits within target
        if max_character_height / character_ratio <= max_character_width:
            # Height is the limiting factor
            character_height = max_character_height
            character_width = int(character_height / character_ratio)
        else:
            # Width is the limiting factor
            character_width = max_character_width
            character_height = int(character_width * character_ratio)
        
        # Calculate component dimensions based on character size
        body_height = int(character_height * 0.5)  # Body is 50% of total height
        body_width = int(character_width * 0.6)    # Body is 60% of total width
        head_width = int(body_width * 0.8)         # Head is 80% of body width
        head_height = int(body_height * 0.3)       # Head is 30% of body height
        
        # Apply height/weight modifiers
        height_modifier = self.character_data['height'] / 170.0
        weight_modifier = self.character_data['weight'] / 70.0
        
        body_height = int(body_height * height_modifier)
        body_width = int(body_width * weight_modifier)
        head_width = int(head_width * weight_modifier)
        head_height = int(head_height * height_modifier)
        
        # Calculate total character dimensions
        total_character_height = head_height + body_height + int(body_height * 0.8) + int(body_height * 0.3)
        total_character_width = max(head_width, body_width) + int(body_width * 0.6)  # Include arms
        
        # Calculate scale to fit character within target canvas with padding
        padding = int(min(width, height) * 0.05)  # 5% padding
        scale_x = (width - padding * 2) / total_character_width
        scale_y = (height - padding * 2) / total_character_height
        fit_scale = min(scale_x, scale_y, 1.0)  # Don't scale up beyond 1.0
        
        # Apply transformations - center the character properly
        painter.translate(width // 2 + self.pan_x, height // 2 + self.pan_y)
        painter.scale(self.zoom_level * fit_scale, self.zoom_level * fit_scale)
        
        # Draw character based on view angle
        if self.view_angle == 0:  # Front
            self.draw_character_components_front(painter, width, height)
        elif self.view_angle == 180:  # Back
            self.draw_character_components_back(painter, width, height)
        else:  # Side views
            side = 'left' if self.view_angle == 270 else 'right'
            self.draw_character_components_side(painter, width, height, side)
        
        painter.end()
        return image
        
    def generate_mugshot_image(self):
        """Generate a mugshot image of the character's head"""
        # Create a 200x200 image for the mugshot
        width = 200
        height = 200
        
        # Create QImage with transparent background
        image = QImage(width, height, QImage.Format_ARGB32)
        image.fill(Qt.transparent)
        
        painter = QPainter(image)
        painter.setRenderHint(QPainter.Antialiasing)
        
        # Use fixed dimensions for mugshot to avoid squishing
        mugshot_head_width = 120
        mugshot_head_height = 90
        
        # Center the head in the mugshot
        head_x = (width - mugshot_head_width) // 2
        head_y = (height - mugshot_head_height) // 2
        
        # Draw the complete head using the same method as main character for consistency
        # Use a dummy body width/height that matches the mugshot head proportions
        dummy_body_width = int(mugshot_head_width * 1.25)  # Slightly wider than head
        dummy_body_height = int(mugshot_head_height * 2.2)  # Much taller than head
        
        self.draw_character_head_front(painter, head_x + mugshot_head_width // 2, head_y + mugshot_head_height // 2, dummy_body_width, dummy_body_height)
        
        painter.end()
        return image
        
    # Front view methods
    def draw_character_components_front(self, painter, width, height):
        """Draw character as separate components - Front view"""
        # Calculate character dimensions based on target size
        # Scale character proportions to fit within the target dimensions
        max_character_height = int(height * 0.9)  # Leave 10% padding
        max_character_width = int(width * 0.8)    # Leave 20% padding for arms
        
        # Base character proportions (height:width ratio)
        character_ratio = 2.5  # Character is 2.5x taller than wide
        
        # Calculate actual character size that fits within target
        if max_character_height / character_ratio <= max_character_width:
            # Height is the limiting factor
            character_height = max_character_height
            character_width = int(character_height / character_ratio)
        else:
            # Width is the limiting factor
            character_width = max_character_width
            character_height = int(character_width * character_ratio)
        
        # Calculate component dimensions based on character size
        body_height = int(character_height * 0.5)  # Body is 50% of total height
        body_width = int(character_width * 0.6)    # Body is 60% of total width
        head_width = int(body_width * 0.8)         # Head is 80% of body width
        head_height = int(body_height * 0.3)       # Head is 30% of body height
        
        # Apply height/weight modifiers
        height_modifier = self.character_data['height'] / 170.0
        weight_modifier = self.character_data['weight'] / 70.0
        
        body_height = int(body_height * height_modifier)
        body_width = int(body_width * weight_modifier)
        head_width = int(head_width * weight_modifier)
        head_height = int(head_height * height_modifier)
        
        # Draw character at origin since painter is already translated to center
        base_x = 0
        base_y = 0
        
        # Draw front view with all components
        self.draw_character_head_front(painter, base_x, base_y, body_width, body_height)
        self.draw_character_body_front(painter, base_x, base_y, body_width, body_height)
        self.draw_character_arms_front(painter, base_x, base_y, body_width, body_height)
        self.draw_character_hands_front(painter, base_x, base_y, body_width, body_height)
        self.draw_character_legs_front(painter, base_x, base_y, body_width, body_height)
        self.draw_character_feet_front(painter, base_x, base_y, body_width, body_height)

    def draw_character_head_front(self, painter, base_x, base_y, body_width, body_height):
        """Draw the character's head component - Front view"""
        head_width = int(80 * (body_width / 100.0))
        head_height = int(60 * (body_height / 200.0))
        
        head_x = base_x - head_width // 2
        head_y = base_y - body_height // 2
        
        # Draw head base
        head_colors = [self.character_data['skin_color'], self.adjust_color(self.character_data['skin_color'], -15)]
        head_texture = generate_block_texture_qimage(
            head_width, head_height, head_colors, block_size=6, opacity=255, style="None", seed=self.character_data['texture_seed']
        )
        painter.drawImage(head_x, head_y, head_texture)
        
        # Draw facial features FIRST (before hair and hat to ensure they're visible)
        self.draw_character_eyes_front(painter, head_x, head_y, head_width, head_height)
        self.draw_character_mouth_front(painter, head_x, head_y, head_width, head_height)
        self.draw_character_facial_hair_front(painter, head_x, head_y, head_width, head_height)
        
        # Draw hair and hat after facial features
        self.draw_character_hair_front(painter, head_x, head_y, head_width, head_height)
        self.draw_character_hat_front(painter, head_x, head_y, head_width, head_height)

    def draw_character_body_front(self, painter, base_x, base_y, body_width, body_height):
        """Draw the character's body component - Front view"""
        torso_width = int(body_width * 0.7)
        torso_height = int(body_height * 0.4)
        head_height = int(60 * (body_height / 200.0))
        
        body_x = base_x - torso_width // 2
        body_y = base_y - body_height // 2 + head_height
        
        # Draw body base
        body_colors = [self.character_data['skin_color'], self.adjust_color(self.character_data['skin_color'], -20)]
        body_texture = generate_block_texture_qimage(
            torso_width, torso_height, body_colors, block_size=8, opacity=255, style="None", seed=self.character_data['texture_seed']
        )
        painter.drawImage(body_x, body_y, body_texture)
        
        # Draw clothing
        self.draw_character_clothing_body_front(painter, body_x, body_y, torso_width, torso_height)

    def draw_character_arms_front(self, painter, base_x, base_y, body_width, body_height):
        """Draw the character's arms component - Front view"""
        arm_width = int(body_width * 0.15)
        arm_height = int(body_height * 0.35)
        torso_width = int(body_width * 0.7)
        head_height = int(60 * (body_height / 200.0))
        
        left_arm_x = base_x - torso_width // 2 - arm_width // 2
        left_arm_y = base_y - body_height // 2 + head_height
        
        right_arm_x = base_x + torso_width // 2 - arm_width // 2
        right_arm_y = base_y - body_height // 2 + head_height
        
        # Draw arms
        arm_colors = [self.character_data['skin_color'], self.adjust_color(self.character_data['skin_color'], -25)]
        arm_texture = generate_block_texture_qimage(
            arm_width, arm_height, arm_colors, block_size=6, opacity=255, style="None", seed=self.character_data['texture_seed']
        )
        
        painter.drawImage(left_arm_x, left_arm_y, arm_texture)
        painter.drawImage(right_arm_x, right_arm_y, arm_texture)
        
        # Draw clothing
        self.draw_character_clothing_arms_front(painter, left_arm_x, left_arm_y, right_arm_x, right_arm_y, arm_width, arm_height)

    def draw_character_hands_front(self, painter, base_x, base_y, body_width, body_height):
        """Draw the character's hands component - Front view"""
        hand_width = int(body_width * 0.12)
        hand_height = int(body_height * 0.08)
        arm_width = int(body_width * 0.15)
        arm_height = int(body_height * 0.35)
        torso_width = int(body_width * 0.7)
        head_height = int(60 * (body_height / 200.0))
        
        left_hand_x = base_x - torso_width // 2 - arm_width // 2 - hand_width // 2
        left_hand_y = base_y - body_height // 2 + head_height + arm_height
        
        right_hand_x = base_x + torso_width // 2 + arm_width // 2 - hand_width // 2
        right_hand_y = base_y - body_height // 2 + head_height + arm_height
        
        # Draw hands
        hand_colors = [self.character_data['skin_color'], self.adjust_color(self.character_data['skin_color'], -10)]
        hand_texture = generate_block_texture_qimage(
            hand_width, hand_height, hand_colors, block_size=4, opacity=255, style="None", seed=self.character_data['texture_seed']
        )
        
        painter.drawImage(left_hand_x, left_hand_y, hand_texture)
        painter.drawImage(right_hand_x, right_hand_y, hand_texture)

    def draw_character_legs_front(self, painter, base_x, base_y, body_width, body_height):
        """Draw the character's legs component - Front view"""
        leg_width = int(body_width * 0.2)
        leg_height = int(body_height * 0.4)
        torso_width = int(body_width * 0.7)
        torso_height = int(body_height * 0.4)
        head_height = int(60 * (body_height / 200.0))
        
        left_leg_x = base_x - torso_width // 4 - leg_width // 2
        left_leg_y = base_y - body_height // 2 + head_height + torso_height
        
        right_leg_x = base_x + torso_width // 4 - leg_width // 2
        right_leg_y = base_y - body_height // 2 + head_height + torso_height
        
        # Draw legs
        leg_colors = [self.character_data['skin_color'], self.adjust_color(self.character_data['skin_color'], -30)]
        leg_texture = generate_block_texture_qimage(
            leg_width, leg_height, leg_colors, block_size=7, opacity=255, style="None", seed=self.character_data['texture_seed']
        )
        
        painter.drawImage(left_leg_x, left_leg_y, leg_texture)
        painter.drawImage(right_leg_x, right_leg_y, leg_texture)
        
        # Draw clothing
        self.draw_character_clothing_legs_front(painter, left_leg_x, left_leg_y, right_leg_x, right_leg_y, leg_width, leg_height)

    def draw_character_feet_front(self, painter, base_x, base_y, body_width, body_height):
        """Draw the character's feet component - Front view"""
        foot_width = int(body_width * 0.15)
        foot_height = int(body_height * 0.08)
        leg_width = int(body_width * 0.2)
        leg_height = int(body_height * 0.4)
        torso_width = int(body_width * 0.7)
        torso_height = int(body_height * 0.4)
        head_height = int(60 * (body_height / 200.0))
        
        left_foot_x = base_x - torso_width // 4 - foot_width // 2
        left_foot_y = base_y - body_height // 2 + head_height + torso_height + leg_height
        
        right_foot_x = base_x + torso_width // 4 - foot_width // 2
        right_foot_y = base_y - body_height // 2 + head_height + torso_height + leg_height
        
        # Draw feet
        foot_colors = [self.character_data['skin_color'], self.adjust_color(self.character_data['skin_color'], -5)]
        foot_texture = generate_block_texture_qimage(
            foot_width, foot_height, foot_colors, block_size=3, opacity=255, style="None", seed=self.character_data['texture_seed']
        )
        
        painter.drawImage(left_foot_x, left_foot_y, foot_texture)
        painter.drawImage(right_foot_x, right_foot_y, foot_texture)
        
        # Draw shoes
        self.draw_character_shoes_front(painter, left_foot_x, left_foot_y, right_foot_x, right_foot_y, foot_width, foot_height)
        
    # Facial features and clothing drawing methods
    def draw_character_eyes_front(self, painter, head_x, head_y, head_width, head_height):
        """Draw eyes on the character's head - Front view"""
        eye_width = head_width // 3
        eye_height = head_height // 3
        eye_y = head_y + head_height // 3
        
        # Left eye
        left_eye_x = head_x + head_width // 4 - eye_width // 2
        eye_colors = [self.character_data['eye_color'], self.adjust_color(self.character_data['eye_color'], -20)]
        eye_texture = generate_block_texture_qimage(
            eye_width, eye_height, eye_colors, block_size=2, opacity=255, style="None", seed=self.character_data['texture_seed']
        )
        painter.drawImage(left_eye_x, eye_y, eye_texture)
        
        # Right eye
        right_eye_x = head_x + 3 * head_width // 4 - eye_width // 2
        painter.drawImage(right_eye_x, eye_y, eye_texture)

    def draw_character_mouth_front(self, painter, head_x, head_y, head_width, head_height):
        """Draw mouth on the character's head - Front view"""
        mouth_width = head_width // 3
        mouth_height = head_height // 6
        mouth_x = head_x + head_width // 2 - mouth_width // 2
        mouth_y = head_y + 2 * head_height // 3
        
        mouth_colors = ['#8B0000', '#660000']
        mouth_texture = generate_block_texture_qimage(
            mouth_width, mouth_height, mouth_colors, block_size=2, opacity=255, style="None", seed=self.character_data['texture_seed']
        )
        painter.drawImage(mouth_x, mouth_y, mouth_texture)

    def draw_character_facial_hair_front(self, painter, head_x, head_y, head_width, head_height):
        """Draw facial hair on the character's head - Front view"""
        if self.character_data['facial_hair'] == 'None':
            return
            
        facial_hair_width = head_width // 2
        facial_hair_height = head_height // 5
        facial_hair_x = head_x + head_width // 2 - facial_hair_width // 2
        facial_hair_y = head_y + head_height // 2
        
        facial_hair_colors = [self.character_data['facial_hair_color'], self.adjust_color(self.character_data['facial_hair_color'], -15)]
        facial_hair_texture = generate_block_texture_qimage(
            facial_hair_width, facial_hair_height, facial_hair_colors, block_size=4, opacity=255, style="None", seed=self.character_data['texture_seed']
        )
        painter.drawImage(facial_hair_x, facial_hair_y, facial_hair_texture)

    def draw_character_hair_front(self, painter, head_x, head_y, head_width, head_height):
        """Draw hair on the character's head - Front view"""
        if self.character_data['hair_style'] == 'Bald':
            return
            
        hair_width = int(head_width * 1.1)
        hair_height = int(head_height * 0.6)
        hair_x = head_x - (hair_width - head_width) // 2
        # Position hair higher up to avoid covering facial features
        hair_y = head_y - int(head_height * 0.1)
        
        hair_colors = [self.character_data['hair_color'], self.adjust_color(self.character_data['hair_color'], -20)]
        hair_texture = generate_block_texture_qimage(
            hair_width, hair_height, hair_colors, block_size=5, opacity=255, style="None", seed=self.character_data['texture_seed']
        )
        painter.drawImage(hair_x, hair_y, hair_texture)

    def draw_character_hat_front(self, painter, head_x, head_y, head_width, head_height):
        """Draw hat on the character's head - Front view"""
        if self.character_data['clothing']['hat'] == 'None':
            return
            
        hat_width = int(head_width * 1.2)
        hat_height = int(head_height * 0.4)
        hat_x = head_x - (hat_width - head_width) // 2
        # Position hat above the head, not covering the face
        hat_y = head_y - hat_height + 5
        
        hat_colors = ['#8B4513', '#654321']
        hat_texture = generate_block_texture_qimage(
            hat_width, hat_height, hat_colors, block_size=6, opacity=255, style="None", seed=self.character_data['texture_seed']
        )
        painter.drawImage(hat_x, hat_y, hat_texture)

    def draw_character_clothing_body_front(self, painter, body_x, body_y, torso_width, torso_height):
        """Draw clothing on the character's body - Front view"""
        # Shirt
        shirt_colors = [self.character_data['clothing']['shirt_color'], self.adjust_color(self.character_data['clothing']['shirt_color'], -15)]
        shirt_texture = generate_block_texture_qimage(
            torso_width, torso_height, shirt_colors, block_size=7, opacity=255, style="None", seed=self.character_data['texture_seed']
        )
        painter.drawImage(body_x, body_y, shirt_texture)
        
        # Jacket (if any)
        if self.character_data['clothing']['jacket'] != 'None':
            jacket_colors = ['#2F4F4F', '#1C2F2F']
            jacket_texture = generate_block_texture_qimage(
                torso_width, torso_height, jacket_colors, block_size=8, opacity=200, style="None", seed=self.character_data['texture_seed']
            )
            painter.drawImage(body_x, body_y, jacket_texture)

    def draw_character_clothing_arms_front(self, painter, left_arm_x, left_arm_y, right_arm_x, right_arm_y, arm_width, arm_height):
        """Draw clothing on the character's arms - Front view"""
        # Shirt sleeves
        shirt_colors = [self.character_data['clothing']['shirt_color'], self.adjust_color(self.character_data['clothing']['shirt_color'], -15)]
        shirt_texture = generate_block_texture_qimage(
            arm_width, arm_height, shirt_colors, block_size=5, opacity=255, style="None", seed=self.character_data['texture_seed']
        )
        painter.drawImage(left_arm_x, left_arm_y, shirt_texture)
        painter.drawImage(right_arm_x, right_arm_y, shirt_texture)

    def draw_character_clothing_legs_front(self, painter, left_leg_x, left_leg_y, right_leg_x, right_leg_y, leg_width, leg_height):
        """Draw clothing on the character's legs - Front view"""
        # Pants
        pants_colors = [self.character_data['clothing']['pants_color'], self.adjust_color(self.character_data['clothing']['pants_color'], -15)]
        pants_texture = generate_block_texture_qimage(
            leg_width, leg_height, pants_colors, block_size=7, opacity=255, style="None", seed=self.character_data['texture_seed']
        )
        painter.drawImage(left_leg_x, left_leg_y, pants_texture)
        painter.drawImage(right_leg_x, right_leg_y, pants_texture)

    def draw_character_shoes_front(self, painter, left_foot_x, left_foot_y, right_foot_x, right_foot_y, foot_width, foot_height):
        """Draw shoes on the character's feet - Front view"""
        if self.character_data['clothing']['shoes'] == 'Barefoot':
            return
            
        # Make shoes larger to cover feet
        shoe_width = int(foot_width * 1.1)
        shoe_height = int(foot_height * 1.2)
        
        left_shoe_x = left_foot_x - (shoe_width - foot_width) // 2
        left_shoe_y = left_foot_y - (shoe_height - foot_height) // 2
        
        right_shoe_x = right_foot_x - (shoe_width - foot_width) // 2
        right_shoe_y = right_foot_y - (shoe_height - foot_height) // 2
        
        shoe_colors = [self.character_data['clothing']['shoes_color'], self.adjust_color(self.character_data['clothing']['shoes_color'], -20)]
        shoe_texture = generate_block_texture_qimage(
            shoe_width, shoe_height, shoe_colors, block_size=6, opacity=255, style="None", seed=self.character_data['texture_seed']
        )
        painter.drawImage(left_shoe_x, left_shoe_y, shoe_texture)
        painter.drawImage(right_shoe_x, right_shoe_y, shoe_texture)

    # Back view methods (simplified)
    def draw_character_components_back(self, painter, width, height):
        """Draw character as separate components - Back view"""
        # Calculate character dimensions based on target size
        # Scale character proportions to fit within the target dimensions
        max_character_height = int(height * 0.9)  # Leave 10% padding
        max_character_width = int(width * 0.8)    # Leave 20% padding for arms
        
        # Base character proportions (height:width ratio)
        character_ratio = 2.5  # Character is 2.5x taller than wide
        
        # Calculate actual character size that fits within target
        if max_character_height / character_ratio <= max_character_width:
            # Height is the limiting factor
            character_height = max_character_height
            character_width = int(character_height / character_ratio)
        else:
            # Width is the limiting factor
            character_width = max_character_width
            character_height = int(character_width * character_ratio)
        
        # Calculate component dimensions based on character size
        body_height = int(character_height * 0.5)  # Body is 50% of total height
        body_width = int(character_width * 0.6)    # Body is 60% of total width
        head_width = int(body_width * 0.8)         # Head is 80% of body width
        head_height = int(body_height * 0.3)       # Head is 30% of body height
        
        # Apply height/weight modifiers
        height_modifier = self.character_data['height'] / 170.0
        weight_modifier = self.character_data['weight'] / 70.0
        
        body_height = int(body_height * height_modifier)
        body_width = int(body_width * weight_modifier)
        head_width = int(head_width * weight_modifier)
        head_height = int(head_height * height_modifier)
        
        # Draw character at origin since painter is already translated to center
        base_x = 0
        base_y = 0
        
        # Draw back view with all components
        self.draw_character_head_back(painter, base_x, base_y, body_width, body_height)
        self.draw_character_body_back(painter, base_x, base_y, body_width, body_height)
        self.draw_character_arms_back(painter, base_x, base_y, body_width, body_height)
        self.draw_character_hands_back(painter, base_x, base_y, body_width, body_height)
        self.draw_character_legs_back(painter, base_x, base_y, body_width, body_height)
        self.draw_character_feet_back(painter, base_x, base_y, body_width, body_height)

    def draw_character_head_back(self, painter, base_x, base_y, body_width, body_height):
        """Draw the character's head component - Back view"""
        head_width = int(80 * (body_width / 100.0))
        head_height = int(60 * (body_height / 200.0))
        
        head_x = base_x - head_width // 2
        head_y = base_y - body_height // 2
        
        # Draw head base
        head_colors = [self.character_data['skin_color'], self.adjust_color(self.character_data['skin_color'], -15)]
        head_texture = generate_block_texture_qimage(
            head_width, head_height, head_colors, block_size=6, opacity=255, style="None", seed=self.character_data['texture_seed']
        )
        painter.drawImage(head_x, head_y, head_texture)
        
        # Draw hair and hat (no facial features in back view)
        self.draw_character_hair_back(painter, head_x, head_y, head_width, head_height)
        self.draw_character_hat_back(painter, head_x, head_y, head_width, head_height)

    def draw_character_body_back(self, painter, base_x, base_y, body_width, body_height):
        """Draw the character's body component - Back view"""
        torso_width = int(body_width * 0.7)
        torso_height = int(body_height * 0.4)
        head_height = int(60 * (body_height / 200.0))
        
        body_x = base_x - torso_width // 2
        body_y = base_y - body_height // 2 + head_height
        
        # Draw body base
        body_colors = [self.character_data['skin_color'], self.adjust_color(self.character_data['skin_color'], -20)]
        body_texture = generate_block_texture_qimage(
            torso_width, torso_height, body_colors, block_size=8, opacity=255, style="None", seed=self.character_data['texture_seed']
        )
        painter.drawImage(body_x, body_y, body_texture)
        
        # Draw clothing
        self.draw_character_clothing_body_back(painter, body_x, body_y, torso_width, torso_height)

    def draw_character_arms_back(self, painter, base_x, base_y, body_width, body_height):
        """Draw the character's arms component - Back view"""
        arm_width = int(body_width * 0.15)
        arm_height = int(body_height * 0.35)
        torso_width = int(body_width * 0.7)
        head_height = int(60 * (body_height / 200.0))
        
        left_arm_x = base_x - torso_width // 2 - arm_width // 2
        left_arm_y = base_y - body_height // 2 + head_height
        
        right_arm_x = base_x + torso_width // 2 - arm_width // 2
        right_arm_y = base_y - body_height // 2 + head_height
        
        # Draw arms
        arm_colors = [self.character_data['skin_color'], self.adjust_color(self.character_data['skin_color'], -25)]
        arm_texture = generate_block_texture_qimage(
            arm_width, arm_height, arm_colors, block_size=6, opacity=255, style="None", seed=self.character_data['texture_seed']
        )
        
        painter.drawImage(left_arm_x, left_arm_y, arm_texture)
        painter.drawImage(right_arm_x, right_arm_y, arm_texture)
        
        # Draw clothing
        self.draw_character_clothing_arms_back(painter, left_arm_x, left_arm_y, right_arm_x, right_arm_y, arm_width, arm_height)

    def draw_character_hands_back(self, painter, base_x, base_y, body_width, body_height):
        """Draw the character's hands component - Back view"""
        hand_width = int(body_width * 0.12)
        hand_height = int(body_height * 0.08)
        arm_width = int(body_width * 0.15)
        arm_height = int(body_height * 0.35)
        torso_width = int(body_width * 0.7)
        head_height = int(60 * (body_height / 200.0))
        
        left_hand_x = base_x - torso_width // 2 - arm_width // 2 - hand_width // 2
        left_hand_y = base_y - body_height // 2 + head_height + arm_height
        
        right_hand_x = base_x + torso_width // 2 + arm_width // 2 - hand_width // 2
        right_hand_y = base_y - body_height // 2 + head_height + arm_height
        
        # Draw hands
        hand_colors = [self.character_data['skin_color'], self.adjust_color(self.character_data['skin_color'], -10)]
        hand_texture = generate_block_texture_qimage(
            hand_width, hand_height, hand_colors, block_size=4, opacity=255, style="None", seed=self.character_data['texture_seed']
        )
        
        painter.drawImage(left_hand_x, left_hand_y, hand_texture)
        painter.drawImage(right_hand_x, right_hand_y, hand_texture)

    def draw_character_legs_back(self, painter, base_x, base_y, body_width, body_height):
        """Draw the character's legs component - Back view"""
        leg_width = int(body_width * 0.2)
        leg_height = int(body_height * 0.4)
        torso_width = int(body_width * 0.7)
        torso_height = int(body_height * 0.4)
        head_height = int(60 * (body_height / 200.0))
        
        left_leg_x = base_x - torso_width // 4 - leg_width // 2
        left_leg_y = base_y - body_height // 2 + head_height + torso_height
        
        right_leg_x = base_x + torso_width // 4 - leg_width // 2
        right_leg_y = base_y - body_height // 2 + head_height + torso_height
        
        # Draw legs
        leg_colors = [self.character_data['skin_color'], self.adjust_color(self.character_data['skin_color'], -30)]
        leg_texture = generate_block_texture_qimage(
            leg_width, leg_height, leg_colors, block_size=7, opacity=255, style="None", seed=self.character_data['texture_seed']
        )
        
        painter.drawImage(left_leg_x, left_leg_y, leg_texture)
        painter.drawImage(right_leg_x, right_leg_y, leg_texture)
        
        # Draw clothing
        self.draw_character_clothing_legs_back(painter, left_leg_x, left_leg_y, right_leg_x, right_leg_y, leg_width, leg_height)

    def draw_character_feet_back(self, painter, base_x, base_y, body_width, body_height):
        """Draw the character's feet component - Back view"""
        foot_width = int(body_width * 0.15)
        foot_height = int(body_height * 0.08)
        leg_width = int(body_width * 0.2)
        leg_height = int(body_height * 0.4)
        torso_width = int(body_width * 0.7)
        torso_height = int(body_height * 0.4)
        head_height = int(60 * (body_height / 200.0))
        
        left_foot_x = base_x - torso_width // 4 - foot_width // 2
        left_foot_y = base_y - body_height // 2 + head_height + torso_height + leg_height
        
        right_foot_x = base_x + torso_width // 4 - foot_width // 2
        right_foot_y = base_y - body_height // 2 + head_height + torso_height + leg_height
        
        # Draw feet
        foot_colors = [self.character_data['skin_color'], self.adjust_color(self.character_data['skin_color'], -5)]
        foot_texture = generate_block_texture_qimage(
            foot_width, foot_height, foot_colors, block_size=3, opacity=255, style="None", seed=self.character_data['texture_seed']
        )
        
        painter.drawImage(left_foot_x, left_foot_y, foot_texture)
        painter.drawImage(right_foot_x, right_foot_y, foot_texture)
        
        # Draw shoes
        self.draw_character_shoes_back(painter, left_foot_x, left_foot_y, right_foot_x, right_foot_y, foot_width, foot_height)

    def draw_character_hair_back(self, painter, head_x, head_y, head_width, head_height):
        """Draw hair on the character's head - Back view"""
        if self.character_data['hair_style'] == 'Bald':
            return
            
        hair_width = int(head_width * 1.1)
        hair_height = int(head_height * 0.7)
        hair_x = head_x - (hair_width - head_width) // 2
        # Position hair at the same level as front view for consistency
        hair_y = head_y - int(head_height * 0.1)
        
        hair_colors = [self.character_data['hair_color'], self.adjust_color(self.character_data['hair_color'], -20)]
        hair_texture = generate_block_texture_qimage(
            hair_width, hair_height, hair_colors, block_size=5, opacity=255, style="None", seed=self.character_data['texture_seed']
        )
        painter.drawImage(hair_x, hair_y, hair_texture)

    def draw_character_hat_back(self, painter, head_x, head_y, head_width, head_height):
        """Draw hat on the character's head - Back view"""
        if self.character_data['clothing']['hat'] == 'None':
            return
            
        hat_width = int(head_width * 1.2)
        hat_height = int(head_height * 0.4)
        hat_x = head_x - (hat_width - head_width) // 2
        hat_y = head_y - hat_height // 2
        
        hat_colors = ['#8B4513', '#654321']
        hat_texture = generate_block_texture_qimage(
            hat_width, hat_height, hat_colors, block_size=6, opacity=255, style="None", seed=self.character_data['texture_seed']
        )
        painter.drawImage(hat_x, hat_y, hat_texture)

    def draw_character_clothing_body_back(self, painter, body_x, body_y, torso_width, torso_height):
        """Draw clothing on the character's body - Back view"""
        # Shirt
        shirt_colors = [self.character_data['clothing']['shirt_color'], self.adjust_color(self.character_data['clothing']['shirt_color'], -15)]
        shirt_texture = generate_block_texture_qimage(
            torso_width, torso_height, shirt_colors, block_size=7, opacity=255, style="None", seed=self.character_data['texture_seed']
        )
        painter.drawImage(body_x, body_y, shirt_texture)
        
        # Jacket (if any)
        if self.character_data['clothing']['jacket'] != 'None':
            jacket_colors = ['#2F4F4F', '#1C2F2F']
            jacket_texture = generate_block_texture_qimage(
                torso_width, torso_height, jacket_colors, block_size=8, opacity=200, style="None", seed=self.character_data['texture_seed']
            )
            painter.drawImage(body_x, body_y, jacket_texture)

    def draw_character_clothing_arms_back(self, painter, left_arm_x, left_arm_y, right_arm_x, right_arm_y, arm_width, arm_height):
        """Draw clothing on the character's arms - Back view"""
        # Shirt sleeves
        shirt_colors = [self.character_data['clothing']['shirt_color'], self.adjust_color(self.character_data['clothing']['shirt_color'], -15)]
        shirt_texture = generate_block_texture_qimage(
            arm_width, arm_height, shirt_colors, block_size=5, opacity=255, style="None", seed=self.character_data['texture_seed']
        )
        painter.drawImage(left_arm_x, left_arm_y, shirt_texture)
        painter.drawImage(right_arm_x, right_arm_y, shirt_texture)

    def draw_character_clothing_legs_back(self, painter, left_leg_x, left_leg_y, right_leg_x, right_leg_y, leg_width, leg_height):
        """Draw clothing on the character's legs - Back view"""
        # Pants
        pants_colors = [self.character_data['clothing']['pants_color'], self.adjust_color(self.character_data['clothing']['pants_color'], -15)]
        pants_texture = generate_block_texture_qimage(
            leg_width, leg_height, pants_colors, block_size=7, opacity=255, style="None", seed=self.character_data['texture_seed']
        )
        painter.drawImage(left_leg_x, left_leg_y, pants_texture)
        painter.drawImage(right_leg_x, right_leg_y, pants_texture)

    def draw_character_shoes_back(self, painter, left_foot_x, left_foot_y, right_foot_x, right_foot_y, foot_width, foot_height):
        """Draw shoes on the character's feet - Back view"""
        if self.character_data['clothing']['shoes'] == 'Barefoot':
            return
            
        # Make shoes larger to cover feet
        shoe_width = int(foot_width * 1.1)
        shoe_height = int(foot_height * 1.2)
        
        left_shoe_x = left_foot_x - (shoe_width - foot_width) // 2
        left_shoe_y = left_foot_y - (shoe_height - foot_height) // 2
        
        right_shoe_x = right_foot_x - (shoe_width - foot_width) // 2
        right_shoe_y = right_foot_y - (shoe_height - foot_height) // 2
        
        shoe_colors = [self.character_data['clothing']['shoes_color'], self.adjust_color(self.character_data['clothing']['shoes_color'], -20)]
        shoe_texture = generate_block_texture_qimage(
            shoe_width, shoe_height, shoe_colors, block_size=6, opacity=255, style="None", seed=self.character_data['texture_seed']
        )
        painter.drawImage(left_shoe_x, left_shoe_y, shoe_texture)
        painter.drawImage(right_shoe_x, right_shoe_y, shoe_texture)

    # Side view methods (simplified)
    def draw_character_components_side(self, painter, width, height, side):
        """Draw character as separate components - Side view"""
        # Calculate character dimensions based on target size
        # Scale character proportions to fit within the target dimensions
        max_character_height = int(height * 0.9)  # Leave 10% padding
        max_character_width = int(width * 0.8)    # Leave 20% padding for arms
        
        # Base character proportions (height:width ratio)
        character_ratio = 2.5  # Character is 2.5x taller than wide
        
        # Calculate actual character size that fits within target
        if max_character_height / character_ratio <= max_character_width:
            # Height is the limiting factor
            character_height = max_character_height
            character_width = int(character_height / character_ratio)
        else:
            # Width is the limiting factor
            character_width = max_character_width
            character_height = int(character_width * character_ratio)
        
        # Calculate component dimensions based on character size
        body_height = int(character_height * 0.5)  # Body is 50% of total height
        body_width = int(character_width * 0.6)    # Body is 60% of total width
        head_width = int(body_width * 0.8)         # Head is 80% of body width
        head_height = int(body_height * 0.3)       # Head is 30% of body height
        
        # Apply height/weight modifiers
        height_modifier = self.character_data['height'] / 170.0
        weight_modifier = self.character_data['weight'] / 70.0
        
        body_height = int(body_height * height_modifier)
        body_width = int(body_width * weight_modifier)
        head_width = int(head_width * weight_modifier)
        head_height = int(head_height * height_modifier)
        
        # Draw character at origin since painter is already translated to center
        base_x = 0
        base_y = 0
        
        # Draw side view with all components
        self.draw_character_head_side(painter, base_x, base_y, body_width, body_height, side)
        self.draw_character_body_side(painter, base_x, base_y, body_width, body_height, side)
        self.draw_character_arms_side(painter, base_x, base_y, body_width, body_height, side)
        self.draw_character_hands_side(painter, base_x, base_y, body_width, body_height, side)
        self.draw_character_legs_side(painter, base_x, base_y, body_width, body_height, side)
        self.draw_character_feet_side(painter, base_x, base_y, body_width, body_height, side)

    def draw_character_head_side(self, painter, base_x, base_y, body_width, body_height, side):
        """Draw the character's head component - Side view"""
        head_width = int(80 * (body_width / 100.0))
        head_height = int(60 * (body_height / 200.0))
        
        head_x = base_x - head_width // 2
        head_y = base_y - body_height // 2
        
        # Draw head base
        head_colors = [self.character_data['skin_color'], self.adjust_color(self.character_data['skin_color'], -15)]
        head_texture = generate_block_texture_qimage(
            head_width, head_height, head_colors, block_size=6, opacity=255, style="None", seed=self.character_data['texture_seed']
        )
        painter.drawImage(head_x, head_y, head_texture)
        
        # Draw side view features in correct order (hair first, then facial features on top)
        self.draw_character_hair_side(painter, head_x, head_y, head_width, head_height, side)
        self.draw_character_ear_side(painter, head_x, head_y, head_width, head_height, side)
        self.draw_character_eyes_side(painter, head_x, head_y, head_width, head_height, side)
        self.draw_character_mouth_side(painter, head_x, head_y, head_width, head_height, side)
        self.draw_character_facial_hair_side(painter, head_x, head_y, head_width, head_height, side)
        self.draw_character_hat_side(painter, head_x, head_y, head_width, head_height, side)

    def draw_character_body_side(self, painter, base_x, base_y, body_width, body_height, side):
        """Draw the character's body component - Side view"""
        torso_width = int(body_width * 0.7)
        torso_height = int(body_height * 0.4)
        head_height = int(60 * (body_height / 200.0))
        
        body_x = base_x - torso_width // 2
        body_y = base_y - body_height // 2 + head_height
        
        # Draw body base
        body_colors = [self.character_data['skin_color'], self.adjust_color(self.character_data['skin_color'], -20)]
        body_texture = generate_block_texture_qimage(
            torso_width, torso_height, body_colors, block_size=8, opacity=255, style="None", seed=self.character_data['texture_seed']
        )
        painter.drawImage(body_x, body_y, body_texture)
        
        # Draw clothing
        self.draw_character_clothing_body_side(painter, body_x, body_y, torso_width, torso_height, side)

    def draw_character_arms_side(self, painter, base_x, base_y, body_width, body_height, side):
        """Draw the character's arms component - Side view"""
        arm_width = int(body_width * 0.15)
        arm_height = int(body_height * 0.35)
        torso_width = int(body_width * 0.7)
        head_height = int(60 * (body_height / 200.0))
        
        # Position arm based on side
        if side == 'left':
            arm_x = base_x - torso_width // 2 - arm_width // 2
        else:  # right
            arm_x = base_x + torso_width // 2 - arm_width // 2
            
        arm_y = base_y - body_height // 2 + head_height
        
        # Draw arm
        arm_colors = [self.character_data['skin_color'], self.adjust_color(self.character_data['skin_color'], -25)]
        arm_texture = generate_block_texture_qimage(
            arm_width, arm_height, arm_colors, block_size=6, opacity=255, style="None", seed=self.character_data['texture_seed']
        )
        painter.drawImage(arm_x, arm_y, arm_texture)
        
        # Draw clothing
        self.draw_character_clothing_arms_side(painter, arm_x, arm_y, arm_width, arm_height, side)

    def draw_character_hands_side(self, painter, base_x, base_y, body_width, body_height, side):
        """Draw the character's hands component - Side view"""
        hand_width = int(body_width * 0.12)
        hand_height = int(body_height * 0.08)
        arm_width = int(body_width * 0.15)
        arm_height = int(body_height * 0.35)
        torso_width = int(body_width * 0.7)
        head_height = int(60 * (body_height / 200.0))
        
        # Position hand based on side
        if side == 'left':
            hand_x = base_x - torso_width // 2 - arm_width // 2 - hand_width // 2
        else:  # right
            hand_x = base_x + torso_width // 2 + arm_width // 2 - hand_width // 2
            
        hand_y = base_y - body_height // 2 + head_height + arm_height
        
        # Draw hand
        hand_colors = [self.character_data['skin_color'], self.adjust_color(self.character_data['skin_color'], -10)]
        hand_texture = generate_block_texture_qimage(
            hand_width, hand_height, hand_colors, block_size=4, opacity=255, style="None", seed=self.character_data['texture_seed']
        )
        painter.drawImage(hand_x, hand_y, hand_texture)

    def draw_character_legs_side(self, painter, base_x, base_y, body_width, body_height, side):
        """Draw the character's legs component - Side view"""
        leg_width = int(body_width * 0.2)
        leg_height = int(body_height * 0.4)
        torso_width = int(body_width * 0.7)
        torso_height = int(body_height * 0.4)
        head_height = int(60 * (body_height / 200.0))
        
        # Draw two legs for depth perception
        back_leg_x = base_x - torso_width // 3 - leg_width // 2
        front_leg_x = base_x + torso_width // 6 - leg_width // 2
        leg_y = base_y - body_height // 2 + head_height + torso_height
        
        # Draw back leg (smaller, more transparent)
        back_leg_colors = [self.character_data['skin_color'], self.adjust_color(self.character_data['skin_color'], -30)]
        back_leg_texture = generate_block_texture_qimage(
            int(leg_width * 0.8), leg_height, back_leg_colors, block_size=8, opacity=150, style="None", seed=self.character_data['texture_seed']
        )
        painter.drawImage(back_leg_x, leg_y, back_leg_texture)
        
        # Draw front leg (larger, opaque)
        front_leg_colors = [self.character_data['skin_color'], self.adjust_color(self.character_data['skin_color'], -30)]
        front_leg_texture = generate_block_texture_qimage(
            leg_width, leg_height, front_leg_colors, block_size=8, opacity=255, style="None", seed=self.character_data['texture_seed']
        )
        painter.drawImage(front_leg_x, leg_y, front_leg_texture)
        
        # Draw clothing
        self.draw_character_clothing_legs_side(painter, back_leg_x, leg_y, int(leg_width * 0.8), leg_height, side, is_back_leg=True)
        self.draw_character_clothing_legs_side(painter, front_leg_x, leg_y, leg_width, leg_height, side, is_back_leg=False)

    def draw_character_feet_side(self, painter, base_x, base_y, body_width, body_height, side):
        """Draw the character's feet component - Side view"""
        foot_width = int(body_width * 0.25)
        foot_height = int(body_height * 0.12)
        leg_width = int(body_width * 0.2)
        leg_height = int(body_height * 0.4)
        torso_width = int(body_width * 0.7)
        torso_height = int(body_height * 0.4)
        head_height = int(60 * (body_height / 200.0))
        
        # Draw two feet for depth perception
        back_foot_x = base_x - torso_width // 3 - foot_width // 2
        front_foot_x = base_x + torso_width // 6 - foot_width // 2
        foot_y = base_y - body_height // 2 + head_height + torso_height + leg_height
        
        # Draw back foot (smaller, more transparent)
        back_foot_colors = [self.character_data['skin_color'], self.adjust_color(self.character_data['skin_color'], -35)]
        back_foot_texture = generate_block_texture_qimage(
            int(foot_width * 0.8), foot_height, back_foot_colors, block_size=6, opacity=150, style="None", seed=self.character_data['texture_seed']
        )
        painter.drawImage(back_foot_x, foot_y, back_foot_texture)
        
        # Draw front foot (larger, opaque)
        front_foot_colors = [self.character_data['skin_color'], self.adjust_color(self.character_data['skin_color'], -35)]
        front_foot_texture = generate_block_texture_qimage(
            foot_width, foot_height, front_foot_colors, block_size=6, opacity=255, style="None", seed=self.character_data['texture_seed']
        )
        painter.drawImage(front_foot_x, foot_y, front_foot_texture)
        
        # Draw shoes
        self.draw_character_shoes_side(painter, back_foot_x, foot_y, int(foot_width * 0.8), foot_height, side, is_back_foot=True)
        self.draw_character_shoes_side(painter, front_foot_x, foot_y, foot_width, foot_height, side, is_back_foot=False)

    # Side view feature methods
    def draw_character_eyes_side(self, painter, head_x, head_y, head_width, head_height, side):
        """Draw single eye for side view"""
        eye_width = head_width // 4
        eye_height = head_height // 4
        eye_y = head_y + head_height // 3
        
        # Position eye much more forward on the face, not too far back
        if side == 'left':
            eye_x = head_x + int(head_width * 0.92) - eye_width // 2  # Even more forward on right side of head
        else:  # right
            eye_x = head_x + int(head_width * 0.08) - eye_width // 2  # Even more forward on left side of head
        
        # Use the actual eye color from character data
        eye_colors = [self.character_data['eye_color'], self.adjust_color(self.character_data['eye_color'], -20)]
        eye_texture = generate_block_texture_qimage(
            eye_width, eye_height, eye_colors, block_size=2, opacity=255, style="None", seed=self.character_data['texture_seed']
        )
        painter.drawImage(eye_x, eye_y, eye_texture)

    def draw_character_mouth_side(self, painter, head_x, head_y, head_width, head_height, side):
        """Draw mouth for side view"""
        # Make mouth smaller and more subtle for side view
        mouth_width = head_width // 12
        mouth_height = head_height // 20
        
        # Position mouth much more forward on the visible side of the face, not covered by hair
        if side == 'left':
            mouth_x = head_x + int(head_width * 0.95)  # Even more forward on right side of head (visible)
        else:  # right
            mouth_x = head_x + int(head_width * 0.05)  # Even more forward on left side of head (visible)
            
        mouth_y = head_y + int(head_height * 0.6)
        
        mouth_colors = ['#8B0000', '#660000']
        mouth_texture = generate_block_texture_qimage(
            mouth_width, mouth_height, mouth_colors, block_size=1, opacity=120, style="None", seed=self.character_data['texture_seed']
        )
        painter.drawImage(mouth_x, mouth_y, mouth_texture)

    def draw_character_facial_hair_side(self, painter, head_x, head_y, head_width, head_height, side):
        """Draw facial hair for side view"""
        if self.character_data['facial_hair'] == 'None':
            return
            
        facial_hair_width = head_width // 3
        facial_hair_height = head_height // 6
        facial_hair_x = head_x + head_width // 2 - facial_hair_width // 2
        facial_hair_y = head_y + head_height // 2
        
        facial_hair_colors = [self.character_data['facial_hair_color'], self.adjust_color(self.character_data['facial_hair_color'], -15)]
        facial_hair_texture = generate_block_texture_qimage(
            facial_hair_width, facial_hair_height, facial_hair_colors, block_size=4, opacity=255, style="None", seed=self.character_data['texture_seed']
        )
        painter.drawImage(facial_hair_x, facial_hair_y, facial_hair_texture)

    def draw_character_hair_side(self, painter, head_x, head_y, head_width, head_height, side):
        """Draw hair on the character's head - Side view with formula based on hair style"""
        if self.character_data['hair_style'] == 'Bald':
            return
            
        hair_style = self.character_data['hair_style']
        hair_colors = [self.character_data['hair_color'], self.adjust_color(self.character_data['hair_color'], -20)]
        
        # Base hair dimensions from front/back views
        front_hair_width = int(head_width * 1.1)
        front_hair_height = int(head_height * 0.6)
        back_hair_width = int(head_width * 1.1)
        back_hair_height = int(head_height * 0.7)
        
        # Calculate side hair based on hair style and front/back dimensions
        if hair_style == 'Short':
            # Short hair: compact, doesn't extend much beyond head
            side_hair_width = head_width  # Same width as head to prevent bowl cut look
            side_hair_height = int(head_height * 0.5)  # Slightly taller
            side_hair_x_offset = int(head_width * 0.02)  # Much less offset to move hair forward
            side_hair_y_offset = int(head_height * 0.02)  # Less offset to move hair up
            block_size = 3
            opacity = 255
            
        elif hair_style == 'Long':
            # Long hair: extends down and flows naturally
            side_hair_width = head_width  # Same width as head to prevent bowl cut look
            side_hair_height = int(head_height * 1.2)  # Extends below head
            side_hair_x_offset = int(head_width * 0.01)  # Much less offset to move hair forward
            side_hair_y_offset = int(head_height * 0.05)  # Less offset to move hair up
            block_size = 4
            opacity = 240
            
        elif hair_style == 'Spiky':
            # Spiky hair: angular, pointed sections
            side_hair_width = head_width  # Same width as head to prevent bowl cut look
            side_hair_height = int(head_height * 0.7)  # Slightly taller
            side_hair_x_offset = int(head_width * 0.03)  # Much less offset to move hair forward
            side_hair_y_offset = int(head_height * 0.03)  # Less offset to move hair up
            block_size = 2
            opacity = 255
            
        elif hair_style == 'Wavy':
            # Wavy hair: flowing, curved sections
            side_hair_width = head_width  # Same width as head to prevent bowl cut look
            side_hair_height = int(head_height * 0.9)  # Slightly taller
            side_hair_x_offset = int(head_width * 0.01)  # Much less offset to move hair forward
            side_hair_y_offset = int(head_height * 0.02)  # Less offset to move hair up
            block_size = 5
            opacity = 245
            
        elif hair_style == 'Curly':
            # Curly hair: tight, coiled sections
            side_hair_width = head_width  # Same width as head to prevent bowl cut look
            side_hair_height = int(head_height * 0.8)  # Slightly taller
            side_hair_x_offset = int(head_width * 0.02)  # Much less offset to move hair forward
            side_hair_y_offset = int(head_height * 0.02)  # Less offset to move hair up
            block_size = 3
            opacity = 250
            
        else:  # Default fallback
            side_hair_width = head_width  # Same width as head to prevent bowl cut look
            side_hair_height = int(head_height * 0.6)  # Slightly taller
            side_hair_x_offset = int(head_width * 0.02)  # Much less offset to move hair forward
            side_hair_y_offset = int(head_height * 0.02)  # Less offset to move hair up
            block_size = 4
            opacity = 255
        
        # Position hair based on side (left/right) - fine-tuned positioning
        if side == 'left':
            # Left side view: hair flows from back-left to front-left
            hair_x = head_x - side_hair_x_offset + int(head_width * 0.02)  # Base position
            hair_y = head_y - side_hair_y_offset
            
            # Fine-tune left side hair position - move back slightly more
            hair_x -= int(head_width * 0.015)  # Move hair back more
            
        else:  # right side
            # Right side view: hair flows from back-right to front-right
            hair_x = head_x + head_width - side_hair_width + side_hair_x_offset - int(head_width * 0.02)  # Base position
            hair_y = head_y - side_hair_y_offset
            
            # Fine-tune right side hair position - move forward slightly more
            hair_x += int(head_width * 0.015)  # Move hair forward more
        
        # Create hair texture with style-appropriate parameters
        hair_texture = generate_block_texture_qimage(
            side_hair_width, side_hair_height, hair_colors, 
            block_size=block_size, opacity=opacity, 
            style="None", seed=self.character_data['texture_seed']
        )
        
        # Draw the main side hair section
        painter.drawImage(hair_x, hair_y, hair_texture)
        
        # For certain hair styles, add additional sections for more realism
        if hair_style in ['Long', 'Wavy']:
            # Add a second section for flowing hair
            flow_width = int(side_hair_width * 0.6)
            flow_height = int(side_hair_height * 0.4)
            
            if side == 'left':
                flow_x = hair_x + int(side_hair_width * 0.3)
            else:
                flow_x = hair_x - int(side_hair_width * 0.3)
                
            flow_y = hair_y + int(side_hair_height * 0.6)
            
            flow_texture = generate_block_texture_qimage(
                flow_width, flow_height, hair_colors,
                block_size=block_size + 1, opacity=opacity - 20,
                style="None", seed=self.character_data['texture_seed'] + 1
            )
            painter.drawImage(flow_x, flow_y, flow_texture)

    def draw_character_ear_side(self, painter, head_x, head_y, head_width, head_height, side):
        """Draw ear for side view"""
        ear_width = head_width // 10
        ear_height = head_height // 3
        ear_y = head_y + head_height // 3
        
        # Position ear on the visible side of the head, not covered by hair
        if side == 'left':
            ear_x = head_x + int(head_width * 0.75) - ear_width // 2  # Right side of head (visible)
        else:  # right
            ear_x = head_x + int(head_width * 0.25) - ear_width // 2  # Left side of head (visible)
        
        # Draw ear with skin color
        ear_colors = [self.character_data['skin_color'], self.adjust_color(self.character_data['skin_color'], -10)]
        ear_texture = generate_block_texture_qimage(
            ear_width, ear_height, ear_colors, block_size=2, opacity=255, style="None", seed=self.character_data['texture_seed']
        )
        painter.drawImage(ear_x, ear_y, ear_texture)

    def draw_character_hat_side(self, painter, head_x, head_y, head_width, head_height, side):
        """Draw hat for side view"""
        if self.character_data['clothing']['hat'] == 'None':
            return
            
        hat_width = int(head_width * 1.2)
        hat_height = int(head_height * 0.4)
        hat_x = head_x - (hat_width - head_width) // 2
        hat_y = head_y - hat_height // 2
        
        hat_colors = ['#8B4513', '#654321']
        hat_texture = generate_block_texture_qimage(
            hat_width, hat_height, hat_colors, block_size=6, opacity=255, style="None", seed=self.character_data['texture_seed']
        )
        painter.drawImage(hat_x, hat_y, hat_texture)

    # Side view clothing methods
    def draw_character_clothing_body_side(self, painter, body_x, body_y, torso_width, torso_height, side):
        """Draw clothing on body for side view"""
        # Shirt
        shirt_colors = [self.character_data['clothing']['shirt_color'], self.adjust_color(self.character_data['clothing']['shirt_color'], -15)]
        shirt_texture = generate_block_texture_qimage(
            torso_width, torso_height, shirt_colors, block_size=7, opacity=255, style="None", seed=self.character_data['texture_seed']
        )
        painter.drawImage(body_x, body_y, shirt_texture)
        
        # Jacket (if any)
        if self.character_data['clothing']['jacket'] != 'None':
            jacket_colors = ['#2F4F4F', '#1C2F2F']
            jacket_texture = generate_block_texture_qimage(
                torso_width, torso_height, jacket_colors, block_size=8, opacity=200, style="None", seed=self.character_data['texture_seed']
            )
            painter.drawImage(body_x, body_y, jacket_texture)

    def draw_character_clothing_arms_side(self, painter, arm_x, arm_y, arm_width, arm_height, side):
        """Draw clothing on arms for side view"""
        # Shirt sleeves
        shirt_colors = [self.character_data['clothing']['shirt_color'], self.adjust_color(self.character_data['clothing']['shirt_color'], -15)]
        shirt_texture = generate_block_texture_qimage(
            arm_width, arm_height, shirt_colors, block_size=5, opacity=255, style="None", seed=self.character_data['texture_seed']
        )
        painter.drawImage(arm_x, arm_y, shirt_texture)

    def draw_character_clothing_legs_side(self, painter, leg_x, leg_y, leg_width, leg_height, side, is_back_leg=False):
        """Draw clothing on legs for side view"""
        # Pants
        pants_colors = [self.character_data['clothing']['pants_color'], self.adjust_color(self.character_data['clothing']['pants_color'], -15)]
        opacity = 150 if is_back_leg else 255
        pants_texture = generate_block_texture_qimage(
            leg_width, leg_height, pants_colors, block_size=7, opacity=opacity, style="None", seed=self.character_data['texture_seed']
        )
        painter.drawImage(leg_x, leg_y, pants_texture)

    def draw_character_shoes_side(self, painter, foot_x, foot_y, foot_width, foot_height, side, is_back_foot=False):
        """Draw shoes for side view"""
        if self.character_data['clothing']['shoes'] == 'Barefoot':
            return
            
        # Make shoes larger to cover feet
        shoe_width = int(foot_width * 1.1)
        shoe_height = int(foot_height * 1.2)
        
        shoe_x = foot_x - (shoe_width - foot_width) // 2
        shoe_y = foot_y - (shoe_height - foot_height) // 2
        
        shoe_colors = [self.character_data['clothing']['shoes_color'], self.adjust_color(self.character_data['clothing']['shoes_color'], -20)]
        opacity = 150 if is_back_foot else 255
        shoe_texture = generate_block_texture_qimage(
            shoe_width, shoe_height, shoe_colors, block_size=6, opacity=opacity, style="None", seed=self.character_data['texture_seed']
        )
        painter.drawImage(shoe_x, shoe_y, shoe_texture)

    def _get_character_hash(self):
        """Generate a hash of character data for caching"""
        import hashlib
        # Create a string representation of all character data
        char_str = str(self.character_data) + str(self.view_angle) + str(self.zoom_level) + str(self.pan_x) + str(self.pan_y)
        return hashlib.md5(char_str.encode()).hexdigest()
    
    def _clear_cache(self):
        """Clear the character image cache"""
        self._last_character_hash = None

    def adjust_color(self, hex_color, adjustment):
        """Adjust a hex color by a given amount (positive = lighter, negative = darker)"""
        # Remove # if present
        hex_color = hex_color.lstrip('#')
        
        # Convert to RGB
        r = int(hex_color[0:2], 16)
        g = int(hex_color[2:4], 16)
        b = int(hex_color[4:6], 16)
        
        # Apply adjustment
        r = max(0, min(255, r + adjustment))
        g = max(0, min(255, g + adjustment))
        b = max(0, min(255, b + adjustment))
        
        # Convert back to hex
        return f"#{r:02x}{g:02x}{b:02x}"

    def apply_to_canvas(self):
        """Apply the generated character to the main canvas"""
        try:
            # Get custom dimensions from UI or use canvas dimensions as fallback
            custom_width = self.custom_width_spin.value()
            custom_height = self.custom_height_spin.value()
            
            # Generate the character image using the custom dimensions
            character_image = self.generate_character_image(custom_width, custom_height)
            
            # Convert QImage to PIL Image for the main editor
            from PIL import Image
            import numpy as np
            
            # Convert QImage to numpy array using a safer method
            # Save QImage to temporary file and load with PIL
            import tempfile
            import os
            
            with tempfile.NamedTemporaryFile(suffix='.png', delete=False) as tmp_file:
                character_image.save(tmp_file.name, 'PNG')
                pil_image = Image.open(tmp_file.name)
                np_image = np.array(pil_image)
            
            # Clean up temporary file
            os.unlink(tmp_file.name)
            
            # Apply to canvas through parent window
            if hasattr(self.parent(), 'apply_image_to_canvas'):
                self.parent().apply_image_to_canvas(np_image)
                self.accept()
            else:
                # Fallback: save to file
                pil_image.save('character_export.png')
                self.accept()
                
        except Exception as e:
            print(f"Error applying character to canvas: {e}")
            # Fallback: save to file
            character_image = self.generate_character_image()
            character_image.save('character_export.png')
            self.accept() 