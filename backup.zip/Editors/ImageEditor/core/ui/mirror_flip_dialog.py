from PySide6.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, 
                               QRadioButton, QButtonGroup, QSlider, QSpinBox, QGroupBox,
                               QDialogButtonBox, QFormLayout, QComboBox)
from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QPixmap, QPainter, QPen, QBrush, QColor

class MirrorFlipDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Mirror/Flip")
        self.setModal(True)
        self.setFixedSize(400, 300)
        
        self.setup_ui()
        
    def setup_ui(self):
        layout = QVBoxLayout(self)
        
        # Preset Options Group
        preset_group = QGroupBox("Preset Options")
        preset_layout = QVBoxLayout(preset_group)
        
        self.preset_group = QButtonGroup()
        
        # Preset radio buttons
        self.horizontal_rb = QRadioButton("Mirror Horizontal")
        self.horizontal_rb.setChecked(True)
        self.vertical_rb = QRadioButton("Mirror Vertical")
        self.both_rb = QRadioButton("Mirror Both (180°)")
        self.none_rb = QRadioButton("No Mirror")
        
        self.preset_group.addButton(self.horizontal_rb, 0)
        self.preset_group.addButton(self.vertical_rb, 1)
        self.preset_group.addButton(self.both_rb, 2)
        self.preset_group.addButton(self.none_rb, 3)
        
        preset_layout.addWidget(self.horizontal_rb)
        preset_layout.addWidget(self.vertical_rb)
        preset_layout.addWidget(self.both_rb)
        preset_layout.addWidget(self.none_rb)
        
        layout.addWidget(preset_group)
        
        # Custom Options Group
        custom_group = QGroupBox("Custom Options")
        custom_layout = QFormLayout(custom_group)
        
        # Horizontal flip checkbox
        self.horizontal_cb = QRadioButton("Flip Horizontally")
        custom_layout.addRow("Horizontal:", self.horizontal_cb)
        
        # Vertical flip checkbox  
        self.vertical_cb = QRadioButton("Flip Vertically")
        custom_layout.addRow("Vertical:", self.vertical_cb)
        
        # Custom group
        self.custom_group = QButtonGroup()
        self.custom_group.addButton(self.horizontal_cb, 0)
        self.custom_group.addButton(self.vertical_cb, 1)
        
        layout.addWidget(custom_group)
        
        # Preview
        preview_group = QGroupBox("Preview")
        preview_layout = QVBoxLayout(preview_group)
        
        self.preview_label = QLabel("Preview will appear here")
        self.preview_label.setFixedSize(100, 100)
        self.preview_label.setStyleSheet("border: 1px solid gray; background: white;")
        self.preview_label.setAlignment(Qt.AlignCenter)
        preview_layout.addWidget(self.preview_label)
        
        layout.addWidget(preview_group)
        
        # Connect signals for live preview
        self.preset_group.buttonClicked.connect(self.update_preview)
        self.custom_group.buttonClicked.connect(self.update_preview)
        
        # Buttons
        button_box = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        button_box.accepted.connect(self.accept)
        button_box.rejected.connect(self.reject)
        layout.addWidget(button_box)
        
        # Initial preview
        self.update_preview()
        
    def update_preview(self):
        """Update the preview based on current selection."""
        # Create a simple preview showing the transformation
        pixmap = QPixmap(100, 100)
        pixmap.fill(QColor(240, 240, 240))
        
        painter = QPainter(pixmap)
        painter.setRenderHint(QPainter.Antialiasing)
        
        # Draw a simple shape to show the transformation
        painter.setPen(QPen(QColor(0, 0, 0), 2))
        painter.setBrush(QBrush(QColor(100, 150, 200)))
        
        # Draw a simple arrow or shape
        painter.drawRect(20, 20, 60, 60)
        painter.drawLine(50, 20, 50, 80)  # Vertical line
        painter.drawLine(20, 50, 80, 50)  # Horizontal line
        
        # Apply transformation based on selection
        if self.preset_group.checkedId() == 0:  # Horizontal
            pixmap = pixmap.transformed(pixmap.transform().scale(-1, 1))
        elif self.preset_group.checkedId() == 1:  # Vertical
            pixmap = pixmap.transformed(pixmap.transform().scale(1, -1))
        elif self.preset_group.checkedId() == 2:  # Both
            pixmap = pixmap.transformed(pixmap.transform().scale(-1, -1))
        elif self.preset_group.checkedId() == 3:  # None
            pass  # No transformation
        
        # Custom options
        if self.horizontal_cb.isChecked():
            pixmap = pixmap.transformed(pixmap.transform().scale(-1, 1))
        if self.vertical_cb.isChecked():
            pixmap = pixmap.transformed(pixmap.transform().scale(1, -1))
            
        painter.end()
        self.preview_label.setPixmap(pixmap)
        
    def get_parameters(self):
        """Get the selected parameters."""
        params = {}
        
        if self.preset_group.checkedId() == 0:  # Horizontal
            params['horizontal'] = True
            params['vertical'] = False
        elif self.preset_group.checkedId() == 1:  # Vertical
            params['horizontal'] = False
            params['vertical'] = True
        elif self.preset_group.checkedId() == 2:  # Both
            params['horizontal'] = True
            params['vertical'] = True
        elif self.preset_group.checkedId() == 3:  # None
            params['horizontal'] = False
            params['vertical'] = False
        
        # Override with custom options if selected
        if self.horizontal_cb.isChecked() or self.vertical_cb.isChecked():
            params['horizontal'] = self.horizontal_cb.isChecked()
            params['vertical'] = self.vertical_cb.isChecked()
            
        return params
