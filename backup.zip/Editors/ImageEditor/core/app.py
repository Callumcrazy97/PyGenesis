import sys
from PySide6.QtWidgets import QApplication
from ui.main_window import MainWindow
from ui.dialogs import NewImageDialog
from core.state import state
from core.background_processor import get_background_processor, shutdown_background_processor

if __name__ == "__main__":
    app = QApplication(sys.argv)
    
    # Initialize background processor
    background_processor = get_background_processor()
    
    window = MainWindow()
    window.showFullScreen()
    dlg = NewImageDialog(window)
    if dlg.exec() == 0:
        window.close()
        shutdown_background_processor()
        sys.exit(0)
    width, height = dlg.get_size()
    state.set_size(width, height)
    window.canvas.set_image_size(width, height)
    window.canvas.update()
    
    # Ensure frame independence (fix for shared reference issues)
    state.layer_manager.ensure_frame_independence()

    # Run the application
    exit_code = app.exec()
    
    # Cleanup
    shutdown_background_processor()
    sys.exit(exit_code)
