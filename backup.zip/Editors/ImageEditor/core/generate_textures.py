import os
import sys
import pygame
from PIL import Image, ImageDraw
import math

# Create directories if they don't exist
os.makedirs("Textures/HUD", exist_ok=True)
os.makedirs("Textures/Blocks", exist_ok=True)

# Generate crosshair texture
def generate_crosshair():
    print("Generating crosshair texture...")
    img = Image.new('RGBA', (16, 16), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    
    # Draw white crosshair with black outline
    # Horizontal line
    draw.line((6, 8, 10, 8), fill=(0, 0, 0, 255), width=3)
    draw.line((7, 8, 9, 8), fill=(255, 255, 255, 255), width=1)
    
    # Vertical line
    draw.line((8, 6, 8, 10), fill=(0, 0, 0, 255), width=3)
    draw.line((8, 7, 8, 9), fill=(255, 255, 255, 255), width=1)
    
    img.save("Textures/HUD/Crosshair.png")
    print("Crosshair saved to Textures/HUD/Crosshair.png")

# Generate block texture atlas
def generate_block_atlas():
    print("Generating block texture atlas...")
    atlas_width = 512
    atlas_height = 512
    block_size = 32
    
    # Create a new image with transparent background
    atlas = Image.new('RGBA', (atlas_width, atlas_height), (0, 0, 0, 0))
    
    # Generate block textures
    textures = {
        # Basic blocks
        "dirt": generate_dirt_texture(block_size),
        "grass_top": generate_grass_top_texture(block_size),
        "grass_side": generate_grass_side_texture(block_size),
        "stone": generate_stone_texture(block_size),
        "coal": generate_ore_texture(block_size, (30, 30, 30)),
        "iron": generate_ore_texture(block_size, (194, 171, 160)),
        "gold": generate_ore_texture(block_size, (255, 215, 0)),
        "emerald": generate_ore_texture(block_size, (0, 200, 0)),
        "diamond": generate_ore_texture(block_size, (0, 191, 255)),
        "water": generate_water_texture(block_size),
        "lava": generate_lava_texture(block_size),
        "oak_wood_top": generate_wood_top_texture(block_size),
        "oak_wood_side": generate_wood_side_texture(block_size),
        "oak_leaves": generate_leaves_texture(block_size),
        "sand": generate_sand_texture(block_size),
        "sandstone_top": generate_sandstone_top_texture(block_size),
        "sandstone_side": generate_sandstone_side_texture(block_size),
        "sandstone_bottom": generate_sandstone_bottom_texture(block_size),
        "gravel": generate_gravel_texture(block_size),
        "clay": generate_clay_texture(block_size),
        "snow": generate_snow_texture(block_size),
        "snow_dirt_side": generate_snow_dirt_side_texture(block_size),
        "coarse_dirt": generate_coarse_dirt_texture(block_size),
        "sun": generate_sun_texture(block_size),
        "cloud": generate_cloud_texture(block_size),
    }
    
    # Place textures in the atlas - ensure proper centering
    positions = {
        "dirt": (0, 0),
        "grass_side": (32, 0),
        "grass_top": (64, 0),
        "stone": (96, 0),
        "coal": (128, 0),
        "iron": (160, 0),
        "gold": (192, 0),
        "emerald": (224, 0),
        "diamond": (256, 0),
        "water": (288, 0),
        "lava": (320, 0),
        "oak_wood_top": (352, 0),
        "oak_wood_side": (352, 32),
        "oak_leaves": (384, 0),
        "sand": (416, 0),
        "sandstone_top": (448, 0),
        "sandstone_side": (448, 32),
        "sandstone_bottom": (448, 64),
        "gravel": (0, 32),
        "clay": (32, 32),
        "snow": (64, 32),
        "snow_dirt_side": (96, 32),
        "coarse_dirt": (128, 32),
        "sun": (160, 32),
        "cloud": (192, 32),
    }
    
    # Paste textures onto the atlas
    for name, texture in textures.items():
        if name in positions:
            x, y = positions[name]
            atlas.paste(texture, (x, y))
    
    # Save the atlas
    atlas.save("Atlas.png")
    print("Block atlas saved to Atlas.png")

# Texture generation functions
def generate_dirt_texture(size):
    img = Image.new('RGBA', (size, size), (121, 85, 58))
    draw = ImageDraw.Draw(img)
    
    # Add some noise/variation
    for _ in range(100):
        x = int(os.urandom(1)[0] / 255 * size)
        y = int(os.urandom(1)[0] / 255 * size)
        r = int(os.urandom(1)[0] / 255 * 3) + 1
        color_var = int(os.urandom(1)[0] / 255 * 30) - 15
        color = (121 + color_var, 85 + color_var, 58 + color_var)
        draw.ellipse((x-r, y-r, x+r, y+r), fill=color)
    
    return img

def generate_grass_top_texture(size):
    img = Image.new('RGBA', (size, size), (95, 159, 53))
    draw = ImageDraw.Draw(img)
    
    # Add some noise/variation
    for _ in range(100):
        x = int(os.urandom(1)[0] / 255 * size)
        y = int(os.urandom(1)[0] / 255 * size)
        r = int(os.urandom(1)[0] / 255 * 2) + 1
        color_var = int(os.urandom(1)[0] / 255 * 20) - 10
        color = (95 + color_var, 159 + color_var, 53 + color_var)
        draw.ellipse((x-r, y-r, x+r, y+r), fill=color)
    
    return img

def generate_grass_side_texture(size):
    # Start with dirt texture
    img = generate_dirt_texture(size)
    draw = ImageDraw.Draw(img)
    
    # Add grass on top
    for y in range(int(size * 0.3)):
        for x in range(size):
            # Gradually fade from grass to dirt
            fade = 1.0 - (y / (size * 0.3))
            if os.urandom(1)[0] / 255 < fade * 0.8:
                color_var = int(os.urandom(1)[0] / 255 * 20) - 10
                color = (95 + color_var, 159 + color_var, 53 + color_var)
                draw.point((x, y), fill=color)
    
    return img

def generate_stone_texture(size):
    img = Image.new('RGBA', (size, size), (128, 128, 128))
    draw = ImageDraw.Draw(img)
    
    # Add some noise/variation
    for _ in range(150):
        x = int(os.urandom(1)[0] / 255 * size)
        y = int(os.urandom(1)[0] / 255 * size)
        r = int(os.urandom(1)[0] / 255 * 3) + 1
        color_var = int(os.urandom(1)[0] / 255 * 30) - 15
        color = (128 + color_var, 128 + color_var, 128 + color_var)
        draw.ellipse((x-r, y-r, x+r, y+r), fill=color)
    
    return img

def generate_ore_texture(size, ore_color):
    # Start with stone texture
    img = generate_stone_texture(size)
    draw = ImageDraw.Draw(img)
    
    # Add ore veins
    for _ in range(8):
        x = int(os.urandom(1)[0] / 255 * size)
        y = int(os.urandom(1)[0] / 255 * size)
        r = int(os.urandom(1)[0] / 255 * 3) + 2
        draw.ellipse((x-r, y-r, x+r, y+r), fill=ore_color)
    
    return img

def generate_water_texture(size):
    img = Image.new('RGBA', (size, size), (64, 64, 200, 180))
    draw = ImageDraw.Draw(img)
    
    # Add some wave patterns
    for y in range(size):
        for x in range(size):
            wave = (math.sin(x/3) + math.sin(y/3)) * 10
            color_var = int(wave)
            color = (64 + color_var, 64 + color_var, 200 + color_var, 180)
            draw.point((x, y), fill=color)
    
    return img

def generate_lava_texture(size):
    img = Image.new('RGBA', (size, size), (207, 16, 32))
    draw = ImageDraw.Draw(img)
    
    # Add some bubbling patterns
    for y in range(size):
        for x in range(size):
            bubble = (math.sin(x/2) * math.cos(y/2)) * 30
            color_var = int(bubble)
            r = min(255, max(0, 207 + color_var))
            g = min(255, max(0, 16 + color_var // 2))
            b = min(255, max(0, 32))
            draw.point((x, y), fill=(r, g, b))
    
    return img

def generate_wood_top_texture(size):
    img = Image.new('RGBA', (size, size), (161, 116, 56))
    draw = ImageDraw.Draw(img)
    
    # Draw tree rings
    center_x, center_y = size // 2, size // 2
    for r in range(2, size // 2, 3):
        color_var = int(os.urandom(1)[0] / 255 * 20) - 10
        color = (161 + color_var, 116 + color_var, 56 + color_var)
        draw.ellipse((center_x - r, center_y - r, center_x + r, center_y + r), outline=color)
    
    return img

def generate_wood_side_texture(size):
    img = Image.new('RGBA', (size, size), (161, 116, 56))
    draw = ImageDraw.Draw(img)
    
    # Draw wood grain
    for i in range(0, size, 4):
        color_var = int(os.urandom(1)[0] / 255 * 20) - 10
        color = (161 + color_var, 116 + color_var, 56 + color_var)
        draw.line((0, i, size, i), fill=color)
    
    return img

def generate_leaves_texture(size):
    img = Image.new('RGBA', (size, size), (60, 192, 41, 200))
    draw = ImageDraw.Draw(img)
    
    # Add some noise/variation
    for _ in range(200):
        x = int(os.urandom(1)[0] / 255 * size)
        y = int(os.urandom(1)[0] / 255 * size)
        r = int(os.urandom(1)[0] / 255 * 2) + 1
        color_var = int(os.urandom(1)[0] / 255 * 30) - 15
        color = (60 + color_var, 192 + color_var, 41 + color_var, 200)
        draw.ellipse((x-r, y-r, x+r, y+r), fill=color)
    
    return img

def generate_sand_texture(size):
    img = Image.new('RGBA', (size, size), (219, 211, 160))
    draw = ImageDraw.Draw(img)
    
    # Add some noise/variation
    for _ in range(150):
        x = int(os.urandom(1)[0] / 255 * size)
        y = int(os.urandom(1)[0] / 255 * size)
        r = int(os.urandom(1)[0] / 255 * 2) + 1
        color_var = int(os.urandom(1)[0] / 255 * 20) - 10
        color = (219 + color_var, 211 + color_var, 160 + color_var)
        draw.ellipse((x-r, y-r, x+r, y+r), fill=color)
    
    return img

def generate_sandstone_top_texture(size):
    img = Image.new('RGBA', (size, size), (219, 211, 160))
    draw = ImageDraw.Draw(img)
    
    # Add some noise/variation
    for _ in range(100):
        x = int(os.urandom(1)[0] / 255 * size)
        y = int(os.urandom(1)[0] / 255 * size)
        r = int(os.urandom(1)[0] / 255 * 2) + 1
        color_var = int(os.urandom(1)[0] / 255 * 15) - 7
        color = (219 + color_var, 211 + color_var, 160 + color_var)
        draw.ellipse((x-r, y-r, x+r, y+r), fill=color)
    
    # Add some lines
    for i in range(0, size, 8):
        color_var = int(os.urandom(1)[0] / 255 * 10) - 5
        color = (209 + color_var, 201 + color_var, 150 + color_var)
        draw.line((0, i, size, i), fill=color, width=1)
    
    return img

def generate_sandstone_side_texture(size):
    img = Image.new('RGBA', (size, size), (219, 211, 160))
    draw = ImageDraw.Draw(img)
    
    # Add some noise/variation
    for _ in range(100):
        x = int(os.urandom(1)[0] / 255 * size)
        y = int(os.urandom(1)[0] / 255 * size)
        r = int(os.urandom(1)[0] / 255 * 2) + 1
        color_var = int(os.urandom(1)[0] / 255 * 15) - 7
        color = (219 + color_var, 211 + color_var, 160 + color_var)
        draw.ellipse((x-r, y-r, x+r, y+r), fill=color)
    
    # Add horizontal lines
    for i in range(0, size, 8):
        color_var = int(os.urandom(1)[0] / 255 * 10) - 5
        color = (209 + color_var, 201 + color_var, 150 + color_var)
        draw.line((0, i, size, i), fill=color, width=1)
    
    return img

def generate_sandstone_bottom_texture(size):
    img = Image.new('RGBA', (size, size), (219, 211, 160))
    draw = ImageDraw.Draw(img)
    
    # Add some noise/variation
    for _ in range(150):
        x = int(os.urandom(1)[0] / 255 * size)
        y = int(os.urandom(1)[0] / 255 * size)
        r = int(os.urandom(1)[0] / 255 * 2) + 1
        color_var = int(os.urandom(1)[0] / 255 * 20) - 10
        color = (219 + color_var, 211 + color_var, 160 + color_var)
        draw.ellipse((x-r, y-r, x+r, y+r), fill=color)
    
    return img

def generate_gravel_texture(size):
    img = Image.new('RGBA', (size, size), (136, 136, 136))
    draw = ImageDraw.Draw(img)
    
    # Add some noise/variation
    for _ in range(100):
        x = int(os.urandom(1)[0] / 255 * size)
        y = int(os.urandom(1)[0] / 255 * size)
        r = int(os.urandom(1)[0] / 255 * 3) + 1
        color_var = int(os.urandom(1)[0] / 255 * 40) - 20
        color = (136 + color_var, 136 + color_var, 136 + color_var)
        draw.ellipse((x-r, y-r, x+r, y+r), fill=color)
    
    return img

def generate_clay_texture(size):
    img = Image.new('RGBA', (size, size), (159, 164, 177))
    draw = ImageDraw.Draw(img)
    
    # Add some noise/variation
    for _ in range(100):
        x = int(os.urandom(1)[0] / 255 * size)
        y = int(os.urandom(1)[0] / 255 * size)
        r = int(os.urandom(1)[0] / 255 * 3) + 1
        color_var = int(os.urandom(1)[0] / 255 * 20) - 10
        color = (159 + color_var, 164 + color_var, 177 + color_var)
        draw.ellipse((x-r, y-r, x+r, y+r), fill=color)
    
    return img

def generate_snow_texture(size):
    img = Image.new('RGBA', (size, size), (240, 240, 240))
    draw = ImageDraw.Draw(img)
    
    # Add some noise/variation
    for _ in range(100):
        x = int(os.urandom(1)[0] / 255 * size)
        y = int(os.urandom(1)[0] / 255 * size)
        r = int(os.urandom(1)[0] / 255 * 2) + 1
        color_var = int(os.urandom(1)[0] / 255 * 15) - 5
        color = (240 + color_var, 240 + color_var, 240 + color_var)
        draw.ellipse((x-r, y-r, x+r, y+r), fill=color)
    
    return img

def generate_snow_dirt_side_texture(size):
    # Start with dirt texture
    img = generate_dirt_texture(size)
    draw = ImageDraw.Draw(img)
    
    # Add snow on top
    for y in range(int(size * 0.3)):
        for x in range(size):
            # Gradually fade from snow to dirt
            fade = 1.0 - (y / (size * 0.3))
            if os.urandom(1)[0] / 255 < fade * 0.8:
                color_var = int(os.urandom(1)[0] / 255 * 15) - 5
                color = (240 + color_var, 240 + color_var, 240 + color_var)
                draw.point((x, y), fill=color)
    
    return img

def generate_coarse_dirt_texture(size):
    img = Image.new('RGBA', (size, size), (121, 85, 58))
    draw = ImageDraw.Draw(img)
    
    # Add some noise/variation
    for _ in range(100):
        x = int(os.urandom(1)[0] / 255 * size)
        y = int(os.urandom(1)[0] / 255 * size)
        r = int(os.urandom(1)[0] / 255 * 3) + 1
        color_var = int(os.urandom(1)[0] / 255 * 40) - 20
        color = (121 + color_var, 85 + color_var, 58 + color_var)
        draw.ellipse((x-r, y-r, x+r, y+r), fill=color)
    
    # Add gravel bits
    for _ in range(30):
        x = int(os.urandom(1)[0] / 255 * size)
        y = int(os.urandom(1)[0] / 255 * size)
        r = int(os.urandom(1)[0] / 255 * 2) + 2
        color_var = int(os.urandom(1)[0] / 255 * 20) - 10
        color = (136 + color_var, 136 + color_var, 136 + color_var)
        draw.ellipse((x-r, y-r, x+r, y+r), fill=color)
    
    return img

def generate_sun_texture(size):
    img = Image.new('RGBA', (size, size), (255, 255, 0, 220))
    draw = ImageDraw.Draw(img)
    
    # Add some glow
    center_x, center_y = size // 2, size // 2
    for r in range(size // 2, 0, -1):
        alpha = int(255 * (r / (size / 2)))
        color = (255, 255, 0, alpha)
        draw.ellipse((center_x - r, center_y - r, center_x + r, center_y + r), fill=color)
    
    return img

def generate_cloud_texture(size):
    img = Image.new('RGBA', (size, size), (255, 255, 255, 180))
    draw = ImageDraw.Draw(img)
    
    # Add some noise/variation
    for _ in range(100):
        x = int(os.urandom(1)[0] / 255 * size)
        y = int(os.urandom(1)[0] / 255 * size)
        r = int(os.urandom(1)[0] / 255 * 3) + 1
        color_var = int(os.urandom(1)[0] / 255 * 20) - 10
        alpha = int(os.urandom(1)[0] / 255 * 40) + 160
        color = (255 + color_var, 255 + color_var, 255 + color_var, alpha)
        draw.ellipse((x-r, y-r, x+r, y+r), fill=color)
    
    return img

# Run the texture generation
if __name__ == "__main__":
    
    generate_crosshair()
    generate_block_atlas()
    print("All textures generated successfully!")
