import numpy as np
import copy

class Frame:
    def __init__(self, width, height):
        self.image = np.zeros((height, width, 4), dtype=np.uint8)  # RGBA
        self.tags = []  # List of tags for this frame
        self.color_code = None  # Color code for timeline display
    
    def __deepcopy__(self, memo):
        """Ensure proper deep copying of Frame objects"""
        new_frame = Frame(self.image.shape[1], self.image.shape[0])  # width, height
        new_frame.image = self.image.copy()
        new_frame.tags = self.tags.copy()
        new_frame.color_code = self.color_code
        return new_frame

class Layer:
    def __init__(self, width, height, state, name="Layer 1", depth=0):
        self.state = state
        self.name = name
        self.frames = [Frame(width, height)]
        self.visible = True
        self.locked = False
        self.depth = depth
        from core.history import HistoryManager
        self.frame_histories = {0: HistoryManager(state, max_undo=10)}
        # Per-layer grid settings (None = use global)
        self.grid_visible = None
        self.grid_size = None
        self.grid_color = None
        self.grid_rotation = None
        # Per-layer onion skin settings
        self.onion_skin_settings = {
            'prev': {'color': '#ff0000', 'opacity': 128, 'visible': True},
            'next': {'color': '#00ff00', 'opacity': 128, 'visible': True},
            'current': {'color': '#8888ff', 'opacity': 64, 'visible': False},
        }
        # Grid metadata for sprite sheets and nine-slice
        self.grid_metadata = {
            "mode": None,  # "sprite_sheet" | "nine_slice" | None
            "cell_width": None,
            "cell_height": None,
            "frames_per_row": None,
            "alignment": "center"  # "center" | "bottom" | "top"
        }

    def add_frame(self, width, height, state):
        # Create a new frame with its own independent image
        new_frame = Frame(width, height)
        # Ensure the image is completely independent
        new_frame.image = np.zeros((height, width, 4), dtype=np.uint8)
        self.frames.append(new_frame)
        from core.history import HistoryManager
        self.frame_histories[len(self.frames)-1] = HistoryManager(state, max_undo=10)

    def get_frame(self, index=0):
        if 0 <= index < len(self.frames):
            return self.frames[index]
        if self.frames:
            return self.frames[-1]
        raise IndexError("No frames available in layer")

    def set_frame(self, index, frame):
        self.frames[index] = frame

    def get_history_for_frame(self, idx):
        return self.frame_histories.get(idx)
