from .layer import Layer
import numpy as np

class LayerManager:
    def __init__(self, width, height, state):
        self.state = state
        self.layers = [Layer(width, height, state=state, depth=0)]
        self.current_layer = 0
        self.current_frame = 0
        self.width = width
        self.height = height
        
        # Performance optimization: Cache composite results
        self._composite_cache = None
        self._composite_cache_frame = None
        self._composite_cache_layers_hash = None
        self._composite_cache_visible_hash = None

    def get_current_layer(self):
        return self.layers[self.current_layer]

    def get_current_frame(self):
        return self.get_current_layer().get_frame(self.current_frame)

    def get_current_image(self):
        return self.get_current_frame().image

    def composite_layers(self, frame_index=None):
        """Composite all visible layers for a given frame in depth order. CACHED for performance."""
        if frame_index is None:
            frame_index = self.current_frame
        
        if not self.layers:
            return None
        
        # Generate cache key
        visible_layers = [(l.depth, l.visible, id(l.get_frame(frame_index).image) if l.get_frame(frame_index) and l.get_frame(frame_index).image is not None else None) 
                         for l in sorted(self.layers, key=lambda l: l.depth)]
        layers_hash = hash(tuple(visible_layers))
        
        # Check cache validity
        if (self._composite_cache is not None and 
            self._composite_cache_frame == frame_index and
            self._composite_cache_layers_hash == layers_hash):
            # Return cached composite (copy to avoid mutation issues)
            return self._composite_cache.copy()
        
        # Cache miss - generate composite
        composite = np.zeros((self.height, self.width, 4), dtype=np.uint8)
        
        # Sort layers by depth (lowest depth = back, highest depth = front)
        sorted_layers = sorted(self.layers, key=lambda l: l.depth)
        
        # Composite each visible layer
        for layer in sorted_layers:
            if not layer.visible:
                continue
            
            frame = layer.get_frame(frame_index)
            if frame and frame.image is not None:
                img = frame.image
                
                # Ensure the image has the right shape
                if img.shape[:2] != (self.height, self.width):
                    # Resize if needed
                    from PIL import Image
                    pil_img = Image.fromarray(img)
                    pil_img = pil_img.resize((self.width, self.height), Image.Resampling.NEAREST)
                    img = np.array(pil_img)
                
                # Alpha blend the layer onto the composite
                if img.shape[2] == 4:  # RGBA
                    alpha = img[..., 3:4].astype(np.float32) / 255.0
                    composite[..., :3] = (1 - alpha) * composite[..., :3] + alpha * img[..., :3]
                    composite[..., 3:4] = np.maximum(composite[..., 3:4], img[..., 3:4])
                else:  # RGB
                    composite[..., :3] = img[..., :3]
                    composite[..., 3:4] = 255
        
        # Update cache
        self._composite_cache = composite
        self._composite_cache_frame = frame_index
        self._composite_cache_layers_hash = layers_hash
        
        return composite.copy()
    
    def invalidate_composite_cache(self):
        """Invalidate the composite cache (call when layers change)"""
        self._composite_cache = None
        self._composite_cache_frame = None
        self._composite_cache_layers_hash = None

    def add_layer(self, width=None, height=None, name=None, state=None):
        """Add a new layer. Supports both old and new signatures for compatibility."""
        # Handle old signature (name only)
        if width is None or not isinstance(width, int):
            # Old signature: add_layer(name=None)
            if isinstance(width, str) or width is None:
                name = width
                width = self.width
                height = self.height
                state = self.state
        
        name = name or f"Layer {len(self.layers)+1}"
        max_depth = max((layer.depth for layer in self.layers), default=0)
        layer = Layer(width or self.width, height or self.height, state=state or self.state, name=name, depth=max_depth+1)
        
        # If there are existing layers, ensure the new layer has the same number of frames
        if self.layers:
            existing_frame_count = len(self.layers[0].frames)
            # Remove the default frame and add the correct number
            layer.frames = []
            for i in range(existing_frame_count):
                from .layer import Frame
                new_frame = Frame(self.width, self.height)
                # Ensure each frame has its own independent image
                new_frame.image = np.zeros((self.height, self.width, 4), dtype=np.uint8)
                layer.frames.append(new_frame)
                from core.history import HistoryManager
                layer.frame_histories[i] = HistoryManager(self.state, max_undo=10)
        
        self.layers.append(layer)
        self.sort_layers()
        self.current_layer = len(self.layers) - 1
        self.invalidate_composite_cache()

    def add_frame(self):
        for layer in self.layers:
            layer.add_frame(self.width, self.height, self.state)
        self.current_frame = len(self.layers[0].frames) - 1
        self.invalidate_composite_cache()

    def ensure_minimums(self):
        if not self.layers:
            self.add_layer()
        for layer in self.layers:
            if not layer.frames:
                from .layer import Frame
                layer.frames.append(Frame(self.width, self.height))
                from core.history import HistoryManager
                layer.frame_histories[0] = HistoryManager(self.state, max_undo=10)

    def sort_layers(self):
        self.layers.sort(key=lambda l: l.depth)
        self.invalidate_composite_cache()
    
    def ensure_frame_independence(self):
        """Ensure all frames have independent images (fix for shared reference issues)"""
        for layer in self.layers:
            for i, frame in enumerate(layer.frames):
                # Create a new independent image for each frame
                frame.image = frame.image.copy()
