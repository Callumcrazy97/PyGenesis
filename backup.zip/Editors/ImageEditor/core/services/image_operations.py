"""
Image Operations Service
Handles general image manipulation operations.
Extracted from main_window.py for better separation of concerns.
"""

import numpy as np
from PIL import Image
from typing import Dict, Any, Optional, Tuple

class ImageOperations:
    """Service for general image operations."""
    
    def __init__(self):
        """Initialize the image operations service."""
        pass
    
    def resize_image(self, img: np.ndarray, width: int, height: int, method: str = 'lanczos') -> np.ndarray:
        """Resize an image."""
        pil_img = Image.fromarray(img, mode='RGBA')
        if method == 'lanczos':
            resized = pil_img.resize((width, height), Image.LANCZOS)
        else:
            resized = pil_img.resize((width, height), Image.NEAREST)
        return np.array(resized)
    
    def crop_image(self, img: np.ndarray, bounds: Tuple[int, int, int, int]) -> np.ndarray:
        """Crop an image to the given bounds (x1, y1, x2, y2)."""
        pil_img = Image.fromarray(img, mode='RGBA')
        cropped = pil_img.crop(bounds)
        return np.array(cropped)
    
    def rotate_image(self, img: np.ndarray, angle: float, expand: bool = True) -> np.ndarray:
        """Rotate an image by the given angle."""
        pil_img = Image.fromarray(img, mode='RGBA')
        rotated = pil_img.rotate(-angle, expand=expand)
        return np.array(rotated)
    
    def flip_horizontal(self, img: np.ndarray) -> np.ndarray:
        """Flip image horizontally."""
        pil_img = Image.fromarray(img, mode='RGBA')
        flipped = pil_img.transpose(Image.FLIP_LEFT_RIGHT)
        return np.array(flipped)
    
    def flip_vertical(self, img: np.ndarray) -> np.ndarray:
        """Flip image vertically."""
        pil_img = Image.fromarray(img, mode='RGBA')
        flipped = pil_img.transpose(Image.FLIP_TOP_BOTTOM)
        return np.array(flipped)

