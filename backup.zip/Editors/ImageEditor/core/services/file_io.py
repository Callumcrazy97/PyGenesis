"""
File I/O Service
Handles file save/load operations for images.
Extracted from main_window.py for better separation of concerns.
"""

import numpy as np
from PIL import Image
from typing import Optional, Dict, Any
import os

class FileIOService:
    """Service for file I/O operations."""
    
    def __init__(self):
        """Initialize the file I/O service."""
        pass
    
    def save_image(self, img: np.ndarray, filepath: str, format: str = 'PNG') -> bool:
        """
        Save an image to file.
        
        Args:
            img: Image as numpy array (RGBA)
            filepath: Path to save the image
            format: Image format (PNG, JPG, etc.)
            
        Returns:
            True if successful, False otherwise
        """
        try:
            pil_img = Image.fromarray(img, mode='RGBA')
            pil_img.save(filepath, format=format)
            return True
        except Exception as e:
            print(f"Error saving image: {e}")
            return False
    
    def load_image(self, filepath: str) -> Optional[np.ndarray]:
        """
        Load an image from file.
        
        Args:
            filepath: Path to the image file
            
        Returns:
            Image as numpy array (RGBA) or None if error
        """
        try:
            pil_img = Image.open(filepath)
            if pil_img.mode != 'RGBA':
                pil_img = pil_img.convert('RGBA')
            return np.array(pil_img)
        except Exception as e:
            print(f"Error loading image: {e}")
            return None
    
    def export_sprite(self, frames: list, filepath: str, format: str = 'PNG') -> bool:
        """
        Export sprite frames to file(s).
        
        Args:
            frames: List of frame images (numpy arrays)
            filepath: Base path for export
            format: Image format
            
        Returns:
            True if successful, False otherwise
        """
        try:
            if len(frames) == 1:
                # Single frame, save directly
                return self.save_image(frames[0], filepath, format)
            else:
                # Multiple frames, save as sequence
                base, ext = os.path.splitext(filepath)
                for i, frame in enumerate(frames):
                    frame_path = f"{base}_frame_{i:03d}{ext}"
                    if not self.save_image(frame, frame_path, format):
                        return False
                return True
        except Exception as e:
            print(f"Error exporting sprite: {e}")
            return False

