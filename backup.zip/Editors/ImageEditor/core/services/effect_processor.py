"""
Effect Processor Service
Handles all image effect processing operations.
Extracted from main_window.py for better separation of concerns.

This service processes image effects without UI dependencies.
Methods that need state/UI access should remain in main_window and call this service.
"""

import numpy as np
from PIL import Image
from typing import Dict, Any, Optional, Union
from scipy import ndimage
import cv2
import math
from colorsys import rgb_to_hsv, hsv_to_rgb

class EffectProcessor:
    """Service for processing image effects."""
    
    def __init__(self):
        """Initialize the effect processor."""
        pass
    
    def process_effect(self, effect_type: str, img: Union[np.ndarray, Image.Image], parameters: Dict[str, Any]) -> np.ndarray:
        """
        Process an image with a specific effect.
        
        Args:
            effect_type: Type of effect to apply
            img: Image as numpy array (RGBA) or PIL Image
            parameters: Effect parameters dictionary
            
        Returns:
            Processed image as numpy array (RGBA)
        """
        # Convert PIL Image to numpy if needed
        if isinstance(img, Image.Image):
            pil_img = img
            if pil_img.mode != 'RGBA':
                pil_img = pil_img.convert('RGBA')
        else:
            # Assume numpy array
            pil_img = Image.fromarray(img, mode='RGBA')
        
        # Handle NumPy-based effects directly
        if effect_type in ['dither', 'pixelate']:
            if isinstance(img, Image.Image):
                img_array = np.array(img)
            else:
                img_array = img
            if effect_type == 'dither':
                return self._apply_dither_effect(img_array, parameters)
            elif effect_type == 'pixelate':
                return self._apply_pixelate_effect(img_array, parameters)
        
        # Route to appropriate effect method
        if effect_type == 'invert':
            return self._apply_invert_effect(pil_img)
        elif effect_type == 'brightness':
            return self._apply_brightness_effect(pil_img, parameters)
        elif effect_type == 'contrast':
            return self._apply_contrast_effect(pil_img, parameters)
        elif effect_type == 'greyscale':
            return self._apply_greyscale_effect(pil_img)
        elif effect_type == 'fade':
            return self._apply_fade_effect(pil_img, parameters)
        elif effect_type == 'opacity':
            return self._apply_opacity_effect(pil_img, parameters)
        elif effect_type == 'blur':
            return self._apply_blur_effect(pil_img, parameters)
        elif effect_type == 'sharpen':
            return self._apply_sharpen_effect(pil_img, parameters)
        elif effect_type == 'noise':
            return self._apply_noise_effect(pil_img, parameters)
        elif effect_type == 'vignette':
            return self._apply_vignette(pil_img, parameters)
        elif effect_type == 'saturation':
            return self._apply_saturation(pil_img, parameters)
        elif effect_type == 'posterize':
            return self._apply_posterize(pil_img, parameters)
        elif effect_type == 'emboss':
            return self._apply_emboss(pil_img, parameters)
        elif effect_type == 'edge_detection':
            return self._apply_edge_detection(pil_img, parameters)
        elif effect_type == 'colorize':
            return self._apply_colorize(pil_img, parameters)
        elif effect_type == 'oil_painting':
            return self._apply_oil_painting(pil_img, parameters)
        elif effect_type == 'glow':
            return self._apply_glow(pil_img, parameters)
        elif effect_type == 'solarize':
            return self._apply_solarize(pil_img, parameters)
        elif effect_type == 'image_enhancement':
            return self._apply_image_enhancement(pil_img, parameters)
        elif effect_type == 'quality_enhancement':
            return self._apply_quality_enhancement(pil_img, parameters)
        elif effect_type == 'upscale':
            return self._apply_upscale(pil_img, parameters)
        elif effect_type == 'motion_blur':
            return self._apply_motion_blur(pil_img, parameters)
        elif effect_type == 'shader_bloom':
            return self._apply_shader_bloom(pil_img, parameters)
        elif effect_type == 'palette_cycler':
            return self._apply_palette_cycler(pil_img, parameters)
        elif effect_type == 'pixel_depth':
            return self._apply_pixel_depth(pil_img, parameters)
        elif effect_type == 'hd_crisp':
            return self._apply_hd_crisp(pil_img, parameters)
        elif effect_type == 'mirror_horizontal':
            return self._apply_mirror_horizontal_effect(pil_img)
        elif effect_type == 'mirror_vertical':
            return self._apply_mirror_vertical_effect(pil_img)
        elif effect_type == 'rotate_90':
            return self._apply_rotate_90_effect(pil_img)
        elif effect_type == 'rotate_180':
            return self._apply_rotate_180_effect(pil_img)
        elif effect_type == 'rotate_custom':
            return self._apply_rotate_custom_effect(pil_img, parameters)
        elif effect_type == 'atmospheric_lighting':
            return self._apply_atmospheric_lighting_effect(pil_img, parameters)
        elif effect_type == 'wind_waker':
            return self._apply_wind_waker_effect(pil_img, parameters)
        elif effect_type == 'ocarina_of_time':
            return self._apply_ocarina_of_time_effect(pil_img, parameters)
        elif effect_type == 'luigis_mansion':
            return self._apply_luigis_mansion_effect(pil_img, parameters)
        elif effect_type == 'eternal_darkness':
            return self._apply_eternal_darkness_effect(pil_img, parameters)
        elif effect_type == 'pokemon_colosseum':
            return self._apply_pokemon_colosseum_effect(pil_img, parameters)
        elif effect_type == 'mario_kart_8':
            return self._apply_mario_kart_8_effect(pil_img, parameters)
        else:
            # Unknown effect, return original
            if isinstance(img, Image.Image):
                return np.array(img)
            return img
    
    # Effect implementation methods
    # These will be extracted from main_window.py incrementally
    # For now, we'll import and delegate to maintain functionality
    
    def _apply_invert_effect(self, pil_img: Image.Image) -> np.ndarray:
        """Apply invert colors effect."""
        r, g, b, a = pil_img.split()
        inverted = Image.merge('RGB', (r.point(lambda x: 255 - x), 
                                      g.point(lambda x: 255 - x), 
                                      b.point(lambda x: 255 - x)))
        inverted.putalpha(a)
        return np.array(inverted)
    
    def _apply_greyscale_effect(self, pil_img: Image.Image) -> np.ndarray:
        """Apply greyscale effect."""
        l_img = pil_img.convert('L')
        a = pil_img.getchannel('A')
        l_img.putalpha(a)
        out = l_img.convert('RGBA')
        return np.array(out)
    
    def _apply_brightness_effect(self, pil_img: Image.Image, parameters: Dict[str, Any]) -> np.ndarray:
        """Apply brightness adjustment effect."""
        factor = parameters.get('factor', 1.0)
        from PIL import ImageEnhance
        
        if pil_img.mode != 'RGBA':
            pil_img = pil_img.convert('RGBA')
        
        rgb_img = pil_img.convert('RGB')
        enhancer = ImageEnhance.Brightness(rgb_img)
        brightened_rgb = enhancer.enhance(factor)
        brightened_rgb.putalpha(pil_img.getchannel('A'))
        return np.array(brightened_rgb)
    
    def _apply_contrast_effect(self, pil_img: Image.Image, parameters: Dict[str, Any]) -> np.ndarray:
        """Apply contrast adjustment effect."""
        factor = parameters.get('factor', 1.0)
        from PIL import ImageEnhance
        
        if pil_img.mode != 'RGBA':
            pil_img = pil_img.convert('RGBA')
        
        rgb_img = pil_img.convert('RGB')
        enhancer = ImageEnhance.Contrast(rgb_img)
        contrasted_rgb = enhancer.enhance(factor)
        contrasted_rgb.putalpha(pil_img.getchannel('A'))
        return np.array(contrasted_rgb)
    
    def _apply_vignette(self, pil_img: Image.Image, parameters: Dict[str, Any]) -> np.ndarray:
        """Apply vignette effect - darkens edges of the image."""
        strength = parameters.get('strength', 0.5)
        radius = parameters.get('radius', 0.8)
        shape = parameters.get('shape', 'circular')
        
        if pil_img.mode != 'RGBA':
            pil_img = pil_img.convert('RGBA')
        
        width, height = pil_img.size
        img_array = np.array(pil_img)
        
        x, y = np.meshgrid(np.arange(width), np.arange(height))
        x_norm = (x / width - 0.5) * 2
        y_norm = (y / height - 0.5) * 2
        
        if shape == 'circular':
            distance = np.sqrt(x_norm**2 + y_norm**2)
        else:
            distance = np.maximum(np.abs(x_norm), np.abs(y_norm))
        
        falloff = distance / radius
        falloff = np.clip(falloff, 0, 1)
        vignette_mask = 1 - (falloff * strength)
        
        vignette_alpha = vignette_mask[:, :, np.newaxis]
        result_array = img_array.copy()
        result_array[:, :, :3] = (result_array[:, :, :3] * vignette_alpha).astype(np.uint8)
        result_array[:, :, 3] = img_array[:, :, 3]
        
        return result_array
    
    def _apply_saturation(self, pil_img: Image.Image, parameters: Dict[str, Any]) -> np.ndarray:
        """Apply saturation adjustment effect."""
        factor = parameters.get('factor', 1.0)
        from PIL import ImageEnhance
        
        if pil_img.mode != 'RGBA':
            pil_img = pil_img.convert('RGBA')
        
        rgb_img = pil_img.convert('RGB')
        enhancer = ImageEnhance.Color(rgb_img)
        adjusted_rgb = enhancer.enhance(factor)
        adjusted_rgb.putalpha(pil_img.getchannel('A'))
        return np.array(adjusted_rgb)
    
    def _apply_posterize(self, pil_img: Image.Image, parameters: Dict[str, Any]) -> np.ndarray:
        """Apply posterize effect - reduces color palette."""
        levels = parameters.get('levels', 8)
        
        if pil_img.mode != 'RGBA':
            pil_img = pil_img.convert('RGBA')
        
        img_array = np.array(pil_img)
        result_array = img_array.copy()
        quantize_step = 256 // levels
        
        for channel in range(3):
            result_array[:, :, channel] = (img_array[:, :, channel] // quantize_step) * quantize_step
        
        result_array[:, :, 3] = img_array[:, :, 3]
        return result_array
    
    def _apply_emboss(self, pil_img: Image.Image, parameters: Dict[str, Any]) -> np.ndarray:
        """Apply emboss effect - creates 3D embossed look."""
        strength = parameters.get('strength', 1.0)
        
        if pil_img.mode != 'RGBA':
            pil_img = pil_img.convert('RGBA')
        
        gray = pil_img.convert('L')
        gray_array = np.array(gray, dtype=np.float32)
        
        kernel = np.array([[-2*strength, -1*strength, 0],
                           [-1*strength,  1,         1*strength],
                           [ 0,            1*strength, 2*strength]])
        
        embossed = ndimage.convolve(gray_array, kernel, mode='constant')
        embossed = np.clip(embossed + 128, 0, 255).astype(np.uint8)
        
        result = np.zeros((*embossed.shape, 4), dtype=np.uint8)
        result[:, :, :3] = embossed[:, :, np.newaxis]
        result[:, :, 3] = np.array(pil_img.getchannel('A'))
        
        return result
    
    def _apply_edge_detection(self, pil_img: Image.Image, parameters: Dict[str, Any]) -> np.ndarray:
        """Apply edge detection effect - preserves grayscale gradients."""
        threshold = parameters.get('threshold', 50)
        
        if pil_img.mode != 'RGBA':
            pil_img = pil_img.convert('RGBA')
        
        gray = pil_img.convert('L')
        gray_array = np.array(gray, dtype=np.float32)
        
        sobel_x = np.array([[-1, 0, 1], [-2, 0, 2], [-1, 0, 1]])
        sobel_y = np.array([[-1, -2, -1], [ 0,  0,  0], [ 1,  2,  1]])
        
        edge_x = ndimage.convolve(gray_array, sobel_x)
        edge_y = ndimage.convolve(gray_array, sobel_y)
        magnitude = np.sqrt(edge_x**2 + edge_y**2)
        magnitude_normalized = np.clip((magnitude / threshold) * 255, 0, 255).astype(np.uint8)
        
        result = np.zeros((*magnitude_normalized.shape, 4), dtype=np.uint8)
        result[:, :, :3] = magnitude_normalized[:, :, np.newaxis]
        result[:, :, 3] = np.array(pil_img.getchannel('A'))
        
        return result
    
    def _apply_colorize(self, pil_img: Image.Image, parameters: Dict[str, Any]) -> np.ndarray:
        """Apply colorize effect - adds a color tint to the image."""
        color_hex = parameters.get('color', '#FF0000')
        strength = parameters.get('strength', 0.5)
        
        color_hex = color_hex.lstrip('#')
        tint_r = int(color_hex[0:2], 16)
        tint_g = int(color_hex[2:4], 16)
        tint_b = int(color_hex[4:6], 16)
        
        if pil_img.mode != 'RGBA':
            pil_img = pil_img.convert('RGBA')
        
        img_array = np.array(pil_img, dtype=np.float32)
        gray = np.dot(img_array[:, :, :3], [0.299, 0.587, 0.114])[:, :, np.newaxis]
        
        tinted = (1 - strength) * gray + strength * np.array([tint_r, tint_g, tint_b])
        tinted = np.clip(tinted, 0, 255).astype(np.uint8)
        
        result_array = np.zeros_like(img_array, dtype=np.uint8)
        result_array[:, :, :3] = tinted
        result_array[:, :, 3] = img_array[:, :, 3].astype(np.uint8)
        
        return result_array
    
    # Placeholder methods for effects that need more complex implementation
    # These will be extracted from main_window.py incrementally
    def _apply_fade_effect(self, pil_img: Image.Image, parameters: Dict[str, Any]) -> np.ndarray:
        """Apply fade to color effect."""
        target_color = parameters.get('target_color', '#000000')
        intensity = parameters.get('intensity', 0.5)
        
        # Convert hex to RGBA
        if target_color.startswith("#"):
            r = int(target_color[1:3], 16)
            g = int(target_color[3:5], 16)
            b = int(target_color[5:7], 16)
            target_rgba = (r, g, b, 255)
        else:
            target_rgba = (0, 0, 0, 255)  # fallback
        
        # Use PIL's blend function for proper alpha blending
        base = pil_img.convert('RGBA')
        overlay = Image.new('RGBA', pil_img.size, target_rgba)
        faded = Image.blend(base, overlay, intensity)
        
        return np.array(faded)
    
    def _apply_opacity_effect(self, pil_img: Image.Image, parameters: Dict[str, Any]) -> np.ndarray:
        """Apply opacity adjustment effect."""
        opacity = parameters.get('opacity', 0.5)
        
        # Adjust alpha channel
        r, g, b, a = pil_img.split()
        new_alpha = a.point(lambda x: int(x * opacity))
        result = Image.merge('RGBA', (r, g, b, new_alpha))
        return np.array(result)
    
    def _apply_blur_effect(self, pil_img: Image.Image, parameters: Dict[str, Any]) -> np.ndarray:
        """Apply blur effect."""
        radius = parameters.get('radius', 5)
        from PIL import ImageFilter
        
        # Apply blur to each channel separately to preserve alpha
        if pil_img.mode != 'RGBA':
            pil_img = pil_img.convert('RGBA')
        
        r, g, b, a = pil_img.split()
        blurred_r = r.filter(ImageFilter.GaussianBlur(radius))
        blurred_g = g.filter(ImageFilter.GaussianBlur(radius))
        blurred_b = b.filter(ImageFilter.GaussianBlur(radius))
        blurred_a = a.filter(ImageFilter.GaussianBlur(radius))
        
        blurred = Image.merge('RGBA', (blurred_r, blurred_g, blurred_b, blurred_a))
        return np.array(blurred)
    
    def _apply_sharpen_effect(self, pil_img: Image.Image, parameters: Dict[str, Any]) -> np.ndarray:
        """Apply sharpen effect."""
        amount = parameters.get('amount', 50)
        from PIL import ImageEnhance
        
        # Apply sharpening while preserving alpha
        if pil_img.mode != 'RGBA':
            pil_img = pil_img.convert('RGBA')
        
        # Convert to RGB for sharpening, then restore alpha
        rgb_img = pil_img.convert('RGB')
        enhancer = ImageEnhance.Sharpness(rgb_img)
        sharpened_rgb = enhancer.enhance(1 + amount / 100.0)
        
        # Restore alpha channel
        sharpened_rgb.putalpha(pil_img.getchannel('A'))
        return np.array(sharpened_rgb)
    
    def _apply_noise_effect(self, pil_img: Image.Image, parameters: Dict[str, Any]) -> np.ndarray:
        """Apply noise effect - optimized version."""
        import random
        
        intensity = parameters.get('intensity', 50)
        noise_type = parameters.get('type', 'Random')
        seed = parameters.get('seed', 42)
        
        # Set random seed for reproducible noise
        random.seed(seed)
        
        # Convert PIL to numpy array
        img_array = np.array(pil_img)
        height, width = img_array.shape[:2]
        
        if noise_type == 'Coherent':
            # Vectorized coherent noise generation
            x_coords, y_coords = np.meshgrid(np.arange(width), np.arange(height))
            x_coords = x_coords * 0.1
            y_coords = y_coords * 0.1
            
            # Vectorized hash function
            def vectorized_noise(x, y):
                n = (x * 73856093 + y * 19349663 + seed).astype(np.int64) & 0x7fffffff
                n = (n << 13) ^ n
                return ((n * (n * n * 15731 + 789221) + 1376312589) & 0x7fffffff) / 0x7fffffff
            
            # Generate noise map vectorized
            noise_map = vectorized_noise(x_coords, y_coords) * (intensity / 100.0)
            
            # Apply noise to RGB channels vectorized
            noise_3d = np.stack([noise_map] * 3, axis=2)
            img_array[:, :, :3] = np.clip(img_array[:, :, :3] + noise_3d * 255, 0, 255)
        else:
            # Vectorized random noise
            noise = np.random.randint(-intensity, intensity, img_array.shape[:3], dtype=np.int16)
            img_array = np.clip(img_array.astype(np.int16) + noise, 0, 255).astype(np.uint8)
        
        return img_array
    
    def _apply_oil_painting(self, pil_img: Image.Image, parameters: Dict[str, Any]) -> np.ndarray:
        """Apply oil painting artistic effect - optimized for performance."""
        brush_size = int(parameters.get('brush_size', 3))
        intensity = parameters.get('intensity', 0.7)
        
        if pil_img.mode != 'RGBA':
            pil_img = pil_img.convert('RGBA')
        
        img_array = np.array(pil_img)
        
        # Use median filter for oil painting look
        oiled = np.zeros_like(img_array)
        for channel in range(3):
            oiled[:, :, channel] = ndimage.median_filter(img_array[:, :, channel], size=max(2, brush_size * 2 - 1))
        oiled[:, :, 3] = img_array[:, :, 3]
        
        # Blend with original based on intensity
        blended = (intensity * oiled + (1 - intensity) * img_array).astype(np.uint8)
        
        return blended
    
    def _apply_glow(self, pil_img: Image.Image, parameters: Dict[str, Any]) -> np.ndarray:
        """Apply glow/bloom effect."""
        radius = int(parameters.get('radius', 10))
        strength = parameters.get('strength', 1.5)
        
        if pil_img.mode != 'RGBA':
            pil_img = pil_img.convert('RGBA')
        
        img_array = np.array(pil_img, dtype=np.float32)
        
        # Apply Gaussian blur for glow
        blurred = np.zeros_like(img_array)
        for channel in range(3):
            blurred[:, :, channel] = ndimage.gaussian_filter(img_array[:, :, channel], sigma=radius)
        
        # Blend original with blurred (additive)
        result = np.clip(img_array + (blurred * strength), 0, 255).astype(np.uint8)
        
        # Preserve alpha
        result[:, :, 3] = img_array[:, :, 3].astype(np.uint8)
        
        return result
    
    def _apply_solarize(self, pil_img: Image.Image, parameters: Dict[str, Any]) -> np.ndarray:
        """Apply solarize effect - artistic color inversion."""
        threshold = parameters.get('threshold', 128)
        
        if pil_img.mode != 'RGBA':
            pil_img = pil_img.convert('RGBA')
        
        img_array = np.array(pil_img, dtype=np.float32)
        
        # Invert colors above threshold
        mask = img_array[:, :, :3] > threshold
        inverted = np.where(mask, 255 - img_array[:, :, :3], img_array[:, :, :3])
        
        result = img_array.copy()
        result[:, :, :3] = inverted
        result = np.clip(result, 0, 255).astype(np.uint8)
        
        return result
    
    def _apply_image_enhancement(self, pil_img: Image.Image, parameters: Dict[str, Any]) -> np.ndarray:
        """Apply combined image enhancement effect - delegates to dialogs implementation."""
        # This effect uses dialog methods, so we delegate to the dialog
        # For now, return original - this will be handled by main_window
        # TODO: Extract full implementation from dialogs
        return np.array(pil_img)
    
    def _apply_quality_enhancement(self, pil_img: Image.Image, parameters: Dict[str, Any]) -> np.ndarray:
        """Apply quality enhancement - improves detail and sharpness while keeping same dimensions."""
        sharpness = float(parameters.get('sharpness', 1.0))
        detail = float(parameters.get('detail', 0.5))
        contrast = float(parameters.get('contrast', 0.3))
        denoise = float(parameters.get('denoise', 0.2))
        enhance_edges = parameters.get('enhance_edges', True)
        preserve_colors = parameters.get('preserve_colors', True)
        
        if pil_img.mode != 'RGBA':
            pil_img = pil_img.convert('RGBA')
        
        img_array = np.array(pil_img, dtype=np.float32)
        height, width = img_array.shape[:2]
        rgb_img = img_array[:, :, :3].astype(np.uint8)
        
        import cv2
        bgr_img = cv2.cvtColor(rgb_img, cv2.COLOR_RGB2BGR)
        
        # Optional denoising
        if denoise > 0:
            denoised = cv2.fastNlMeansDenoisingColored(
                bgr_img, None,
                h=int(denoise * 10),
                hColor=int(denoise * 10),
                templateWindowSize=7,
                searchWindowSize=21
            )
            bgr_img = cv2.addWeighted(bgr_img, 1.0 - denoise, denoised, denoise, 0)
        
        # Edge-aware sharpening and detail enhancement
        if enhance_edges:
            lab = cv2.cvtColor(bgr_img, cv2.COLOR_BGR2LAB)
            l_channel, a_channel, b_channel = cv2.split(lab)
            
            blurred_l = cv2.GaussianBlur(l_channel, (0, 0), 1.0)
            sharpened_l = cv2.addWeighted(l_channel, 1.0 + sharpness, blurred_l, -sharpness, 0)
            
            if detail > 0:
                detail_layer = cv2.subtract(l_channel.astype(np.float32), blurred_l.astype(np.float32))
                enhanced_l = np.clip(l_channel.astype(np.float32) + detail_layer * detail, 0, 255).astype(np.uint8)
                l_final = cv2.addWeighted(sharpened_l, 0.7, enhanced_l, 0.3, 0)
            else:
                l_final = sharpened_l
            
            if contrast > 0:
                clahe = cv2.createCLAHE(clipLimit=1.0 + contrast * 2.0, tileGridSize=(8, 8))
                l_final = clahe.apply(l_final)
            
            enhanced_lab = cv2.merge([l_final, a_channel, b_channel])
            result_bgr = cv2.cvtColor(enhanced_lab, cv2.COLOR_LAB2BGR)
        else:
            blurred = cv2.GaussianBlur(bgr_img, (0, 0), 1.0)
            result_bgr = cv2.addWeighted(bgr_img, 1.0 + sharpness, blurred, -sharpness, 0)
        
        # Color preservation
        if preserve_colors:
            hsv_original = cv2.cvtColor(rgb_img, cv2.COLOR_RGB2HSV)
            hsv_result = cv2.cvtColor(cv2.cvtColor(result_bgr, cv2.COLOR_BGR2RGB), cv2.COLOR_RGB2HSV)
            hsv_result[:, :, 0] = hsv_original[:, :, 0]
            hsv_result[:, :, 1] = cv2.addWeighted(hsv_original[:, :, 1], 0.8, hsv_result[:, :, 1], 0.2, 0)
            result_rgb = cv2.cvtColor(hsv_result, cv2.COLOR_HSV2RGB)
        else:
            result_rgb = cv2.cvtColor(result_bgr, cv2.COLOR_BGR2RGB)
        
        result_rgba = np.zeros((height, width, 4), dtype=np.uint8)
        result_rgba[:, :, :3] = np.clip(result_rgb, 0, 255).astype(np.uint8)
        result_rgba[:, :, 3] = img_array[:, :, 3].astype(np.uint8)
        
        return result_rgba
    
    def _apply_upscale(self, pil_img: Image.Image, parameters: Dict[str, Any]) -> np.ndarray:
        """Apply enhanced upscaling with edge-aware sharpening and multi-pass refinement."""
        scale = int(parameters.get('scale', 2))
        sharpening = float(parameters.get('sharpening', 1.2))
        enhance_edges = parameters.get('enhance_edges', True)
        
        if pil_img.mode != 'RGBA':
            pil_img = pil_img.convert('RGBA')
        
        width, height = pil_img.size
        new_width = width * scale
        new_height = height * scale
        
        upscaled = pil_img.resize((new_width, new_height), Image.LANCZOS)
        
        import cv2
        upscaled_array = np.array(upscaled, dtype=np.float32)
        h, w = upscaled_array.shape[:2]
        
        if enhance_edges:
            rgb_img = upscaled_array[:, :, :3].astype(np.uint8)
            bgr_img = cv2.cvtColor(rgb_img, cv2.COLOR_RGB2BGR)
            
            gray = cv2.cvtColor(bgr_img, cv2.COLOR_BGR2GRAY)
            laplacian = cv2.Laplacian(gray, cv2.CV_64F)
            edge_strength = np.abs(laplacian)
            edge_mask = np.clip(edge_strength / np.max(edge_strength) if np.max(edge_strength) > 0 else edge_strength, 0, 1)
            edge_mask_3d = edge_mask[:, :, np.newaxis]
            
            blurred_bgr = cv2.GaussianBlur(bgr_img, (0, 0), 1.0)
            unsharp_bgr = bgr_img.astype(np.float32) + (bgr_img.astype(np.float32) - blurred_bgr.astype(np.float32)) * sharpening
            
            result_bgr = bgr_img.astype(np.float32) * (1 - edge_mask_3d * 0.3) + unsharp_bgr * (edge_mask_3d * 0.3 + (1 - edge_mask_3d) * 0.1)
            result_bgr = np.clip(result_bgr, 0, 255).astype(np.uint8)
            result_rgb = cv2.cvtColor(result_bgr, cv2.COLOR_BGR2RGB)
        else:
            rgb_img = upscaled_array[:, :, :3].astype(np.uint8)
            bgr_img = cv2.cvtColor(rgb_img, cv2.COLOR_RGB2BGR)
            blurred_bgr = cv2.GaussianBlur(bgr_img, (0, 0), 1.0)
            result_bgr = np.clip(bgr_img.astype(np.float32) + (bgr_img.astype(np.float32) - blurred_bgr.astype(np.float32)) * sharpening, 0, 255).astype(np.uint8)
            result_rgb = cv2.cvtColor(result_bgr, cv2.COLOR_BGR2RGB)
        
        result_rgba = np.zeros((h, w, 4), dtype=np.uint8)
        result_rgba[:, :, :3] = result_rgb
        result_rgba[:, :, 3] = upscaled_array[:, :, 3].astype(np.uint8)
        
        return result_rgba
    
    def _apply_motion_blur(self, pil_img: Image.Image, parameters: Dict[str, Any]) -> np.ndarray:
        """Apply motion blur effect."""
        angle = parameters.get('angle', 45)
        distance = int(parameters.get('distance', 10))
        
        if pil_img.mode != 'RGBA':
            pil_img = pil_img.convert('RGBA')
        
        img_array = np.array(pil_img)
        rad = math.radians(angle)
        kernel_size = distance * 2 + 1
        kernel = np.zeros((kernel_size, kernel_size))
        
        for i in range(-distance, distance + 1):
            x_offset = int(i * math.cos(rad))
            y_offset = int(i * math.sin(rad))
            center = kernel_size // 2
            x = center + x_offset
            y = center + y_offset
            if 0 <= x < kernel_size and 0 <= y < kernel_size:
                kernel[y, x] = 1.0
        
        kernel /= kernel.sum()
        result = img_array.copy()
        for channel in range(3):
            result[:, :, channel] = ndimage.convolve(img_array[:, :, channel], kernel)
        result[:, :, 3] = img_array[:, :, 3]
        return result
    
    def _apply_shader_bloom(self, pil_img: Image.Image, parameters: Dict[str, Any]) -> np.ndarray:
        """Apply shader bloom effect - optimized with OpenCV."""
        intensity = parameters.get('intensity', 1.0)
        threshold = parameters.get('threshold', 200)
        radius = int(parameters.get('radius', 15))
        
        if pil_img.mode != 'RGBA':
            pil_img = pil_img.convert('RGBA')
        
        img_array = np.array(pil_img, dtype=np.float32)
        height, width = img_array.shape[:2]
        
        # Extract bright areas above threshold
        bright_mask = np.max(img_array[:, :, :3], axis=2) > threshold
        bright_pixels = img_array.copy()
        bright_pixels[~bright_mask] = 0
        
        # Convert to uint8 for OpenCV
        bright_pixels_uint8 = np.clip(bright_pixels[:, :, :3], 0, 255).astype(np.uint8)
        
        # Use OpenCV for much faster Gaussian blur
        bright_bgr = cv2.cvtColor(bright_pixels_uint8, cv2.COLOR_RGB2BGR)
        
        # Calculate kernel size (must be odd)
        kernel_size = int(radius * 6) | 1
        if kernel_size < 3:
            kernel_size = 3
        
        # First blur pass
        bloom_bgr = cv2.GaussianBlur(bright_bgr, (kernel_size, kernel_size), radius)
        
        # Second pass (reduced radius)
        radius2 = radius * 0.7
        kernel_size2 = int(radius2 * 6) | 1
        if kernel_size2 < 3:
            kernel_size2 = 3
        bloom_bgr = cv2.GaussianBlur(bloom_bgr, (kernel_size2, kernel_size2), radius2)
        
        # Convert back to RGB
        bloom_rgb = cv2.cvtColor(bloom_bgr, cv2.COLOR_BGR2RGB).astype(np.float32)
        
        # Add bloom to original
        result = np.clip(img_array[:, :, :3] + (bloom_rgb * intensity), 0, 255).astype(np.uint8)
        
        # Reconstruct RGBA
        result_rgba = np.zeros((height, width, 4), dtype=np.uint8)
        result_rgba[:, :, :3] = result
        result_rgba[:, :, 3] = img_array[:, :, 3].astype(np.uint8)
        
        return result_rgba
    
    def _apply_palette_cycler(self, pil_img: Image.Image, parameters: Dict[str, Any]) -> np.ndarray:
        """Apply palette cycling effect - shifts colors in a cycle."""
        cycle_speed = parameters.get('cycle_speed', 0.5)
        direction = parameters.get('direction', 'forward')
        
        if pil_img.mode != 'RGBA':
            pil_img = pil_img.convert('RGBA')
        
        img_array = np.array(pil_img)
        
        # Apply hue shift based on pixel intensity
        result = np.zeros_like(img_array)
        for y in range(img_array.shape[0]):
            for x in range(img_array.shape[1]):
                r, g, b, a = img_array[y, x]
                
                # Convert to HSV
                h, s, v = rgb_to_hsv(r/255.0, g/255.0, b/255.0)
                
                # Add hue shift based on pixel intensity
                shift = cycle_speed * (v * 2 - 1)
                if direction == 'reverse':
                    shift = -shift
                
                h_shifted = (h + shift) % 1.0
                
                # Convert back to RGB
                r_new, g_new, b_new = hsv_to_rgb(h_shifted, s, v)
                result[y, x] = [int(r_new*255), int(g_new*255), int(b_new*255), a]
        
        return result
    
    def _apply_pixel_depth(self, pil_img: Image.Image, parameters: Dict[str, Any]) -> np.ndarray:
        """Apply pixel depth mapping effect - creates 3D depth illusion."""
        depth = parameters.get('depth', 0.5)
        angle = parameters.get('angle', 45)
        
        if pil_img.mode != 'RGBA':
            pil_img = pil_img.convert('RGBA')
        
        img_array = np.array(pil_img, dtype=np.float32)
        
        # Convert to grayscale to use as depth map
        gray = np.dot(img_array[:, :, :3], [0.299, 0.587, 0.114])
        
        # Create depth offset based on angle
        rad = math.radians(angle)
        offset_x = depth * math.cos(rad)
        offset_y = depth * math.sin(rad)
        
        # Create displacement map
        displacement = (gray - 128) / 128  # Normalize to -1 to 1
        displ_x = displacement * offset_x
        displ_y = displacement * offset_y
        
        # Apply displacement (simplified: just darken/lighten based on depth)
        result = img_array.copy()
        depth_factor = 1 + (displacement * depth)
        
        # Apply depth shading
        result[:, :, :3] = np.clip(img_array[:, :, :3] * depth_factor[:, :, np.newaxis], 0, 255)
        result[:, :, 3] = img_array[:, :, 3]
        
        result = np.clip(result, 0, 255).astype(np.uint8)
        return result
    
    def _apply_hd_crisp(self, pil_img: Image.Image, parameters: Dict[str, Any]) -> np.ndarray:
        """Apply HD Crisp effect - optimized with OpenCV and size limits."""
        upscale_factor = int(parameters.get('upscale', 2))
        sharpening = parameters.get('sharpening', 1.0)
        edge_enhancement = parameters.get('edge_enhancement', 0.8)
        denoise = parameters.get('denoise', False)
        
        if pil_img.mode != 'RGBA':
            pil_img = pil_img.convert('RGBA')
        
        img_array = np.array(pil_img, dtype=np.float32)
        height, width = img_array.shape[:2]
        
        # Safety check: Limit maximum output size
        max_dimension = 4000
        original_max = max(width, height)
        if original_max * upscale_factor > max_dimension:
            safe_upscale = max(1, int(max_dimension / original_max))
            upscale_factor = min(upscale_factor, safe_upscale)
        
        # Step 1: Upscale using high-quality Lanczos interpolation
        new_width = width * upscale_factor
        new_height = height * upscale_factor
        upscaled = pil_img.resize((new_width, new_height), Image.LANCZOS)
        upscaled_array = np.array(upscaled, dtype=np.float32)
        up_h, up_w = upscaled_array.shape[:2]
        
        # Step 2: Edge detection using OpenCV
        upscaled_rgb = upscaled_array[:, :, :3].astype(np.uint8)
        gray = cv2.cvtColor(upscaled_rgb, cv2.COLOR_RGB2GRAY)
        
        sobel_x = cv2.Sobel(gray, cv2.CV_64F, 1, 0, ksize=3)
        sobel_y = cv2.Sobel(gray, cv2.CV_64F, 0, 1, ksize=3)
        edge_magnitude = np.sqrt(sobel_x**2 + sobel_y**2)
        edge_max = np.max(edge_magnitude)
        if edge_max > 0:
            edge_mask = edge_magnitude / edge_max
        else:
            edge_mask = np.zeros_like(edge_magnitude)
        
        # Step 3: Enhanced unsharp masking
        upscaled_bgr = cv2.cvtColor(upscaled_rgb, cv2.COLOR_RGB2BGR)
        blur_sigma = 1.0 + (upscale_factor - 2) * 0.3
        blurred_bgr = cv2.GaussianBlur(upscaled_bgr, (0, 0), blur_sigma)
        blurred_rgb = cv2.cvtColor(blurred_bgr, cv2.COLOR_BGR2RGB).astype(np.float32)
        
        unsharp = upscaled_array[:, :, :3] + (upscaled_array[:, :, :3] - blurred_rgb) * sharpening * 1.2
        unsharp = np.clip(unsharp, 0, 255)
        
        # Step 4: Enhanced edge enhancement
        edge_boost = upscaled_array[:, :, :3].copy().astype(np.float32)
        gray_float = gray.astype(np.float32)
        laplacian = cv2.Laplacian(gray_float, cv2.CV_64F)
        
        edge_mask_3d = edge_mask[:, :, np.newaxis]
        laplacian_3d = np.stack([laplacian] * 3, axis=2)
        laplacian_norm = np.clip((laplacian_3d + 128) / 128.0, 0.5, 1.5)
        edge_boost = edge_boost * laplacian_norm * (1.0 + edge_mask_3d * edge_enhancement * 0.5)
        edge_boost = np.clip(edge_boost, 0, 255)
        
        # Step 5: Blend unsharp and edge-enhanced versions
        result = (unsharp * (1 - edge_mask_3d) + edge_boost * edge_mask_3d)
        result = np.clip(result, 0, 255)
        
        # Step 6: Optional denoising
        if denoise:
            result_uint8 = result.astype(np.uint8)
            result_bgr = cv2.cvtColor(result_uint8, cv2.COLOR_RGB2BGR)
            result_bgr = cv2.medianBlur(result_bgr, 3)
            result = cv2.cvtColor(result_bgr, cv2.COLOR_BGR2RGB).astype(np.float32)
        
        # Step 7: Enhanced contrast boost
        result = np.power(result / 255.0, 0.92) * 255
        result = np.clip(result, 0, 255)
        
        # Reconstruct RGBA
        result_rgba = np.zeros((up_h, up_w, 4), dtype=np.uint8)
        result_rgba[:, :, :3] = result.astype(np.uint8)
        result_rgba[:, :, 3] = upscaled_array[:, :, 3].astype(np.uint8)
        
        return result_rgba
    
    def _apply_mirror_horizontal_effect(self, pil_img: Image.Image) -> np.ndarray:
        """Apply horizontal mirror effect."""
        mirrored = pil_img.transpose(Image.FLIP_LEFT_RIGHT)
        return np.array(mirrored)
    
    def _apply_mirror_vertical_effect(self, pil_img: Image.Image) -> np.ndarray:
        """Apply vertical mirror effect."""
        mirrored = pil_img.transpose(Image.FLIP_TOP_BOTTOM)
        return np.array(mirrored)
    
    def _apply_rotate_90_effect(self, pil_img: Image.Image) -> np.ndarray:
        """Apply 90 degree rotation."""
        rotated = pil_img.rotate(-90, expand=True)
        return np.array(rotated)
    
    def _apply_rotate_180_effect(self, pil_img: Image.Image) -> np.ndarray:
        """Apply 180 degree rotation."""
        rotated = pil_img.rotate(180)
        return np.array(rotated)
    
    def _apply_rotate_custom_effect(self, pil_img: Image.Image, parameters: Dict[str, Any]) -> np.ndarray:
        """Apply custom rotation."""
        angle = parameters.get('angle', 90)
        rotated = pil_img.rotate(-angle, expand=True)
        return np.array(rotated)
    
    def _apply_dither_effect(self, img_array: np.ndarray, parameters: Dict[str, Any]) -> np.ndarray:
        """Apply dithering effect."""
        method = parameters.get('method', 'Floyd-Steinberg')
        intensity = parameters.get('intensity', 1.0)
        
        height, width = img_array.shape[:2]
        max_levels = 16
        min_levels = 4
        levels = max(min_levels, int(max_levels * (1 - intensity * 0.9)))
        
        np.random.seed(42)
        noise = np.random.uniform(-1, 1, (height, width, 3)) * intensity * 32
        
        step = 256 / levels
        result = np.round(img_array / step) * step
        
        result = result + noise
        
        return np.clip(result, 0, 255).astype(np.uint8)
    
    def _apply_pixelate_effect(self, img_array: np.ndarray, parameters: Dict[str, Any]) -> np.ndarray:
        """Apply simple pixelate effect with customizable block size."""
        block_size = parameters.get('block_size', 4)
        
        height, width = img_array.shape[:2]
        
        if len(img_array.shape) == 3 and img_array.shape[2] == 4:
            rgb_array = img_array[:, :, :3]
            alpha_channel = img_array[:, :, 3]
        else:
            rgb_array = img_array
            alpha_channel = None
        
        result = self._pixelate_blocks(rgb_array, block_size)
        
        if alpha_channel is not None:
            result_img = np.zeros((height, width, 4), dtype=np.uint8)
            result_img[:, :, :3] = result
            result_img[:, :, 3] = alpha_channel
        else:
            result_img = result
        
        return result_img
    
    def _pixelate_blocks(self, img_array: np.ndarray, block_size: int) -> np.ndarray:
        """Create pixelated blocks by averaging colors."""
        height, width = img_array.shape[:2]
        result = img_array.copy()
        
        for y in range(0, height, block_size):
            for x in range(0, width, block_size):
                y_end = min(y + block_size, height)
                x_end = min(x + block_size, width)
                
                block = img_array[y:y_end, x:x_end]
                avg_color = np.mean(block, axis=(0, 1))
                
                result[y:y_end, x:x_end] = avg_color
        
        return result
    
    # Complex effects that need state/UI - these remain in main_window for now
    def _apply_map_generator_effect(self, pil_img: Image.Image, parameters: Dict[str, Any]) -> np.ndarray:
        """Apply map generator effect - needs state access, keep in main_window."""
        # This effect is complex and needs state access, so it should remain in main_window
        # or be refactored to accept state as parameter
        return np.array(pil_img)
    
    def _apply_texture_2d_effect(self, pil_img: Image.Image, parameters: Dict[str, Any]) -> np.ndarray:
        """Apply texture 2D effect - needs state access, keep in main_window."""
        return np.array(pil_img)
    
    def _apply_generate_lod_effect(self, pil_img: Image.Image, parameters: Dict[str, Any]) -> np.ndarray:
        """Apply LOD generation effect - needs state access, keep in main_window."""
        return np.array(pil_img)
    
    def _apply_atmospheric_lighting_effect(self, pil_img: Image.Image, parameters: Dict[str, Any]) -> np.ndarray:
        """Apply atmospheric lighting effect - placeholder."""
        return np.array(pil_img)
    
    def _apply_wind_waker_effect(self, pil_img: Image.Image, parameters: Dict[str, Any]) -> np.ndarray:
        """Apply Wind Waker effect - placeholder."""
        return np.array(pil_img)
    
    def _apply_ocarina_of_time_effect(self, pil_img: Image.Image, parameters: Dict[str, Any]) -> np.ndarray:
        """Apply Ocarina of Time effect - placeholder."""
        return np.array(pil_img)
    
    def _apply_luigis_mansion_effect(self, pil_img: Image.Image, parameters: Dict[str, Any]) -> np.ndarray:
        """Apply Luigi's Mansion effect - placeholder."""
        return np.array(pil_img)
    
    def _apply_eternal_darkness_effect(self, pil_img: Image.Image, parameters: Dict[str, Any]) -> np.ndarray:
        """Apply Eternal Darkness effect - placeholder."""
        return np.array(pil_img)
    
    def _apply_pokemon_colosseum_effect(self, pil_img: Image.Image, parameters: Dict[str, Any]) -> np.ndarray:
        """Apply Pokemon Colosseum effect - placeholder."""
        return np.array(pil_img)
    
    def _apply_mario_kart_8_effect(self, pil_img: Image.Image, parameters: Dict[str, Any]) -> np.ndarray:
        """Apply Mario Kart 8 effect - placeholder."""
        return np.array(pil_img)
