import numpy as np
from PySide6.QtGui import QImage, QColor
import math
import random
import warnings

def hex_to_qcolor(hex_color):
    """Convert hex color string to QColor."""
    if hex_color.startswith('#'):
        hex_color = hex_color[1:]
    r = int(hex_color[0:2], 16)
    g = int(hex_color[2:4], 16)
    b = int(hex_color[4:6], 16)
    return QColor(r, g, b, 255)

def lerp_color(c1, c2, t):
    """Linear interpolation between two QColors."""
    r = int(c1.red() * (1 - t) + c2.red() * t)
    g = int(c1.green() * (1 - t) + c2.green() * t)
    b = int(c1.blue() * (1 - t) + c2.blue() * t)
    a = int(c1.alpha() * (1 - t) + c2.alpha() * t)
    return QColor(r, g, b, a)

def make_gradient_palette_qt(c1, c2, steps=6):
    # Ensure colors have full alpha
    c1 = QColor(c1.red(), c1.green(), c1.blue(), 255)
    c2 = QColor(c2.red(), c2.green(), c2.blue(), 255)
    
    palette = []
    for i in range(steps):
        t = i / (steps - 1)
        palette.append(lerp_color(c1, c2, t))
    return palette

# Centralized noise functions using the existing system
def vectorized_noise(x, y, seed=0):
    """Vectorized coherent noise function from the centralized system."""
    # Use int64 throughout to prevent overflow warnings
    n = (x * 73856093 + y * 19349663 + seed).astype(np.int64) & 0x7fffffff
    n = (n << 13) ^ n
    n = n.astype(np.int64)
    
    # Suppress overflow warnings for these multiplications
    # We're using int64 which can safely handle the intermediate results
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", RuntimeWarning)
        # Reduce n modulo 0x7fffffff before squaring to keep values smaller
        n_mod = n % 0x7fffffff
        # Calculate n^2: intermediate result fits in int64 (max ~9.2e18)
        n_squared = (n_mod * n_mod) % 0x7fffffff
        # Calculate n^3: multiply squared result by n_mod
        n_cubed = (n_squared * n_mod) % 0x7fffffff
    
    # Final calculation with bitwise AND to ensure positive result
    result = ((n_cubed * 15731 + 789221) + 1376312589) & 0x7fffffff
    return result.astype(np.float64) / 0x7fffffff

def vectorized_smooth_noise(x, y, seed=0):
    """Vectorized smooth noise using bilinear interpolation."""
    x_int = np.floor(x).astype(int)
    y_int = np.floor(y).astype(int)
    x_frac = x - x_int
    y_frac = y - y_int
    
    v1 = vectorized_noise(x_int, y_int, seed)
    v2 = vectorized_noise(x_int + 1, y_int, seed)
    v3 = vectorized_noise(x_int, y_int + 1, seed)
    v4 = vectorized_noise(x_int + 1, y_int + 1, seed)
    
    i1 = v1 * (1 - x_frac) + v2 * x_frac
    i2 = v3 * (1 - x_frac) + v4 * x_frac
    return i1 * (1 - y_frac) + i2 * y_frac

def vectorized_fractal_noise(x, y, octaves=4, persistence=0.5, seed=0):
    """Vectorized fractal noise using multiple octaves."""
    total = np.zeros_like(x)
    frequency = 1.0
    amplitude = 1.0
    max_value = 0
    
    for i in range(octaves):
        total += vectorized_smooth_noise(x * frequency, y * frequency, seed + i) * amplitude
        max_value += amplitude
        amplitude *= persistence
        frequency *= 2
    
    return np.clip(total / max_value, 0, 1)

def animate_palette_qt(palette, anim_type, frame_idx):
    """Apply distinct animation patterns for each style type using centralized noise system."""
    if not palette or len(palette) < 2:
        return palette
    
    if anim_type == "Water":
        # Water: Realistic ripples and currents using centralized noise
        time_factor = frame_idx * 0.1
        new_palette = []
        
        for i, color in enumerate(palette):
            # Create flowing water effect with multiple noise layers
            x = i * 0.3 + time_factor
            y = time_factor * 0.5
            
            # Primary flow noise
            flow_noise = vectorized_fractal_noise(x, y, octaves=3, persistence=0.5, seed=100)
            
            # Secondary ripple noise
            ripple_noise = vectorized_fractal_noise(x * 2.0, y * 1.5, octaves=2, persistence=0.6, seed=200)
            
            # Depth variation
            depth_noise = vectorized_fractal_noise(x * 0.5, y * 0.3, octaves=2, persistence=0.7, seed=300)
            
            # Combine noise layers
            water_factor = 0.7 + 0.3 * (flow_noise * 0.6 + ripple_noise * 0.3 + depth_noise * 0.1)
            
            # Water color enhancement - boost blues, reduce reds
            r = int(color.red() * water_factor * 0.7)  # Reduce red
            g = int(color.green() * water_factor * 0.9)  # Slightly reduce green
            b = int(color.blue() * water_factor * 1.4)   # Enhance blue significantly
            a = color.alpha()
            
            # Ensure bounds
            r = min(255, max(0, r))
            g = min(255, max(0, g))
            b = min(255, max(0, b))
            
            new_palette.append(QColor(r, g, b, a))
        return new_palette
        
    elif anim_type == "Lava":
        # Lava: Bubbling animation without dark frames
        time_factor = frame_idx * 0.3
        new_palette = []
        
        for i, color in enumerate(palette):
            # Use absolute sine for always-positive pulsing (0.0 to 1.0 range)
            # This ensures no frame gets stuck in the dark zone
            pulse_input = time_factor + i * 0.5
            pulse_raw = math.sin(pulse_input)
            
            # Map sine from [-1, 1] to [0.85, 1.15] to keep brightness consistent
            # This gives variation without going too dark
            heat_pulse = 1.0 + 0.15 * pulse_raw  # Range: 0.85 to 1.15
            
            # Apply lava color transformation
            r = int(color.red() * heat_pulse * 1.2)    # Boost red
            g = int(color.green() * heat_pulse * 0.8)  # Medium green for orange
            b = int(color.blue() * heat_pulse * 0.3)   # Low blue
            
            # Add bright highlights for hot spots (when pulse is high)
            if heat_pulse > 1.08:
                brightness_boost = int((heat_pulse - 1.08) * 300)
                r = min(255, r + brightness_boost)
                g = min(255, g + int(brightness_boost * 0.8))
                b = min(255, b + int(brightness_boost * 0.2))
            
            # Ensure minimum brightness - no darkening below original
            r = min(255, max(int(color.red() * 0.85), r))
            g = min(255, max(int(color.green() * 0.7), g))
            b = min(255, max(int(color.blue() * 0.25), b))
            
            a = color.alpha()
            
            new_palette.append(QColor(r, g, b, a))
        
        return new_palette
        
    elif anim_type == "Fire":
        # Fire: Flickering flame shapes with rising particles
        time_factor = frame_idx * 0.2
        new_palette = []
        
        for i, color in enumerate(palette):
            # Create flame flicker effect
            x = i * 0.3 + time_factor
            y = time_factor * 1.2
            
            # Primary flame noise
            flame_noise = vectorized_fractal_noise(x, y, octaves=3, persistence=0.6, seed=700)
            
            # Flicker noise
            flicker_noise = vectorized_fractal_noise(x * 3.0, y * 2.0, octaves=2, persistence=0.4, seed=800)
            
            # Rising movement
            rise_factor = 1.0 + 0.3 * math.sin(i * 0.5 + time_factor * 0.8)
            
            # Combine for realistic fire
            fire_factor = 0.5 + 0.5 * (flame_noise * 0.7 + flicker_noise * 0.3) * rise_factor
            
            # Fire color transformation
            r = int(color.red() * fire_factor * 1.6)  # Strong red
            g = int(color.green() * fire_factor * 1.2)  # Good green for yellow
            b = int(color.blue() * fire_factor * 0.5)   # Minimal blue
            a = int(color.alpha() * (0.8 + fire_factor * 0.2))  # Vary alpha for flicker
            
            # Add bright yellow/white highlights for hot spots
            if fire_factor > 1.2:
                r = min(255, r + 50)
                g = min(255, g + 40)
                b = min(255, b + 20)
            
            # Ensure bounds
            r = min(255, max(0, r))
            g = min(255, max(0, g))
            b = min(255, max(0, b))
            a = min(255, max(0, a))
            
            new_palette.append(QColor(r, g, b, a))
        return new_palette
        
    elif anim_type == "Smoke":
        # Smoke: Wispy, swirling cloud formations
        time_factor = frame_idx * 0.08
        new_palette = []
        
        for i, color in enumerate(palette):
            # Create smoke swirls
            x = i * 0.2 + time_factor
            y = time_factor * 0.6
            
            # Primary smoke noise
            smoke_noise = vectorized_fractal_noise(x, y, octaves=4, persistence=0.5, seed=900)
            
            # Swirling motion
            swirl_noise = vectorized_fractal_noise(x * 1.5, y * 1.8, octaves=3, persistence=0.6, seed=1000)
            
            # Density variation
            density_noise = vectorized_fractal_noise(x * 0.8, y * 0.4, octaves=2, persistence=0.7, seed=1100)
            
            # Combine for realistic smoke
            smoke_factor = 0.3 + 0.7 * (smoke_noise * 0.6 + swirl_noise * 0.3 + density_noise * 0.1)
            
            # Smoke color - grayscale with slight color tint
            intensity = smoke_factor * 0.8
            r = int(color.red() * intensity)
            g = int(color.green() * intensity)
            b = int(color.blue() * intensity)
            a = int(color.alpha() * smoke_factor * 0.7)  # Reduce alpha for smoke effect
            
            # Ensure bounds
            r = min(255, max(0, r))
            g = min(255, max(0, g))
            b = min(255, max(0, b))
            a = min(255, max(0, a))
            
            new_palette.append(QColor(r, g, b, a))
        return new_palette
        
    elif anim_type == "Fog":
        # Fog: Slow drift with opacity changes
        time_factor = frame_idx * 0.05
        new_palette = []
        
        for i, color in enumerate(palette):
            # Create fog drift
            x = i * 0.15 + time_factor
            y = time_factor * 0.3
            
            # Primary fog noise
            fog_noise = vectorized_fractal_noise(x, y, octaves=3, persistence=0.6, seed=1200)
            
            # Drift motion
            drift_noise = vectorized_fractal_noise(x * 0.7, y * 1.2, octaves=2, persistence=0.7, seed=1300)
            
            # Opacity variation
            opacity_noise = vectorized_fractal_noise(x * 1.3, y * 0.6, octaves=2, persistence=0.5, seed=1400)
            
            # Combine for realistic fog
            fog_factor = 0.4 + 0.6 * (fog_noise * 0.7 + drift_noise * 0.2 + opacity_noise * 0.1)
            
            # Fog color - light grays with slight blue tint
            intensity = fog_factor * 0.9
            r = int(color.red() * intensity)
            g = int(color.green() * intensity)
            b = int(color.blue() * intensity * 1.1)  # Slight blue tint
            a = int(color.alpha() * fog_factor * 0.8)  # Vary opacity
            
            # Ensure bounds
            r = min(255, max(0, r))
            g = min(255, max(0, g))
            b = min(255, max(0, b))
            a = min(255, max(0, a))
            
            new_palette.append(QColor(r, g, b, a))
        return new_palette
        
    elif anim_type == "Crystal":
        # Crystal: Sharp sparkles and refraction
        time_factor = frame_idx * 0.25
        new_palette = []
        
        for i, color in enumerate(palette):
            # Create crystal sparkles
            x = i * 0.4 + time_factor
            y = time_factor * 0.9
            
            # Primary sparkle noise
            sparkle_noise = vectorized_fractal_noise(x, y, octaves=2, persistence=0.4, seed=1500)
            
            # Refraction noise
            refraction_noise = vectorized_fractal_noise(x * 2.0, y * 1.5, octaves=3, persistence=0.6, seed=1600)
            
            # Sharp sparkle effect
            sparkle_factor = 0.3 + 0.7 * sparkle_noise
            if sparkle_factor > 0.8:
                sparkle_factor *= 2.0  # Bright sparkles
            
            # Crystal color enhancement
            r = int(color.red() * sparkle_factor)
            g = int(color.green() * sparkle_factor)
            b = int(color.blue() * sparkle_factor * 1.4)  # Enhance blue for crystal
            a = color.alpha()
            
            # Add refraction color shift
            if refraction_noise > 0.6:
                r = min(255, r + 20)
                g = min(255, g + 15)
                b = min(255, b + 30)
            
            # Ensure bounds
            r = min(255, max(0, r))
            g = min(255, max(0, g))
            b = min(255, max(0, b))
            
            new_palette.append(QColor(r, g, b, a))
        return new_palette
        
    elif anim_type == "Wind":
        # Wind: Rapid directional movement with gusts
        time_factor = frame_idx * 0.3
        new_palette = []
        
        for i, color in enumerate(palette):
            # Create wind movement
            x = i * 0.5 + time_factor
            y = time_factor * 0.4
            
            # Primary wind noise
            wind_noise = vectorized_fractal_noise(x, y, octaves=2, persistence=0.5, seed=1700)
            
            # Gust noise
            gust_noise = vectorized_fractal_noise(x * 3.0, y * 1.0, octaves=1, persistence=0.3, seed=1800)
            
            # Directional movement
            direction_factor = 1.0 + 0.5 * math.sin(i * 0.3 + time_factor * 1.5)
            
            # Combine for wind effect
            wind_factor = 0.6 + 0.4 * (wind_noise * 0.7 + gust_noise * 0.3) * direction_factor
            
            # Wind color - slight green tint for nature
            r = int(color.red() * wind_factor)
            g = int(color.green() * wind_factor * 1.1)  # Slight green enhancement
            b = int(color.blue() * wind_factor)
            a = color.alpha()
            
            # Ensure bounds
            r = min(255, max(0, r))
            g = min(255, max(0, g))
            b = min(255, max(0, b))
            
            new_palette.append(QColor(r, g, b, a))
        return new_palette
        
    elif anim_type == "Portal":
        # Portal: Energy pulsing with dimensional distortion and chromatic aberration
        time_factor = frame_idx * 0.4  # Increased for more dramatic portal effects
        new_palette = []
        
        for i, color in enumerate(palette):
            # Create portal effects with more dramatic movement
            x = i * 0.3 + time_factor
            y = time_factor * 1.0  # Faster movement
            
            # Energy pulse noise with time variation
            energy_noise = vectorized_fractal_noise(x, y, octaves=3, persistence=0.6, seed=1900)
            
            # Distortion noise with faster changes
            distortion_noise = vectorized_fractal_noise(x * 2.0 + time_factor * 0.3, y * 1.8 + time_factor * 0.2, octaves=4, persistence=0.4, seed=2000)
            
            # Swirling motion with more dramatic rotation
            swirl_noise = vectorized_fractal_noise(x * 1.5 + time_factor * 0.4, y * 2.2 + time_factor * 0.3, octaves=2, persistence=0.5, seed=2100)
            
            # Combine for portal effect with more variation
            portal_factor = 0.4 + 0.6 * (energy_noise * 0.5 + distortion_noise * 0.3 + swirl_noise * 0.2)
            
            # Chromatic aberration effect with faster pulsing
            aberration = math.sin(i * 0.2 + time_factor * 1.0) * 20  # Increased amplitude and speed
            
            # Portal color with rainbow refraction
            r = int(color.red() * portal_factor + aberration)
            g = int(color.green() * portal_factor + aberration * 0.8)
            b = int(color.blue() * portal_factor + aberration * 1.2)
            # Fix alpha calculation to ensure proper opacity for all frames
            # Ensure minimum alpha of 0.8 (80%) and maximum of 1.0 (100%)
            alpha_factor = max(0.8, min(1.0, 0.7 + portal_factor * 0.3))
            a = int(color.alpha() * alpha_factor)
            
            # Add energy glow
            if portal_factor > 1.0:
                r = min(255, r + 30)
                g = min(255, g + 20)
                b = min(255, b + 40)
            
            # Ensure bounds
            r = min(255, max(0, r))
            g = min(255, max(0, g))
            b = min(255, max(0, b))
            a = min(255, max(0, a))
            
            new_palette.append(QColor(r, g, b, a))
        return new_palette
        
    else:
        # Default: No animation
        return palette

def generate_block_texture_qimage(width, height, palette, block_size=4, opacity=255, style="None", style_params=None, frame_idx=0, seed=None):
    # palette: list of hex strings or QColor
    # Set random seed for consistent generation if provided
    if seed is not None:
        random.seed(seed)
    
    # Create gradient palette from the two colors
    palette_qt = [hex_to_qcolor(c) if isinstance(c, str) else c for c in palette]
    
    # Create a gradient palette with variations of the two colors
    if len(palette_qt) >= 2:
        gradient_palette = make_gradient_palette_qt(palette_qt[0], palette_qt[1], steps=6)
    else:
        gradient_palette = palette_qt
    
    # Apply style effects to the palette first
    if style != "None" and style_params:
        gradient_palette = apply_style_effects(gradient_palette, style, style_params, frame_idx)
    
    # Then apply animation effects to create distinct movement patterns
    # Only animate styles that are actually animated
    animated_styles = ['Water', 'Lava', 'Fire', 'Smoke', 'Fog', 'Crystal', 'Wind', 'Portal']
    if style in animated_styles:
        gradient_palette = animate_palette_qt(gradient_palette, style, frame_idx)
    
    arr = np.zeros((height, width, 4), dtype=np.uint8)
    
    # For animated styles, we need to create spatial animation
    animated_styles = ['Water', 'Lava', 'Fire', 'Smoke', 'Fog', 'Crystal', 'Wind', 'Portal']
    use_spatial_animation = style in animated_styles
    
    for y in range(0, height, block_size):
        for x in range(0, width, block_size):
            # For "None" style, create structured block patterns
            if style == "None":
                # Use grid-based pattern for structured blocks
                grid_x = x // block_size
                grid_y = y // block_size
                pattern_index = (grid_x + grid_y * 2) % len(gradient_palette)
                color = gradient_palette[pattern_index]
                
                # Add subtle random variation for natural look
                if random.random() < 0.2:  # 20% chance for variation
                    color = random.choice(gradient_palette)
            else:
                # For animated styles, use spatial noise to determine color selection
                if use_spatial_animation:
                    # Create spatial animation by using noise based on position and time
                    # frame_idx is actually animation_time (float) when called from animated texture creation
                    time_factor = float(frame_idx) * 0.15  # Increased for more noticeable movement
                    spatial_x = x / block_size + time_factor
                    spatial_y = y / block_size + time_factor * 0.7
                    
                    # For lava, simple bubbling animation like "Texture Type: None"
                    if style == "Lava":
                        # Simple bubbling - just shift the spatial coordinates slightly
                        time_factor = frame_idx * 0.2  # Gentle animation
                        
                        # Simple bubbling effect - shift coordinates based on time
                        bubble_x = spatial_x + time_factor * 0.1
                        bubble_y = spatial_y + time_factor * 0.05
                        
                        # Use simple noise for basic block pattern with slight movement
                        noise_value = vectorized_fractal_noise(bubble_x, bubble_y, octaves=2, persistence=0.5, seed=seed or 42)
                    elif style == "Portal":
                        # Portal-specific spatial animation with swirling effects
                        time_factor = frame_idx * 0.4
                        
                        # Create swirling portal effect
                        swirl_x = spatial_x + time_factor * 0.3
                        swirl_y = spatial_y + time_factor * 0.2
                        
                        # Use multiple noise layers for portal distortion
                        energy_noise = vectorized_fractal_noise(swirl_x, swirl_y, octaves=3, persistence=0.6, seed=seed or 42)
                        distortion_noise = vectorized_fractal_noise(spatial_x * 1.5 + time_factor * 0.2, spatial_y * 1.3 + time_factor * 0.1, octaves=2, persistence=0.4, seed=(seed or 42) + 100)
                        
                        # Combine for portal spatial effect
                        combined_noise = (energy_noise * 0.7 + distortion_noise * 0.3)
                        noise_value = combined_noise
                    else:
                        # Use standard noise for other animated styles
                        noise_value = vectorized_fractal_noise(spatial_x, spatial_y, octaves=3, persistence=0.5, seed=seed or 42)
                    
                    # Map noise to palette index with some variation
                    palette_index = int((noise_value + 1) * 0.5 * len(gradient_palette)) % len(gradient_palette)
                    color = gradient_palette[palette_index]
                else:
                    # Use random selection from the gradient palette for natural variation
                    color = random.choice(gradient_palette)
            
            r, g, b, a = color.red(), color.green(), color.blue(), int(color.alpha() * (opacity / 255))
            
            # Ensure we don't go out of bounds
            end_y = min(y + block_size, height)
            end_x = min(x + block_size, width)
            
            arr[y:end_y, x:end_x, 0] = r
            arr[y:end_y, x:end_x, 1] = g
            arr[y:end_y, x:end_x, 2] = b
            arr[y:end_y, x:end_x, 3] = a
    
    # Convert to QImage - ensure proper format
    qimg = QImage(arr.data, width, height, width * 4, QImage.Format_RGBA8888)
    # Make a deep copy so numpy buffer can be released
    return qimg.copy()

def apply_style_effects(palette, style, params, frame_idx):
    """Apply style effects to the palette based on the selected style."""
    if style == "Water":
        return apply_water_style(palette, params, frame_idx)
    elif style == "Lava":
        return apply_lava_style(palette, params, frame_idx)
    elif style == "Fire":
        return apply_fire_style(palette, params, frame_idx)
    elif style == "Smoke":
        return apply_smoke_style(palette, params, frame_idx)
    elif style == "Fog":
        return apply_fog_style(palette, params, frame_idx)
    elif style == "Crystal":
        return apply_crystal_style(palette, params, frame_idx)
    elif style == "Wind":
        return apply_wind_style(palette, params, frame_idx)
    elif style == "Portal":
        return apply_portal_style(palette, params, frame_idx)
    else:
        return palette

def apply_water_style(palette, params, frame_idx):
    """Apply water-like effects to the palette."""
    wave_intensity = params.get('water_wave', 5) / 10.0
    depth = params.get('water_depth', 5) / 10.0
    
    # Create more complex water movement
    time_factor = frame_idx * 0.4
    wave_offset = math.sin(time_factor) * wave_intensity
    ripple_offset = math.cos(time_factor * 1.7) * wave_intensity * 0.5
    
    new_palette = []
    for i, color in enumerate(palette):
        # Create multiple wave patterns
        wave1 = math.sin(i * 0.3 + wave_offset) * 0.2
        wave2 = math.sin(i * 0.7 + ripple_offset) * 0.15
        wave3 = math.cos(i * 0.5 + time_factor * 0.8) * 0.1
        
        # Combine waves for more natural water movement
        wave_factor = 1.0 + wave1 + wave2 + wave3
        
        # Add depth variation - deeper areas are darker and more blue
        depth_var = 1.0 - depth * 0.3 * math.sin(i * 0.4 + time_factor * 0.3)
        
        # Water color enhancement - boost blues, reduce reds
        r = int(color.red() * wave_factor * depth_var * 0.8)  # Reduce red
        g = int(color.green() * wave_factor * depth_var * 0.9)  # Slightly reduce green
        b = int(color.blue() * wave_factor * depth_var * 1.3)   # Enhance blue significantly
        a = color.alpha()
        
        # Ensure we don't make colors too dark
        r = min(255, max(0, r))
        g = min(255, max(0, g))
        b = min(255, max(0, b))
        
        new_palette.append(QColor(r, g, b, a))
    
    return new_palette

def apply_lava_style(palette, params, frame_idx):
    """Apply lava-like effects to the palette."""
    heat_intensity = params.get('lava_heat', 7) / 10.0
    bubbling = params.get('lava_bubble', 5) / 10.0
    
    # Create complex lava movement patterns
    time_factor = frame_idx * 0.6
    heat_wave = math.sin(time_factor) * heat_intensity
    bubble_wave = math.cos(time_factor * 2.3) * bubbling
    magma_flow = math.sin(time_factor * 0.8) * heat_intensity * 0.7
    
    new_palette = []
    for i, color in enumerate(palette):
        # Create bubbling effect with multiple frequencies
        bubble1 = math.sin(i * 0.4 + bubble_wave) * 0.3
        bubble2 = math.cos(i * 0.8 + time_factor * 1.5) * 0.2
        bubble3 = math.sin(i * 1.2 + magma_flow) * 0.25
        
        bubble_factor = 1.0 + bubble1 + bubble2 + bubble3
        
        # Heat glow effect - creates bright hot spots
        heat_glow = 1.0 + math.sin(i * 0.6 + heat_wave) * heat_intensity * 0.4
        
        # Lava color transformation - strong red/orange with yellow highlights
        r = int(color.red() * bubble_factor * heat_glow * 1.4)  # Boost red significantly
        g = int(color.green() * bubble_factor * heat_glow * 0.6)  # Reduce green for orange
        b = int(color.blue() * bubble_factor * heat_glow * 0.3)   # Minimal blue for red/orange
        a = color.alpha()
        
        # Add bright yellow highlights for hot spots
        if heat_glow > 1.2:
            r = min(255, r + 30)
            g = min(255, g + 20)
        
        # Ensure we don't make colors too dark
        r = min(255, max(0, r))
        g = min(255, max(0, g))
        b = min(255, max(0, b))
        
        new_palette.append(QColor(r, g, b, a))
    
    return new_palette

def apply_fire_style(palette, params, frame_idx):
    """Apply fire-like effects to the palette."""
    flame_intensity = params.get('fire_flame', 8) / 10.0
    flickering = params.get('fire_flicker', 6) / 10.0
    
    # Create realistic fire flickering
    time_factor = frame_idx * 1.2
    flicker_base = math.sin(time_factor) * flickering
    flame_wave = math.cos(time_factor * 0.7) * flame_intensity
    sparkle = math.sin(time_factor * 2.1) * flame_intensity * 0.5
    
    new_palette = []
    for i, color in enumerate(palette):
        # Create flickering effect with multiple frequencies
        flicker1 = math.sin(i * 0.5 + flicker_base) * 0.4
        flicker2 = math.cos(i * 1.1 + time_factor * 1.8) * 0.3
        flicker3 = math.sin(i * 0.8 + sparkle) * 0.25
        
        flicker_factor = 1.0 + flicker1 + flicker2 + flicker3
        
        # Flame intensity variation
        flame_var = 1.0 + math.sin(i * 0.7 + flame_wave) * flame_intensity * 0.3
        
        # Fire color transformation - red base with yellow/white tips
        r = int(color.red() * flicker_factor * flame_var * 1.5)  # Strong red base
        g = int(color.green() * flicker_factor * flame_var * 0.8)  # Moderate green for yellow
        b = int(color.blue() * flicker_factor * flame_var * 0.4)   # Low blue for red/orange
        a = color.alpha()
        
        # Add bright yellow/white tips for flame effect
        if flame_var > 1.1:
            r = min(255, r + 40)
            g = min(255, g + 30)
            b = min(255, b + 15)
        
        # Random sparkle effect
        if random.random() < 0.1:  # 10% chance for sparkle
            r = min(255, r + 50)
            g = min(255, g + 50)
            b = min(255, b + 30)
        
        # Ensure we don't make colors too dark
        r = min(255, max(0, r))
        g = min(255, max(0, g))
        b = min(255, max(0, b))
        
        new_palette.append(QColor(r, g, b, a))
    
    return new_palette

def apply_smoke_style(palette, params, frame_idx):
    """Apply smoke-like effects to the palette."""
    density = params.get('smoke_density', 5) / 10.0
    drift = params.get('smoke_drift', 4) / 10.0
    
    # Create smoke drift and density patterns
    time_factor = frame_idx * 0.3
    drift_wave = math.sin(time_factor) * drift
    density_wave = math.cos(time_factor * 1.4) * density
    swirl = math.sin(time_factor * 0.6) * drift * 0.7
    
    new_palette = []
    for i, color in enumerate(palette):
        # Create smoke drift effect
        drift1 = math.sin(i * 0.4 + drift_wave) * 0.3
        drift2 = math.cos(i * 0.9 + swirl) * 0.2
        drift3 = math.sin(i * 1.3 + time_factor * 0.8) * 0.25
        
        drift_factor = 1.0 + drift1 + drift2 + drift3
        
        # Density variation
        density_var = 1.0 + math.sin(i * 0.6 + density_wave) * density * 0.4
        
        # Convert to realistic smoke colors - various grays with slight tinting
        gray_base = (color.red() + color.green() + color.blue()) / 3
        
        # Add slight color variation for more realistic smoke
        r_offset = math.sin(i * 0.5 + time_factor) * 20
        g_offset = math.cos(i * 0.7 + time_factor * 0.8) * 15
        b_offset = math.sin(i * 0.9 + time_factor * 1.2) * 25
        
        r = int(gray_base * drift_factor * density_var + r_offset)
        g = int(gray_base * drift_factor * density_var + g_offset)
        b = int(gray_base * drift_factor * density_var + b_offset)
        a = int(color.alpha() * density_var * 0.8)  # Smoke is semi-transparent
        
        # Ensure we don't make colors too dark
        r = min(255, max(0, r))
        g = min(255, max(0, g))
        b = min(255, max(0, b))
        a = min(255, max(0, a))
        
        new_palette.append(QColor(r, g, b, a))
    
    return new_palette

def apply_fog_style(palette, params, frame_idx):
    """Apply fog-like effects to the palette."""
    thickness = params.get('fog_thickness', 6) / 10.0
    movement = params.get('fog_movement', 3) / 10.0
    
    # Create fog movement patterns
    time_factor = frame_idx * 0.2
    fog_wave = math.sin(time_factor) * movement
    thickness_wave = math.cos(time_factor * 1.6) * thickness
    mist = math.sin(time_factor * 0.9) * movement * 0.6
    
    new_palette = []
    for i, color in enumerate(palette):
        # Create fog thickness variation
        thickness1 = math.sin(i * 0.3 + thickness_wave) * 0.4
        thickness2 = math.cos(i * 0.8 + mist) * 0.3
        thickness3 = math.sin(i * 1.2 + time_factor * 0.7) * 0.25
        
        thickness_factor = 1.0 + thickness1 + thickness2 + thickness3
        
        # Movement effect
        movement_var = 1.0 + math.sin(i * 0.6 + fog_wave) * movement * 0.3
        
        # Convert to fog colors - whitish with slight blue tint
        r = int(color.red() * thickness_factor * movement_var * 1.4)  # Boost red for white
        g = int(color.green() * thickness_factor * movement_var * 1.4)  # Boost green for white
        b = int(color.blue() * thickness_factor * movement_var * 1.5)   # Boost blue slightly more
        
        # Add slight blue tint for atmospheric fog
        b = min(255, b + 20)
        
        # Reduce alpha for fog transparency
        a = int(color.alpha() * thickness_factor * 0.7)
        
        # Ensure we don't make colors too dark
        r = min(255, max(0, r))
        g = min(255, max(0, g))
        b = min(255, max(0, b))
        a = min(255, max(0, a))
        
        new_palette.append(QColor(r, g, b, a))
    
    return new_palette

def apply_crystal_style(palette, params, frame_idx):
    """Apply crystal-like effects to the palette."""
    sparkle = params.get('crystal_sparkle', 7) / 10.0
    refraction = params.get('crystal_refraction', 5) / 10.0
    
    # Create crystal sparkle and refraction patterns
    time_factor = frame_idx * 0.8
    sparkle_wave = math.sin(time_factor) * sparkle
    refraction_wave = math.cos(time_factor * 1.3) * refraction
    prism = math.sin(time_factor * 0.5) * sparkle * 0.8
    
    new_palette = []
    for i, color in enumerate(palette):
        # Create sparkle effect with multiple frequencies
        sparkle1 = math.sin(i * 0.4 + sparkle_wave) * 0.5
        sparkle2 = math.cos(i * 1.0 + prism) * 0.4
        sparkle3 = math.sin(i * 1.6 + time_factor * 1.1) * 0.3
        
        sparkle_factor = 1.0 + sparkle1 + sparkle2 + sparkle3
        
        # Refraction effect
        refraction_var = 1.0 + math.sin(i * 0.7 + refraction_wave) * refraction * 0.4
        
        # Crystal color enhancement - bright and prismatic
        r = int(color.red() * sparkle_factor * refraction_var * 1.3)
        g = int(color.green() * sparkle_factor * refraction_var * 1.3)
        b = int(color.blue() * sparkle_factor * refraction_var * 1.4)  # Slightly more blue
        
        # Add rainbow refraction effect
        rainbow_offset = math.sin(i * 0.5 + time_factor * 0.6) * 30
        r = min(255, r + rainbow_offset)
        g = min(255, g + rainbow_offset * 0.8)
        b = min(255, b + rainbow_offset * 1.2)
        
        # Reduce alpha for crystal transparency
        a = int(color.alpha() * 0.9)
        
        # Ensure we don't make colors too dark
        r = min(255, max(0, r))
        g = min(255, max(0, g))
        b = min(255, max(0, b))
        a = min(255, max(0, a))
        
        new_palette.append(QColor(r, g, b, a))
    
    return new_palette

def apply_wind_style(palette, params, frame_idx):
    """Apply wind-like effects to the palette."""
    strength = params.get('wind_strength', 5) / 10.0
    direction = params.get('wind_direction', 0) / 360.0
    
    # Create wind movement patterns
    time_factor = frame_idx * 0.5
    wind_wave = math.sin(time_factor) * strength
    gust = math.cos(time_factor * 2.1) * strength * 0.7
    breeze = math.sin(time_factor * 0.8) * strength * 0.5
    
    # Convert direction to radians
    direction_rad = direction * 2 * math.pi
    
    new_palette = []
    for i, color in enumerate(palette):
        # Create wind strength variation
        wind1 = math.sin(i * 0.3 + wind_wave + direction_rad) * 0.4
        wind2 = math.cos(i * 0.8 + gust) * 0.3
        wind3 = math.sin(i * 1.2 + breeze) * 0.25
        
        wind_factor = 1.0 + wind1 + wind2 + wind3
        
        # Directional effect
        direction_var = 1.0 + math.sin(i * 0.6 + direction_rad) * strength * 0.3
        
        # Wind color effect - slight desaturation and movement
        r = int(color.red() * wind_factor * direction_var * 0.95)  # Slight desaturation
        g = int(color.green() * wind_factor * direction_var * 0.95)
        b = int(color.blue() * wind_factor * direction_var * 0.95)
        a = color.alpha()
        
        # Add slight blur effect for wind
        if wind_factor > 1.2:
            r = min(255, r + 10)
            g = min(255, g + 10)
            b = min(255, b + 10)
        
        # Ensure we don't make colors too dark
        r = min(255, max(0, r))
        g = min(255, max(0, g))
        b = min(255, max(0, b))
        
        new_palette.append(QColor(r, g, b, a))
    
    return new_palette 

def apply_portal_style(palette, params, frame_idx):
    """Apply portal-like effects to the palette."""
    energy_intensity = params.get('portal_energy', 7) / 10.0
    distortion = params.get('portal_distortion', 5) / 10.0
    
    # Create portal energy and distortion patterns
    time_factor = frame_idx * 0.8
    energy_wave = math.sin(time_factor) * energy_intensity
    distortion_wave = math.cos(time_factor * 1.5) * distortion
    vortex = math.sin(time_factor * 0.6) * energy_intensity * 0.8
    
    new_palette = []
    for i, color in enumerate(palette):
        # Create energy pulsing effect
        energy1 = math.sin(i * 0.4 + energy_wave) * 0.5
        energy2 = math.cos(i * 1.0 + vortex) * 0.4
        energy3 = math.sin(i * 1.6 + time_factor * 1.1) * 0.3
        
        energy_factor = 1.0 + energy1 + energy2 + energy3
        
        # Distortion effect
        distortion_var = 1.0 + math.sin(i * 0.7 + distortion_wave) * distortion * 0.4
        
        # Portal color transformation - vibrant and otherworldly
        r = int(color.red() * energy_factor * distortion_var * 1.3)
        g = int(color.green() * energy_factor * distortion_var * 1.3)
        b = int(color.blue() * energy_factor * distortion_var * 1.4)  # Slightly more blue
        
        # Add rainbow refraction effect for portal
        rainbow_offset = math.sin(i * 0.5 + time_factor * 0.6) * 40
        r = min(255, r + rainbow_offset)
        g = min(255, g + rainbow_offset * 0.8)
        b = min(255, b + rainbow_offset * 1.2)
        
        # Add energy glow effect
        if energy_factor > 1.2:
            r = min(255, r + 30)
            g = min(255, g + 30)
            b = min(255, b + 40)
        
        # Reduce alpha for portal transparency
        a = int(color.alpha() * 0.85)
        
        # Ensure we don't make colors too dark
        r = min(255, max(0, r))
        g = min(255, max(0, g))
        b = min(255, max(0, b))
        a = min(255, max(0, a))
        
        new_palette.append(QColor(r, g, b, a))
    
    return new_palette 