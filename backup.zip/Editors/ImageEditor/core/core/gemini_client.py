"""
Gemini API Client for Image Generation and Analysis
Handles API communication, caching, and response processing
"""

import os
import json
from typing import Dict, List, Optional, Any, Tuple
from PIL import Image
import numpy as np
import io
import base64

try:
    import google.generativeai as genai
    GEMINI_AVAILABLE = True
except ImportError:
    GEMINI_AVAILABLE = False
    print("Warning: google-generativeai not installed. AI features will be unavailable.")

from core.ai_helpers import (
    parse_json_response, get_cache_key, get_cached_response, 
    cache_response, validate_region, clamp_region
)


class GeminiClient:
    """Client for Gemini API operations."""
    
    def __init__(self, api_key: Optional[str] = None):
        """
        Initialize Gemini client.
        
        Args:
            api_key: Gemini API key (if None, tries to get from environment)
        """
        if not GEMINI_AVAILABLE:
            raise ImportError("google-generativeai package is required")
        
        self.api_key = api_key or os.getenv('GEMINI_API_KEY')
        if not self.api_key:
            raise ValueError("Gemini API key required. Set GEMINI_API_KEY environment variable or pass api_key parameter.")
        
        genai.configure(api_key=self.api_key)
        self.model = genai.GenerativeModel('gemini-2.0-flash-exp')
    
    def generate_base_image(self, prompt: str, theme: str, detail: int, 
                           size: Tuple[int, int], use_cache: bool = True) -> Optional[np.ndarray]:
        """
        Generate base sprite image using Gemini.
        
        Args:
            prompt: Image description
            theme: Style theme (e.g., "medieval fantasy", "cyberpunk")
            detail: Detail level (1-10)
            size: (width, height) in pixels
            use_cache: Whether to use cached responses
        
        Returns:
            RGBA numpy array or None if generation fails
        """
        cache_key = get_cache_key(prompt, theme, detail, "base_image", 0)
        
        # Check cache
        if use_cache:
            cached = get_cached_response(cache_key)
            if cached and 'image_data' in cached:
                # Reconstruct image from cached data
                return self._decode_image_from_cache(cached['image_data'])
        
        # Generate prompt
        full_prompt = f"""
        Create a pixel art sprite: {prompt}
        Style: {theme}
        Detail level: {detail}/10
        Size: {size[0]}x{size[1]} pixels
        Format: PNG with transparency
        Background: Transparent
        """
        
        try:
            response = self.model.generate_content(full_prompt)
            
            # Extract image from response
            image_data = self._extract_image_from_response(response)
            
            if image_data is None:
                return None
            
            # Convert to numpy array
            image_array = np.array(image_data)
            
            # Ensure RGBA
            if image_array.shape[2] == 3:
                alpha = np.ones((image_array.shape[0], image_array.shape[1], 1), dtype=np.uint8) * 255
                image_array = np.concatenate([image_array, alpha], axis=2)
            
            # Resize to requested size if needed
            if image_array.shape[:2] != (size[1], size[0]):
                from PIL import Image as PILImage
                pil_img = PILImage.fromarray(image_array, mode='RGBA')
                pil_img = pil_img.resize(size, PILImage.Resampling.LANCZOS)
                image_array = np.array(pil_img)
            
            # Cache result
            if use_cache:
                cache_data = {
                    'prompt': prompt,
                    'theme': theme,
                    'detail': detail,
                    'size': size,
                    'image_data': self._encode_image_for_cache(image_array)
                }
                cache_response(cache_key, cache_data)
            
            return image_array
            
        except Exception as e:
            print(f"Error generating base image: {e}")
            return None
    
    def analyze_frame_changes(self, base_image: np.ndarray, animation_type: str, 
                             frame_count: int, use_cache: bool = True) -> Optional[Dict[str, Any]]:
        """
        Analyze animation and generate frame change instructions.
        
        Args:
            base_image: Base sprite image (RGBA numpy array)
            animation_type: Type of animation (e.g., "walk_cycle", "jump")
            frame_count: Number of frames to generate
            use_cache: Whether to use cached responses
        
        Returns:
            Dictionary with frame change instructions
        """
        # Create cache key from image hash + animation params
        image_hash = hash(base_image.tobytes())
        cache_key = get_cache_key(f"img_{image_hash}", "", 0, animation_type, frame_count)
        
        # Check cache
        if use_cache:
            cached = get_cached_response(cache_key)
            if cached:
                return cached.get('changes', None)
        
        # Convert image to PIL for Gemini
        pil_image = Image.fromarray(base_image, mode='RGBA')
        
        # Create analysis prompt
        prompt = f"""
        Analyze this pixel art sprite and create a {animation_type} animation with {frame_count} frames.
        
        For each frame, describe ONLY what changes from the base image.
        Return JSON format:
        {{
            "frames": [
                {{
                    "frame": 0,
                    "changes": [
                        {{
                            "type": "move_region",
                            "description": "Move left leg forward",
                            "source": {{"x": 20, "y": 45, "w": 8, "h": 12}},
                            "target": {{"x": 18, "y": 43, "w": 8, "h": 12}}
                        }},
                        {{
                            "type": "modify_pixels",
                            "description": "Rotate right arm backward",
                            "region": {{"x": 40, "y": 25, "w": 10, "h": 15}},
                            "operation": "rotate",
                            "params": {{"angle": -15}}
                        }}
                    ]
                }}
            ]
        }}
        
        Important:
        - Use pixel coordinates (0-indexed)
        - Only describe visible changes
        - Keep changes minimal and realistic
        - Ensure smooth motion between frames
        """
        
        try:
            response = self.model.generate_content([pil_image, prompt])
            
            # Parse JSON response
            response_text = response.text
            changes_data = parse_json_response(response_text)
            
            # Validate and clamp all regions
            changes_data = self._validate_changes(changes_data, base_image.shape)
            
            # Cache result
            if use_cache:
                cache_data = {
                    'animation_type': animation_type,
                    'frame_count': frame_count,
                    'changes': changes_data
                }
                cache_response(cache_key, cache_data)
            
            return changes_data
            
        except Exception as e:
            print(f"Error analyzing frame changes: {e}")
            return None
    
    def refine_animation(self, base_image: np.ndarray, changes_data: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """
        Two-pass refinement: Verify and improve animation smoothness.
        
        Args:
            base_image: Base sprite image
            changes_data: Initial change instructions
        
        Returns:
            Refined change instructions
        """
        pil_image = Image.fromarray(base_image, mode='RGBA')
        
        prompt = f"""
        Review this animation JSON and verify that limb motion and symmetry are correct.
        Adjust coordinates to match realistic animation motion for smooth cycles.
        
        Current changes:
        {json.dumps(changes_data, indent=2)}
        
        Return improved JSON with:
        - Smoother motion transitions
        - Corrected coordinate errors
        - Better frame continuity
        - Realistic physics (e.g., walking cycles)
        
        Keep the same JSON structure.
        """
        
        try:
            response = self.model.generate_content([pil_image, prompt])
            refined_data = parse_json_response(response.text)
            return self._validate_changes(refined_data, base_image.shape)
        except Exception as e:
            print(f"Error refining animation: {e}")
            return changes_data  # Return original if refinement fails
    
    def detect_anchors(self, base_image: np.ndarray) -> Optional[Dict[str, Dict[str, int]]]:
        """
        Detect anchor points (bones) in sprite for rigging.
        
        Args:
            base_image: Base sprite image
        
        Returns:
            Dictionary of anchor points: {"head": {"x": 30, "y": 10}, ...}
        """
        pil_image = Image.fromarray(base_image, mode='RGBA')
        
        prompt = """
        Analyze this sprite and identify key anchor points (body parts) for animation.
        Return JSON format:
        {
            "anchors": {
                "head": {"x": 30, "y": 10},
                "torso": {"x": 30, "y": 25},
                "left_arm": {"x": 22, "y": 25},
                "right_arm": {"x": 38, "y": 25},
                "left_leg": {"x": 26, "y": 45},
                "right_leg": {"x": 34, "y": 45}
            }
        }
        """
        
        try:
            response = self.model.generate_content([pil_image, prompt])
            data = parse_json_response(response.text)
            return data.get('anchors', {})
        except Exception as e:
            print(f"Error detecting anchors: {e}")
            return None
    
    def _extract_image_from_response(self, response) -> Optional[Image.Image]:
        """Extract image from Gemini response."""
        # Gemini may return images in different formats
        if hasattr(response, 'candidates') and response.candidates:
            for candidate in response.candidates:
                if hasattr(candidate, 'content') and candidate.content:
                    for part in candidate.content.parts:
                        if hasattr(part, 'inline_data'):
                            # Inline image data
                            image_data = part.inline_data.data
                            return Image.open(io.BytesIO(base64.b64decode(image_data)))
                        elif hasattr(part, 'text') and 'data:image' in part.text:
                            # Base64 encoded image in text
                            # Extract base64 data
                            import re
                            match = re.search(r'data:image/[^;]+;base64,([A-Za-z0-9+/=]+)', part.text)
                            if match:
                                image_data = base64.b64decode(match.group(1))
                                return Image.open(io.BytesIO(image_data))
        
        return None
    
    def _encode_image_for_cache(self, image_array: np.ndarray) -> str:
        """Encode image array to base64 for caching."""
        pil_image = Image.fromarray(image_array, mode='RGBA')
        buffer = io.BytesIO()
        pil_image.save(buffer, format='PNG')
        return base64.b64encode(buffer.getvalue()).decode('utf-8')
    
    def _decode_image_from_cache(self, image_data: str) -> np.ndarray:
        """Decode base64 image data from cache."""
        image_bytes = base64.b64decode(image_data)
        pil_image = Image.open(io.BytesIO(image_bytes))
        return np.array(pil_image.convert('RGBA'))
    
    def _validate_changes(self, changes_data: Dict[str, Any], image_shape: Tuple[int, ...]) -> Dict[str, Any]:
        """Validate and clamp all regions in change instructions."""
        if 'frames' not in changes_data:
            return changes_data
        
        validated_frames = []
        for frame_data in changes_data['frames']:
            validated_changes = []
            for change in frame_data.get('changes', []):
                # Validate regions
                if 'source' in change:
                    source = validate_region(change['source'], image_shape)
                    if source:
                        change['source'] = {'x': source[0], 'y': source[1], 'w': source[2], 'h': source[3]}
                    else:
                        continue  # Skip invalid change
                
                if 'target' in change:
                    target = validate_region(change['target'], image_shape)
                    if target:
                        change['target'] = {'x': target[0], 'y': target[1], 'w': target[2], 'h': target[3]}
                    else:
                        continue
                
                if 'region' in change:
                    region = validate_region(change['region'], image_shape)
                    if region:
                        change['region'] = {'x': region[0], 'y': region[1], 'w': region[2], 'h': region[3]}
                    else:
                        continue
                
                validated_changes.append(change)
            
            frame_data['changes'] = validated_changes
            validated_frames.append(frame_data)
        
        changes_data['frames'] = validated_frames
        return changes_data

