THEMES = {
    "default": {
        "background": "#282c34",
        "panel": "#313640",
        "border": "#444950",
        "accent": "#61afef",
        "text": "#e5e5e5",
        "canvas_border": "#3a3f4b",
        "canvas_bg1": "#22252a",
        "canvas_bg2": "#2c313a",
        "canvas_outer_bg": "#23272e",
    },
    "light": {
        "background": "#f5f5f5",
        "panel": "#e0e0e0",
        "border": "#b0b0b0",
        "accent": "#007acc",
        "text": "#222222",
        "canvas_border": "#b0b0b0",
        "canvas_bg1": "#eaeaea",
        "canvas_bg2": "#d0d0d0",
        "canvas_outer_bg": "#e0e0e0",
    },
    "Legacy": {
        "background": "#23272e",
        "panel": "#2d323c",
        "border": "#b0b6c2",
        "accent": "#00bfff",
        "text": "#e0e0e0",
        "canvas_border": "#b0b6c2",
        "canvas_bg1": "#23272e",
        "canvas_bg2": "#2d323c",
        "canvas_outer_bg": "#23272e",
    },
}

def get_theme(name):
    return THEMES.get(name, THEMES["default"]) 