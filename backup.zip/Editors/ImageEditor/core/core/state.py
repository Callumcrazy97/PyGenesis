from layers.manager import LayerManager
from core.history import HistoryManager
from core.atlas_manager import AtlasManager
from core.selection_manager import SelectionManager
from PySide6.QtCore import QRect

class EditorState:
    def __init__(self, width=256, height=256):
        self.width = width
        self.height = height
        self.layer_manager = LayerManager(self.width, self.height, self)
        self.layer_manager.ensure_minimums()
        self.atlas_manager = AtlasManager(self)
        self.selection_manager = SelectionManager()
        self.current_radius = 8
        self.current_left_color = '#000000'
        self.current_right_color = '#ffffff'
        self.current_tool = 'brush'
        self.shape_filled = True
        self.grid_visible = False
        self.grid_size = 16
        self.grid_color = '#888888'
        self.grid_rotation = 0
        self.grid_snap = False
        self.global_grid = False  # If True, use global grid settings for all layers
        self.history = HistoryManager(self)
        self.clipboard_frame = None  # For single frame clipboard
        self.clipboard_frames = None  # For multi-frame clipboard
        self.clipboard_image = None  # For selection clipboard
        self.clipboard_mask = None  # For selection mask
        self.clipboard_bounds = None  # For selection bounds
        
        # Dirty rectangle tracking for partial updates
        self.dirty_rectangles = []  # List of QRect objects in image coordinates
        self.full_redraw_needed = False  # Flag for full redraw (e.g., after resize)

    def set_size(self, width, height):
        self.push_undo()
        self.width = width
        self.height = height
        self.layer_manager = LayerManager(self.width, self.height, self)
        self.layer_manager.ensure_minimums()
        self.atlas_manager.set_canvas_size(width, height)

    def set_radius(self, value):
        # Don't push undo for UI parameter changes (only for actual edits)
        self.current_radius = value

    def set_left_color(self, color):
        # Don't push undo for UI parameter changes (only for actual edits)
        self.current_left_color = color

    def set_right_color(self, color):
        # Don't push undo for UI parameter changes (only for actual edits)
        self.current_right_color = color

    def set_tool(self, tool):
        # Don't push undo for tool changes (only push undo for actual edits)
        old_tool = self.current_tool
        self.current_tool = tool
        # Clear selection when switching to non-selection tools
        selection_tools = ['region', 'magic_wand', 'spray', 'lasso']
        if tool not in selection_tools and self.selection_manager.has_selection():
            self.selection_manager.clear_selection()
            # Store reference to canvas for update (set by MainWindow)
            if hasattr(self, '_canvas_ref') and self._canvas_ref:
                self._canvas_ref.selecting = False
                self._canvas_ref.region_start = None
                self._canvas_ref.region_current = None
                self._canvas_ref.brush_selecting = False
                self._canvas_ref.update()

    def set_grid_visible(self, visible):
        # Don't push undo for UI parameter changes (only for actual edits)
        self.grid_visible = visible

    def set_grid_size(self, size):
        # Don't push undo for UI parameter changes (only for actual edits)
        self.grid_size = size

    def set_grid_color(self, color):
        # Don't push undo for UI parameter changes (only for actual edits)
        self.grid_color = color

    def set_grid_rotation(self, rotation):
        # Don't push undo for UI parameter changes (only for actual edits)
        self.grid_rotation = rotation

    def set_grid_snap(self, snap):
        # Don't push undo for UI parameter changes (only for actual edits)
        self.grid_snap = snap

    def undo(self):
        layer = self.layer_manager.get_current_layer()
        frame_idx = self.layer_manager.current_frame
        history = layer.get_history_for_frame(frame_idx)
        if history:
            history.undo()

    def redo(self):
        layer = self.layer_manager.get_current_layer()
        frame_idx = self.layer_manager.current_frame
        history = layer.get_history_for_frame(frame_idx)
        if history:
            history.redo()

    def add_layer(self, name=None):
        self.push_undo()
        self.layer_manager.add_layer(name)

    def add_frame(self):
        self.push_undo()
        self.layer_manager.add_frame()

    def push_undo(self):
        layer = self.layer_manager.get_current_layer()
        frame_idx = self.layer_manager.current_frame
        history = layer.get_history_for_frame(frame_idx)
        if history:
            history.push_undo()
    
    def mark_dirty_region(self, x: int, y: int, width: int, height: int):
        """
        Mark a region as dirty (needs update).
        Coordinates are in image space.
        
        Args:
            x, y: Top-left corner in image coordinates
            width, height: Size of dirty region in image coordinates
        """
        # Clamp to image bounds
        x = max(0, min(self.width - 1, x))
        y = max(0, min(self.height - 1, y))
        width = max(1, min(width, self.width - x))
        height = max(1, min(height, self.height - y))
        
        rect = QRect(x, y, width, height)
        self.dirty_rectangles.append(rect)
        
        # Limit the number of dirty rectangles to prevent memory issues
        # If we have too many, merge them or force full redraw
        if len(self.dirty_rectangles) > 100:
            self.full_redraw_needed = True
            self.dirty_rectangles.clear()
    
    def mark_dirty_point(self, x: int, y: int, radius: int = 0):
        """
        Mark a point (and surrounding area) as dirty.
        
        Args:
            x, y: Center point in image coordinates
            radius: Radius of dirty area (defaults to current brush radius)
        """
        if radius == 0:
            radius = self.current_radius
        
        # Add padding to ensure the full brush area is covered
        padding = radius + 2
        self.mark_dirty_region(
            x - padding, y - padding,
            padding * 2 + 1, padding * 2 + 1
        )
    
    def merge_dirty_rectangles(self):
        """
        Merge overlapping and adjacent dirty rectangles for efficiency.
        Returns True if rectangles were merged, False otherwise.
        """
        if len(self.dirty_rectangles) <= 1:
            return False
        
        merged = True
        max_iterations = 10  # Prevent infinite loops
        
        while merged and max_iterations > 0:
            merged = False
            max_iterations -= 1
            
            # Try to merge rectangles
            i = 0
            while i < len(self.dirty_rectangles):
                rect1 = self.dirty_rectangles[i]
                
                j = i + 1
                while j < len(self.dirty_rectangles):
                    rect2 = self.dirty_rectangles[j]
                    
                    # Check if rectangles overlap or are adjacent
                    if rect1.intersects(rect2) or self._rectangles_adjacent(rect1, rect2):
                        # Merge rectangles
                        merged_rect = rect1.united(rect2)
                        self.dirty_rectangles[i] = merged_rect
                        self.dirty_rectangles.pop(j)
                        merged = True
                        break
                    
                    j += 1
                
                if merged:
                    break
                
                i += 1
        
        return merged or max_iterations <= 9
    
    def _rectangles_adjacent(self, rect1: QRect, rect2: QRect, threshold: int = 2) -> bool:
        """
        Check if two rectangles are adjacent (close enough to merge).
        Threshold is in pixels.
        """
        # Expand both rectangles by threshold
        expanded1 = rect1.adjusted(-threshold, -threshold, threshold, threshold)
        return expanded1.intersects(rect2)
    
    def clear_dirty_rectangles(self):
        """Clear all dirty rectangles (called after render)"""
        self.dirty_rectangles.clear()
        self.full_redraw_needed = False
    
    def get_dirty_rectangles(self) -> list:
        """
        Get list of dirty rectangles, merging overlapping ones first.
        Returns list of QRect objects in image coordinates.
        """
        if self.full_redraw_needed:
            return [QRect(0, 0, self.width, self.height)]
        
        # Merge rectangles before returning
        self.merge_dirty_rectangles()
        return self.dirty_rectangles.copy()
    
    def has_dirty_regions(self) -> bool:
        """Check if there are any dirty regions"""
        return len(self.dirty_rectangles) > 0 or self.full_redraw_needed

state = EditorState()
