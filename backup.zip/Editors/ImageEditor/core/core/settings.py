import json
import os
import logging

SETTINGS_FILE = os.path.expanduser("~/.pixel_editor_settings.json")

class Settings:
    def __init__(self):
        # Default settings
        self.theme = "default"
        self.custom_colors = {}  # Dict of role: hex color
        self.grid_size = 16
        self.last_open_folder = ""
        self.gemini_api_key = ""  # Stored API key for AI features
        self.use_gpu_canvas = False  # Use GPU-accelerated Canvas_2D instead of QPainter-based CheckerboardCanvas
        self.pixel_perfect_filtering = True  # Pixel-perfect (nearest neighbor) vs smooth (linear) filtering for GPU canvas
        self.load()

    def load(self):
        if os.path.exists(SETTINGS_FILE):
            try:
                with open(SETTINGS_FILE, "r") as f:
                    data = json.load(f)
                self.__dict__.update(data)
            except (json.JSONDecodeError, IOError) as e:
                logging.warning(f"Failed to load settings from {SETTINGS_FILE}: {e}")
                # Keep default settings if loading fails

    def save(self):
        try:
            # Ensure directory exists
            os.makedirs(os.path.dirname(SETTINGS_FILE), exist_ok=True)
            with open(SETTINGS_FILE, "w") as f:
                json.dump(self.__dict__, f, indent=2)
        except (IOError, OSError) as e:
            logging.error(f"Failed to save settings to {SETTINGS_FILE}: {e}")

settings = Settings() 