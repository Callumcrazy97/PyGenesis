"""
GUI Test App for AI-driven image generation using editor tools.
Dialog-based interface with preview and animation support.
"""

import json
import os
import sys
import subprocess

# Check and install dependencies before importing
def check_and_install_dependencies():
    """Check for required packages and install them if missing."""
    required_packages = [
        ('numpy', 'numpy'),
        ('PIL', 'Pillow'),
        ('PySide6', 'PySide6'),
        ('anthropic', 'anthropic'),  # For Claude API (Cursor AI)
    ]
    
    missing_packages = []
    
    for import_name, package_name in required_packages:
        try:
            __import__(import_name)
        except ImportError:
            if package_name not in [p[1] for p in missing_packages]:
                missing_packages.append((import_name, package_name))
    
    if missing_packages:
        print(f"[INFO] Checking dependencies...")
        packages_to_install = list(set(pkg[1] for pkg in missing_packages))
        print(f"[INFO] Missing packages: {', '.join(packages_to_install)}")
        
        for import_name, package_name in missing_packages:
            print(f"[INFO] Installing {package_name}...")
            try:
                result = subprocess.run(
                    [sys.executable, "-m", "pip", "install", package_name, "--quiet", "--disable-pip-version-check"],
                    capture_output=True,
                    text=True,
                    timeout=120
                )
                if result.returncode == 0:
                    print(f"[OK] Successfully installed {package_name}")
                else:
                    print(f"[WARNING] pip install returned code {result.returncode}")
            except Exception as e:
                print(f"[ERROR] Failed to install {package_name}: {e}")
                sys.exit(1)
        
        import importlib
        if 'importlib' in sys.modules:
            importlib.reload(importlib)
        
        print("[INFO] Verifying installations...")
        for import_name, package_name in required_packages:
            try:
                if import_name in sys.modules:
                    del sys.modules[import_name]
                __import__(import_name)
                print(f"[OK] {package_name} is available")
            except ImportError:
                print(f"[ERROR] {package_name} is still not available")
                sys.exit(1)
    
    if not missing_packages:
        print("[OK] All required packages are available")

check_and_install_dependencies()

# Now safe to import
import numpy as np
from PIL import Image
import random

from PySide6.QtWidgets import (
    QApplication, QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QTextEdit, QGroupBox, QLineEdit, QSplitter, QFrame, QCheckBox, QFileDialog, QMessageBox
)
from PySide6.QtCore import Qt, QTimer, Signal
from PySide6.QtGui import QColor, QPainter, QPixmap, QImage

# Import the core functions from ai_test_scenario
# Get the directory containing ai_test_scenario.py
scenario_dir = os.path.dirname(__file__)
if scenario_dir not in sys.path:
    sys.path.insert(0, scenario_dir)

# Import from ai_test_scenario module
try:
    from ai_test_scenario import (
        load_tool_knowledge, create_system_prompt, generate_instructions_with_ai,
        execute_instructions
    )
except ImportError:
    # File doesn't exist, define functions inline
    pass

# Define functions if not imported
try:
    load_tool_knowledge
except NameError:
    # Core functions for AI instruction generation and execution
    def load_tool_knowledge():
        """Load the tool knowledge file."""
        tool_knowledge_path = os.path.join(os.path.dirname(__file__), "ai_tool_knowledge.json")
        with open(tool_knowledge_path, 'r', encoding='utf-8') as f:
            return json.load(f)

    def create_system_prompt(tool_knowledge):
        """Create a concise system prompt that references tool knowledge."""
        prompt = f"""You are an AI assistant for the {tool_knowledge['editor_name']}.

Your task is to analyze user requests and determine if the editor can accomplish them using available tools and effects.

AVAILABLE CAPABILITIES:
- Effects: {', '.join(tool_knowledge['capabilities'].keys())}
- Basic Operations: {', '.join(tool_knowledge['basic_operations'].keys())}

When the editor CAN handle the request:
- Respond with JSON: {{"type": "instructions", "actions": [...]}}
- Each action can be {{"operation": "name", "parameters": {{...}}}} OR {{"effect": "name", "parameters": {{...}}}}
- Chain multiple operations/effects to accomplish complex tasks

When the editor CANNOT handle the request:
- Respond with JSON: {{"type": "generate", "description": "..."}}
- Then generate the image(s) directly

COORDINATE SYSTEM: Origin (0,0) at top-left. x increases right, y increases down.
COLOR FORMAT: Use hex format #RRGGBB (e.g., #000000 for black, #FFFFFF for white, #FF0000 for red)

IMPORTANT: Keep responses concise. Reference tool names only, not full definitions."""
        return prompt

    def generate_instructions_with_ai(user_prompt, api_key=None, provider="claude", tool_knowledge=None):
        """Generate instructions using real AI (Claude/Anthropic - Cursor AI)."""
        if tool_knowledge is None:
            tool_knowledge = load_tool_knowledge()
        
        system_prompt = create_system_prompt(tool_knowledge)
        
        # Always use real AI - no fallbacks
        if not api_key:
            # Try environment variable
            api_key = os.getenv('ANTHROPIC_API_KEY') or os.getenv('CLAUDE_API_KEY')
        
        if not api_key:
            raise ValueError(
                "Anthropic API key required for Cursor AI.\n"
                "Set ANTHROPIC_API_KEY environment variable or provide API key in the dialog."
            )
        
        # Use Anthropic Claude API (what Cursor uses)
        try:
            import anthropic
        except ImportError:
            raise ImportError(
                "anthropic package required. Install with: pip install anthropic"
            )
        
        print("\n" + "="*70)
        print("CALLING CURSOR AI (CLAUDE/ANTHROPIC)")
        print("="*70)
        
        client = anthropic.Anthropic(api_key=api_key)
        
        # Create the full prompt
        full_prompt = f"""{system_prompt}

USER REQUEST: {user_prompt}

Analyze the request and determine if the editor can accomplish it.
If YES, return JSON instructions.
If NO, return {{"type": "generate", "description": "why editor can't do it"}}

Respond ONLY with valid JSON, no other text."""
        
        print(f"Sending prompt to Claude ({len(full_prompt)} characters)...")
        
        # Call Claude API
        try:
            message = client.messages.create(
                model="claude-3-5-sonnet-20241022",  # Latest Claude model
                max_tokens=4096,
                system=system_prompt,
                messages=[
                    {
                        "role": "user",
                        "content": f"""USER REQUEST: {user_prompt}

Analyze the request and determine if the editor can accomplish it.
If YES, return JSON instructions.
If NO, return {{"type": "generate", "description": "why editor can't do it"}}

Respond ONLY with valid JSON, no other text."""
                    }
                ]
            )
        except Exception as api_error:
            error_msg = str(api_error)
            if "credit balance" in error_msg.lower() or "billing" in error_msg.lower():
                raise ValueError(
                    "Anthropic API billing error: Your account needs credits.\n"
                    "Please visit https://console.anthropic.com/ to add credits.\n\n"
                    "Note: Cursor uses Claude (Anthropic) under the hood, but requires a paid API account."
                )
            elif "api key" in error_msg.lower() or "authentication" in error_msg.lower():
                raise ValueError(
                    "Anthropic API authentication error: Invalid API key.\n"
                    "Please check your API key at https://console.anthropic.com/"
                )
            else:
                raise ValueError(f"Anthropic API error: {error_msg}")
        
        response_text = message.content[0].text.strip()
        print(f"AI Response Length: {len(response_text)} characters")
        print(f"Response preview: {response_text[:200]}...")
        
        # Try to extract JSON from response
        import re
        json_match = re.search(r'\{[\s\S]*\}', response_text)
        if json_match:
            response_text = json_match.group(0)
        
        try:
            instructions = json.loads(response_text)
            print("[OK] Successfully parsed AI response")
            return instructions
        except json.JSONDecodeError as e:
            print(f"[ERROR] Failed to parse JSON: {e}")
            print(f"Response text: {response_text}")
            raise ValueError(f"AI returned invalid JSON. Response: {response_text[:500]}")

    def execute_instructions(instructions, canvas_width=512, canvas_height=512):
        """Execute instructions to create an image."""
        canvas = np.zeros((canvas_height, canvas_width, 4), dtype=np.uint8)
        current_color = "#000000"
        current_radius = 8
        
        def hex_to_rgba(hex_color):
            hex_color = hex_color.lstrip('#')
            return np.array([int(hex_color[0:2], 16), int(hex_color[2:4], 16), int(hex_color[4:6], 16), 255], dtype=np.uint8)
        
        def draw_circle(canvas, cx, cy, radius, color):
            h, w = canvas.shape[:2]
            for y in range(max(0, cy - radius), min(h, cy + radius + 1)):
                for x in range(max(0, cx - radius), min(w, cx + radius + 1)):
                    if (x - cx)**2 + (y - cy)**2 <= radius**2:
                        canvas[y, x] = color
        
        def draw_rectangle(canvas, x, y, width, height, color, filled=True):
            h, w = canvas.shape[:2]
            x1, y1 = max(0, int(x)), max(0, int(y))
            x2, y2 = min(w, int(x + width)), min(h, int(y + height))
            if filled:
                canvas[y1:y2, x1:x2] = color
        
        def draw_ellipse(canvas, x, y, width, height, color, filled=True):
            h, w = canvas.shape[:2]
            cx, cy = int(x + width // 2), int(y + height // 2)
            rx, ry = width // 2, height // 2
            x1, y1 = max(0, int(x)), max(0, int(y))
            x2, y2 = min(w, int(x + width)), min(h, int(y + height))
            for py in range(y1, y2):
                for px in range(x1, x2):
                    dx, dy = (px - cx) / rx if rx > 0 else 0, (py - cy) / ry if ry > 0 else 0
                    if dx*dx + dy*dy <= 1.0:
                        canvas[py, px] = color
        
        for action in instructions.get("actions", []):
            params = action.get("parameters", {})
            op = action.get("operation", "")
            
            if op == "fill_all":
                canvas[:, :] = hex_to_rgba(params.get("color", current_color))
            elif op == "set_foreground_color":
                current_color = params.get("color", current_color)
            elif op == "set_brush_radius":
                current_radius = params.get("radius", current_radius)
            elif op == "draw_with_brush":
                points = params.get("points", [])
                color = hex_to_rgba(params.get("color", current_color))
                for point in points:
                    draw_circle(canvas, point["x"], point["y"], params.get("radius", current_radius), color)
            elif op == "draw_rectangle":
                draw_rectangle(canvas, params.get("x", 0), params.get("y", 0), params.get("width", 0), params.get("height", 0), hex_to_rgba(params.get("color", current_color)), params.get("filled", True))
            elif op == "draw_ellipse":
                draw_ellipse(canvas, params.get("x", 0), params.get("y", 0), params.get("width", 0), params.get("height", 0), hex_to_rgba(params.get("color", current_color)), params.get("filled", True))
        
        return canvas


class CheckerboardPreviewWidget(QLabel):
    """Preview widget with checkerboard background."""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumSize(400, 300)
        self.setAlignment(Qt.AlignCenter)
        self.setText("Preview will appear here")
        self.setStyleSheet("border: 1px solid #888;")
        self.preview_pixmap = None
        
    def setPixmap(self, pixmap):
        """Override setPixmap to store the pixmap and trigger repaint."""
        self.preview_pixmap = pixmap
        self.update()
        
    def paintEvent(self, event):
        """Override paint event to draw checkerboard background and preview image."""
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        
        width = self.width()
        height = self.height()
        
        # Draw checkerboard pattern
        checker_size = 8
        color1 = QColor(40, 40, 40)
        color2 = QColor(60, 60, 60)
        
        for y in range(0, height, checker_size):
            for x in range(0, width, checker_size):
                if (x // checker_size + y // checker_size) % 2 == 0:
                    painter.fillRect(x, y, checker_size, checker_size, color1)
                else:
                    painter.fillRect(x, y, checker_size, checker_size, color2)
        
        # Draw the preview image if available
        if self.preview_pixmap is not None:
            pixmap_rect = self.preview_pixmap.rect()
            widget_rect = self.rect()
            
            scaled_pixmap = self.preview_pixmap.scaled(
                widget_rect.size(), 
                Qt.KeepAspectRatio, 
                Qt.SmoothTransformation
            )
            
            x = (widget_rect.width() - scaled_pixmap.width()) // 2
            y = (widget_rect.height() - scaled_pixmap.height()) // 2
            
            painter.drawPixmap(x, y, scaled_pixmap)
        else:
            painter.setPen(QColor(200, 200, 200))
            painter.drawText(self.rect(), Qt.AlignCenter, self.text())


class AITestDialog(QDialog):
    """Dialog for testing AI instruction generation with preview."""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("AI Instruction Test App")
        self.setMinimumSize(800, 600)
        
        # State
        self.tool_knowledge = None
        self.current_frames = []  # List of numpy arrays
        self.current_frame_index = 0
        self.is_playing = False
        self.playback_timer = QTimer(self)
        self.playback_timer.timeout.connect(self.on_playback_tick)
        
        self.setup_ui()
        self.load_tool_knowledge()
    
    def setup_ui(self):
        """Set up the UI."""
        layout = QVBoxLayout(self)
        
        # Prompt input section
        prompt_group = QGroupBox("Prompt")
        prompt_layout = QVBoxLayout()
        self.prompt_edit = QTextEdit()
        self.prompt_edit.setPlaceholderText(
            "Enter your prompt here...\n"
            "Example: 'Create a Black Night Sky With Stars Above A Grassy Hill'\n"
            "Or: 'Make A Starry Background above a grassy hill, copy the frame to save time, but animate a shooting star going overhead'"
        )
        self.prompt_edit.setMaximumHeight(100)
        prompt_layout.addWidget(self.prompt_edit)
        prompt_group.setLayout(prompt_layout)
        layout.addWidget(prompt_group)
        
        # AI Settings (Always uses Cursor AI - Claude/Anthropic)
        ai_group = QGroupBox("AI Settings (Cursor AI - Claude/Anthropic)")
        ai_layout = QVBoxLayout()
        
        ai_row2 = QHBoxLayout()
        ai_row2.addWidget(QLabel("Anthropic API Key:"))
        self.api_key_edit = QLineEdit()
        self.api_key_edit.setPlaceholderText("Enter Anthropic API key or leave empty to use ANTHROPIC_API_KEY env var")
        self.api_key_edit.setEchoMode(QLineEdit.Password)
        self.api_key_edit.textChanged.connect(self.on_api_key_changed)
        # Try to load from environment
        api_key_env = os.getenv('ANTHROPIC_API_KEY') or os.getenv('CLAUDE_API_KEY')
        if api_key_env:
            self.api_key_edit.setPlaceholderText(f"Using ANTHROPIC_API_KEY from environment ({len(api_key_env)} chars)")
            self.api_key_edit.setEnabled(False)
        ai_row2.addWidget(self.api_key_edit)
        ai_layout.addLayout(ai_row2)
        
        info_label = QLabel(
            "This test uses Claude (Anthropic) API, which powers Cursor AI.\n"
            "Get your API key at: https://console.anthropic.com/"
        )
        info_label.setWordWrap(True)
        info_label.setStyleSheet("color: #888; font-size: 9pt; padding: 5px;")
        ai_layout.addWidget(info_label)
        
        self.ai_status_label = QLabel("Status: Ready for Cursor AI (Claude)")
        self.ai_status_label.setStyleSheet("color: #4CAF50; font-weight: bold;")
        ai_layout.addWidget(self.ai_status_label)
        
        ai_group.setLayout(ai_layout)
        layout.addWidget(ai_group)
        
        # Generate button
        button_layout = QHBoxLayout()
        self.generate_btn = QPushButton("Generate Instructions & Execute")
        self.generate_btn.clicked.connect(self.on_generate)
        button_layout.addWidget(self.generate_btn)
        button_layout.addStretch()
        layout.addLayout(button_layout)
        
        # Splitter for preview and instructions
        splitter = QSplitter(Qt.Horizontal)
        
        # Left: Instructions display
        instructions_group = QGroupBox("Generated Instructions (JSON)")
        instructions_layout = QVBoxLayout()
        self.instructions_display = QTextEdit()
        self.instructions_display.setReadOnly(True)
        self.instructions_display.setStyleSheet("background-color: #2b2b2b; color: #ffffff; font-family: monospace;")
        instructions_layout.addWidget(self.instructions_display)
        instructions_group.setLayout(instructions_layout)
        splitter.addWidget(instructions_group)
        
        # Right: Preview section
        preview_group = QGroupBox("Preview")
        preview_layout = QVBoxLayout()
        
        self.preview_widget = CheckerboardPreviewWidget(self)
        preview_layout.addWidget(self.preview_widget)
        
        # Frame controls (hidden by default)
        self.frame_controls = QFrame()
        frame_layout = QHBoxLayout(self.frame_controls)
        frame_layout.setContentsMargins(5, 5, 5, 5)
        
        self.prev_frame_btn = QPushButton("◄ Prev")
        self.prev_frame_btn.clicked.connect(self.prev_frame)
        frame_layout.addWidget(self.prev_frame_btn)
        
        self.play_pause_btn = QPushButton("⏯ Play")
        self.play_pause_btn.clicked.connect(self.toggle_playback)
        frame_layout.addWidget(self.play_pause_btn)
        
        self.stop_btn = QPushButton("⏹ Stop")
        self.stop_btn.clicked.connect(self.stop_playback)
        frame_layout.addWidget(self.stop_btn)
        
        self.next_frame_btn = QPushButton("Next ►")
        self.next_frame_btn.clicked.connect(self.next_frame)
        frame_layout.addWidget(self.next_frame_btn)
        
        self.frame_counter_label = QLabel("Frame 0/0")
        self.frame_counter_label.setAlignment(Qt.AlignCenter)
        frame_layout.addWidget(self.frame_counter_label)
        
        self.frame_controls.hide()
        preview_layout.addWidget(self.frame_controls)
        
        preview_group.setLayout(preview_layout)
        splitter.addWidget(preview_group)
        
        splitter.setSizes([300, 500])  # Give more space to preview
        layout.addWidget(splitter)
        
        # Buttons
        button_box = QHBoxLayout()
        button_box.addStretch()
        
        self.save_btn = QPushButton("Save Image(s)")
        self.save_btn.clicked.connect(self.on_save)
        self.save_btn.setEnabled(False)
        button_box.addWidget(self.save_btn)
        
        close_btn = QPushButton("Close")
        close_btn.clicked.connect(self.accept)
        button_box.addWidget(close_btn)
        
        layout.addLayout(button_box)
    
    def load_tool_knowledge(self):
        """Load tool knowledge file."""
        try:
            self.tool_knowledge = load_tool_knowledge()
        except Exception as e:
            print(f"[ERROR] Failed to load tool knowledge: {e}")
    
    def on_api_key_changed(self, text):
        """Handle API key input change."""
        # Re-enable field if user is typing
        if text and self.api_key_edit.isEnabled() == False:
            self.api_key_edit.setEnabled(True)
            env_key = os.getenv('ANTHROPIC_API_KEY') or os.getenv('CLAUDE_API_KEY')
            if env_key:
                self.api_key_edit.setPlaceholderText("Enter Anthropic API key or leave empty to use ANTHROPIC_API_KEY env var")
        
        # Update status based on whether we have an API key
        api_key = text.strip() if text else (os.getenv('ANTHROPIC_API_KEY') or os.getenv('CLAUDE_API_KEY'))
        if api_key:
            self.ai_status_label.setText(f"Status: Ready for Cursor AI (API key set, {len(api_key)} chars)")
            self.ai_status_label.setStyleSheet("color: #4CAF50; font-weight: bold;")
        else:
            self.ai_status_label.setText("Status: API key required")
            self.ai_status_label.setStyleSheet("color: #FF9800; font-weight: bold;")
    
    def on_generate(self):
        """Generate instructions and execute them (always uses real Cursor AI)."""
        prompt = self.prompt_edit.toPlainText().strip()
        if not prompt:
            self.instructions_display.setText("Please enter a prompt first.")
            return
        
        # Get API key (required - always uses real Cursor AI)
        api_key = self.api_key_edit.text().strip()
        if not api_key:
            api_key = os.getenv('ANTHROPIC_API_KEY') or os.getenv('CLAUDE_API_KEY')
        
        if not api_key:
            error_msg = (
                "ERROR: Anthropic API key required for Cursor AI.\n\n"
                "Please enter an Anthropic API key or set ANTHROPIC_API_KEY environment variable.\n\n"
                "Get your API key at: https://console.anthropic.com/"
            )
            self.instructions_display.setText(error_msg)
            QMessageBox.warning(
                self,
                "API Key Required",
                "Anthropic API key required for Cursor AI.\n\n"
                "Get your API key at: https://console.anthropic.com/\n\n"
                "You can set it in the dialog or as ANTHROPIC_API_KEY environment variable."
            )
            return
        
        # Update status
        self.generate_btn.setEnabled(False)
        self.generate_btn.setText("Generating...")
        self.instructions_display.setText("Generating instructions... Please wait.")
        QApplication.processEvents()  # Update UI
        
        try:
            # Check for animation keywords
            is_animation = any(keyword in prompt.lower() for keyword in [
                'animate', 'animation', 'shooting', 'moving', 'frame', 'frames'
            ])
            
            # Generate instructions using Cursor AI (Claude)
            instructions = generate_instructions_with_ai(
                prompt,
                api_key=api_key,
                provider="claude",  # Use Claude/Anthropic (Cursor AI)
                tool_knowledge=self.tool_knowledge
            )
            
            if instructions is None:
                self.instructions_display.setText(
                    "ERROR: Failed to generate instructions.\n"
                    "Check console for details."
                )
                return
            
            # Check if AI said it can't do it
            if instructions.get("type") == "generate":
                self.instructions_display.setText(
                    f"AI Response: Editor cannot accomplish this request.\n"
                    f"Reason: {instructions.get('description', 'Unknown')}\n\n"
                    f"The AI would need to generate the image directly instead of using editor tools."
                )
                return
            
            # Display instructions
            self.instructions_display.setText(json.dumps(instructions, indent=2))
            
            # Execute instructions
            self.instructions_display.append("\n\n[EXECUTING INSTRUCTIONS...]")
            QApplication.processEvents()
            
            if is_animation:
                frames = self.execute_instructions_animated(instructions, prompt)
            else:
                canvas = execute_instructions(instructions)
                frames = [canvas]
            
            # Display result
            self.current_frames = frames
            self.current_frame_index = 0
            self.update_preview()
            self.update_frame_controls()
            self.save_btn.setEnabled(True)
            
            self.instructions_display.append(f"\n[OK] Generated {len(frames)} frame(s) successfully!")
            
        except Exception as e:
            import traceback
            error_msg = f"ERROR: {str(e)}\n\nTraceback:\n{traceback.format_exc()}"
            self.instructions_display.setText(error_msg)
            print(error_msg)
        finally:
            self.generate_btn.setEnabled(True)
            self.generate_btn.setText("Generate Instructions & Execute")
    
    def execute_instructions_animated(self, instructions, prompt):
        """Execute instructions with animation support."""
        frames = []
        
        # Create base frame
        base_canvas = execute_instructions(instructions)
        frames.append(base_canvas.copy())
        
        # If prompt mentions animation, create additional frames
        if "shooting star" in prompt.lower():
            # Add shooting star animation (8 frames)
            for i in range(8):
                frame = base_canvas.copy()
                # Draw shooting star moving across
                star_x = int(50 + (i * 60))
                star_y = int(50 + (i * 10))
                
                # Draw star with tail
                self.draw_shooting_star(frame, star_x, star_y)
                frames.append(frame)
        
        return frames
    
    def draw_shooting_star(self, canvas, x, y):
        """Draw a shooting star with tail on the canvas."""
        h, w = canvas.shape[:2]
        
        # Star body (white)
        star_color = np.array([255, 255, 255, 255], dtype=np.uint8)
        if 0 <= y < h and 0 <= x < w:
            canvas[y, x] = star_color
        if 0 <= y-1 < h and 0 <= x < w:
            canvas[y-1, x] = star_color
        if 0 <= y+1 < h and 0 <= x < w:
            canvas[y+1, x] = star_color
        
        # Tail (fading white)
        for i in range(1, 10):
            tail_x = x - i * 3
            tail_y = y + i * 2
            if 0 <= tail_y < h and 0 <= tail_x < w:
                alpha = max(0, 255 - (i * 25))
                tail_color = np.array([255, 255, 255, alpha], dtype=np.uint8)
                canvas[tail_y, tail_x] = tail_color
    
    def update_preview(self):
        """Update the preview widget with current frame."""
        if not self.current_frames:
            self.preview_widget.setText("No preview available")
            self.preview_widget.setPixmap(QPixmap())
            return
        
        frame = self.current_frames[self.current_frame_index]
        h, w = frame.shape[:2]
        
        # Convert numpy array to QImage
        if frame.shape[2] == 4:  # RGBA
            q_image = QImage(frame.data, w, h, w * 4, QImage.Format_RGBA8888)
        elif frame.shape[2] == 3:  # RGB
            q_image = QImage(frame.data, w, h, w * 3, QImage.Format_RGB888)
        else:  # Grayscale
            q_image = QImage(frame.data, w, h, w, QImage.Format_Grayscale8)
        
        pixmap = QPixmap.fromImage(q_image)
        self.preview_widget.setPixmap(pixmap)
    
    def update_frame_controls(self):
        """Show/hide frame controls based on frame count."""
        if len(self.current_frames) > 1:
            self.frame_controls.show()
            self.update_frame_counter()
        else:
            self.frame_controls.hide()
    
    def update_frame_counter(self):
        """Update frame counter label."""
        total = len(self.current_frames)
        current = self.current_frame_index + 1 if total > 0 else 0
        self.frame_counter_label.setText(f"Frame {current}/{total}")
    
    def prev_frame(self):
        """Navigate to previous frame."""
        if self.current_frames:
            self.current_frame_index = (self.current_frame_index - 1 + len(self.current_frames)) % len(self.current_frames)
            self.update_preview()
            self.update_frame_counter()
    
    def next_frame(self):
        """Navigate to next frame."""
        if self.current_frames:
            self.current_frame_index = (self.current_frame_index + 1) % len(self.current_frames)
            self.update_preview()
            self.update_frame_counter()
    
    def toggle_playback(self):
        """Toggle animation playback."""
        if self.is_playing:
            self.pause_playback()
        else:
            self.start_playback()
    
    def start_playback(self):
        """Start animation playback."""
        if len(self.current_frames) > 1:
            self.is_playing = True
            self.play_pause_btn.setText("⏸ Pause")
            self.playback_timer.start(100)  # 100ms per frame
    
    def pause_playback(self):
        """Pause animation playback."""
        self.is_playing = False
        self.play_pause_btn.setText("⏯ Play")
        self.playback_timer.stop()
    
    def stop_playback(self):
        """Stop playback and reset to first frame."""
        self.pause_playback()
        self.current_frame_index = 0
        self.update_preview()
        self.update_frame_counter()
    
    def on_playback_tick(self):
        """Handle animation playback tick."""
        if not self.current_frames or not self.is_playing:
            return
        
        self.current_frame_index = (self.current_frame_index + 1) % len(self.current_frames)
        self.update_preview()
        self.update_frame_counter()
    
    def on_save(self):
        """Save the generated image(s)."""
        if not self.current_frames:
            return
        
        from PySide6.QtWidgets import QFileDialog
        
        if len(self.current_frames) == 1:
            # Save single image
            file_path, _ = QFileDialog.getSaveFileName(
                self, "Save Image", "", "PNG Files (*.png)"
            )
            if file_path:
                pil_image = Image.fromarray(self.current_frames[0], 'RGBA')
                pil_image.save(file_path)
                print(f"[OK] Saved image to: {file_path}")
        else:
            # Save animation as multiple frames
            dir_path = QFileDialog.getExistingDirectory(self, "Select Folder to Save Frames")
            if dir_path:
                for i, frame in enumerate(self.current_frames):
                    file_path = os.path.join(dir_path, f"frame_{i:03d}.png")
                    pil_image = Image.fromarray(frame, 'RGBA')
                    pil_image.save(file_path)
                print(f"[OK] Saved {len(self.current_frames)} frames to: {dir_path}")


def main():
    """Main entry point."""
    app = QApplication(sys.argv)
    
    dialog = AITestDialog()
    dialog.show()
    
    sys.exit(app.exec())


if __name__ == "__main__":
    main()

