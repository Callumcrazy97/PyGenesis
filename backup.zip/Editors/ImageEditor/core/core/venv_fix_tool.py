"""
Venv Permission Fix Tool
Attempts to fix permission issues in the venv directory
"""

import os
import subprocess
import stat
from pathlib import Path
from typing import Tuple, List


class VenvFixTool:
    """Tool to fix venv permission issues."""
    
    @staticmethod
    def check_venv_permissions(venv_path: Path) -> Tuple[bool, List[str]]:
        """
        Check venv directory permissions.
        Returns: (is_ok, issues_list)
        """
        issues = []
        
        if not venv_path.exists():
            issues.append(f"Venv directory does not exist: {venv_path}")
            return False, issues
        
        # Check if we can write to venv
        test_file = venv_path / ".write_test"
        try:
            test_file.write_text("test")
            test_file.unlink()
        except PermissionError:
            issues.append(f"Cannot write to venv directory: {venv_path}")
            return False, issues
        except Exception as e:
            issues.append(f"Error testing write access: {e}")
            return False, issues
        
        # Check site-packages
        if os.name == 'nt':  # Windows
            site_packages = venv_path / "Lib" / "site-packages"
        else:
            import sys
            site_packages = venv_path / "lib" / f"python{sys.version_info.major}.{sys.version_info.minor}" / "site-packages"
        
        if site_packages.exists():
            try:
                test_file = site_packages / ".write_test"
                test_file.write_text("test")
                test_file.unlink()
            except PermissionError:
                issues.append(f"Cannot write to site-packages: {site_packages}")
                return False, issues
        
        return True, []
    
    @staticmethod
    def find_locked_files(venv_path: Path) -> List[Path]:
        """Find potentially locked .pyd and .dll files."""
        locked_files = []
        
        if os.name == 'nt':  # Windows
            site_packages = venv_path / "Lib" / "site-packages"
        else:
            import sys
            site_packages = venv_path / "lib" / f"python{sys.version_info.major}.{sys.version_info.minor}" / "site-packages"
        
        if not site_packages.exists():
            return locked_files
        
        # Look for .pyd and .dll files
        for ext in ['*.pyd', '*.dll']:
            for file_path in site_packages.rglob(ext):
                try:
                    # Try to open file in write mode to check if locked
                    with open(file_path, 'r+b'):
                        pass
                except (PermissionError, IOError):
                    locked_files.append(file_path)
                except Exception:
                    pass  # Other errors, skip
        
        return locked_files
    
    @staticmethod
    def check_running_python_processes() -> List[dict]:
        """Check for running Python processes that might lock files."""
        import psutil
        processes = []
        
        try:
            current_pid = os.getpid()
            for proc in psutil.process_iter(['pid', 'name', 'exe', 'cmdline']):
                try:
                    if proc.info['pid'] == current_pid:
                        continue
                    
                    name = proc.info.get('name', '').lower()
                    exe = proc.info.get('exe', '')
                    
                    if 'python' in name or (exe and 'python' in exe.lower()):
                        processes.append({
                            'pid': proc.info['pid'],
                            'name': proc.info.get('name', 'Unknown'),
                            'cmdline': ' '.join(proc.info.get('cmdline', []))
                        })
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue
        except ImportError:
            # psutil not available
            pass
        except Exception:
            pass
        
        return processes
    
    @staticmethod
    def suggest_fixes(venv_path: Path, locked_files: List[Path] = None) -> str:
        """Generate suggestions for fixing venv issues."""
        suggestions = []
        
        # Check permissions
        is_ok, issues = VenvFixTool.check_venv_permissions(venv_path)
        if not is_ok:
            suggestions.append("Venv Permission Issues:")
            for issue in issues:
                suggestions.append(f"  • {issue}")
            suggestions.append("  Fix: Check folder permissions or recreate venv")
        
        # Check for locked files
        if locked_files:
            suggestions.append(f"\nLocked Files Found ({len(locked_files)}):")
            for locked_file in locked_files[:5]:  # Show first 5
                suggestions.append(f"  • {locked_file.name}")
            if len(locked_files) > 5:
                suggestions.append(f"  ... and {len(locked_files) - 5} more")
            suggestions.append("\n  Fix: Close programs using these files")
        
        # Check for Python processes
        python_procs = VenvFixTool.check_running_python_processes()
        if python_procs:
            suggestions.append(f"\nRunning Python Processes ({len(python_procs)}):")
            for proc in python_procs[:3]:  # Show first 3
                suggestions.append(f"  • PID {proc['pid']}: {proc['name']}")
            if len(python_procs) > 3:
                suggestions.append(f"  ... and {len(python_procs) - 3} more")
            suggestions.append("\n  Fix: Close these processes")
        
        if not suggestions:
            return "No obvious issues detected. Try restarting PyGenesis."
        
        return "\n".join(suggestions)

