import copy
import numpy as np

class HistoryManager:
    def __init__(self, state, max_undo=10):
        self.state = state
        self.undo_stack = []
        self.redo_stack = []
        self.max_undo = max_undo

    def push_undo(self):
        # Store a deep copy of the current frame's image AND selection state
        layer = self.state.layer_manager.get_current_layer()
        frame_idx = self.state.layer_manager.current_frame
        frame = layer.get_frame(frame_idx)
        
        # Save selection state
        selection_state = None
        if self.state.selection_manager.has_selection():
            selection_state = {
                'mask': self.state.selection_manager.mask.copy() if self.state.selection_manager.mask is not None else None,
                'bounds': self.state.selection_manager.bounds
            }
        
        # Store both image and selection
        self.undo_stack.append({
            'image': copy.deepcopy(frame.image),
            'selection': selection_state
        })
        if len(self.undo_stack) > self.max_undo:
            self.undo_stack.pop(0)
        self.redo_stack.clear()

    def undo(self):
        if not self.undo_stack:
            return
        layer = self.state.layer_manager.get_current_layer()
        frame_idx = self.state.layer_manager.current_frame
        frame = layer.get_frame(frame_idx)
        
        # Save current state to redo stack
        selection_state = None
        if self.state.selection_manager.has_selection():
            selection_state = {
                'mask': self.state.selection_manager.mask.copy() if self.state.selection_manager.mask is not None else None,
                'bounds': self.state.selection_manager.bounds
            }
        
        self.redo_stack.append({
            'image': copy.deepcopy(frame.image),
            'selection': selection_state
        })
        
        # Restore from undo stack
        state_data = self.undo_stack.pop()
        frame.image = state_data['image']
        
        # Restore selection
        if state_data['selection'] is not None:
            self.state.selection_manager.mask = state_data['selection']['mask'].copy() if state_data['selection']['mask'] is not None else None
            self.state.selection_manager.bounds = state_data['selection']['bounds']
        else:
            self.state.selection_manager.clear_selection()

    def redo(self):
        if not self.redo_stack:
            return
        layer = self.state.layer_manager.get_current_layer()
        frame_idx = self.state.layer_manager.current_frame
        frame = layer.get_frame(frame_idx)
        
        # Save current state to undo stack
        selection_state = None
        if self.state.selection_manager.has_selection():
            selection_state = {
                'mask': self.state.selection_manager.mask.copy() if self.state.selection_manager.mask is not None else None,
                'bounds': self.state.selection_manager.bounds
            }
        
        self.undo_stack.append({
            'image': copy.deepcopy(frame.image),
            'selection': selection_state
        })
        
        # Restore from redo stack
        state_data = self.redo_stack.pop()
        frame.image = state_data['image']
        
        # Restore selection
        if state_data['selection'] is not None:
            self.state.selection_manager.mask = state_data['selection']['mask'].copy() if state_data['selection']['mask'] is not None else None
            self.state.selection_manager.bounds = state_data['selection']['bounds']
        else:
            self.state.selection_manager.clear_selection()

    def clear_history(self):
        self.undo_stack.clear()
        self.redo_stack.clear() 