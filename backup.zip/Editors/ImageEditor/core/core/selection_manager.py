from PySide6.QtCore import Qt, QRectF
from PySide6.QtGui import QPainter, QColor, QPen, QPainterPath, QBrush
from PySide6.QtCore import QPointF
import numpy as np

# Optional SAM support
SAM_AVAILABLE = False
try:
    from segment_anything import SamPredictor, sam_model_registry
    SAM_AVAILABLE = True
except ImportError:
    pass

class SimpleSelectionManager:
    """Simplified, fast selection manager using only boolean masks"""
    
    def __init__(self):
        self.mask = None  # Boolean mask (H, W) - the only selection data we need
        self.bounds = None  # Cached bounding box (x1, y1, x2, y2)
        self.marching_ants_offset = 0
        self.marching_ants_speed = 2
        
        # Selection transform state
        self.is_moving = False
        self.is_resizing = False
        self.resize_handle = None  # Which handle is being dragged (0-7: corners + edges)
        self.move_start_pos = None
        self.move_start_bounds = None
        
        # Optional SAM predictor (lazy-loaded)
        self.sam_predictor = None
        self.sam_model_path = None
        
    def has_selection(self):
        """Check if there's an active selection"""
        return self.mask is not None and np.any(self.mask)
    
    def clear_selection(self):
        """Clear the current selection"""
        self.mask = None
        self.bounds = None
    
    def get_selection_bounds(self):
        """Get the bounding rectangle of the current selection"""
        if self.bounds is not None:
            return self.bounds
        
        if self.mask is None or not np.any(self.mask):
            return None
            
        # Calculate bounds from mask
        coords = np.where(self.mask)
        if len(coords[0]) > 0:
            y1, y2 = coords[0].min(), coords[0].max()
            x1, x2 = coords[1].min(), coords[1].max()
            self.bounds = (x1, y1, x2 + 1, y2 + 1)
            return self.bounds
        return None
    
    def _update_bounds(self):
        """Update cached bounds from mask"""
        self.bounds = None  # Clear cache first
        self.bounds = self.get_selection_bounds()
    
    # ========== SELECTION METHODS ==========
    
    def select_rect(self, x1, y1, x2, y2, image_shape):
        """Create rectangular selection"""
        h, w = image_shape[:2]
        x1, x2 = max(0, min(x1, x2)), min(w, max(x1, x2))
        y1, y2 = max(0, min(y1, y2)), min(h, max(y1, y2))
        
        if x2 <= x1 or y2 <= y1:
            self.mask = None
            self.bounds = None
            return
        
        self.mask = np.zeros((h, w), dtype=bool)
        self.mask[y1:y2, x1:x2] = True
        self.bounds = (x1, y1, x2, y2)
    
    def select_magic_wand_opencv(self, pos_x, pos_y, image, tolerance=32):
        """Fast magic wand using OpenCV floodFill"""
        try:
            import cv2
        except ImportError:
            # Fallback to slower pure Python version
            return self.select_magic_wand_python(pos_x, pos_y, image, tolerance)
        
        h, w = image.shape[:2]
        if pos_x < 0 or pos_x >= w or pos_y < 0 or pos_y >= h:
            return False
        
        # Check if clicked pixel is transparent/blank
        # If so, we need to handle it specially to avoid selecting entire image
        if len(image.shape) == 3 and image.shape[2] == 4:
            clicked_alpha = image[pos_y, pos_x, 3]
            # Calculate blank threshold based on tolerance (10-50 range)
            # Higher tolerance = more lenient blank detection
            blank_alpha_threshold = min(10 + (tolerance // 3), 50)
            # If clicked on transparent/near-blank pixel
            if clicked_alpha < blank_alpha_threshold:
                # For transparent pixels, only select contiguous transparent areas
                # Use alpha channel for flood fill on transparent regions
                alpha_mask = image[:, :, 3]
                
                # Flood fill mask (needs border for OpenCV)
                mask = np.zeros((h + 2, w + 2), np.uint8)
                
                # Flood fill using alpha channel only, with low tolerance for transparency
                # Convert alpha to single channel for flood fill
                alpha_bgr = cv2.cvtColor(alpha_mask, cv2.COLOR_GRAY2BGR)
                
                flags = 4 | (255 << 8) | cv2.FLOODFILL_MASK_ONLY
                # Use tolerance for alpha values (how much alpha can vary)
                # Scale tolerance appropriately for near-blank detection
                alpha_tolerance = max(10, tolerance // 2)  # More lenient for alpha
                lo_diff = (alpha_tolerance,) * 3
                up_diff = (alpha_tolerance,) * 3
                
                cv2.floodFill(alpha_bgr, mask, (pos_x, pos_y), 255, 
                             lo_diff, up_diff, flags)
                
                # Remove border and convert to boolean
                result_mask = mask[1:-1, 1:-1].astype(bool)
                
                # Limit selection to only transparent pixels (alpha < threshold)
                # This prevents selecting the entire image when clicking on blank space
                transparent_mask = alpha_mask < 10
                result_mask = result_mask & transparent_mask
                
                # If the selection is too large (more than 50% of image), limit it
                # This handles the case where clicking on blank selects everything
                selection_size = np.sum(result_mask)
                if selection_size > (h * w * 0.5):
                    # Too large - likely clicked on mostly blank image or large blank area
                    # Limit to a reasonable maximum size (e.g., 25% of image)
                    max_size = int(h * w * 0.25)
                    if selection_size > max_size:
                        # Get the largest connected component around the click point
                        # This keeps the selection local to where the user clicked
                        from scipy import ndimage
                        try:
                            # Label connected components
                            labeled, num_features = ndimage.label(result_mask)
                            # Find the label at the click point
                            click_label = labeled[pos_y, pos_x]
                            if click_label > 0:
                                # Keep only the component containing the click
                                result_mask = (labeled == click_label)
                            else:
                                # Click wasn't in a component, select small area
                                result_mask = np.zeros((h, w), dtype=bool)
                                size = 3
                                y1 = max(0, pos_y - size)
                                y2 = min(h, pos_y + size + 1)
                                x1 = max(0, pos_x - size)
                                x2 = min(w, pos_x + size + 1)
                                result_mask[y1:y2, x1:x2] = True
                                result_mask = result_mask & transparent_mask
                        except ImportError:
                            # scipy not available, fallback to small area
                            result_mask = np.zeros((h, w), dtype=bool)
                            size = 3
                            y1 = max(0, pos_y - size)
                            y2 = min(h, pos_y + size + 1)
                            x1 = max(0, pos_x - size)
                            x2 = min(w, pos_x + size + 1)
                            result_mask[y1:y2, x1:x2] = True
                            result_mask = result_mask & transparent_mask
                
                self.mask = result_mask
                self._update_bounds()
                return True
        
        # Normal case: clicked on non-transparent pixel
        # Use LAB color space for better perceptual color matching (especially with effects)
        if len(image.shape) == 3 and image.shape[2] >= 3:
            # Convert RGB to LAB color space for perceptual matching
            rgb = image[:, :, :3].astype(np.uint8)
            lab = cv2.cvtColor(rgb, cv2.COLOR_RGB2LAB)
            
            # Flood fill mask (needs border for OpenCV)
            mask = np.zeros((h + 2, w + 2), np.uint8)
            
            # Use LAB color space - tolerance is more perceptually accurate
            # Scale tolerance for LAB (L: 0-100, A/B: -127 to 127)
            # Convert tolerance from RGB range (0-255) to LAB-appropriate range
            lab_tolerance = int(tolerance * 0.4)  # Scale down for LAB
            lo_diff = (lab_tolerance, lab_tolerance, lab_tolerance)
            up_diff = (lab_tolerance, lab_tolerance, lab_tolerance)
            
            flags = 4 | (255 << 8) | cv2.FLOODFILL_MASK_ONLY
            cv2.floodFill(lab, mask, (pos_x, pos_y), 255, lo_diff, up_diff, flags)
        else:
            # Fallback to RGB if LAB not available
            if len(image.shape) == 3:
                img_bgr = cv2.cvtColor(image[:, :, :3], cv2.COLOR_RGB2BGR)
            else:
                img_bgr = cv2.cvtColor(image, cv2.COLOR_GRAY2BGR)
            
            mask = np.zeros((h + 2, w + 2), np.uint8)
            flags = 4 | (255 << 8) | cv2.FLOODFILL_MASK_ONLY
            lo_diff = (tolerance,) * 3
            up_diff = (tolerance,) * 3
            cv2.floodFill(img_bgr, mask, (pos_x, pos_y), 255, lo_diff, up_diff, flags)
        
        # Remove border
        result_mask = mask[1:-1, 1:-1].astype(bool)
        
        # Limit selection size if it's too large (likely clicked on background with effects)
        # This prevents selecting the entire image when effects change colors
        selection_size = np.sum(result_mask)
        if selection_size > (h * w * 0.8):  # If more than 80% selected
            # Keep only the connected component at the click point
            from scipy import ndimage
            try:
                labeled, num_features = ndimage.label(result_mask)
                click_label = labeled[pos_y, pos_x]
                if click_label > 0:
                    result_mask = (labeled == click_label)
            except ImportError:
                pass  # Keep original mask if scipy not available
        
        self.mask = result_mask
        self._update_bounds()
        return True
    
    def select_magic_wand_python(self, pos_x, pos_y, image, tolerance=32):
        """Pure Python fallback for magic wand (slower but always works)"""
        h, w = image.shape[:2]
        if pos_x < 0 or pos_x >= w or pos_y < 0 or pos_y >= h:
            return False
        
        # Calculate blank threshold based on tolerance
        blank_alpha_threshold = min(10 + (tolerance // 3), 50)
        alpha_tolerance = max(10, tolerance // 2)
        
        # Check if clicked pixel is transparent/blank
        if len(image.shape) == 3 and image.shape[2] == 4:
            clicked_alpha = image[pos_y, pos_x, 3]
            # If clicked on transparent/near-blank pixel
            if clicked_alpha < blank_alpha_threshold:
                # For transparent pixels, use flood fill on alpha channel only
                alpha_mask = image[:, :, 3]
                mask = np.zeros((h, w), dtype=bool)
                stack = [(pos_y, pos_x)]
                visited = set()
                
                target_alpha = alpha_mask[pos_y, pos_x]
                
                while stack:
                    cy, cx = stack.pop()
                    if (cy, cx) in visited:
                        continue
                    if cy < 0 or cy >= h or cx < 0 or cx >= w:
                        continue
                    
                    # Check if pixel alpha is within tolerance of target
                    pixel_alpha = alpha_mask[cy, cx]
                    if abs(pixel_alpha - target_alpha) <= alpha_tolerance:
                        mask[cy, cx] = True
                        visited.add((cy, cx))
                        # Add neighbors
                        stack.append((cy - 1, cx))
                        stack.append((cy + 1, cx))
                        stack.append((cy, cx - 1))
                        stack.append((cy, cx + 1))
                
                # If the selection is too large (more than 90% of image), limit it
                if np.sum(mask) > (h * w * 0.9):
                    # Too large - only select small area around click
                    mask = np.zeros((h, w), dtype=bool)
                    size = 2
                    y1 = max(0, pos_y - size)
                    y2 = min(h, pos_y + size + 1)
                    x1 = max(0, pos_x - size)
                    x2 = min(w, pos_x + size + 1)
                    mask[y1:y2, x1:x2] = True
                    # Only keep transparent pixels
                    transparent_mask = alpha_mask < 10
                    mask = mask & transparent_mask
                
                self.mask = mask
                self._update_bounds()
                return True
        
        # Normal case: clicked on non-transparent pixel
        # Get target color
        target = image[pos_y, pos_x, :3].astype(np.int32) if len(image.shape) == 3 else image[pos_y, pos_x]
        if len(image.shape) == 3:
            mask = np.zeros((h, w), dtype=bool)
            stack = [(pos_y, pos_x)]
            
            while stack:
                cy, cx = stack.pop()
                if 0 <= cy < h and 0 <= cx < w and not mask[cy, cx]:
                    color = image[cy, cx, :3].astype(np.int32)
                    r_diff = abs(color[0] - target[0])
                    g_diff = abs(color[1] - target[1])
                    b_diff = abs(color[2] - target[2])
                    max_diff = max(r_diff, g_diff, b_diff)
                    avg_diff = (r_diff + g_diff + b_diff) / 3
                    color_diff = (max_diff + avg_diff) / 2
                    
                    if color_diff <= tolerance:
                        mask[cy, cx] = True
                        stack.extend([
                            (cy-1, cx-1), (cy-1, cx), (cy-1, cx+1),
                            (cy, cx-1), (cy, cx+1),
                            (cy+1, cx-1), (cy+1, cx), (cy+1, cx+1)
                        ])
        else:
            # Grayscale
            mask = np.zeros((h, w), dtype=bool)
            stack = [(pos_y, pos_x)]
            target_val = int(target)
            
            while stack:
                cy, cx = stack.pop()
                if 0 <= cy < h and 0 <= cx < w and not mask[cy, cx]:
                    val = int(image[cy, cx])
                    if abs(val - target_val) <= tolerance:
                        mask[cy, cx] = True
                        stack.extend([
                            (cy-1, cx-1), (cy-1, cx), (cy-1, cx+1),
                            (cy, cx-1), (cy, cx+1),
                            (cy+1, cx-1), (cy+1, cx), (cy+1, cx+1)
                        ])
        
        self.mask = mask
        self._update_bounds()
        return True
    
    def select_sam(self, pos_x, pos_y, image):
        """Use Segment Anything Model for smart selection"""
        if not SAM_AVAILABLE:
            return False
        
        # Lazy-load SAM predictor
        if self.sam_predictor is None:
            try:
                # Try to load SAM model
                # User should set sam_model_path before calling
                if self.sam_model_path is None:
                    return False
                
                sam = sam_model_registry["vit_b"](checkpoint=self.sam_model_path)
                self.sam_predictor = SamPredictor(sam)
            except Exception:
                return False
        
        try:
            h, w = image.shape[:2]
            if len(image.shape) == 3:
                img_rgb = image[:, :, :3]
            else:
                img_rgb = np.stack([image] * 3, axis=-1)
            
            self.sam_predictor.set_image(img_rgb)
            masks, scores, _ = self.sam_predictor.predict(
                point_coords=np.array([[pos_x, pos_y]]),
                point_labels=np.array([1])
            )
            
            # Use the highest scoring mask
            if len(masks) > 0 and scores[0] > 0.5:
                self.mask = masks[0].astype(bool)
                self._update_bounds()
                return True
        except Exception:
            pass
        
        return False
    
    def brush_select(self, pos_x, pos_y, radius, image_shape, add=True):
        """Brush selection - simple circular mask"""
        h, w = image_shape[:2]
        
        # Create circle mask
        y, x = np.ogrid[:h, :w]
        dist = np.sqrt((x - pos_x)**2 + (y - pos_y)**2)
        circle_mask = dist <= radius
        
        if self.mask is None:
            self.mask = np.zeros((h, w), dtype=bool)
        
        if add:
            self.mask |= circle_mask
        else:
            self.mask &= ~circle_mask
        
        self._update_bounds()
    
    def lasso_select(self, points, image_shape):
        """Lasso selection using polygon points"""
        h, w = image_shape[:2]
        
        if len(points) < 3:
            return
        
        try:
            from matplotlib.path import Path
            mask = np.zeros((h, w), dtype=bool)
            
            # Create path from points
            path = Path(points)
            
            # Check all pixels
            y, x = np.ogrid[:h, :w]
            coords = np.column_stack([x.ravel(), y.ravel()])
            mask_flat = path.contains_points(coords)
            mask = mask_flat.reshape((h, w))
            
            self.mask = mask
            self._update_bounds()
        except ImportError:
            # Fallback: simple approximation
            pass
    
    def select_all(self, image_shape):
        """Select entire image"""
        h, w = image_shape[:2]
        self.mask = np.ones((h, w), dtype=bool)
        self.bounds = (0, 0, w, h)
    
    def invert_selection(self, image_shape):
        """Invert current selection"""
        if self.mask is not None:
            h, w = image_shape[:2]
            self.mask = ~self.mask
            self._update_bounds()
    
    def expand_selection(self, pixels=1):
        """Expand selection by specified pixels"""
        if self.mask is None:
            return
        
        try:
            from scipy.ndimage import binary_dilation
            structure = np.ones((pixels*2+1, pixels*2+1), dtype=bool)
            self.mask = binary_dilation(self.mask, structure=structure, iterations=pixels)
            self._update_bounds()
        except ImportError:
            # Simple fallback dilation
            kernel = np.ones((3, 3), dtype=bool)
            for _ in range(pixels):
                h, w = self.mask.shape
                expanded = np.zeros_like(self.mask)
                for y in range(1, h-1):
                    for x in range(1, w-1):
                        if self.mask[y, x] or np.any(self.mask[y-1:y+2, x-1:x+2]):
                            expanded[y, x] = True
                self.mask = expanded
            self._update_bounds()
    
    def contract_selection(self, pixels=1):
        """Contract selection by specified pixels"""
        if self.mask is None:
            return
        
        try:
            from scipy.ndimage import binary_erosion
            structure = np.ones((pixels*2+1, pixels*2+1), dtype=bool)
            self.mask = binary_erosion(self.mask, structure=structure, iterations=pixels)
            self._update_bounds()
        except ImportError:
            # Simple fallback erosion
            for _ in range(pixels):
                h, w = self.mask.shape
                contracted = np.zeros_like(self.mask)
                for y in range(1, h-1):
                    for x in range(1, w-1):
                        if self.mask[y, x] and np.all(self.mask[y-1:y+2, x-1:x+2]):
                            contracted[y, x] = True
                self.mask = contracted
            self._update_bounds()
    
    # ========== DRAWING METHODS ==========
    
    def update_marching_ants(self):
        """Update marching ants animation"""
        self.marching_ants_offset = (self.marching_ants_offset + self.marching_ants_speed) % 16
    
    def get_handle_at_position(self, screen_x, screen_y, scale=1.0, offset_x=0, offset_y=0, handle_size=8):
        """Get which resize handle (if any) is at the given screen position"""
        if not self.has_selection():
            return None
        
        bounds = self.get_selection_bounds()
        if not bounds:
            return None
        
        x1, y1, x2, y2 = bounds
        screen_x1 = x1 * scale + offset_x
        screen_y1 = y1 * scale + offset_y
        screen_x2 = x2 * scale + offset_x
        screen_y2 = y2 * scale + offset_y
        
        # Handle positions: 0=top-left, 1=top, 2=top-right, 3=right, 4=bottom-right, 5=bottom, 6=bottom-left, 7=left
        handles = [
            (screen_x1, screen_y1),  # 0: top-left
            ((screen_x1 + screen_x2) / 2, screen_y1),  # 1: top
            (screen_x2, screen_y1),  # 2: top-right
            (screen_x2, (screen_y1 + screen_y2) / 2),  # 3: right
            (screen_x2, screen_y2),  # 4: bottom-right
            ((screen_x1 + screen_x2) / 2, screen_y2),  # 5: bottom
            (screen_x1, screen_y2),  # 6: bottom-left
            (screen_x1, (screen_y1 + screen_y2) / 2),  # 7: left
        ]
        
        # Check if click is near any handle
        for i, (hx, hy) in enumerate(handles):
            if abs(screen_x - hx) <= handle_size and abs(screen_y - hy) <= handle_size:
                return i
        
        return None
    
    def draw_selection_overlay(self, painter, scale=1.0, offset_x=0, offset_y=0, selection_color=None, show_handles=True):
        """Draw smooth marching ants using contour detection with improved visuals and resize handles"""
        if not self.has_selection():
            return
        
        # Use provided color or default to bright accent color
        if selection_color is None:
            selection_color = QColor(97, 175, 239)  # Default bright blue (#61afef)
        
        # Get contours - try OpenCV first (more likely to be available), then skimage
        contours = None
        try:
            import cv2
            # OpenCV findContours expects uint8
            mask_uint8 = self.mask.astype(np.uint8) * 255
            cv_contours, _ = cv2.findContours(mask_uint8, cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE)
            # Convert OpenCV contours to skimage-like format (list of (row, col) points)
            contours = []
            for cnt in cv_contours:
                if len(cnt) >= 3:
                    # OpenCV format: (x, y) -> convert to (row, col) = (y, x)
                    contour_points = np.array([[pt[0][1], pt[0][0]] for pt in cnt])
                    contours.append(contour_points)
        except (ImportError, Exception):
            # Try skimage as fallback
            try:
                from skimage import measure
                contours = measure.find_contours(self.mask.astype(float), 0.5)
            except (ImportError, Exception):
                contours = None
        
        if contours:
            # Draw semi-transparent fill for better visibility
            painter.setRenderHint(QPainter.Antialiasing, True)
            
            # Draw fill with low opacity
            fill_color = QColor(selection_color)
            fill_color.setAlpha(30)  # Very transparent fill
            painter.setBrush(QBrush(fill_color))
            painter.setPen(Qt.NoPen)
            
            for contour in contours:
                if len(contour) < 3:
                    continue
                
                path = QPainterPath()
                row, col = contour[0]
                screen_x = col * scale + offset_x
                screen_y = row * scale + offset_y
                path.moveTo(QPointF(screen_x, screen_y))
                
                for point in contour[1:]:
                    row, col = point
                    screen_x = col * scale + offset_x
                    screen_y = row * scale + offset_y
                    path.lineTo(QPointF(screen_x, screen_y))
                
                path.closeSubpath()
                painter.drawPath(path)
            
            # Draw outer border (white) with marching ants
            pen = QPen(QColor(255, 255, 255), 2, Qt.SolidLine)
            dash_pattern = [6, 4]  # Longer dashes for better visibility
            pen.setDashPattern(dash_pattern)
            pen.setDashOffset(self.marching_ants_offset)
            painter.setPen(pen)
            painter.setBrush(Qt.NoBrush)
            
            for contour in contours:
                if len(contour) < 3:
                    continue
                
                path = QPainterPath()
                row, col = contour[0]
                screen_x = col * scale + offset_x
                screen_y = row * scale + offset_y
                path.moveTo(QPointF(screen_x, screen_y))
                
                for point in contour[1:]:
                    row, col = point
                    screen_x = col * scale + offset_x
                    screen_y = row * scale + offset_y
                    path.lineTo(QPointF(screen_x, screen_y))
                
                path.closeSubpath()
                painter.drawPath(path)
            
            # Draw inner border (colored) with marching ants offset
            pen = QPen(selection_color, 1.5, Qt.SolidLine)
            pen.setDashPattern(dash_pattern)
            pen.setDashOffset(self.marching_ants_offset + 5)  # Offset for alternating effect
            painter.setPen(pen)
            
            for contour in contours:
                if len(contour) < 3:
                    continue
                
                path = QPainterPath()
                row, col = contour[0]
                screen_x = col * scale + offset_x
                screen_y = row * scale + offset_y
                path.moveTo(QPointF(screen_x, screen_y))
                
                for point in contour[1:]:
                    row, col = point
                    screen_x = col * scale + offset_x
                    screen_y = row * scale + offset_y
                    path.lineTo(QPointF(screen_x, screen_y))
                
                path.closeSubpath()
                painter.drawPath(path)
        else:
            # Fallback: draw rectangle bounds if contour detection not available
            bounds = self.get_selection_bounds()
            if bounds:
                x1, y1, x2, y2 = bounds
                screen_x1 = x1 * scale + offset_x
                screen_y1 = y1 * scale + offset_y
                screen_x2 = x2 * scale + offset_x
                screen_y2 = y2 * scale + offset_y
                
                rect = QRectF(screen_x1, screen_y1, screen_x2 - screen_x1, screen_y2 - screen_y1)
                
                # Draw fill
                fill_color = QColor(selection_color)
                fill_color.setAlpha(30)
                painter.setBrush(QBrush(fill_color))
                painter.setPen(Qt.NoPen)
                painter.drawRect(rect)
                
                # Draw outer white border
                pen = QPen(QColor(255, 255, 255), 2, Qt.SolidLine)
                dash_pattern = [6, 4]
                pen.setDashPattern(dash_pattern)
                pen.setDashOffset(self.marching_ants_offset)
                painter.setPen(pen)
                painter.setBrush(Qt.NoBrush)
                painter.drawRect(rect)
                
                # Draw inner colored border
                pen = QPen(selection_color, 1.5, Qt.SolidLine)
                pen.setDashPattern(dash_pattern)
                pen.setDashOffset(self.marching_ants_offset + 5)
                painter.setPen(pen)
                painter.drawRect(rect)
    
    def draw_rectangle_preview(self, painter, start_pos, current_pos, scale=1.0, offset_x=0, offset_y=0, selection_color=None):
        """Draw rectangle selection preview with improved visuals"""
        screen_x1 = start_pos.x()
        screen_y1 = start_pos.y()
        screen_x2 = current_pos.x()
        screen_y2 = current_pos.y()
        
        rect_x = min(screen_x1, screen_x2)
        rect_y = min(screen_y1, screen_y2)
        rect_w = abs(screen_x2 - screen_x1)
        rect_h = abs(screen_y2 - screen_y1)
        
        rect = QRectF(rect_x, rect_y, rect_w, rect_h)
        
        # Use provided color or default
        if selection_color is None:
            selection_color = QColor(97, 175, 239)  # Default bright blue
        
        painter.setRenderHint(QPainter.Antialiasing, True)
        
        # Draw semi-transparent fill
        fill_color = QColor(selection_color)
        fill_color.setAlpha(30)
        painter.setBrush(QBrush(fill_color))
        painter.setPen(Qt.NoPen)
        painter.drawRect(rect)
        
        # Draw outer white border with marching ants
        pen = QPen(QColor(255, 255, 255), 2, Qt.SolidLine)
        dash_pattern = [6, 4]
        pen.setDashPattern(dash_pattern)
        pen.setDashOffset(self.marching_ants_offset)
        painter.setPen(pen)
        painter.setBrush(Qt.NoBrush)
        painter.drawRect(rect)
        
        # Draw inner colored border with marching ants offset
        pen = QPen(selection_color, 1.5, Qt.SolidLine)
        pen.setDashPattern(dash_pattern)
        pen.setDashOffset(self.marching_ants_offset + 5)
        painter.setPen(pen)
        painter.drawRect(rect)
        
        # Note: No handles for preview - handles are shown only for finalized selections
    
    def _draw_resize_handles(self, painter, contours, scale, offset_x, offset_y, selection_color):
        """Draw resize handles for complex selection shapes"""
        if not contours:
            return
        
        # Get bounding box for handles
        bounds = self.get_selection_bounds()
        if not bounds:
            return
        
        x1, y1, x2, y2 = bounds
        screen_x1 = x1 * scale + offset_x
        screen_y1 = y1 * scale + offset_y
        screen_x2 = x2 * scale + offset_x
        screen_y2 = y2 * scale + offset_y
        
        self._draw_resize_handles_at_bounds(painter, screen_x1, screen_y1, screen_x2, screen_y2, selection_color)
    
    def _draw_resize_handles_rect(self, painter, rect, selection_color):
        """Draw resize handles for rectangular selection"""
        self._draw_resize_handles_at_bounds(painter, rect.x(), rect.y(), rect.x() + rect.width(), rect.y() + rect.height(), selection_color)
    
    def _draw_resize_handles_at_bounds(self, painter, x1, y1, x2, y2, selection_color):
        """Draw 8 resize handles at selection bounds"""
        handle_size = 8
        handle_half = handle_size / 2
        
        # Handle color - white with dark border for visibility
        handle_color = QColor(255, 255, 255)
        handle_border = QColor(0, 0, 0)
        
        painter.setRenderHint(QPainter.Antialiasing, True)
        
        # Define handle positions: corners and midpoints
        handles = [
            (x1, y1),  # 0: top-left
            ((x1 + x2) / 2, y1),  # 1: top
            (x2, y1),  # 2: top-right
            (x2, (y1 + y2) / 2),  # 3: right
            (x2, y2),  # 4: bottom-right
            ((x1 + x2) / 2, y2),  # 5: bottom
            (x1, y2),  # 6: bottom-left
            (x1, (y1 + y2) / 2),  # 7: left
        ]
        
        # Draw each handle
        for hx, hy in handles:
            # Draw border
            painter.setPen(QPen(handle_border, 2))
            painter.setBrush(QBrush(handle_border))
            painter.drawEllipse(int(hx - handle_half - 1), int(hy - handle_half - 1), handle_size + 2, handle_size + 2)
            
            # Draw handle
            painter.setPen(QPen(handle_color, 1))
            painter.setBrush(QBrush(handle_color))
            painter.drawEllipse(int(hx - handle_half), int(hy - handle_half), handle_size, handle_size)
    
    # ========== SELECTION OPERATIONS ==========
    
    def delete_selection(self, layer_manager):
        """Delete the selected area from the current layer"""
        if not self.has_selection():
            return False
        
        layer = layer_manager.get_current_layer()
        if not layer or not layer.visible:
            return False
        
        image = layer_manager.get_current_image()
        if image is None:
            return False
        
        bounds = self.get_selection_bounds()
        if bounds:
            x1, y1, x2, y2 = bounds
            region = image[y1:y2, x1:x2]
            mask_region = self.mask[y1:y2, x1:x2]
            # Set selected pixels to transparent (RGBA: 0,0,0,0)
            if len(image.shape) == 3 and image.shape[2] == 4:
                region[mask_region] = [0, 0, 0, 0]
            else:
                region[mask_region] = 0
        
        # Note: The caller should update the layer/image after deletion
        return True
    
    def point_in_selection(self, x, y):
        """Check if a point (in image coordinates) is inside the selection"""
        if not self.has_selection() or self.mask is None:
            return False
        h, w = self.mask.shape[:2]
        if 0 <= int(y) < h and 0 <= int(x) < w:
            return bool(self.mask[int(y), int(x)])
        return False
    
    def move_selection(self, dx, dy, image_shape):
        """Move selection mask (for mouse dragging)"""
        if not self.has_selection():
            return False
        
        # Convert deltas to integers (image coordinates should be whole pixels)
        dx = int(round(dx))
        dy = int(round(dy))

        if dx == 0 and dy == 0:
            return False

        h, w = image_shape[:2]
        new_mask = np.zeros((h, w), dtype=bool)
        
        # Calculate new bounds
        bounds = self.get_selection_bounds()
        if bounds:
            x1, y1, x2, y2 = bounds
            new_x1 = int(max(0, min(w - (x2 - x1), x1 + dx)))
            new_y1 = int(max(0, min(h - (y2 - y1), y1 + dy)))
            
            # Copy mask region
            sel_h = y2 - y1
            sel_w = x2 - x1
            
            src_y1 = max(0, y1)
            src_y2 = min(h, y2)
            src_x1 = max(0, x1)
            src_x2 = min(w, x2)
            
            dst_y1 = max(0, new_y1)
            dst_y2 = min(h, new_y1 + (src_y2 - src_y1))
            dst_x1 = max(0, new_x1)
            dst_x2 = min(w, new_x1 + (src_x2 - src_x1))
            
            sel_h_actual = min(dst_y2 - dst_y1, src_y2 - src_y1)
            sel_w_actual = min(dst_x2 - dst_x1, src_x2 - src_x1)
            
            if sel_h_actual > 0 and sel_w_actual > 0:
                new_mask[dst_y1:dst_y1+sel_h_actual, dst_x1:dst_x1+sel_w_actual] = \
                    self.mask[src_y1:src_y1+sel_h_actual, src_x1:src_x1+sel_w_actual]
        
        self.mask = new_mask
        self._update_bounds()
        return True
    
    def move_selection_by_keys(self, dx, dy, image_shape):
        """Move selection by keyboard arrow keys"""
        if not self.has_selection():
            return False
        
        dx = int(dx)
        dy = int(dy)

        if dx == 0 and dy == 0:
            return False

        h, w = image_shape[:2]
        new_mask = np.zeros((h, w), dtype=bool)
        
        # Calculate new bounds
        bounds = self.get_selection_bounds()
        if bounds:
            x1, y1, x2, y2 = bounds
            new_x1 = int(max(0, min(w - (x2 - x1), x1 + dx)))
            new_y1 = int(max(0, min(h - (y2 - y1), y1 + dy)))
            
            # Copy mask region
            sel_h = y2 - y1
            sel_w = x2 - x1
            
            src_y1 = max(0, y1)
            src_y2 = min(h, y2)
            src_x1 = max(0, x1)
            src_x2 = min(w, x2)
            
            dst_y1 = max(0, new_y1)
            dst_y2 = min(h, new_y1 + (src_y2 - src_y1))
            dst_x1 = max(0, new_x1)
            dst_x2 = min(w, new_x1 + (src_x2 - src_x1))
            
            sel_h_actual = min(dst_y2 - dst_y1, src_y2 - src_y1)
            sel_w_actual = min(dst_x2 - dst_x1, src_x2 - src_x1)
            
            if sel_h_actual > 0 and sel_w_actual > 0:
                new_mask[dst_y1:dst_y1+sel_h_actual, dst_x1:dst_x1+sel_w_actual] = \
                    self.mask[src_y1:src_y1+sel_h_actual, src_x1:src_x1+sel_w_actual]
        
        self.mask = new_mask
        self._update_bounds()
        return True
    
    # ========== SELECTION OPERATIONS (ADD/SUBTRACT/INTERSECT) ==========
    
    def add_to_selection(self, new_mask):
        """Add (union) a new mask to the existing selection"""
        if not self.has_selection():
            self.mask = new_mask.copy()
        else:
            # Union: combine both selections
            self.mask = self.mask | new_mask
        self._update_bounds()
    
    def subtract_from_selection(self, mask_to_remove):
        """Subtract (difference) a mask from the existing selection"""
        if not self.has_selection():
            return  # Nothing to subtract from
        # Difference: remove the second mask from the first
        self.mask = self.mask & ~mask_to_remove
        self._update_bounds()
    
    def intersect_selection(self, new_mask):
        """Intersect (AND) a new mask with the existing selection"""
        if not self.has_selection():
            return  # Nothing to intersect with
        # Intersection: only keep pixels that are in both
        self.mask = self.mask & new_mask
        self._update_bounds()
    
    def invert_selection(self, image_shape):
        """Invert the current selection"""
        h, w = image_shape[:2]
        if not self.has_selection():
            # Select all if nothing selected
            self.mask = np.ones((h, w), dtype=bool)
        else:
            # Invert the mask
            self.mask = ~self.mask
        self._update_bounds()
    
    # ========== CLIPBOARD OPERATIONS ==========
    
    def get_selected_content(self, image):
        """Extract the selected content from the image as a new image"""
        if not self.has_selection():
            return None
        
        bounds = self.get_selection_bounds()
        if not bounds:
            return None
        
        x1, y1, x2, y2 = bounds
        h, w = image.shape[:2]
        
        # Extract the region
        region = image[y1:y2, x1:x2].copy()
        
        # Apply mask to make non-selected pixels transparent
        mask_region = self.mask[y1:y2, x1:x2]
        
        # Ensure RGBA format
        if len(region.shape) == 2:
            region = np.dstack([region, region, region, np.ones_like(region) * 255])
        elif region.shape[2] == 3:
            region = np.dstack([region, np.ones((region.shape[0], region.shape[1]), dtype=np.uint8) * 255])
        
        # Apply mask to alpha channel
        region[:, :, 3] = np.where(mask_region, region[:, :, 3], 0)
        
        return region
    
    def paste_content(self, content, paste_x, paste_y, image_shape):
        """Create a selection mask for pasted content"""
        if content is None:
            return False
        
        h, w = image_shape[:2]
        ch, cw = content.shape[:2]
        
        # Clip to image bounds
        dst_x1 = max(0, paste_x)
        dst_y1 = max(0, paste_y)
        dst_x2 = min(w, paste_x + cw)
        dst_y2 = min(h, paste_y + ch)
        
        if dst_x2 <= dst_x1 or dst_y2 <= dst_y1:
            return False
        
        # Calculate source region
        src_x1 = dst_x1 - paste_x
        src_y1 = dst_y1 - paste_y
        src_x2 = src_x1 + (dst_x2 - dst_x1)
        src_y2 = src_y1 + (dst_y2 - dst_y1)
        
        # Create selection mask for the pasted region
        self.mask = np.zeros((h, w), dtype=bool)
        
        # Check if content has alpha channel to determine selection
        if len(content.shape) == 3 and content.shape[2] == 4:
            content_alpha = content[src_y1:src_y2, src_x1:src_x2, 3]
            self.mask[dst_y1:dst_y2, dst_x1:dst_x2] = content_alpha > 0
        else:
            # No alpha, select entire rectangle
            self.mask[dst_y1:dst_y2, dst_x1:dst_x2] = True
        
        self._update_bounds()
        return True

# Backwards compatibility alias
SelectionManager = SimpleSelectionManager