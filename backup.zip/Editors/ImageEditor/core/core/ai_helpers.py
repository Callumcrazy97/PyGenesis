"""
AI Helper Functions for Gemini Integration
Handles JSON parsing, region validation, caching, and frame generation
"""

import json
import re
import hashlib
import os
import numpy as np
from typing import Dict, List, Tuple, Optional, Any
from pathlib import Path
import cv2
from PIL import Image
import concurrent.futures
from threading import Lock

# Cache directory
CACHE_DIR = Path.home() / ".pygenesis" / "cache" / "ai"
CACHE_DIR.mkdir(parents=True, exist_ok=True)

# Thread-safe cache lock
_cache_lock = Lock()


def parse_json_response(response_text: str) -> Dict[str, Any]:
    """
    Parse JSON from Gemini response with fallback extraction.
    Handles cases where Gemini adds commentary before/after JSON.
    """
    try:
        # Try direct parsing first
        return json.loads(response_text)
    except json.JSONDecodeError:
        # Extract JSON from text using regex
        json_str = extract_json_from_text(response_text)
        try:
            return json.loads(json_str)
        except json.JSONDecodeError:
            # Last resort: try to find and parse any JSON-like structure
            json_str = extract_json_fallback(response_text)
            return json.loads(json_str)


def extract_json_from_text(text: str) -> str:
    """Extract JSON block from text that may contain commentary."""
    # Look for JSON object or array
    patterns = [
        r'\{[^{}]*(?:\{[^{}]*\}[^{}]*)*\}',  # Nested objects
        r'\[[^\[\]]*(?:\[[^\[\]]*\][^\[\]]*)*\]',  # Arrays
    ]
    
    for pattern in patterns:
        matches = re.findall(pattern, text, re.DOTALL)
        if matches:
            # Return the longest match (most likely to be complete)
            return max(matches, key=len)
    
    # Fallback: try to find content between { and }
    start = text.find('{')
    end = text.rfind('}')
    if start != -1 and end != -1 and end > start:
        return text[start:end+1]
    
    raise ValueError("No valid JSON found in response")


def extract_json_fallback(text: str) -> str:
    """Fallback JSON extraction using more aggressive pattern matching."""
    # Remove common prefixes/suffixes
    text = text.strip()
    
    # Remove markdown code blocks
    text = re.sub(r'```json\s*', '', text)
    text = re.sub(r'```\s*', '', text)
    
    # Find JSON boundaries
    start_idx = text.find('{')
    if start_idx == -1:
        start_idx = text.find('[')
    
    if start_idx == -1:
        raise ValueError("No JSON structure found")
    
    # Find matching closing brace/bracket
    depth = 0
    end_idx = start_idx
    
    for i in range(start_idx, len(text)):
        if text[i] in '{[':
            depth += 1
        elif text[i] in '}]':
            depth -= 1
            if depth == 0:
                end_idx = i
                break
    
    if depth != 0:
        raise ValueError("Unmatched JSON brackets")
    
    return text[start_idx:end_idx+1]


def clamp_region(region: Tuple[int, int, int, int], image_shape: Tuple[int, ...]) -> Tuple[int, int, int, int]:
    """
    Clamp region coordinates to image bounds.
    
    Args:
        region: (x, y, width, height)
        image_shape: (height, width) or (height, width, channels)
    
    Returns:
        Clamped (x, y, width, height)
    """
    x, y, w, h = region
    h_img, w_img = image_shape[:2]
    
    # Clamp position
    x = max(0, min(x, w_img - 1))
    y = max(0, min(y, h_img - 1))
    
    # Clamp size to fit within image
    w = min(w, w_img - x)
    h = min(h, h_img - y)
    
    # Ensure positive dimensions
    w = max(1, w)
    h = max(1, h)
    
    return x, y, w, h


def validate_region(region: Dict[str, Any], image_shape: Tuple[int, ...]) -> Optional[Tuple[int, int, int, int]]:
    """
    Validate and clamp a region dictionary.
    
    Args:
        region: Dict with 'x', 'y', 'w', 'h' or 'width', 'height'
        image_shape: Image dimensions
    
    Returns:
        Clamped (x, y, width, height) or None if invalid
    """
    try:
        x = int(region.get('x', 0))
        y = int(region.get('y', 0))
        w = int(region.get('w', region.get('width', 0)))
        h = int(region.get('h', region.get('height', 0)))
        
        if w <= 0 or h <= 0:
            return None
        
        return clamp_region((x, y, w, h), image_shape)
    except (ValueError, KeyError, TypeError):
        return None


def compute_frame_diff(base_image: np.ndarray, frame_image: np.ndarray, threshold: int = 10) -> Tuple[bool, float]:
    """
    Compute difference between base and frame image.
    
    Args:
        base_image: Base frame (RGBA numpy array)
        frame_image: Modified frame (RGBA numpy array)
        threshold: Minimum pixel difference to consider valid
    
    Returns:
        (is_valid, diff_score) - True if change is significant
    """
    if base_image.shape != frame_image.shape:
        return True, float('inf')  # Different sizes = valid change
    
    # Compute absolute difference
    diff = np.abs(frame_image.astype(np.int16) - base_image.astype(np.int16))
    total_diff = np.sum(diff)
    
    # Normalize by image size
    pixel_count = base_image.shape[0] * base_image.shape[1]
    diff_score = total_diff / (pixel_count * 255.0 * 4.0)  # Normalize to 0-1
    
    is_valid = total_diff >= threshold
    
    return is_valid, diff_score


def get_cache_key(prompt: str, theme: str, detail: int, animation_type: str = "", frame_count: int = 0) -> str:
    """Generate cache key from parameters."""
    key_string = f"{prompt}|{theme}|{detail}|{animation_type}|{frame_count}"
    return hashlib.md5(key_string.encode()).hexdigest()


def get_cached_response(cache_key: str) -> Optional[Dict[str, Any]]:
    """Retrieve cached Gemini response."""
    cache_file = CACHE_DIR / f"{cache_key}.json"
    
    if not cache_file.exists():
        return None
    
    try:
        with _cache_lock:
            with open(cache_file, 'r', encoding='utf-8') as f:
                return json.load(f)
    except (json.JSONDecodeError, IOError):
        return None


def cache_response(cache_key: str, response_data: Dict[str, Any]) -> None:
    """Cache Gemini response."""
    cache_file = CACHE_DIR / f"{cache_key}.json"
    
    try:
        with _cache_lock:
            with open(cache_file, 'w', encoding='utf-8') as f:
                json.dump(response_data, f, indent=2)
    except IOError:
        pass  # Cache failures shouldn't break the workflow


def move_region(image: np.ndarray, source_rect: Tuple[int, int, int, int], 
                target_rect: Tuple[int, int, int, int]) -> np.ndarray:
    """
    Move a region of pixels from source to target location.
    
    Args:
        image: RGBA numpy array
        source_rect: (x, y, width, height) of source region
        target_rect: (x, y, width, height) of target region
    
    Returns:
        Modified image
    """
    h, w = image.shape[:2]
    
    # Clamp regions
    src_x, src_y, src_w, src_h = clamp_region(source_rect, image.shape)
    tgt_x, tgt_y, tgt_w, tgt_h = clamp_region(target_rect, image.shape)
    
    # Ensure target size matches source (or use minimum)
    tgt_w = min(tgt_w, src_w)
    tgt_h = min(tgt_h, src_h)
    
    # Extract source region
    source_region = image[src_y:src_y+src_h, src_x:src_x+src_w].copy()
    
    # Resize if needed
    if (src_w, src_h) != (tgt_w, tgt_h):
        source_region = cv2.resize(source_region, (tgt_w, tgt_h), 
                                  interpolation=cv2.INTER_NEAREST)
    
    # Create result image
    result = image.copy()
    
    # Clear source region (make transparent)
    result[src_y:src_y+src_h, src_x:src_x+src_w] = [0, 0, 0, 0]
    
    # Paste at target (handle alpha blending)
    tgt_y_end = min(tgt_y + tgt_h, h)
    tgt_x_end = min(tgt_x + tgt_w, w)
    src_h_actual = tgt_y_end - tgt_y
    src_w_actual = tgt_x_end - tgt_x
    
    if src_h_actual > 0 and src_w_actual > 0:
        result[tgt_y:tgt_y_end, tgt_x:tgt_x_end] = source_region[:src_h_actual, :src_w_actual]
    
    return result


def modify_region(image: np.ndarray, region: Tuple[int, int, int, int], 
                  operation: str, params: Dict[str, Any]) -> np.ndarray:
    """
    Modify a region with transformation operations.
    
    Args:
        image: RGBA numpy array
        region: (x, y, width, height)
        operation: 'rotate', 'scale', 'flip_horizontal', 'flip_vertical'
        params: Operation-specific parameters
    
    Returns:
        Modified image
    """
    h, w = image.shape[:2]
    x, y, region_w, region_h = clamp_region(region, image.shape)
    
    # Extract region
    region_data = image[y:y+region_h, x:x+region_w].copy()
    
    if operation == 'rotate':
        angle = params.get('angle', 0)
        # Rotate around center
        center = (region_w // 2, region_h // 2)
        rotation_matrix = cv2.getRotationMatrix2D(center, angle, 1.0)
        rotated = cv2.warpAffine(region_data, rotation_matrix, 
                                 (region_w, region_h),
                                 flags=cv2.INTER_NEAREST,
                                 borderMode=cv2.BORDER_TRANSPARENT)
        region_data = rotated
    
    elif operation == 'scale':
        scale_x = params.get('scale_x', 1.0)
        scale_y = params.get('scale_y', 1.0)
        new_w = int(region_w * scale_x)
        new_h = int(region_h * scale_y)
        if new_w > 0 and new_h > 0:
            region_data = cv2.resize(region_data, (new_w, new_h),
                                    interpolation=cv2.INTER_NEAREST)
            # Update region size
            region_w, region_h = new_w, new_h
    
    elif operation == 'flip_horizontal':
        region_data = cv2.flip(region_data, 1)
    
    elif operation == 'flip_vertical':
        region_data = cv2.flip(region_data, 0)
    
    # Paste back (clamp to image bounds)
    result = image.copy()
    paste_h = min(region_h, h - y)
    paste_w = min(region_w, w - x)
    
    if paste_h > 0 and paste_w > 0:
        result[y:y+paste_h, x:x+paste_w] = region_data[:paste_h, :paste_w]
    
    return result


def paint_region(image: np.ndarray, region: Tuple[int, int, int, int], 
                 color: Tuple[int, int, int, int]) -> np.ndarray:
    """
    Paint a region with a specific color.
    
    Args:
        image: RGBA numpy array
        region: (x, y, width, height)
        color: (R, G, B, A) tuple
    
    Returns:
        Modified image
    """
    x, y, w, h = clamp_region(region, image.shape)
    result = image.copy()
    result[y:y+h, x:x+w] = color
    return result


def generate_frames_parallel(base_image: np.ndarray, 
                             change_instructions: List[Dict[str, Any]],
                             validate_diffs: bool = True,
                             diff_threshold: int = 10) -> List[np.ndarray]:
    """
    Generate frames in parallel using ThreadPoolExecutor.
    
    Args:
        base_image: Base frame image
        change_instructions: List of change dictionaries per frame
        validate_diffs: Whether to validate frame differences
        diff_threshold: Minimum difference threshold
    
    Returns:
        List of frame images
    """
    def generate_single_frame(frame_idx: int, changes: List[Dict[str, Any]]) -> Tuple[int, np.ndarray]:
        """Generate a single frame with its changes."""
        frame_image = base_image.copy()
        
        for change in changes:
            change_type = change.get('type', '')
            
            if change_type == 'move_region':
                source = validate_region(change.get('source', {}), base_image.shape)
                target = validate_region(change.get('target', {}), base_image.shape)
                if source and target:
                    frame_image = move_region(frame_image, source, target)
            
            elif change_type == 'modify_pixels':
                region = validate_region(change.get('region', {}), base_image.shape)
                if region:
                    operation = change.get('operation', '')
                    params = change.get('params', {})
                    frame_image = modify_region(frame_image, region, operation, params)
            
            elif change_type == 'paint_pixels':
                region = validate_region(change.get('region', {}), base_image.shape)
                if region:
                    color_tuple = tuple(change.get('color', [0, 0, 0, 255]))
                    frame_image = paint_region(frame_image, region, color_tuple)
        
        # Validate difference
        if validate_diffs:
            is_valid, diff_score = compute_frame_diff(base_image, frame_image, diff_threshold)
            if not is_valid:
                print(f"Warning: Frame {frame_idx} has minimal changes (diff={diff_score:.4f})")
        
        return frame_idx, frame_image
    
    # Generate frames in parallel
    frames = [None] * len(change_instructions)
    
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as executor:
        futures = []
        for i, changes in enumerate(change_instructions):
            future = executor.submit(generate_single_frame, i, changes)
            futures.append(future)
        
        for future in concurrent.futures.as_completed(futures):
            frame_idx, frame_image = future.result()
            frames[frame_idx] = frame_image
    
    return frames


def apply_cumulative_changes(base_image: np.ndarray, 
                            all_changes: List[List[Dict[str, Any]]]) -> List[np.ndarray]:
    """
    Apply cumulative changes (pose-state model).
    Each frame builds on the previous frame's state.
    
    Args:
        base_image: Base frame
        all_changes: List of change lists, one per frame
    
    Returns:
        List of frame images
    """
    frames = []
    current_state = base_image.copy()
    
    for frame_idx, changes in enumerate(all_changes):
        # Apply changes to current state
        for change in changes:
            change_type = change.get('type', '')
            
            if change_type == 'move_region':
                source = validate_region(change.get('source', {}), current_state.shape)
                target = validate_region(change.get('target', {}), current_state.shape)
                if source and target:
                    current_state = move_region(current_state, source, target)
            
            elif change_type == 'modify_pixels':
                region = validate_region(change.get('region', {}), current_state.shape)
                if region:
                    operation = change.get('operation', '')
                    params = change.get('params', {})
                    current_state = modify_region(current_state, region, operation, params)
            
            elif change_type == 'paint_pixels':
                region = validate_region(change.get('region', {}), current_state.shape)
                if region:
                    color_tuple = tuple(change.get('color', [0, 0, 0, 255]))
                    current_state = paint_region(current_state, region, color_tuple)
        
        frames.append(current_state.copy())
    
    return frames

