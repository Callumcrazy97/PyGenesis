import json
import os
import numpy as np
from PIL import Image
from PySide6.QtGui import QImage, QColor
from PySide6.QtCore import QBuffer, QIODevice
import io
import base64
from typing import Dict, List, Any, Optional

class PgSpriteIO:
    """Handles import and export of .PgSprite files"""
    
    def __init__(self):
        self.version = "1.0"
        self.magic_header = "PgSprite"
    
    def export_pgsprite(self, filepath: str, state) -> bool:
        """Export current project to .PgSprite format"""
        try:
            # Collect all data
            data = {
                "header": {
                    "magic": self.magic_header,
                    "version": self.version,
                    "width": state.width,
                    "height": state.height
                },
                "layers": self._export_layers(state),
                "atlas": self._export_atlas(state),
                "settings": self._export_settings(state)
            }
            
            # Write to file
            with open(filepath, 'w') as f:
                json.dump(data, f, indent=2)
            
            return True
            
        except Exception as e:
            print(f"Error exporting PgSprite: {e}")
            return False
    
    def import_pgsprite(self, filepath: str, state) -> bool:
        """Import project from .PgSprite format"""
        try:
            with open(filepath, 'r') as f:
                data = json.load(f)
            
            # Validate header
            if data.get("header", {}).get("magic") != self.magic_header:
                raise ValueError("Invalid PgSprite file")
            
            # Import data
            self._import_layers(data.get("layers", []), state)
            self._import_atlas(data.get("atlas", {}), state)
            self._import_settings(data.get("settings", {}), state)
            
            return True
            
        except Exception as e:
            print(f"Error importing PgSprite: {e}")
            return False
    
    def _export_layers(self, state) -> List[Dict]:
        """Export layer data"""
        layers_data = []
        layer_manager = state.layer_manager
        
        for layer in layer_manager.layers:
            layer_data = {
                "name": layer.name,
                "visible": layer.visible,
                "locked": layer.locked,
                "depth": layer.depth,
                "frames": []
            }
            
            # Export frames
            for i, frame in enumerate(layer.frames):
                frame_data = {
                    "index": i,
                    "image": self._image_to_base64(frame.image),
                    "tags": getattr(frame, 'tags', []),
                    "color_code": getattr(frame, 'color_code', None)
                }
                layer_data["frames"].append(frame_data)
            
            layers_data.append(layer_data)
        
        return layers_data
    
    def _import_layers(self, layers_data: List[Dict], state):
        """Import layer data"""
        layer_manager = state.layer_manager
        
        # Clear existing layers
        layer_manager.layers.clear()
        
        for layer_data in layers_data:
            # Create layer
            layer = layer_manager.add_layer(layer_data["name"])
            layer.visible = layer_data.get("visible", True)
            layer.locked = layer_data.get("locked", False)
            layer.depth = layer_data.get("depth", 0)
            
            # Import frames
            for frame_data in layer_data.get("frames", []):
                frame_idx = frame_data["index"]
                while len(layer.frames) <= frame_idx:
                    layer.add_frame(state.width, state.height, state)
                
                frame = layer.frames[frame_idx]
                frame.image = self._base64_to_image(frame_data["image"])
                frame.tags = frame_data.get("tags", [])
                frame.color_code = frame_data.get("color_code", None)
    
    def _export_atlas(self, state) -> Dict:
        """Export atlas data"""
        atlas_manager = state.atlas_manager
        return {
            "grid_size": atlas_manager.grid_size,
            "num_frames": atlas_manager.num_frames,
            "cells": [
                {
                    "x": cell.x,
                    "y": cell.y,
                    "width": cell.width,
                    "height": cell.height,
                    "name": cell.name,
                    "primary_color": cell.primary_color,
                    "secondary_color": cell.secondary_color,
                    "animated": cell.animated,
                    "style": cell.style,
                    "block_size": cell.block_size,
                    "ores": cell.ores,
                    "num_ores": cell.num_ores,
                    "ore_color": cell.ore_color,
                    "top_side": cell.top_side,
                    "border": cell.border,
                    "top_color": cell.top_color,
                    "side_color": cell.side_color,
                    "frames": [self._qimage_to_base64(frame) for frame in cell.frames]
                }
                for cell in atlas_manager.grid_cells
            ]
        }
    
    def _import_atlas(self, atlas_data: Dict, state):
        """Import atlas data"""
        atlas_manager = state.atlas_manager
        
        atlas_manager.grid_size = atlas_data.get("grid_size", 32)
        atlas_manager.num_frames = atlas_data.get("num_frames", 1)
        
        # Clear existing cells
        atlas_manager.grid_cells.clear()
        
        for cell_data in atlas_data.get("cells", []):
            cell = atlas_manager.add_cell(cell_data["name"])
            if cell:
                cell.x = cell_data["x"]
                cell.y = cell_data["y"]
                cell.width = cell_data["width"]
                cell.height = cell_data["height"]
                cell.primary_color = cell_data.get("primary_color", "#8B4513")
                cell.secondary_color = cell_data.get("secondary_color", "#A0522D")
                cell.animated = cell_data.get("animated", False)
                cell.style = cell_data.get("style", "None")
                cell.block_size = cell_data.get("block_size", 8)
                cell.ores = cell_data.get("ores", False)
                cell.num_ores = cell_data.get("num_ores", 2)
                cell.ore_color = cell_data.get("ore_color", "#FFD700")
                cell.top_side = cell_data.get("top_side", False)
                cell.border = cell_data.get("border", 20)
                cell.top_color = cell_data.get("top_color", "#FFFFFF")
                cell.side_color = cell_data.get("side_color", "#AAAAAA")
                
                # Import frames
                cell.frames = [self._base64_to_qimage(frame_data) for frame_data in cell_data.get("frames", [])]
    
    def _export_settings(self, state) -> Dict:
        """Export settings data"""
        return {
            "current_radius": state.current_radius,
            "current_left_color": state.current_left_color,
            "current_right_color": state.current_right_color,
            "current_tool": state.current_tool,
            "shape_filled": state.shape_filled,
            "grid_visible": state.grid_visible,
            "grid_size": state.grid_size,
            "grid_color": state.grid_color,
            "grid_rotation": state.grid_rotation,
            "grid_snap": state.grid_snap,
            "global_grid": state.global_grid
        }
    
    def _import_settings(self, settings_data: Dict, state):
        """Import settings data"""
        state.current_radius = settings_data.get("current_radius", 8)
        state.current_left_color = settings_data.get("current_left_color", "#000000")
        state.current_right_color = settings_data.get("current_right_color", "#ffffff")
        state.current_tool = settings_data.get("current_tool", "brush")
        state.shape_filled = settings_data.get("shape_filled", True)
        state.grid_visible = settings_data.get("grid_visible", False)
        state.grid_size = settings_data.get("grid_size", 16)
        state.grid_color = settings_data.get("grid_color", "#888888")
        state.grid_rotation = settings_data.get("grid_rotation", 0)
        state.grid_snap = settings_data.get("grid_snap", False)
        state.global_grid = settings_data.get("global_grid", False)
    
    def _image_to_base64(self, image: np.ndarray) -> str:
        """Convert numpy image to base64 string"""
        if image is None:
            return ""
        
        # Convert numpy array to PIL Image
        pil_image = Image.fromarray(image)
        
        # Save to bytes
        buffer = io.BytesIO()
        pil_image.save(buffer, format='PNG')
        
        # Convert to base64
        return base64.b64encode(buffer.getvalue()).decode('utf-8')
    
    def _base64_to_image(self, base64_str: str) -> np.ndarray:
        """Convert base64 string to numpy image"""
        if not base64_str:
            return None
        
        # Decode base64
        image_data = base64.b64decode(base64_str)
        
        # Load with PIL
        pil_image = Image.open(io.BytesIO(image_data))
        
        # Convert to numpy array
        return np.array(pil_image)
    
    def _qimage_to_base64(self, qimage: QImage) -> str:
        """Convert QImage to base64 string"""
        if qimage is None:
            return ""
        
        # Convert QImage to bytes
        buffer = QBuffer()
        buffer.open(QIODevice.WriteOnly)
        qimage.save(buffer, "PNG")
        
        # Convert to base64
        return base64.b64encode(buffer.data()).decode('utf-8')
    
    def _base64_to_qimage(self, base64_str: str) -> QImage:
        """Convert base64 string to QImage"""
        if not base64_str:
            return None
        
        # Decode base64
        image_data = base64.b64decode(base64_str)
        
        # Create QImage from bytes
        qimage = QImage()
        qimage.loadFromData(image_data)
        
        return qimage

# Global instance
pgsprite_io = PgSpriteIO() 