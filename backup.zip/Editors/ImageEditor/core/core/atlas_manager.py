import copy
import numpy as np
from PySide6.QtGui import QImage, QColor
from core.texture_utils import generate_block_texture_qimage

class AtlasCell:
    """Represents a single cell in the texture atlas grid."""
    
    def __init__(self, x, y, width, height, name="Grid"):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.name = name
        self.frames = []  # List of QImage objects for animation
        self.primary_color = "#8B4513"
        self.secondary_color = "#A0522D"
        self.animated = False
        self.style = "None"
        self.block_size = 8  # Default block size within each cell
        self.ores = False
        self.num_ores = 2
        self.ore_color = "#FFD700"
        self.top_side = False
        self.border = 20
        self.top_color = "#FFFFFF"
        self.side_color = "#AAAAAA"
        self._individual_settings = False  # Track if cell has individual settings

class AtlasManager:
    """Manages texture atlas state and operations."""
    
    def __init__(self, state):
        self.state = state
        self.grid_cells = []
        self.grid_size = 32
        self.num_frames = 1
        self.canvas_width = state.width
        self.canvas_height = state.height
        self._undo_stack = []
        self._redo_stack = []
        self.max_undo = 10
        
        # Initialize with default grid if canvas is large enough
        self._create_default_grid()
    
    def _create_default_grid(self):
        """Create a default grid layout based on canvas size."""
        # Only create a default grid if the canvas is large enough
        if self.canvas_width >= 64 and self.canvas_height >= 64:
            # Create a simple 2x2 grid as default
            grid_positions = [
                (0, 0), (self.grid_size, 0),
                (0, self.grid_size), (self.grid_size, self.grid_size)
            ]
            
            for i, (x, y) in enumerate(grid_positions):
                if x + self.grid_size <= self.canvas_width and y + self.grid_size <= self.canvas_height:
                    cell = AtlasCell(x, y, self.grid_size, self.grid_size, f"Grid {i+1}")
                    self.grid_cells.append(cell)
    
    def set_canvas_size(self, width, height):
        """Update canvas size and recalculate grid layout."""
        self.canvas_width = width
        self.canvas_height = height
        self._recalculate_grid_layout()
    
    def _recalculate_grid_layout(self):
        """Recalculate grid positions based on new canvas size."""
        grids_h = self.canvas_width // self.grid_size
        grids_v = self.canvas_height // self.grid_size
        total_slots = grids_h * grids_v
        
        # Remove cells that no longer fit
        self.grid_cells = self.grid_cells[:total_slots]
        
        # Update positions for remaining cells
        for i, cell in enumerate(self.grid_cells):
            row = i // grids_h
            col = i % grids_h
            cell.x = col * self.grid_size
            cell.y = row * self.grid_size
            cell.width = self.grid_size
            cell.height = self.grid_size
    
    def set_grid_size(self, size):
        """Set grid size and recalculate layout."""
        self.grid_size = size
        self._recalculate_grid_layout()
    
    def add_cell(self, name=None):
        """Add a new cell to the atlas."""
        grids_h = self.canvas_width // self.grid_size
        grids_v = self.canvas_height // self.grid_size
        total_slots = grids_h * grids_v
        
        if len(self.grid_cells) >= total_slots:
            return False  # No space available
        
        idx = len(self.grid_cells)
        row = idx // grids_h
        col = idx % grids_h
        x = col * self.grid_size
        y = row * self.grid_size
        
        cell = AtlasCell(x, y, self.grid_size, self.grid_size, name or f"Grid {idx+1}")
        self.grid_cells.append(cell)
        return True
    
    def remove_cell(self, index):
        """Remove a cell at the specified index."""
        if 0 <= index < len(self.grid_cells):
            del self.grid_cells[index]
            self._recalculate_grid_layout()
            return True
        return False
    
    def _generate_texture_using_2d_creation_logic(self, cell, frame_index=0):
        """Generate texture using 2D Texture Creation's proven logic."""
        from core.texture_utils import generate_block_texture_qimage
        
        # Map style names to texture generation parameters
        style_mapping = {
            'Air': 'None',  # Air is invisible
            'None': 'None',
            'Water': 'Water',
            'Lava': 'Lava',
            'Fire': 'Fire',
            'Smoke': 'Smoke',
            'Fog': 'Fog',
            'Crystal': 'Crystal',
            'Wind': 'Wind',
            'Portal': 'Portal'
        }
        
        # Get the mapped style, default to 'None' if not found
        mapped_style = style_mapping.get(cell.style, 'None')
        
        # For Air cells, return transparent texture
        if cell.style == 'Air':
            texture = QImage(cell.width, cell.height, QImage.Format_RGBA8888)
            texture.fill(QColor(0, 0, 0, 0))  # Transparent
            return texture
        
        # Use 2D Texture Creation's proven logic with proper animation parameters
        # Only use frame_index if the cell is animated
        actual_frame_index = frame_index if cell.animated else 0
        
        # Calculate animation time using 2D Texture Creation's speed multipliers
        speed_multipliers = {
            1: 0.5, 2: 0.8, 3: 1.0, 4: 1.5, 5: 2.0,
            6: 3.0, 7: 4.0, 8: 5.0, 9: 7.0, 10: 10.0
        }
        animation_speed = 5  # Default speed for atlas cells
        time_step = speed_multipliers.get(animation_speed, 2.0)
        animation_time = actual_frame_index * time_step
        
        # Generate texture using 2D Texture Creation's exact logic
        texture = generate_block_texture_qimage(
            cell.width, cell.height,
            [cell.primary_color, cell.secondary_color],
            cell.block_size,  # Use cell's block_size property
            255,  # Opacity - force 100% like 2D Texture Creation
            mapped_style,
            None,  # Style params - None like 2D Texture Creation
            animation_time,  # Use animation_time like 2D Texture Creation
            42  # Default seed
        )
        
        return texture

    def generate_cell_texture(self, cell_index, frame_index=0):
        """Generate texture for a specific cell using 2D Texture Creation logic."""
        if cell_index >= len(self.grid_cells):
            return None
            
        cell = self.grid_cells[cell_index]
        
        # Use 2D Texture Creation's proven effect generation logic
        return self._generate_texture_using_2d_creation_logic(cell, frame_index)
    
    def generate_atlas_image(self, frame_index=0):
        """Generate the complete atlas image for a specific frame."""
        if not self.grid_cells:
            return None
        
        # Create base image
        atlas_img = QImage(self.canvas_width, self.canvas_height, QImage.Format_RGBA8888)
        atlas_img.fill(QColor(0, 0, 0, 0))  # Transparent background
        
        # Composite all cells
        for cell in self.grid_cells:
            # Determine frame index for this cell based on its animation setting
            if cell.animated:
                # Animated cells use the frame index
                cell_frame_index = frame_index
            else:
                # Static cells always use frame 0
                cell_frame_index = 0
            
            texture = self.generate_cell_texture(self.grid_cells.index(cell), cell_frame_index)
            if texture:
                # Convert QImage to numpy for compositing
                texture_array = self._qimage_to_numpy(texture)
                
                # Ensure we don't go out of bounds
                end_x = min(cell.x + cell.width, self.canvas_width)
                end_y = min(cell.y + cell.height, self.canvas_height)
                
                # Composite the texture onto the atlas
                for y in range(cell.y, end_y):
                    for x in range(cell.x, end_x):
                        if (x - cell.x < texture_array.shape[1] and 
                            y - cell.y < texture_array.shape[0]):
                            atlas_img.setPixel(x, y, self._numpy_to_qcolor(
                                texture_array[y - cell.y, x - cell.x]
                            ))
        
        return atlas_img
    
    def generate_all_frames(self):
        """Generate all animation frames for the atlas."""
        frames = []
        for frame_index in range(self.num_frames):
            frame_image = self.generate_atlas_image(frame_index)
            if frame_image:
                frames.append(frame_image)
        return frames
    
    def get_frame_count(self):
        """Get the number of animation frames."""
        return self.num_frames
    
    def _qimage_to_numpy(self, qimage):
        """Convert QImage to numpy array."""
        from PIL import Image
        import tempfile
        import os
        
        # Save QImage to temporary file
        with tempfile.NamedTemporaryFile(suffix='.png', delete=False) as tmp_file:
            qimage.save(tmp_file.name, 'PNG')
            tmp_path = tmp_file.name
        
        try:
            # Load with PIL and convert to numpy
            pil_image = Image.open(tmp_path)
            arr = np.array(pil_image)
            return arr
        finally:
            # Clean up temporary file
            if os.path.exists(tmp_path):
                os.unlink(tmp_path)
    
    def _numpy_to_qcolor(self, pixel):
        """Convert numpy pixel to QColor."""
        r, g, b, a = pixel
        return QColor(r, g, b, a).rgba()
    
    def push_undo(self):
        """Save current state for undo."""
        state_copy = {
            'grid_cells': copy.deepcopy(self.grid_cells),
            'grid_size': self.grid_size,
            'num_frames': self.num_frames
        }
        self._undo_stack.append(state_copy)
        if len(self._undo_stack) > self.max_undo:
            self._undo_stack.pop(0)
        self._redo_stack.clear()
    
    def undo(self):
        """Undo the last operation."""
        if not self._undo_stack:
            return False
        
        # Save current state to redo stack
        current_state = {
            'grid_cells': copy.deepcopy(self.grid_cells),
            'grid_size': self.grid_size,
            'num_frames': self.num_frames
        }
        self._redo_stack.append(current_state)
        
        # Restore from undo stack
        state = self._undo_stack.pop()
        self.grid_cells = state['grid_cells']
        self.grid_size = state['grid_size']
        self.num_frames = state['num_frames']
        
        return True
    
    def redo(self):
        """Redo the last undone operation."""
        if not self._redo_stack:
            return False
        
        # Save current state to undo stack
        current_state = {
            'grid_cells': copy.deepcopy(self.grid_cells),
            'grid_size': self.grid_size,
            'num_frames': self.num_frames
        }
        self._undo_stack.append(current_state)
        
        # Restore from redo stack
        state = self._redo_stack.pop()
        self.grid_cells = state['grid_cells']
        self.grid_size = state['grid_size']
        self.num_frames = state['num_frames']
        
        return True
    
    def clear_history(self):
        """Clear undo/redo history."""
        self._undo_stack.clear()
        self._redo_stack.clear()
    
    def get_atlas_state(self):
        """Get current atlas state for serialization."""
        return {
            'grid_cells': [
                {
                    'x': cell.x,
                    'y': cell.y,
                    'width': cell.width,
                    'height': cell.height,
                    'name': cell.name,
                    'primary_color': cell.primary_color,
                    'secondary_color': cell.secondary_color,
                    'animated': cell.animated,
                    'style': cell.style,
                    'block_size': cell.block_size,
                    'ores': cell.ores,
                    'num_ores': cell.num_ores,
                    'ore_color': cell.ore_color,
                    'top_side': cell.top_side,
                    'border': cell.border,
                    'top_color': cell.top_color,
                    'side_color': cell.side_color,
                    '_individual_settings': getattr(cell, '_individual_settings', False)
                }
                for cell in self.grid_cells
            ],
            'grid_size': self.grid_size,
            'num_frames': self.num_frames
        }
    
    def set_atlas_state(self, state):
        """Set atlas state from serialized data."""
        self.grid_cells = []
        for cell_data in state.get('grid_cells', []):
            cell = AtlasCell(
                cell_data['x'],
                cell_data['y'],
                cell_data['width'],
                cell_data['height'],
                cell_data['name']
            )
            cell.primary_color = cell_data.get('primary_color', "#8B4513")
            cell.secondary_color = cell_data.get('secondary_color', "#A0522D")
            cell.animated = cell_data.get('animated', False)
            cell.style = cell_data.get('style', 'None')
            cell.block_size = cell_data.get('block_size', 8)
            cell.ores = cell_data.get('ores', False)
            cell.num_ores = cell_data.get('num_ores', 2)
            cell.ore_color = cell_data.get('ore_color', "#FFD700")
            cell.top_side = cell_data.get('top_side', False)
            cell.border = cell_data.get('border', 20)
            cell.top_color = cell_data.get('top_color', "#FFFFFF")
            cell.side_color = cell_data.get('side_color', "#AAAAAA")
            cell._individual_settings = cell_data.get('_individual_settings', False)
            self.grid_cells.append(cell)
        
        self.grid_size = state.get('grid_size', 32)
        self.num_frames = state.get('num_frames', 1) 