"""
Admin Elevation Helper for Windows
Handles requesting admin privileges for package installation
"""

import sys
import os
import subprocess
import ctypes
import tempfile
from pathlib import Path


def is_admin():
    """Check if the current process is running with admin privileges."""
    try:
        return ctypes.windll.shell32.IsUserAnAdmin() != 0
    except:
        return False


def run_pip_with_admin(python_exe, package_name, venv_manager=None):
    """
    Run pip install with admin elevation using PowerShell.
    
    Args:
        python_exe: Path to Python executable
        package_name: Package to install
        venv_manager: VenvManager instance (optional)
    
    Returns:
        subprocess.CompletedProcess
    """
    if os.name != 'nt':
        # Not Windows, run normally
        return subprocess.run(
            [python_exe, "-m", "pip", "install", "--no-cache-dir", package_name],
            capture_output=True,
            text=True,
            check=True
        )
    
    # If already admin, run directly
    if is_admin():
        return subprocess.run(
            [python_exe, "-m", "pip", "install", "--no-cache-dir", package_name],
            capture_output=True,
            text=True,
            check=True
        )
    
    # Get absolute paths
    python_exe = str(Path(python_exe).resolve())
    python_dir = str(Path(python_exe).parent)
    
    # Escape paths for PowerShell (double backslashes)
    python_exe_escaped = python_exe.replace('\\', '\\\\').replace('"', '\\"')
    python_dir_escaped = python_dir.replace('\\', '\\\\').replace('"', '\\"')
    package_escaped = package_name.replace('"', '\\"')
    
    # Create a temporary batch script that runs pip install
    # This matches exactly what works in terminal
    batch_content = f'''@echo off
cd /d "{python_dir}"
"{python_exe}" -m pip install --no-cache-dir {package_name}
exit /b %ERRORLEVEL%
'''
    
    # Write batch script to temp file
    with tempfile.NamedTemporaryFile(mode='w', suffix='.bat', delete=False, encoding='utf-8') as f:
        script_path = f.name
        f.write(batch_content)
    
    try:
        # Use PowerShell to run batch script with elevation
        # This will show UAC prompt to user
        # Escape the script path for PowerShell
        script_path_escaped = script_path.replace('\\', '\\\\').replace('"', '\\"')
        
        # Use Start-Process with -Verb RunAs to request elevation
        # -Wait ensures we wait for completion
        # -PassThru returns the process object so we can get exit code
        ps_command = f'''
$script = "{script_path_escaped}"
try {{
    $proc = Start-Process -FilePath $script -Verb RunAs -Wait -PassThru -WindowStyle Hidden
    if ($proc) {{
        exit $proc.ExitCode
    }} else {{
        exit 1
    }}
}} catch {{
    Write-Host "Error: $_"
    exit 1
}}
'''
        
        # Run PowerShell command
        result = subprocess.run(
            ["powershell", "-NoProfile", "-Command", ps_command],
            capture_output=True,
            text=True,
            check=False,
            timeout=600  # 10 minute timeout
        )
        
        # Check if elevation was successful
        if result.returncode == 0:
            # Success - verify installation by trying to import
            import importlib
            importlib.invalidate_caches()
            
            # Return success
            return subprocess.CompletedProcess(
                [python_exe, "-m", "pip", "install", package_name],
                0,
                "Installation completed with admin privileges",
                ""
            )
        else:
            # Elevation failed or installation failed
            error_msg = result.stderr or result.stdout or "Unknown error"
            # Provide more helpful error message
            if "Access is denied" in error_msg or "User cancelled" in error_msg or "denied" in error_msg.lower():
                raise Exception(
                    f"Admin elevation was cancelled or denied.\n\n"
                    f"Please allow the UAC prompt when it appears, or run PyGenesis as administrator.\n\n"
                    f"Alternatively, you can install manually in terminal:\n"
                    f'pip install {package_name}'
                )
            raise subprocess.CalledProcessError(
                result.returncode,
                [python_exe, "-m", "pip", "install", package_name],
                result.stdout,
                error_msg
            )
    except subprocess.TimeoutExpired:
        raise Exception("Admin elevation timed out. The installation may still be running.")
    finally:
        # Clean up temp script
        try:
            if os.path.exists(script_path):
                # Wait a bit before deleting (Windows may still have file handle)
                import time
                time.sleep(0.5)
                try:
                    os.unlink(script_path)
                except:
                    # If we can't delete, that's okay - it's in temp directory
                    pass
        except:
            pass

