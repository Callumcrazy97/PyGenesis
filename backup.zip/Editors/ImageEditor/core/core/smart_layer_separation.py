"""
Smart Layer Separation System
Detects and tracks objects across frames, moving them to separate layers with gap filling
"""

import numpy as np
from PySide6.QtCore import Qt
from PySide6.QtGui import QColor
import cv2

try:
    CV2_AVAILABLE = True
except ImportError:
    CV2_AVAILABLE = False


class SmartLayerSeparator:
    """Detects and separates objects into their own layers with frame tracking"""
    
    def __init__(self):
        self.template = None  # Template image for tracking
        self.template_bounds = None  # Bounds of template in original image
        self.tracking_method = 'template_matching'  # 'template_matching' or 'optical_flow'
    
    def detect_object_in_selection(self, image, selection_mask):
        """Extract object from selection to use as template for tracking"""
        if not CV2_AVAILABLE:
            return None
        
        # Extract the selected region
        bounds = self._get_bounds_from_mask(selection_mask)
        if not bounds:
            return None
        
        x1, y1, x2, y2 = bounds
        
        # Extract template (selected region)
        template = image[y1:y2, x1:x2].copy()
        
        # Create mask for template (only selected pixels)
        template_mask = selection_mask[y1:y2, x1:x2].copy()
        
        # Apply mask to template (set non-selected pixels to transparent)
        if len(template.shape) == 3:
            if template.shape[2] == 4:  # RGBA
                template[:, :, 3] = template_mask.astype(np.uint8) * 255
            else:  # RGB
                # Convert to RGBA
                template_rgba = np.zeros((template.shape[0], template.shape[1], 4), dtype=np.uint8)
                template_rgba[:, :, :3] = template
                template_rgba[:, :, 3] = template_mask.astype(np.uint8) * 255
                template = template_rgba
        
        self.template = template
        self.template_bounds = bounds
        
        return template
    
    def track_object_in_frame(self, frame_image, previous_position=None):
        """Track the object in a new frame using template matching"""
        if not CV2_AVAILABLE or self.template is None:
            return None
        
        if self.tracking_method == 'template_matching':
            return self._track_with_template_matching(frame_image, previous_position)
        elif self.tracking_method == 'optical_flow':
            return self._track_with_optical_flow(frame_image, previous_position)
        
        return None
    
    def _track_with_template_matching(self, frame_image, previous_position=None):
        """Track object using template matching"""
        if len(self.template.shape) == 3 and self.template.shape[2] == 4:
            # Use alpha channel as mask
            template_rgb = self.template[:, :, :3]
            template_mask = self.template[:, :, 3] > 128
        else:
            template_rgb = self.template
            template_mask = None
        
        # Convert to grayscale for matching
        if len(template_rgb.shape) == 3:
            template_gray = cv2.cvtColor(template_rgb, cv2.COLOR_RGB2GRAY)
        else:
            template_gray = template_rgb
        
        if len(frame_image.shape) == 3:
            frame_gray = cv2.cvtColor(frame_image[:, :, :3], cv2.COLOR_RGB2GRAY)
        else:
            frame_gray = frame_image
        
        # Search area - if previous position known, search nearby
        if previous_position:
            x, y, w, h = previous_position
            # Expand search area
            search_margin = 50
            search_x1 = max(0, x - search_margin)
            search_y1 = max(0, y - search_margin)
            search_x2 = min(frame_gray.shape[1], x + w + search_margin)
            search_y2 = min(frame_gray.shape[0], y + h + search_margin)
            search_area = frame_gray[search_y1:search_y2, search_x1:search_x2]
        else:
            search_area = frame_gray
            search_x1 = 0
            search_y1 = 0
        
        # Template matching
        if template_mask is not None:
            result = cv2.matchTemplate(search_area, template_gray, cv2.TM_CCOEFF_NORMED, mask=template_mask)
        else:
            result = cv2.matchTemplate(search_area, template_gray, cv2.TM_CCOEFF_NORMED)
        
        # Find best match
        min_val, max_val, min_loc, max_loc = cv2.minMaxLoc(result)
        
        if max_val > 0.5:  # Confidence threshold
            match_x = max_loc[0] + search_x1
            match_y = max_loc[1] + search_y1
            h, w = template_gray.shape[:2]
            return (match_x, match_y, w, h, max_val)
        
        return None
    
    def _track_with_optical_flow(self, frame_image, previous_position=None):
        """Track object using optical flow (for moving objects)"""
        # This would use Lucas-Kanade or Farneback optical flow
        # For now, fallback to template matching
        return self._track_with_template_matching(frame_image, previous_position)
    
    def extract_object_from_frame(self, frame_image, position):
        """Extract the object from frame at given position"""
        if position is None:
            return None, None
        
        x, y, w, h = position[:4]
        
        # Extract region
        obj_image = frame_image[y:y+h, x:x+w].copy()
        
        # Create mask (use template mask if available)
        if self.template is not None and len(self.template.shape) == 3 and self.template.shape[2] == 4:
            # Resize template mask to match
            template_mask = self.template[:, :, 3] > 128
            if template_mask.shape != (h, w):
                template_mask = cv2.resize(template_mask.astype(np.uint8), (w, h), interpolation=cv2.INTER_NEAREST).astype(bool)
            obj_mask = template_mask
        else:
            # Create rectangular mask
            obj_mask = np.ones((h, w), dtype=bool)
        
        return obj_image, obj_mask
    
    def fill_gap_in_frame(self, frame_image, mask, method='inpaint'):
        """Fill the gap left by removing an object"""
        if not CV2_AVAILABLE:
            return frame_image
        
        if method == 'inpaint':
            # Use OpenCV inpainting
            if len(frame_image.shape) == 3:
                # Convert to BGR for inpainting
                frame_bgr = cv2.cvtColor(frame_image[:, :, :3], cv2.COLOR_RGB2BGR)
                mask_uint8 = (mask * 255).astype(np.uint8)
                inpainted = cv2.inpaint(frame_bgr, mask_uint8, 3, cv2.INPAINT_TELEA)
                # Convert back to RGB
                inpainted_rgb = cv2.cvtColor(inpainted, cv2.COLOR_BGR2RGB)
                
                # Preserve alpha if present
                if frame_image.shape[2] == 4:
                    result = np.zeros_like(frame_image)
                    result[:, :, :3] = inpainted_rgb
                    result[:, :, 3] = frame_image[:, :, 3]
                    return result
                return inpainted_rgb
        elif method == 'extend':
            # Extend surrounding pixels (simple approach)
            # This is a placeholder - could implement edge extension
            return frame_image
        
        return frame_image
    
    def _get_bounds_from_mask(self, mask):
        """Get bounding box from boolean mask"""
        if mask is None or not np.any(mask):
            return None
        
        coords = np.where(mask)
        if len(coords[0]) > 0:
            y1, y2 = coords[0].min(), coords[0].max()
            x1, x2 = coords[1].min(), coords[1].max()
            return (x1, y1, x2 + 1, y2 + 1)
        return None

