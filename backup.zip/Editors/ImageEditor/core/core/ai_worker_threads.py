"""
Worker threads for AI operations (background processing)
"""

from PySide6.QtCore import QThread, Signal
import numpy as np
from typing import Optional, Dict, Any, List, Tuple

from core.gemini_client import GeminiClient
from core.ai_helpers import (
    generate_frames_parallel, apply_cumulative_changes,
    compute_frame_diff
)


class BaseImageWorkerThread(QThread):
    """Worker thread for generating base image."""
    
    progress_updated = Signal(str, int)  # message, percentage
    finished = Signal()
    error_occurred = Signal(str)
    
    def __init__(self, gemini_client: GeminiClient, prompt: str, theme: str, 
                 detail: int, size: Tuple[int, int], use_cache: bool = True):
        super().__init__()
        self.gemini_client = gemini_client
        self.prompt = prompt
        self.theme = theme
        self.detail = detail
        self.size = size
        self.use_cache = use_cache
        self.result = None
    
    def run(self):
        """Execute base image generation."""
        try:
            self.progress_updated.emit("Generating base sprite with Gemini...", 10)
            
            base_image = self.gemini_client.generate_base_image(
                self.prompt, self.theme, self.detail, self.size, self.use_cache
            )
            
            if base_image is None:
                self.error_occurred.emit("Failed to generate base image")
                return
            
            self.progress_updated.emit("Base image generated successfully", 100)
            self.result = base_image
            self.finished.emit()
            
        except Exception as e:
            self.error_occurred.emit(f"Error generating base image: {str(e)}")


class AnimationWorkerThread(QThread):
    """Worker thread for generating animation frames."""
    
    progress_updated = Signal(str, int)  # message, percentage
    finished = Signal()
    error_occurred = Signal(str)
    
    def __init__(self, gemini_client: GeminiClient, base_image: np.ndarray,
                 animation_type: str, frame_count: int, mode: str = 'base_changes',
                 refine: bool = True, validate_diffs: bool = True, use_cache: bool = True):
        super().__init__()
        self.gemini_client = gemini_client
        self.base_image = base_image
        self.animation_type = animation_type
        self.frame_count = frame_count
        self.mode = mode
        self.refine = refine
        self.validate_diffs = validate_diffs
        self.use_cache = use_cache
        self.result = None
    
    def run(self):
        """Execute animation generation."""
        try:
            self.progress_updated.emit("Analyzing sprite structure...", 10)
            
            # Get change instructions from Gemini
            changes_data = self.gemini_client.analyze_frame_changes(
                self.base_image, self.animation_type, self.frame_count, self.use_cache
            )
            
            if changes_data is None:
                self.error_occurred.emit("Failed to analyze frame changes")
                return
            
            self.progress_updated.emit("Frame changes analyzed", 40)
            
            # Two-pass refinement
            if self.refine:
                self.progress_updated.emit("Refining animation smoothness...", 50)
                changes_data = self.gemini_client.refine_animation(
                    self.base_image, changes_data
                )
                self.progress_updated.emit("Animation refined", 60)
            
            # Generate frames
            self.progress_updated.emit("Generating frames...", 70)
            
            if self.mode == 'cumulative':
                # Cumulative changes (pose-state model)
                all_changes = [frame.get('changes', []) for frame in changes_data.get('frames', [])]
                frames = apply_cumulative_changes(self.base_image, all_changes)
            else:
                # Base + changes (each frame copies base)
                all_changes = [frame.get('changes', []) for frame in changes_data.get('frames', [])]
                frames = generate_frames_parallel(
                    self.base_image, all_changes, 
                    validate_diffs=self.validate_diffs
                )
            
            self.progress_updated.emit("Frames generated", 90)
            
            # Validate results
            if not frames or len(frames) != self.frame_count:
                self.error_occurred.emit(f"Expected {self.frame_count} frames, got {len(frames) if frames else 0}")
                return
            
            self.progress_updated.emit("Animation complete", 100)
            self.result = {
                'frames': frames,
                'changes_data': changes_data
            }
            self.finished.emit()
            
        except Exception as e:
            self.error_occurred.emit(f"Error generating animation: {str(e)}")


class AnchorDetectionWorkerThread(QThread):
    """Worker thread for detecting anchor points."""
    
    progress_updated = Signal(str, int)
    finished = Signal()
    error_occurred = Signal(str)
    
    def __init__(self, gemini_client: GeminiClient, base_image: np.ndarray):
        super().__init__()
        self.gemini_client = gemini_client
        self.base_image = base_image
        self.result = None
    
    def run(self):
        """Execute anchor detection."""
        try:
            self.progress_updated.emit("Detecting anchor points...", 50)
            anchors = self.gemini_client.detect_anchors(self.base_image)
            self.progress_updated.emit("Anchors detected", 100)
            self.result = anchors
            self.finished.emit()
        except Exception as e:
            self.error_occurred.emit(f"Error detecting anchors: {str(e)}")

