"""
AI Requirements Checker
Handles checking for AI-related dependencies
Users install packages via Extension Manager
"""

import importlib
import sys
from typing import List, Tuple, Optional


class RequirementChecker:
    """Checks for required AI packages."""
    
    REQUIRED_PACKAGES = {
        'google-generativeai': {
            'import_name': 'google.generativeai',
            'display_name': 'Google Generative AI (Gemini)',
            'description': 'Required for AI image generation and analysis',
            'dependencies': []
        },
        'requests': {
            'import_name': 'requests',
            'display_name': 'Requests',
            'description': 'Required for API calls (remove.bg, etc.)',
            'dependencies': []
        },
        'rembg': {
            'import_name': 'rembg',
            'display_name': 'rembg',
            'description': 'Free, offline background removal (requires onnxruntime)',
            'dependencies': ['onnxruntime']
        },
        'onnxruntime': {
            'import_name': 'onnxruntime',
            'display_name': 'ONNX Runtime',
            'description': 'Required dependency for rembg',
            'dependencies': []
        }
    }
    
    @staticmethod
    def check_package_with_dependencies(package_name: str, python_exe: str = None) -> Tuple[bool, List[str], Optional[str]]:
        """
        Check if a package and its dependencies are installed.
        
        Args:
            package_name: Name of the package to check
            python_exe: Python executable to use
        
        Returns:
            (is_installed, missing_dependencies, error_message)
        """
        package_info = RequirementChecker.REQUIRED_PACKAGES.get(package_name)
        if not package_info:
            return False, [], f"Unknown package: {package_name}"
        
        # Check main package
        is_installed, error = RequirementChecker.check_package(package_name, python_exe)
        if not is_installed:
            return False, [], error
        
        # Check dependencies
        missing_deps = []
        dependencies = package_info.get('dependencies', [])
        for dep in dependencies:
            dep_installed, _ = RequirementChecker.check_package(dep, python_exe)
            if not dep_installed:
                missing_deps.append(dep)
        
        if missing_deps:
            return False, missing_deps, f"Package installed but missing dependencies: {', '.join(missing_deps)}"
        
        return True, [], None
    
    @staticmethod
    def check_package(package_name: str, python_exe: str = None) -> Tuple[bool, Optional[str]]:
        """
        Check if a package is installed.
        Uses the same method as Extension Manager (pip list) for consistency.
        
        Args:
            package_name: Name of the package to check
            python_exe: Python executable to use (if None, uses sys.executable)
        
        Returns:
            (is_installed, error_message)
        """
        package_info = RequirementChecker.REQUIRED_PACKAGES.get(package_name)
        if not package_info:
            return False, f"Unknown package: {package_name}"
        
        import_name = package_info['import_name']
        
        # Method 1: Try importing the module directly (fastest)
        try:
            importlib.import_module(import_name)
            return True, None
        except ImportError:
            # Import failed - check via pip list (same as Extension Manager)
            pass
        
        # Method 2: Check via pip list (same method Extension Manager uses)
        # This is more reliable because it checks what's actually installed
        try:
            import subprocess
            import json
            
            # Use provided python_exe or default to sys.executable
            if python_exe is None:
                python_exe = sys.executable
            
            # Run pip list to check if package is installed
            result = subprocess.run(
                [python_exe, "-m", "pip", "list", "--format=json"],
                capture_output=True,
                text=True,
                timeout=10
            )
            
            if result.returncode == 0:
                packages = json.loads(result.stdout)
                # Check if package is in the list (case-insensitive)
                package_name_lower = package_name.lower()
                for pkg in packages:
                    if pkg.get("name", "").lower() == package_name_lower:
                        # Package is installed according to pip
                        # Clear import cache and try importing again
                        importlib.invalidate_caches()
                        # Clear from sys.modules if present (in case of failed import)
                        modules_to_clear = [m for m in sys.modules.keys() if m == import_name or m.startswith(import_name + '.')]
                        for mod in modules_to_clear:
                            del sys.modules[mod]
                        
                        # Try importing again
                        try:
                            importlib.import_module(import_name)
                            return True, None
                        except ImportError as import_err:
                            # Package is installed according to pip but can't be imported
                            # This could mean:
                            # 1. Missing dependencies (but package is there)
                            # 2. Package needs a restart to be available
                            # 3. Import error for other reasons
                            # Since Extension Manager shows it as installed, we trust that
                            # and consider it installed - the import error will surface later
                            # when actually using it, which is better than blocking the user now
                            return True, None
        except Exception:
            # pip check failed - fall back to import check
            pass
        
        # All methods failed - package is not installed
        return False, f"Package '{package_name}' not found"
    
    @staticmethod
    def check_all_packages() -> List[Tuple[str, bool, Optional[str]]]:
        """
        Check all required packages.
        
        Returns:
            List of (package_name, is_installed, error_message)
        """
        results = []
        for package_name in RequirementChecker.REQUIRED_PACKAGES.keys():
            is_installed, error = RequirementChecker.check_package(package_name)
            results.append((package_name, is_installed, error))
        return results
    
    @staticmethod
    def get_missing_packages() -> List[str]:
        """Get list of missing package names."""
        missing = []
        for package_name, is_installed, _ in RequirementChecker.check_all_packages():
            if not is_installed:
                missing.append(package_name)
        return missing
    
    @staticmethod
    def get_package_display_name(package_name: str) -> str:
        """Get display name for a package."""
        package_info = RequirementChecker.REQUIRED_PACKAGES.get(package_name, {})
        return package_info.get('display_name', package_name)
    
    @staticmethod
    def get_package_description(package_name: str) -> str:
        """Get description for a package."""
        package_info = RequirementChecker.REQUIRED_PACKAGES.get(package_name, {})
        return package_info.get('description', '')
