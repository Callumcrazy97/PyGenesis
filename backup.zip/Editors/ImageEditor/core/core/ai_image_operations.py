"""
AI Image Operations Helper
Supports Gemini, OpenAI, and Claude for image generation, inpainting, and editing
"""

import json
import base64
import io
from typing import Optional, Tuple, Dict, Any
import numpy as np
from PIL import Image
import requests


class AIQuotaExceededError(Exception):
    """Raised when AI API quota/rate limit is exceeded"""
    def __init__(self, message: str, provider: str, retry_after: Optional[float] = None):
        super().__init__(message)
        self.provider = provider
        self.retry_after = retry_after  # Seconds to wait before retry


def _check_and_raise_quota_error(e: Exception, provider: str) -> None:
    """Check if exception is a quota/rate limit error and raise AIQuotaExceededError if so."""
    error_str = str(e)
    
    # Check for quota/rate limit indicators
    is_quota_error = (
        "429" in error_str or
        "quota" in error_str.lower() or
        "rate limit" in error_str.lower() or
        "exceeded" in error_str.lower() and ("limit" in error_str.lower() or "quota" in error_str.lower())
    )
    
    if is_quota_error:
        # Extract retry delay if available
        retry_after = None
        import re
        retry_match = re.search(r'retry in ([\d.]+)s?', error_str, re.IGNORECASE)
        if retry_match:
            retry_after = float(retry_match.group(1))
        else:
            # Check for retry_delay in structured format
            retry_match = re.search(r'retry_delay.*?seconds[:\s]+([\d.]+)', error_str, re.IGNORECASE)
            if retry_match:
                retry_after = float(retry_match.group(1))
        
        # Build provider-specific help message
        if "gemini" in provider.lower() or "google" in provider.lower():
            help_url = "https://ai.dev/usage?tab=rate-limit"
            help_text = "Gemini: https://ai.dev/usage?tab=rate-limit"
        elif "openai" in provider.lower() or "chatgpt" in provider.lower():
            help_url = "https://platform.openai.com/usage"
            help_text = "OpenAI: https://platform.openai.com/usage"
        elif "claude" in provider.lower() or "anthropic" in provider.lower():
            help_url = "https://console.anthropic.com/settings/limits"
            help_text = "Claude: https://console.anthropic.com/settings/limits"
        else:
            help_text = "Check your API provider's usage dashboard"
        
        retry_msg = ""
        if retry_after:
            retry_msg = f"\n\nPlease wait {int(retry_after)} seconds before trying again."
        else:
            retry_msg = "\n\nPlease wait a few minutes before trying again."
        
        raise AIQuotaExceededError(
            f"API quota/rate limit exceeded for {provider}.\n\n"
            f"Error details: {error_str[:500]}\n\n"
            f"To check your usage and limits:\n"
            f"• {help_text}{retry_msg}",
            provider,
            retry_after
        )


class AIImageOperations:
    """Unified AI image operations for multiple providers"""
    
    def __init__(self, provider: str, api_key: str):
        """
        Initialize AI image operations.
        
        Args:
            provider: "Gemini (Google)", "ChatGPT (OpenAI)", "Claude (Anthropic)", or "Local AI"
            api_key: API key for the provider
        """
        self.provider = provider
        self.api_key = api_key
        self.model = None
        
        if provider == "Gemini (Google)":
            # Try to import at runtime (venv path may be added later)
            try:
                import google.generativeai as genai
                genai.configure(api_key=api_key)
                self.model = genai.GenerativeModel('gemini-2.0-flash-exp')
            except ImportError:
                raise ImportError(
                    "google-generativeai package is required for Gemini.\n\n"
                    "Please install it via Extension Manager:\n"
                    "1. Go to: Tools → Extension Manager\n"
                    "2. Search for: google-generativeai\n"
                    "3. Click Install\n"
                    "4. Restart PyGenesis after installation"
                )
        elif provider == "ChatGPT (OpenAI)":
            self.api_key = api_key
        elif provider == "Claude (Anthropic)":
            self.api_key = api_key
        else:
            raise ValueError(f"Unsupported provider: {provider}")
    
    def generate_image(self, prompt: str, size: Tuple[int, int] = (512, 512)) -> Optional[np.ndarray]:
        """
        Generate an image from a text prompt.
        
        Args:
            prompt: Text description of the image
            size: (width, height) in pixels
        
        Returns:
            RGBA numpy array or None if generation fails
        """
        if self.provider == "Gemini (Google)":
            return self._generate_gemini(prompt, size)
        elif self.provider == "ChatGPT (OpenAI)":
            return self._generate_openai(prompt, size)
        elif self.provider == "Claude (Anthropic)":
            return self._generate_claude(prompt, size)
        return None
    
    def inpaint_image(self, image: np.ndarray, mask: np.ndarray, prompt: str = "remove object and fill background seamlessly") -> Optional[np.ndarray]:
        """
        Remove objects from an image using AI inpainting.
        
        Args:
            image: Original RGBA image as numpy array
            mask: Binary mask (255 = area to remove, 0 = keep) as numpy array
            prompt: Description of what to fill the area with
        
        Returns:
            RGBA numpy array with object removed, or None if fails
        """
        if self.provider == "Gemini (Google)":
            return self._inpaint_gemini(image, mask, prompt)
        elif self.provider == "ChatGPT (OpenAI)":
            return self._inpaint_openai(image, mask, prompt)
        elif self.provider == "Claude (Anthropic)":
            return self._inpaint_claude(image, mask, prompt)
        return None
    
    def remove_background(self, image: np.ndarray) -> Optional[np.ndarray]:
        """
        Remove background from an image using AI.
        
        Args:
            image: Original RGBA image as numpy array
        
        Returns:
            RGBA numpy array with transparent background, or None if fails
        """
        if self.provider == "Gemini (Google)":
            return self._remove_background_gemini(image)
        elif self.provider == "ChatGPT (OpenAI)":
            return self._remove_background_openai(image)
        elif self.provider == "Claude (Anthropic)":
            return self._remove_background_claude(image)
        return None
    
    def generate_animation_frames(self, base_image: np.ndarray, animation_type: str, frame_count: int) -> Optional[list]:
        """
        Generate animation frames from a base sprite.
        
        Args:
            base_image: Base sprite image (RGBA numpy array)
            animation_type: Type of animation ("jump", "run", "walk", "sit", "crawl", etc.)
            frame_count: Number of frames to generate
        
        Returns:
            List of RGBA numpy arrays (frames) or None if generation fails
        """
        if self.provider == "Gemini (Google)":
            return self._generate_animation_gemini(base_image, animation_type, frame_count)
        elif self.provider == "ChatGPT (OpenAI)":
            return self._generate_animation_openai(base_image, animation_type, frame_count)
        elif self.provider == "Claude (Anthropic)":
            return self._generate_animation_claude(base_image, animation_type, frame_count)
        return None
    
    # === Gemini Implementation ===
    
    def _remove_background_gemini(self, image: np.ndarray) -> Optional[np.ndarray]:
        """Remove background using Gemini."""
        try:
            if self.model is None:
                # Re-initialize if model wasn't set (shouldn't happen, but safety check)
                import google.generativeai as genai
                genai.configure(api_key=self.api_key)
                self.model = genai.GenerativeModel('gemini-2.0-flash-exp')
            
            pil_image = Image.fromarray(image, mode='RGBA')
            
            prompt = """Remove the background from this image, making it transparent.
Keep only the main subject/foreground object.
The result should have a transparent background (alpha channel).
Preserve all details and colors of the foreground object."""
            
            response = self.model.generate_content([pil_image, prompt])
            
            # Extract result image
            result_image = self._extract_image_from_gemini_response(response)
            if result_image is None:
                return None
            
            result_array = np.array(result_image.convert('RGBA'))
            
            # Ensure transparency is preserved
            return result_array
        except Exception as e:
            _check_and_raise_quota_error(e, self.provider)
            # Re-raise other exceptions
            raise
    
    def _generate_gemini(self, prompt: str, size: Tuple[int, int]) -> Optional[np.ndarray]:
        """Generate image using Gemini."""
        try:
            full_prompt = f"""Create a pixel art sprite: {prompt}
Size: {size[0]}x{size[1]} pixels
Format: PNG with transparency
Background: Transparent"""
            
            response = self.model.generate_content(full_prompt)
            
            # Extract image from response
            image = self._extract_image_from_gemini_response(response)
            if image is None:
                return None
            
            # Convert to numpy array
            image_array = np.array(image.convert('RGBA'))
            
            # Resize if needed
            if image_array.shape[:2] != (size[1], size[0]):
                image = Image.fromarray(image_array, mode='RGBA')
                image = image.resize(size, Image.Resampling.LANCZOS)
                image_array = np.array(image)
            
            return image_array
        except Exception as e:
            _check_and_raise_quota_error(e, self.provider)
            print(f"Gemini generation error: {e}")
            return None
    
    def _inpaint_gemini(self, image: np.ndarray, mask: np.ndarray, prompt: str) -> Optional[np.ndarray]:
        """Inpaint using Gemini."""
        try:
            # Convert to PIL
            pil_image = Image.fromarray(image, mode='RGBA')
            pil_mask = Image.fromarray(mask, mode='L')
            
            # Create prompt
            full_prompt = f"""Remove the object marked in the mask and fill the area seamlessly with the background.
{prompt}
Make sure the result looks natural and professional."""
            
            # Gemini can handle image + mask inputs
            response = self.model.generate_content([
                pil_image,
                f"Mask (white = remove, black = keep):",
                pil_mask,
                full_prompt
            ])
            
            # Extract result image
            result_image = self._extract_image_from_gemini_response(response)
            if result_image is None:
                return None
            
            result_array = np.array(result_image.convert('RGBA'))
            
            # Blend with original (keep non-masked areas from original)
            result = image.copy()
            mask_bool = mask > 128
            result[mask_bool] = result_array[mask_bool]
            
            return result
        except Exception as e:
            _check_and_raise_quota_error(e, self.provider)
            print(f"Gemini inpainting error: {e}")
            return None
    
    def _generate_animation_gemini(self, base_image: np.ndarray, animation_type: str, frame_count: int) -> Optional[list]:
        """Generate animation frames using Gemini."""
        try:
            pil_image = Image.fromarray(base_image, mode='RGBA')
            
            prompt = f"""Create a {animation_type} animation with {frame_count} frames from this base sprite.
Generate {frame_count} variations showing the animation cycle.
Each frame should show the sprite in a different pose of the {animation_type} animation.
Return the frames as separate images."""
            
            # Request multiple images (Gemini can generate multiple)
            response = self.model.generate_content([pil_image, prompt])
            
            # Extract all images from response
            frames = self._extract_multiple_images_from_gemini_response(response)
            
            if not frames:
                return None
            
            # Convert to numpy arrays
            frame_arrays = []
            for frame in frames:
                frame_array = np.array(frame.convert('RGBA'))
                frame_arrays.append(frame_array)
            
            # If we got fewer frames than requested, duplicate the last frame
            while len(frame_arrays) < frame_count:
                frame_arrays.append(frame_arrays[-1].copy())
            
            return frame_arrays[:frame_count]
        except Exception as e:
            _check_and_raise_quota_error(e, self.provider)
            print(f"Gemini animation generation error: {e}")
            return None
    
    # === OpenAI Implementation ===
    
    def _generate_openai(self, prompt: str, size: Tuple[int, int]) -> Optional[np.ndarray]:
        """Generate image using OpenAI DALL-E."""
        try:
            # DALL-E 3 supports specific sizes
            size_str = "1024x1024"  # DALL-E 3 default
            if size[0] <= 256 and size[1] <= 256:
                size_str = "256x256"
            elif size[0] <= 512 and size[1] <= 512:
                size_str = "512x512"
            
            response = requests.post(
                "https://api.openai.com/v1/images/generations",
                headers={
                    "Authorization": f"Bearer {self.api_key}",
                    "Content-Type": "application/json"
                },
                json={
                    "model": "dall-e-3",
                    "prompt": f"Pixel art sprite: {prompt}, transparent background, {size[0]}x{size[1]} pixels",
                    "n": 1,
                    "size": size_str,
                    "response_format": "b64_json"
                },
                timeout=60
            )
            
            if response.status_code != 200:
                error_text = response.text
                # Check for quota/rate limit (429)
                if response.status_code == 429:
                    raise AIQuotaExceededError(
                        f"API rate limit exceeded for {self.provider}.\n\n"
                        f"Error: {error_text}\n\n"
                        f"Please check your usage: https://platform.openai.com/usage\n"
                        f"Wait a few minutes before trying again.",
                        self.provider
                    )
                print(f"OpenAI API error: {error_text}")
                return None
            
            data = response.json()
            if "data" not in data or not data["data"]:
                return None
            
            # Decode base64 image
            image_data = base64.b64decode(data["data"][0]["b64_json"])
            image = Image.open(io.BytesIO(image_data))
            
            # Convert to RGBA and resize
            image = image.convert('RGBA')
            if image.size != size:
                image = image.resize(size, Image.Resampling.LANCZOS)
            
            return np.array(image)
        except AIQuotaExceededError:
            raise  # Re-raise quota errors
        except Exception as e:
            print(f"OpenAI generation error: {e}")
            return None
    
    def _inpaint_openai(self, image: np.ndarray, mask: np.ndarray, prompt: str) -> Optional[np.ndarray]:
        """Inpaint using OpenAI (requires image editing API)."""
        try:
            # Convert image and mask to base64
            pil_image = Image.fromarray(image, mode='RGBA')
            pil_mask = Image.fromarray(mask, mode='L')
            
            # Save to bytes
            img_buffer = io.BytesIO()
            pil_image.save(img_buffer, format='PNG')
            img_b64 = base64.b64encode(img_buffer.getvalue()).decode('utf-8')
            
            mask_buffer = io.BytesIO()
            pil_mask.save(mask_buffer, format='PNG')
            mask_b64 = base64.b64encode(mask_buffer.getvalue()).decode('utf-8')
            
            # OpenAI image editing API
            response = requests.post(
                "https://api.openai.com/v1/images/edits",
                headers={
                    "Authorization": f"Bearer {self.api_key}"
                },
                files={
                    "image": ("image.png", img_buffer.getvalue(), "image/png"),
                    "mask": ("mask.png", mask_buffer.getvalue(), "image/png")
                },
                data={
                    "prompt": prompt,
                    "n": 1,
                    "size": f"{image.shape[1]}x{image.shape[0]}",
                    "response_format": "b64_json"
                },
                timeout=60
            )
            
            if response.status_code != 200:
                error_text = response.text
                # Check for quota/rate limit (429)
                if response.status_code == 429:
                    raise AIQuotaExceededError(
                        f"API rate limit exceeded for {self.provider}.\n\n"
                        f"Error: {error_text}\n\n"
                        f"Please check your usage: https://platform.openai.com/usage\n"
                        f"Wait a few minutes before trying again.",
                        self.provider
                    )
                print(f"OpenAI inpainting error: {error_text}")
                return None
            
            data = response.json()
            if "data" not in data or not data["data"]:
                return None
            
            # Decode result
            result_data = base64.b64decode(data["data"][0]["b64_json"])
            result_image = Image.open(io.BytesIO(result_data))
            result_array = np.array(result_image.convert('RGBA'))
            
            # Blend with original
            result = image.copy()
            mask_bool = mask > 128
            result[mask_bool] = result_array[mask_bool]
            
            return result
        except AIQuotaExceededError:
            raise  # Re-raise quota errors
        except Exception as e:
            print(f"OpenAI inpainting error: {e}")
            return None
    
    def _generate_animation_openai(self, base_image: np.ndarray, animation_type: str, frame_count: int) -> Optional[list]:
        """Generate animation frames using OpenAI."""
        # OpenAI doesn't support multi-image generation in one call
        # Generate frames one by one
        frames = []
        for i in range(frame_count):
            # Create a prompt that describes the frame
            frame_prompt = f"Frame {i+1} of {frame_count} of a {animation_type} animation, pixel art sprite, transparent background"
            
            # For now, return None as this would require multiple API calls
            # Could be implemented with a loop, but would be expensive
            return None
        
        return frames
    
    # === Claude Implementation ===
    
    def _remove_background_claude(self, image: np.ndarray) -> Optional[np.ndarray]:
        """Remove background using Claude."""
        # Claude doesn't have native image editing capabilities
        print("Claude does not support background removal directly")
        return None
    
    def _generate_claude(self, prompt: str, size: Tuple[int, int]) -> Optional[np.ndarray]:
        """Generate image using Claude (Anthropic)."""
        # Claude doesn't have native image generation
        # Would need to use a different service or return None
        print("Claude does not support image generation directly")
        return None
    
    def _inpaint_claude(self, image: np.ndarray, mask: np.ndarray, prompt: str) -> Optional[np.ndarray]:
        """Inpaint using Claude."""
        # Claude doesn't have native inpainting
        # Would need to use a different service or return None
        print("Claude does not support inpainting directly")
        return None
    
    def _generate_animation_claude(self, base_image: np.ndarray, animation_type: str, frame_count: int) -> Optional[list]:
        """Generate animation frames using Claude."""
        # Claude doesn't support image generation
        return None
    
    # === Helper Methods ===
    
    def _extract_image_from_gemini_response(self, response) -> Optional[Image.Image]:
        """Extract image from Gemini response."""
        try:
            if hasattr(response, 'candidates') and response.candidates:
                for candidate in response.candidates:
                    if hasattr(candidate, 'content') and candidate.content:
                        for part in candidate.content.parts:
                            if hasattr(part, 'inline_data'):
                                image_data = part.inline_data.data
                                return Image.open(io.BytesIO(base64.b64decode(image_data)))
                            elif hasattr(part, 'text') and 'data:image' in part.text:
                                import re
                                match = re.search(r'data:image/[^;]+;base64,([A-Za-z0-9+/=]+)', part.text)
                                if match:
                                    image_data = base64.b64decode(match.group(1))
                                    return Image.open(io.BytesIO(image_data))
        except Exception as e:
            print(f"Error extracting image from Gemini response: {e}")
        return None
    
    def _extract_multiple_images_from_gemini_response(self, response) -> list:
        """Extract multiple images from Gemini response."""
        images = []
        try:
            if hasattr(response, 'candidates') and response.candidates:
                for candidate in response.candidates:
                    if hasattr(candidate, 'content') and candidate.content:
                        for part in candidate.content.parts:
                            if hasattr(part, 'inline_data'):
                                image_data = part.inline_data.data
                                images.append(Image.open(io.BytesIO(base64.b64decode(image_data))))
        except Exception as e:
            print(f"Error extracting images from Gemini response: {e}")
        return images

