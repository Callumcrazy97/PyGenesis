import threading
import queue
import time
from typing import Callable, Any, Optional
from PySide6.QtCore import QObject, Signal, QThread, QTimer

class BackgroundTask:
    """Represents a background task with progress tracking"""
    
    def __init__(self, task_id: str, operation: str, func: Callable, args: tuple = (), kwargs: dict = None):
        self.task_id = task_id
        self.operation = operation
        self.func = func
        self.args = args or ()
        self.kwargs = kwargs or {}
        self.progress = 0
        self.status = "pending"  # pending, running, completed, failed, cancelled
        self.result = None
        self.error = None
        self.start_time = None
        self.end_time = None

class BackgroundWorker(QThread):
    """Worker thread for background processing"""
    
    task_started = Signal(str)  # task_id
    task_progress = Signal(str, int)  # task_id, progress
    task_completed = Signal(str, object)  # task_id, result
    task_failed = Signal(str, str)  # task_id, error_message
    task_cancelled = Signal(str)  # task_id
    
    def __init__(self, task_queue: queue.Queue, result_queue: queue.Queue):
        super().__init__()
        self.task_queue = task_queue
        self.result_queue = result_queue
        self.running = True
        self.current_task = None
    
    def run(self):
        while self.running:
            try:
                # Get task from queue with timeout
                task = self.task_queue.get(timeout=0.1)
                if task is None:  # Shutdown signal
                    break
                
                self.current_task = task
                task.status = "running"
                task.start_time = time.time()
                
                self.task_started.emit(task.task_id)
                
                try:
                    # Execute the task
                    result = task.func(*task.args, **task.kwargs)
                    task.result = result
                    task.status = "completed"
                    task.end_time = time.time()
                    
                    self.task_completed.emit(task.task_id, result)
                    
                except Exception as e:
                    task.error = str(e)
                    task.status = "failed"
                    task.end_time = time.time()
                    
                    self.task_failed.emit(task.task_id, str(e))
                
                finally:
                    self.current_task = None
                    
            except queue.Empty:
                continue
            except Exception as e:
                print(f"Background worker error: {e}")
    
    def stop(self):
        self.running = False
        if self.current_task:
            self.current_task.status = "cancelled"
            self.task_cancelled.emit(self.current_task.task_id)

class BackgroundProcessor(QObject):
    """Main background processing manager"""
    
    task_added = Signal(str, str)  # task_id, operation
    task_started = Signal(str)
    task_progress = Signal(str, int)
    task_completed = Signal(str, object)
    task_failed = Signal(str, str)
    task_cancelled = Signal(str)
    
    def __init__(self, max_workers: int = 2):
        super().__init__()
        self.max_workers = max_workers
        self.task_queue = queue.Queue()
        self.result_queue = queue.Queue()
        self.workers = []
        self.tasks = {}  # task_id -> BackgroundTask
        self.task_counter = 0
        
        self._start_workers()
    
    def _start_workers(self):
        """Start background worker threads"""
        for i in range(self.max_workers):
            worker = BackgroundWorker(self.task_queue, self.result_queue)
            worker.task_started.connect(self.task_started.emit)
            worker.task_progress.connect(self.task_progress.emit)
            worker.task_completed.connect(self.task_completed.emit)
            worker.task_failed.connect(self.task_failed.emit)
            worker.task_cancelled.connect(self.task_cancelled.emit)
            
            worker.start()
            self.workers.append(worker)
    
    def submit_task(self, operation: str, func: Callable, args: tuple = (), kwargs: dict = None) -> str:
        """Submit a task for background processing"""
        self.task_counter += 1
        task_id = f"task_{self.task_counter}_{operation.lower().replace(' ', '_')}"
        
        task = BackgroundTask(task_id, operation, func, args, kwargs)
        self.tasks[task_id] = task
        
        self.task_queue.put(task)
        self.task_added.emit(task_id, operation)
        
        return task_id
    
    def get_task_status(self, task_id: str) -> Optional[str]:
        """Get the status of a task"""
        if task_id in self.tasks:
            return self.tasks[task_id].status
        return None
    
    def get_task_result(self, task_id: str) -> Any:
        """Get the result of a completed task"""
        if task_id in self.tasks and self.tasks[task_id].status == "completed":
            return self.tasks[task_id].result
        return None
    
    def cancel_task(self, task_id: str) -> bool:
        """Cancel a pending task"""
        if task_id in self.tasks and self.tasks[task_id].status == "pending":
            self.tasks[task_id].status = "cancelled"
            return True
        return False
    
    def get_active_tasks(self) -> list:
        """Get list of active task IDs"""
        return [task_id for task_id, task in self.tasks.items() 
                if task.status in ["pending", "running"]]
    
    def cleanup_completed_tasks(self, max_age_seconds: int = 3600):
        """Clean up old completed tasks"""
        current_time = time.time()
        to_remove = []
        
        for task_id, task in self.tasks.items():
            if task.status in ["completed", "failed", "cancelled"]:
                if task.end_time and (current_time - task.end_time) > max_age_seconds:
                    to_remove.append(task_id)
        
        for task_id in to_remove:
            del self.tasks[task_id]
    
    def shutdown(self):
        """Shutdown the background processor"""
        # Send shutdown signal to all workers
        for _ in self.workers:
            self.task_queue.put(None)
        
        # Wait for workers to finish
        for worker in self.workers:
            worker.stop()
            worker.wait()
        
        self.workers.clear()

# Global background processor instance
background_processor = None

def get_background_processor() -> BackgroundProcessor:
    """Get the global background processor instance"""
    global background_processor
    if background_processor is None:
        background_processor = BackgroundProcessor()
    return background_processor

def shutdown_background_processor():
    """Shutdown the global background processor"""
    global background_processor
    if background_processor:
        background_processor.shutdown()
        background_processor = None 